//! Prioritārā rinda, kas ieviesta ar bināro kaudzi.
//!
//! Lielākā elementa ievietošanai un atvēršanai ir *O*(log(*n*)) laika sarežģītība.
//! Lielākā elementa pārbaude ir *O*(1).vector konvertēšanu binārā kaudzē var veikt uz vietas, un tam ir sarežģītība *O*(*n*).
//! Bināro kaudzi var arī pārveidot par sakārtotu vector vietā, ļaujot to izmantot *O*(*n*\*log(* n*)) vietējā galvenajā ostā.
//!
//! # Examples
//!
//! Šis ir lielāks piemērs, kas ievieš [Dijkstra's algorithm][dijkstra], lai atrisinātu [shortest path problem][sssp] uz [directed graph][dir_graph].
//!
//! Tas parāda, kā lietot [`BinaryHeap`] ar pielāgotiem veidiem.
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // Prioritārā rinda ir atkarīga no `Ord`.
//! // Skaidri ieviesiet trait, lai rinda kļūtu par min-kaudzi, nevis par kaudzi.
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // Ievērojiet, ka mēs mainīsim pasūtījumu par izmaksām.
//!         // Vienāda rezultāta gadījumā mēs salīdzinām pozīcijas, šis solis ir nepieciešams, lai `PartialEq` un `Ord` ieviešana būtu konsekventa.
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` jāīsteno arī.
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // Īsākai ieviešanai katrs mezgls tiek attēlots kā `usize`.
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // Dijkstra īsākā ceļa algoritms.
//!
//! // Sāciet ar `start` un izmantojiet `dist`, lai izsekotu pašreizējo īsāko attālumu līdz katram mezglam.Šī ieviešana nav efektīva atmiņā, jo tā var atstāt mezglu dublikātus rindā.
//! //
//! // Vienkāršākai ieviešanai tā izmanto arī `usize::MAX` kā sūtījuma vērtību.
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // dist [mezgls]=pašreizējais īsākais attālums no `start` līdz `node`
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // Mēs esam pie `start`, ar nulles izmaksām
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // Vispirms pārbaudiet robežu ar zemāku izmaksu mezgliem (min-heap)
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // Alternatīvi mēs būtu varējuši turpināt atrast visus īsākos ceļus
//!         if position == goal { return Some(cost); }
//!
//!         // Tas ir svarīgi, jo mēs, iespējams, jau esam atraduši labāku veidu
//!         if cost > dist[position] { continue; }
//!
//!         // Katram mezglam, kuru mēs varam sasniegt, pārbaudiet, vai mēs varam atrast veidu, kā iet caur šo mezglu ar zemākām izmaksām
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // Ja tā, pievienojiet to robežai un turpiniet
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // Atpūta, tagad esam atraduši labāku veidu
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // Mērķis nav sasniedzams
//!     None
//! }
//!
//! fn main() {
//!     // Šis ir virzītais grafiks, kuru mēs izmantosim.
//!     // Mezglu numuri atbilst dažādiem stāvokļiem, un edge svars simbolizē pārvietošanās izmaksas no viena mezgla uz otru.
//!     //
//!     // Ņemiet vērā, ka malas ir vienvirziena.
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          v 1 2 |2
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10 ||
//!     //                   +---------------+
//!     //
//!     // Grafiks tiek attēlots kā blakusesošs saraksts, kur katram indeksam, kas atbilst mezgla vērtībai, ir izejošo malu saraksts.
//!     // Izvēlēts tā efektivitātes dēļ.
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // Mezgls 0
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // 1. mezgls
//!         vec![Edge { node: 3, cost: 2 }],
//!         // 2. mezgls
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // 3. mezgls
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // 4. mezgls
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// Prioritārā rinda, kas ieviesta ar bināro kaudzi.
///
/// Tas būs maks-kaudze.
///
/// Ir loģiska kļūda, ja vienumu modificē tā, ka vienuma secība attiecībā pret jebkuru citu priekšmetu, ko nosaka `Ord` trait, mainās, kamēr tas atrodas kaudzē.
///
/// Parasti tas ir iespējams tikai ar `Cell`, `RefCell`, globālo stāvokli, I/O vai nedrošu kodu.
/// Rīcība, kas izriet no šādas loģiskās kļūdas, nav norādīta, taču neizraisīs nedefinētu rīcību.
/// Tas var ietvert panics, nepareizus rezultātus, pārtraukumus, atmiņas noplūdi un nepārtraukšanu.
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // Tipa secinājums ļauj mums izlaist skaidru tipa parakstu (kas šajā piemērā būtu `BinaryHeap<i32>`).
/////
/// let mut heap = BinaryHeap::new();
///
/// // Mēs varam izmantot palūrēšanu, lai apskatītu nākamo kaudzes priekšmetu.
/// // Šajā gadījumā tur vēl nav neviena priekšmeta, tāpēc mēs to nedarām.
/// assert_eq!(heap.peek(), None);
///
/// // Pievienosim dažus rādītājus ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // Tagad palūrēšana parāda vissvarīgāko kaudzes priekšmetu.
/// assert_eq!(heap.peek(), Some(&5));
///
/// // Mēs varam pārbaudīt kaudzes garumu.
/// assert_eq!(heap.len(), 3);
///
/// // Mēs varam atkārtot kaudzes priekšmetus, lai gan tie tiek atgriezti nejaušā secībā.
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // Ja mēs šo popu vietā izlecam, viņiem vajadzētu atgriezties kārtībā.
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // Mēs varam notīrīt kaudzi no visiem atlikušajiem priekšmetiem.
/// heap.clear();
///
/// // Kaudzei tagad jābūt tukšai.
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// Lai `BinaryHeap` padarītu par min-kaudzi, var izmantot vai nu `std::cmp::Reverse`, vai pielāgotu `Ord` ieviešanu.
/// Tas liek `heap.pop()` atgriezt mazāko vērtību, nevis lielāko.
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // Aptiniet vērtības `Reverse`
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // Ja mēs šos rādītājus izmantosim tagad, tiem vajadzētu atgriezties apgrieztā secībā.
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # Laika sarežģītība
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// `push` vērtība ir paredzamās izmaksas;metodes dokumentācija sniedz detalizētāku analīzi.
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// Struktūra, kurā ir maināma atsauce uz `BinaryHeap` lielāko vienumu.
///
///
/// Šis `struct` ir izveidots ar [`peek_mut`] metodi uz [`BinaryHeap`].
/// Plašāku informāciju skatiet tās dokumentācijā.
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // DROŠĪBA: PeekMut tiek aktivizēts tikai tukšām kaudzēm.
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // DROŠI: PeekMut tiek instancēts tikai tukšām kaudzēm
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // DROŠI: PeekMut tiek instancēts tikai tukšām kaudzēm
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// Noņem lūrēto vērtību no kaudzes un atgriež to.
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// Izveido tukšu `BinaryHeap<T>`.
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// Izveido tukšu `BinaryHeap` kā maksimālu kaudzi.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// Izveido tukšu `BinaryHeap` ar noteiktu ietilpību.
    /// Tas sākotnēji piešķir pietiekami daudz atmiņas `capacity` elementiem, tāpēc `BinaryHeap` nav jāpārdala, līdz tajā ir vismaz tik daudz vērtību.
    ///
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// Atgriež maināmu atsauci uz lielāko vienumu binārā kaudzē vai `None`, ja tas ir tukšs.
    ///
    /// Note: Ja `PeekMut` vērtība ir noplūdusi, kaudze var būt pretrunīgā stāvoklī.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # Laika sarežģītība
    ///
    /// Ja vienums tiek modificēts, sliktākajā gadījumā laika sarežģītība ir *O*(log(*n*)), pretējā gadījumā tas ir *O*(1).
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// Noņem lielāko vienumu no binārā kaudzes un atdod to vai `None`, ja tas ir tukšs.
    ///
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # Laika sarežģītība
    ///
    /// Sliktākās `pop` izmaksas uz kaudzi, kas satur *n* elementus, ir *O*(log(*n*)).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // DROŠĪBA: !self.is_empty() nozīmē, ka self.len()> 0
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// Pabīda priekšmetu uz binārā kaudzes.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # Laika sarežģītība
    ///
    /// Paredzamās `push` izmaksas, vidēji aprēķinot katru iespējamo bīdāmo elementu secību un pietiekami lielu skaitu grūdienu, ir *O*(1).
    ///
    /// Šī ir visnozīmīgākā izmaksu metrika, virzot elementus, kas *nav* jau pēc jebkura sakārtota modeļa.
    ///
    /// Laika sarežģītība pasliktinās, ja elementi tiek virzīti galvenokārt augošā secībā.
    /// Sliktākajā gadījumā elementi tiek virzīti augošā secībā, un amortizētās izmaksas par vienu grūdienu ir *O*(log(*n*)) pret kaudzi, kas satur *n* elementus.
    ///
    /// Sliktākā *viena* zvana uz `push` cena ir *O*(*n*).Sliktākais gadījums rodas, ja jauda ir izsmelta un tai ir nepieciešams mainīt izmērus.
    /// Pārmaiņas izmaksas ir amortizētas iepriekšējos skaitļos.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // DROŠĪBA: Tā kā mēs ievietojām jaunu priekšmetu, tas nozīmē
        //  old_len= self.len(), 1 <self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    /// Patērē `BinaryHeap` un atgriež vector sakārtotā (ascending) secībā.
    ///
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // DROŠĪBA: `end` iet no `self.len() - 1` uz 1 (abi iekļauti),
            //  tāpēc piekļuvei tas vienmēr ir derīgs indekss.
            //  Ir droši piekļūt indeksam 0 (ti, `ptr`), jo
            //  1 <=beigas <self.len(), kas nozīmē self.len()>=2.
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // DROŠĪBA: `end` pāriet no `self.len() - 1` uz 1 (abi iekļauti), tātad:
            //  0 <1 <=beigas <= self.len(), 1 <self.len() Kas nozīmē 0 <beigas un beigas <self.len().
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // Sift_up un sift_down realizācijā tiek izmantoti nedroši bloki, lai pārvietotu elementu no vector (atstājot aiz cauruma), pārvietotos pa citiem un pārvietotu noņemto elementu atpakaļ vector cauruma galīgajā vietā.
    //
    // `Hole` tips tiek izmantots, lai to parādītu, un pārliecinieties, ka caurums ir aizpildīts atpakaļ tā darbības jomas beigās, pat izmantojot panic.
    // Cauruma izmantošana samazina nemainīgo koeficientu salīdzinājumā ar mijmaiņas darījumiem, kas ietver divreiz vairāk kustību.
    //
    //
    //
    //

    /// # Safety
    ///
    /// Zvanītājam ir jāgarantē, ka `pos < self.len()`.
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // Izņemiet vērtību pie `pos` un izveidojiet caurumu.
        // DROŠĪBA: Zvanītājs garantē, ka pozīcija <self.len()
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // DROŠĪBA: hole.pos()> start>=0, kas nozīmē hole.pos()> 0
            //  un tāpēc hole.pos(), 1 nevar pārplūst.
            //  Tas garantē, ka vecākam <hole.pos(), tāpēc tas ir derīgs indekss un arī!= hole.pos().
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // DROŠĪBA: Tas pats, kas iepriekš
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// Paņemiet elementu pie `pos` un pārvietojiet to uz leju, kamēr tā bērni ir lielāki.
    ///
    ///
    /// # Safety
    ///
    /// Zvanītājam ir jāgarantē, ka `pos < end <= self.len()`.
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // DROŠĪBA: zvanītājs garantē, ka pozīcija <beigas <= self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Cilpas nemainīgais: bērns==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // salīdziniet ar lielāko no diviem bērniem DROŠĪBA: bērns <beigas, 1 <self.len() un bērns + 1 <beigas <= self.len(), tāpēc tie ir derīgi indeksi.
            //
            //  bērns==2 *hole.pos() + 1!= hole.pos() un bērns + 1==2* hole.pos() + 2!= hole.pos().
            // FIXME: 2 *hole.pos() + 1 vai 2* hole.pos() + 2 varētu pārplūst, ja T ir ZST
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // ja jau esam kārtībā, apstājies.
            // DROŠĪBA: bērns tagad ir vai nu vecs, vai vecs bērns + 1
            //  Mēs jau esam pierādījuši, ka abi ir <self.len() un!= hole.pos()
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // DROŠĪBA: tāda pati kā iepriekš.
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // DROŠĪBA: &&īssavienojums, kas nozīmē, ka
        //  otrais nosacījums jau ir taisnība, ka bērns==beigas, 1 <self.len().
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // DROŠĪBA: bērns jau ir pierādīts kā derīgs indekss un
            //  bērns==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// Zvanītājam ir jāgarantē, ka `pos < self.len()`.
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // DROŠĪBA: poz <len garantē zvanītājs un
        //  acīmredzami len= self.len() <= self.len().
        unsafe { self.sift_down_range(pos, len) };
    }

    /// Paņemiet elementu pie `pos` un pārvietojiet to līdz galam uz leju, pēc tam izsijājiet to līdz tā pozīcijai.
    ///
    ///
    /// Note: Tas notiek ātrāk, ja zināms, ka elements ir liels/tam vajadzētu būt tuvāk apakšai.
    ///
    /// # Safety
    ///
    /// Zvanītājam ir jāgarantē, ka `pos < self.len()`.
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // DROŠĪBA: Zvanītājs garantē, ka pozīcija <self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Cilpas nemainīgais: bērns==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // DROŠĪBA: bērns <beigas, 1 <self.len() un
            //  bērns + 1 <beigas <= self.len(), tāpēc tie ir derīgi indeksi.
            //  bērns==2 *hole.pos() + 1!= hole.pos() un bērns + 1==2* hole.pos() + 2!= hole.pos().
            //
            // FIXME: 2 *hole.pos() + 1 vai 2* hole.pos() + 2 varētu pārplūst, ja T ir ZST
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // DROŠĪBA: Tas pats, kas iepriekš
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // DROŠĪBA: bērns==beigas, 1 <self.len(), tāpēc tas ir derīgs indekss
            //  un bērns==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // DROŠĪBA: poz ir pozīcija urbumā, un tas jau tika pierādīts
        //  ir derīgs indekss.
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // DROŠĪBA: n sākas no self.len()/2 un iet uz leju līdz 0.
            //  Vienīgais gadījums, kad! (N <self.len()) ir, ja self.len() ==0, bet to izslēdz cilpas nosacījums.
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// Pārvieto visus `other` elementus uz `self`, atstājot `other` tukšu.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` veic O(len1 + len2) operācijas un apmēram 2 *(len1 + len2) salīdzinājumus sliktākajā gadījumā, kamēr `extend` veic O(len2* log(len1)) operācijas un apmēram 1 *len2* log_2(len1) salīdzinājumus sliktākajā gadījumā, pieņemot, ka len1>= len2.
        // Lielākiem kaudzēm šķērsošanas punkts vairs neatbilst šim pamatojumam un tika noteikts empīriski.
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// Atgriež atkārtotāju, kas izgūst elementus kaudzes secībā.
    /// Iegūtie elementi tiek noņemti no sākotnējā kaudzes.
    /// Pārējie elementi tiks noņemti, nokrītot kaudzes secībā.
    ///
    /// Note:
    /// * `.drain_sorted()` ir *O*(*n*\*log(* n*)); daudz lēnāk nekā `.drain()`.
    ///   Lielākajā daļā gadījumu jums vajadzētu izmantot pēdējo.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // noņem visus elementus kaudzes secībā
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// Saglabā tikai predikātā norādītos elementus.
    ///
    /// Citiem vārdiem sakot, noņemiet visus elementus `e` tā, lai `f(&e)` atgrieztu `false`.
    /// Elementi tiek apmeklēti nešķirotā (un nenoteiktā) secībā.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // tur tikai pāra skaitļus
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// Atgriež atkārtotāju, kas patvaļīgā secībā apmeklē visas vērtības pamatā esošajā vector.
    ///
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Izdrukājiet 1, 2, 3, 4 patvaļīgā secībā
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// Atgriež atkārtotāju, kas izgūst elementus kaudzes secībā.
    /// Šī metode patērē sākotnējo kaudzi.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// Atgriež lielāko vienumu binārā kaudzē vai `None`, ja tas ir tukšs.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # Laika sarežģītība
    ///
    /// Izmaksas sliktākajā gadījumā ir *O*(1).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// Atgriež to elementu skaitu, kurus binārā kaudze var saturēt, nepārdalot tos citādi.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// Rezervē minimālo ietilpību precīzi `additional` vairāk elementu ievietošanai dotajā `BinaryHeap`.
    /// Neko nedara, ja jauda jau ir pietiekama.
    ///
    /// Ņemiet vērā, ka piešķīrējs var piešķirt kolekcijai vairāk vietas, nekā tas prasa.
    /// Tāpēc nevar paļauties, ka jauda ir precīzi minimāla.
    /// Dodiet priekšroku [`reserve`], ja ir paredzami future ievietojumi.
    ///
    /// # Panics
    ///
    /// Panics, ja jaunā jauda pārpilda `usize`.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// Rezervē jaudu vismaz vēl `additional` elementiem, kas jāievieto `BinaryHeap`.
    /// Kolekcijā var būt vairāk vietas, lai izvairītos no biežas pārdalīšanas.
    ///
    /// # Panics
    ///
    /// Panics, ja jaunā jauda pārpilda `usize`.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// Izmet pēc iespējas vairāk papildu jaudas.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// Izmet ietilpību ar apakšējo robežu.
    ///
    /// Jauda paliks vismaz tikpat liela kā garums, tā piegādātā vērtība.
    ///
    ///
    /// Ja pašreizējā jauda ir mazāka par apakšējo robežu, tas ir aizliegts.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// Patērē `BinaryHeap` un patvaļīgā secībā atgriež pamatā esošo vector.
    ///
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // Drukās kādā secībā
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// Atgriež binārā kaudzes garumu.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// Pārbauda, vai binārā kaudze ir tukša.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Notīra bināro kaudzi, atgriežot iteratoru virs noņemtajiem elementiem.
    ///
    /// Elementi tiek noņemti patvaļīgā secībā.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// Nomet visus vienumus no binārā kaudzes.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// Hole apzīmē cauruma daļu, ti, indeksu bez derīgas vērtības (jo tas tika pārvietots vai dublēts).
///
/// Pilienā `Hole` atjaunos šķēli, aizpildot cauruma pozīciju ar sākotnēji noņemto vērtību.
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// Izveidojiet jaunu `Hole` indeksā `pos`.
    ///
    /// Droša, jo pozīcijai jābūt datu slānī.
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // DROŠI: pozīcijai jābūt šķēles iekšpusē
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// Atgriež atsauci uz noņemto elementu.
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// Atgriež atsauci uz elementu `index`.
    ///
    /// Nedrošs, jo indeksam jābūt datu slānī, un tam nav jābūt vienādam ar poz.
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// Pārvietot caurumu uz jaunu vietu
    ///
    /// Nedrošs, jo indeksam jābūt datu slānī, un tam nav jābūt vienādam ar poz.
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // atkal aizpildiet caurumu
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// Iterators pār `BinaryHeap` elementiem.
///
/// Šo `struct` izveidoja [`BinaryHeap::iter()`].
/// Plašāku informāciju skatiet tās dokumentācijā.
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) Noņemiet par labu `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// Īpašnieka iterators pār `BinaryHeap` elementiem.
///
/// Šo `struct` ir izveidojis [`BinaryHeap::into_iter()`] (nodrošina `IntoIterator` trait).
/// Plašāku informāciju skatiet tās dokumentācijā.
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// Drenējošs iterators virs `BinaryHeap` elementiem.
///
/// Šo `struct` izveidoja [`BinaryHeap::drain()`].
/// Plašāku informāciju skatiet tās dokumentācijā.
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// Drenējošs iterators virs `BinaryHeap` elementiem.
///
/// Šo `struct` izveidoja [`BinaryHeap::drain_sorted()`].
/// Plašāku informāciju skatiet tās dokumentācijā.
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// Noņem kaudzes elementus kaudzes secībā.
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// Pārvērš `Vec<T>` par `BinaryHeap<T>`.
    ///
    /// Šī konversija notiek uz vietas, un tai ir sarežģītība *O*(*n*).
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// Pārvērš `BinaryHeap<T>` par `Vec<T>`.
    ///
    /// Šī konvertēšana neprasa datu pārvietošanu vai piešķiršanu, un tai ir nemainīga laika sarežģītība.
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Izveido patērējošu iteratoru, tas ir, kas katru vērtību patvaļīgā secībā pārvieto no binārā kaudzes.
    /// Bināro kaudzi pēc šī izsaukšanas nevar izmantot.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Izdrukājiet 1, 2, 3, 4 patvaļīgā secībā
    /// for x in heap.into_iter() {
    ///     // x ir i32 tips, nevis &i32
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}