//! Atsauces skaitīšanas norādes ar vienu vītni.'Rc' nozīmē 'Atsauce
//! Counted'.
//!
//! [`Rc<T>`][`Rc`] tips nodrošina koplietojuma tiesības uz `T` tipa vērtību, kas piešķirta kaudzē.
//! [`clone`][clone] izsaukšana uz [`Rc`] rada jaunu rādītāju tam pašam sadalījumam kaudzē.
//! Kad tiek iznīcināts pēdējais norādītā piešķīruma [`Rc`] rādītājs, tiek izmesta arī šajā piešķīrumā saglabātā vērtība (bieži saukta par "inner value").
//!
//! Rust koplietotās atsauces pēc noklusējuma neatļauj mutāciju, un [`Rc`] nav izņēmums: parasti nevar iegūt maināmu atsauci uz kaut ko [`Rc`].
//! Ja jums ir nepieciešama mainīgums, [`Rc`] iekšpusē ievietojiet [`Cell`] vai [`RefCell`];skatiet [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] izmanto atomu atskaites skaitīšanu.
//! Tas nozīmē, ka pieskaitāmās izmaksas ir ļoti zemas, bet [`Rc`] nevar nosūtīt starp pavedieniem, un tāpēc [`Rc`] neievieš [`Send`][send].
//! Rezultātā Rust kompilators kompilēšanas laikā * pārbaudīs, vai jūs nesūtāt [`Rc`] s starp pavedieniem.
//! Ja jums nepieciešams vairāku vītņu atomu atskaites skaitīšana, izmantojiet [`sync::Arc`][arc].
//!
//! Lai izveidotu [`Weak`] rādītāju, kas nepieder, [`downgrade`][downgrade] metodi var izmantot.
//! [`Weak`] rādītājs var būt [`jauninājums`][jauninājums] d uz [`Rc`], taču tas atgriezīs [`None`], ja piešķīrumā saglabātā vērtība jau būs nomesta.
//! Citiem vārdiem sakot, `Weak` rādītāji neuztur vērtību sadalījuma iekšpusē;tomēr viņi *saglabā* piešķīrumu (iekšējās vērtības pamatkrātuvi).
//!
//! Cikls starp [`Rc`] rādītājiem nekad netiks sadalīts.
//! Šī iemesla dēļ [`Weak`] tiek izmantots ciklu pārtraukšanai.
//! Piemēram, kokam var būt spēcīgi [`Rc`] rādītāji no vecāku mezgliem līdz bērniem, un [`Weak`] rādītāji no bērniem atpakaļ uz vecākiem.
//!
//! `Rc<T>` automātiski novirzes no `T` (izmantojot [`Deref`] trait), lai jūs varētu izsaukt `T` metodes ar vērtību [`Rc<T>`][`Rc`].
//! Lai izvairītos no vārdu sadursmēm ar `T` metodēm, pašas [`Rc<T>`][`Rc`] metodes ir saistītas funkcijas, kuras sauc par [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>traits, piemēram, `Clone`, ieviešanu var izsaukt arī, izmantojot pilnībā kvalificētu sintaksi.
//! Daži cilvēki dod priekšroku pilnībā kvalificētai sintaksei, bet citi-metodi zvana sintaksei.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Metode-zvana sintakse
//! let rc2 = rc.clone();
//! // Pilnībā kvalificēta sintakse
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] automātiski nenovirza no `T`, jo iekšējā vērtība, iespējams, jau ir samazināta.
//!
//! # Klonēšanas atsauces
//!
//! Jaunas atsauces izveidošana tam pašam piešķīrumam kā esošajam atsauces skaitītajam rādītājam tiek veikta, izmantojot `Clone` trait, kas ieviesta [`Rc<T>`][`Rc`] un [`Weak<T>`][`Weak`].
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Divas zemāk minētās sintakse ir līdzvērtīgas.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a un b abi norāda uz to pašu atmiņas vietu, kur foo.
//! ```
//!
//! `Rc::clone(&from)` sintakse ir visidiodiskākā, jo tā precīzāk izsaka koda nozīmi.
//! Iepriekš minētajā piemērā šī sintakse ļauj vieglāk saprast, ka šis kods rada jaunu atsauci, nevis kopē visu foo saturu.
//!
//! # Examples
//!
//! Apsveriet scenāriju, kurā `sīkrīku` kopa pieder attiecīgajam `Owner`.
//! Mēs vēlamies, lai mūsu sīkrīks norāda uz viņu `Owner`.Mēs to nevaram izdarīt ar unikālām īpašumtiesībām, jo vienam un tam pašam `Owner` var piederēt vairāki sīkrīki.
//! [`Rc`] ļauj mums koplietot `Owner` starp vairākiem sīkrīkiem un `Owner` tiek piešķirts tik ilgi, kamēr tajā atrodas visi `Gadget` punkti.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... citi lauki
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... citi lauki
//! }
//!
//! fn main() {
//!     // Izveidojiet atsauces skaitīto `Owner`.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Izveidojiet `sīkrīku`, kas pieder `gadget_owner`.
//!     // `Rc<Owner>` klonēšana dod mums jaunu rādītāju tam pašam `Owner` sadalījumam, palielinot atsauces skaitu procesā.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Atbrīvojieties no mūsu vietējā mainīgā `gadget_owner`.
//!     drop(gadget_owner);
//!
//!     // Neskatoties uz `gadget_owner` nomešanu, mēs joprojām varam izdrukāt `sīkrīka `Owner` nosaukumu.
//!     // Tas ir tāpēc, ka mēs esam izmetuši tikai vienu `Rc<Owner>`, nevis `Owner`, uz kuru tas norāda.
//!     // Kamēr tajā pašā `Owner` sadalījumā ir citi `Rc<Owner>` norādījumi, tas paliks aktīvs.
//!     // Lauka projekcija `gadget1.owner.name` darbojas, jo `Rc<Owner>` automātiski novirza uz `Owner`.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // Funkcijas beigās `gadget1` un `gadget2` tiek iznīcinātas, un līdz ar tām pēdējās saskaitītās atsauces uz mūsu `Owner`.
//!     // Arī sīkrīku vīrietis tagad tiek iznīcināts.
//!     //
//! }
//! ```
//!
//! Ja mainīsies mūsu prasības un mums arī jāspēj pāriet no `Owner` uz `Gadget`, mums radīsies problēmas.
//! [`Rc`] rādītājs no `Owner` līdz `Gadget` ievada ciklu.
//! Tas nozīmē, ka viņu atsauces skaits nekad nevar sasniegt 0 un piešķiršana nekad netiks iznīcināta:
//! atmiņas noplūde.Lai to apietu, mēs varam izmantot [`Weak`] rādītājus.
//!
//! Rust faktiski nedaudz apgrūtina šīs cilpas ražošanu.Lai iegūtu divas vērtības, kas norāda viena uz otru, vienai no tām jābūt maināmām.
//! Tas ir grūti, jo [`Rc`] nodrošina atmiņas drošību, izsniedzot tikai kopīgas atsauces uz vērtību, kuru tā aptver, un tie nepieļauj tiešu mutāciju.
//! Vērtības daļa, kuru mēs vēlamies mutēt, jāiesaiņo [`RefCell`], kas nodrošina *iekšējo mutabilitāti*: metodi, lai panāktu mutabilitāti, izmantojot kopīgu atsauci.
//! [`RefCell`] izpilda Rust aizņemšanās noteikumus izpildes laikā.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... citi lauki
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... citi lauki
//! }
//!
//! fn main() {
//!     // Izveidojiet atsauces skaitīto `Owner`.
//!     // Ņemiet vērā, ka mēs esam ievietojuši `Sīkrīka` īpašnieka vector `RefCell` iekšpusē, lai mēs to varētu mutēt, izmantojot kopīgu atsauci.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Izveidojiet `sīkrīku`, kas pieder `gadget_owner`, tāpat kā iepriekš.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Pievienojiet `sīkrīku` viņu `Owner`.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` dinamiskais aizņēmums beidzas šeit.
//!     }
//!
//!     // Atkārtojiet mūsu sīkrīku, izdrukājot viņu detaļas.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` ir `Weak<Gadget>`.
//!         // Tā kā `Weak` rādītāji nevar garantēt, ka piešķiršana joprojām pastāv, mums jāzvana uz `upgrade`, kas atgriež `Option<Rc<Gadget>>`.
//!         //
//!         //
//!         // Šajā gadījumā mēs zinām, ka piešķiršana joprojām pastāv, tāpēc mēs vienkārši `unwrap` `Option`.
//!         // Sarežģītākā programmā `None` rezultātam var būt nepieciešama gracioza kļūdu apstrāde.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // Funkcijas beigās `gadget_owner`, `gadget1` un `gadget2` tiek iznīcināti.
//!     // Tagad sīkrīkiem nav spēcīgu (`Rc`) norāžu, tāpēc tie tiek iznīcināti.
//!     // Tas novērš sīkrīka atsauces skaitu, tāpēc arī viņš tiek iznīcināts.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Tas ir izturīgs pret repr(C) līdz future pret iespējamu lauka pārkārtošanu, kas traucētu citādi drošu pārveidojamo iekšējo tipu [into|from]_raw().
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Viena pavediena atsauces skaitīšanas rādītājs.'Rc' nozīmē 'Atsauce
/// Counted'.
///
/// Plašāku informāciju skatiet [module-level documentation](./index.html).
///
/// `Rc` raksturīgās metodes ir visas saistītās funkcijas, kas nozīmē, ka jums tās jāizsauc, piemēram, [`Rc::get_mut(&mut value)`][get_mut], nevis `value.get_mut()`.
/// Tas ļauj izvairīties no konfliktiem ar iekšējā tipa `T` metodēm.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Šis nedrošums ir kārtībā, jo, kamēr šis Rc ir dzīvs, mēs garantējam, ka iekšējais rādītājs ir derīgs.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Konstruē jaunu `Rc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Pastāv netiešs vājš rādītājs, kas pieder visiem spēcīgajiem rādītājiem, kas nodrošina, ka vājš iznīcinātājs nekad neatbrīvo piešķiršanu, kamēr darbojas spēcīgais iznīcinātājs, pat ja vājais rādītājs tiek saglabāts spēcīgā iekšpusē.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Konstruē jaunu `Rc<T>`, izmantojot vāju atsauci uz sevi.
    /// Mēģinot uzlabot vājo atsauci pirms šīs funkcijas atgriešanās, tiks iegūta vērtība `None`.
    ///
    /// Tomēr vājo atsauci var brīvi klonēt un uzglabāt lietošanai vēlāk.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... vairāk lauku
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Iekšējo "uninitialized" stāvoklī izveidojiet ar vienu vāju atsauci.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Ir svarīgi, lai mēs neatstātu vājā rādītāja īpašumtiesības, pretējā gadījumā atmiņa var tikt atbrīvota līdz `data_fn` atgriešanās brīdim.
        // Ja mēs patiešām vēlētos nodot īpašumtiesības, mēs varētu izveidot sev papildu vāju rādītāju, taču tas novestu pie vāja atsauces skaita papildu atjauninājumiem, kas citādi varētu nebūt vajadzīgi.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Spēcīgām atsaucēm kopā vajadzētu būt kopīgai vājajai atsaucei, tāpēc nedarbiniet iznīcinātāju mūsu vecajai vājajai atsaucei.
        //
        mem::forget(weak);
        strong
    }

    /// Konstruē jaunu `Rc` ar neinicializētu saturu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Atliktā inicializācija:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Konstruē jaunu `Rc` ar neinicializētu saturu, atmiņai piepildot `0` baitus.
    ///
    ///
    /// Šīs metodes pareizas un nepareizas izmantošanas piemērus skatiet [`MaybeUninit::zeroed`][zeroed].
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Konstruē jaunu `Rc<T>`, atgriežot kļūdu, ja piešķiršana neizdodas
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Pastāv netiešs vājš rādītājs, kas pieder visiem spēcīgajiem rādītājiem, kas nodrošina, ka vājš iznīcinātājs nekad neatbrīvo piešķiršanu, kamēr darbojas spēcīgais iznīcinātājs, pat ja vājais rādītājs tiek saglabāts spēcīgā iekšpusē.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Konstruē jaunu `Rc` ar neinicializētu saturu, atgriežot kļūdu, ja piešķiršana neizdodas
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Atliktā inicializācija:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Konstruē jaunu `Rc` ar neinicializētu saturu, atmiņai piepildot `0` baitus, atgriežot kļūdu, ja piešķiršana neizdodas
    ///
    ///
    /// Šīs metodes pareizas un nepareizas izmantošanas piemērus skatiet [`MaybeUninit::zeroed`][zeroed].
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Konstruē jaunu `Pin<Rc<T>>`.
    /// Ja `T` neievieš `Unpin`, tad `value` tiks piestiprināts atmiņā un to nevarēs pārvietot.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Atgriež iekšējo vērtību, ja `Rc` ir tieši viena spēcīga atsauce.
    ///
    /// Pretējā gadījumā [`Err`] tiek atgriezts ar to pašu `Rc`, kas tika ievadīts.
    ///
    ///
    /// Tas izdosies pat tad, ja ir izcilas vājas atsauces.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // nokopējiet ietverto objektu

                // Norādiet Weaks, ka tos nevar reklamēt, samazinot spēcīgo skaitu, un pēc tam noņemiet netiešo "strong weak" rādītāju, vienlaikus rīkojoties ar kritiena loģiku, vienkārši izveidojot viltus vāju.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Izveido jaunu atsaucēs saskaitītu šķēli ar neinicializētu saturu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Atliktā inicializācija:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Konstruē jaunu atsauču skaitāmo šķēli ar neinicializētu saturu, atmiņai piepildot `0` baitus.
    ///
    ///
    /// Šīs metodes pareizas un nepareizas izmantošanas piemērus skatiet [`MaybeUninit::zeroed`][zeroed].
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Pārvērš par `Rc<T>`.
    ///
    /// # Safety
    ///
    /// Tāpat kā [`MaybeUninit::assume_init`] gadījumā, zvanītāja ziņā ir garantēt, ka iekšējā vērtība patiešām ir inicializēta.
    ///
    /// Tā saukšana, kad saturs vēl nav pilnībā inicializēts, rada tūlītēju nedefinētu rīcību.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Atliktā inicializācija:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Pārvērš par `Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// Tāpat kā [`MaybeUninit::assume_init`] gadījumā, zvanītāja ziņā ir garantēt, ka iekšējā vērtība patiešām ir inicializēta.
    ///
    /// Tā saukšana, kad saturs vēl nav pilnībā inicializēts, rada tūlītēju nedefinētu rīcību.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Atliktā inicializācija:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Patērē `Rc`, atgriežot iesaiņoto rādītāju.
    ///
    /// Lai izvairītos no atmiņas noplūdes, rādītājs jāpārvērš atpakaļ uz `Rc`, izmantojot [`Rc::from_raw`][from_raw].
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Nodrošina neapstrādātu rādītāju datiem.
    ///
    /// Skaiti netiek ietekmēti nekādā veidā, un `Rc` netiek patērēts.
    /// Rādītājs ir derīgs tik ilgi, kamēr `Rc` ir spēcīgs skaits.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // DROŠĪBA: To nevar izmantot, izmantojot Deref::deref vai Rc::inner, jo
        // tas ir nepieciešams, lai saglabātu raw/mut izcelsmi tā, ka, piem
        // `get_mut` var rakstīt caur rādītāju pēc tam, kad Rc ir atkopts caur `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// No jēlrādītāja izveido `Rc<T>`.
    ///
    /// Neapstrādātajam rādītājam jābūt iepriekš atgrieztam ar zvanu uz [`Rc<U>::into_raw`][into_raw], kur `U` jābūt tādam pašam izmēram un izlīdzinājumam kā `T`.
    /// Tas ir triviāli taisnība, ja `U` ir `T`.
    /// Ņemiet vērā, ka, ja `U` nav `T`, bet tam ir vienāds izmērs un izlīdzinājums, tas būtībā līdzinās dažādu veidu atsauču pārveidošanai.
    /// Plašāku informāciju par šajā gadījumā piemērojamiem ierobežojumiem skatiet vietnē [`mem::transmute`][transmute].
    ///
    /// `from_raw` lietotājam ir jāpārliecinās, ka konkrēta `T` vērtība tiek nomesta tikai vienu reizi.
    ///
    /// Šī funkcija ir nedroša, jo nepareiza lietošana var izraisīt atmiņas nedrošību, pat ja atgrieztajam `Rc<T>` nekad netiek piekļūts.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Pārvērtiet atpakaļ uz `Rc`, lai novērstu noplūdi.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Turpmāki zvani uz `Rc::from_raw(x_ptr)` būtu nedroši atmiņā.
    /// }
    ///
    /// // Atmiņa tika atbrīvota, kad `x` izgāja no iepriekš minētās darbības jomas, tāpēc `x_ptr` tagad karājas!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Apgrieziet nobīdi, lai atrastu sākotnējo RcBox.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Šim piešķīrumam tiek izveidots jauns [`Weak`] rādītājs.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Pārliecinieties, ka mēs neradām nokareno Vājo
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Tiek iegūts [`Weak`] rādītāju skaits šim sadalījumam.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Saņem spēcīgu (`Rc`) rādītāju skaitu šim sadalījumam.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Atgriež `true`, ja šim piešķīrumam nav citu `Rc` vai [`Weak`] rādītāju.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Atgriež maināmo atsauci dotajā `Rc`, ja tam pašam piešķīrumam nav citu `Rc` vai [`Weak`] rādītāju.
    ///
    ///
    /// Atgriež [`None`] citādi, jo nav droši mutēt koplietojamo vērtību.
    ///
    /// Skatiet arī [`make_mut`][make_mut], kas [`clone`][clone] samazinās iekšējo vērtību, ja ir citas norādes.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Atgriež maināmo atsauci dotajā `Rc` bez jebkādas pārbaudes.
    ///
    /// Skatiet arī [`get_mut`], kas ir drošs un veic atbilstošas pārbaudes.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Visiem citiem `Rc` vai [`Weak`] rādītājiem uz to pašu piešķīrumu nedrīkst ieturēt norādi uz atdotā aizņēmuma laiku.
    ///
    /// Tas ir nenozīmīgi, ja šādu norāžu nav, piemēram, tūlīt pēc `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Mēs uzmanīgi *neveidojam* atsauci, kas aptver laukus "count", jo tas būtu pretrunā ar piekļuvi atsauču skaitam (piem.,
        // ar `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Atgriež `true`, ja abi Rc norāda uz to pašu sadalījumu (vēnā, kas līdzīga [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Padara maināmu atsauci uz norādīto `Rc`.
    ///
    /// Ja tam pašam piešķīrumam ir citi `Rc` rādītāji, tad `make_mut` [`clone`] iekasēs jaunā piešķīruma iekšējo vērtību, lai nodrošinātu unikālas īpašumtiesības.
    /// To sauc arī par rakstīšanu uz klona.
    ///
    /// Ja šim piešķīrumam nav citu `Rc` rādītāju, tad šī piešķīruma [`Weak`] rādītāji tiks atdalīti.
    ///
    /// Skatiet arī [`get_mut`], kas neizdosies, nevis klonēs.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Neklonēs neko
    /// let mut other_data = Rc::clone(&data);    // Neklonēs iekšējos datus
    /// *Rc::make_mut(&mut data) += 1;        // Klonē iekšējos datus
    /// *Rc::make_mut(&mut data) += 1;        // Neklonēs neko
    /// *Rc::make_mut(&mut other_data) *= 2;  // Neklonēs neko
    ///
    /// // Tagad `data` un `other_data` norāda uz dažādiem piešķīrumiem.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] norādes tiks atdalītas:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Jāklonē dati, ir arī citi Rcs.
            // Iepriekš piešķiriet atmiņu, lai varētu tieši rakstīt klonēto vērtību.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Var vienkārši nozagt datus, atliek tikai Weaks
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Noņemiet netiešo spēcīgo un vājo atsauci (šeit nav nepieciešams izveidot viltus vāju-mēs zinām, ka citi Weaks var mums iztīrīt)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Šis nedrošums ir kārtībā, jo mēs garantējam, ka atgrieztais rādītājs ir *vienīgais* rādītājs, kas kādreiz tiks atgriezts T.
        // Šajā brīdī tiek garantēts, ka mūsu atskaites skaitlis ir 1, un mēs pieprasījām, lai pats `Rc<T>` būtu `mut`, tāpēc mēs atgriezīsim vienīgo iespējamo atsauci uz piešķiršanu.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Mēģinājums `Rc<dyn Any>` samazināt līdz konkrētam tipam.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Piešķir `RcBox<T>` ar pietiekamu vietu, iespējams, neizmērāmai iekšējai vērtībai, kur vērtībai ir paredzēts izkārtojums.
    ///
    /// Funkcija `mem_to_rcbox` tiek izsaukta ar datu rādītāju, un tai jāatgriež `RcBox<T>` (iespējams, tauku) rādītājs.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Aprēķiniet izkārtojumu, izmantojot norādīto vērtību izkārtojumu.
        // Iepriekš izkārtojums tika aprēķināts izteiksmē `&*(ptr as* const RcBox<T>)`, taču tas radīja nepareizu atsauci (skat. #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Piešķir `RcBox<T>` ar pietiekamu vietu, iespējams, nesamērīgai iekšējai vērtībai, kur vērtībai ir paredzēts izkārtojums, atgriežot kļūdu, ja piešķiršana neizdodas.
    ///
    ///
    /// Funkcija `mem_to_rcbox` tiek izsaukta ar datu rādītāju, un tai jāatgriež `RcBox<T>` (iespējams, tauku) rādītājs.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Aprēķiniet izkārtojumu, izmantojot norādīto vērtību izkārtojumu.
        // Iepriekš izkārtojums tika aprēķināts izteiksmē `&*(ptr as* const RcBox<T>)`, taču tas radīja nepareizu atsauci (skat. #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Piešķirt izkārtojumam.
        let ptr = allocate(layout)?;

        // Inicializējiet RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Piešķir `RcBox<T>` ar pietiekamu vietu lieluma iekšējai vērtībai
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Piešķiriet `RcBox<T>`, izmantojot norādīto vērtību.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Kopēt vērtību kā baitus
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Bezmaksas piešķīrums, nemetot tā saturu
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Piešķir `RcBox<[T]>` ar norādīto garumu.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Kopējiet elementus no šķēles nesen piešķirtajā Rc <\[T\]>
    ///
    /// Nedroši, jo zvanītājam ir jāuzņemas īpašumtiesības vai jāsaista `T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// No iteratora izveido `Rc<[T]>`, kas, kā zināms, ir noteikta lieluma.
    ///
    /// Uzvedība nav noteikta, ja izmērs ir nepareizs.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Panic aizsargs, klonējot T elementus.
        // panic gadījumā elementi, kas ir ierakstīti jaunajā RcBox, tiks nomesti, pēc tam atmiņa atbrīvosies.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Rādītājs pirmajam elementam
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Viss skaidrs.Aizmirstiet aizsargu, lai tas neatbrīvo jauno RcBox.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Specializācija trait, ko izmanto `From<&[T]>`.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Nomet `Rc`.
    ///
    /// Tas samazinās spēcīgo atsauces skaitu.
    /// Ja spēcīgais atsauces skaits sasniedz nulli, tad vienīgās pārējās atsauces (ja tādas ir) ir [`Weak`], tāpēc mēs `drop` iekšējo vērtību.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Neko nedrukā
    /// drop(foo2);   // Izdrukā "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // iznīcināt turēto priekšmetu
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // noņemiet netiešo "strong weak" rādītāju tagad, kad esam iznīcinājuši tā saturu.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Izveido `Rc` rādītāja klonu.
    ///
    /// Tas rada vēl vienu rādītāju tam pašam sadalījumam, palielinot spēcīgo atsauču skaitu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Izveido jaunu `Rc<T>` ar `Default` vērtību `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Hack atļaut specializēties uz `Eq`, pat ja `Eq` ir metode.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Mēs šeit veicam šo specializāciju, nevis kā vispārīgāku `&T` optimizāciju, jo pretējā gadījumā tas palielinātu izmaksas visām vienlīdzības pārbaudēm uz atsaucēm.
/// Mēs pieņemam, ka `Rc` izmanto, lai uzglabātu lielas vērtības, kas ir lēni klonētas, bet arī smagas, lai pārbaudītu vienlīdzību, kā rezultātā šīs izmaksas vieglāk atmaksājas.
///
/// Visticamāk, ka tajā ir arī divi `Rc` kloni, kas norāda uz to pašu vērtību, nekā divi&T.
///
/// Mēs to varam izdarīt tikai tad, ja `T: Eq` kā `PartialEq` var būt apzināti nerefleksīvs.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Vienādība diviem `Rc`.
    ///
    /// Divas "Rc" ir vienādas, ja to iekšējās vērtības ir vienādas, pat ja tās tiek uzglabātas atšķirīgā sadalījumā.
    ///
    /// Ja `T` ievieš arī `Eq` (tas nozīmē vienlīdzības refleksivitāti), divi "Rc", kas norāda uz to pašu sadalījumu, vienmēr ir vienādi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Nevienlīdzība diviem `Rc`.
    ///
    /// Divi `Rc` ir nevienlīdzīgi, ja to iekšējās vērtības ir nevienādas.
    ///
    /// Ja `T` ievieš arī `Eq` (kas nozīmē vienlīdzības refleksivitāti), divi "Rc", kas norāda uz to pašu sadalījumu, nekad nav nevienlīdzīgi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Daļējs divu `Rc` salīdzinājums.
    ///
    /// Abus salīdzina, izsaucot `partial_cmp()` uz viņu iekšējām vērtībām.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Mazāk nekā salīdzinājums diviem `Rc`.
    ///
    /// Abus salīdzina, izsaucot `<` uz viņu iekšējām vērtībām.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// "Mazāks vai vienāds ar" divu "Rc" salīdzinājums.
    ///
    /// Abus salīdzina, izsaucot `<=` uz viņu iekšējām vērtībām.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Lielāks nekā divu `Rc` salīdzinājums.
    ///
    /// Abus salīdzina, izsaucot `>` uz viņu iekšējām vērtībām.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// "Lielāks par vai vienāds ar" divu "Rc" salīdzinājums.
    ///
    /// Abus salīdzina, izsaucot `>=` uz viņu iekšējām vērtībām.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Divu `Rc` salīdzinājums.
    ///
    /// Abus salīdzina, izsaucot `cmp()` uz viņu iekšējām vērtībām.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Piešķiriet atsauces skaitīto šķēli un aizpildiet to, klonējot `v` vienumus.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Piešķiriet atsauces skaitīto virknes daļu un iekopējiet tajā `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Piešķiriet atsauces skaitīto virknes daļu un iekopējiet tajā `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Pārvietojiet lodziņā ievietotu objektu uz jaunu, uzskaites atskaites punktu piešķiršanu.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Piešķiriet atsauces skaitīto šķēli un pārvietojiet tajā `v` elementus.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Ļaujiet Vec atbrīvot atmiņu, bet nesagraujiet tās saturu
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Paņem katru elementu `Iterator` un savāc to `Rc<[T]>`.
    ///
    /// # Veiktspējas raksturojums
    ///
    /// ## Vispārīgais gadījums
    ///
    /// Parasti kolekcionēšana `Rc<[T]>` tiek veikta, vispirms savācot `Vec<T>`.Tas ir, rakstot sekojošo:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// tas uzvedas tā, it kā mēs rakstītu:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Pirmais piešķīrumu kopums notiek šeit.
    ///     .into(); // Šeit notiek otrais piešķīrums `Rc<[T]>`.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Tas tiks piešķirts tik reižu, cik nepieciešams `Vec<T>` konstruēšanai, un pēc tam tas tiks piešķirts vienu reizi, lai `Vec<T>` pārvērstu par `Rc<[T]>`.
    ///
    ///
    /// ## Zināmā garuma iteratori
    ///
    /// Kad jūsu `Iterator` ievieš `TrustedLen` un tam ir precīzs izmērs, `Rc<[T]>` tiks piešķirts viens piešķīrums.Piemēram:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Šeit notiek tikai viena piešķiršana.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Specializācija trait, ko izmanto savākšanai `Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Tas attiecas uz `TrustedLen` iteratoru.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // DROŠĪBA: Mums jānodrošina, lai iteratoram būtu precīzs garums un mums ir.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Atgriezieties pie normālas ieviešanas.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` ir [`Rc`] versija, kurai ir atsauce uz pārvaldīto sadalījumu, kurai nepieder.Piešķīrumam var piekļūt, izsaucot [`upgrade`] uz `Weak` rādītāja, kas atgriež [Option]] <<[[Rc`]`<T>> ".
///
/// Tā kā `Weak` atsauce netiek ieskaitīta īpašumtiesībās, tā netraucēs nomest piešķīrumā saglabāto vērtību, un pats `Weak` nedod nekādas garantijas, ka vērtība joprojām ir.
/// Tādējādi tas var atgriezt [`None`], kad [`jaunināt`] d.
/// Tomēr ņemiet vērā, ka `Weak` atsauce * neļauj pašu izvietojumu (atbalsta krātuvi) sadalīt.
///
/// `Weak` rādītājs ir noderīgs, lai saglabātu pagaidu atsauci uz [`Rc`] pārvaldīto piešķīrumu, neļaujot nomest tā iekšējo vērtību.
/// To lieto arī, lai novērstu apļveida atsauces starp [`Rc`] rādītājiem, jo savstarpējas atsauces nekad neļautu nomest [`Rc`].
/// Piemēram, kokam var būt spēcīgi [`Rc`] rādītāji no vecāku mezgliem līdz bērniem, un `Weak` rādītāji no bērniem atpakaļ uz vecākiem.
///
/// Tipisks veids, kā iegūt `Weak` rādītāju, ir piezvanīt uz [`Rc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Šis ir `NonNull`, kas ļauj optimizēt šāda veida izmērus uzskaitēs, taču tas ne vienmēr ir derīgs rādītājs.
    //
    // `Weak::new` iestata šo vērtību `usize::MAX`, lai tai nebūtu jāpiešķir vieta kaudzē.
    // Tā nav vērtība, kāda reālam rādītājam jebkad būs, jo RcBox ir izlīdzināts vismaz 2.
    // Tas ir iespējams tikai tad, ja `T: Sized`;izmēra `T` nekad nenokarājas.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Konstruē jaunu `Weak<T>`, nepiešķirot atmiņu.
    /// Zvanot uz [`upgrade`] pēc atgriešanās vērtības, vienmēr tiek iegūts [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Palīga veids, lai atļautu piekļuvi atsauces skaitiem, neizteicot apgalvojumus par datu lauku.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Atgriež neapstrādātu rādītāju objektam `T`, uz kuru norāda šis `Weak<T>`.
    ///
    /// Rādītājs ir derīgs tikai tad, ja ir dažas spēcīgas atsauces.
    /// Rādītājs var būt karājošs, nesaskaņots vai pat [`null`] citādi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Abi norāda uz vienu un to pašu objektu
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Spēcīgais šeit uztur to dzīvu, tāpēc mēs joprojām varam piekļūt objektam.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Bet ne vairāk.
    /// // Mēs varam veikt weak.as_ptr(), taču piekļuve rādītājam novestu pie nedefinētas uzvedības.
    /// // assert_eq! ("sveiki", nedrošs {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Ja rādītājs karājas, mēs kontrolieri atdodam tieši.
            // Šī nevar būt derīga kravas adrese, jo derīgā krava ir vismaz tikpat līdzināta kā RcBox (usize).
            ptr as *const T
        } else {
            // DROŠĪBA: ja is_dangling atgriež false, tad rādītājs ir novirzāms.
            // Derīgā slodze šajā brīdī var samazināties, un mums ir jāsaglabā izcelsme, tāpēc izmantojiet neapstrādātu rādītāju manipulāciju.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Patērē `Weak<T>` un pārvērš to par neapstrādātu rādītāju.
    ///
    /// Tas pārvērš vājo rādītāju par neapstrādātu rādītāju, vienlaikus saglabājot vienas vājas atsauces īpašumtiesības (vājo skaitu šī darbība nemaina).
    /// Ar [`from_raw`] to var atkal pārvērst par `Weak<T>`.
    ///
    /// Tiek izmantoti tie paši ierobežojumi, kas attiecas uz piekļuvi rādītāja mērķim, kā ar [`as_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Pārvērš neapstrādātu rādītāju, kuru iepriekš izveidoja [`into_raw`], atpakaļ uz `Weak<T>`.
    ///
    /// To var izmantot, lai droši iegūtu spēcīgu atsauci (vēlāk piezvanot uz [`upgrade`]), vai vājo skaitļu sadalīšanai, nometot `Weak<T>`.
    ///
    /// Tam ir īpašumtiesības uz vienu vāju atsauci (izņemot [`new`] izveidotos rādītājus, jo tiem nekas nepieder; metode joprojām darbojas ar tiem).
    ///
    /// # Safety
    ///
    /// Rādītājam ir jābūt no [`into_raw`], un tam joprojām ir jābūt tā vājajai atsaucei.
    ///
    /// Lai to izsauktu, spēcīgajam skaitam ir atļauts būt 0.
    /// Neskatoties uz to, tas pārņem vienu vāju atsauci, kas pašlaik tiek attēlota kā neapstrādāts rādītājs (vājo skaitu šī darbība nemaina), un tāpēc tā ir jāsavieno pārī ar iepriekšējo zvanu uz [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Samazināt pēdējo vājo skaitu.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Skatiet Weak::as_ptr kontekstu par ievades rādītāja atvasināšanu.

        let ptr = if is_dangling(ptr as *mut T) {
            // Tas ir karājas vājš.
            ptr as *mut RcBox<T>
        } else {
            // Pretējā gadījumā mēs garantējam, ka rādītājs nāca no nepārspējama Vāja.
            // DROŠĪBA: data_offset ir droši izsaukt, jo ptr atsaucas uz reālu (potenciāli nokritušo) T.
            let offset = unsafe { data_offset(ptr) };
            // Tādējādi mēs mainām nobīdi, lai iegūtu visu RcBox.
            // DROŠĪBA: rādītājs ir radies no vāja, tāpēc šis nobīde ir droša.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // DROŠĪBA: tagad mēs esam atguvuši sākotnējo vājo rādītāju, tāpēc varam izveidot vājo.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Mēģinājumi jaunināt `Weak` rādītāju uz [`Rc`], veiksmīgi aizkavējot iekšējās vērtības samazināšanos.
    ///
    ///
    /// Atgriež vērtību [`None`], ja kopš tā laika iekšējā vērtība ir samazināta.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Iznīcini visus spēcīgos norādījumus.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Tiek iegūts spēcīgo (`Rc`) rādītāju skaits, kas norāda uz šo sadalījumu.
    ///
    /// Ja `self` tika izveidots, izmantojot [`Weak::new`], tas atgriezīs 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Tiek iegūts `Weak` rādītāju skaits, kas norāda uz šo sadalījumu.
    ///
    /// Ja nepaliks spēcīgas norādes, tas atgriezīs nulli.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // atņemt netiešo vājo ptr
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Atgriež vērtību `None`, kad rādītājs karājas un nav piešķirta `RcBox` (ti, kad šo `Weak` izveidoja `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Mēs uzmanīgi * neizveidojam atsauci, kas aptvertu "data" lauku, jo lauks var būt mutēts vienlaikus (piemēram, ja tiek nomests pēdējais `Rc`, datu lauks tiks nomests vietā).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Atgriež `true`, ja abi vājie norāda uz vienu un to pašu sadalījumu (līdzīgi kā [`ptr::eq`]) vai ja abi nenorāda uz kādu piešķīrumu (jo tie tika izveidoti ar `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Tā kā tas salīdzina rādītājus, tas nozīmē, ka `Weak::new()` būs līdzvērtīgi viens otram, kaut arī tie nenorāda uz nekādu sadalījumu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Salīdzinot `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Nomet `Weak` rādītāju.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Neko nedrukā
    /// drop(foo);        // Izdrukā "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // vājais skaitlis sākas ar 1, un nulle būs tikai tad, ja visi spēcīgie rādītāji būs pazuduši.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Izveido `Weak` rādītāja klonu, kas norāda uz to pašu sadalījumu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Konstruē jaunu `Weak<T>`, piešķirot atmiņu `T`, to neinicializējot.
    /// Zvanot uz [`upgrade`] pēc atgriešanās vērtības, vienmēr tiek iegūts [`None`].
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Mēs šeit pārbaudījām_pievienot, lai droši tiktu galā ar mem::forget.It īpaši
// Ja jūs mem::forget Rcs (vai Weaks), ref-count var pārpildīties, un pēc tam jūs varat atbrīvot piešķīrumu, kamēr pastāv izcili Rcs (vai Weaks).
//
// Mēs pārtraucam, jo tas ir tik deģenerēts scenārijs, ka mums nav svarīgi, kas notiek-nevienai reālai programmai to nekad nevajadzētu piedzīvot.
//
// Tam vajadzētu būt nenozīmīgai pieskaitāmajai daļai, jo, pateicoties īpašumtiesībām un pārvietošanās semantikai, patiesībā jums nav nepieciešams tik daudz klonēt Rust.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Mēs vēlamies pārtraukt pārplūdi, nevis samazināt vērtību.
        // Atsauces skaits nekad nebūs nulle, kad to izsauks;
        // tomēr mēs šeit ievietojam abortu, lai norādītu LLVM par citādi nokavētu optimizāciju.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Mēs vēlamies pārtraukt pārplūdi, nevis samazināt vērtību.
        // Atsauces skaits nekad nebūs nulle, kad to izsauks;
        // tomēr mēs šeit ievietojam abortu, lai norādītu LLVM par citādi nokavētu optimizāciju.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Iegūstiet nobīdi `RcBox` robežās par lietderīgo slodzi aiz rādītāja.
///
/// # Safety
///
/// Rādītājam jānorāda uz iepriekš derīgu T gadījumu (un tiem ir derīgi metadati), taču T ir atļauts nomest.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Pielāgojiet lieluma vērtību līdz RcBox beigām.
    // Tā kā RcBox ir repr(C), tas vienmēr būs pēdējais atmiņas lauks.
    // DROŠĪBA: tā kā vienīgie iespējamie izmēri ir šķēles, trait objekti,
    // un ārējiem veidiem, ievades drošības prasība pašlaik ir pietiekama, lai apmierinātu align_of_val_raw prasības;šī ir valodas ieviešanas detaļa, uz kuru nevar paļauties ārpus std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}