#![stable(feature = "rust1", since = "1.0.0")]

//! Vītnei drošas atsauces skaitīšanas norādes.
//!
//! Plašāku informāciju skatiet [`Arc<T>`][Arc] dokumentācijā.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// Maigs ierobežojums atsauču daudzumam, ko var izdarīt uz `Arc`.
///
/// Pārsniedzot šo ierobežojumu, jūsu programma tiks pārtraukta (kaut arī ne vienmēr) ar atsaucēm _exactly_ `MAX_REFCOUNT + 1`.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer neatbalsta atmiņas žogus.
// Lai izvairītos no kļūdaini pozitīviem ziņojumiem Arc/Weak ieviešanā, tā vietā sinhronizācijai izmantojiet atomu slodzes.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Vītnei droša atsauces skaitīšanas rādītājs.'Arc' nozīmē `Atomical Reference Counted`.
///
/// `Arc<T>` tips nodrošina koplietojuma tiesības uz kaudzē piešķirto `T` tipa vērtību.[`clone`][clone] izsaukšana uz `Arc` rada jaunu `Arc` instanci, kas norāda uz to pašu kaudzes sadalījumu kā avots `Arc`, vienlaikus palielinot atsauces skaitu.
/// Kad tiek iznīcināts pēdējais norādītā piešķīruma `Arc` rādītājs, tiek izmesta arī šajā piešķīrumā saglabātā vērtība (bieži saukta par "inner value").
///
/// Rust koplietotās atsauces pēc noklusējuma neatļauj mutāciju, un `Arc` nav izņēmums: parasti nevar iegūt maināmu atsauci uz kaut ko `Arc`.Ja jums ir jāveic mutācija, izmantojot `Arc`, izmantojiet [`Mutex`][mutex], [`RwLock`][rwlock] vai kādu no [`Atomic`][atomic] tipiem.
///
/// ## Vītnes drošība
///
/// Atšķirībā no [`Rc<T>`], `Arc<T>` atsauces skaitīšanai izmanto atomu darbības.Tas nozīmē, ka tas ir drošs ar vītni.Trūkums ir tāds, ka atomu darbības ir dārgākas nekā parastās piekļuves atmiņai.Ja jūs koplietojat atsauču uzskaitītos piešķīrumus starp pavedieniem, apsveriet iespēju [`Rc<T>`] izmantot zemākām pieskaitāmajām izmaksām.
/// [`Rc<T>`] ir droša noklusējuma vērtība, jo kompilators noķers visus mēģinājumus nosūtīt [`Rc<T>`] starp pavedieniem.
/// Tomēr bibliotēka var izvēlēties `Arc<T>`, lai bibliotēkas patērētājiem nodrošinātu lielāku elastību.
///
/// `Arc<T>` ieviesīs [`Send`] un [`Sync`], kamēr `T` ieviesīs [`Send`] un [`Sync`].
/// Kāpēc jūs nevarat ievietot `T` bezvītnes modeli `Arc<T>`, lai padarītu to drošu?Sākumā tas var būt nedaudz pret intuitīvu: galu galā, vai `Arc<T>` pavedienu drošība nav jēga?Galvenais ir šāds: `Arc<T>` padara drošu pavedienu, ja tiem ir vairākas īpašumtiesības uz vieniem un tiem pašiem datiem, taču tas nepievieno pavedienu drošību saviem datiem.
///
/// Apsveriet `Arc <` [`RefCell<T>"]">".
/// [`RefCell<T>`] nav [`Sync`], un, ja `Arc<T>` vienmēr bija [`Send`], `Arc <` [`RefCell<T>"]`> arī būtu.
/// Bet tad mums būtu problēma:
/// [`RefCell<T>`] nav drošs ar vītni;tas seko aizņēmumu skaitam, izmantojot atomu darbības.
///
/// Galu galā tas nozīmē, ka jums var būt nepieciešams savienot pārī `Arc<T>` ar kaut kāda veida [`std::sync`] tipu, parasti [`Mutex<T>`][mutex].
///
/// ## Ciklu pārtraukšana ar `Weak`
///
/// [`downgrade`][downgrade] metodi var izmantot, lai izveidotu [`Weak`] rādītāju, kas nepieder.[`Weak`] rādītājs var būt [`jauninājums`][jauninājums] d uz `Arc`, taču tas atgriezīs [`None`], ja piešķīrumā saglabātā vērtība jau būs nomesta.
/// Citiem vārdiem sakot, `Weak` rādītāji neuztur vērtību sadalījuma iekšpusē;tomēr viņi *saglabā* piešķiršanu (vērtības rezerves krātuvi).
///
/// Cikls starp `Arc` rādītājiem nekad netiks sadalīts.
/// Šī iemesla dēļ [`Weak`] tiek izmantots ciklu pārtraukšanai.Piemēram, kokam var būt spēcīgi `Arc` rādītāji no vecāku mezgliem līdz bērniem, un [`Weak`] rādītāji no bērniem atgriežas pie vecākiem.
///
/// # Klonēšanas atsauces
///
/// Jaunas atsauces izveidošana no esošā atsauces uzskaitītā rādītāja tiek veikta, izmantojot `Clone` trait, kas ieviesta [`Arc<T>`][Arc] un [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Divas zemāk minētās sintakse ir līdzvērtīgas.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b un foo ir visi loki, kas norāda uz vienu un to pašu atmiņas vietu
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` automātiski novirzes uz `T` (izmantojot [`Deref`][deref] trait), lai jūs varētu izsaukt `T` metodes uz `Arc<T>` tipa vērtību.Lai izvairītos no vārdu sadursmēm ar `T` metodēm, pašas `Arc<T>` metodes ir saistītas funkcijas, sauktas, izmantojot [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `Loka<T>traits, piemēram, `Clone`, ieviešanu var izsaukt arī, izmantojot pilnībā kvalificētu sintaksi.
/// Daži cilvēki dod priekšroku pilnībā kvalificētai sintaksei, bet citi-metodi zvana sintaksei.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Metode-zvana sintakse
/// let arc2 = arc.clone();
/// // Pilnībā kvalificēta sintakse
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] automātiski nenovirza no `T`, jo iekšējā vērtība, iespējams, jau ir samazināta.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Dažu nemainīgu datu koplietošana starp pavedieniem:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Ņemiet vērā, ka mēs ** neveicam šos testus šeit.
// windows celtnieki kļūst ļoti neapmierināti, ja pavediens pārdzīvo galveno pavedienu un pēc tam iziet tajā pašā laikā (kaut kas strupceļā), tāpēc mēs vienkārši no tā pilnībā izvairāmies, neveicot šos testus.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Maināmā [`AtomicUsize`] kopīgošana:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Citus atsauces skaitīšanas piemērus kopumā skatiet [`rc` documentation][rc_examples].
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` ir [`Arc`] versija, kurai ir atsauce uz pārvaldīto sadalījumu, kurai nepieder.
/// Piešķiršanai var piekļūt, izsaucot [`upgrade`] uz `Weak` rādītāja, kas atgriež [Option]] <<[[Arc]]<T>> ".
///
/// Tā kā `Weak` atsauce netiek ieskaitīta īpašumtiesībās, tā netraucēs nomest piešķīrumā saglabāto vērtību, un pats `Weak` nedod nekādas garantijas, ka vērtība joprojām ir.
///
/// Tādējādi tas var atgriezt [`None`], kad [`jaunināt`] d.
/// Tomēr ņemiet vērā, ka `Weak` atsauce * neļauj pašu izvietojumu (atbalsta krātuvi) sadalīt.
///
/// `Weak` rādītājs ir noderīgs, lai saglabātu pagaidu atsauci uz [`Arc`] pārvaldīto piešķīrumu, neļaujot nomest tā iekšējo vērtību.
/// To lieto arī, lai novērstu apļveida atsauces starp [`Arc`] rādītājiem, jo savstarpējas atsauces nekad neļautu nomest [`Arc`].
/// Piemēram, kokam var būt spēcīgi [`Arc`] rādītāji no vecāku mezgliem līdz bērniem, un `Weak` rādītāji no bērniem atpakaļ uz vecākiem.
///
/// Tipisks veids, kā iegūt `Weak` rādītāju, ir piezvanīt uz [`Arc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Šis ir `NonNull`, kas ļauj optimizēt šāda veida izmērus uzskaitēs, taču tas ne vienmēr ir derīgs rādītājs.
    //
    // `Weak::new` iestata šo vērtību `usize::MAX`, lai tai nebūtu jāpiešķir vieta kaudzē.
    // Tā nav vērtība, kāda reālam rādītājam jebkad būs, jo RcBox ir izlīdzināts vismaz 2.
    // Tas ir iespējams tikai tad, ja `T: Sized`;izmēra `T` nekad nenokarājas.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Tas ir izturīgs pret repr(C) līdz future pret iespējamu lauka pārkārtošanu, kas traucētu citādi drošu pārveidojamo iekšējo tipu [into|from]_raw().
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // vērtība usize::MAX darbojas kā kontrolieris īslaicīgai "locking" spējai uzlabot vājās norādes vai pazemināt spēcīgās;to izmanto, lai izvairītos no sacīkstēm `make_mut` un `get_mut`.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Konstruē jaunu `Arc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Sāciet vājo rādītāju skaitu kā 1, kas ir vājais rādītājs, kuru tur visi spēcīgie rādītāji (kinda). Plašāku informāciju skatiet sadaļā std/rc.rs
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Konstruē jaunu `Arc<T>`, izmantojot vāju atsauci uz sevi.
    /// Mēģinot uzlabot vājo atsauci pirms šīs funkcijas atgriešanās, tiks iegūta vērtība `None`.
    /// Tomēr vājo atsauci var brīvi klonēt un uzglabāt lietošanai vēlāk.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Iekšējo "uninitialized" stāvoklī izveidojiet ar vienu vāju atsauci.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Ir svarīgi, lai mēs neatstātu vājā rādītāja īpašumtiesības, pretējā gadījumā atmiņa var tikt atbrīvota līdz `data_fn` atgriešanās brīdim.
        // Ja mēs patiešām vēlētos nodot īpašumtiesības, mēs varētu izveidot sev papildu vāju rādītāju, taču tas novestu pie vāja atsauces skaita papildu atjauninājumiem, kas citādi varētu nebūt vajadzīgi.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Tagad mēs varam pareizi inicializēt iekšējo vērtību un padarīt mūsu vājo atsauci par spēcīgu atsauci.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Iepriekš rakstītajam datu laukā jābūt redzamam visiem pavedieniem, kas novēro spēcīgu skaitlisko vērtību, kas nav nulle.
            // Tāpēc mums ir nepieciešama vismaz "Release" pasūtīšana, lai sinhronizētu ar `compare_exchange_weak` `Weak::upgrade`.
            //
            // "Acquire" pasūtīšana nav nepieciešama.
            // Apsverot iespējamo `data_fn` izturēšanos, mums tikai jāaplūko, ko tas varētu darīt, atsaucoties uz neatjaunināmu `Weak`:
            //
            // - Tas var *klonēt*`Weak`, palielinot vājo atsauču skaitu.
            // - Tas var nomest šos klonus, samazinot vājo atsauces skaitu (bet nekad līdz nullei).
            //
            // Šīs blakusparādības mūs nekādā veidā neietekmē, un tikai ar drošu kodu nav iespējamas citas blakusparādības.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Spēcīgām atsaucēm kopā vajadzētu būt kopīgai vājajai atsaucei, tāpēc nedarbiniet iznīcinātāju mūsu vecajai vājajai atsaucei.
        //
        mem::forget(weak);
        strong
    }

    /// Konstruē jaunu `Arc` ar neinicializētu saturu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Atliktā inicializācija:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Konstruē jaunu `Arc` ar neinicializētu saturu, atmiņai piepildot `0` baitus.
    ///
    ///
    /// Šīs metodes pareizas un nepareizas izmantošanas piemērus skatiet [`MaybeUninit::zeroed`][zeroed].
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Konstruē jaunu `Pin<Arc<T>>`.
    /// Ja `T` neievieš `Unpin`, tad `data` tiks piestiprināts atmiņā un to nevarēs pārvietot.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Konstruē jaunu `Arc<T>`, atgriežot kļūdu, ja piešķiršana neizdodas.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Sāciet vājo rādītāju skaitu kā 1, kas ir vājais rādītājs, kuru tur visi spēcīgie rādītāji (kinda). Plašāku informāciju skatiet sadaļā std/rc.rs
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Konstruē jaunu `Arc` ar neinicializētu saturu, atgriežot kļūdu, ja piešķiršana neizdodas.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Atliktā inicializācija:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Konstruē jaunu `Arc` ar neinicializētu saturu, atmiņai piepildot `0` baitus, atgriežot kļūdu, ja piešķiršana neizdodas.
    ///
    ///
    /// Šīs metodes pareizas un nepareizas izmantošanas piemērus skatiet [`MaybeUninit::zeroed`][zeroed].
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Atgriež iekšējo vērtību, ja `Arc` ir tieši viena spēcīga atsauce.
    ///
    /// Pretējā gadījumā [`Err`] tiek atgriezts ar to pašu `Arc`, kas tika ievadīts.
    ///
    ///
    /// Tas izdosies pat tad, ja ir izcilas vājas atsauces.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Veiciet vāju rādītāju, lai notīrītu netiešo spēcīgo un vājo atsauci
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Konstruē jaunu atomu veidā uzskaitītu šķēli ar neinicializētu saturu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Atliktā inicializācija:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Konstruē jaunu atomiāli uzskaitītu šķēli ar neinicializētu saturu, atmiņai piepildot ar `0` baitiem.
    ///
    ///
    /// Šīs metodes pareizas un nepareizas izmantošanas piemērus skatiet [`MaybeUninit::zeroed`][zeroed].
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Pārvērš par `Arc<T>`.
    ///
    /// # Safety
    ///
    /// Tāpat kā [`MaybeUninit::assume_init`] gadījumā, zvanītāja ziņā ir garantēt, ka iekšējā vērtība patiešām ir inicializēta.
    ///
    /// Tā saukšana, kad saturs vēl nav pilnībā inicializēts, rada tūlītēju nedefinētu rīcību.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Atliktā inicializācija:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Pārvērš par `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// Tāpat kā [`MaybeUninit::assume_init`] gadījumā, zvanītāja ziņā ir garantēt, ka iekšējā vērtība patiešām ir inicializēta.
    ///
    /// Tā saukšana, kad saturs vēl nav pilnībā inicializēts, rada tūlītēju nedefinētu rīcību.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Atliktā inicializācija:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Patērē `Arc`, atgriežot iesaiņoto rādītāju.
    ///
    /// Lai izvairītos no atmiņas noplūdes, rādītājs jāpārvērš atpakaļ uz `Arc`, izmantojot [`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Nodrošina neapstrādātu rādītāju datiem.
    ///
    /// Skaiti nekādā veidā netiek ietekmēti, un `Arc` netiek patērēts.
    /// Rādītājs ir derīgs tik ilgi, kamēr `Arc` ir spēcīgs skaits.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // DROŠĪBA: To nevar izmantot, izmantojot Deref::deref vai RcBoxPtr::inner, jo
        // tas ir nepieciešams, lai saglabātu raw/mut izcelsmi tā, ka, piem
        // `get_mut` var rakstīt caur rādītāju pēc tam, kad Rc ir atkopts caur `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// No jēlrādītāja izveido `Arc<T>`.
    ///
    /// Neapstrādātajam rādītājam jābūt iepriekš atgrieztam ar zvanu uz [`Arc<U>::into_raw`][into_raw], kur `U` jābūt tādam pašam izmēram un izlīdzinājumam kā `T`.
    /// Tas ir triviāli taisnība, ja `U` ir `T`.
    /// Ņemiet vērā, ka, ja `U` nav `T`, bet tam ir vienāds izmērs un izlīdzinājums, tas būtībā līdzinās dažādu veidu atsauču pārveidošanai.
    /// Plašāku informāciju par šajā gadījumā piemērojamiem ierobežojumiem skatiet vietnē [`mem::transmute`][transmute].
    ///
    /// `from_raw` lietotājam ir jāpārliecinās, ka konkrēta `T` vērtība tiek nomesta tikai vienu reizi.
    ///
    /// Šī funkcija ir nedroša, jo nepareiza lietošana var izraisīt atmiņas nedrošību, pat ja atgrieztajam `Arc<T>` nekad netiek piekļūts.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Pārvērtiet atpakaļ uz `Arc`, lai novērstu noplūdi.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Turpmāki zvani uz `Arc::from_raw(x_ptr)` būtu nedroši atmiņā.
    /// }
    ///
    /// // Atmiņa tika atbrīvota, kad `x` izgāja no iepriekš minētās darbības jomas, tāpēc `x_ptr` tagad karājas!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Apgrieziet nobīdi, lai atrastu sākotnējo ArcInner.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Šim piešķīrumam tiek izveidots jauns [`Weak`] rādītājs.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Tas ir mierīgi, jo zemāk mēs pārbaudām vērtību CAS.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // pārbaudiet, vai vājais skaitītājs pašlaik ir "locked";ja tā, griezieties.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: šis kods šobrīd ignorē pārpildes iespēju
            // usize::MAX;kopumā gan Rc, gan Arc ir jāpielāgo, lai tiktu galā ar pārplūdi.
            //

            // Atšķirībā no Clone(), mums tas ir jāiegūst lasījumā, lai sinhronizētu ar rakstīšanu, kas nāk no `is_unique`, lai notikumi pirms šī rakstīšanas notiktu pirms šīs lasīšanas.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Pārliecinieties, ka mēs neradām nokareno Vājo
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Tiek iegūts [`Weak`] rādītāju skaits šim sadalījumam.
    ///
    /// # Safety
    ///
    /// Šī metode pati par sevi ir droša, taču, lai to pareizi lietotu, nepieciešama īpaša piesardzība.
    /// Cits pavediens var jebkurā laikā mainīt vājo skaitu, tostarp, iespējams, starp šīs metodes izsaukšanu un darbību pēc rezultāta.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Šis apgalvojums ir deterministisks, jo mēs neesam koplietojuši `Arc` vai `Weak` starp pavedieniem.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Ja vājais skaitlis pašlaik ir bloķēts, skaitīšanas vērtība bija 0 tieši pirms bloķēšanas.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Tiek iegūts spēcīgo (`Arc`) rādītāju skaits šim sadalījumam.
    ///
    /// # Safety
    ///
    /// Šī metode pati par sevi ir droša, taču, lai to pareizi lietotu, nepieciešama īpaša piesardzība.
    /// Cits pavediens var jebkurā laikā mainīt spēcīgo skaitu, tostarp, iespējams, starp šīs metodes izsaukšanu un darbību pēc rezultāta.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Šis apgalvojums ir deterministisks, jo mēs neesam koplietojuši `Arc` starp pavedieniem.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Par vienu palielina `Arc<T>` spēcīgo atsauču skaitu, kas saistīts ar norādīto rādītāju.
    ///
    /// # Safety
    ///
    /// Rādītājam jābūt iegūtam, izmantojot `Arc::into_raw`, un saistītajam `Arc` gadījumam jābūt derīgam (ti
    /// spēcīgajam skaitam šīs metodes laikā jābūt vismaz 1).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Šis apgalvojums ir deterministisks, jo mēs neesam koplietojuši `Arc` starp pavedieniem.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Saglabājiet Arc, bet nepieskarieties refcount, iesaiņojot ManuallyDrop
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Tagad palieliniet pārrēķinu skaitu, bet nepazeminiet arī jaunu
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Par vienu samazina `Arc<T>`, kas saistīts ar norādīto rādītāju, spēcīgo atsauču skaitu.
    ///
    /// # Safety
    ///
    /// Rādītājam jābūt iegūtam, izmantojot `Arc::into_raw`, un saistītajam `Arc` gadījumam jābūt derīgam (ti
    /// spēcīgajam skaitam jābūt vismaz 1), izmantojot šo metodi.
    /// Šo metodi var izmantot, lai atbrīvotu galīgo `Arc` un rezerves krātuvi, taču **nevajadzētu izsaukt** pēc pēdējās `Arc` izlaišanas.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Šie apgalvojumi ir determinējoši, jo mēs neesam koplietojuši `Arc` starp pavedieniem.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Šis nedrošums ir kārtībā, jo, kamēr šī loka ir dzīva, mēs garantējam, ka iekšējais rādītājs ir derīgs.
        // Turklāt mēs zinām, ka pati `ArcInner` struktūra ir `Sync`, jo iekšējie dati ir arī `Sync`, tāpēc mēs varam aizdot nemaināmu rādītāju šim saturam.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // `drop` daļa, kas nav iesaiņota.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Pašlaik iznīciniet datus, kaut arī mēs paši nevaram atbrīvot lodziņa piešķiršanu (iespējams, joprojām atrodas vājas norādes).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Nometiet vājo atsauci, ko kopīgi tur visas spēcīgās atsauces
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Atgriež vērtību `true`, ja abi `Arc 'punkti norāda uz to pašu sadalījumu (vēnā, kas līdzīga [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Piešķir `ArcInner<T>` ar pietiekamu vietu, iespējams, neizmērāmai iekšējai vērtībai, kur vērtībai ir paredzēts izkārtojums.
    ///
    /// Funkcija `mem_to_arcinner` tiek izsaukta ar datu rādītāju, un tai jāatgriež `ArcInner<T>` (iespējams, tauku) rādītājs.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Aprēķiniet izkārtojumu, izmantojot norādīto vērtību izkārtojumu.
        // Iepriekš izkārtojums tika aprēķināts izteiksmē `&*(ptr as* const ArcInner<T>)`, taču tas radīja nepareizu atsauci (skat. #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Piešķir `ArcInner<T>` ar pietiekamu vietu, iespējams, nesamērīgai iekšējai vērtībai, kur vērtībai ir paredzēts izkārtojums, atgriežot kļūdu, ja piešķiršana neizdodas.
    ///
    ///
    /// Funkcija `mem_to_arcinner` tiek izsaukta ar datu rādītāju, un tai jāatgriež `ArcInner<T>` (iespējams, tauku) rādītājs.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Aprēķiniet izkārtojumu, izmantojot norādīto vērtību izkārtojumu.
        // Iepriekš izkārtojums tika aprēķināts izteiksmē `&*(ptr as* const ArcInner<T>)`, taču tas radīja nepareizu atsauci (skat. #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Inicializējiet ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Piešķir `ArcInner<T>` ar pietiekamu vietu lieluma iekšējai vērtībai.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Piešķiriet `ArcInner<T>`, izmantojot norādīto vērtību.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Kopēt vērtību kā baitus
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Bezmaksas piešķīrums, nemetot tā saturu
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Piešķir `ArcInner<[T]>` ar norādīto garumu.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Kopējiet elementus no šķēles nesen piešķirtajā lokā <\[T\]>
    ///
    /// Nedroši, jo zvanītājam ir jāuzņemas īpašumtiesības vai jāsaista `T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// No iteratora izveido `Arc<[T]>`, kas, kā zināms, ir noteikta lieluma.
    ///
    /// Uzvedība nav noteikta, ja izmērs ir nepareizs.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Panic aizsargs, klonējot T elementus.
        // panic gadījumā elementi, kas ir ierakstīti jaunajā ArcInner, tiks nomesti, pēc tam atmiņa atbrīvosies.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Rādītājs pirmajam elementam
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Viss skaidrs.Aizmirstiet aizsargu, lai tas neatbrīvo jauno ArcInner.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Specializācija trait, ko izmanto `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Izveido `Arc` rādītāja klonu.
    ///
    /// Tas rada vēl vienu rādītāju tam pašam sadalījumam, palielinot spēcīgo atsauču skaitu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Atvieglotas pasūtīšanas izmantošana šeit ir labi, jo sākotnējās atsauces zināšanas neļauj citiem pavedieniem kļūdaini izdzēst objektu.
        //
        // Kā paskaidrots [Boost documentation][1], atsauces skaitītāja palielināšanu vienmēr var veikt ar memory_order_relaxed: jaunas atsauces uz objektu var veidot tikai no esošas atsauces, un, nododot esošu atsauci no viena pavediena citam, jau jānodrošina nepieciešamā sinhronizācija.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Tomēr mums ir jāaizsargājas no masveida pārrēķināšanās, ja kāds ir aizmirsis lokus.
        // Ja mēs to nedarīsim, skaitīšana var pārpildīties, un lietotāji to izmantos bez maksas.
        // Mēs ļoti piesātināmies ar `isize::MAX`, pieņemot, ka nav ~2 miljardu pavedienu, kas vienlaikus palielinātu atsauces skaitu.
        //
        // Šis branch nekad netiks uzņemts nevienā reālistiskā programmā.
        //
        // Mēs pārtraucam, jo šāda programma ir neticami deģenerēta, un mums ir vienalga to atbalstīt.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Padara maināmu atsauci uz norādīto `Arc`.
    ///
    /// Ja tam pašam piešķīrumam ir citi `Arc` vai [`Weak`] rādītāji, tad `make_mut` izveidos jaunu piešķiršanu un uz iekšējo vērtību izsauks [`clone`][clone], lai nodrošinātu unikālas īpašumtiesības.
    /// To sauc arī par rakstīšanu uz klona.
    ///
    /// Ņemiet vērā, ka tas atšķiras no [`Rc::make_mut`] uzvedības, kas nošķir visus pārējos `Weak` rādītājus.
    ///
    /// Skatiet arī [`get_mut`][get_mut], kas neizdosies, nevis klonēs.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Neklonēs neko
    /// let mut other_data = Arc::clone(&data); // Neklonēs iekšējos datus
    /// *Arc::make_mut(&mut data) += 1;         // Klonē iekšējos datus
    /// *Arc::make_mut(&mut data) += 1;         // Neklonēs neko
    /// *Arc::make_mut(&mut other_data) *= 2;   // Neklonēs neko
    ///
    /// // Tagad `data` un `other_data` norāda uz dažādiem piešķīrumiem.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Ņemiet vērā, ka mums ir gan spēcīga atsauce, gan vāja atsauce.
        // Tādējādi, atbrīvojot tikai mūsu spēcīgo atsauci, tas pats par sevi neizraisīs atmiņas atdalīšanu.
        //
        // Izmantojiet opciju Iegūt, lai pārliecinātos, ka `weak` redzam jebkādus ierakstus, kas notiek pirms izlaišanas rakstīšanas (ti, samazināšanas) uz `strong`.
        // Tā kā mums ir vājš skaitlis, nav izredžu, ka pašu ArcInner varētu sadalīt.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Pastāv vēl viens spēcīgs rādītājs, tāpēc mums ir jāklonē.
            // Iepriekš piešķiriet atmiņu, lai varētu tieši rakstīt klonēto vērtību.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Ar iepriekšminēto pietiek ar relaksāciju, jo tā būtībā ir optimizācija: mēs vienmēr braucam ar kritušiem vājiem rādītājiem.
            // Sliktākajā gadījumā mēs lieki piešķiram jaunu loku.
            //

            // Mēs noņēmām pēdējo spēcīgo norādi, taču ir palikuši vēl vāji norādes.
            // Mēs pārvietosim saturu uz jaunu loku un nederēsim pārējos vājās atsauces.
            //

            // Ņemiet vērā, ka `weak` nolasījumam nav iespējams iegūt usize::MAX (ti, bloķēt), jo vājo skaitu var bloķēt tikai ar pavedienu ar spēcīgu atsauci.
            //
            //

            // Realizējiet mūsu pašu netiešo vājo rādītāju, lai tas pēc vajadzības varētu iztīrīt ArcInner.
            //
            let _weak = Weak { ptr: this.ptr };

            // Var vienkārši nozagt datus, atliek tikai Weaks
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Mēs bijām vienīgā abu veidu atsauce;sasist atpakaļ uz augšu spēcīgo ref skaits.
            //
            this.inner().strong.store(1, Release);
        }

        // Tāpat kā `get_mut()` gadījumā, nedrošība ir kārtībā, jo mūsu atsauce bija vai nu unikāla, lai sāktu, vai arī kļuva par tādu, klonējot saturu.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Atgriež maināmo atsauci dotajā `Arc`, ja tam pašam piešķīrumam nav citu `Arc` vai [`Weak`] rādītāju.
    ///
    ///
    /// Atgriež [`None`] citādi, jo nav droši mutēt koplietojamo vērtību.
    ///
    /// Skatiet arī [`make_mut`][make_mut], kas [`clone`][clone] samazinās iekšējo vērtību, ja ir citas norādes.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Šis nedrošums ir kārtībā, jo mēs garantējam, ka atgrieztais rādītājs ir *vienīgais* rādītājs, kas kādreiz tiks atgriezts T.
            // Šajā brīdī tiek garantēts, ka mūsu atskaites skaits ir 1, un mēs pieprasījām, lai pati loka vērtība būtu `mut`, tāpēc mēs atgriezīsim vienīgo iespējamo atsauci uz iekšējiem datiem.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Atgriež maināmo atsauci dotajā `Arc` bez jebkādas pārbaudes.
    ///
    /// Skatiet arī [`get_mut`], kas ir drošs un veic atbilstošas pārbaudes.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Visiem citiem `Arc` vai [`Weak`] rādītājiem uz to pašu piešķīrumu nedrīkst ieturēt norādi uz atdotā aizņēmuma laiku.
    ///
    /// Tas ir nenozīmīgi, ja šādu norāžu nav, piemēram, tūlīt pēc `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Mēs uzmanīgi * neizveidojam atsauci, kas aptvertu "count" laukus, jo tas aizstājvārdu ar vienlaicīgu piekļuvi atsauču skaitam (piem.,
        // ar `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Nosakiet, vai šī ir unikālā atsauce (ieskaitot vājās atsauces) uz pamatā esošajiem datiem.
    ///
    ///
    /// Ņemiet vērā, ka tas prasa bloķēt vājo atsauces skaitu.
    fn is_unique(&mut self) -> bool {
        // bloķējiet vājo rādītāju skaitu, ja šķiet, ka esam vienīgais vāja rādītāja turētājs.
        //
        // Iegādes etiķete šeit nodrošina notikumu pirms attiecībām ar jebkādiem ierakstiem `strong` (it īpaši `Weak::upgrade`) pirms `weak` skaita samazināšanas (izmantojot `Weak::drop`, kas izmanto atbrīvošanu).
        // Ja jauninātā vāja atsauce nekad netika nomesta, CAS šeit neizdosies, tāpēc mums nav svarīgi sinhronizēt.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Tam jābūt `Acquire`, lai sinhronizētu ar `strong` skaitītāja samazinājumu `drop`-vienīgā piekļuve, kas notiek, kad tiek atcelta jebkura atsauce, izņemot pēdējo.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Izlaiduma rakstīšana šeit tiek sinhronizēta ar lasījumu `downgrade`, efektīvi novēršot iepriekšminēto `strong` lasīšanu pēc rakstīšanas.
            //
            //
            self.inner().weak.store(1, Release); // atlaidiet slēdzeni
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Nomet `Arc`.
    ///
    /// Tas samazinās spēcīgo atsauces skaitu.
    /// Ja spēcīgais atsauces skaits sasniedz nulli, tad vienīgās pārējās atsauces (ja tādas ir) ir [`Weak`], tāpēc mēs `drop` iekšējo vērtību.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Neko nedrukā
    /// drop(foo2);   // Izdrukā "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Tā kā `fetch_sub` jau ir atoms, mums nav nepieciešams sinhronizēt ar citiem pavedieniem, ja vien mēs neizdzēsīsim objektu.
        // Šī pati loģika attiecas uz zemāk esošo `fetch_sub` uz `weak` skaitu.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Šis žogs ir nepieciešams, lai novērstu datu izmantošanas pārkārtošanu un datu dzēšanu.
        // Tā kā tas ir apzīmēts ar `Release`, atsauces skaita samazināšanās tiek sinhronizēta ar šo `Acquire` žogu.
        // Tas nozīmē, ka datu izmantošana notiek pirms atskaites skaita samazināšanas, kas notiek pirms šī žoga, kas notiek pirms datu dzēšanas.
        //
        // Kā paskaidrots [Boost documentation][1],
        //
        // > Ir svarīgi nodrošināt visu iespējamo piekļuvi objektam vienā
        // > pavediens (izmantojot esošu atsauci), kas *notiek pirms* dzēšanas
        // > objekts citā pavedienā.To panāk ar "release"
        // > operācija pēc atsauces nomešanas (jebkura piekļuve objektam
        // > caur šo atsauci acīmredzami ir noticis jau iepriekš), un
        // > "acquire" pirms objekta dzēšanas.
        //
        // Kaut arī loka saturs parasti nav maināms, ir iespējams, ka interjers raksta kaut ko līdzīgu Mutex<T>.
        // Tā kā Mutex netiek iegūts, to izdzēšot, mēs nevaram paļauties uz tā sinhronizācijas loģiku, lai rakstā A pavediens būtu redzams destruktoram, kas darbojas pavedienā B.
        //
        //
        // Ņemiet vērā arī to, ka šeit žogu Acquire, iespējams, varētu aizstāt ar Acquire slodzi, kas varētu uzlabot veiktspēju ļoti strīdīgās situācijās.Skatiet [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Mēģinājums pazemināt `Arc<dyn Any + Send + Sync>` uz konkrētu tipu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Konstruē jaunu `Weak<T>`, nepiešķirot atmiņu.
    /// Zvanot uz [`upgrade`] pēc atgriešanās vērtības, vienmēr tiek iegūts [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Palīga veids, lai atļautu piekļuvi atsauces skaitiem, neizteicot apgalvojumus par datu lauku.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Atgriež neapstrādātu rādītāju objektam `T`, uz kuru norāda šis `Weak<T>`.
    ///
    /// Rādītājs ir derīgs tikai tad, ja ir dažas spēcīgas atsauces.
    /// Rādītājs var būt karājošs, nesaskaņots vai pat [`null`] citādi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Abi norāda uz vienu un to pašu objektu
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Spēcīgais šeit uztur to dzīvu, tāpēc mēs joprojām varam piekļūt objektam.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Bet ne vairāk.
    /// // Mēs varam veikt weak.as_ptr(), taču piekļuve rādītājam novestu pie nedefinētas uzvedības.
    /// // assert_eq! ("sveiki", nedrošs {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Ja rādītājs karājas, mēs kontrolieri atdodam tieši.
            // Šī nevar būt derīga kravas adrese, jo derīgā krava ir vismaz tikpat līdzināta kā ArcInner (usize).
            ptr as *const T
        } else {
            // DROŠĪBA: ja is_dangling atgriež false, tad rādītājs ir novirzāms.
            // Derīgā slodze šajā brīdī var samazināties, un mums ir jāsaglabā izcelsme, tāpēc izmantojiet neapstrādātu rādītāju manipulāciju.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Patērē `Weak<T>` un pārvērš to par neapstrādātu rādītāju.
    ///
    /// Tas pārvērš vājo rādītāju par neapstrādātu rādītāju, vienlaikus saglabājot vienas vājas atsauces īpašumtiesības (vājo skaitu šī darbība nemaina).
    /// Ar [`from_raw`] to var atkal pārvērst par `Weak<T>`.
    ///
    /// Tiek izmantoti tie paši ierobežojumi, kas attiecas uz piekļuvi rādītāja mērķim, kā ar [`as_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Pārvērš neapstrādātu rādītāju, kuru iepriekš izveidoja [`into_raw`], atpakaļ uz `Weak<T>`.
    ///
    /// To var izmantot, lai droši iegūtu spēcīgu atsauci (vēlāk piezvanot uz [`upgrade`]), vai vājo skaitļu sadalīšanai, nometot `Weak<T>`.
    ///
    /// Tam ir īpašumtiesības uz vienu vāju atsauci (izņemot [`new`] izveidotos rādītājus, jo tiem nekas nepieder; metode joprojām darbojas ar tiem).
    ///
    /// # Safety
    ///
    /// Rādītājam ir jābūt no [`into_raw`], un tam joprojām ir jābūt tā vājajai atsaucei.
    ///
    /// Lai to izsauktu, spēcīgajam skaitam ir atļauts būt 0.
    /// Neskatoties uz to, tas pārņem vienu vāju atsauci, kas pašlaik tiek attēlota kā neapstrādāts rādītājs (vājo skaitu šī darbība nemaina), un tāpēc tā ir jāsavieno pārī ar iepriekšējo zvanu uz [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Samazināt pēdējo vājo skaitu.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Skatiet Weak::as_ptr kontekstu par ievades rādītāja atvasināšanu.

        let ptr = if is_dangling(ptr as *mut T) {
            // Tas ir karājas vājš.
            ptr as *mut ArcInner<T>
        } else {
            // Pretējā gadījumā mēs garantējam, ka rādītājs nāca no nepārspējama Vāja.
            // DROŠĪBA: data_offset ir droši izsaukt, jo ptr atsaucas uz reālu (potenciāli nokritušo) T.
            let offset = unsafe { data_offset(ptr) };
            // Tādējādi mēs mainām nobīdi, lai iegūtu visu RcBox.
            // DROŠĪBA: rādītājs ir radies no vāja, tāpēc šis nobīde ir droša.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // DROŠĪBA: tagad mēs esam atguvuši sākotnējo vājo rādītāju, tāpēc varam izveidot vājo.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Mēģinājumi jaunināt `Weak` rādītāju uz [`Arc`], veiksmīgi aizkavējot iekšējās vērtības samazināšanos.
    ///
    ///
    /// Atgriež vērtību [`None`], ja kopš tā laika iekšējā vērtība ir samazināta.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Iznīcini visus spēcīgos norādījumus.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Mēs izmantojam CAS cilpu, lai palielinātu spēcīgo skaitu, nevis fetch_add, jo šai funkcijai nekad nevajadzētu ņemt atsauces skaitu no nulles uz vienu.
        //
        //
        let inner = self.inner()?;

        // Atslābināta slodze, jo jebkura 0 rakstīšana, ko mēs varam novērot, atstāj lauku pastāvīgi nulles stāvoklī (tāpēc "stale" nolasījums 0 ir labi), un jebkura cita vērtība tiek apstiprināta, izmantojot zemāk esošo CAS.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Skatiet komentārus `Arc::clone`, lai uzzinātu, kāpēc mēs to darām (`mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Relaksēts ir piemērots neveiksmes gadījumam, jo mums nav nekādu cerību par jauno valsti.
            // Iegūšana ir nepieciešama veiksmes gadījuma sinhronizēšanai ar `Arc::new_cyclic`, kad iekšējo vērtību var inicializēt pēc tam, kad `Weak` atsauces jau ir izveidotas.
            // Tādā gadījumā mēs ceram ievērot pilnībā inicializēto vērtību.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // null pārbaudīts iepriekš
                Err(old) => n = old,
            }
        }
    }

    /// Tiek iegūts spēcīgo (`Arc`) rādītāju skaits, kas norāda uz šo sadalījumu.
    ///
    /// Ja `self` tika izveidots, izmantojot [`Weak::new`], tas atgriezīs 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Tiek iegūts aptuvens `Weak` rādītāju skaits, kas norāda uz šo sadalījumu.
    ///
    /// Ja `self` tika izveidots, izmantojot [`Weak::new`], vai ja nav atlikušo spēcīgo norāžu, tas atgriezīs 0.
    ///
    /// # Accuracy
    ///
    /// Īstenošanas detaļu dēļ atgriezto vērtību var izslēgt par 1 jebkurā virzienā, kad citi pavedieni manipulē ar jebkuru arku vai vājo, norādot uz to pašu sadalījumu.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Tā kā pēc vājo skaitļu nolasīšanas mēs novērojām, ka bija vismaz viens spēcīgs rādītājs, mēs zinām, ka netiešā vāja atsauce (klāt vienmēr, kad ir kādas stipras atsauces ir dzīvas) joprojām bija aptuveni, kad mēs novērojām vājo skaitu, un tāpēc to varam droši atņemt.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Atgriež vērtību `None`, kad rādītājs karājas un nav piešķirta `ArcInner` (ti, kad šo `Weak` izveidoja `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Mēs uzmanīgi * neizveidojam atsauci, kas aptvertu "data" lauku, jo lauks var būt mutēts vienlaikus (piemēram, ja tiek nomests pēdējais `Arc`, datu lauks tiks nomests vietā).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Atgriež `true`, ja abi vājie norāda uz vienu un to pašu sadalījumu (līdzīgi kā [`ptr::eq`]) vai ja abi nenorāda uz kādu piešķīrumu (jo tie tika izveidoti ar `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Tā kā tas salīdzina rādītājus, tas nozīmē, ka `Weak::new()` būs līdzvērtīgi viens otram, kaut arī tie nenorāda uz nekādu sadalījumu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Salīdzinot `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Izveido `Weak` rādītāja klonu, kas norāda uz to pašu sadalījumu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Skatiet komentārus Arc::clone(), lai uzzinātu, kāpēc tas ir atvieglots.
        // Tas var izmantot fetch_add (ignorējot bloķēšanu), jo vājais skaits tiek bloķēts tikai tur, kur *nav citu* vāju norāžu.
        //
        // (Tātad šajā gadījumā mēs nevaram palaist šo kodu).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Skatiet komentārus Arc::clone(), lai uzzinātu, kāpēc mēs to darām (mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Konstruē jaunu `Weak<T>`, nepiešķirot atmiņu.
    /// Zvanot uz [`upgrade`] pēc atgriešanās vērtības, vienmēr tiek iegūts [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Nomet `Weak` rādītāju.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Neko nedrukā
    /// drop(foo);        // Izdrukā "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Ja mēs uzzinām, ka mēs bijām pēdējais vājais rādītājs, ir pienācis laiks pilnībā izdalīt datus.Skatiet diskusiju Arc::drop() par atmiņas secību
        //
        // Šeit nav nepieciešams pārbaudīt bloķēto stāvokli, jo vājo skaitu var bloķēt tikai tad, ja bija precīzi viens vājš ref, tas nozīmē, ka kritums varēja tikai pēc tam palaist ON, ka atlikušais vājais ref, kas var notikt tikai pēc bloķēšanas atbrīvošanas.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Mēs šeit veicam šo specializāciju, nevis kā vispārīgāku `&T` optimizāciju, jo pretējā gadījumā tas palielinātu izmaksas visām vienlīdzības pārbaudēm uz atsaucēm.
/// Mēs pieņemam, ka `Arc` tiek izmantoti lielu vērtību glabāšanai, kuras ir lēni klonētas, bet arī smagas, lai pārbaudītu vienlīdzību, kā rezultātā šīs izmaksas vieglāk atmaksājas.
///
/// Visticamāk, ka tajā ir arī divi `Arc` kloni, kas norāda uz to pašu vērtību, nekā divi&T.
///
/// Mēs to varam izdarīt tikai tad, ja `T: Eq` kā `PartialEq` var būt apzināti nerefleksīvs.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Vienādība diviem `Arc`s.
    ///
    /// Divi `loka` ir vienādi, ja to iekšējās vērtības ir vienādas, pat ja tās tiek uzglabātas atšķirīgā sadalījumā.
    ///
    /// Ja `T` ievieš arī `Eq` (kas nozīmē vienlīdzības refleksivitāti), divi "Arc", kas norāda uz to pašu sadalījumu, vienmēr ir vienādi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Nevienlīdzība diviem `Arc`s.
    ///
    /// Divi `Loka` ir nevienlīdzīgi, ja to iekšējās vērtības ir nevienādas.
    ///
    /// Ja `T` ievieš arī `Eq` (tas nozīmē vienlīdzības refleksivitāti), divi `Arc ', kas norāda uz to pašu vērtību, nekad nav nevienlīdzīgi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Daļējs divu "Arc" salīdzinājums.
    ///
    /// Abus salīdzina, izsaucot `partial_cmp()` uz viņu iekšējām vērtībām.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Mazāk nekā salīdzinājums diviem `Arc`s.
    ///
    /// Abus salīdzina, izsaucot `<` uz viņu iekšējām vērtībām.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// "Mazāks vai vienāds ar" divu "loku" salīdzinājums.
    ///
    /// Abus salīdzina, izsaucot `<=` uz viņu iekšējām vērtībām.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Lielāks nekā divu "Arc" salīdzinājums.
    ///
    /// Abus salīdzina, izsaucot `>` uz viņu iekšējām vērtībām.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// "Lielāks par vai vienāds ar" divu "loku" salīdzinājums.
    ///
    /// Abus salīdzina, izsaucot `>=` uz viņu iekšējām vērtībām.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Salīdzinājums diviem `Arc`s.
    ///
    /// Abus salīdzina, izsaucot `cmp()` uz viņu iekšējām vērtībām.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Izveido jaunu `Arc<T>` ar `Default` vērtību `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Piešķiriet atsauces skaitīto šķēli un aizpildiet to, klonējot `v` vienumus.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Piešķiriet atsauces skaitīto `str` un iekopējiet tajā `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Piešķiriet atsauces skaitīto `str` un iekopējiet tajā `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Pārvietojiet lodziņā ievietotu objektu uz jaunu, atsauces uzskaitītu piešķīrumu.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Piešķiriet atsauces skaitīto šķēli un pārvietojiet tajā `v` elementus.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Ļaujiet Vec atbrīvot atmiņu, bet nesagraujiet tās saturu
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Paņem katru elementu `Iterator` un savāc to `Arc<[T]>`.
    ///
    /// # Veiktspējas raksturojums
    ///
    /// ## Vispārīgais gadījums
    ///
    /// Parasti kolekcionēšana `Arc<[T]>` tiek veikta, vispirms savācot `Vec<T>`.Tas ir, rakstot sekojošo:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// tas uzvedas tā, it kā mēs rakstītu:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Pirmais piešķīrumu kopums notiek šeit.
    ///     .into(); // Šeit notiek otrais piešķīrums `Arc<[T]>`.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Tas tiks piešķirts tik reižu, cik nepieciešams `Vec<T>` konstruēšanai, un pēc tam tas tiks piešķirts vienu reizi, lai `Vec<T>` pārvērstu par `Arc<[T]>`.
    ///
    ///
    /// ## Zināmā garuma iteratori
    ///
    /// Kad jūsu `Iterator` ievieš `TrustedLen` un tam ir precīzs izmērs, `Arc<[T]>` tiks piešķirts viens piešķīrums.Piemēram:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Šeit notiek tikai viena piešķiršana.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Specializācija trait, ko izmanto savākšanai `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Tas attiecas uz `TrustedLen` iteratoru.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // DROŠĪBA: Mums jānodrošina, lai iteratoram būtu precīzs garums un mums ir.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Atgriezieties pie normālas ieviešanas.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Iegūstiet nobīdi `ArcInner` robežās par kravas aiz rādītāja.
///
/// # Safety
///
/// Rādītājam jānorāda uz iepriekš derīgu T gadījumu (un tiem ir derīgi metadati), taču T ir atļauts nomest.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Pielāgojiet lieluma vērtību līdz ArcInner beigām.
    // Tā kā RcBox ir repr(C), tas vienmēr būs pēdējais atmiņas lauks.
    // DROŠĪBA: tā kā vienīgie iespējamie izmēri ir šķēles, trait objekti,
    // un ārējiem veidiem, ievades drošības prasība pašlaik ir pietiekama, lai apmierinātu align_of_val_raw prasības;šī ir valodas ieviešanas detaļa, uz kuru nevar paļauties ārpus std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}