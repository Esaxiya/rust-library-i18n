use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // Rakstīt integrācijas testu starp trešo pušu sadalītājiem un `RawVec` ir nedaudz grūts, jo `RawVec` API neatklāj kļūdainas piešķiršanas metodes, tāpēc mēs nevaram pārbaudīt, kas notiek, ja sadalītājs ir izsmelts (papildus panic noteikšanai).
    //
    //
    // Tā vietā tas tikai pārbauda, vai `RawVec` metodes vismaz iziet cauri Allocator API, kad tā rezervē krātuvi.
    //
    //
    //
    //
    //

    // Mēms sadalītājs, kas patērē noteiktu daudzumu degvielas, pirms sāk nedarboties sadales mēģinājumi.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (izraisa pārdali, tādējādi izmantojot 50 + 150=200 degvielas vienības)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // Pirmkārt, `reserve` piešķir kā `reserve_exact`.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 ir vairāk nekā dubultā no 7, tāpēc `reserve` jādarbojas tāpat kā `reserve_exact`.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 ir mazāks par pusi no 12, tāpēc `reserve` ir jāaug eksponenciāli.
        // Rakstīšanas laikā šis testa pieauguma koeficients ir 2, tāpēc jaunā jauda ir 24, tomēr arī 1.5 pieauguma koeficients ir labs.
        //
        // Tādējādi apgalvo `>= 18`.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}