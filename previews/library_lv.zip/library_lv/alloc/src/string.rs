//! UTF-8 kodēta, audzējama virkne.
//!
//! Šis modulis satur [`String`] tipu, [`ToString`] trait pārveidošanai par virknēm un vairākus kļūdu veidus, kas var rasties, strādājot ar [`String`] s.
//!
//!
//! # Examples
//!
//! Ir vairāki veidi, kā izveidot jaunu [`String`] no virknes burta:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! Jūs varat izveidot jaunu [`String`] no esošā, savienojot ar
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! Ja jums ir derīgu UTF-8 baitu vector, varat no tā izveidot [`String`].Jūs varat arī rīkoties pretēji.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // Mēs zinām, ka šie baiti ir derīgi, tāpēc izmantosim `unwrap()`.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// UTF-8 kodēta, audzējama virkne.
///
/// `String` tips ir visizplatītākais virknes tips, kas pieder virknes saturam.Tam ir ciešas attiecības ar aizņemto kolēģi-primitīvo [`str`].
///
/// # Examples
///
/// Varat izveidot `String` no [a literal string][`str`] ar [`String::from`]:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// [`char`] var pievienot `String` ar metodi [`push`] un [`&str`] pievienot ar metodi [`push_str`]:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// Ja jums ir UTF-8 baitu vector, varat no tā izveidot `String` ar metodi [`from_utf8`]:
///
/// ```
/// // daži baiti vektorā
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Mēs zinām, ka šie baiti ir derīgi, tāpēc izmantosim `unwrap()`.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// Stīgas vienmēr ir derīgas UTF-8.Tam ir dažas sekas, no kurām pirmā ir tāda, ka, ja jums ir nepieciešama virkne, kas nav UTF-8, apsveriet iespēju [`OsString`].Tas ir līdzīgs, bet bez UTF-8 ierobežojuma.Otrais secinājums ir tāds, ka nevar indeksēt `String`:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// Indeksēšana ir paredzēta kā pastāvīga laika darbība, taču UTF-8 kodēšana mums to neļauj darīt.Turklāt nav skaidrs, kāda veida indeksam jāatgriež: baits, koda punkts vai grafēmas kopa.
/// [`bytes`] un [`chars`] metodes atgriež iteratorus attiecīgi pirmajos divos.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// `String`s īsteno [`Deref`] `<Target=str>`, un tā pārmantojiet visas [`str`] metodes.Turklāt tas nozīmē, ka jūs varat nodot `String` funkcijai, kas aizņem [`&str`], izmantojot zīmi (`&`):
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// Tas no `String` izveidos [`&str`] un to nodos iekšā. Šī pārveidošana ir ļoti lēta, un tāpēc parasti funkcijas pieņem argumentus [&&str`], ja vien kāda konkrēta iemesla dēļ tām nav nepieciešama `String`.
///
/// Dažos gadījumos Rust nav pietiekami daudz informācijas, lai veiktu šo konvertēšanu, kas pazīstama kā [`Deref`] piespiešana.Šajā piemērā virknes šķēle [`&'a str`][`&str`] īsteno trait `TraitExample`, un funkcija `example_func` ņem visu, kas īsteno trait.
/// Šajā gadījumā Rust būtu jāveic divi netieši pārveidojumi, kuriem Rust nav līdzekļu.
/// Šī iemesla dēļ šāds piemērs netiks apkopots.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// Ir divas iespējas, kas tā vietā darbotos.Pirmais būtu mainīt līniju `example_func(&example_string);` uz `example_func(example_string.as_str());`, izmantojot metodi [`as_str()`], lai skaidri izvilktu virknes daļu, kas satur virkni.
/// Otrais veids maina `example_func(&example_string);` uz `example_func(&*example_string);`.
/// Šajā gadījumā mēs novirzām `String` uz [`str`][`&str`], pēc tam [`str`][`&str`] atsaucam uz [`&str`].
/// Otrais veids ir idiomātiskāks, tomēr abi strādā, lai veiktu pārveidošanu tieši, nevis paļaujas uz netiešo pārveidošanu.
///
/// # Representation
///
/// `String` veido trīs komponenti: rādītājs dažiem baitiem, garums un ietilpība.Rādītājs norāda uz iekšējo buferi, kuru `String` izmanto datu glabāšanai.Garums ir buferī pašlaik saglabāto baitu skaits, un ietilpība ir bufera lielums.
///
/// Tā garums vienmēr būs mazāks vai vienāds ar ietilpību.
///
/// Šis buferis vienmēr tiek glabāts kaudzē.
///
/// Jūs varat tos apskatīt, izmantojot metodes [`as_ptr`], [`len`] un [`capacity`]:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME Atjauniniet to, kad vec_into_raw_parts ir stabilizēts.
/// // Novērsiet virknes datu automātisku nomešanu
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // sižetam ir deviņpadsmit baiti
/// assert_eq!(19, len);
///
/// // Mēs varam atjaunot virkni no ptr, len un kapacitātes.
/// // Tas viss ir nedroši, jo mēs esam atbildīgi par komponentu derīguma pārbaudi:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// Ja `String` ir pietiekami daudz jaudas, elementu pievienošana tam netiks piešķirta atkārtoti.Apsveriet, piemēram, šo programmu:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// Tas radīs sekojošo:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// Sākumā mums vispār nav atvēlētas atmiņas, bet, pievienojoties virknei, tā atbilstoši palielina tās ietilpību.Ja sākotnēji pareizās jaudas piešķiršanai izmantosim metodi [`with_capacity`]:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// Mēs iegūstam citu rezultātu:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// Lokā nav nepieciešams piešķirt vairāk atmiņas.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// Iespējamā kļūdas vērtība, pārveidojot `String` no UTF-8 baita vector.
///
/// Šis tips ir kļūdas veids [`from_utf8`] metodei operētājsistēmā [`String`].
/// Tas ir veidots tā, lai uzmanīgi izvairītos no pārdalīšanas: [`into_bytes`] metode atgriezīs baitu vector, kas tika izmantots pārveidošanas mēģinājumā.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// [`std::str`] nodrošinātais [`Utf8Error`] tips ir kļūda, kas var rasties, pārveidojot ["u8" s šķēli par [`&str`].
/// Šajā ziņā tas ir `FromUtf8Error` analogs, un jūs to varat iegūt no `FromUtf8Error`, izmantojot metodi [`utf8_error`].
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// Pamata lietojums:
///
/// ```
/// // daži nederīgi baiti vector
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// Iespējama kļūdas vērtība, pārveidojot `String` no UTF-16 baitu šķēles.
///
/// Šis tips ir kļūdas veids [`from_utf16`] metodei operētājsistēmā [`String`].
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// Pamata lietojums:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// Izveido jaunu tukšu `String`.
    ///
    /// Ņemot vērā, ka `String` ir tukšs, tas nepiešķirs sākotnējo buferi.Lai gan tas nozīmē, ka šī sākotnējā darbība ir ļoti lēta, vēlāk, pievienojot datus, tā var izraisīt pārmērīgu piešķiršanu.
    ///
    /// Ja jums ir ideja par to, cik daudz datu glabās `String`, apsveriet metodi [`with_capacity`], lai novērstu pārmērīgu pārdalīšanu.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// Izveido jaunu tukšu `String` ar noteiktu ietilpību.
    ///
    /// `String`s ir iekšējs buferis datu glabāšanai.
    /// Jauda ir šī bufera garums, un to var pieprasīt, izmantojot metodi [`capacity`].
    /// Šī metode izveido tukšu `String`, bet tādu ar sākotnējo buferi, kas var turēt `capacity` baitus.
    /// Tas ir noderīgi, ja, iespējams, `String` pievienojat virkni datu, samazinot tai nepieciešamo pārdalījumu skaitu.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// Ja norādītā jauda ir `0`, piešķiršana nenotiks, un šī metode ir identiska [`new`] metodei.
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // Stīgas nesatur rakstzīmes, kaut arī tās spēj vairāk
    /// assert_eq!(s.len(), 0);
    ///
    /// // Tie visi tiek veikti, nepārdalot ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... bet tas var padarīt virkni pārdalītu
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): ar cfg(test) raksturīgā metode `[T]::to_vec`, kas nepieciešama šīs metodes definēšanai, nav pieejama.
    // Tā kā testēšanas nolūkos šī metode nav nepieciešama, es to vienkārši izdomāju. Lai iegūtu papildinformāciju, skatiet slice::hack moduli slice.rs
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// Pārvērš baitu vector par `String`.
    ///
    /// Virkne ([`String`]) ir izgatavota no baitiem ([`u8`]), un vector no baitiem ([`Vec<u8>`]) ir izgatavota no baitiem, tāpēc šī funkcija pārveidojas starp abiem.
    /// Ne visas baitu šķēles ir derīgas `virknes`, tomēr `String` pieprasa, lai tā būtu derīga UTF-8.
    /// `from_utf8()` pārbauda, vai baiti ir derīgi UTF-8, un pēc tam veic konvertēšanu.
    ///
    /// Ja esat pārliecināts, ka baita šķēle ir derīga UTF-8, un jūs nevēlaties uzņemties derīguma pārbaudes pieskaitāmās izmaksas, ir šīs funkcijas nedrošā versija [`from_utf8_unchecked`], kurai ir tāda pati darbība, taču pārbaude tiek izlaista.
    ///
    ///
    /// Efektivitātes labad šī metode rūpēsies, lai vector netiktu kopēts.
    ///
    /// Ja `String` vietā nepieciešams [`&str`], apsveriet iespēju [`str::from_utf8`].
    ///
    /// Šīs metodes apgrieztā vērtība ir [`into_bytes`].
    ///
    /// # Errors
    ///
    /// Atgriež [`Err`], ja šķēle nav UTF-8, ar aprakstu, kāpēc sniegtie baiti nav UTF-8.Iekļauts arī vector, kurā jūs pārvietojāties.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// // daži baiti vektorā
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // Mēs zinām, ka šie baiti ir derīgi, tāpēc izmantosim `unwrap()`.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Nepareizi baiti:
    ///
    /// ```
    /// // daži nederīgi baiti vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// Plašāku informāciju par to, kā rīkoties ar šo kļūdu, skatiet dokumentos [`FromUtf8Error`].
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// Pārvērš baitu daļu par virkni, ieskaitot nederīgas rakstzīmes.
    ///
    /// Stīgas ir izgatavotas no baitiem ([`u8`]), un baitu šķēle ([`&[u8]`][byteslice]) ir izgatavota no baitiem, tāpēc šī funkcija pārvēršas starp abiem.Ne visas baitu šķēles ir derīgas virknes, tomēr: virknēm jābūt derīgām UTF-8.
    /// Šīs konvertēšanas laikā `from_utf8_lossy()` aizstās visas nederīgās UTF-8 sekvences ar [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD], kas izskatās šādi:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// Ja esat pārliecināts, ka baita šķēle ir derīga UTF-8, un jūs nevēlaties segt reklāmguvumu, pastāv šīs funkcijas nedrošā versija [`from_utf8_unchecked`], kurai ir tāda pati darbība, taču tā izlaiž pārbaudes.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// Šī funkcija atgriež [`Cow<'a, str>`].Ja mūsu baitu šķēle nav derīga UTF-8, tad mums jāievieto aizstājējzīmes, kas mainīs virknes lielumu un līdz ar to būs nepieciešama `String`.
    /// Bet, ja tas jau ir derīgs UTF-8, mums nav nepieciešams jauns piešķīrums.
    /// Šis atgriešanās veids ļauj mums rīkoties abos gadījumos.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// // daži baiti vektorā
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Nepareizi baiti:
    ///
    /// ```
    /// // daži nederīgi baiti
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// Atkodējiet UTF-16 kodētu vector `v` par `String`, atgriežot [`Err`], ja `v` satur nederīgus datus.
    ///
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // Tas netiek izdarīts, izmantojot kolekciju: : <Result<_, _>> () veiktspējas apsvērumu dēļ.
        // FIXME: funkciju var atkal vienkāršot, kad #48994 ir aizvērts.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// Atkodējiet UTF-16 kodētu `v` daļu `String`, nederīgus datus aizstājot ar [the replacement character (`U+FFFD`)][U+FFFD].
    ///
    /// Atšķirībā no [`from_utf8_lossy`], kas atgriež [`Cow<'a, str>`], `from_utf16_lossy` atgriež `String`, jo UTF-16 pārveidošanai UTF-8 ir nepieciešama atmiņas piešķiršana.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// Sadalās `String` tā izejvielās.
    ///
    /// Atgriež neapstrādāto rādītāju pamatā esošajiem datiem, virknes garumam (baitos) un datu piešķirtajai jaudai (baitos).
    /// Šie ir tie paši argumenti tādā pašā secībā kā argumenti [`from_raw_parts`].
    ///
    /// Pēc šīs funkcijas izsaukšanas zvanītājs ir atbildīgs par atmiņu, kuru iepriekš pārvaldīja `String`.
    /// Vienīgais veids, kā to izdarīt, ir neapstrādātu rādītāju, garumu un ietilpību pārveidot atpakaļ par `String` ar funkciju [`from_raw_parts`], ļaujot iznīcinātājam veikt tīrīšanu.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// Izveido jaunu `String` no garuma, ietilpības un rādītāja.
    ///
    /// # Safety
    ///
    /// Tas ir ļoti nedroši, jo netiek pārbaudīti invarianti:
    ///
    /// * Atmiņu pie `buf` iepriekš jāpiešķir tam pašam sadalītājam, kuru izmanto standarta bibliotēka, ar nepieciešamo izlīdzinājumu precīzi 1.
    /// * `length` jābūt mazākam vai vienādam ar `capacity`.
    /// * `capacity` jābūt pareizai vērtībai.
    /// * Pirmajiem `length` baitiem `buf` jābūt derīgiem UTF-8.
    ///
    /// To pārkāpšana var radīt tādas problēmas kā sadalītāja iekšējo datu struktūru bojāšana.
    ///
    /// Īpašumtiesības uz `buf` faktiski tiek nodotas `String`, kas pēc tam var sadalīt, pārdalīt vai mainīt atmiņas saturu, uz kuru norāda rādītājs pēc vēlēšanās.
    /// Pēc šīs funkcijas izsaukšanas pārliecinieties, ka nekas cits neizmanto rādītāju.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME Atjauniniet to, kad vec_into_raw_parts ir stabilizēts.
    ///     // Novērsiet virknes datu automātisku nomešanu
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// Pārvērš baitu vector par `String`, nepārbaudot, vai virkne satur derīgu UTF-8.
    ///
    /// Plašāku informāciju skatiet drošajā versijā [`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// Šī funkcija ir nedroša, jo tā nepārbauda, vai tai nodotie baiti ir derīgi UTF-8.
    /// Ja šis ierobežojums tiek pārkāpts, tas var izraisīt atmiņas nedrošības problēmas ar `String` lietotājiem future, jo pārējā standarta bibliotēkā tiek pieņemts, ka `virknes ir derīgas UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// // daži baiti vektorā
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// Pārvērš `String` par baitu vector.
    ///
    /// Tas patērē `String`, tāpēc mums nav nepieciešams kopēt tā saturu.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// Izvelk virknes šķēli, kas satur visu `String`.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// Pārvērš `String` par maināmu virknes daļu.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// Pievieno doto virknes daļu šī `String` galā.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// Atgriež šīs `virknes` ietilpību baitos.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// Nodrošina, ka šīs "virknes" ietilpība ir vismaz `additional` baiti lielāka par tās garumu.
    ///
    /// Ja vēlaties, jaudu var palielināt par vairāk nekā `additional` baitiem, lai novērstu biežu pārdalīšanu.
    ///
    ///
    /// Ja nevēlaties šo "at least" darbību, skatiet metodi [`reserve_exact`].
    ///
    /// # Panics
    ///
    /// Panics, ja jaunā jauda pārpilda [`usize`].
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Tas faktiski var nepalielināt jaudu:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s tagad ir 2 garums un 10 ietilpība
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Tā kā mums jau ir papildu 8 ietilpība, to saucam par ...
    /// s.reserve(8);
    ///
    /// // ... faktiski nepalielinās.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// Nodrošina, ka šīs "virknes" ietilpība ir `additional` baiti lielāka par tās garumu.
    ///
    /// Apsveriet iespēju izmantot metodi [`reserve`], ja vien jūs absolūti nezināt labāk par sadalītāju.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics, ja jaunā jauda pārpilda `usize`.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Tas faktiski var nepalielināt jaudu:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s tagad ir 2 garums un 10 ietilpība
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Tā kā mums jau ir papildu 8 ietilpība, to saucam par ...
    /// s.reserve_exact(8);
    ///
    /// // ... faktiski nepalielinās.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// Mēģina rezervēt jaudu vismaz `additional` vairāk elementu ievietošanai dotajā `String`.
    /// Kolekcijā var būt vairāk vietas, lai izvairītos no biežas pārdalīšanas.
    /// Pēc `reserve` izsaukšanas jauda būs lielāka vai vienāda ar `self.len() + additional`.
    /// Neko nedara, ja jauda jau ir pietiekama.
    ///
    /// # Errors
    ///
    /// Ja jauda pārpilda vai ja sadalītājs ziņo par kļūmi, tiek atgriezta kļūda.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Iepriekš rezervējiet atmiņu, aizverot, ja mēs to nevaram
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Tagad mēs zinām, ka tas nevar OOM mūsu sarežģītā darba vidū
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// Mēģina rezervēt minimālo jaudu, lai precīzi `additional` elementi tiktu ievietoti dotajā `String`.
    ///
    /// Pēc `reserve_exact` izsaukšanas jauda būs lielāka vai vienāda ar `self.len() + additional`.
    /// Neko nedara, ja jauda jau ir pietiekama.
    ///
    /// Ņemiet vērā, ka piešķīrējs var piešķirt kolekcijai vairāk vietas, nekā tas prasa.
    /// Tāpēc nevar paļauties, ka jauda ir precīzi minimāla.
    /// Dodiet priekšroku `reserve`, ja ir paredzami future ievietojumi.
    ///
    /// # Errors
    ///
    /// Ja jauda pārpilda vai ja sadalītājs ziņo par kļūmi, tiek atgriezta kļūda.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Iepriekš rezervējiet atmiņu, aizverot, ja mēs to nevaram
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Tagad mēs zinām, ka tas nevar OOM mūsu sarežģītā darba vidū
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// Samazina šī `String` ietilpību atbilstoši tā garumam.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// Samazina šī `String` ietilpību ar apakšējo robežu.
    ///
    /// Jauda paliks vismaz tikpat liela kā garums, tā piegādātā vērtība.
    ///
    ///
    /// Ja pašreizējā jauda ir mazāka par apakšējo robežu, tas ir aizliegts.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// Pievieno doto [`char`] šīs `String` beigās.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// Atgriež šīs `virknes` satura baitu šķēli.
    ///
    /// Šīs metodes apgrieztā vērtība ir [`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// Saīsiniet šo `String` līdz norādītajam garumam.
    ///
    /// Ja `new_len` ir lielāks par virknes pašreizējo garumu, tas neietekmē.
    ///
    ///
    /// Ņemiet vērā, ka šī metode neietekmē virknes piešķirto jaudu
    ///
    /// # Panics
    ///
    /// Panics, ja `new_len` neatrodas uz [`char`] robežas.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// Noņem virknes buferī pēdējo rakstzīmi un atgriež to.
    ///
    /// Atgriež vērtību [`None`], ja šī `String` ir tukša.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// No šī `String` baita pozīcijā noņem [`char`] un atgriež to.
    ///
    /// Šī ir operācija *O*(*n*), jo tai ir nepieciešams kopēt visus bufera elementus.
    ///
    /// # Panics
    ///
    /// Panics, ja `idx` ir lielāks vai vienāds ar "virknes" garumu vai ja tas nav uz [`char`] robežas.
    ///
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// Noņemiet visas `pat` modeļa atbilstības `String`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// Atbilstības tiks noteiktas un noņemtas atkārtoti, tādēļ gadījumos, kad modeļi pārklājas, tiks noņemts tikai pirmais raksts:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // DROŠĪBA: sākums un beigas būs uz utf8 baitu robežām katrā
        // meklētāja dokumenti
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// Saglabā tikai predikātā norādītās rakstzīmes.
    ///
    /// Citiem vārdiem sakot, noņemiet visas rakstzīmes `c` tā, lai `f(c)` atgrieztu `false`.
    /// Šī metode darbojas vietā, katru rakstzīmi apmeklējot precīzi vienreiz sākotnējā secībā, un saglabā saglabāto rakstzīmju secību.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// Precīza secība var būt noderīga, lai izsekotu ārējo stāvokli, piemēram, indeksu.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // Norādiet IDX uz nākamo simbolu
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// Ievieto rakstzīmi šajā `String` baita pozīcijā.
    ///
    /// Šī ir operācija *O*(*n*), jo tai ir nepieciešams kopēt visus bufera elementus.
    ///
    /// # Panics
    ///
    /// Panics, ja `idx` ir lielāks par virknes garumu vai ja tas neatrodas uz [`char`] robežas.
    ///
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// Šajā `String` ievieto virknes šķēli baitu pozīcijā.
    ///
    /// Šī ir operācija *O*(*n*), jo tai ir nepieciešams kopēt visus bufera elementus.
    ///
    /// # Panics
    ///
    /// Panics, ja `idx` ir lielāks par virknes garumu vai ja tas neatrodas uz [`char`] robežas.
    ///
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// Atgriež maināmu atsauci uz šī `String` saturu.
    ///
    /// # Safety
    ///
    /// Šī funkcija ir nedroša, jo tā nepārbauda, vai tai nodotie baiti ir derīgi UTF-8.
    /// Ja šis ierobežojums tiek pārkāpts, tas var izraisīt atmiņas nedrošības problēmas ar `String` lietotājiem future, jo pārējā standarta bibliotēkā tiek pieņemts, ka `virknes ir derīgas UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// Atgriež šīs `String` garumu baitos, nevis [`char`] s vai grafēmas.
    /// Citiem vārdiem sakot, tas var nebūt tas, ko cilvēks uzskata par virknes garumu.
    ///
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// Atgriež vērtību `true`, ja `String` garums ir nulle, un citādi `false`.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Sadala virkni divās norādītajā baitu indeksā.
    ///
    /// Atgriež tikko piešķirto `String`.
    /// `self` satur baitus `[0, at)`, un atgrieztais `String` satur baitus `[at, len)`.
    /// `at` jābūt uz UTF-8 koda punkta robežas.
    ///
    /// Ņemiet vērā, ka `self` ietilpība nemainās.
    ///
    /// # Panics
    ///
    /// Panics, ja `at` neatrodas uz `UTF-8` koda punkta robežas vai ja tas pārsniedz virknes pēdējo koda punktu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// Saīsina šo `String`, noņemot visu saturu.
    ///
    /// Lai gan tas nozīmē, ka `String` garums būs nulle, tas neskar tā ietilpību.
    ///
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// Izveido iztukšošanas atkārtotāju, kas noņem norādīto diapazonu `String` un iegūst noņemto `chars`.
    ///
    ///
    /// Note: Elementu diapazons tiek noņemts, pat ja iterators netiek patērēts līdz beigām.
    ///
    /// # Panics
    ///
    /// Panics, ja sākumpunkts vai beigu punkts neatrodas uz [`char`] robežas vai ja tie ir ārpus robežas.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Noņemiet diapazonu līdz β no virknes
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // Pilns diapazons notīra virkni
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // Atmiņas drošība
        //
        // Drain virknes versijai nav vector versijas atmiņas drošības problēmu.
        // Dati ir vienkārši baiti.
        // Tā kā diapazona noņemšana notiek programmā Drop, ja Drain iterators ir noplūdis, noņemšana nenotiks.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // Izņemiet divus vienlaicīgus aizņēmumus.
        // &mut virknei nevar piekļūt, kamēr nav beidzies atkārtojums Drop.
        let self_ptr = self as *mut _;
        // DROŠĪBA: `slice::range` un `is_char_boundary` veic atbilstošās robežu pārbaudes.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// Noņem virkni norādīto diapazonu un aizstāj to ar norādīto virkni.
    /// Dotajai virknei nav jābūt vienādam ar diapazonu.
    ///
    /// # Panics
    ///
    /// Panics, ja sākumpunkts vai beigu punkts neatrodas uz [`char`] robežas vai ja tie ir ārpus robežas.
    ///
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Nomainiet diapazonu līdz β no virknes
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // Atmiņas drošība
        //
        // Replace_range nav vector Splice atmiņas drošības problēmu.
        // no vector versijas.Dati ir vienkārši baiti.

        // BRĪDINĀJUMS: šī mainīgā ievietošana būtu nepamatota (#81138)
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // BRĪDINĀJUMS: šī mainīgā ievietošana būtu nepamatota (#81138)
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // `range` atkārtota izmantošana būtu nepamatota
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// Pārvērš šo `String` par [`Box ']` <`[` str`]`>`.
    ///
    /// Tas samazinās visas jaudas pārpalikumu.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// Atgriež [u8`] baitu šķēli, kuras mēģināja pārveidot par `String`.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// // daži nederīgi baiti vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// Atgriež baitus, kurus mēģināja pārveidot par `String`.
    ///
    /// Šī metode ir rūpīgi izveidota, lai izvairītos no piešķiršanas.
    /// Tas patērēs kļūdu, pārvietojot baitus, tāpēc baitu kopija nav jāveido.
    ///
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// // daži nederīgi baiti vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// Iegūstiet `Utf8Error`, lai iegūtu sīkāku informāciju par pārveidošanas kļūmi.
    ///
    /// [`std::str`] nodrošinātais [`Utf8Error`] tips ir kļūda, kas var rasties, pārveidojot ["u8" s šķēli par [`&str`].
    /// Šajā ziņā tas ir `FromUtf8Error` analogs.
    /// Plašāku informāciju par tā lietošanu skatiet tā dokumentācijā.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// // daži nederīgi baiti vector
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // pirmais baits šeit nav derīgs
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Tā kā mēs atkārtojam vairāk nekā virknes, mēs varam izvairīties no vismaz viena piešķīruma, iegūstot pirmo virkni no iteratora un pievienojot tam visas nākamās virknes.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Tā kā mēs atkārtojam CoW, mēs varam (potentially) izvairīties no vismaz viena piešķīruma, iegūstot pirmo vienumu un pievienojot tam visus nākamos vienumus.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// Ērtības implekts, kas deleģē `&str` impliku.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// Izveido tukšu `String`.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// Īsteno `+` operatoru divu virkņu savienošanai.
///
/// Tas patērē `String` kreisajā pusē un atkārtoti izmanto buferi (ja nepieciešams, to palielina).
/// Tas tiek darīts, lai izvairītos no jauna `String` piešķiršanas un visa operācijas satura kopēšanas, kas novestu pie *O*(*n*^ 2) darbības laika, veidojot *n* baitu virkni ar atkārtotu savienojumu.
///
///
/// Stīga labajā pusē ir tikai aizņemta;tā saturs tiek iekopēts atgrieztajā `String`.
///
/// # Examples
///
/// Savienojot divas "stīgas", pirmā ņem vērtību un aizņemas otro:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` ir pārvietots un šeit to vairs nevar izmantot.
/// ```
///
/// Ja vēlaties turpināt izmantot pirmo `String`, varat to klonēt un tā vietā pievienot klonam:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` šeit joprojām ir derīgs.
/// ```
///
/// Apvienot `&str` šķēles var, pārveidojot pirmo par `String`:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// Īsteno `+=` operatoru pievienošanai `String`.
///
/// Tam ir tāda pati darbība kā [`push_str`][String::push_str] metodei.
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// [`Infallible`] tipa aizstājvārds.
///
/// Šis aizstājvārds pastāv atgriezeniskai saderībai, un tas var būt novecojis.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// trait vērtības pārvēršanai par `String`.
///
/// Šis trait tiek automātiski ieviests jebkuram tipam, kas īsteno [`Display`] trait.
/// Tādējādi `ToString` nevajadzētu ieviest tieši:
/// [`Display`] Tā vietā ir jāievieš `ToString` ieviešana bez maksas.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// Konvertē norādīto vērtību uz `String`.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// Šajā ieviešanā `to_string` metode panics, ja `Display` ieviešana atgriež kļūdu.
/// Tas norāda uz nepareizu `Display` ieviešanu, jo `fmt::Write for String` nekad neatgriež kļūdu.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // Kopēja vadlīnija ir vispārīgo funkciju neiekļaušana.
    // Tomēr `#[inline]` noņemšana no šīs metodes izraisa nenozīmīgas regresijas.
    // Skatiet <https://github.com/rust-lang/rust/pull/74852>-pēdējo mēģinājumu mēģināt to noņemt.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// Pārvērš `&mut str` par `String`.
    ///
    /// Rezultāts tiek piešķirts uz kaudzes.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: tests ievelk libstd, kas šeit rada kļūdas
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// Konvertē norādīto `str` šķēli `String`.
    /// Zīmīgi, ka `str` šķēle pieder.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// Konvertē norādīto `String` par īpašumā esošu `str` šķēlīti.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// Stīgu šķēli pārvērš par aizņemtu variantu.
    /// Nekāda kaudzes piešķiršana netiek veikta, un virkne netiek kopēta.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// Stīgu pārveido par īpašumā esošu variantu.
    /// Nekāda kaudzes piešķiršana netiek veikta, un virkne netiek kopēta.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// Konvertē virknes atsauci uz aizņemtu variantu.
    /// Nekāda kaudzes piešķiršana netiek veikta, un virkne netiek kopēta.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// Konvertē norādīto `String` par vector `Vec`, kurā ir `u8` tipa vērtības.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// `String` iztukšošanas iterators.
///
/// Šo struktūru izveido [`drain`] metode operētājsistēmā [`String`].
/// Plašāku informāciju skatiet tās dokumentācijā.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// Destruktorā tiks izmantots kā&mut virkne
    string: *mut String,
    /// Sākt daļu noņemšanai
    start: usize,
    /// Noņemamās daļas beigas
    end: usize,
    /// Pašreizējais atlikušais diapazons, kas jānoņem
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Izmantojiet Vec::drain.
            // "Reaffirm" robežu pārbaudes, lai izvairītos no panic koda atkārtotas ievietošanas.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// Atgriež šī iteratora atlikušo (apakš) virkni kā daļu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: komentārs AsRef stabilizējoties norāda zemāk.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// Nekomentējot, stabilizējot `string_drain_as_str`.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>priekš Drain <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> Drain <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}