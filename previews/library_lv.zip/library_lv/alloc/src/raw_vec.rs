#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Jaunās atmiņas saturs nav inicializēts.
    Uninitialized,
    /// Jaunā atmiņa tiek garantēta nulles.
    Zeroed,
}

/// Zema līmeņa utilīta, lai ergonomiskāk piešķirtu, pārdalītu un sadalītu atmiņas buferi uz kaudzes, neuztraucoties par visiem iesaistītajiem stūra gadījumiem.
///
/// Šis tips ir lieliski piemērots, lai izveidotu savas datu struktūras, piemēram, Vec un VecDeque.
/// It īpaši:
///
/// * Izgatavo `Unique::dangling()` uz nulles lieluma tipiem.
/// * Izgatavo `Unique::dangling()` uz nulles garuma piešķīrumiem.
/// * Izvairās no `Unique::dangling()` atbrīvošanas.
/// * Uztver visas pārpildes jaudas aprēķinos (paaugstina tos par "capacity overflow" panics).
/// * Aizsargā pret 32 bitu sistēmām, kas piešķir vairāk nekā isize::MAX baitus.
/// * Aizsargi pret jūsu garuma pārpildīšanu.
/// * Pieprasa `handle_alloc_error` kļūdainus piešķīrumus.
/// * Satur `ptr::Unique` un tādējādi piešķir lietotājam visas saistītās priekšrocības.
/// * Izmanto no sadalītāja atdoto pārsniegumu, lai izmantotu lielāko pieejamo jaudu.
///
/// Šis tips tik un tā nepārbauda tā pārvaldīto atmiņu.Nometot, tas * atbrīvos atmiņu, bet nemēģinās nomest tā saturu.
/// `RawVec` lietotāja ziņā ir rīkoties ar faktiskajām lietām, kas *glabājas*`RawVec` iekšpusē.
///
/// Ņemiet vērā, ka nulles lieluma tipu pārsniegums vienmēr ir bezgalīgs, tāpēc `capacity()` vienmēr atgriež `usize::MAX`.
/// Tas nozīmē, ka jums jābūt piesardzīgam, ja šo veidu noapaļojat ar `Box<[T]>`, jo `capacity()` nedos garumu.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Tas pastāv, jo `#[unstable]` `const fn` nav obligāti jāatbilst `min_const_fn` un tāpēc tos nevar izsaukt arī sadaļā`min_const_fn`.
    ///
    /// Ja maināt `RawVec<T>::new` vai atkarības, lūdzu, uzmanieties, lai netiktu ieviests nekas tāds, kas patiešām pārkāptu `min_const_fn`.
    ///
    /// NOTE: Mēs varētu izvairīties no šī uzlaušanas un pārbaudīt atbilstību kādam `#[rustc_force_min_const_fn]` atribūtam, kam nepieciešama atbilstība `min_const_fn`, bet ne vienmēr ļauj to izsaukt `stable(...) const fn`/lietotāja kodā, neļaujot `foo`, kad ir klāt `#[rustc_const_unstable(feature = "foo", issue = "01234")]`.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Izveido pēc iespējas lielāku `RawVec` (sistēmas kaudzē), nepiešķirot.
    /// Ja `T` ir pozitīvs izmērs, tad tas veido `RawVec` ar ietilpību `0`.
    /// Ja `T` ir nulles lielums, tas veido `RawVec` ar ietilpību `usize::MAX`.
    /// Noderīgi novēlotas piešķiršanas ieviešanai.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Izveido `RawVec` (sistēmas kaudzē) ar precīzi `[T; capacity]` jaudas un izlīdzināšanas prasībām.
    /// Tas ir līdzvērtīgs `RawVec::new` izsaukšanai, ja `capacity` ir `0` vai `T` ir nulles lielums.
    /// Ņemiet vērā, ka, ja `T` ir nulle izmēra, tas nozīmē, ka jūs * nesaņemsit `RawVec` ar pieprasīto jaudu.
    ///
    /// # Panics
    ///
    /// Panics, ja pieprasītā jauda pārsniedz `isize::MAX` baitus.
    ///
    /// # Aborts
    ///
    /// Pārtrauca OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Tāpat kā `with_capacity`, bet garantē, ka buferis tiek nulle.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Izveido `RawVec` no rādītāja un ietilpības.
    ///
    /// # Safety
    ///
    /// `ptr` ir jāpiešķir (sistēmas kaudzē) un ar norādīto `capacity`.
    /// `capacity` lieluma tipiem nevar pārsniegt `isize::MAX`.(bažas tikai par 32 bitu sistēmām).
    /// ZST vectors ietilpība var būt līdz `usize::MAX`.
    /// Ja `ptr` un `capacity` nāk no `RawVec`, tas tiek garantēts.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Tiny vecs ir mēms.Pāriet uz:
    // - 8, ja elementa lielums ir 1, jo visi kaudzes sadalītāji, iespējams, noapaļo pieprasījumu, kas ir mazāks par 8 baitiem, līdz vismaz 8 baitiem.
    //
    // - 4, ja elementi ir mērena izmēra (<=1 KiB).
    // - 1 citādi, lai nepieļautu pārāk daudz vietas izšķērdēšanu ļoti īsiem Vecs.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Tāpat kā `new`, bet tas ir parametrizēts salīdzinājumā ar atvēlētā `RawVec` sadalītāja izvēli.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` nozīmē "unallocated".nulles lieluma veidi tiek ignorēti.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Tāpat kā `with_capacity`, bet tas ir parametrizēts salīdzinājumā ar atvēlētā `RawVec` sadalītāja izvēli.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Tāpat kā `with_capacity_zeroed`, bet tas ir parametrizēts, salīdzinot ar atvēlētā `RawVec` sadalītāja izvēli.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Pārvērš `Box<[T]>` par `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Pārvērš visu buferi par `Box<[MaybeUninit<T>]>` ar norādīto `len`.
    ///
    /// Ņemiet vērā, ka tas pareizi atjaunos visas veiktās `cap` izmaiņas.(Sīkāku informāciju skatiet tipa aprakstā.)
    ///
    /// # Safety
    ///
    /// * `len` - tai jābūt lielākai par vai vienādai ar pēdējo pieprasīto jaudu, un-
    /// * `len` jābūt mazākai vai vienādai ar `self.capacity()`.
    ///
    /// Ņemiet vērā, ka pieprasītā jauda un `self.capacity()` var atšķirties, jo piešķīrējs varētu vispārīgi izvietot un atgriezt lielāku atmiņas bloku, nekā pieprasīts.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Saprāts-pārbaudiet pusi drošības prasību (otru pusi mēs nevaram pārbaudīt).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Mēs šeit izvairāmies no `unwrap_or_else`, jo tas uzpūš ģenerētā LLVM IR daudzumu.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Izveido `RawVec` no rādītāja, jaudas un sadalītāja.
    ///
    /// # Safety
    ///
    /// `ptr` jāpiešķir (caur doto sadalītāju `alloc`) un ar doto `capacity`.
    /// `capacity` lieluma tipiem nevar pārsniegt `isize::MAX`.
    /// (bažas tikai par 32 bitu sistēmām).
    /// ZST vectors ietilpība var būt līdz `usize::MAX`.
    /// Ja `ptr` un `capacity` nāk no `RawVec`, kas izveidots, izmantojot `alloc`, tas tiek garantēts.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Iegūst neapstrādātu rādītāju piešķiršanas sākumam.
    /// Ņemiet vērā, ka tas ir `Unique::dangling()`, ja `capacity == 0` vai `T` ir nulles lielums.
    /// Pirmajā gadījumā jums jābūt uzmanīgam.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Iegūst piešķīruma jaudu.
    ///
    /// Tas vienmēr būs `usize::MAX`, ja `T` ir nulles lielums.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Atgriež kopīgu atsauci uz sadalītāju, kas atbalsta šo `RawVec`.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Mums ir piešķirta atmiņas daļa, tāpēc mēs varam apiet izpildlaika pārbaudes, lai iegūtu pašreizējo izkārtojumu.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Nodrošina, ka buferī ir vismaz pietiekami daudz vietas, lai turētu `len + additional` elementus.
    /// Ja tam vēl nav pietiekami daudz jaudas, tas pārdalīs pietiekami daudz vietas un ērtu brīvu vietu, lai iegūtu amortizētu *O*(1) uzvedību.
    ///
    /// Ierobežos šo rīcību, ja tas nevajadzīgi izraisīs panic.
    ///
    /// Ja `len` pārsniedz `self.capacity()`, tas var neizdoties faktiski piešķirt pieprasīto vietu.
    /// Tas patiesībā nav nedrošs, taču nedrošais kods, kuru * uzrakstāt un kurš balstās uz šīs funkcijas darbību, var salūzt.
    ///
    /// Tas ir ideāli piemērots lielapjoma darbības, piemēram, `extend`, ieviešanai.
    ///
    /// # Panics
    ///
    /// Panics, ja jaunā jauda pārsniedz `isize::MAX` baitus.
    ///
    /// # Aborts
    ///
    /// Pārtrauca OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // rezerve būtu pārtraukusi vai panikā, ja len pārsniegtu `isize::MAX`, tāpēc to tagad var droši pārbaudīt.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// Tas pats, kas `reserve`, bet atgriežas pie kļūdām, nevis panikā vai pārtraukumā.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Nodrošina, ka buferī ir vismaz pietiekami daudz vietas, lai turētu `len + additional` elementus.
    /// Ja tas vēl nav izdarīts, pārdalīs minimālo iespējamo nepieciešamo atmiņas apjomu.
    /// Parasti tas būs tieši nepieciešamais atmiņas apjoms, taču principā sadalītājs var brīvi atdot vairāk, nekā mēs lūdzām.
    ///
    ///
    /// Ja `len` pārsniedz `self.capacity()`, tas var neizdoties faktiski piešķirt pieprasīto vietu.
    /// Tas patiesībā nav nedrošs, taču nedrošais kods, kuru * uzrakstāt un kurš balstās uz šīs funkcijas darbību, var salūzt.
    ///
    /// # Panics
    ///
    /// Panics, ja jaunā jauda pārsniedz `isize::MAX` baitus.
    ///
    /// # Aborts
    ///
    /// Pārtrauca OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// Tas pats, kas `reserve_exact`, bet atgriežas pie kļūdām, nevis panikā vai pārtraukumā.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Samazina piešķīrumu līdz norādītajai summai.
    /// Ja norādītā summa ir 0, faktiski tiek pilnībā sadalīti.
    ///
    /// # Panics
    ///
    /// Panics, ja norādītā summa ir *lielāka* par pašreizējo jaudu.
    ///
    /// # Aborts
    ///
    /// Pārtrauca OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Atgriež, ja buferim ir jāaug, lai izpildītu nepieciešamo papildu jaudu.
    /// Galvenokārt tiek izmantots, lai rezerves zvani būtu iespējami bez `grow` iekļaušanas.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Šo metodi parasti instancē daudzas reizes.Tāpēc mēs vēlamies, lai tas būtu pēc iespējas mazāks, lai uzlabotu kompilēšanas laikus.
    // Bet mēs arī vēlamies, lai pēc iespējas vairāk tā satura būtu statiski aprēķināms, lai radītais kods darbotos ātrāk.
    // Tāpēc šī metode ir rūpīgi uzrakstīta tā, lai viss kods, kas ir atkarīgs no `T`, būtu tajā, kamēr pēc iespējas vairāk koda, kas nav atkarīgs no `T`, atrodas funkcijās, kas nav vispārīgas, izmantojot `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // To nodrošina izsaucošie konteksti.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Tā kā mēs atgriežam `usize::MAX` jaudu, kad `elem_size` ir
            // 0, nokļūšana šeit nozīmē, ka `RawVec` ir pārpildīts.
            return Err(CapacityOverflow);
        }

        // Diemžēl mēs neko īsti nevaram padarīt par šīm pārbaudēm.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Tas garantē eksponenciālu izaugsmi.
        // Divkāršošana nevar pārplūst, jo `cap <= isize::MAX` un `cap` tips ir `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` nav vispārējs, izmantojot `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Šīs metodes ierobežojumi ir daudz tādi paši kā `grow_amortized`, taču šī metode parasti tiek parādīta retāk, tāpēc tā ir mazāk kritiska.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Tā kā mēs atdodam jaudu `usize::MAX`, kad tipa lielums ir
            // 0, nokļūšana šeit nozīmē, ka `RawVec` ir pārpildīts.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` nav vispārējs, izmantojot `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Šī funkcija ir ārpus `RawVec`, lai samazinātu kompilēšanas laiku.Sīkāku informāciju skatiet komentārā virs `RawVec::grow_amortized`.
// (`A` parametrs nav nozīmīgs, jo dažādu praksē redzamo `A` tipu skaits ir daudz mazāks nekā `T` tipu skaits.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Pārbaudiet, vai šeit nav kļūdas, lai samazinātu `RawVec::grow_*` lielumu.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Alokators pārbauda saskaņošanas vienlīdzību
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Atbrīvo `RawVec` piederošo atmiņu *, nemēģinot* nomest tā saturu.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Centrālā funkcija rezerves kļūdu apstrādei.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Mums jāgarantē:
// * Mēs nekad nepiešķiram `> isize::MAX` baitu lieluma objektus.
// * Mēs nepārpildām `usize::MAX` un faktiski piešķiram pārāk maz.
//
// 64 bitu mums vienkārši jāpārbauda pārplūde, jo mēģinājums piešķirt `> isize::MAX` baitus noteikti neizdosies.
// 32 bitu un 16 bitu gadījumā mums tam jāpievieno papildu aizsargs, ja mēs darbojamies uz platformas, kas lietotāja telpā var izmantot visus 4 GB, piemēram, PAE vai x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Viena centrālā funkcija, kas ir atbildīga par pārpildes jaudas ziņošanu.
// Tas nodrošinās, ka kodu ģenerēšana, kas saistīta ar šiem panics, ir minimāla, jo visā modulī ir tikai viena vieta, kuru panics, nevis ķekars.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}