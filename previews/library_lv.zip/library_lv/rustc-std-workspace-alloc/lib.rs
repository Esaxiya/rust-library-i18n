#![feature(no_core)]
#![no_core]

// Skatiet rustc-std-darbvietas kodols, kāpēc nepieciešams šis crate.

// Pārdēvējiet crate, lai izvairītos no konfliktiem ar piešķiršanas moduli liballoc.
extern crate alloc as foo;

pub use foo::*;