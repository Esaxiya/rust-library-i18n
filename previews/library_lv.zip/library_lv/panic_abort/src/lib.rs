//! Rust ieviešana panics, izmantojot procesa pārtraukšanu
//!
//! Salīdzinot ar ieviešanu, izmantojot atritināšanu, šis crate ir *daudz* vienkāršāks!Tas nozīmē, ka tas nav tik universāls, bet šeit iet!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" lietderīgā slodze un pārsegs attiecīgajam abortam uz attiecīgās platformas.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // zvaniet uz std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // Operētājsistēmā Windows izmantojiet procesoram raksturīgo __fastfail mehānismu.Operētājsistēmā Windows 8 un jaunākās versijās process tiks nekavējoties pārtraukts, nedarbinot nevienu procesa izņēmumu apstrādātāju.
            // Iepriekšējās Windows versijās šī instrukciju secība tiks uzskatīta par piekļuves pārkāpumu, pārtraucot procesu, bet ne vienmēr apejot visus izņēmumu apstrādātājus.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: šī ir tāda pati ieviešana kā libstd `abort_internal`
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// Tas ... ir mazliet dīvainība.Tl; dr;ir tas, ka tas ir nepieciešams, lai pareizi saistītu, garāks skaidrojums ir zemāk.
//
// Pašlaik visi mūsu piegādātie libcore/libstd binārie faili ir apkopoti ar `-C panic=unwind`.Tas tiek darīts, lai nodrošinātu, ka binārie faili ir maksimāli saderīgi ar pēc iespējas vairākām situācijām.
// Kompilatoram tomēr ir nepieciešama "personality function" visām funkcijām, kas apkopotas ar `-C panic=unwind`.Šī personības funkcija ir kodēta līdz simbolam `rust_eh_personality`, un to nosaka vienums `eh_personality` lang.
//
// So...
// kāpēc ne tikai definēt šo lang vienumu šeit?Labs jautājums!panic izpildlaiku saistīšanas veids faktiski ir nedaudz smalks, jo tie ir "sort of" kompilatora crate veikalā, bet faktiski ir saistīti tikai tad, ja cits nav faktiski saistīts.
//
// Tas galu galā nozīmē, ka gan šis crate, gan panic_unwind crate var parādīties kompilatora crate veikalā, un, ja abi definē `eh_personality` lang vienumu, tas kļūs par kļūdu.
//
// Lai to paveiktu, kompilatoram ir nepieciešama `eh_personality` definīcija tikai tad, ja saistāmais panic izpildlaiks ir attīšanas izpildlaiks, un citādi tas nav jādefinē (pareizi).
// Tomēr šajā gadījumā šī bibliotēka tikai definē šo simbolu, tāpēc kaut kur ir vismaz kāda personība.
//
// Būtībā šis simbols ir tikai definēts, lai izveidotu vadu līdz libcore/libstd bināriem failiem, taču to nekad nevajadzētu izsaukt, jo mēs vispār nesaistāmies attīšanas laikā.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // Vietnē x86_64-pc-windows-gnu mēs izmantojam savu personības funkciju, kurai jāatdod `ExceptionContinueSearch`, kad mēs nododam visus savus rāmjus.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // Līdzīgi kā iepriekš, tas atbilst vienumam `eh_catch_typeinfo` lang, kas pašlaik tiek izmantots tikai Emscripten.
    //
    // Tā kā panics nerada izņēmumus un ārvalstu izņēmumi pašlaik ir UB ar -C panic=pārtraukt (lai gan tas var tikt mainīts), jebkādos catch_unwind zvanos nekad netiks izmantota šāda veida informācija.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // Šos divus izsauc mūsu startēšanas objekti vietnē i686-pc-windows-gnu, taču viņiem nekas nav jādara, tāpēc ķermeņi ir nops.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}