// rsbegin.o un rsend.o ir tā sauktie "compiler runtime startup objects".
// Tie satur kodu, kas nepieciešams, lai pareizi inicializētu kompilatora izpildlaiku.
//
// Kad ir saistīts izpildāms vai dylib attēls, visi lietotāja kodi un bibliotēkas atrodas starp šiem diviem objektu failiem "sandwiched", tāpēc kods vai dati no rsbegin.o kļūst par pirmajiem attiecīgajās attēla sadaļās, savukārt kods un dati no rsend.o kļūst par pēdējiem.
// Šo efektu var izmantot, lai ievietotu simbolus sadaļas sākumā vai beigās, kā arī ievietotu visas nepieciešamās galvenes vai kājenes.
//
// Ņemiet vērā, ka faktiskais moduļa ieejas punkts atrodas C izpildlaika startēšanas objektā (parasti saukts par `crtX.o`), kas pēc tam izsauc citu izpildlaika komponentu inicializācijas atzvanus (reģistrēti, izmantojot vēl vienu īpašu attēlu sadaļu).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Atzīmē kaudzes rāmja atsākšanas informācijas sadaļas sākumu
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Skrāpējumu vieta, lai atpūsties iekšējā grāmatvedībā.
    // Tas ir definēts kā `struct object` mapē $ GCC/unfind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Atritiniet informāciju par registration/deregistration kārtību.
    // Skatiet libpanic_unwind dokumentus.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // reģistrējiet informāciju par moduļa startēšanu
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // atcelt reģistrāciju pēc izslēgšanas
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW raksturīgā init/uninit ikdienas reģistrācija
    pub mod mingw_init {
        // MinGW starta objekti (crt0.o/dllcrt0.o) startējot un izejot, izsauks globālos konstruktorus sadaļās .ctors un .dtors.
        // DLL gadījumā tas tiek darīts, kad DLL tiek ielādēts un izkrauts.
        //
        // Saite sašķiros sadaļas, kas nodrošina, ka mūsu atzvanīšana atrodas saraksta beigās.
        // Tā kā konstruktori darbojas apgrieztā secībā, tas nodrošina, ka mūsu atzvanīšana ir pirmā un pēdējā.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: C inicializācijas atzvanīšana
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: C pārtraukšanas atzvanīšana
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}