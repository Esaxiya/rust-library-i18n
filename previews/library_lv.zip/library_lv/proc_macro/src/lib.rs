//! Atbalsta bibliotēka makro autoriem, nosakot jaunus makro.
//!
//! Šī bibliotēka, ko nodrošina standarta izplatīšana, nodrošina veidus, kas patērēti procesuāli definētu makro definīciju saskarnēs, piemēram, funkcijai līdzīgi makro `#[proc_macro]`, makro atribūti `#[proc_macro_attribute]` un pielāgotie atvasināšanas atribūti "#[proc_macro_derive]".
//!
//!
//! Lai uzzinātu vairāk, skatiet [the book].
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Nosaka, vai proc_macro ir padarīts pieejams pašreizējai programmai.
///
/// Proc_macro crate ir paredzēts lietošanai tikai procesuālo makro ieviešanā.Visas funkcijas šajā crate panic tiek izsauktas no procedūras makro ārpuses, piemēram, no būvniecības skripta vai vienības testa vai parastā binārā Rust.
///
/// Ņemot vērā Rust bibliotēkas, kas paredzētas gan makro, gan bez makro izmantošanas gadījumu atbalstam, `proc_macro::is_available()` nodrošina panikas nepazīšanas veidu, lai noteiktu, vai proc_macro API lietošanai nepieciešamā infrastruktūra pašlaik ir pieejama.
/// Atgriež vērtību true, ja to izsauc no procedūras makro iekšpuses, false, ja to izsauc no jebkura cita binārā faila.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// Galvenais veids, ko nodrošina šis crate, kas attēlo abstraktu tokens plūsmu vai, precīzāk, token koku secību.
/// Šis tips nodrošina saskarnes, lai atkārtotu šos token kokus un, gluži pretēji, vienā straumē savāktu vairākus token kokus.
///
///
/// Tas ir gan `#[proc_macro]`, `#[proc_macro_attribute]` un `#[proc_macro_derive]` definīciju ievads, gan izeja.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Kļūda atgriezta no `TokenStream::from_str`.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Atgriež tukšu `TokenStream`, kurā nav koku token.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Pārbauda, vai šis `TokenStream` ir tukšs.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Mēģinājumi sadalīt virkni tokens un parsēt tos tokens token straumē.
/// Var neizdoties vairāku iemeslu dēļ, piemēram, ja virkne satur nesabalansētus atdalītājus vai rakstzīmes, kuru valodā nav.
///
/// Visi parsētās straumē esošie tokens iegūst `Span::call_site()` laidumus.
///
/// NOTE: dažas kļūdas var izraisīt panics, nevis atgriezt `LexError`.Mēs paturam tiesības šīs kļūdas vēlāk mainīt uz `LexError`.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, tilts nodrošina tikai `to_string`, ieviešot uz tā balstītu `fmt::Display` (otrādi, nekā parasti ir starp abām attiecībām).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Drukā token straumi kā virkni, kas, domājams, bez zaudējumiem var tikt konvertēta atpakaļ tajā pašā token straumē (moduļa laidumi), izņemot, iespējams, `TokenTree: : Group` ar `Delimiter::None` atdalītājiem un negatīviem skaitliskiem literāliem.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Drukā token formā, kas ērta atkļūdošanai.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Izveido token plūsmu, kurā ir viens token koks.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Savāc vairākus token kokus vienā plūsmā.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// "flattening" darbība ar token straumēm apkopo token kokus no vairākām token straumēm vienā straumē.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Izmantojiet optimizētu if/when ieviešanas iespēju.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// `TokenStream` tipa publiska ieviešanas informācija, piemēram, iteratori.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// `TokenStream` `TokenTree` atkārtojums.
    /// Atkārtojums ir "shallow", piemēram, atkārtotājs neatkārtojas norobežotās grupās un veselas grupas atgriež kā token kokus.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` pieņem patvaļīgu tokens un izplešas par `TokenStream`, kas apraksta ievadi.
/// Piemēram, `quote!(a + b)` radīs izteiksmi, kas, novērtējot, konstruē `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Nekotēšana tiek veikta, izmantojot `$`, un tā darbojas kā nākamais vienīgais identifikators kā nekotētais termins.
/// Lai citētu pašu `$`, izmantojiet `$$`.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// Avota koda reģions kopā ar makro paplašināšanas informāciju.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Izveido jaunu `Diagnostic` ar norādīto `message` diapazonā `self`.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Diapazons, kas tiek atrisināts makro definīcijas vietnē.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// Pašreizējā procesuālā makro piesaiste.
    /// Identifikatori, kas izveidoti ar šo diapazonu, tiks atrisināti tā, it kā tie būtu rakstīti tieši makro zvana vietā (zvana vietas higiēna), un uz tiem varēs atsaukties arī citi makro zvana vietnes kodi.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// Diapazons, kas atspoguļo `macro_rules` higiēnu un dažreiz tiek atrisināts makro definīcijas vietnē (vietējie mainīgie, etiķetes, `$crate`) un dažreiz makro izsaukuma vietā (viss pārējais).
    ///
    /// Span atrašanās vieta tiek ņemta no zvana vietnes.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// Sākotnējais avota fails, kurā norāda šo laidumu.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// `Span` tokens modelim iepriekšējā makro paplašinājumā, no kura tika ģenerēts `self`, ja tāds bija.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// Izcelsmes avota koda diapazons, no kura tika ģenerēts `self`.
    /// Ja šī `Span` netika ģenerēta no citiem makro paplašinājumiem, atgriešanās vērtība ir tāda pati kā `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Iegūst sākuma line/column avota failā šim diapazonam.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Šim posmam tiek iegūts beigu line/column avota failā.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Izveido jaunu diapazonu, kas ietver `self` un `other`.
    ///
    /// Atgriež vērtību `None`, ja `self` un `other` ir no dažādiem failiem.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Izveido jaunu diapazonu ar tādu pašu line/column informāciju kā `self`, bet tas atrisina simbolus tā, it kā tas būtu `other`.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Izveido jaunu diapazonu ar tādu pašu nosaukuma izšķirtspējas uzvedību kā `self`, bet ar `other` informāciju line/column.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Salīdzina ar laidumiem, lai redzētu, vai tie ir vienādi.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Atgriež avota tekstu aiz atstarpes.
    /// Tas saglabā sākotnējo pirmkodu, ieskaitot atstarpes un komentārus.
    /// Tas atgriež rezultātu tikai tad, ja diapazons atbilst reālajam avota kodam.
    ///
    /// Note: Makro novērojamajam rezultātam vajadzētu paļauties tikai uz tokens, nevis uz šo avota tekstu.
    ///
    /// Šīs funkcijas rezultāts ir labākais, lai to izmantotu tikai diagnostikai.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Izdrukā izmēru formā, kas ir ērta atkļūdošanai.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Rindu un kolonnu pāris, kas apzīmē `Span` sākumu vai beigas.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// 1 indeksētā rinda avota failā, kurā diapazons sākas vai beidzas (inclusive).
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// 0 indeksēta kolonna (ar UTF-8 rakstzīmēm) avota failā, kurā diapazons sākas vai beidzas (inclusive).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Dotā `Span` avota fails.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Tiek iegūts ceļš uz šo avota failu.
    ///
    /// ### Note
    /// Ja koda laidumu, kas saistīts ar šo `SourceFile`, ir ģenerējis ārējs makro, šis makro, iespējams, nav faktiskais failu sistēmas ceļš.
    /// Lai pārbaudītu, izmantojiet [`is_real`].
    ///
    /// Ņemiet vērā arī to, ka pat tad, ja `is_real` atgriež `true`, ja `--remap-path-prefix` tika nodots komandrindā, norādītais ceļš faktiski var nebūt derīgs.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Atgriež vērtību `true`, ja šis avota fails ir reāls avota fails un nav ģenerēts ārēja makro paplašināšanas rezultātā.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Tas ir kapāt, līdz tiek ieviesti starpkļūmju diapazoni, un mums var būt reāli avota faili laidumiem, kas ģenerēti ārējos makros.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// Viena token vai norobežota token koku secība (piemēram, `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// token straume, kuru ieskauj iekavu atdalītāji.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Identifikators.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Viena pieturzīme (`+`, `,`, `$` utt.).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// Burtisks burts (`'a'`), virkne (`"hello"`), skaitlis (`2.3`) utt.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Atgriež šī koka laidumu, deleģējot `span` metodi ietvertajam token vai norobežotai straumei.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Konfigurē diapazonu *tikai šim token*.
    ///
    /// Ņemiet vērā, ka, ja šis token ir `Group`, šī metode nekonfigurēs katra iekšējā tokens diapazonu, tas vienkārši tiks deleģēts katra varianta `set_span` metodei.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// Izdrukā token koku atkļūdošanai ērtā formā.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Katram no tiem atvasinātajā atkļūdojumā ir struktūras tipa nosaukums, tāpēc neuztraucieties ar papildu netiešo slāni
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, tilts nodrošina tikai `to_string`, ieviešot uz tā balstītu `fmt::Display` (otrādi, nekā parasti ir starp abām attiecībām).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Izdrukā token koku kā virkni, kas, domājams, bez zaudējumiem var tikt pārveidota tajā pašā token kokā (modulo laidumi), izņemot, iespējams, `TokenTree: : Group` ar `Delimiter::None` atdalītājiem un negatīviem skaitliskiem literāliem.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Norobežota token straume.
///
/// `Group` iekšpusē ir `TokenStream`, kuru ieskauj `Delimiter`s.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Apraksta, kā tiek norobežota token koku secība.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// Netiešs atdalītājs, kas, piemēram, var parādīties ap tokens, kas nāk no "macro variable" `$var`.
    /// Ir svarīgi saglabāt operatora prioritātes tādos gadījumos kā `$var * 3`, kur `$var` ir `1 + 2`.
    /// Netiešie atdalītāji var neizdzīvot token straumes apļa virkni.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Izveido jaunu `Group` ar norādīto atdalītāju un token straumi.
    ///
    /// Šis konstruktors iestatīs šīs grupas diapazonu uz `Span::call_site()`.
    /// Lai mainītu diapazonu, varat izmantot `set_span` metodi.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Atgriež šī `Group` atdalītāju
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Atgriež tokens `TokenStream`, kas ir norobežots šajā `Group`.
    ///
    /// Ņemiet vērā, ka atgrieztajā token straumē nav iekļauts iepriekš atgrieztais atdalītājs.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Atgriež šīs token straumes norobežotāju diapazonu, kas aptver visu `Group`.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Atgriež diapazonu, kas norāda uz šīs grupas sākuma atdalītāju.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Atgriež diapazonu, kas norāda uz šīs grupas noslēguma atdalītāju.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Konfigurē šīs `grupas 'atdalītāju diapazonu, bet ne tās iekšējo tokens.
    ///
    /// Šī metode **nenoteiks** visu iekšējo tokens diapazonu, ko aptver šī grupa, bet tā tikai noteiks norobežotāja tokens diapazonu `Group` līmenī.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, tilts nodrošina tikai `to_string`, ieviešot uz tā balstītu `fmt::Display` (otrādi, nekā parasti ir starp abām attiecībām).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Izdrukā grupu kā virkni, kuru vajadzētu bez zaudējumiem pārveidot atpakaļ tajā pašā grupā (moduļa laidumi), izņemot, iespējams, `TokenTree: : Group` ar `Delimiter::None` atdalītājiem.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// `Punct` ir viena pieturzīme, piemēram, `+`, `-` vai `#`.
///
/// Vairāku rakstzīmju operatori, piemēram, `+=`, tiek attēloti kā divi `Punct` gadījumi ar dažādu `Spacing` formu atgriešanos.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Vai `Punct` seko uzreiz cits `Punct`, vai seko cits token vai atstarpe.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// piemēram, `+` ir `Alone` `+ =`, `+ident` vai `+()`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// piemēram, `+` ir `Joint` `+=` vai `'#`.
    /// Turklāt viena kotācija `'` var apvienoties ar identifikatoriem, lai izveidotu `'ident` kalpošanas laiku.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Izveido jaunu `Punct` no norādītās rakstzīmes un atstarpes.
    /// `ch` argumentam jābūt derīgai pieturzīmei, ko atļauj valoda, pretējā gadījumā funkcija būs panic.
    ///
    /// Atgrieztajam `Punct` būs noklusējuma diapazons `Span::call_site()`, ko var tālāk konfigurēt, izmantojot tālāk norādīto `set_span` metodi.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Atgriež šīs pieturzīmes vērtību kā `char`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Atgriež šīs pieturzīmes atstarpi, norādot, vai token straumē tam tūlīt seko cits `Punct`, lai tos varētu apvienot daudzzīmju operatorā (`Joint`), vai arī tam seko kāds cits token vai atstarpes (`Alone`), tāpēc operators noteikti ir beidzās.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Atgriež šī pieturzīmes rakstzīmi.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Konfigurējiet šī pieturzīmes rakstzīmi.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, tilts nodrošina tikai `to_string`, ieviešot uz tā balstītu `fmt::Display` (otrādi, nekā parasti ir starp abām attiecībām).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Izdrukā pieturzīmi kā virkni, kas bez zaudējumiem jāpārveido atpakaļ tajā pašā rakstzīmē.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// Identifikators (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Izveido jaunu `Ident` ar norādīto `string`, kā arī norādīto `span`.
    /// `string` argumentam ir jābūt derīgam identifikatoram, ko atļauj valoda (ieskaitot atslēgvārdus, piemēram, `self` vai `fn`).Pretējā gadījumā funkcija būs panic.
    ///
    /// Ņemiet vērā, ka `span`, kas pašlaik atrodas rustc, konfigurē šī identifikatora higiēnas informāciju.
    ///
    /// Šajā laikā `Span::call_site()` skaidri izvēlas "call-site" higiēnu, kas nozīmē, ka identifikatori, kas izveidoti ar šo diapazonu, tiks atrisināti tā, it kā tie būtu rakstīti tieši makro zvana vietā, un citi makro zvana vietnes kodi varēs atsaukties uz arī viņus.
    ///
    ///
    /// Vēlāki laidumi, piemēram, `Span::def_site()`, ļaus izvēlēties "definition-site" higiēnu, kas nozīmē, ka identifikatori, kas izveidoti ar šo diapazonu, tiks atrisināti makro definīcijas vietā, un citi makro zvana vietnes kodi uz tiem nevarēs atsaukties.
    ///
    /// Pašreizējās higiēnas nozīmes dēļ šim konstruktoram, atšķirībā no citiem tokens, būvniecībā ir jānorāda `Span`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// Tas pats, kas `Ident::new`, bet izveido neapstrādātu identifikatoru (`r#ident`).
    /// `string` arguments ir derīgs identifikators, ko atļauj valoda (ieskaitot atslēgvārdus, piemēram, `fn`).
    /// Atslēgvārdi, kas ir izmantojami ceļa segmentos (piemēram,
    /// `self`, "super") netiek atbalstīti, un tas izraisīs panic.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Atgriež šīs `Ident` laidumu, aptverot visu virkni, ko atdeva [`to_string`](Self::to_string).
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Konfigurē šī `Ident` diapazonu, iespējams, mainot tā higiēnas kontekstu.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, tilts nodrošina tikai `to_string`, ieviešot uz tā balstītu `fmt::Display` (otrādi, nekā parasti ir starp abām attiecībām).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Drukā identifikatoru kā virkni, kuru vajadzētu bez zaudējumiem pārveidot atpakaļ tajā pašā identifikatorā.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// Burtiskā virkne (`"hello"`), baitu virkne (`b"hello"`), rakstzīme (`'a'`), baitu rakstzīme (`b'a'`), vesels skaitlis vai peldošā komata skaitlis ar sufiksu vai bez tā ("1", `1u8`, `2.3`, `2.3f32`).
///
/// Būla burtnieki, piemēram, `true` un `false`, šeit nepieder, tie ir `Ident`s.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Izveido jaunu veselu skaitļa burtu burtu ar norādīto vērtību.
        ///
        /// Šī funkcija izveidos tādu veselu skaitli kā `1u32`, kur norādītā veselā skaitļa vērtība ir token pirmā daļa, un beigās integrālis ir arī piedēvēts.
        /// Burtnieki, kas izveidoti no negatīviem skaitļiem, var neizdzīvot turp un atpakaļ, izmantojot `TokenStream` vai virknes, un tos var sadalīt divos tokens (`-` un pozitīvais burtnieks).
        ///
        ///
        /// Literāriem, kas izveidoti, izmantojot šo metodi, pēc noklusējuma ir `Span::call_site()` laidums, kuru var konfigurēt ar zemāk esošo `set_span` metodi.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Izveido jaunu nepievienotu vesela skaitļa burtnīcu ar norādīto vērtību.
        ///
        /// Šī funkcija izveidos tādu veselu skaitli kā `1`, kur norādītā veselā skaitļa vērtība ir token pirmā daļa.
        /// Šajā token nav norādīts piedēklis, tas nozīmē, ka izsaukumi, piemēram, `Literal::i8_unsuffixed(1)`, ir līdzvērtīgi `Literal::u32_unsuffixed(1)`.
        /// Burtnieki, kas izveidoti no negatīviem skaitļiem, var neizdzīvot rountrips caur `TokenStream` vai virknēm, un tos var sadalīt divos tokens (`-` un pozitīvais burtnieks).
        ///
        ///
        /// Literāriem, kas izveidoti, izmantojot šo metodi, pēc noklusējuma ir `Span::call_site()` laidums, kuru var konfigurēt ar zemāk esošo `set_span` metodi.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Izveido jaunu nepiesaistītu peldošā komata burtnīcu.
    ///
    /// Šis konstruktors ir līdzīgs tiem, piemēram, `Literal::i8_unsuffixed`, kur pludiņa vērtība tiek emitēta tieši token, bet netiek izmantots piedēklis, tāpēc vēlāk kompilatorā var secināt, ka tas ir `f64`.
    ///
    /// Burtnieki, kas izveidoti no negatīviem skaitļiem, var neizdzīvot rountrips caur `TokenStream` vai virknēm, un tos var sadalīt divos tokens (`-` un pozitīvais burtnieks).
    ///
    /// # Panics
    ///
    /// Šai funkcijai ir nepieciešams, lai norādītais pludiņš būtu ierobežots, piemēram, ja tas ir bezgalīgs vai NaN, šī funkcija būs panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Izveido jaunu burtu burtu ar peldošo punktu.
    ///
    /// Šis konstruktors izveidos tādu burtisku burtu kā `1.0f32`, kur norādītā vērtība ir token iepriekšējā daļa un `f32` ir token sufikss.
    /// Par šo token vienmēr kompilatorā tiks secināts, ka tas ir `f32`.
    /// Burtnieki, kas izveidoti no negatīviem skaitļiem, var neizdzīvot rountrips caur `TokenStream` vai virknēm, un tos var sadalīt divos tokens (`-` un pozitīvais burtnieks).
    ///
    ///
    /// # Panics
    ///
    /// Šai funkcijai ir nepieciešams, lai norādītais pludiņš būtu ierobežots, piemēram, ja tas ir bezgalīgs vai NaN, šī funkcija būs panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Izveido jaunu nepiesaistītu peldošā komata burtnīcu.
    ///
    /// Šis konstruktors ir līdzīgs tiem, piemēram, `Literal::i8_unsuffixed`, kur pludiņa vērtība tiek emitēta tieši token, bet netiek izmantots piedēklis, tāpēc vēlāk kompilatorā var secināt, ka tas ir `f64`.
    ///
    /// Burtnieki, kas izveidoti no negatīviem skaitļiem, var neizdzīvot rountrips caur `TokenStream` vai virknēm, un tos var sadalīt divos tokens (`-` un pozitīvais burtnieks).
    ///
    /// # Panics
    ///
    /// Šai funkcijai ir nepieciešams, lai norādītais pludiņš būtu ierobežots, piemēram, ja tas ir bezgalīgs vai NaN, šī funkcija būs panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Izveido jaunu burtu burtu ar peldošo punktu.
    ///
    /// Šis konstruktors izveidos tādu burtisku burtu kā `1.0f64`, kur norādītā vērtība ir token iepriekšējā daļa un `f64` ir token sufikss.
    /// Par šo token vienmēr kompilatorā tiks secināts, ka tas ir `f64`.
    /// Burtnieki, kas izveidoti no negatīviem skaitļiem, var neizdzīvot rountrips caur `TokenStream` vai virknēm, un tos var sadalīt divos tokens (`-` un pozitīvais burtnieks).
    ///
    ///
    /// # Panics
    ///
    /// Šai funkcijai ir nepieciešams, lai norādītais pludiņš būtu ierobežots, piemēram, ja tas ir bezgalīgs vai NaN, šī funkcija būs panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// Stīgu burtiskā.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Raksturs burtiski.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Baitu virknes burtiskais.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Atgriež diapazonu, kas aptver šo burtnīcu.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Konfigurē šim literālim saistīto diapazonu.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Atgriež `Span`, kas ir `self.span()` apakškopa, kas satur tikai avota baitus diapazonā `range`.
    /// Atgriež vērtību `None`, ja iespējamais apgrieztais diapazons ir ārpus `self` robežas.
    ///
    // FIXME(SergioBenitez): pārbaudiet, vai baitu diapazons sākas un beidzas pie avota UTF-8 robežas.
    // pretējā gadījumā, visticamāk, panic notiks citur, kad tiek izdrukāts avota teksts.
    // FIXME(SergioBenitez): lietotājam nav iespējas zināt, ar ko `self.span()` faktiski kartē, tāpēc šo metodi pašlaik var izsaukt tikai akli.
    // Piemēram, rakstzīmei `to_string()` `to_string()` atgriež vērtību "'\u{63}'";lietotājam nav iespējas uzzināt, vai avota teksts bija 'c' vai '\u{63}'.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) kaut kas līdzīgs `Option::cloned`, bet `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, tilts nodrošina tikai `to_string`, ieviešot uz tā balstītu `fmt::Display` (otrādi, nekā parasti ir starp abām attiecībām).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Drukā burtnīcu kā virkni, kuru bez zaudējumiem var pārvērst atpakaļ tajā pašā literārā (izņemot peldošā komata literāļu iespējamo noapaļošanu).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Izsekota piekļuve vides mainīgajiem.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Ielādējiet vides mainīgo un pievienojiet to, lai izveidotu informāciju par atkarību.
    /// Veidošanas sistēma, kas izpilda kompilatoru, zinās, ka mainīgajam bija piekļuve kompilēšanas laikā, un varēs atkārtoti palaist versiju, kad mainīsies šī mainīgā vērtība.
    ///
    /// Papildus atkarības izsekošanai šai funkcijai jābūt ekvivalentai `env::var` no standarta bibliotēkas, izņemot to, ka argumentam jābūt UTF-8.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}