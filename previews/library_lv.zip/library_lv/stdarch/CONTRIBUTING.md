# Ieguldījums stdarchā

`stdarch` crate ir vairāk nekā gatavs pieņemt ieguldījumus!Vispirms jūs, iespējams, vēlēsities apskatīt repozitoriju un pārliecināties, vai testi jums ir izturēti:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Kur `<your-target-arch>` ir mērķa trīskāršais, ko lieto `rustup`, piemēram, `x86_x64-unknown-linux-gnu` (bez iepriekšējas `nightly-` vai tamlīdzīgas).
Atcerieties arī, ka šai krātuvei ir nepieciešams Rust nakts kanāls!
Iepriekšminētie testi faktiski prasa, lai nakts rust būtu noklusējums jūsu sistēmā, lai iestatītu `rustup default nightly` (un `rustup default stable`, lai atgrieztos).

Ja kāda no iepriekš minētajām darbībām nedarbojas, [please let us know][new]!

Tālāk jūs varat [find an issue][issues], lai palīdzētu, mēs esam izvēlējušies dažus ar [`help wanted`][help] un [`impl-period`][impl] tagiem, kas varētu īpaši izmantot kādu palīdzību. 
Iespējams, jūs visvairāk interesē [#40][vendor], ieviešot visus piegādātāja raksturīgos elementus x86.Šis jautājums ir ieguvis dažus labus norādījumus par to, kur sākt!

Ja jums ir vispārīgi jautājumi, droši sazinieties ar [join us on gitter][gitter] un jautājiet apkārt!Jūtieties brīvi pingēt vai nu ar@BurntSushi, vai@alexcrichton.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Kā rakstīt piemērus stdarch intrinsics

Ir dažas funkcijas, kuras ir jāiespējo, lai dotā iekšējā funkcija darbotos pareizi, un piemēru `cargo test --doc` vajadzētu palaist tikai tad, kad šo funkciju atbalsta centrālais procesors.

Tā rezultātā noklusējuma `fn main`, ko ģenerē `rustdoc`, nedarbosies (vairumā gadījumu).
Apsveriet iespēju izmantot šo rokasgrāmatu, lai nodrošinātu, ka jūsu piemērs darbojas kā paredzēts.

```rust
/// # // Mums ir nepieciešams cfg_target_feature, lai nodrošinātu tikai piemēru
/// # // palaiž `cargo test --doc`, kad procesors atbalsta šo funkciju
/// # #![feature(cfg_target_feature)]
/// # // Lai iekšējais darbotos, mums ir nepieciešams target_feature
/// # #![feature(target_feature)]
/// #
/// # // rustdoc pēc noklusējuma izmanto `extern crate stdarch`, bet mums tas ir nepieciešams
/// # // `#[macro_use]`
/// # # [macro_use] extern crate stdarch;
/// #
/// # // Patiesā galvenā funkcija
/// # fn main() {
/// #     // Palaidiet to tikai tad, ja tiek atbalstīts `<target feature>`
/// #     ja cfg_feature_enabled! ("<target feature>"){
/// #         // Izveidojiet funkciju `worker`, kas darbosies tikai tad, ja tiks izmantota mērķa funkcija
/// #         // tiek atbalstīts, un pārliecinieties, ka jūsu darbiniekam ir iespējota `target_feature`
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         nedrošs fn worker() {
/// // Uzrakstiet savu piemēru šeit.Šeit darbosies specifiskas iezīmes!Ej mežonīgs!
///
/// #         }
///
/// #         nedrošs { worker(); }
/// #     }
/// # }
```

Ja kāda no iepriekšminētajām sintaksēm neizskatās pazīstama, [Rust Book] sadaļā [Documentation as tests] diezgan labi aprakstīta `rustdoc` sintakse.
Kā vienmēr, nekautrējieties izmantot [join us on gitter][gitter] un pajautājiet mums, vai esat sasniedzis nevienu aizķeršanos, un paldies, ka palīdzējāt uzlabot `stdarch` dokumentāciju!

# Alternatīvās testēšanas instrukcijas

Parasti testu veikšanai ieteicams izmantot `ci/run.sh`.
Tomēr tas var nedarboties jums, piemēram, ja izmantojat Windows.

Tādā gadījumā jūs varat atgriezties pie `cargo +nightly test` un `cargo +nightly test --release -p core_arch` palaišanas, lai pārbaudītu kodu ģenerēšanu.
Ņemiet vērā, ka tiem ir jāinstalē iknedēļas rīku ķēde un lai `rustc` uzzinātu par jūsu mērķa trīskāršo un tā procesoru.
Jo īpaši jums jāiestata vides mainīgais `TARGET` tāpat kā `ci/run.sh`.
Turklāt jums jāiestata `RUSTCFLAGS` (nepieciešams `C`), lai norādītu mērķa funkcijas, piem `RUSTCFLAGS="-C -target-features=+avx2"`.
Varat arī iestatīt `-C -target-cpu=native`, ja izstrādājat "just" pret pašreizējo procesoru.

Jābrīdina, ka, lietojot šīs alternatīvās instrukcijas, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], piem
instrukciju ģenerēšanas testi var neizdoties, jo izjaucējs tos nosauca citādi, piem
tas var ģenerēt `vaesenc`, nevis `aesenc` instrukcijas, neskatoties uz to, ka viņi rīkojas tāpat.
Arī šajos norādījumos tiek veikts mazāk testu nekā parasti, tāpēc nebrīnieties, ka, veicot pieprasījumu, dažas kļūdas var parādīties testos, kas šeit nav apskatīti.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






