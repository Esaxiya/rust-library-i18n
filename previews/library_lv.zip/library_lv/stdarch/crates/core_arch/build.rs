use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Izmanto, lai pastāstītu mūsu `#[assert_instr]` anotācijām, ka visi simd iekšējie elementi ir pieejami, lai pārbaudītu viņu kodegenus, jo daži no tiem ir aiz papildu `-Ctarget-feature=+unimplemented-simd128`, kam pašlaik nav ekvivalenta `#[target_feature]`.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}