`core::arch` - Rust galvenā bibliotēkas arhitektūras specifika
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

`core::arch` modulis ievieš no arhitektūras atkarīgus iekšējos elementus (piemēram, SIMD).

# Usage 

`core::arch` ir pieejams kā daļa no `libcore`, un `libstd` to reeksportē.Dodiet priekšroku tam, izmantojot `core::arch` vai `std::arch`, nevis izmantojot šo crate.
Nestabilas funkcijas bieži vien ir pieejamas nakts Rust, izmantojot `feature(stdsimd)`.

Lai izmantotu `core::arch`, izmantojot šo crate, ir nepieciešams Rust katru nakti, un tas var (un arī) bieži saplīst.Vienīgie gadījumi, kad jāapsver tā izmantošana, izmantojot šo crate, ir:

* ja jums pašam jāpārkompilē `core::arch`, piemēram, ar iespējotām konkrētām mērķa funkcijām, kuras nav iespējotas `libcore`/`libstd`.
Note: ja jums tas ir jāpārkompilē nestandarta mērķim, lūdzu, dodiet priekšroku `xargo` un attiecīgi `libcore`/`libstd` kompilēšanai, nevis šī crate lietošanai.
  
* izmantojot dažas funkcijas, kuras, iespējams, nav pieejamas pat aiz nestabilajām Rust funkcijām.Mēs cenšamies tos samazināt līdz minimumam.
Ja jums ir jāizmanto dažas no šīm funkcijām, lūdzu, atveriet problēmu, lai mēs tos varētu atklāt naktī Rust, un jūs tos varētu izmantot no turienes.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` galvenokārt tiek izplatīts saskaņā ar gan MIT licences, gan Apache licences (versija 2.0) noteikumiem, ar daļām, uz kurām attiecas dažādas BSD līdzīgas licences.

Sīkāku informāciju skatiet LICENCE-APACHE un LICENCE-MIT.

# Contribution

Ja vien nepārprotami nenorādīsiet citādi, jebkurš ieguldījums, ko jūs tīši iesniedzāt iekļaušanai `core_arch`, kā noteikts Apache-2.0 licencē, būs divējāda licence, kā norādīts iepriekš, bez jebkādiem papildu noteikumiem vai nosacījumiem.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












