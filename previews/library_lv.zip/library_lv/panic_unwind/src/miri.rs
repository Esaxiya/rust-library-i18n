//! Atslogo panics Miri.
use alloc::boxed::Box;
use core::any::Any;

// Derīgās kravas veids, ko Miri dzinējs mums izplata, atlaižoties.
// Jābūt rādītāja lielumam.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Miri nodrošina ārējo funkciju, lai sāktu atpūsties.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // Derīgā slodze, kuru mēs nododam `miri_start_panic`, būs tieši arguments, ko mēs iegūsim zemāk esošajā `cleanup`.
    // Tāpēc mēs to vienkārši iesakām vienu reizi, lai iegūtu kaut ko rādītāja izmēru.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Atgūstiet pamatā esošo `Box`.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}