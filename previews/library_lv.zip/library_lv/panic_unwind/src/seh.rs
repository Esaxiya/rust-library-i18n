//! Windows SEH
//!
//! Operētājsistēmā Windows (pašlaik tikai MSVC) noklusējuma izņēmumu apstrādes mehānisms ir Strukturētā izņēmuma apstrāde (SEH).
//! Kompilatora iekšējā ziņā tas ir diezgan atšķirīgs no izņēmumu apstrādes uz punduriem (piemēram, ko izmanto citas unix platformas), tāpēc LLVM ir nepieciešams liels papildu atbalsts SEH.
//!
//! Īsumā šeit notiek:
//!
//! 1. `panic` funkcija izsauc standarta Windows funkciju `_CxxThrowException`, lai izmestu C++ līdzīgu izņēmumu, izraisot attīšanas procesu.
//! 2.
//! Visos kompilatora ģenerētajos piezemēšanās spilventiņos tiek izmantota personības funkcija `__CxxFrameHandler3`, CRT funkcija, un Windows attīšanas kods izmantos šo personības funkciju, lai izpildītu visu sakopšanas kodu.
//!
//! 3. Visiem kompilatora ģenerētajiem zvaniem uz `invoke` ir iestatīta piezemēšanās spilventiņa kā `cleanuppad` LLVM instrukcija, kas norāda tīrīšanas rutīnas sākumu.
//! Personība (2. solī, kas definēta CRT) ir atbildīga par tīrīšanas rutīnas vadīšanu.
//! 4. Galu galā "catch" kods `try` iekšējā (kompilatora ģenerēts) tiek izpildīts un norāda, ka vadībai vajadzētu atgriezties pie Rust.
//! Tas tiek darīts, izmantojot `catchswitch` plus `catchpad` instrukciju LLVM IR izteiksmē, beidzot atgriežot normālu vadību programmā ar `catchret` instrukciju.
//!
//! Dažas specifiskas atšķirības no izņēmumu apstrādes, kuru pamatā ir gcc, ir:
//!
//! * Rust nav pielāgotas personības funkcijas, tā vietā tā ir *vienmēr*`__CxxFrameHandler3`.Turklāt netiek veikta papildu filtrēšana, tāpēc mēs galu galā uztveram visus C++ izņēmumus, kas izskatās līdzīgi mūsu izmestajiem.
//! Ņemiet vērā, ka izņēmuma iemetšana Rust ir nedefinēta rīcība, tāpēc tam vajadzētu būt labi.
//! * Mums ir daži dati, lai tos pārsūtītu pāri pārtīšanas robežai, īpaši `Box<dyn Any + Send>`.Tāpat kā ar rūķu izņēmumiem, šie divi rādītāji tiek glabāti kā lietderīgā krava pašā izņēmumā.
//! Tomēr MSVC nav nepieciešams papildu kaudzes piešķīrums, jo zvana kaudze tiek saglabāta, kamēr tiek izpildītas filtrēšanas funkcijas.
//! Tas nozīmē, ka rādītāji tiek pārsūtīti tieši uz `_CxxThrowException`, kuri pēc tam tiek atgūti filtrēšanas funkcijā, lai tos ierakstītu `try` iekšējā kaudzes rāmī.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Tam jābūt Opcijai, jo mēs noķeram izņēmumu ar atsauci un tā iznīcinātāju izpilda C++ izpildlaiks.
    // Kad mēs izņemam lodziņu no izņēmuma, mums ir jāatstāj izņēmums derīgā stāvoklī, lai tā iznīcinātājs darbotos, divreiz nenometot lodziņu.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// Vispirms viss ķekars tipa definīciju.Šeit ir dažas platformai raksturīgas dīvainības, un daudzas no LLVM ir nepārprotami pārkopētas.Tā visa mērķis ir ieviest zemāk esošo `panic` funkciju, izmantojot zvanu uz `_CxxThrowException`.
//
// Šai funkcijai nepieciešami divi argumenti.Pirmais ir rādītājs datiem, kurus mēs iesūtām, kas šajā gadījumā ir mūsu trait objekts.Diezgan viegli atrast!Nākamais tomēr ir sarežģītāks.
// Šis ir rādītājs `_ThrowInfo` struktūrai, un tas parasti ir paredzēts tikai aprakstīt izmesto izņēmumu.
//
// Pašlaik šāda veida [1] definīcija ir nedaudz mataina, un galvenā dīvainība (un atšķirība no tiešsaistes raksta) ir tāda, ka 32 bitu rādītāji ir rādītāji, bet 64 bitu rādītāji tiek izteikti kā 32 bitu nobīdes no `__ImageBase` simbols.
//
// Lai to izteiktu, tiek izmantoti `ptr_t` un `ptr!` makro zemāk esošajos moduļos.
//
// Tipa definīciju labirints arī cieši seko tam, ko LLVM izstaro šāda veida darbībai.Piemēram, ja jūs apkopojat šo C++ kodu MSVC un izstarojat LLVM IR:
//
//      #include <stdint.h>
//
//      struct rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      anulēts foo() { rust_panic a = {0, 1};
//          iemest a;}
//
// Būtībā to mēs cenšamies atdarināt.Lielākā daļa no tālāk norādītajām nemainīgajām vērtībām tika tikko nokopētas no LLVM,
//
// Jebkurā gadījumā šīs struktūras visas tiek uzbūvētas līdzīgā veidā, un tas mums ir tikai nedaudz izteiksmīgs.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Ņemiet vērā, ka šeit mēs ar nolūku ignorējam vārdu sajaukšanas noteikumus: mēs nevēlamies, lai C++ varētu noķert Rust panics, vienkārši deklarējot `struct rust_panic`.
//
//
// Veicot modifikāciju, pārliecinieties, vai tipa nosaukuma virkne precīzi atbilst `compiler/rustc_codegen_llvm/src/intrinsic.rs` lietotajai.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // Šeit vadošais `\x01` baits faktiski ir maģisks signāls LLVM, lai * nepiemērotu nekādu citu manglingu, piemēram, prefiksu ar `_` rakstzīmi.
    //
    //
    // Šis simbols ir redzamais, ko izmanto C++ `std::type_info`.
    // `std::type_info` tipa objektiem, tipu aprakstiem, ir norāde uz šo tabulu.
    // Uz tipu aprakstiem atsaucas iepriekš definētās C++ EH struktūras, kuras mēs konstruējam tālāk.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Šis tipa deskriptors tiek izmantots tikai tad, ja tiek izmests izņēmums.
// Noķeršanas daļu apstrādā iekšējais mēģinājums, kas ģenerē pats savu TypeDescriptor.
//
// Tas ir labi, jo MSVC izpildlaiks izmanto virknes salīdzinājumu tipa nosaukumā, lai tas atbilstu TypeDescriptors, nevis rādītāja vienādībai.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Iznīcinātājs tiek izmantots, ja C++ kods nolemj sagūstīt izņēmumu un nomet to bez pavairošanas.
// Izmēģinājuma iekšējā uztveršanas daļa izņēmuma objekta pirmajam vārdam iestatīs 0, lai iznīcinātājs to izlaistu.
//
// Ņemiet vērā, ka x86 Windows izmanto "thiscall" izsaukuma konvenciju C++ dalībnieka funkcijām, nevis noklusējuma "C" izsaukšanas konvenciju.
//
// Funkcija išskirt_kopija šeit ir nedaudz īpaša: to izsauc MSVC izpildlaiks ar try/catch bloku, un šeit ģenerētais panic tiks izmantots kā izņēmuma kopijas rezultāts.
//
// C ++ izpildlaika to izmanto, lai atbalstītu izņēmumu tveršanu ar std::exception_ptr, ko mēs nevaram atbalstīt, jo Box<dyn Any>nav klonējams.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException pilnībā izpilda šo kaudzes rāmi, tāpēc nav nepieciešams citādi pārsūtīt `data` uz kaudzi.
    // Mēs vienkārši nododam kaudzes rādītāju šai funkcijai.
    //
    // ManuallyDrop ir vajadzīgs šeit, jo mēs nevēlamies, lai, izvelkot, izņēmums tiek izmests.
    // Tā vietā to atcels izņēmuma_tīrīšana, kuru izsauc izpildlaiks C++ .
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Tas ... var šķist pārsteidzoši un pamatoti.32 bitu MSVC rādītāji starp šīm struktūrām ir tieši tādi, rādītāji.
    // Tomēr 64 bitu MSVC rādītāji starp struktūrām drīzāk tiek izteikti kā 32 bitu nobīdes no `__ImageBase`.
    //
    // Līdz ar to 32 bitu MSVC mēs visus šos rādītājus varam deklarēt iepriekš norādītajos statiskajos punktos.
    // Izmantojot 64 bitu MSVC, mums statikā būtu jāizsaka rādītāju atņemšana, ko Rust pašlaik neatļauj, tāpēc mēs to faktiski nevaram izdarīt.
    //
    // Nākamā labākā lieta ir izpildes laikā aizpildīt šīs struktūras (panika jau tāpat ir "slow path").
    // Tātad šeit mēs visus šos rādītāju laukus atkārtoti interpretējam kā 32 bitu veselus skaitļus un pēc tam tajā saglabājam attiecīgo vērtību (atomiski, jo vienlaikus var notikt panics).
    //
    // Tehniski izpildlaiks, iespējams, neanatomiski nolasīs šos laukus, taču teorētiski viņi nekad nelasa *nepareizo* vērtību, tāpēc tam nevajadzētu būt par sliktu ...
    //
    // Jebkurā gadījumā mums principā ir jādara kaut kas līdzīgs šim, līdz mēs varam izteikt vairāk operāciju statikā (un mēs, iespējams, nekad nespēsim).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // NULL lietderīgā slodze šeit nozīmē, ka mēs šeit nokļuvām no __rust_try nozvejas (...).
    // Tas notiek, ja tiek noķerts ārzemju izņēmums, kas nav Rust.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Kompilatoram ir nepieciešams, lai tas eksistētu (piemēram, tas ir lang vienums), taču kompilators to nekad nav izsaucis, jo __C_specific_handler vai_except_handler3 ir personības funkcija, kas vienmēr tiek izmantota.
//
// Tādējādi tas ir tikai aborts, kas pārtrauc darbību.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}