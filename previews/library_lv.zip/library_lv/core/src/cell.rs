//! Dalāmi maināmi konteineri.
//!
//! Rust atmiņas drošība ir balstīta uz šo noteikumu: ņemot vērā objektu `T`, ir iespējams tikai viens no šiem:
//!
//! - Ir vairākas nemainīgas (`&T`) atsauces uz objektu (pazīstams arī kā **aliasing**).
//! - Ir viena maināma atsauce (`&mut T`) uz objektu (pazīstama arī kā **mutabilitāte**).
//!
//! To izpilda kompilators Rust.Tomēr ir situācijas, kad šis noteikums nav pietiekami elastīgs.Dažreiz tiek prasīts, lai uz objektu būtu vairākas atsauces, taču tas tomēr ir mutēts.
//!
//! Pastāv koplietojami maināmie konteineri, kas ļauj kontrolēti mainīt maināmību pat pseidonīmi.Gan [`Cell<T>`], gan [`RefCell<T>`] ļauj to izdarīt ar vienu pavedienu.
//! Tomēr ne `Cell<T>`, ne `RefCell<T>` nav drošas ar vītni (tās neievieš [`Sync`]).
//! Ja jums ir jāveic pseidonīmi un mutācijas starp vairākiem pavedieniem, ir iespējams izmantot [`Mutex<T>`], [`RwLock<T>`] vai [`atomic`] veidus.
//!
//! `Cell<T>` un `RefCell<T>` tipu vērtības var mutēt, izmantojot kopīgas atsauces (ti
//! `&T` tipu), turpretim lielāko daļu Rust tipu var mutēt tikai ar unikālām (`&mut T`) atsaucēm.
//! Mēs sakām, ka `Cell<T>` un `RefCell<T>` nodrošina `iekšējo mainīgumu`, atšķirībā no tipiskajiem Rust tipiem, kuriem piemīt `iedzimta mutabilitāte`.
//!
//! Šūnu tipiem ir divas garšas: `Cell<T>` un `RefCell<T>`.`Cell<T>` īsteno salona mainīgumu, pārvietojot vērtības iekšā un ārpus `Cell<T>`.
//! Lai vērtību vietā izmantotu atsauces, jāizmanto `RefCell<T>` tips, pirms mutācijas iegūšanas jāiegūst rakstīšanas atslēga.`Cell<T>` piedāvā metodes, kā iegūt un mainīt pašreizējo interjera vērtību:
//!
//!  - Tiem tipiem, kas ievieš [`Copy`], metode [`get`](Cell::get) izgūst pašreizējo interjera vērtību.
//!  - Tiem tipiem, kas ievieš [`Default`], [`take`](Cell::take) metode pašreizējo interjera vērtību aizstāj ar [`Default::default()`] un atgriež aizstāto vērtību.
//!  - Visiem veidiem [`replace`](Cell::replace) metode aizstāj pašreizējo interjera vērtību un atgriež aizstāto vērtību, un [`into_inner`](Cell::into_inner) metode patērē `Cell<T>` un atgriež interjera vērtību.
//!  Turklāt [`set`](Cell::set) metode aizstāj interjera vērtību, nomest aizstāto vērtību.
//!
//! `RefCell<T>` izmanto Rust dzīves laiku, lai īstenotu `dinamisku aizņēmumu`-procesu, kurā var pieprasīt pagaidu, ekskluzīvu, mainīgu piekļuvi iekšējai vērtībai.
//! Aizņemas `RefCell<T>Atšķirībā no Rust vietējiem atsauces tipiem, kas tiek pilnībā izsekoti statiski, kompilēšanas laikā tiek izsekoti s.
//! Tā kā `RefCell<T>` aizņēmumi ir dinamiski, ir iespējams mēģināt aizņemties vērtību, kas jau ir savstarpēji aizņemta;kad tas notiek, rodas pavediens panic.
//!
//! # Kad izvēlēties interjera mainīgumu
//!
//! Visizplatītākā iedzimtā mutabilitāte, kur vērtības mutācijai ir jābūt unikālai piekļuvei, ir viens no galvenajiem valodas elementiem, kas ļauj Rust spēcīgi pamatot rādītāju aizstājēju, statiski novēršot avārijas kļūdas.
//! Tāpēc priekšroka tiek dota iedzimtai mutabilitātei, un iekšējā mutabilitāte ir kaut kas pēdējais.
//! Tā kā šūnu tipi ļauj mutēt tur, kur tā citādi netiktu atļauta, ir gadījumi, kad iekšējā mutabilitāte varētu būt piemērota vai pat *jāizmanto*, piemēram,
//!
//! * Iepazīstinām ar maināmu maināmību 'inside'
//! * Loģiski nemainīgu metožu ieviešanas informācija.
//! * [`Clone`] ieviešanas mutācija.
//!
//! ## Iepazīstinām ar maināmu maināmību 'inside'
//!
//! Daudzi kopīgi viedo rādītāju veidi, tostarp [`Rc<T>`] un [`Arc<T>`], nodrošina konteinerus, kurus var klonēt un koplietot starp vairākām pusēm.
//! Tā kā ietvertās vērtības var būt pavairotas, tās var aizņemties tikai ar `&`, nevis ar `&mut`.
//! Bez šūnām vispār nebūtu iespējams mutēt datus šo viedo norāžu iekšienē.
//!
//! Tad ir ļoti izplatīts ievietot `RefCell<T>` koplietojamo rādītāju tipos, lai atjaunotu mainīgumu:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Izveidojiet jaunu bloku, lai ierobežotu dinamiskā aizņēmuma apjomu
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Ņemiet vērā, ka, ja mēs nebūtu ļāvuši kešatmiņas iepriekšējam aizņēmumam izkrist no darbības jomas, tad nākamais aizņēmums izraisītu dinamisku pavedienu panic.
//!     //
//!     // Tas ir galvenais `RefCell` lietošanas risks.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Ņemiet vērā, ka šajā piemērā tiek izmantota `Rc<T>`, nevis `Arc<T>`.`RefCell<T>s ir paredzēti viena pavediena scenārijiem.Apsveriet iespēju izmantot [`RwLock<T>`] vai [`Mutex<T>`], ja jums ir nepieciešama kopīga mainīgums vairāku pavedienu situācijā.
//!
//! ## Loģiski nemainīgu metožu ieviešanas informācija
//!
//! Dažreiz var būt vēlams API neatklāt, ka "under the hood" notiek mutācija.
//! Tas var būt tāpēc, ka loģiski operācija nav maināma, bet, piemēram, kešatmiņa piespiež ieviešanu veikt mutāciju;vai tāpēc, ka jums ir jāizmanto mutācija, lai ieviestu trait metodi, kas sākotnēji tika definēta, lai ņemtu `&self`.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Šeit iet dārga aprēķins
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## `Clone` ieviešanas mutācija
//!
//! Šis ir vienkārši īpašs, bet bieži sastopams gadījums iepriekšējam: maināmības slēpšana darbībām, kuras šķiet nemainīgas.
//! Paredzams, ka metode [`clone`](Clone::clone) nemainīs avota vērtību, un tiek deklarēts, ka tā izmanto `&self`, nevis `&mut self`.
//! Tāpēc jebkurai mutācijai, kas notiek `clone` metodē, jāizmanto šūnu tipi.
//! Piemēram, [`Rc<T>`] saglabā atsauces skaitu `Cell<T>`.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// Maināma atmiņas vieta.
///
/// # Examples
///
/// Šajā piemērā varat redzēt, ka `Cell<T>` ļauj mutēt nemainīgā struktūrā.
/// Citiem vārdiem sakot, tas ļauj "interior mutability".
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // KĻŪDA: `my_struct` nav maināms
/// // my_struct.regular_field =new_value;
///
/// // DARBI: lai gan `my_struct` nav maināms, `special_field` ir `Cell`,
/// // ko vienmēr var mutēt
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Lai uzzinātu vairāk, skatiet [module-level documentation](self).
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// Izveido `Cell<T>` ar X vērtību X.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Izveido jaunu `Cell`, kas satur norādīto vērtību.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Iestata ierobežoto vērtību.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Apmaina divu šūnu vērtības.
    /// Atšķirība no `std::mem::swap` ir tā, ka šai funkcijai nav nepieciešama atsauce uz `&mut`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // DROŠĪBA: Tas var būt riskants, ja to izsauc no atsevišķiem pavedieniem, bet `Cell`
        // ir `!Sync`, tāpēc tas nenotiks.
        // Tas arī nederēs nevienu norādi, jo `Cell` nodrošina, ka nekas cits netiks norādīts nevienā no šīm "Cell".
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Iekļautā vērtība tiek aizstāta ar `val` un tiek atgriezta vecā ietvertā vērtība.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // DROŠĪBA: tas var izraisīt datu sacīkstes, ja tās izsauc no atsevišķas pavediena,
        // bet `Cell` ir `!Sync`, tāpēc tas nenotiks.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Atsauc vērtību.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Atgriež ietvertās vērtības kopiju.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // DROŠĪBA: tas var izraisīt datu sacīkstes, ja tās izsauc no atsevišķas pavediena,
        // bet `Cell` ir `!Sync`, tāpēc tas nenotiks.
        unsafe { *self.value.get() }
    }

    /// Izmantojot funkciju, tiek atjaunināta ietvertā vērtība un tiek atgriezta jaunā vērtība.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Atgriež neapstrādātu rādītāju pamatā esošajiem datiem šajā šūnā.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Atgriež maināmu atsauci uz pamatā esošajiem datiem.
    ///
    /// Šis zvans aizņemas `Cell` mainīgi (sastādīšanas laikā), kas garantē, ka mums ir vienīgā atsauce.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Atgriež `&Cell<T>` no `&mut T`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // DROŠĪBA: `&mut` nodrošina unikālu piekļuvi.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Tiek ņemta šūnas vērtība, atstājot vietā `Default::default()`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// Atgriež `&[Cell<T>]` no `&Cell<[T]>`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // DROŠĪBA: `Cell<T>` ir tāds pats atmiņas izkārtojums kā `T`.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Maināma atmiņas vieta ar dinamiski pārbaudītām aizņemšanās kārtulām
///
/// Lai uzzinātu vairāk, skatiet [module-level documentation](self).
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// [`RefCell::try_borrow`] atgriezta kļūda.
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// [`RefCell::try_borrow_mut`] atgriezta kļūda.
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Pozitīvās vērtības norāda aktīvo `Ref` skaitu.Negatīvās vērtības apzīmē aktīvā `RefMut` skaitu.
// Vairāki `RefMut` vienlaikus var būt aktīvi tikai tad, ja tie attiecas uz atšķirīgiem, nepārklājamiem `RefCell` komponentiem (piemēram, dažādiem šķēles diapazoniem).
//
// `Ref` un `RefMut` ir abi vārdi pēc izmēra, un tāpēc, iespējams, nekad nebūs pietiekami daudz `Ref`s vai`RefMut`, lai pārpildītu pusi no `usize` diapazona.
// Tādējādi `BorrowFlag`, iespējams, nekad nepārsniegs un nepietiks.
// Tomēr tas nav garantija, jo patoloģiska programma varētu atkārtoti izveidot un pēc tam mem::forget `Ref`s vai`RefMut`s.
// Tādējādi visam kodam ir skaidri jāpārbauda pārplūde un nepietiekama plūsma, lai izvairītos no nedrošības, vai vismaz pareizi jārīkojas, ja notiek pārplūde vai nepietiekama plūsma (piemēram, skatiet BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// Izveido jaunu `RefCell`, kas satur `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// Patērē `RefCell`, atgriežot iesaiņoto vērtību.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Tā kā šī funkcija pēc vērtības ņem `self` (`RefCell`), kompilators statiski pārbauda, vai tā pašlaik nav aizņemta.
        //
        self.value.into_inner()
    }

    /// Iesaiņoto vērtību aizstāj ar jaunu, atgriežot veco vērtību, nevienu no tām neinicializējot.
    ///
    ///
    /// Šī funkcija atbilst [`std::mem::replace`](../mem/fn.replace.html).
    ///
    /// # Panics
    ///
    /// Panics, ja vērtība pašlaik ir aizņemta.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Iesaiņoto vērtību aizstāj ar jaunu, kas aprēķināta no `f`, atgriežot veco vērtību, nevienu no tām neinicializējot.
    ///
    ///
    /// # Panics
    ///
    /// Panics, ja vērtība pašlaik ir aizņemta.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Apmaina `self` iesaiņoto vērtību ar `other` ietīto vērtību, nevienu no tām neinicializējot.
    ///
    ///
    /// Šī funkcija atbilst [`std::mem::swap`](../mem/fn.swap.html).
    ///
    /// # Panics
    ///
    /// Panics, ja vērtība vienā no `RefCell` pašlaik ir aizņemta.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Neaizmirstami aizņemas iesaiņoto vērtību.
    ///
    /// Aizņēmums ilgst līdz brīdim, kad atgrieztais `Ref` iziet no darbības sfēras.
    /// Vienlaikus var izņemt vairākus nemainīgus aizņēmumus.
    ///
    /// # Panics
    ///
    /// Panics, ja vērtība pašlaik ir savstarpēji aizgūta.
    /// Bez panikas varianta izmantojiet [`try_borrow`](#method.try_borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// panic piemērs:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Neaizmirstami aizņemas iesaiņoto vērtību, atgriežot kļūdu, ja vērtība pašlaik ir aizņēmusies.
    ///
    ///
    /// Aizņēmums ilgst līdz brīdim, kad atgrieztais `Ref` iziet no darbības sfēras.
    /// Vienlaikus var izņemt vairākus nemainīgus aizņēmumus.
    ///
    /// Šis ir [`borrow`](#method.borrow) panikas variants.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // DROŠĪBA: `BorrowRef` nodrošina tikai nemainīgu piekļuvi
            // līdz vērtībai aizņemoties.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Mainīgi aizņemas iesaiņoto vērtību.
    ///
    /// Aizņēmums ilgst līdz brīdim, kad atgrieztais `RefMut` vai visi no tā izrietošie `RefMut` iziet no darbības jomas.
    ///
    /// Vērtību nevar aizņemties, kamēr šis aizņēmums ir aktīvs.
    ///
    /// # Panics
    ///
    /// Panics, ja vērtība pašlaik ir aizņemta.
    /// Bez panikas varianta izmantojiet [`try_borrow_mut`](#method.try_borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// panic piemērs:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Maināmi aizņemas iesaiņoto vērtību, atgriežot kļūdu, ja vērtība pašlaik ir aizņemta.
    ///
    ///
    /// Aizņēmums ilgst līdz brīdim, kad atgrieztais `RefMut` vai visi no tā izrietošie `RefMut` iziet no darbības jomas.
    /// Vērtību nevar aizņemties, kamēr šis aizņēmums ir aktīvs.
    ///
    /// Šis ir [`borrow_mut`](#method.borrow_mut) panikas variants.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // DROŠĪBA: `BorrowRef` garantē unikālu piekļuvi.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Atgriež neapstrādātu rādītāju pamatā esošajiem datiem šajā šūnā.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Atgriež maināmu atsauci uz pamatā esošajiem datiem.
    ///
    /// Šis zvans aizņemas `RefCell` mainīgi (sastādīšanas laikā), tāpēc nav nepieciešamas dinamiskas pārbaudes.
    ///
    /// Tomēr esiet piesardzīgs: šī metode paredz, ka `self` ir maināms, kas parasti nenotiek, lietojot `RefCell`.
    ///
    /// Apskatiet [`borrow_mut`] metodi, ja `self` nav maināms.
    ///
    /// Lūdzu, ņemiet vērā, ka šī metode ir paredzēta tikai īpašiem apstākļiem un parasti nav tā, ko vēlaties.
    /// Šaubu gadījumā tā vietā izmantojiet [`borrow_mut`].
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Atsauciet noplūdušo aizsargu ietekmi uz `RefCell` aizņemšanās stāvokli.
    ///
    /// Šis zvans ir līdzīgs [`get_mut`], bet ir specializētāks.
    /// Tas aizņemas `RefCell` mainīgi, lai nodrošinātu, ka nav aizņēmumu, un pēc tam atiestata kopīgo aizņēmumu izsekošanas stāvokli.
    /// Tas ir svarīgi, ja ir noplūduši daži `Ref` vai `RefMut` aizņēmumi.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Neaizmirstami aizņemas iesaiņoto vērtību, atgriežot kļūdu, ja vērtība pašlaik ir aizņēmusies.
    ///
    /// # Safety
    ///
    /// Atšķirībā no `RefCell::borrow`, šī metode ir nedroša, jo tā neatdod `Ref`, tādējādi aizņēmuma karodziņš paliek neskarts.
    /// `RefCell` aizdošana, kamēr šīs metodes atgrieztā atsauce ir dzīva, nav noteikta rīcība.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // DROŠĪBA: Mēs pārbaudām, vai tagad neviens aktīvi neraksta, bet tā ir
            // zvanītāja atbildība nodrošināt, lai neviens nerakstītu, kamēr atgrieztā atsauce vairs netiek izmantota.
            // Tāpat `self.value.get()` attiecas uz vērtību, kas pieder `self`, un tādējādi tiek garantēta, ka tā būs derīga `self` darbības laikā.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// Ņem iesaiņoto vērtību, atstājot vietā `Default::default()`.
    ///
    /// # Panics
    ///
    /// Panics, ja vērtība pašlaik ir aizņemta.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics, ja vērtība pašlaik ir savstarpēji aizgūta.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// Izveido `RefCell<T>` ar X vērtību X.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics, ja vērtība vienā no `RefCell` pašlaik ir aizņemta.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics, ja vērtība vienā no `RefCell` pašlaik ir aizņemta.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics, ja vērtība vienā no `RefCell` pašlaik ir aizņemta.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics, ja vērtība vienā no `RefCell` pašlaik ir aizņemta.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics, ja vērtība vienā no `RefCell` pašlaik ir aizņemta.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics, ja vērtība vienā no `RefCell` pašlaik ir aizņemta.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics, ja vērtība vienā no `RefCell` pašlaik ir aizņemta.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Aizdevuma palielināšana var radīt vērtību, kas nav nolasāma (<=0) šādos gadījumos:
            // 1. Tas bija <0, ti, ir aizņēmumi, kas saistīti ar rakstīšanu, tāpēc mēs nevaram atļaut lasīt aizņemšanos, pateicoties Rust atsauces aizstājējnoteikumiem
            // 2.
            // Tas bija isize::MAX (maksimālais lasāmo aizņēmumu apjoms), un tas pārpildījās isize::MIN (maksimālais aizņēmumu rakstīšanas apjoms), tāpēc mēs nevaram atļaut papildu lasāmo aizņēmumu, jo isize nevar pārstāvēt tik daudz lasīto aizņēmumu (tas var notikt tikai tad, ja jūs mem::forget vairāk nekā nelielu nemainīgu daudzumu Ref, kas nav laba prakse)
            //
            //
            //
            //
            None
        } else {
            // Aizdevuma palielināšana var radīt nolasīšanas vērtību (> 0) šādos gadījumos:
            // 1. Tas bija=0, ti, tas nebija aizņemts, un mēs ņemam pirmo lasīto aizņēmumu
            // 2. Tas bija> 0 un <isize::MAX, ti
            // bija lasītie aizņēmumi, un isize ir pietiekami liela, lai parādītu, ka ir vēl viens lasīts aizņēmums
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Tā kā šī atsauce pastāv, mēs zinām, ka aizņēmuma karogs ir lasāms aizņēmums.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Novērsiet aizņēmuma skaitītāja pārpildīšanu rakstiskā aizņēmumā.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// `RefCell` lodziņā ietin aizņemto atsauci uz vērtību.
/// Iesaiņojuma veids nemainīgi aizņemtai vērtībai no `RefCell<T>`.
///
/// Lai uzzinātu vairāk, skatiet [module-level documentation](self).
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Kopē `Ref`.
    ///
    /// `RefCell` jau ir nemainīgi aizņemts, tāpēc tas nevar neizdoties.
    ///
    /// Šī ir saistītā funkcija, kas jāizmanto kā `Ref::clone(...)`.
    /// `Clone` ieviešana vai metode traucētu `r.borrow().clone()` plaši izmantot `RefCell` satura klonēšanai.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Izgatavo jaunu `Ref` aizņemto datu komponentam.
    ///
    /// `RefCell` jau ir nemainīgi aizņemts, tāpēc tas nevar neizdoties.
    ///
    /// Šī ir saistītā funkcija, kas jāizmanto kā `Ref::map(...)`.
    /// Metode traucētu tāda paša nosaukuma metodēm `RefCell` saturā, ko izmanto caur `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Izgatavo jaunu `Ref` aizņemto datu izvēles komponentam.
    /// Sākotnējais aizsargs tiek atgriezts kā `Err(..)`, ja aizvēršana atgriež `None`.
    ///
    /// `RefCell` jau ir nemainīgi aizņemts, tāpēc tas nevar neizdoties.
    ///
    /// Šī ir saistītā funkcija, kas jāizmanto kā `Ref::filter_map(...)`.
    /// Metode traucētu tāda paša nosaukuma metodēm `RefCell` saturā, ko izmanto caur `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Sadaliet `Ref` vairākos `Ref` dažādos aizņemto datu komponentos.
    ///
    /// `RefCell` jau ir nemainīgi aizņemts, tāpēc tas nevar neizdoties.
    ///
    /// Šī ir saistītā funkcija, kas jāizmanto kā `Ref::map_split(...)`.
    /// Metode traucētu tāda paša nosaukuma metodēm `RefCell` saturā, ko izmanto caur `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Pārvērst par atsauci uz pamatā esošajiem datiem.
    ///
    /// Pakārtoto `RefCell` vairs nevar aizņemties no jauna, un tas vienmēr parādīsies jau nemainīgi aizņemts.
    ///
    /// Nav laba ideja nopludināt vairāk nekā nemainīgu atsauču skaitu.
    /// `RefCell` var nemainīgi aizņemties vēlreiz, ja kopumā ir noticis tikai mazāks noplūdes gadījumu skaits.
    ///
    /// Šī ir saistītā funkcija, kas jāizmanto kā `Ref::leak(...)`.
    /// Metode traucētu tāda paša nosaukuma metodēm `RefCell` saturā, ko izmanto caur `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // Aizmirstot šo atsauci, mēs nodrošinām, ka RefCell aizņemšanās skaitītājs `'b` dzīves laikā nevar atgriezties pie NELIETOTS.
        // Atsauces atskaites stāvokļa atiestatīšanai būtu nepieciešama unikāla atsauce uz aizņemto RefCell.
        // Sākotnējā šūnā vairs nevar izveidot citas maināmas atsauces.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Izgatavo jaunu `RefMut` aizņemto datu komponentam, piemēram, uzskaites variantam.
    ///
    /// `RefCell` jau ir savstarpēji aizņēmies, tāpēc tas nevar neizdoties.
    ///
    /// Šī ir saistītā funkcija, kas jāizmanto kā `RefMut::map(...)`.
    /// Metode traucētu tāda paša nosaukuma metodēm `RefCell` saturā, ko izmanto caur `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): noteikt aizņēmuma čeku
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Izgatavo jaunu `RefMut` aizņemto datu izvēles komponentam.
    /// Sākotnējais aizsargs tiek atgriezts kā `Err(..)`, ja aizvēršana atgriež `None`.
    ///
    /// `RefCell` jau ir savstarpēji aizņēmies, tāpēc tas nevar neizdoties.
    ///
    /// Šī ir saistītā funkcija, kas jāizmanto kā `RefMut::filter_map(...)`.
    /// Metode traucētu tāda paša nosaukuma metodēm `RefCell` saturā, ko izmanto caur `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): noteikt aizņēmuma čeku
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // DROŠĪBA: funkcija ilgst ekskluzīvu atsauci
        // zvana, izmantojot `orig`, un rādītājs ir atsaukts tikai funkcijas izsaukuma iekšpusē, nekad neļaujot iziet ekskluzīvajai atsaucei.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // DROŠĪBA: tāda pati kā iepriekš.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Sadaliet `RefMut` vairākos "RefMut" dažādos aizņemto datu komponentos.
    ///
    /// Bāzes `RefCell` paliks savstarpēji aizņemts, līdz abi atgrieztie RefMut būs ārpus darbības jomas.
    ///
    /// `RefCell` jau ir savstarpēji aizņēmies, tāpēc tas nevar neizdoties.
    ///
    /// Šī ir saistītā funkcija, kas jāizmanto kā `RefMut::map_split(...)`.
    /// Metode traucētu tāda paša nosaukuma metodēm `RefCell` saturā, ko izmanto caur `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Pārvērst par maināmu atsauci uz pamatā esošajiem datiem.
    ///
    /// Bāzes `RefCell` nevar aizņemties no jauna, un tas vienmēr parādīsies jau savstarpēji aizdots, padarot atgriezto atsauci vienīgo uz interjeru.
    ///
    ///
    /// Šī ir saistītā funkcija, kas jāizmanto kā `RefMut::leak(...)`.
    /// Metode traucētu tāda paša nosaukuma metodēm `RefCell` saturā, ko izmanto caur `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Aizmirstot šo BorrowRefMut, mēs nodrošinām, ka RefCell aizņemšanās skaitītājs `'b` dzīves laikā nevar atgriezties pie NELIETOTS.
        // Atsauces atskaites stāvokļa atiestatīšanai būtu nepieciešama unikāla atsauce uz aizņemto RefCell.
        // Šajā dzīves laikā no sākotnējās šūnas nevar izveidot citas atsauces, padarot pašreizējo aizņēmumu par vienīgo atsauci uz atlikušo dzīves laiku.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: Atšķirībā no BorrowRefMut::clone, lai izveidotu sākotnējo, tiek izsaukts jauns
        // maināma atsauce, un tāpēc pašlaik nedrīkst būt atsauces.
        // Tādējādi, lai gan klons palielina mainīgo pārrēķinu, šeit mēs skaidri atļaujamies pāriet tikai no NELIETOTA uz NELIETOTU.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // Klonē a `BorrowRefMut`.
    //
    // Tas ir derīgs tikai tad, ja katrs `BorrowRefMut` tiek izmantots, lai izsekotu maināmu atsauci uz oriģinālā objekta atšķirīgu, nepārklājamu diapazonu.
    //
    // Tas nav klona implikā, tāpēc kods to netieši nenosauc.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Novērsiet aizņēmumu skaitītāja nepietiekamu plūsmu.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// Iesaiņojuma veids mainīgi aizņemtai vērtībai no `RefCell<T>`.
///
/// Lai uzzinātu vairāk, skatiet [module-level documentation](self).
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Rust iekšējais mainīgums ir primitīvs.
///
/// Ja jums ir atsauce `&T`, tad Rust parasti kompilators veic optimizāciju, pamatojoties uz zināšanām, ka `&T` norāda uz nemaināmiem datiem.Šo datu mutēšana, piemēram, izmantojot aizstājvārdu vai pārveidojot `&T` par `&mut T`, tiek uzskatīta par nedefinētu rīcību.
/// `UnsafeCell<T>` izvēlas nemaināmības garantiju `&T`: koplietojama atsauce `&UnsafeCell<T>` var norādīt uz datiem, kas tiek mutēti.To sauc par "interior mutability".
///
/// Visi citi veidi, kas pieļauj iekšējo mainīgumu, piemēram, `Cell<T>` un `RefCell<T>`, iekšēji izmanto `UnsafeCell`, lai aplaupītu savus datus.
///
/// Ņemiet vērā, ka `UnsafeCell` ietekmē tikai nemaināmības garantiju koplietojamām atsaucēm.Mainīgo atsauču unikalitātes garantija netiek ietekmēta.Nav * likumīga veida, kā iegūt pseidonīmu `&mut`, pat ar `UnsafeCell<T>`.
///
/// Pati `UnsafeCell` API ir tehniski ļoti vienkārša: [`.get()`] sniedz jums neapstrādātu rādītāju `*mut T` tā saturam.Pareizi izmantot šo neapstrādāto rādītāju ir abstrakcijas dizainera ziņā _you_.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// Precīzie Rust aizstājējnoteikumi nedaudz mainās, taču galvenie punkti nav strīdīgi:
///
/// - Ja izveidojat drošu atsauci ar kalpošanas laiku `'a` (vai nu `&T`, vai `&mut T` atsauci), kurai var piekļūt, izmantojot drošu kodu (piemēram, tāpēc, ka esat to atgriezis), tad datiem nedrīkst piekļūt nekādā veidā, kas atlikušajā laikā ir pretrunā ar šo atsauci no `'a`.
/// Piemēram, tas nozīmē, ka, ja `*mut T` ņemat no `UnsafeCell<T>` un apmetat uz `&T`, tad `T` esošajiem datiem jāpaliek nemainīgiem (protams, modulējiet visus `UnsafeCell` datus, kas atrodami `T`, protams), līdz beidzas šīs atsauces kalpošanas laiks.
/// Līdzīgi, ja izveidojat `&mut T` atsauci, kas tiek izlaista drošajam kodam, jums nav jāpiekļūst datiem `UnsafeCell`, kamēr šīs atsauces derīguma termiņš nav beidzies.
///
/// - Jums vienmēr jāizvairās no datu sacīkstēm.Ja vairākiem pavedieniem ir piekļuve vienam un tam pašam `UnsafeCell`, tad jebkuram rakstam ir jābūt pareizam atgadījumam pirms visām pārējām piekļuvēm (vai arī jāizmanto atomi).
///
/// Lai veicinātu pareizu noformēšanu, vienvītņotam kodam ir skaidri pasludināti šādi scenāriji:
///
/// 1. `&T` atsauci var atbrīvot drošajā kodā, un tur tā var pastāvēt kopā ar citām `&T` atsaucēm, bet ne ar `&mut T`
///
/// 2. `&mut T` atsauci var atbrīvot uz drošu kodu, ja ar to nepastāv ne cits `&mut T`, ne `&T`.`&mut T` vienmēr jābūt unikālam.
///
/// Ņemiet vērā, ka, lai gan `&UnsafeCell<T>` satura mutācija (pat ja citas `&UnsafeCell<T>` atsauces aizstājvārds ir šūna) ir kārtībā (ja iepriekšminētos invariantus īstenojat citādi), tomēr vairākiem `&mut UnsafeCell<T>` aizstājvārdiem nav noteikta rīcība.
/// Tas ir, `UnsafeCell` ir iesaiņotājs, kas paredzēts īpašai mijiedarbībai ar _shared_ accesses (_i.e._, izmantojot `&UnsafeCell<_>` atsauci);darījumos ar _exclusive_ accesses (_e.g._ caur `&mut UnsafeCell<_>` nav nekādas burvju): ne šūna, ne iesaiņotā vērtība nedrīkst būt pseidonīmi šīs `&mut` aizņemšanās laikā.
///
/// To parāda [`.get_mut()`] piekļuvējs, kas ir _safe_ getter, kas dod `&mut T`.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Šeit ir piemērs, kurā parādīts, kā pareizi pārveidot `UnsafeCell<_>` saturu, neskatoties uz to, ka šūnā tiek aizstātas vairākas atsauces:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Iegūstiet vairākas/vienlaicīgas/kopīgas atsauces uz to pašu `x`.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // DROŠĪBA: šajā jomā nav citu atsauču uz `x` saturu,
///     // tātad mūsējais ir faktiski unikāls.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- aizņemties-+
///     *p1_exclusive += 27; // |
/// } // <---------- nevar pārsniegt šo punktu -------------------+
///
/// unsafe {
///     // DROŠĪBA: šajā jomā neviens necer, ka viņam būs ekskluzīva piekļuve `x` saturam,
///     // tāpēc mums vienlaikus var būt vairākas koplietojamas piekļuves.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// Šis piemērs parāda faktu, ka ekskluzīva piekļuve `UnsafeCell<T>` nozīmē ekskluzīvu piekļuvi tā `T`:
///
/// ```rust
/// #![forbid(unsafe_code)] // ar ekskluzīvām piekļuvēm,
///                         // `UnsafeCell` ir caurspīdīgs iesaiņojums bez opcijas, tāpēc šeit nav nepieciešams `unsafe`.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Iegūstiet kompilēšanas laikā pārbaudītu unikālo atsauci uz `x`.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Izmantojot ekskluzīvu atsauci, mēs varam mutēt saturu bez maksas.
/// *p_unique.get_mut() = 0;
/// // Vai līdzvērtīgi:
/// x = UnsafeCell::new(0);
///
/// // Kad mums pieder vērtība, saturu varam iegūt bez maksas.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Konstruē jaunu `UnsafeCell` gadījumu, kas ietin norādīto vērtību.
    ///
    ///
    /// Visa pieeja iekšējai vērtībai, izmantojot metodes, ir `unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Atsauc vērtību.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Iegūst maināmu rādītāju uz iesaiņoto vērtību.
    ///
    /// To var nodot jebkura veida rādītājam.
    /// Pārsūtot uz `&mut T`, pārliecinieties, vai piekļuve ir unikāla (nav aktīvu atsauču, maināma vai nē) un pārliecinieties, ka apraides laikā uz `&T` nav mutāciju vai maināmu aizstājvārdu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // #[repr(transparent)] dēļ mēs varam vienkārši nodot rādītāju no `UnsafeCell<T>` uz `T`.
        // Tas izmanto libstd īpašo statusu, lietotāja kodam nav garantijas, ka tas darbosies kompilatora future versijās!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Atgriež maināmu atsauci uz pamatā esošajiem datiem.
    ///
    /// Šis zvans aizņemas `UnsafeCell` mainīgi (sastādīšanas laikā), kas garantē, ka mums ir vienīgā atsauce.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Iegūst maināmu rādītāju uz iesaiņoto vērtību.
    /// Atšķirība no [`get`] ir tā, ka šī funkcija pieņem neapstrādātu rādītāju, kas ir noderīgi, lai izvairītos no pagaidu atsauču izveidošanas.
    ///
    /// Rezultātu var nodot jebkura veida rādītājam.
    /// Pārsūtot uz `&mut T`, pārliecinieties, vai piekļuve ir unikāla (nav aktīvu atsauču, maināma vai nē) un pārliecinieties, ka apraides laikā uz `&T` nav mutāciju vai maināmu aizstājvārdu.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// Pakāpeniska `UnsafeCell` inicializēšana prasa `raw_get`, jo, izsaucot `get`, būs jāizveido atsauce uz neinicializētiem datiem:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // #[repr(transparent)] dēļ mēs varam vienkārši nodot rādītāju no `UnsafeCell<T>` uz `T`.
        // Tas izmanto libstd īpašo statusu, lietotāja kodam nav garantijas, ka tas darbosies kompilatora future versijās!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// Izveido `UnsafeCell` ar X vērtību X.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}