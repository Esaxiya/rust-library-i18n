/// Pielāgots kods iznīcinātājā.
///
/// Kad vērtība vairs nav nepieciešama, Rust palaidīs "destructor" šai vērtībai.
/// Visizplatītākais veids, kā vērtība vairs nav vajadzīga, ir tad, kad tā iziet no darbības jomas.Iznīcinātāji joprojām var darboties citos apstākļos, taču mēs pievērsīsimies šeit sniegto piemēru tvērumam.
/// Lai uzzinātu vairāk par šiem gadījumiem, lūdzu, skatiet sadaļu [the reference] par iznīcinātājiem.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Šis iznīcinātājs sastāv no divām sastāvdaļām:
/// - Zvans uz `Drop::drop` par šo vērtību, ja šis īpašais `Drop` trait ir ieviests.
/// - Automātiski ģenerētais "drop glue", kas rekursīvi izsauc visas šīs vērtības lauku iznīcinātājus.
///
/// Tā kā Rust automātiski izsauc visu ietverto lauku iznīcinātājus, vairumā gadījumu `Drop` nav jāievieš.
/// Bet dažos gadījumos tas ir noderīgi, piemēram, tipiem, kuri tieši pārvalda resursu.
/// Šis resurss var būt atmiņa, tas var būt failu deskriptors, tas var būt tīkla ligzda.
/// Kad šāda veida vērtība vairs netiks izmantota, tai "clean up" vajadzētu būt savam resursam, atbrīvojot atmiņu vai aizverot failu vai ligzdu.
/// Tas ir destruktora darbs, tātad arī `Drop::drop` darbs.
///
/// ## Examples
///
/// Lai redzētu iznīcinātājus darbībā, apskatīsim šo programmu:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust vispirms izsauks `Drop::drop` par `_x` un pēc tam gan uz `_x.one`, gan `_x.two`, tas nozīmē, ka, palaižot to, tiks izdrukāts
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// Pat ja mēs noņemam `Drop` ieviešanu `HasTwoDrop`, tā lauku iznīcinātāji joprojām tiek saukti.
/// Tā rezultātā
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## Jūs pats nevarat piezvanīt uz `Drop::drop`
///
/// Tā kā `Drop::drop` tiek izmantots vērtības attīrīšanai, var būt bīstami izmantot šo vērtību pēc metodes izsaukšanas.
/// Tā kā `Drop::drop` neuzņemas īpašumtiesības uz savu ievadi, Rust novērš nepareizu izmantošanu, neļaujot jums tieši piezvanīt uz `Drop::drop`.
///
/// Citiem vārdiem sakot, ja mēģinājāt iepriekš minētajā piemērā skaidri izsaukt `Drop::drop`, jūs saņemsiet kompilatora kļūdu.
///
/// Ja vēlaties skaidri izsaukt vērtības iznīcinātāju, tā vietā var izmantot [`mem::drop`].
///
/// [`mem::drop`]: drop
///
/// ## Drop order
///
/// Kurš no abiem mūsu `HasDrop` pilieniem ir pirmais?Struktūrām tā ir tā pati secība, kādā viņi tiek deklarēti: vispirms `one`, pēc tam `two`.
/// Ja vēlaties to izmēģināt pats, varat modificēt `HasDrop` iepriekš, lai tajā būtu daži dati, piemēram, vesels skaitlis, un pēc tam tos izmantot `println!` iekšpusē `Drop`.
/// Šo rīcību garantē valoda.
///
/// Atšķirībā no struktūrām, vietējie mainīgie tiek nomesti apgrieztā secībā:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// Tas tiks izdrukāts
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Lūdzu, skatiet visus noteikumus [the reference].
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` un `Drop` ir ekskluzīvas
///
/// Jūs nevarat ieviest gan [`Copy`], gan `Drop` vienā un tajā pašā tipā.`Copy` tipus kompilators netieši dublē, tāpēc ir ļoti grūti paredzēt, kad un cik bieži destruktori tiks izpildīti.
///
/// Šādiem tipiem nevar būt destruktoru.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Izpilda destruktoru šim tipam.
    ///
    /// Šo metodi sauc netieši, kad vērtība iziet no darbības jomas, un to nevar skaidri izsaukt (tā ir kompilatora kļūda [E0040]).
    /// Tomēr funkciju [`mem::drop`] prelude var izmantot, lai izsauktu argumenta `Drop` ieviešanu.
    ///
    /// Kad šī metode ir izsaukta, `self` vēl nav sadalīta.
    /// Tas notiek tikai pēc tam, kad metode ir beigusies.
    /// Ja tas tā nebūtu, `self` būtu karājoša atsauce.
    ///
    /// # Panics
    ///
    /// Ņemot vērā, ka [`panic!`] izsaukšanas laikā izsauks `drop`, jebkurš [`panic!`] `drop` ieviešanā, iespējams, pārtrauks.
    ///
    /// Ņemiet vērā, ka pat tad, ja šis panics, tiek uzskatīts, ka vērtība ir samazināta;
    /// nedrīkst izraisīt `drop` atkārtotu izsaukšanu.
    /// Parasti kompilators to automātiski apstrādā, taču, izmantojot nedrošu kodu, dažreiz tas var notikt nejauši, it īpaši, lietojot [`ptr::drop_in_place`].
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}