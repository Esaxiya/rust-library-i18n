//! Pārslogoti operatori.
//!
//! Šo traits ieviešana ļauj pārslogot noteiktus operatorus.
//!
//! Dažus no šiem traits importē prelude, tāpēc tie ir pieejami katrā Rust programmā.Pārlādēt var tikai tos operatorus, kurus atbalsta traits.
//! Piemēram, pievienošanas operatoru (`+`) var pārslogot, izmantojot [`Add`] trait, taču, tā kā piešķiršanas operatoram (`=`) nav atbalsta trait, tā semantiku nav iespējams pārslogot.
//! Turklāt šis modulis neparedz mehānismu jaunu operatoru izveidei.
//! Ja ir nepieciešama bezjūtīga pārslodze vai pielāgoti operatori, jums vajadzētu meklēt makro vai kompilatora spraudņus, lai paplašinātu Rust sintaksi.
//!
//! Operatora traits ieviešanai nevajadzētu būt pārsteidzošam to attiecīgajā kontekstā, paturot prātā to parasto nozīmi un [operator precedence].
//! Piemēram, ieviešot [`Mul`], operācijai vajadzētu būt zināmai līdzībai ar reizināšanu (un kopīgot paredzamās īpašības, piemēram, asociativitāti).
//!
//! Ņemiet vērā, ka operatoriem `&&` un `||` ir īssavienojums, ti, viņi novērtē savu otro operandu tikai tad, ja tas veicina rezultātu.Tā kā traits šo rīcību nevar izpildīt, `&&` un `||` netiek atbalstīti kā pārslodzes operatori.
//!
//! Daudzi no operatoriem savus operandus vērtē pēc vērtības.Neraksturīgos kontekstos, kas saistīti ar iebūvētiem tipiem, tā parasti nav problēma.
//! Tomēr, izmantojot šos operatorus vispārējā kodā, ir jāpievērš īpaša uzmanība, ja vērtības ir jāizmanto atkārtoti, nevis ļaujot operatoriem tās patērēt.Viena iespēja ir laiku pa laikam izmantot [`clone`].
//! Vēl viena iespēja ir paļauties uz iesaistītajiem veidiem, nodrošinot papildu operatoru ieviešanu atsaucēm.
//! Piemēram, lietotāja definētam tipam `T`, kas paredzēts papildināšanai, iespējams, ir laba ideja, lai gan `T`, gan `&T` ieviestu traits [`Add<T>`][`Add`] un [`Add<&T>`][`Add`], lai vispārīgo kodu varētu rakstīt bez nevajadzīgas klonēšanas.
//!
//!
//! # Examples
//!
//! Šis piemērs izveido `Point` struktūru, kas ievieš [`Add`] un [`Sub`], un pēc tam parāda divu "punktu" saskaitīšanu un atņemšanu.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Īstenošanas piemēru skatiet katra trait dokumentācijā.
//!
//! [`Fn`], [`FnMut`] un [`FnOnce`] traits tiek ieviesti pēc tipiem, kurus var izsaukt līdzīgi funkcijām.Ņemiet vērā, ka [`Fn`] aizņem `&self`, [`FnMut`] aizņem `&mut self` un [`FnOnce`] aizņem `self`.
//! Tie atbilst trīs veidu metodēm, kuras var izmantot instancē: call-by-reference, call-by-mainable-reference un call-by-value.
//! Visizplatītākais šo traits lietojums ir darboties kā robežām augstāka līmeņa funkcijām, kuras funkcijas vai slēgumus uzskata par argumentiem.
//!
//! [`Fn`] kā parametrs:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! [`FnMut`] kā parametrs:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! [`FnOnce`] kā parametrs:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` patērē uzņemtos mainīgos, tāpēc to nevar palaist vairāk nekā vienu reizi
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Mēģinot vēlreiz izsaukt `func()`, `func` radīsies `use of moved value` kļūda
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` šajā brīdī vairs nevar atsaukties
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;