/// Zvana operatora versija, kas aizņem nemainīgu uztvērēju.
///
/// `Fn` gadījumus var atkārtoti izsaukt, nemutējot stāvokli.
///
/// *Šis trait (`Fn`) nav sajaucams ar [function pointers] (`fn`).*
///
/// `Fn` tiek automātiski ieviests ar slēgšanu, kurā tiek izmantotas tikai nemainīgas atsauces uz notvertajiem mainīgajiem vai vispār nekas netiek uztverts, kā arī (safe) [function pointers] (ar dažiem iebildumiem sīkāku informāciju skatiet to dokumentācijā).
///
/// Turklāt jebkuram `F` tipam, kas ievieš `Fn`, `&F` arī `Fn`.
///
/// Tā kā gan [`FnMut`], gan [`FnOnce`] ir `Fn` supertrakti, jebkuru parametru `Fn` var izmantot kā parametru, kur ir paredzēts [`FnMut`] vai [`FnOnce`].
///
/// Izmantojiet `Fn` kā saistījumu, ja vēlaties pieņemt funkcijai līdzīgu parametru un jums tas jāizsauc atkārtoti un bez mutācijas stāvokļa (piemēram, vienlaikus izsaucot).
/// Ja jums nav nepieciešamas tik stingras prasības, kā robežas izmantojiet [`FnMut`] vai [`FnOnce`].
///
/// Plašāku informāciju par šo tēmu skatiet [chapter on closures in *The Rust Programming Language*][book].
///
/// Jāatzīmē arī īpašā sintakse `Fn` traits (piem.,
/// `Fn(usize, bool) -> izmantot`).Tie, kurus interesē tehniskā informācija, var atsaukties uz [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Zvanīšana par slēgšanu
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## `Fn` parametra izmantošana
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // lai regex varētu paļauties uz šo `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Veic zvana darbību.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Zvana operatora versija, kas aizņem maināmu uztvērēju.
///
/// `FnMut` gadījumus var izsaukt atkārtoti, un tie var mainīt stāvokli.
///
/// `FnMut` tiek automātiski ieviests ar slēgšanu, kurā tiek izmantotas mainīgas atsauces uz notvertajiem mainīgajiem, kā arī visiem tipiem, kas ievieš [`Fn`], piemēram, (safe) [function pointers] (jo `FnMut` ir [`Fn`] supertraits).
/// Turklāt jebkuram `F` tipam, kas ievieš `FnMut`, `&mut F` arī `FnMut`.
///
/// Tā kā [`FnOnce`] ir `FnMut` supertraits, jebkurus `FnMut` gadījumus var izmantot tur, kur gaidāms [`FnOnce`], un, tā kā [`Fn`] ir `FnMut` apakštips, var izmantot jebkuru [`Fn`] gadījumu, kur gaidāms `FnMut`.
///
/// Izmantojiet `FnMut` kā saistījumu, ja vēlaties pieņemt funkcijai līdzīgu parametru un nepieciešams to izsaukt atkārtoti, vienlaikus ļaujot tam mutēt stāvokli.
/// Ja jūs nevēlaties, lai parametrs mainītu stāvokli, kā saistījumu izmantojiet [`Fn`];ja jums nav nepieciešams to atkārtoti izsaukt, izmantojiet [`FnOnce`].
///
/// Plašāku informāciju par šo tēmu skatiet [chapter on closures in *The Rust Programming Language*][book].
///
/// Jāatzīmē arī īpašā sintakse `Fn` traits (piem.,
/// `Fn(usize, bool) -> izmantot`).Tie, kurus interesē tehniskā informācija, var atsaukties uz [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Zvanot par mainīgi fiksētu slēgšanu
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## `FnMut` parametra izmantošana
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // lai regex varētu paļauties uz šo `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Veic zvana darbību.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Zvana operatora versija, kas ņem blakus vērtību uztvērēju.
///
/// Var izsaukt `FnOnce` gadījumus, taču, iespējams, vairākas reizes tos nevar izsaukt.Tādēļ, ja vienīgais veids, kas zināms par tipu, ir tas, ka tas ievieš `FnOnce`, to var izsaukt tikai vienu reizi.
///
/// `FnOnce` tiek automātiski ieviesta ar slēgšanu, kas varētu patērēt uzņemtos mainīgos, kā arī visiem veidiem, kas ievieš [`FnMut`], piemēram, (safe) [function pointers] (jo `FnOnce` ir [`FnMut`] supertraits).
///
///
/// Tā kā gan [`Fn`], gan [`FnMut`] ir `FnOnce` apakškategorijas, var izmantot jebkuru [`Fn`] vai [`FnMut`] gadījumu, kur gaidāms `FnOnce`.
///
/// Izmantojiet `FnOnce` kā saistījumu, ja vēlaties pieņemt funkcijai līdzīgu parametru un jums tas jāizsauc tikai vienu reizi.
/// Ja jums ir nepieciešams atkārtoti izsaukt parametru, izmantojiet [`FnMut`] kā saistītu;ja jums tas ir nepieciešams arī stāvokļa nemutēšanai, izmantojiet [`Fn`].
///
/// Plašāku informāciju par šo tēmu skatiet [chapter on closures in *The Rust Programming Language*][book].
///
/// Jāatzīmē arī īpašā sintakse `Fn` traits (piem.,
/// `Fn(usize, bool) -> izmantot`).Tie, kurus interesē tehniskā informācija, var atsaukties uz [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## `FnOnce` parametra izmantošana
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` patērē uzņemtos mainīgos, tāpēc to nevar palaist vairāk nekā vienu reizi.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Mēģinot vēlreiz izsaukt `func()`, `func` radīsies `use of moved value` kļūda.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` šajā brīdī vairs nevar atsaukties
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // lai regex varētu paļauties uz šo `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Atgrieztais tips pēc zvana operatora izmantošanas.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Veic zvana darbību.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}