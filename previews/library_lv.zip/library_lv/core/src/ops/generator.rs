use crate::marker::Unpin;
use crate::pin::Pin;

/// Ģeneratora atsākšanas rezultāts.
///
/// Šis skaitlis tiek atgriezts no metodes `Generator::resume` un norāda ģeneratora iespējamās atgriešanās vērtības.
/// Pašlaik tas atbilst vai nu apturēšanas punktam (`Yielded`), vai gala punktam (`Complete`).
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// Ģenerators ir apturēts ar vērtību.
    ///
    /// Šis stāvoklis norāda, ka ģenerators ir apturēts, un tas parasti atbilst `yield` paziņojumam.
    /// Šajā variantā norādītā vērtība atbilst izteiksmei, kas nodota `yield`, un ļauj ģeneratoriem katru reizi norādīt vērtību.
    ///
    ///
    Yielded(Y),

    /// Ģenerators komplektēts ar atgriešanās vērtību.
    ///
    /// Šis stāvoklis norāda, ka ģenerators ir pabeidzis izpildi ar norādīto vērtību.
    /// Kad ģenerators ir atgriezis `Complete`, tiek uzskatīta par programmētāja kļūdu, lai vēlreiz izsauktu `resume`.
    ///
    Complete(R),
}

/// trait, ko ievieš iebūvēti ģeneratoru tipi.
///
/// Ģeneratori, kurus parasti dēvē arī par korutīnām, pašlaik ir eksperimentāla valodas iezīme Rust.
/// [RFC 2033] pievienotie ģeneratori pašlaik ir domāti, lai galvenokārt nodrošinātu async/await sintakses veidošanas bloku, taču, visticamāk, tas tiks paplašināts, nodrošinot arī ergonomisku definīciju iteratoriem un citiem primitīviem.
///
///
/// Ģeneratoru sintakse un semantika ir nestabila, un stabilizācijai būs nepieciešama papildu RFC.Tomēr šobrīd sintakse ir līdzīga slēgšanai:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Plašāka ģeneratoru dokumentācija ir atrodama nestabilajā grāmatā.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// Vērtības veids, ko iegūst šis ģenerators.
    ///
    /// Šis saistītais tips atbilst `yield` izteiksmei un vērtībām, kuras ir atļauts atgriezt katru reizi, kad ģenerators iegūst.
    ///
    /// Piemēram, iteratoram kā ģeneratoram, visticamāk, šis tips ir `T`, tipam tiek atkārtots.
    ///
    type Yield;

    /// Vērtības veids, ko šis ģenerators atgriež.
    ///
    /// Tas atbilst tipam, kas atgriezts no ģeneratora vai nu ar `return` paziņojumu, vai netieši kā ģeneratora literāļa pēdējā izteiksme.
    /// Piemēram, futures to izmantos kā `Result<T, E>`, jo tas apzīmē pabeigtu future.
    ///
    ///
    type Return;

    /// Atsāk šī ģeneratora izpildi.
    ///
    /// Šī funkcija atsāks ģeneratora izpildi vai sāks izpildi, ja tā vēl nav izdarīta.
    /// Šis zvans atgriezīsies ģeneratora pēdējā apturēšanas punktā, atsākot izpildi no jaunākās `yield`.
    /// Ģenerators turpinās izpildīt, līdz tas vai nu dos, vai atgriezīsies, un tad šī funkcija atgriezīsies.
    ///
    /// # Atgriešanās vērtība
    ///
    /// `GeneratorState` enum, kas atgriezts no šīs funkcijas, norāda, kādā stāvoklī ir ģenerators pēc atgriešanās.
    /// Ja `Yielded` variants tiek atgriezts, ģenerators ir sasniedzis piekares punktu un ir iegūta vērtība.
    /// Šajā stāvoklī esošie ģeneratori ir pieejami atsākšanai vēlāk.
    ///
    /// Ja `Complete` tiek atgriezts, ģenerators ir pilnībā pabeidzis norādīto vērtību.Ģeneratoru var atsākt atkārtoti.
    ///
    /// # Panics
    ///
    /// Šī funkcija var būt panic, ja tā tiek izsaukta pēc tam, kad iepriekš ir atgriezts `Complete` variants.
    /// Kaut arī ģeneratora literāļi valodā tiek garantēti līdz panic, atsākot darbu pēc `Complete`, tas netiek garantēts visām `Generator` trait ieviešanām.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}