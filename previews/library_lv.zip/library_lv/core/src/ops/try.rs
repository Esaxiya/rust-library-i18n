/// trait `?` operatora uzvedības pielāgošanai.
///
/// `Try` ieviešanas veids ir kanonisks veids, kā to skatīt success/failure divdabuma izteiksmē.
/// Šis trait ļauj gan iegūt šīs veiksmes vai neveiksmes vērtības no esošā gadījuma, gan izveidot jaunu gadījumu no veiksmes vai neveiksmes vērtības.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Šīs vērtības veids, ja to uzskata par veiksmīgu.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Šīs vērtības tips, ja to uzskata par neizdevušos.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Pielieto operatoru "?".`Ok(t)` atgriešanās nozīmē, ka izpilde jāturpina normāli, un `?` rezultāts ir vērtība `t`.
    /// `Err(e)` atgriešanās nozīmē, ka izpildei vajadzētu branch ievadīt iekšējam `catch` vai arī atgriezties no funkcijas.
    ///
    /// Ja `Err(e)` rezultāts tiek atgriezts, `e` vērtība būs "wrapped" norobežojošās sfēras atgriešanas tipā (kurai pašai jāievieš `Try`).
    ///
    /// Konkrēti, tiek atgriezta vērtība `X::from_error(From::from(e))`, kur `X` ir norobežojošās funkcijas atgriešanās tips.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Aptiniet kļūdas vērtību, lai izveidotu salikto rezultātu.
    /// Piemēram, `Result::Err(x)` un `Result::from_error(x)` ir līdzvērtīgi.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Aptiniet OK vērtību, lai izveidotu salikto rezultātu.
    /// Piemēram, `Result::Ok(x)` un `Result::from_ok(x)` ir līdzvērtīgi.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}