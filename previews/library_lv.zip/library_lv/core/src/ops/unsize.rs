use crate::marker::Unsize;

/// Trait, kas norāda, ka šis ir rādītājs vai iesaiņotājs, kur rādītājam var veikt izmēru samazināšanu.
///
/// Plašāku informāciju skatiet [DST coercion RFC][dst-coerce] un [the nomicon entry on coercion][nomicon-coerce].
///
/// Iebūvētajiem rādītāju veidiem norādes uz `T` piespiedīs rādītājus uz `U`, ja `T: Unsize<U>`, pārveidojot no plānas rādītāja uz tauku rādītāju.
///
/// Pielāgotiem veidiem piespiešana šeit darbojas, piespiežot `Foo<T>` uz `Foo<U>`, ja pastāv `CoerceUnsized<Foo<U>> for Foo<T>` implekts.
/// Šādu impliku var uzrakstīt tikai tad, ja `Foo<T>` ir tikai viens lauks, kas nav fantomdatu lauks, kurā ir iekļauts `T`.
/// Ja šī lauka tips ir `Bar<T>`, `CoerceUnsized<Bar<U>> for Bar<T>` ir jāievieš.
/// Piespiešana darbosies, piespiežot `Bar<T>` lauku uz `Bar<U>` un aizpildot pārējos laukus no `Foo<T>`, lai izveidotu `Foo<U>`.
/// Tas efektīvi izpētīs rādītāja lauku un to piespiedīs.
///
/// Parasti viedajiem rādītājiem jūs ieviesīsit `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized` ar izvēles `?Sized`, kas saistīts ar pašu `T`.
/// Iesaiņojuma veidiem, kas tieši iegulst `T`, piemēram, `Cell<T>` un `RefCell<T>`, varat tieši ieviest `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>`.
///
/// Tas ļaus darboties tādu veidu kā `Cell<Box<T>>` piespiešanai.
///
/// [`Unsize`][unsize] tiek izmantots, lai atzīmētu tipus, kurus var piespiest DST, ja aiz rādītājiem.Kompilators to ievieš automātiski.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// To izmanto objektu drošībai, lai pārbaudītu, vai var nosūtīt metodes uztvērēja tipu.
///
/// trait ieviešanas piemērs:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}