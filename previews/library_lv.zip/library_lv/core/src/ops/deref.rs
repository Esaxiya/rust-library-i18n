/// Izmanto nemainīgām novirzīšanas operācijām, piemēram, `*v`.
///
/// Papildus tam, ka `Deref` tiek izmantots izteiktām novirzīšanas operācijām ar operatoru (unary) `*` nemaināmos apstākļos, daudzos gadījumos kompilators netieši izmanto arī `Deref`.
/// Šo mehānismu sauc par ['`Deref` coercion'][more].
/// Mainīgos apstākļos tiek izmantots [`DerefMut`].
///
/// `Deref` ieviešana viedajiem rādītājiem padara ērtu piekļuvi aiz tiem esošajiem datiem, tāpēc viņi ievieš `Deref`.
/// No otras puses, noteikumi attiecībā uz `Deref` un [`DerefMut`] tika īpaši izstrādāti, lai pielāgotos viedajiem rādītājiem.
/// Tādēļ, lai izvairītos no neskaidrībām,**`Deref` ir jāievieš tikai viedajiem rādītājiem**.
///
/// Līdzīgu iemeslu dēļ **šim trait nekad nevajadzētu izgāzties**.Neveiksme novirzīšanas laikā var būt ļoti mulsinoša, ja netieši tiek izsaukta `Deref`.
///
/// # Vairāk par `Deref` piespiešanu
///
/// Ja `T` ievieš `Deref<Target = U>` un `x` ir `T` tipa vērtība, tad:
///
/// * Nemainīgā kontekstā `*x` (kur `T` nav nedz atsauce, nedz neapstrādāts rādītājs) ir ekvivalents `* Deref::deref(&x)`.
/// * `&T` tipa vērtības tiek piespiestas `&U` tipa vērtībām
/// * `T` netieši ievieš visas `U` tipa (immutable) metodes.
///
/// Lai iegūtu sīkāku informāciju, apmeklējiet [the chapter in *The Rust Programming Language*][book], kā arī atsauces sadaļas par [the dereference operator][ref-deref-op], [method resolution] un [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Struktūra ar vienu lauku, kurai var piekļūt, novirzot struktūru.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Iegūtais veids pēc novirzīšanas.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Novirza vērtību.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Izmanto maināmām novirzīšanas operācijām, piemēram, `*v = 1;`.
///
/// Papildus tam, ka `DerefMut` tiek izmantots izteiktām novirzīšanas operācijām ar (unary) `*` operatoru mainīgos kontekstos, daudzos gadījumos kompilators netieši izmanto arī `DerefMut`.
/// Šo mehānismu sauc par ['`Deref` coercion'][more].
/// Nemainīgos apstākļos tiek izmantots [`Deref`].
///
/// `DerefMut` ieviešana viedajiem rādītājiem padara aiz muguras esošo datu mutāciju ērtu, tāpēc viņi ievieš `DerefMut`.
/// No otras puses, noteikumi attiecībā uz [`Deref`] un `DerefMut` tika īpaši izstrādāti, lai pielāgotos viedajiem rādītājiem.
/// Tāpēc **, lai izvairītos no neskaidrībām,** DerefMut ir jāievieš tikai viedajiem rādītājiem **.
///
/// Līdzīgu iemeslu dēļ **šim trait nekad nevajadzētu izgāzties**.Neveiksme novirzīšanas laikā var būt ļoti mulsinoša, ja netieši tiek izsaukta `DerefMut`.
///
/// # Vairāk par `Deref` piespiešanu
///
/// Ja `T` ievieš `DerefMut<Target = U>` un `x` ir `T` tipa vērtība, tad:
///
/// * Mainīgos apstākļos `*x` (kur `T` nav nedz atsauce, nedz neapstrādāts rādītājs) ir ekvivalents `* DerefMut::deref_mut(&mut x)`.
/// * `&mut T` tipa vērtības tiek piespiestas `&mut U` tipa vērtībām
/// * `T` netieši ievieš visas `U` tipa (mutable) metodes.
///
/// Lai iegūtu sīkāku informāciju, apmeklējiet [the chapter in *The Rust Programming Language*][book], kā arī atsauces sadaļas par [the dereference operator][ref-deref-op], [method resolution] un [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Struktūra ar vienu lauku, kuru var mainīt, novirzot struktūru.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Maināmi novirza vērtību.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Norāda, ka struktūru var izmantot kā metožu uztvērēju bez `arbitrary_self_types` funkcijas.
///
/// To ievieš stdlib rādītāju tipi, piemēram, `Box<T>`, `Rc<T>`, `&T` un `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}