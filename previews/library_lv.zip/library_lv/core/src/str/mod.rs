//! Stīgu manipulācijas.
//!
//! Lai iegūtu sīkāku informāciju, skatiet moduli [`std::str`].
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. ārpus robežas
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. sākums <=beigas
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. rakstzīmju robeža
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // atrast raksturu
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` jābūt mazākai par len un char robežu
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// Atgriež `self` garumu.
    ///
    /// Šis garums ir baiti, nevis [`char`] s vai grafēmas.
    /// Citiem vārdiem sakot, tas var nebūt tas, ko cilvēks uzskata par virknes garumu.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // iedomātā f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// Atgriež vērtību `true`, ja `self` garums ir nulle baitu.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Pārbauda, vai indekss ir pirmais baits UTF-8 koda punktu secībā vai virknes beigas.
    ///
    ///
    /// Virknes sākums un beigas (ja `indekss== self.len()`) tiek uzskatīts par robežām.
    ///
    /// Atgriež `false`, ja `index` ir lielāks par `self.len()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // `老` sākums
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // `ö` otrais baits
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // `老` trešais baits
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 un len vienmēr ir ok.
        // Pārbaudiet precīzi ar 0, lai tas varētu optimizēt pārbaudi un izlaist virknes datu lasīšanu attiecīgajam gadījumam.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // Šī ir mazliet maģiska ekvivalents: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// Pārvērš virknes daļu par baitu.
    /// Lai baitu šķēli atkal pārveidotu par virknes šķēli, izmantojiet funkciju [`from_utf8`].
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // DROŠĪBA: const skaņa, jo mēs pārveidojam divus tipus ar vienādu izkārtojumu
        unsafe { mem::transmute(self) }
    }

    /// Pārveido maināmu virknes daļu par maināmu baitu.
    ///
    /// # Safety
    ///
    /// Zvanītājam pirms aizņēmuma beigām jāpārliecinās, ka šķēles saturs ir derīgs UTF-8 un tiek izmantots pamatā esošais `str`.
    ///
    ///
    /// `str`, kura saturs nav derīgs, izmantošana UTF-8 ir nedefinēta rīcība.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // DROŠĪBA: kopa no `&str` līdz `&[u8]` ir droša kopš `str`
        // ir tāds pats izkārtojums kā `&[u8]` (šo garantiju var sniegt tikai libstd).
        // Rādītāja novirzīšana ir droša, jo tā nāk no maināmas atsauces, kas tiek garantēta derīga rakstīšanai.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// Pārvērš virknes daļu par neapstrādātu rādītāju.
    ///
    /// Tā kā virknes šķēles ir baitu šķēle, neapstrādātais rādītājs norāda uz [`u8`].
    /// Šis rādītājs norāda uz virknes daļas pirmo baitu.
    ///
    /// Zvanītājam ir jānodrošina, lai atgrieztais rādītājs nekad netiktu rakstīts.
    /// Ja jums ir nepieciešams pārveidot virknes daļas saturu, izmantojiet [`as_mut_ptr`].
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// Pārvērš maināmo virknes daļu par neapstrādātu rādītāju.
    ///
    /// Tā kā virknes šķēles ir baitu šķēle, neapstrādātais rādītājs norāda uz [`u8`].
    /// Šis rādītājs norāda uz virknes daļas pirmo baitu.
    ///
    /// Jūsu pienākums ir pārliecināties, ka virknes daļa tiek modificēta tikai tā, lai tā paliktu derīga UTF-8.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// Atgriež `str` apakšslāni.
    ///
    /// Šī ir bez panikas alternatīva `str` indeksēšanai.
    /// Atgriež vērtību [`None`] ikreiz, kad ekvivalenta indeksēšanas darbība būtu panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // indeksi nav uz UTF-8 secības robežām
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // ārpus robežas
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// Atgriež maināmu apakšslāni `str`.
    ///
    /// Šī ir bez panikas alternatīva `str` indeksēšanai.
    /// Atgriež vērtību [`None`] ikreiz, kad ekvivalenta indeksēšanas darbība būtu panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // pareizs garums
    /// assert!(v.get_mut(0..5).is_some());
    /// // ārpus robežas
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// Atgriež nepārbaudītu `str` apakšslāni.
    ///
    /// Šī ir nepārbaudīta alternatīva `str` indeksēšanai.
    ///
    /// # Safety
    ///
    /// Šīs funkcijas zvanītāji ir atbildīgi par šo priekšnoteikumu izpildi:
    ///
    /// * Sākuma indekss nedrīkst pārsniegt beigu indeksu;
    /// * Indeksiem jābūt robežās no sākotnējās šķēles;
    /// * Indeksiem jāatrodas uz UTF-8 secības robežām.
    ///
    /// Ja tas nav izdarīts, atgrieztā virknes daļa var norādīt uz nederīgu atmiņu vai pārkāpt `str` tipa paziņotos invariantus.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // DROŠĪBA: zvanītājam jāievēro `get_unchecked` drošības līgums;
        // šķēle ir norobežojama, jo `self` ir droša atsauce.
        // Atgrieztais rādītājs ir drošs, jo `SliceIndex` implikiem ir jāgarantē, ka tas ir.
        unsafe { &*i.get_unchecked(self) }
    }

    /// Atgriež maināmu, nepārbaudītu `str` apakšslāni.
    ///
    /// Šī ir nepārbaudīta alternatīva `str` indeksēšanai.
    ///
    /// # Safety
    ///
    /// Šīs funkcijas zvanītāji ir atbildīgi par šo priekšnoteikumu izpildi:
    ///
    /// * Sākuma indekss nedrīkst pārsniegt beigu indeksu;
    /// * Indeksiem jābūt robežās no sākotnējās šķēles;
    /// * Indeksiem jāatrodas uz UTF-8 secības robežām.
    ///
    /// Ja tas nav izdarīts, atgrieztā virknes daļa var norādīt uz nederīgu atmiņu vai pārkāpt `str` tipa paziņotos invariantus.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // DROŠĪBA: zvanītājam jāievēro `get_unchecked_mut` drošības līgums;
        // šķēle ir norobežojama, jo `self` ir droša atsauce.
        // Atgrieztais rādītājs ir drošs, jo `SliceIndex` implikiem ir jāgarantē, ka tas ir.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// Izveido virknes daļu no citas virknes šķēles, apejot drošības pārbaudes.
    ///
    /// Parasti tas nav ieteicams, lietojiet piesardzīgi!Drošu alternatīvu skatiet [`str`] un [`Index`].
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// Šī jaunā šķēle iet no `begin` uz `end`, ieskaitot `begin`, bet izņemot `end`.
    ///
    /// Lai tā vietā iegūtu mainīgu virknes daļu, skatiet metodi [`slice_mut_unchecked`].
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// Šīs funkcijas zvanītāji ir atbildīgi, ka ir izpildīti trīs priekšnoteikumi:
    ///
    /// * `begin` nedrīkst pārsniegt `end`.
    /// * `begin` un `end` jābūt baitu pozīcijām virknes daļā.
    /// * `begin` un `end` jāatrodas uz UTF-8 secības robežām.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // DROŠĪBA: zvanītājam jāievēro `get_unchecked` drošības līgums;
        // šķēle ir norobežojama, jo `self` ir droša atsauce.
        // Atgrieztais rādītājs ir drošs, jo `SliceIndex` implikiem ir jāgarantē, ka tas ir.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// Izveido virknes daļu no citas virknes šķēles, apejot drošības pārbaudes.
    /// Parasti tas nav ieteicams, lietojiet piesardzīgi!Drošu alternatīvu skatiet [`str`] un [`IndexMut`].
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// Šī jaunā šķēle iet no `begin` uz `end`, ieskaitot `begin`, bet izņemot `end`.
    ///
    /// Lai tā vietā iegūtu nemainīgu virknes šķēli, skatiet metodi [`slice_unchecked`].
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// Šīs funkcijas zvanītāji ir atbildīgi, ka ir izpildīti trīs priekšnoteikumi:
    ///
    /// * `begin` nedrīkst pārsniegt `end`.
    /// * `begin` un `end` jābūt baitu pozīcijām virknes daļā.
    /// * `begin` un `end` jāatrodas uz UTF-8 secības robežām.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // DROŠĪBA: zvanītājam jāievēro `get_unchecked_mut` drošības līgums;
        // šķēle ir norobežojama, jo `self` ir droša atsauce.
        // Atgrieztais rādītājs ir drošs, jo `SliceIndex` implikiem ir jāgarantē, ka tas ir.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// Indeksā sadaliet vienu virknes šķēli divās daļās.
    ///
    /// Argumentam `mid` jābūt baitu nobīdei no virknes sākuma.
    /// Tam jābūt arī uz UTF-8 koda punkta robežas.
    ///
    /// Divas atgrieztās šķēles iet no virknes daļas sākuma līdz `mid` un no `mid` līdz virknes daļas beigām.
    ///
    /// Lai tā vietā iegūtu mainīgas virknes šķēles, skatiet metodi [`split_at_mut`].
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics, ja `mid` neatrodas uz UTF-8 koda punkta robežas vai ja tas ir aiz virknes pēdējā koda punkta beigām.
    ///
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary pārbauda, vai indekss ir [0, .len()]
        if self.is_char_boundary(mid) {
            // DROŠĪBA: tikko pārbaudījāt, vai `mid` atrodas uz char robežas.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Indeksā sadaliet vienu maināmu virknes šķēli divās daļās.
    ///
    /// Argumentam `mid` jābūt baitu nobīdei no virknes sākuma.
    /// Tam jābūt arī uz UTF-8 koda punkta robežas.
    ///
    /// Divas atgrieztās šķēles iet no virknes daļas sākuma līdz `mid` un no `mid` līdz virknes daļas beigām.
    ///
    /// Lai tā vietā iegūtu nemainīgas virknes šķēles, skatiet metodi [`split_at`].
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics, ja `mid` neatrodas uz UTF-8 koda punkta robežas vai ja tas ir aiz virknes pēdējā koda punkta beigām.
    ///
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary pārbauda, vai indekss ir [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // DROŠĪBA: tikko pārbaudījāt, vai `mid` atrodas uz char robežas.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Atgriež virknes virknes iteratoru.
    ///
    /// Tā kā virknes šķēle sastāv no derīga UTF-8, mēs varam atkārtot virknes šķēli ar [`char`].
    /// Šī metode atgriež šādu iteratoru.
    ///
    /// Ir svarīgi atcerēties, ka [`char`] apzīmē Unicode skalāro vērtību un, iespējams, neatbilst jūsu idejai par to, kas ir 'character'.
    ///
    /// Atkārtojums virs grafēmu kopām var būt tas, ko jūs patiesībā vēlaties.
    /// Šo funkcionalitāti nenodrošina Rust standarta bibliotēka, tā vietā pārbaudiet crates.io.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// Atcerieties, ka [`char`] var neatbilst jūsu intuīcijai par rakstzīmēm:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // nevis 'y̆'
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// Atgriež iteratoru virs virknes šķēles [char] un to pozīcijām.
    ///
    /// Tā kā virknes šķēle sastāv no derīga UTF-8, mēs varam atkārtot virknes šķēli ar [`char`].
    /// Šī metode atgriež šo [char], kā arī to baitu pozīciju atkārtotāju.
    ///
    /// Atkārtotājs dod kopas.Pozīcija ir pirmā, [`char`] ir otrā.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// Atcerieties, ka [`char`] var neatbilst jūsu intuīcijai par rakstzīmēm:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // nevis (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // šeit atzīmējiet 3, pēdējais varonis aizņēma divus baitus
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// Atkārtotājs pār virknes šķēles baitiem.
    ///
    /// Tā kā virknes šķēle sastāv no baitu secības, mēs varam atkārtot virknes virkni pēc baita.
    /// Šī metode atgriež šādu iteratoru.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// Sadaliet virknes daļu pa atstarpi.
    ///
    /// Atgrieztais atkārtotājs atgriezīs virknes šķēles, kas ir sākotnējās virknes daļas apakšslāņi, atdalīti ar jebkuru atstarpi.
    ///
    ///
    /// 'Whitespace' ir definēts saskaņā ar Unicode atvasinātā pamatīpašuma `White_Space` noteikumiem.
    /// Ja tā vietā vēlaties sadalīties tikai ASCII tukšumā, izmantojiet [`split_ascii_whitespace`].
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Tiek uzskatīti visu veidu atstarpes:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// Sadala virknes daļu ar ASCII atstarpi.
    ///
    /// Atgrieztais atkārtotājs atgriezīs virknes šķēles, kas ir sākotnējās virknes daļas apakšslāņi, atdalot ar jebkuru daudzumu ASCII atstarpes.
    ///
    ///
    /// Tā vietā, lai sadalītu pa Unicode `Whitespace`, izmantojiet [`split_whitespace`].
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Tiek uzskatīti visu veidu ASCII atstarpes:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// Iterators pāri virknes līnijām kā virknes šķēles.
    ///
    /// Līnijas tiek beigtas vai nu ar jaunu līniju (`\n`), vai ar karietes atgriešanos ar līnijas padevi (`\r\n`).
    ///
    /// Pēdējās rindas beigas nav obligātas.
    /// Virkne, kas beidzas ar pēdējās rindas beigām, atgriezīs tādas pašas rindas kā citādi identiska virkne bez pēdējās rindas beigām.
    ///
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// Pēdējās rindas beigas nav nepieciešamas:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// Atkārtotājs pāri virknes līnijām.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// Atgriež `u16` atkārtotāju pāri virknei, kas kodēta kā UTF-16.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// Atgriež `true`, ja dotais modelis sakrīt ar šīs virknes daļas apakšslāni.
    ///
    /// Atgriež `false`, ja tā nav.
    ///
    /// [pattern] var būt `&str`, [`char`], [char}] daļa vai funkcija vai aizvēršana, kas nosaka, vai raksturs sakrīt.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// Atgriež `true`, ja dotais modelis atbilst šīs virknes daļas prefiksam.
    ///
    /// Atgriež `false`, ja tā nav.
    ///
    /// [pattern] var būt `&str`, [`char`], [char}] daļa vai funkcija vai aizvēršana, kas nosaka, vai raksturs sakrīt.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// Atgriež `true`, ja dotais modelis atbilst šīs virknes daļas sufiksam.
    ///
    /// Atgriež `false`, ja tā nav.
    ///
    /// [pattern] var būt `&str`, [`char`], [char}] daļa vai funkcija vai aizvēršana, kas nosaka, vai raksturs sakrīt.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// Atgriež šīs virknes daļas pirmās rakstzīmes baitu indeksu, kas atbilst paraugam.
    ///
    /// Atgriež vērtību [`None`], ja modelis neatbilst.
    ///
    /// [pattern] var būt `&str`, [`char`], [char}] daļa vai funkcija vai aizvēršana, kas nosaka, vai raksturs sakrīt.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Vienkārši modeļi:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// Sarežģītāki modeļi, izmantojot bezpunktu stilu un slēgšanu:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// Neatrodot modeli:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// Atgriež baitu indeksu pirmajai rakstzīmei, kas atbilst šīs virknes daļas parauga labākajai atbilstībai.
    ///
    /// Atgriež vērtību [`None`], ja modelis neatbilst.
    ///
    /// [pattern] var būt `&str`, [`char`], [char}] daļa vai funkcija vai aizvēršana, kas nosaka, vai raksturs sakrīt.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Vienkārši modeļi:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// Sarežģītāki modeļi ar slēgšanu:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// Neatrodot modeli:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// Iterators pār šīs virknes daļas apakšpozīcijām, atdalīts ar rakstzīmēm, kas saskaņotas ar modeli.
    ///
    /// [pattern] var būt `&str`, [`char`], [char}] daļa vai funkcija vai aizvēršana, kas nosaka, vai raksturs sakrīt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteratora uzvedība
    ///
    /// Atgrieztais iterators būs [`DoubleEndedIterator`], ja modelis ļauj veikt reverso meklēšanu un forward/reverse meklēšana dod tos pašus elementus.
    /// Tas attiecas uz, piemēram, [`char`], bet ne uz `&str`.
    ///
    /// Ja modelis ļauj veikt reverso meklēšanu, bet tā rezultāti var atšķirties no meklēšanas uz priekšu, var izmantot metodi [`rsplit`].
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// Vienkārši modeļi:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// Ja modelis ir rakstzīmju daļa, sadaliet katru rakstzīmi:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// Sarežģītāks modelis, izmantojot aizdari:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// Ja virkne satur vairākus blakus esošus atdalītājus, izvadē beigās būs tukšas virknes:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Blakus esošos atdalītājus atdala tukša virkne.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// Atdalītājus virknes sākumā vai beigās ieskauj tukšas virknes.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// Ja tukšo virkni izmanto kā atdalītāju, tā atdala katru virknes rakstzīmi, kā arī virknes sākumu un beigas.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// Blakus esošie atdalītāji var izraisīt, iespējams, pārsteidzošu uzvedību, ja kā atdalītāju izmanto atstarpi.Šis kods ir pareizs:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Tas _not_ dod jums:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// Šādai uzvedībai izmantojiet [`split_whitespace`].
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// Iterators pār šīs virknes daļas apakšpozīcijām, atdalīts ar rakstzīmēm, kas saskaņotas ar modeli.
    /// Atšķiras no `split` radītā iteratora ar to, ka `split_inclusive` atstāj saskaņoto daļu kā apakšvirsmas galotni.
    ///
    ///
    /// [pattern] var būt `&str`, [`char`], [char}] daļa vai funkcija vai aizvēršana, kas nosaka, vai raksturs sakrīt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// Ja virknes pēdējais elements ir saskaņots, šis elements tiks uzskatīts par iepriekšējās apakšvirknes beigu daļu.
    /// Šis apakšvirsraksts būs pēdējais vienums, kuru atdeva atkārtotājs.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// Iterators pār dotās virknes daļas apakšvirsrakstiem, atdalīts ar rakstzīmēm, kas saskaņotas ar modeli un iegūtas apgrieztā secībā.
    ///
    /// [pattern] var būt `&str`, [`char`], [char}] daļa vai funkcija vai aizvēršana, kas nosaka, vai raksturs sakrīt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteratora uzvedība
    ///
    /// Atgrieztajam atkārtotājam ir nepieciešams, lai modelis atbalstītu reverso meklēšanu, un tas būs [`DoubleEndedIterator`], ja forward/reverse meklēšanā tiek iegūti tie paši elementi.
    ///
    ///
    /// Lai veiktu iterāciju no priekšpuses, var izmantot [`split`] metodi.
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// Vienkārši modeļi:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// Sarežģītāks modelis, izmantojot aizdari:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// Iterators pār dotās virknes daļas apakšvirsrakstiem, atdalīts ar rakstzīmēm, kurām atbilst modelis.
    ///
    /// [pattern] var būt `&str`, [`char`], [char}] daļa vai funkcija vai aizvēršana, kas nosaka, vai raksturs sakrīt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Ekvivalents [`split`], izņemot to, ka aizmugurējā apakšvirsraksts tiek izlaists, ja tas ir tukšs.
    ///
    /// [`split`]: str::split
    ///
    /// Šo metodi var izmantot virknes datiem, kas ir _terminated_, nevis _separated_ pēc parauga.
    ///
    /// # Iteratora uzvedība
    ///
    /// Atgrieztais iterators būs [`DoubleEndedIterator`], ja modelis ļauj veikt reverso meklēšanu un forward/reverse meklēšana dod tos pašus elementus.
    /// Tas attiecas uz, piemēram, [`char`], bet ne uz `&str`.
    ///
    /// Ja modelis ļauj veikt reverso meklēšanu, bet tā rezultāti var atšķirties no meklēšanas uz priekšu, var izmantot metodi [`rsplit_terminator`].
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// Iterators virs `self` apakškārtām, atdalīts ar rakstzīmēm, kas saskaņotas ar modeli, un iegūtas apgrieztā secībā.
    ///
    /// [pattern] var būt `&str`, [`char`], [char}] daļa vai funkcija vai aizvēršana, kas nosaka, vai raksturs sakrīt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Ekvivalents [`split`], izņemot to, ka aizmugurējā apakšvirsraksts tiek izlaists, ja tas ir tukšs.
    ///
    /// [`split`]: str::split
    ///
    /// Šo metodi var izmantot virknes datiem, kas ir _terminated_, nevis _separated_ pēc parauga.
    ///
    /// # Iteratora uzvedība
    ///
    /// Atgrieztajam atkārtotājam ir nepieciešams, lai modelis atbalstītu reverso meklēšanu, un tas būs divkāršs, ja forward/reverse meklēšanā tiks iegūti tie paši elementi.
    ///
    ///
    /// Lai veiktu iterāciju no priekšpuses, var izmantot [`split_terminator`] metodi.
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// Iterators pār dotās virknes daļas apakšvirknēm, atdalīts ar modeli, ierobežots, lai atgrieztu ne vairāk kā `n` vienumus.
    ///
    /// Ja `n` apakšvirknes tiek atgrieztas, pēdējā apakšvirkne ("n". Apakšvirsraksts) satur atlikušo virkni.
    ///
    /// [pattern] var būt `&str`, [`char`], [char}] daļa vai funkcija vai aizvēršana, kas nosaka, vai raksturs sakrīt.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteratora uzvedība
    ///
    /// Atgrieztais atkārtotājs nebūs divkāršs, jo to atbalstīt nav efektīvi.
    ///
    /// Ja modelis ļauj veikt reverso meklēšanu, var izmantot metodi [`rsplitn`].
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// Vienkārši modeļi:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// Sarežģītāks modelis, izmantojot aizdari:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// Iterators virs šīs virknes šķēluma apakšstruktūrām, atdalīts ar rakstu, sākot no virknes beigām, ierobežots, lai atgrieztu ne vairāk kā `n` vienumus.
    ///
    ///
    /// Ja `n` apakšvirknes tiek atgrieztas, pēdējā apakšvirkne ("n". Apakšvirsraksts) satur atlikušo virkni.
    ///
    /// [pattern] var būt `&str`, [`char`], [char}] daļa vai funkcija vai aizvēršana, kas nosaka, vai raksturs sakrīt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteratora uzvedība
    ///
    /// Atgrieztais atkārtotājs nebūs divkāršs, jo to atbalstīt nav efektīvi.
    ///
    /// Sadalīšanai no priekšpuses var izmantot [`splitn`] metodi.
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// Vienkārši modeļi:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// Sarežģītāks modelis, izmantojot aizdari:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// Sadala virkni pēc norādītā atdalītāja pirmā gadījuma un atgriež prefiksu pirms atdalītāja un sufiksu pēc atdalītāja.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// Sadala virkni norādītajā atdalītāja pēdējā reizē un atgriež prefiksu pirms atdalītāja un sufiksu pēc atdalītāja.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// Atkārtotājs pār modeļa nedalītajām spēlēm dotajā virknes daļā.
    ///
    /// [pattern] var būt `&str`, [`char`], [char}] daļa vai funkcija vai aizvēršana, kas nosaka, vai raksturs sakrīt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteratora uzvedība
    ///
    /// Atgrieztais iterators būs [`DoubleEndedIterator`], ja modelis ļauj veikt reverso meklēšanu un forward/reverse meklēšana dod tos pašus elementus.
    /// Tas attiecas uz, piemēram, [`char`], bet ne uz `&str`.
    ///
    /// Ja modelis ļauj veikt reverso meklēšanu, bet tā rezultāti var atšķirties no meklēšanas uz priekšu, var izmantot metodi [`rmatches`].
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// Iterators par modeļa nesakritīgajām atbilstībām šajā virknes šķēlē, kas iegūta apgrieztā secībā.
    ///
    /// [pattern] var būt `&str`, [`char`], [char}] daļa vai funkcija vai aizvēršana, kas nosaka, vai raksturs sakrīt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteratora uzvedība
    ///
    /// Atgrieztajam atkārtotājam ir nepieciešams, lai modelis atbalstītu reverso meklēšanu, un tas būs [`DoubleEndedIterator`], ja forward/reverse meklēšanā tiek iegūti tie paši elementi.
    ///
    ///
    /// Lai veiktu iterāciju no priekšpuses, var izmantot [`matches`] metodi.
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// Iterators par modeļa nedalītajām atbilstībām šajā virknes daļā, kā arī indeksu, no kura sākas spēle.
    ///
    /// `pat` atbilstībām `self` robežās, kas pārklājas, tiek atgriezti tikai indeksi, kas atbilst pirmajai atbilstībai.
    ///
    /// [pattern] var būt `&str`, [`char`], [char}] daļa vai funkcija vai aizvēršana, kas nosaka, vai raksturs sakrīt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteratora uzvedība
    ///
    /// Atgrieztais iterators būs [`DoubleEndedIterator`], ja modelis ļauj veikt reverso meklēšanu un forward/reverse meklēšana dod tos pašus elementus.
    /// Tas attiecas uz, piemēram, [`char`], bet ne uz `&str`.
    ///
    /// Ja modelis ļauj veikt reverso meklēšanu, bet tā rezultāti var atšķirties no meklēšanas uz priekšu, var izmantot metodi [`rmatch_indices`].
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // tikai pirmais `aba`
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// Iterators par modeļa `self` nesakritīgo atbilstību, kas iegūts apgrieztā secībā kopā ar spēles indeksu.
    ///
    /// Ja `pat` spēles `self` ietvaros pārklājas, tiek atgriezti tikai indeksi, kas atbilst pēdējai atbilstībai.
    ///
    /// [pattern] var būt `&str`, [`char`], [char}] daļa vai funkcija vai aizvēršana, kas nosaka, vai raksturs sakrīt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteratora uzvedība
    ///
    /// Atgrieztajam atkārtotājam ir nepieciešams, lai modelis atbalstītu reverso meklēšanu, un tas būs [`DoubleEndedIterator`], ja forward/reverse meklēšanā tiek iegūti tie paši elementi.
    ///
    ///
    /// Lai veiktu iterāciju no priekšpuses, var izmantot [`match_indices`] metodi.
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // tikai pēdējais `aba`
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// Atgriež virknes daļu, kuras priekšējā un aizmugurējā atstarpe ir noņemta.
    ///
    /// 'Whitespace' ir definēts saskaņā ar Unicode atvasinātā pamatīpašuma `White_Space` noteikumiem.
    ///
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// Atgriež virknes šķēli, kuras priekšējā atstarpe ir noņemta.
    ///
    /// 'Whitespace' ir definēts saskaņā ar Unicode atvasinātā pamatīpašuma `White_Space` noteikumiem.
    ///
    /// # Teksta virziens
    ///
    /// Virkne ir baitu secība.
    /// `start` šajā kontekstā nozīmē šīs baitu virknes pirmo pozīciju;no kreisās uz labo valodu, piemēram, angļu vai krievu, tā būs kreisā puse, un no labās uz kreiso valodu, piemēram, arābu vai ebreju, tā būs labā puse.
    ///
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// Atgriež virknes šķēli ar aizvāktu atstarpi.
    ///
    /// 'Whitespace' ir definēts saskaņā ar Unicode atvasinātā pamatīpašuma `White_Space` noteikumiem.
    ///
    /// # Teksta virziens
    ///
    /// Virkne ir baitu secība.
    /// `end` šajā kontekstā nozīmē šīs baitu virknes pēdējo pozīciju;no kreisās uz labo valodu, piemēram, angļu vai krievu, šī būs labā puse, un no labās uz kreiso valodu, piemēram, arābu vai ebreju, tā būs kreisā puse.
    ///
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// Atgriež virknes šķēli, kuras priekšējā atstarpe ir noņemta.
    ///
    /// 'Whitespace' ir definēts saskaņā ar Unicode atvasinātā pamatīpašuma `White_Space` noteikumiem.
    ///
    /// # Teksta virziens
    ///
    /// Virkne ir baitu secība.
    /// 'Left' šajā kontekstā nozīmē šīs baitu virknes pirmo pozīciju;tādai valodai kā arābu vai ebreju valoda, kas ir `no labās uz kreiso`, nevis `no kreisās uz labo`, tā būs _right_ puse, nevis kreisā.
    ///
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// Atgriež virknes šķēli ar aizvāktu atstarpi.
    ///
    /// 'Whitespace' ir definēts saskaņā ar Unicode atvasinātā pamatīpašuma `White_Space` noteikumiem.
    ///
    /// # Teksta virziens
    ///
    /// Virkne ir baitu secība.
    /// 'Right' šajā kontekstā nozīmē šīs baitu virknes pēdējo pozīciju;tādai valodai kā arābu vai ebreju valoda, kas ir `no labās uz kreiso`, nevis `no kreisās uz labo`, tā būs _left_ puse, nevis labā.
    ///
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// Atgriež virknes šķēli ar visiem prefiksiem un sufiksiem, kas atbilst atkārtoti noņemtam paraugam.
    ///
    /// [pattern] var būt [`char`], [`char`] šķēle vai funkcija vai slēgšana, kas nosaka, vai raksturs sakrīt.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Vienkārši modeļi:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// Sarežģītāks modelis, izmantojot aizdari:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // Atcerieties agrāko zināmo spēli, izlabojiet to zemāk, ja
            // pēdējā spēle ir atšķirīga
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // DROŠĪBA: Ir zināms, ka `Searcher` atgriež derīgus indeksus.
        unsafe { self.get_unchecked(i..j) }
    }

    /// Atgriež virknes šķēli ar visiem prefiksiem, kas atbilst atkārtoti noņemtam paraugam.
    ///
    /// [pattern] var būt `&str`, [`char`], [char}] daļa vai funkcija vai aizvēršana, kas nosaka, vai raksturs sakrīt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Teksta virziens
    ///
    /// Virkne ir baitu secība.
    /// `start` šajā kontekstā nozīmē šīs baitu virknes pirmo pozīciju;no kreisās uz labo valodu, piemēram, angļu vai krievu, tā būs kreisā puse, un no labās uz kreiso valodu, piemēram, arābu vai ebreju, tā būs labā puse.
    ///
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // DROŠĪBA: Ir zināms, ka `Searcher` atgriež derīgus indeksus.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// Atgriež virknes šķēli ar noņemtu prefiksu.
    ///
    /// Ja virkne sākas ar modeli `prefix`, pēc prefiksa atgriež apakšvirsrakstu, kas iesaiņots `Some`.
    /// Atšķirībā no `trim_start_matches`, šī metode prefiksu noņem tieši vienu reizi.
    ///
    /// Ja virkne nesākas ar `prefix`, atgriež vērtību `None`.
    ///
    /// [pattern] var būt `&str`, [`char`], [char}] daļa vai funkcija vai aizvēršana, kas nosaka, vai raksturs sakrīt.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// Atgriež virknes šķēli ar noņemtu sufiksu.
    ///
    /// Ja virkne beidzas ar rakstu `suffix`, apakšvirsraksts tiek atgriezts pirms sufiksa, ietinot `Some`.
    /// Atšķirībā no `trim_end_matches`, šī metode piedēkli noņem tieši vienu reizi.
    ///
    /// Ja virkne nebeidzas ar `suffix`, atgriež `None`.
    ///
    /// [pattern] var būt `&str`, [`char`], [char}] daļa vai funkcija vai aizvēršana, kas nosaka, vai raksturs sakrīt.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// Atgriež virknes šķēli ar visiem sufiksiem, kas atbilst atkārtoti noņemtam paraugam.
    ///
    /// [pattern] var būt `&str`, [`char`], [char}] daļa vai funkcija vai aizvēršana, kas nosaka, vai raksturs sakrīt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Teksta virziens
    ///
    /// Virkne ir baitu secība.
    /// `end` šajā kontekstā nozīmē šīs baitu virknes pēdējo pozīciju;no kreisās uz labo valodu, piemēram, angļu vai krievu, šī būs labā puse, un no labās uz kreiso valodu, piemēram, arābu vai ebreju, tā būs kreisā puse.
    ///
    ///
    /// # Examples
    ///
    /// Vienkārši modeļi:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// Sarežģītāks modelis, izmantojot aizdari:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // DROŠĪBA: Ir zināms, ka `Searcher` atgriež derīgus indeksus.
        unsafe { self.get_unchecked(0..j) }
    }

    /// Atgriež virknes šķēli ar visiem prefiksiem, kas atbilst atkārtoti noņemtam paraugam.
    ///
    /// [pattern] var būt `&str`, [`char`], [char}] daļa vai funkcija vai aizvēršana, kas nosaka, vai raksturs sakrīt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Teksta virziens
    ///
    /// Virkne ir baitu secība.
    /// 'Left' šajā kontekstā nozīmē šīs baitu virknes pirmo pozīciju;tādai valodai kā arābu vai ebreju valoda, kas ir `no labās uz kreiso`, nevis `no kreisās uz labo`, tā būs _right_ puse, nevis kreisā.
    ///
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// Atgriež virknes šķēli ar visiem sufiksiem, kas atbilst atkārtoti noņemtam paraugam.
    ///
    /// [pattern] var būt `&str`, [`char`], [char}] daļa vai funkcija vai aizvēršana, kas nosaka, vai raksturs sakrīt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Teksta virziens
    ///
    /// Virkne ir baitu secība.
    /// 'Right' šajā kontekstā nozīmē šīs baitu virknes pēdējo pozīciju;tādai valodai kā arābu vai ebreju valoda, kas ir `no labās uz kreiso`, nevis `no kreisās uz labo`, tā būs _left_ puse, nevis labā.
    ///
    ///
    /// # Examples
    ///
    /// Vienkārši modeļi:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// Sarežģītāks modelis, izmantojot aizdari:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// Parsē šo virknes daļu citā tipā.
    ///
    /// Tā kā `parse` ir tik vispārīgs, tas var radīt problēmas ar tipa secinājumiem.
    /// Tādējādi `parse` ir viena no retajām reizēm, kad jūs redzēsiet sintaksi, ko mīļi dēvē par 'turbofish': `::<>`.
    ///
    /// Tas ļauj secināšanas algoritmam precīzi saprast, kura veida jūs mēģināt parsēt.
    ///
    /// `parse` var parsēt jebkurā tipā, kas ievieš [`FromStr`] trait.
    ///

    /// # Errors
    ///
    /// Atgriezīs [`Err`], ja nav iespējams parsēt šo virknes daļu vajadzīgajā tipā.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// Pamata lietošana
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// 'turbofish' izmantošana, nevis `four` anotēšana:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// Neizdevās parsēt:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// Pārbauda, vai visas šīs virknes rakstzīmes atrodas ASCII diapazonā.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // Šeit mēs varam izturēties pret katru baitu kā rakstzīmi: visas daudzbaitu rakstzīmes sākas ar baitu, kas nav ascii diapazonā, tāpēc mēs jau apstāsimies.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// Pārbauda, vai divas virknes sakrīt ar ASCII reģistru.
    ///
    /// Tas pats, kas `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, bet nepiešķirot un nekopējot īslaicīgus.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// Pārvērš šo virkni savā ASCII lielo burtu ekvivalentā vietā.
    ///
    /// ASCII burti 'a' līdz 'z' tiek kartēti ar 'A' līdz 'Z', bet burti, kas nav ASCII, nemainās.
    ///
    /// Lai atgrieztu jaunu lielās vērtības vērtību, nemodificējot esošo, izmantojiet [`to_ascii_uppercase()`].
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // DROŠĪBA: droša, jo mēs pārveidojam divus tipus ar vienādu izkārtojumu.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// Pārvērš šo virkni savā ASCII mazo burtu ekvivalentā vietā.
    ///
    /// ASCII burti 'A' līdz 'Z' tiek kartēti ar 'a' līdz 'z', bet burti, kas nav ASCII, nemainās.
    ///
    /// Lai atgrieztu jaunu vērtību ar mazāku burtu, nemainot esošo, izmantojiet [`to_ascii_lowercase()`].
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // DROŠĪBA: droša, jo mēs pārveidojam divus tipus ar vienādu izkārtojumu.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// Atgrieziet atkārtotāju, kas izvairās no katras `self` rakstzīmes ar [`char::escape_debug`].
    ///
    ///
    /// Note: tiks izbēgti tikai tie paplašinātie grafēmas koda punkti, ar kuriem sākas virkne.
    ///
    /// # Examples
    ///
    /// Kā atkārtotājs:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Izmantojot `println!` tieši:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// Abi ir līdzvērtīgi:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// Izmantojot `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// Atgrieziet atkārtotāju, kas izvairās no katras `self` rakstzīmes ar [`char::escape_default`].
    ///
    ///
    /// # Examples
    ///
    /// Kā atkārtotājs:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Izmantojot `println!` tieši:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// Abi ir līdzvērtīgi:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// Izmantojot `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// Atgrieziet atkārtotāju, kas izvairās no katras `self` rakstzīmes ar [`char::escape_unicode`].
    ///
    ///
    /// # Examples
    ///
    /// Kā atkārtotājs:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Izmantojot `println!` tieši:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// Abi ir līdzvērtīgi:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// Izmantojot `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// Izveido tukšu str
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// Izveido tukšu maināmu str
    #[inline]
    fn default() -> Self {
        // DROŠĪBA: tukša virkne ir derīga UTF-8.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// Nosaukts, klonējams fn tips
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // DROŠĪBA: nav droša
        unsafe { from_utf8_unchecked(bytes) }
    };
}