//! Veidi, kā izveidot `str` no baitu šķēles.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Pārvērš baitu šķēli virknes šķēlēs.
///
/// Virknes šķēle ([`&str`]) ir izgatavota no baitiem ([`u8`]), un baitu šķēle ([`&[u8]`][byteslice]) ir izgatavota no baitiem, tāpēc šī funkcija pārvēršas starp abiem.
/// Ne visas baitu šķēles ir derīgas virknes šķēles, taču [`&str`] pieprasa, lai tā būtu derīga UTF-8.
/// `from_utf8()` pārbauda, vai baiti ir derīgi UTF-8, un pēc tam veic konvertēšanu.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Ja esat pārliecināts, ka baita šķēle ir derīga UTF-8, un jūs nevēlaties uzņemties derīguma pārbaudes pieskaitāmās izmaksas, ir šīs funkcijas nedrošā versija [`from_utf8_unchecked`], kurai ir tāda pati darbība, taču pārbaude tiek izlaista.
///
///
/// Ja `&str` vietā nepieciešams `String`, apsveriet iespēju [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Tā kā jūs varat sakraut `[u8; N]` kaudzē un varat ņemt no tā [`&[u8]`][byteslice], šī funkcija ir viens no veidiem, kā izveidot kaudzei piešķirtu virkni.Tālāk ir sniegts piemērs piemēru sadaļā.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Atgriež `Err`, ja šķēle nav UTF-8, ar aprakstu, kāpēc norādītā šķēle nav UTF-8.
///
/// # Examples
///
/// Pamata lietojums:
///
/// ```
/// use std::str;
///
/// // daži baiti vektorā
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Mēs zinām, ka šie baiti ir derīgi, tāpēc vienkārši izmantojiet `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Nepareizi baiti:
///
/// ```
/// use std::str;
///
/// // daži nederīgi baiti vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Plašāku informāciju par kļūdu veidiem, kuras var atgriezt, skatiet dokumentos [`Utf8Error`].
///
/// A "stack allocated string":
///
/// ```
/// use std::str;
///
/// // daži baiti kaudzē piešķirtajā masīvā
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Mēs zinām, ka šie baiti ir derīgi, tāpēc vienkārši izmantojiet `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // DROŠĪBA: tikko tika veikta validācija.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Pārvērš maināmo baitu šķēli maināmās virknes šķēlē.
///
/// # Examples
///
/// Pamata lietojums:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" kā maināms vector
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Tā kā mēs zinām, ka šie baiti ir derīgi, mēs varam izmantot `unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Nepareizi baiti:
///
/// ```
/// use std::str;
///
/// // Daži nederīgi baiti maināmā vector
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Plašāku informāciju par kļūdu veidiem, kuras var atgriezt, skatiet dokumentos [`Utf8Error`].
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // DROŠĪBA: tikko tika veikta validācija.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Pārvērš baitu daļu par virknes daļu, nepārbaudot, vai virkne satur derīgu UTF-8.
///
/// Plašāku informāciju skatiet drošajā versijā [`from_utf8`].
///
/// # Safety
///
/// Šī funkcija ir nedroša, jo tā nepārbauda, vai tai nodotie baiti ir derīgi UTF-8.
/// Ja šis ierobežojums tiek pārkāpts, rodas nedefinēta uzvedība, jo pārējā Rust tiek pieņemts, ka [`&str`] ir derīgi UTF-8.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Pamata lietojums:
///
/// ```
/// use std::str;
///
/// // daži baiti vektorā
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // DROŠĪBA: zvanītājam jāgarantē, ka `v` baiti ir derīgi UTF-8.
    // Paļaujas arī uz to, ka `&str` un `&[u8]` ir vienāds izkārtojums.
    unsafe { mem::transmute(v) }
}

/// Pārvērš baitu daļu par virknes daļu, nepārbaudot, vai virkne satur derīgu UTF-8;maināma versija.
///
///
/// Plašāku informāciju skatiet nemainīgajā versijā [`from_utf8_unchecked()`].
///
/// # Examples
///
/// Pamata lietojums:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // DROŠĪBA: zvanītājam jāgarantē `v` baiti
    // ir derīgi UTF-8, tāpēc apraide uz `*mut str` ir droša.
    // Rādītāja novirzīšana ir droša, jo šis rādītājs nāk no atsauces, kas tiek garantēta kā derīga rakstīšanai.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}