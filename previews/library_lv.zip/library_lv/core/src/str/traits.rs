//! Trait ieviešana `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Īsteno virkņu secību.
///
/// Stīgas [lexicographically](Ord#lexicographical-comparison) sakārto pēc to baitu vērtībām.
/// Tas pasūta Unicode koda punktus, pamatojoties uz to pozīcijām kodu diagrammās.
/// Tas ne vienmēr ir tas pats, kas "alphabetical" pasūtījums, kas atšķiras atkarībā no valodas un lokalizācijas.
/// Kārtojot virknes pēc kultūrā pieņemtiem standartiem, ir nepieciešami lokalizācijai specifiski dati, kas ir ārpus `str` tipa darbības jomas.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Īsteno virkņu salīdzināšanas operācijas.
///
/// Stīgas [lexicographically](Ord#lexicographical-comparison) salīdzina pēc to baitu vērtībām.
/// Tādējādi tiek salīdzināti Unicode koda punkti, pamatojoties uz to pozīcijām kodu diagrammās.
/// Tas ne vienmēr ir tas pats, kas "alphabetical" pasūtījums, kas atšķiras atkarībā no valodas un lokalizācijas.
/// Virkņu salīdzināšanai saskaņā ar kultūrā pieņemtiem standartiem ir nepieciešami lokalizācijas dati, kas ir ārpus `str` tipa darbības jomas.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Īsteno apakšvirkņu sagriešanu ar sintaksi `&self[..]` vai `&mut self[..]`.
///
/// Atgriež visas virknes šķēli, ti, atgriež vērtību `&self` vai `&mut self`.Ekvivalents `&self [0 ..
/// len] `vai`&mut self [0 ..
/// len]`.
/// Atšķirībā no citām indeksēšanas operācijām tas nekad nevar būt panic.
///
/// Šī darbība ir *O*(1).
///
/// Pirms 1.20.0 šīs indeksēšanas darbības joprojām tika atbalstītas ar tiešu `Index` un `IndexMut` ieviešanu.
///
/// Ekvivalents `&self[0 .. len]` vai `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Īsteno apakšvirkņu sagriešanu ar sintaksi `&self[begin .. end]` vai `&mut self[begin .. end]`.
///
/// Atgriež norādītās virknes šķēli no baitu diapazona [`sākt`, `end`).
///
/// Šī darbība ir *O*(1).
///
/// Pirms 1.20.0 šīs indeksēšanas darbības joprojām tika atbalstītas ar tiešu `Index` un `IndexMut` ieviešanu.
///
/// # Panics
///
/// Panics, ja `begin` vai `end` nenorāda uz rakstzīmes sākuma baita nobīdi (kā definējis `is_char_boundary`), ja `begin > end` vai `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // tie būs panic:
/// // 2. baits atrodas `ö`:
/// // &s [2 ..3];
///
/// // 8. baits atrodas `老`&s [1 ..
/// // 8];
///
/// // 100 baits atrodas ārpus virknes&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // DROŠĪBA: tikko pārbaudījāt, vai `start` un `end` atrodas uz char robežas,
            // un mēs nododam drošu atsauci, tāpēc arī atgriešanās vērtība būs viena.
            // Mēs arī pārbaudījām char robežas, tāpēc tas ir derīgs UTF-8.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // DROŠĪBA: vienkārši pārbaudiet, vai `start` un `end` atrodas uz char robežas.
            // Mēs zinām, ka rādītājs ir unikāls, jo to ieguvām no `slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // DROŠĪBA: zvanītājs garantē, ka `self` atrodas `slice` robežās
        // kas atbilst visiem `add` nosacījumiem.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // DROŠĪBA: skatiet `get_unchecked` komentārus.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary pārbauda, vai indekss ir domēnā [0, NLL problēmu dēļ .len()] nevar atkārtoti izmantot `get` kā iepriekš
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // DROŠĪBA: tikko pārbaudījāt, vai `start` un `end` atrodas uz char robežas,
            // un mēs nododam drošu atsauci, tāpēc arī atgriešanās vērtība būs viena.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Īsteno apakšvirkņu sagriešanu ar sintaksi `&self[.. end]` vai `&mut self[.. end]`.
///
/// Atgriež dotās virknes šķēli no baitu diapazona ["0", `end`).
/// Ekvivalents `&self[0 .. end]` vai `&mut self[0 .. end]`.
///
/// Šī darbība ir *O*(1).
///
/// Pirms 1.20.0 šīs indeksēšanas darbības joprojām tika atbalstītas ar tiešu `Index` un `IndexMut` ieviešanu.
///
/// # Panics
///
/// Panics, ja `end` nenorāda uz rakstzīmes sākuma baita nobīdi (kā definējis `is_char_boundary`) vai ja `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // DROŠĪBA: tikko pārbaudījāt, vai `end` atrodas uz char robežas,
            // un mēs nododam drošu atsauci, tāpēc arī atgriešanās vērtība būs viena.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // DROŠĪBA: tikko pārbaudījāt, vai `end` atrodas uz char robežas,
            // un mēs nododam drošu atsauci, tāpēc arī atgriešanās vērtība būs viena.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // DROŠĪBA: tikko pārbaudījāt, vai `end` atrodas uz char robežas,
            // un mēs nododam drošu atsauci, tāpēc arī atgriešanās vērtība būs viena.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Īsteno apakšvirkņu sagriešanu ar sintaksi `&self[begin ..]` vai `&mut self[begin ..]`.
///
/// Atgriež norādītās virknes šķēli no baitu diapazona [`sākt`, `len`).Līdzvērtīgs `&self [sāk ..
/// len] `vai`&mut self [sākt ..
/// len]`.
///
/// Šī darbība ir *O*(1).
///
/// Pirms 1.20.0 šīs indeksēšanas darbības joprojām tika atbalstītas ar tiešu `Index` un `IndexMut` ieviešanu.
///
/// # Panics
///
/// Panics, ja `begin` nenorāda uz rakstzīmes sākuma baita nobīdi (kā definējis `is_char_boundary`) vai ja `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // DROŠĪBA: tikko pārbaudījāt, vai `start` atrodas uz char robežas,
            // un mēs nododam drošu atsauci, tāpēc arī atgriešanās vērtība būs viena.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // DROŠĪBA: tikko pārbaudījāt, vai `start` atrodas uz char robežas,
            // un mēs nododam drošu atsauci, tāpēc arī atgriešanās vērtība būs viena.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // DROŠĪBA: zvanītājs garantē, ka `self` atrodas `slice` robežās
        // kas atbilst visiem `add` nosacījumiem.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // DROŠĪBA: identiska `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // DROŠĪBA: tikko pārbaudījāt, vai `start` atrodas uz char robežas,
            // un mēs nododam drošu atsauci, tāpēc arī atgriešanās vērtība būs viena.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Īsteno apakšvirkņu sagriešanu ar sintaksi `&self[begin ..= end]` vai `&mut self[begin ..= end]`.
///
/// Atgriež norādītās virknes šķēli no baitu diapazona [`begin`, `end`].Ekvivalents `&self [begin .. end + 1]` vai `&mut self[begin .. end + 1]`, izņemot gadījumus, ja `end` ir `usize` maksimālā vērtība.
///
/// Šī darbība ir *O*(1).
///
/// # Panics
///
/// Panics, ja `begin` nenorāda uz rakstzīmes sākuma baita nobīdi (kā definējis `is_char_boundary`), ja `end` nenorāda uz rakstzīmes beigu baita nobīdi (`end + 1` ir vai nu sākuma baita nobīde, vai vienāda ar `len`), ja `begin > end` vai ja `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // DROŠĪBA: zvanītājam jāievēro `get_unchecked` drošības līgums.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // DROŠĪBA: zvanītājam jāievēro `get_unchecked_mut` drošības līgums.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Īsteno apakšvirkņu sagriešanu ar sintaksi `&self[..= end]` vai `&mut self[..= end]`.
///
/// Atgriež norādītās virknes šķēli no baitu diapazona [0, `end`].
/// Ekvivalents `&self [0 .. end + 1]`, izņemot gadījumus, ja `end` ir `usize` maksimālā vērtība.
///
/// Šī darbība ir *O*(1).
///
/// # Panics
///
/// Panics, ja `end` nenorāda uz rakstzīmes beigu baita nobīdi (`end + 1` ir vai nu sākuma baita nobīde, kā definēts `is_char_boundary`, vai vienāda ar `len`), vai arī, ja `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // DROŠĪBA: zvanītājam jāievēro `get_unchecked` drošības līgums.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // DROŠĪBA: zvanītājam jāievēro `get_unchecked_mut` drošības līgums.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Parsējiet vērtību no virknes
///
/// `FromStr` [`from_str`] metodi bieži izmanto netieši, izmantojot [`str`] [`parse`] metodi.
/// Piemērus skatiet [parsēšanas] dokumentācijā.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` nav mūža parametra, un tāpēc jūs varat parsēt tikai tos tipus, kas paši nesatur mūža parametru.
///
/// Citiem vārdiem sakot, jūs varat parsēt `i32` ar `FromStr`, bet ne `&i32`.
/// Varat parsēt struktūru, kas satur `i32`, bet ne tādu, kas satur `&i32`.
///
/// # Examples
///
/// `FromStr` pamata ieviešana `Point` tipa piemērā:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// Saistītā kļūda, kuru var atgriezt parsējot.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Parsē virkni `s`, lai atgrieztu šāda veida vērtību.
    ///
    /// Ja parsēšana ir veiksmīga, atgrieziet vērtību [`Ok`] iekšienē, pretējā gadījumā, ja virkne ir nepareizi formatēta, atgrieziet kļūdu, kas raksturīga iekšējam [`Err`].
    /// Kļūdas veids ir raksturīgs trait ieviešanai.
    ///
    /// # Examples
    ///
    /// Pamata lietojums ar [`i32`], tips, kas ievieš `FromStr`:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Parsējiet `bool` no virknes.
    ///
    /// Iegūst `Result<bool, ParseBoolError>`, jo `s` var būt vai nevar būt parsējams.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Ņemiet vērā, ka daudzos gadījumos `.parse()` metode `str` ir piemērotāka.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}