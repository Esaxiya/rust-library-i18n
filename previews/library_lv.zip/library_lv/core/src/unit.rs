use crate::iter::FromIterator;

/// Sakļauj visus vienības vienumus no iteratora vienā.
///
/// Tas ir noderīgāk, ja to apvieno ar augstāka līmeņa abstrakcijām, piemēram, kolekcionēšanu `Result<(), E>`, kur jums rūp tikai kļūdas:
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}