Panics pašreizējo pavedienu.

Tas ļauj programmai nekavējoties pārtraukt darbību un sniegt atsauksmes programmas zvanītājam.
`panic!` jāizmanto, kad programma nonāk neatjaunojamā stāvoklī.

Šis makro ir ideāls veids, kā noteikt nosacījumus koda piemērā un testos.
`panic!` ir cieši saistīts ar `unwrap` un [`Result`][runwrap] enumu metodi `unwrap`.
Abas realizācijas izsauc `panic!`, ja tās ir iestatītas uz [`None`] vai [`Err`] variantiem.

Izmantojot `panic!()`, varat norādīt virknes lietderīgo slodzi, kas veidota, izmantojot [`format!`] sintaksi.
Šī lietderīgā slodze tiek izmantota, injicējot panic izsaucošajā Rust pavedienā, izraisot pavedienu pilnībā panic.

Noklusējuma `std` hook uzvedība, ti
Kods, kas darbojas tieši pēc panic izsaukšanas, ir drukāt ziņojuma lietderīgo slodzi uz `stderr` kopā ar `panic!()` zvana informāciju file/line/column.

Izmantojot [`std::panic::set_hook()`], varat ignorēt panic hook.
hook iekšpusē panic var piekļūt kā `&dyn Any + Send`, kas satur `&str` vai `String` regulārām `panic!()` izsaukšanām.
panic ar cita veida vērtību var izmantot [`panic_any`].

[`Result`] enum bieži ir labāks risinājums, lai atkoptu kļūdas, nekā izmantojot `panic!` makro.
Šis makro jāizmanto, lai izvairītos no nepareizu vērtību izmantošanas, piemēram, no ārējiem avotiem.
Detalizēta informācija par kļūdu apstrādi ir atrodama [book].

Skatiet arī makro [`compile_error!`], lai apkopotu kļūdas.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Pašreizējā ieviešana

Ja galvenais pavediens panics pārtrauks visus pavedienus un beigs programmu ar kodu `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





