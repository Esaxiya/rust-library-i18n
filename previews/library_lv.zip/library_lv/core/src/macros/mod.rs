#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Izplešas uz `$crate::panic::panic_2015` vai `$crate::panic::panic_2021` atkarībā no zvanītāja izdevuma.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Apgalvo, ka divas izteiksmes ir vienādas viena ar otru (izmantojot [`PartialEq`]).
///
/// Vietnē panic šis makro izdrukās izteicienu vērtības ar atkļūdošanas attēliem.
///
///
/// Tāpat kā [`assert!`], arī šim makro ir otrā forma, kur var sniegt pielāgotu panic ziņojumu.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Zemāk minētie pārņemtie līdzekļi ir tīši.
                    // Bez tiem aizņēmuma kaudze tiek inicializēta pat pirms vērtību salīdzināšanas, kas noved pie ievērojama palēnināšanās.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Zemāk minētie pārņemtie līdzekļi ir tīši.
                    // Bez tiem aizņēmuma kaudze tiek inicializēta pat pirms vērtību salīdzināšanas, kas noved pie ievērojama palēnināšanās.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Apgalvo, ka divas izteiksmes nav vienādas viena ar otru (izmantojot [`PartialEq`]).
///
/// Vietnē panic šis makro izdrukās izteicienu vērtības ar atkļūdošanas attēliem.
///
///
/// Tāpat kā [`assert!`], arī šim makro ir otrā forma, kur var sniegt pielāgotu panic ziņojumu.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Zemāk minētie pārņemtie līdzekļi ir tīši.
                    // Bez tiem aizņēmuma kaudze tiek inicializēta pat pirms vērtību salīdzināšanas, kas noved pie ievērojama palēnināšanās.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Zemāk minētie pārņemtie līdzekļi ir tīši.
                    // Bez tiem aizņēmuma kaudze tiek inicializēta pat pirms vērtību salīdzināšanas, kas noved pie ievērojama palēnināšanās.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Apgalvo, ka būla izteiksme izpildlaikā ir `true`.
///
/// Tas izsauks [`panic!`] makro, ja sniegto izteiksmi izpildes laikā nevar novērtēt ar `true`.
///
/// Tāpat kā [`assert!`], arī šai makro ir otrā versija, kur var sniegt pielāgotu panic ziņojumu.
///
/// # Uses
///
/// Atšķirībā no [`assert!`], `debug_assert!` priekšraksti pēc noklusējuma tiek iespējoti tikai neoptimizētos būvējumos.
/// Optimizēta būvēšana neizpildīs `debug_assert!` paziņojumus, ja `-C debug-assertions` netiks nodota kompilatoram.
/// Tas padara `debug_assert!` noderīgu pārbaudēm, kas ir pārāk dārgas, lai tās būtu laidiena būvē, bet var būt noderīgas izstrādes laikā.
/// `debug_assert!` paplašināšanas rezultāts vienmēr tiek pārbaudīts pēc veida.
///
/// Nepārbaudīts apgalvojums ļauj programmai, kas atrodas nekonsekventā stāvoklī, turpināt darboties, kam varētu būt negaidītas sekas, taču tas neievieš nedrošību, ja vien tas notiek tikai drošajā kodā.
///
/// Apgalvojumu snieguma izmaksas tomēr nav izmērāmas.
/// Tādējādi [`assert!`] aizstāšana ar `debug_assert!` ir ieteicama tikai pēc rūpīgas profilēšanas un, vēl svarīgāk, tikai drošā kodā!
///
/// # Examples
///
/// ```
/// // panic ziņojums šiem apgalvojumiem ir norādītās izteiksmes stingrākā vērtība.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // ļoti vienkārša funkcija
/// debug_assert!(some_expensive_computation());
///
/// // apgalvot ar pielāgotu ziņojumu
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Apgalvo, ka divi izteicieni ir vienādi viens ar otru.
///
/// Vietnē panic šis makro izdrukās izteicienu vērtības ar atkļūdošanas attēliem.
///
/// Atšķirībā no [`assert_eq!`], `debug_assert_eq!` priekšraksti pēc noklusējuma tiek iespējoti tikai neoptimizētos būvējumos.
/// Optimizēta būvēšana neizpildīs `debug_assert_eq!` paziņojumus, ja `-C debug-assertions` netiks nodota kompilatoram.
/// Tas padara `debug_assert_eq!` noderīgu pārbaudēm, kas ir pārāk dārgas, lai tās būtu laidiena būvē, bet var būt noderīgas izstrādes laikā.
///
/// `debug_assert_eq!` paplašināšanas rezultāts vienmēr tiek pārbaudīts pēc veida.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Apgalvo, ka divi izteicieni nav vienādi viens ar otru.
///
/// Vietnē panic šis makro izdrukās izteicienu vērtības ar atkļūdošanas attēliem.
///
/// Atšķirībā no [`assert_ne!`], `debug_assert_ne!` priekšraksti pēc noklusējuma tiek iespējoti tikai neoptimizētos būvējumos.
/// Optimizēta būvēšana neizpildīs `debug_assert_ne!` paziņojumus, ja `-C debug-assertions` netiks nodota kompilatoram.
/// Tas padara `debug_assert_ne!` noderīgu pārbaudēm, kas ir pārāk dārgas, lai tās būtu laidiena būvē, bet var būt noderīgas izstrādes laikā.
///
/// `debug_assert_ne!` paplašināšanas rezultāts vienmēr tiek pārbaudīts pēc veida.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Atgriež, vai dotā izteiksme atbilst kādam no dotajiem modeļiem.
///
/// Tāpat kā `match` izteiksmē, pēc modeļa pēc izvēles var sekot `if` un aizsargājoša izteiksme, kurai ir piekļuve nosaukumiem, kurus saista raksts.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Atsauc rezultātu vai izplata tā kļūdu.
///
/// Operators `?` tika pievienots, lai aizstātu `try!`, un tā vietā to vajadzētu izmantot.
/// Turklāt `try` ir rezervēts vārds Rust 2018, tādēļ, ja jums tas jāizmanto, jums būs jāizmanto [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` atbilst dotajam [`Result`].`Ok` varianta gadījumā izteiksmei ir ietītās vērtības vērtība.
///
/// `Err` varianta gadījumā tas izgūst iekšējo kļūdu.Pēc tam `try!` veic konvertēšanu, izmantojot `From`.
/// Tas nodrošina automātisku pārveidošanu starp specializētām kļūdām un vispārīgākām kļūdām.
/// Iegūtā kļūda tiek nekavējoties atgriezta.
///
/// Agrīnas atgriešanās dēļ `try!` var izmantot tikai funkcijās, kas atgriež [`Result`].
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Vēlamā kļūdu ātras atdošanas metode
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Iepriekšējā kļūdu ātras atdošanas metode
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Tas ir līdzvērtīgs:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Raksta formatētus datus buferī.
///
/// Šis makro pieņem 'writer', formāta virkni un argumentu sarakstu.
/// Argumenti tiks formatēti atbilstoši norādītajai formāta virknei, un rezultāts tiks nodots rakstniekam.
/// Rakstītājs var būt jebkura vērtība ar `write_fmt` metodi;parasti tas nāk no [`fmt::Write`] vai [`io::Write`] trait ieviešanas.
/// Makro atgriež visu, ko atgriež metode `write_fmt`;parasti [`fmt::Result`] vai [`io::Result`].
///
/// Skatiet [`std::fmt`], lai iegūtu papildinformāciju par formāta virknes sintaksi.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Modulis var importēt gan `std::fmt::Write`, gan `std::io::Write` un izsaukt `write!` objektos, kuri realizē vienu vai otru, jo objekti parasti neievieš abus.
///
/// Tomēr modulim ir jāimportē kvalificēts traits, lai viņu nosaukumi nebūtu pretrunā:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // izmanto fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // izmanto io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Šo makro var izmantot arī `no_std` iestatījumos.
/// `no_std` iestatījumos esat atbildīgs par detaļu ieviešanas detaļām.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Rakstiet formatētus datus buferī, pievienojot jaunu rindiņu.
///
/// Visās platformās jaunā līnija ir tikai LINE FEED raksturs (`\n`/`U+000A`) (bez papildu CARRIAGE RETURN (`\r`/`U+000D`).
///
/// Lai iegūtu papildinformāciju, skatiet [`write!`].Informāciju par formāta virknes sintaksi skatiet [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Modulis var importēt gan `std::fmt::Write`, gan `std::io::Write` un izsaukt `write!` objektos, kuri realizē vienu vai otru, jo objekti parasti neievieš abus.
/// Tomēr modulim ir jāimportē kvalificēts traits, lai viņu nosaukumi nebūtu pretrunā:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // izmanto fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // izmanto io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Norāda nesasniedzamu kodu.
///
/// Tas ir noderīgi jebkurā laikā, kad kompilators nevar noteikt, ka kāds kods nav sasniedzams.Piemēram:
///
/// * Pielāgojiet ieročus ar aizsargiem.
/// * Cilpas, kas dinamiski izbeidzas.
/// * Iteratori, kas dinamiski izbeidzas.
///
/// Ja konstatējums, ka kods nav sasniedzams, izrādās nepareiza, programma nekavējoties tiek pārtraukta ar [`panic!`].
///
/// Šīs makro nedrošais līdzinieks ir funkcija [`unreachable_unchecked`], kas, koda sasniegšanas gadījumā, izraisīs nedefinētu rīcību.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Tas vienmēr būs [`panic!`].
///
/// # Examples
///
/// Spēļu ieroči:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // sastādīt kļūdu, ja to komentē
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // viena no visnabadzīgākajām x/3 ieviešanām
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Norāda neīstenotu kodu, krītot ar "not implemented" ziņojumu.
///
/// Tas ļauj jūsu kodam veikt tipa pārbaudi, kas ir noderīgi, ja veidojat prototipu vai īstenojat trait, kam nepieciešamas vairākas metodes, kuras jūs neplānojat izmantot visas.
///
/// Atšķirība starp `unimplemented!` un [`todo!`] ir tāda, ka, lai gan `todo!` norāda uz nodomu vēlāk ieviest funkcionalitāti un ziņojums ir "not yet implemented", `unimplemented!` šādas pretenzijas neizvirza.
/// Tās ziņojums ir "not implemented".
/// Arī daži IDE atzīmēs `todo!`.
///
/// # Panics
///
/// Tas vienmēr būs [`panic!`], jo `unimplemented!` ir tikai stenogrāfs `panic!` ar fiksētu, specifisku ziņojumu.
///
/// Tāpat kā `panic!`, arī šim makro ir otra forma pielāgotu vērtību parādīšanai.
///
/// # Examples
///
/// Pieņemsim, ka mums ir trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Mēs vēlamies ieviest `Foo` operētājsistēmai 'MyStruct', taču nez kāpēc ir jēga ieviest tikai funkciju `bar()`.
/// `baz()` un `qux()` joprojām būs jādefinē, īstenojot `Foo`, taču to definīcijās mēs varam izmantot `unimplemented!`, lai mūsu kods varētu apkopot.
///
/// Mēs joprojām vēlamies, lai mūsu programma tiktu pārtraukta, ja tiek sasniegtas neīstenotās metodes.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // `baz` un `MyStruct` nav jēgas, tāpēc mums šeit vispār nav loģikas.
/////
///         // Tas parādīs "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Šeit mums ir kāda loģika, mēs varam pievienot ziņojumu neizpildītam!lai parādītu mūsu izlaidumu.
///         // Tas parādīs: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Norāda nepabeigtu kodu.
///
/// Tas var būt noderīgi, ja veidojat prototipus un vienkārši vēlaties, lai jūsu kods tiktu pārbaudīts.
///
/// Atšķirība starp [`unimplemented!`] un `todo!` ir tāda, ka, lai gan `todo!` norāda uz nodomu vēlāk ieviest funkcionalitāti un ziņojums ir "not yet implemented", `unimplemented!` šādas pretenzijas neizvirza.
/// Tās ziņojums ir "not implemented".
/// Arī daži IDE atzīmēs `todo!`.
///
/// # Panics
///
/// Tas vienmēr būs [`panic!`].
///
/// # Examples
///
/// Lūk, kāda nepabeigta koda piemērs.Mums ir trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Mēs vēlamies ieviest `Foo` vienā no mūsu veidiem, bet vispirms mēs vēlamies strādāt tikai pie `bar()`.Lai mūsu kods varētu apkopot, mums jāievieš `baz()`, lai mēs varētu izmantot `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // ieviešana notiek šeit
///     }
///
///     fn baz(&self) {
///         // pagaidām neuztraucamies par baz() ieviešanu
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // mēs pat neizmantojam baz(), tāpēc tas ir lieliski.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Iebūvēto makro definīcijas.
///
/// Lielākā daļa makro rekvizītu (stabilitāte, redzamība utt.) Ir ņemti no avota koda šeit, izņemot paplašināšanas funkcijas, kas pārveido makro ievades izvadēs, šīs funkcijas nodrošina kompilators.
///
///
pub(crate) mod builtin {

    /// Izraisa kompilācijas izgāšanos, izmantojot norādīto kļūdas ziņojumu.
    ///
    /// Šis makro ir jāizmanto, ja crate izmanto nosacītu kompilēšanas stratēģiju, lai nodrošinātu labākus kļūdu ziņojumus kļūdainos apstākļos.
    ///
    /// Tā ir [`panic!`] kompilatora līmeņa forma, taču tā rada kļūdu *kompilācijas* laikā, nevis *izpildlaika* laikā.
    ///
    /// # Examples
    ///
    /// Divi šādi piemēri ir makro un `#[cfg]` vide.
    ///
    /// Izraisiet labāku kompilatora kļūdu, ja makro tiek nodotas nederīgas vērtības.
    /// Bez galīgā branch kompilators joprojām izdotu kļūdu, taču kļūdas ziņojumā nebūtu minētas divas derīgās vērtības.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Izraidiet kompilatora kļūdu, ja kāda no vairākām funkcijām nav pieejama.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Konstruē parametrus citiem virknes formatēšanas makro.
    ///
    /// Šis makro darbojas, katram papildu nodotajam argumentam paņemot formatēšanas virknes burtu, kas satur `{}`.
    /// `format_args!` sagatavo papildu parametrus, lai nodrošinātu, ka izvadi var interpretēt kā virkni, un kanonizē argumentus vienā tipā.
    /// Jebkuru vērtību, kas ievieš [`Display`] trait, var nodot `format_args!`, tāpat kā jebkuru [`Debug`] ieviešanu var nodot `{:?}` formatēšanas virknē.
    ///
    ///
    /// Šis makro rada [`fmt::Arguments`] tipa vērtību.Lai veiktu noderīgu novirzīšanu, šo vērtību var nodot makro [`std::fmt`] ietvaros.
    /// Visi pārējie formatēšanas makro ([`format!`], [`write!`], [`println!`] utt.) Tiek tuvināti caur šo.
    /// `format_args!`, atšķirībā no atvasinātajiem makro, izvairās no kaudzes piešķiršanas.
    ///
    /// Varat izmantot vērtību [`fmt::Arguments`], kuru `format_args!` atgriež kontekstā `Debug` un `Display`, kā redzams zemāk.
    /// Piemērs arī parāda, ka `Debug` un `Display` formatē vienu un to pašu: interpolēto formāta virkni `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Lai iegūtu papildinformāciju, skatiet dokumentāciju [`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Tas pats, kas `format_args`, bet beigās pievieno jaunu rindu.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Apkopošanas laikā pārbauda vides mainīgo.
    ///
    /// Šis makro tiks izvērsts līdz nosauktā vides mainīgā vērtībai sastādīšanas laikā, iegūstot `&'static str` tipa izteiksmi.
    ///
    ///
    /// Ja vides mainīgais nav definēts, tiks parādīta kompilācijas kļūda.
    /// Lai neizdotu kompilēšanas kļūdu, tā vietā izmantojiet [`option_env!`] makro.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Kļūdas ziņojumu var pielāgot, kā otro parametru nododot virkni:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Ja `documentation` vides mainīgais nav definēts, tiks parādīta šāda kļūda:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Pēc izvēles kompilēšanas laikā pārbauda vides mainīgo.
    ///
    /// Ja nosauktais vides mainīgais ir kompilēšanas laikā, tas tiks paplašināts līdz `Option<&'static str>` tipa izteiksmei, kuras vērtība ir `Some` no vides mainīgā vērtības.
    /// Ja vides mainīgais nav pieejams, tas tiks paplašināts līdz `None`.
    /// Plašāku informāciju par šo veidu skatiet [`Option<T>`][Option].
    ///
    /// Kompilācijas laika kļūda, izmantojot šo makro, nekad netiek emitēta neatkarīgi no tā, vai ir pieejams vides mainīgais.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Apvieno identifikatorus vienā identifikatorā.
    ///
    /// Šajā makro tiek ņemts jebkurš skaits ar komatiem atdalītu identifikatoru un tie visi tiek apvienoti vienā, iegūstot izteiksmi, kas ir jauns identifikators.
    /// Ņemiet vērā, ka higiēna padara to tādu, ka šis makro nevar uztvert vietējos mainīgos.
    /// Turklāt makro ir atļauts izmantot tikai vienuma, paziņojuma vai izteiksmes pozīcijā.
    /// Tas nozīmē, ka, lai gan jūs varat izmantot šo makro, atsaucoties uz esošajiem mainīgajiem, funkcijām vai moduļiem utt., Ar to nevar definēt jaunu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (jauns, jautrs, nosaukums) { }//šādā veidā nav izmantojams!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Saīsina literāļus statiskā virknes šķēlītē.
    ///
    /// Šis makro aizņem jebkuru skaitu ar komatiem atdalītu literāļu, iegūstot `&'static str` tipa izteiksmi, kas apzīmē visus burtniekus, kas savienoti no kreisās uz labo pusi.
    ///
    ///
    /// Lai sasietu, ir jānosaka veselā un peldošā komata literāļi.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Izvēršas līdz rindas numuram, uz kuru tas tika izsaukts.
    ///
    /// Izmantojot [`column!`] un [`file!`], šie makro sniedz izstrādātājiem atkļūdošanas informāciju par atrašanās vietu avotā.
    ///
    /// Izvērstajai izteiksmei ir `u32` tips un tā ir balstīta uz 1, tāpēc katra faila pirmā rinda tiek novērtēta kā 1, otrā-2 utt.
    /// Tas atbilst kļūdu ziņojumiem, ko izsniedz kopīgi sastādītāji vai populāri redaktori.
    /// Atgrieztā līnija *nav obligāti* pašas `line!` izsaukuma līnija, bet gan pirmā makro izsaukšana, kas noved pie `line!` makro izsaukšanas.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Izvēršas līdz kolonnas numuram, ar kuru tas tika izsaukts.
    ///
    /// Izmantojot [`line!`] un [`file!`], šie makro sniedz izstrādātājiem atkļūdošanas informāciju par atrašanās vietu avotā.
    ///
    /// Izvērstajai izteiksmei ir `u32` tips un tā ir balstīta uz 1, tāpēc katras rindas pirmā kolonna tiek novērtēta kā 1, otrā-2 utt.
    /// Tas atbilst kļūdu ziņojumiem, ko izsniedz kopīgi sastādītāji vai populāri redaktori.
    /// Atgrieztā kolonna *nav obligāti* paša `column!` izsaukuma līnija, bet gan pirmā makro izsaukšana, kas noved pie `column!` makro izsaukšanas.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Izvēršas līdz faila nosaukumam, kurā tas tika izsaukts.
    ///
    /// Izmantojot [`line!`] un [`column!`], šie makro sniedz izstrādātājiem atkļūdošanas informāciju par atrašanās vietu avotā.
    ///
    /// Izvērstajai izteiksmei ir `&'static str` tips, un atgrieztais fails nav paša `file!` makro izsaukums, bet gan pirmais makro izsaukums, kas noved pie `file!` makro izsaukšanas.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Stingrina savus argumentus.
    ///
    /// Šis makro iegūs `&'static str` tipa izteiksmi, kas ir visu makro pārsūtīto tokens virkņu virkne.
    /// Paša makro izsaukuma sintaksei nav noteikti ierobežojumi.
    ///
    /// Ņemiet vērā, ka izvērstie ievades tokens rezultāti var mainīties future.Jums vajadzētu būt uzmanīgiem, ja paļaujaties uz rezultātu.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Iekļauj UTF-8 kodētu failu kā virkni.
    ///
    /// Fails atrodas attiecībā pret pašreizējo failu (līdzīgi tam, kā tiek atrasti moduļi).
    /// Sniegtais ceļš kompilēšanas laikā tiek interpretēts platformai raksturīgā veidā.
    /// Tā, piemēram, izsaukums ar Windows ceļu, kas satur atpakaļsvītras `\`, netiks pareizi apkopots Unix.
    ///
    ///
    /// Šis makro iegūs `&'static str` tipa izteiksmi, kas ir faila saturs.
    ///
    /// # Examples
    ///
    /// Pieņemsim, ka vienā direktorijā ir divi faili ar šādu saturu:
    ///
    /// Fails 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Fails 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// Apkopojot 'main.rs' un palaižot iegūto bināro failu, tiks izdrukāts "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Iekļauts fails kā atsauce uz baitu masīvu.
    ///
    /// Fails atrodas attiecībā pret pašreizējo failu (līdzīgi tam, kā tiek atrasti moduļi).
    /// Sniegtais ceļš kompilēšanas laikā tiek interpretēts platformai raksturīgā veidā.
    /// Tā, piemēram, izsaukums ar Windows ceļu, kas satur atpakaļsvītras `\`, netiks pareizi apkopots Unix.
    ///
    ///
    /// Šis makro iegūs `&'static [u8; N]` tipa izteiksmi, kas ir faila saturs.
    ///
    /// # Examples
    ///
    /// Pieņemsim, ka vienā direktorijā ir divi faili ar šādu saturu:
    ///
    /// Fails 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Fails 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// Apkopojot 'main.rs' un palaižot iegūto bināro failu, tiks izdrukāts "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Izvēršas līdz virknei, kas apzīmē pašreizējo moduļa ceļu.
    ///
    /// Pašreizējo moduļu ceļu var uzskatīt par moduļu hierarhiju, kas ved atpakaļ uz crate root.
    /// Pirmā atgrieztā ceļa sastāvdaļa ir pašlaik apkopojamā crate nosaukums.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Novērtē konfigurācijas karodziņu būla kombinācijas sastādīšanas laikā.
    ///
    /// Papildus atribūtam `#[cfg]` šis makro ir paredzēts, lai ļautu konfigurācijas karodziņus novērtēt Būla izteiksmē.
    /// Tas bieži noved pie tā, ka kods tiek dublēts mazāk.
    ///
    /// Šai makro dotā sintakse ir tāda pati sintakse kā [`cfg`] atribūts.
    ///
    /// `cfg!`, atšķirībā no `#[cfg]`, nenoņem nevienu kodu un novērtē tikai patiesu vai nepatiesu.
    /// Piemēram, visiem if/else izteiksmes blokiem jābūt derīgiem, ja nosacījumam tiek izmantota `cfg!`, neatkarīgi no tā, ko `cfg!` vērtē.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Parsē failu kā izteiksmi vai vienumu atbilstoši kontekstam.
    ///
    /// Fails atrodas attiecībā pret pašreizējo failu (līdzīgi tam, kā tiek atrasti moduļi).Sniegtais ceļš kompilēšanas laikā tiek interpretēts platformai raksturīgā veidā.
    /// Tā, piemēram, izsaukums ar Windows ceļu, kas satur atpakaļsvītras `\`, netiks pareizi apkopots Unix.
    ///
    /// Šī makro izmantošana bieži ir slikta ideja, jo, ja fails tiek parsēts kā izteiksme, to nehigiēniski ievietos apkārtējā kodā.
    /// Tā rezultātā mainīgie vai funkcijas var atšķirties no gaidītā faila, ja pašreizējā failā ir mainīgie vai funkcijas, kurām ir tāds pats nosaukums.
    ///
    ///
    /// # Examples
    ///
    /// Pieņemsim, ka vienā direktorijā ir divi faili ar šādu saturu:
    ///
    /// Fails 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Fails 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// Apkopojot 'main.rs' un palaižot iegūto bināro failu, tiks izdrukāts "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Apgalvo, ka būla izteiksme izpildlaikā ir `true`.
    ///
    /// Tas izsauks [`panic!`] makro, ja sniegto izteiksmi izpildes laikā nevar novērtēt ar `true`.
    ///
    /// # Uses
    ///
    /// Apgalvojumus vienmēr pārbauda gan atkļūdošanas, gan laidienu versijās, un tos nevar atspējot.
    /// Apstiprinājumus, kas pēc noklusējuma nav iespējoti laidienu būvējumos, skatiet [`debug_assert!`].
    ///
    /// Nedrošs kods var paļauties uz `assert!`, lai izpildītu izpildlaika invariantus, kas pārkāpuma gadījumā var izraisīt nedrošību.
    ///
    /// Citi `assert!` lietošanas gadījumi ietver izpildes laika invariantu testēšanu un ieviešanu drošajā kodā (kuru pārkāpums nevar izraisīt nedrošību).
    ///
    ///
    /// # Pielāgoti ziņojumi
    ///
    /// Šim makro ir otrā forma, kur pielāgotu panic ziņojumu var sniegt ar argumentiem vai bez formatēšanas.
    /// Šīs formas sintaksi skatiet [`std::fmt`].
    /// Izteiksmes, kas tiek izmantotas kā formāta argumenti, tiks vērtētas tikai tad, ja apgalvojums neizdosies.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // panic ziņojums šiem apgalvojumiem ir norādītās izteiksmes stingrākā vērtība.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // ļoti vienkārša funkcija
    ///
    /// assert!(some_computation());
    ///
    /// // apgalvot ar pielāgotu ziņojumu
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Iekšējā montāža.
    ///
    /// Izlasiet [unstable book] lietošanai.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// LLVM stila inline montāža.
    ///
    /// Izlasiet [unstable book] lietošanai.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Moduļa līmeņa iekšējā montāža.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Drukājumi nodeva tokens standarta izvadē.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Iespējo vai atspējo izsekošanas funkcionalitāti, ko izmanto citu makro atkļūdošanai.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Atribūtu makro, ko izmanto atvasināšanas makro lietošanai.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Funkcijai piemērots atribūtu makro, lai to pārvērstu par vienības testu.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Funkcijai piemērots atribūtu makro, lai to pārvērstu par etalona testu.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// `#[test]` un `#[bench]` makro ieviešanas detaļa.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Atribūtu makro, kas piemērots statikai, lai reģistrētu to kā globālo sadalītāju.
    ///
    /// Skatiet arī [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Saglabā vienumu, kuram tas tiek piemērots, ja nodotajam ceļam var piekļūt, un citādi noņem.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Paplašina visus `#[cfg]` un `#[cfg_attr]` atribūtus koda fragmentā, uz kuru tas tiek lietots.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Nestabila `rustc` kompilatora ieviešanas detaļa, nelietot.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Nestabila `rustc` kompilatora ieviešanas detaļa, nelietot.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}