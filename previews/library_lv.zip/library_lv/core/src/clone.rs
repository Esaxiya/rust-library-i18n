//! `Clone` trait tipiem, kurus nevar `netieši nokopēt`.
//!
//! Programmā Rust daži vienkārši veidi ir "implicitly copyable", un, tos piešķirot vai nododot kā argumentus, uztvērējs saņems kopiju, atstājot sākotnējo vērtību vietā.
//! Šiem tipiem nav nepieciešams piešķīrums kopēšanai un tiem nav pabeigšanas ierīču (ti, tajos nav īpašumā esošu lodziņu vai [`Drop`] ieviešanas rīku), tāpēc kompilators tos uzskata par lētiem un drošiem kopēšanai.
//!
//! Citu veidu kopijām jābūt skaidri izgatavotām, pēc vienošanās ieviešot [`Clone`] trait un izsaucot metodi [`clone`].
//!
//! [`clone`]: Clone::clone
//!
//! Pamata lietošanas piemērs:
//!
//! ```
//! let s = String::new(); // Stīgu tipa instrumenti Klons
//! let copy = s.clone(); // lai mēs to varētu klonēt
//! ```
//!
//! Lai ērti ieviestu Clone trait, varat izmantot arī `#[derive(Clone)]`.Piemērs:
//!
//! ```
//! #[derive(Clone)] // mēs pievienojam Clone trait Morfeja struktūrai
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // un tagad mēs to varam klonēt!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// Parasta trait spēja skaidri dublēt objektu.
///
/// Atšķiras no [`Copy`] ar to, ka [`Copy`] ir netiešs un ārkārtīgi lēts, savukārt `Clone` vienmēr ir nepārprotams un var arī nebūt dārgs.
/// Lai ieviestu šīs īpašības, Rust neļauj atjaunot [`Copy`], bet jūs varat atjaunot `Clone` un palaist patvaļīgu kodu.
///
/// Tā kā `Clone` ir vispārīgāks nekā [`Copy`], jūs varat automātiski padarīt visu [`Copy`] arī par `Clone`.
///
/// ## Derivable
///
/// Šo trait var izmantot ar `#[derive]`, ja visi lauki ir `Clone`.[`Clone`] ieviešana katrā laukā izsauc [`clone`].
///
/// [`clone`]: Clone::clone
///
/// Vispārīgai struktūrai `#[derive]` `Clone` ievieš nosacīti, pievienojot saistīto `Clone` vispārējiem parametriem.
///
/// ```
/// // `derive` ievieš klonu lasīšanai<T>kad T ir klons.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Kā es varu ieviest `Clone`?
///
/// [`Copy`] tipiem vajadzētu būt niecīgai `Clone` ieviešanai.Formālāk:
/// ja `T: Copy`, `x: T` un `y: &T`, tad `let x = y.clone();` ir ekvivalents `let x = *y;`.
/// Manuālai ieviešanai jābūt uzmanīgai, lai uzturētu šo nemainīgo;tomēr nedrošs kods nedrīkst paļauties uz to, lai nodrošinātu atmiņas drošību.
///
/// Piemērs ir vispārīgs struktūras elements, kas tur funkciju rādītāju.Šajā gadījumā `Clone` ieviešanu nevar "atvasināt", bet to var īstenot kā:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Papildu ieviesēji
///
/// Papildus [implementors listed below][impls] `Clone` ievieš arī šādi tipi:
///
/// * Funkciju vienumu veidi (ti, katrai funkcijai noteiktie atšķirīgie veidi)
/// * Funkciju rādītāju veidi (piem., `fn() -> i32`)
/// * Masīvu veidi visiem izmēriem, ja vienuma tips ievieš arī `Clone` (piem., `[i32; 123456]`)
/// * Tuple veidi, ja katrs komponents arī ievieš `Clone` (piemēram, `()`, `(i32, bool)`)
/// * Slēgšanas veidi, ja tie neuzņem nekādu vērtību no vides vai ja visas šādas uzņemtās vērtības pašas ievieš `Clone`.
///   Ņemiet vērā, ka mainīgie, kas uztverti ar kopīgu atsauci, vienmēr ievieš `Clone` (pat ja referents to nedara), bet mainīgie, kurus uztver mainīga atsauce, nekad neievieš `Clone`.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Atgriež vērtības kopiju.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str īsteno Klonu
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Veic kopēšanas piešķiršanu no `source`.
    ///
    /// `a.clone_from(&b)` funkcionalitātē ir līdzvērtīgs `a = b.clone()`, taču to var ignorēt, lai atkārtoti izmantotu `a` resursus, lai izvairītos no nevajadzīgas piešķiršanas.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Iegūstiet makro, ģenerējot trait `Clone` impliku.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): šos uzrakstus izmanto tikai#[atvasināt], lai apgalvotu, ka visi tipa komponenti īsteno klonu vai kopiju.
//
//
// Šie norādījumi nekad nedrīkst parādīties lietotāja kodā.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// `Clone` ieviešana primitīviem tipiem.
///
/// Īstenojumi, kurus nevar aprakstīt Rust, tiek ieviesti `traits::SelectionContext::copy_clone_conditions()` versijā `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Koplietotās atsauces var klonēt, bet mainīgās atsauces *nevar*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Koplietotās atsauces var klonēt, bet mainīgās atsauces *nevar*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}