#![stable(feature = "core_hint", since = "1.27.0")]

//! Padomi kompilatoram, kas ietekmē koda emitēšanu vai optimizēšanu.
//! Padomi var būt apkopošanas laiks vai izpildlaiks.

use crate::intrinsics;

/// Informē kompilatoru, ka šis koda punkts nav sasniedzams, ļaujot turpināt optimizāciju.
///
/// # Safety
///
/// Šīs funkcijas sasniegšana ir pilnīgi *nenoteikta uzvedība*(UB).Sastādītājs pieņem, ka visiem UB nekad nedrīkst notikt, un tāpēc tiks likvidētas visas filiāles, kas sasniedz zvanu uz `unreachable_unchecked()`.
///
/// Tāpat kā visi UB gadījumi, ja šis pieņēmums izrādās nepareizs, ti, `unreachable_unchecked()` izsaukums ir faktiski sasniedzams starp visām iespējamām vadības plūsmām, kompilators izmantos nepareizu optimizācijas stratēģiju un dažkārt var pat sabojāt šķietami nesaistītu kodu, izraisot sarežģītus atkļūdošanas problēmas.
///
///
/// Izmantojiet šo funkciju tikai tad, ja varat pierādīt, ka kods to nekad neizsauks.
/// Pretējā gadījumā apsveriet iespēju izmantot makro [`unreachable!`], kas neļauj veikt optimizāciju, bet izpildes laikā tas būs panic.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` vienmēr ir pozitīvs (nevis nulle), tāpēc `checked_div` nekad neatgriezīs `None`.
/////
///     // Tāpēc cits branch nav sasniedzams.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // DROŠĪBA: jāpievieno `intrinsics::unreachable` drošības līgums
    // jāuztur zvanītājam.
    unsafe { intrinsics::unreachable() }
}

/// Izstāda mašīnas instrukciju, lai signalizētu procesoram, ka tas darbojas aizņemtas gaidīšanas griešanās cilpā ("spin lock").
///
/// Saņemot spin-loop signālu, procesors var optimizēt savu darbību, piemēram, ietaupot enerģiju vai pārslēdzot hyper pavedienus.
///
/// Šī funkcija atšķiras no [`thread::yield_now`], kas tieši padodas sistēmas plānotājam, turpretim `spin_loop` nedarbojas ar operētājsistēmu.
///
/// `spin_loop` izplatīts izmantošanas gadījums ir ierobežotas optimistiskas vērpšanas ieviešana CAS lokā sinhronizācijas primitīvos.
/// Lai izvairītos no tādām problēmām kā prioritārā inversija, ir ļoti ieteicams pēc ierobežota daudzuma atkārtojumu izbeigt griešanās cilpu un veikt atbilstošu bloķējošu sistēmas zvanu.
///
///
/// **Piezīme**: Platformās, kas neatbalsta spin-loop saņemšanu, šī funkcija neko nedara.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // Kopīga atomu vērtība, kuru pavedieni izmantos, lai koordinētu
/// let live = Arc::new(AtomicBool::new(false));
///
/// // Fona pavedienā mēs galu galā iestatīsim vērtību
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Veiciet kādu darbu, pēc tam padariet vērtību dzīvu
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // Atgriežoties pie pašreizējā pavediena, mēs gaidām, kamēr tiks iestatīta vērtība
/// while !live.load(Ordering::Acquire) {
///     // Pagrieziena cilpa ir mājiens CPU, ko mēs gaidām, bet, iespējams, ne pārāk ilgi
/////
///     hint::spin_loop();
/// }
///
/// // Tagad vērtība ir iestatīta
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // DROŠĪBA: `cfg` attr nodrošina, ka mēs to izpildām tikai uz x86 mērķiem.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // DROŠĪBA: `cfg` attr nodrošina, ka mēs to izpildām tikai uz x86_64 mērķiem.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // DROŠĪBA: `cfg` attr nodrošina, ka mēs to izpildām tikai uz aarch64 mērķiem.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // DROŠĪBA: `cfg` attr nodrošina, ka mēs to izpildām tikai uz rokas mērķiem
            // ar v6 funkcijas atbalstu.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// Identitātes funkcija, kas *__ iesaka __* kompilatoram būt maksimāli pesimistiskam attiecībā uz to, ko `black_box` varētu darīt.
///
/// Atšķirībā no [`std::convert::identity`], Rust kompilators tiek aicināts pieņemt, ka `black_box` var izmantot `dummy` jebkurā iespējamā veidā, kas atļauts Rust kodam, neieviešot nenoteiktu uzvedību zvanīšanas kodā.
///
/// Šis rekvizīts padara `black_box` noderīgu koda rakstīšanai, kurā nav nepieciešama noteikta optimizācija, piemēram, etaloni.
///
/// Tomēr ņemiet vērā, ka `black_box` tiek nodrošināts (un to var piegādāt) tikai uz "best-effort" pamata.Tas, cik lielā mērā tas var bloķēt optimizācijas, var atšķirties atkarībā no izmantotās platformas un koda ģeneratora aizmugures.
/// Programmas nekādā ziņā nevar paļauties uz `black_box`*pareizībai*.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // Mums kaut kādā veidā "use" ir jāmaina arguments, LLVM nevar izpētīt, un mērķos, kas to atbalsta, mēs parasti varam izmantot iekšējo montāžu, lai to izdarītu.
    // LLVM interpretē inline montāžu, ka tā, labi, ir melnā kaste.
    // Šī nav vislielākā ieviešana, jo tā, iespējams, dezoptimizē vairāk, nekā mēs vēlamies, bet līdz šim tā ir pietiekami laba.
    //
    //

    #[cfg(not(miri))] // Tas ir tikai mājiens, tāpēc ir labi izlaist Miri.
    // DROŠĪBA: iekšējā montāža ir aizliegta.
    unsafe {
        // FIXME: Nevar izmantot `asm!`, jo tas neatbalsta MIPS un citas arhitektūras.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}