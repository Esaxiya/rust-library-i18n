//! impl char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// Augstākais derīgais koda punkts, kāds var būt `char`.
    ///
    /// `char` ir [Unicode Scalar Value], kas nozīmē, ka tas ir [Code Point], bet tikai tie, kas atrodas noteiktā diapazonā.
    /// `MAX` ir visaugstākais derīgais koda punkts, kas ir derīgs [Unicode Scalar Value].
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () tiek izmantots Unicode, lai attēlotu dekodēšanas kļūdu.
    ///
    /// Tas var notikt, piemēram, piešķirot slikti veidotus UTF-8 baitus [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy).
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// [Unicode](http://www.unicode.org/) versija, uz kuras balstās `char` un `str` metožu Unicode daļas.
    ///
    /// Regulāri tiek izlaistas jaunas Unicode versijas, un pēc tam tiek atjauninātas visas metodes standarta bibliotēkā atkarībā no Unicode.
    /// Tāpēc dažu `char` un `str` metožu uzvedība un šīs konstantes vērtība laika gaitā mainās.
    /// Tas *netiek* uzskatīts par lūzuma maiņu.
    ///
    /// Versiju numerācijas shēma ir paskaidrota [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// Izveido iteratoru virs UTF-16 kodētajiem koda punktiem `iter`, atgriežot nepāra aizstājējus kā "Err".
    ///
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// Dekoderu ar zaudējumiem var iegūt, aizstājot `Err` rezultātus ar aizstājējzīmi:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// Pārvērš `u32` par `char`.
    ///
    /// Ņemiet vērā, ka visas `char` ir derīgas [`u32`], un tās var nodot vienam ar
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Tomēr otrādi nav taisnība: ne visi derīgie [`u32`] ir derīgi`char`s.
    /// `from_u32()` atgriezīs `None`, ja ievade nav derīga `char` vērtība.
    ///
    /// Par šīs funkcijas nedrošu versiju, kas ignorē šīs pārbaudes, skatiet [`from_u32_unchecked`].
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// Atgriežot `None`, ja ievade nav derīga `char`:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// Pārvērš `u32` par `char`, ignorējot derīgumu.
    ///
    /// Ņemiet vērā, ka visas `char` ir derīgas [`u32`], un tās var nodot vienam ar
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Tomēr otrādi nav taisnība: ne visi derīgie [`u32`] ir derīgi`char`s.
    /// `from_u32_unchecked()` to ignorēs un akli metīs uz `char`, iespējams, izveidojot nederīgu.
    ///
    ///
    /// # Safety
    ///
    /// Šī funkcija nav droša, jo tā var veidot nederīgas `char` vērtības.
    ///
    /// Lai iegūtu drošu šīs funkcijas versiju, skatiet funkciju [`from_u32`].
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // DROŠĪBA: zvanītājam jāievēro drošības līgums.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Konvertē ciparu dotajā rādiusā uz `char`.
    ///
    /// Šeit 'radix' dažreiz sauc arī par 'base'.
    /// Divu rādiuss norāda bināro skaitli, desmit ciparu aiz komata un sešpadsmit sešpadsmito skaitli, lai iegūtu dažas kopīgas vērtības.
    ///
    /// Tiek atbalstīti patvaļīgi radiki.
    ///
    /// `from_digit()` atgriezīs `None`, ja ievadītais rādiuss nav cipars.
    ///
    /// # Panics
    ///
    /// Panics, ja radiks ir lielāks par 36.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // 11. decimāldaļa ir viens cipars 16. bāzē
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// Atgriežot `None`, ja ievade nav cipars:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// Braucot garām lielam radiksam, izraisot panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// Pārbauda, vai `char` ir cipars dotajā rādiusā.
    ///
    /// Šeit 'radix' dažreiz sauc arī par 'base'.
    /// Divu rādiuss norāda bināro skaitli, desmit ciparu aiz komata un sešpadsmit sešpadsmito skaitli, lai iegūtu dažas kopīgas vērtības.
    ///
    /// Tiek atbalstīti patvaļīgi radiki.
    ///
    /// Salīdzinot ar [`is_numeric()`], šī funkcija atpazīst tikai rakstzīmes `0-9`, `a-z` un `A-Z`.
    ///
    /// 'Digit' ir definēts kā tikai šādas rakstzīmes:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// Plašāku 'digit' izpratni skatiet [`is_numeric()`].
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics, ja radiks ir lielāks par 36.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// Braucot garām lielam radiksam, izraisot panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// Pārvērš `char` par ciparu dotajā rādiusā.
    ///
    /// Šeit 'radix' dažreiz sauc arī par 'base'.
    /// Divu rādiuss norāda bināro skaitli, desmit ciparu aiz komata un sešpadsmit sešpadsmito skaitli, lai iegūtu dažas kopīgas vērtības.
    ///
    /// Tiek atbalstīti patvaļīgi radiki.
    ///
    /// 'Digit' ir definēts kā tikai šādas rakstzīmes:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Atgriež `None`, ja `char` neattiecas uz ciparu dotajā rādiusā.
    ///
    /// # Panics
    ///
    /// Panics, ja radiks ir lielāks par 36.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Ne ciparu nodošana neizdodas:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// Braucot garām lielam radiksam, izraisot panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // kods tiek sadalīts šeit, lai uzlabotu izpildes ātrumu gadījumos, kad `radix` ir nemainīgs un 10 vai mazāks
        //
        let val = if likely(radix <= 10) {
            // Ja tas nav cipars, tiks izveidots skaitlis, kas lielāks par radix.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Atgriež iteratoru, kas dod rakstzīmes heksadecimālo Unicode aizbēgšanu kā `char`.
    ///
    /// Tas izvairīsies no rakstzīmēm ar formas 0Rust sintaksi formā `\u{NNNNNN}`, kur `NNNNNN` ir heksadecimāls attēlojums.
    ///
    ///
    /// # Examples
    ///
    /// Kā atkārtotājs:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Izmantojot `println!` tieši:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Abi ir līdzvērtīgi:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// Izmantojot `to_string`:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // vai 1. darbība nodrošina, ka c==0 kods aprēķina, ka viens cipars ir jādrukā, un (kas ir tas pats) novērš (31, 32) aizplūšanu
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // nozīmīgākā sešciparu rādītājs
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// Paplašināta `escape_debug` versija, kas pēc izvēles ļauj izvairīties no paplašinātās grafikas kodpunktiem.
    /// Tas ļauj mums labāk formatēt tādas rakstzīmes kā neatdalošās zīmes, kad tās atrodas virknes sākumā.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Atgriež iteratoru, kas dod burta burtisko aizbēgšanas kodu kā `char`.
    ///
    /// Tas izvairīsies no rakstzīmēm, kas līdzīgas `str` vai `char` ieviešanai `Debug`.
    ///
    ///
    /// # Examples
    ///
    /// Kā atkārtotājs:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Izmantojot `println!` tieši:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Abi ir līdzvērtīgi:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// Izmantojot `to_string`:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Atgriež iteratoru, kas dod burta burtisko aizbēgšanas kodu kā `char`.
    ///
    /// Noklusējums tiek izvēlēts ar neobjektivitāti pret tādu literāru ražošanu, kas ir likumīgi dažādās valodās, ieskaitot C++ 11 un līdzīgas C ģimenes valodas.
    /// Precīzi noteikumi ir:
    ///
    /// * Cilne ir izbēgta kā `\t`.
    /// * Atgriešanās no karietes tiek izlaista kā `\r`.
    /// * Rindas padeve ir izdzēsta kā `\n`.
    /// * Viens piedāvājums ir izdzēsts kā `\'`.
    /// * Divkāršais piedāvājums ir izdzēsts kā `\"`.
    /// * Backslash ir izbēgts kā `\\`.
    /// * Neviena rakstzīme diapazonā `izdrukājamā ASCII` `0x20` .. `0x7e` ieskaitot netiek aizvērta.
    /// * Visām pārējām rakstzīmēm tiek doti heksadecimālie Unicode aizbēgšanas gadījumi;skatiet [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Kā atkārtotājs:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Izmantojot `println!` tieši:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Abi ir līdzvērtīgi:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// Izmantojot `to_string`:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// Atgriež to baitu skaitu, kas šim `char` būtu nepieciešams, ja tas būtu kodēts UTF-8.
    ///
    /// Šis baitu skaits vienmēr ir no 1 līdz 4 ieskaitot.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// `&str` tips garantē, ka tā saturs ir UTF-8, un tāpēc mēs varam salīdzināt garumu, kas būtu nepieciešams, ja katrs koda punkts būtu attēlots kā `char` salīdzinājumā ar pašu `&str`:
    ///
    ///
    /// ```
    /// // kā čari
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // abus var attēlot kā trīs baitus
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // kā &str šie divi ir kodēti UTF-8
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // mēs varam redzēt, ka tie aizņem sešus baitus kopā ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... tāpat kā &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// Atgriež 16 bitu kodu vienību skaitu, kas šim `char` būtu nepieciešams, ja tas būtu kodēts UTF-16.
    ///
    ///
    /// Plašāku šīs koncepcijas skaidrojumu skatiet [`len_utf8()`] dokumentācijā.
    /// Šī funkcija ir spogulis, bet UTF-16, nevis UTF-8.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Kodē šo rakstzīmi kā UTF-8 paredzētajā baitu buferī un pēc tam atgriež bufera apakšslāni, kas satur kodēto rakstzīmi.
    ///
    ///
    /// # Panics
    ///
    /// Panics, ja buferis nav pietiekami liels.
    /// Četru garumu buferis ir pietiekami liels, lai kodētu jebkuru `char`.
    ///
    /// # Examples
    ///
    /// Abos šajos piemēros 'ß' kodēšanai nepieciešami divi baiti.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Pārāk mazs buferis:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // DROŠĪBA: `char` nav aizstājējs, tāpēc tas ir derīgs UTF-8.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Kodē šo rakstzīmi kā UTF-16 paredzētajā `u16` buferī un pēc tam atgriež bufera apakšslāni, kas satur kodēto rakstzīmi.
    ///
    ///
    /// # Panics
    ///
    /// Panics, ja buferis nav pietiekami liels.
    /// 2. garuma buferis ir pietiekami liels, lai kodētu jebkuru `char`.
    ///
    /// # Examples
    ///
    /// Abos šajos piemēros '𝕊' kodēšanai nepieciešami divi `u16`.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Pārāk mazs buferis:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Atgriež vērtību `true`, ja šim `char` ir rekvizīts `Alphabetic`.
    ///
    /// `Alphabetic` ir aprakstīts [Unicode Standard] 4. nodaļā (Rakstzīmju īpašības) un norādīts [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // mīlestība ir daudzas lietas, taču tā nav alfabēta
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Atgriež vērtību `true`, ja šim `char` ir rekvizīts `Lowercase`.
    ///
    /// `Lowercase` ir aprakstīts [Unicode Standard] 4. nodaļā (Rakstzīmju īpašības) un norādīts [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // Dažādiem ķīniešu rakstiem un pieturzīmēm nav burtu, un tāpēc:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Atgriež vērtību `true`, ja šim `char` ir rekvizīts `Uppercase`.
    ///
    /// `Uppercase` ir aprakstīts [Unicode Standard] 4. nodaļā (Rakstzīmju īpašības) un norādīts [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // Dažādiem ķīniešu rakstiem un pieturzīmēm nav burtu, un tāpēc:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Atgriež vērtību `true`, ja šim `char` ir rekvizīts `White_Space`.
    ///
    /// `White_Space` ir norādīts [Unicode Character Database][ucd] [`PropList.txt`].
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // neplīstoša telpa
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Atgriež vērtību `true`, ja šī `char` atbilst [`is_alphabetic()`] vai [`is_numeric()`].
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Atgriež vērtību `true`, ja šai `char` ir vispārīga vadības kodu kategorija.
    ///
    /// Vadības kodi (koda punkti ar vispārējo kategoriju `Cc`) ir aprakstīti [Unicode Standard] 4. nodaļā (Rakstzīmju īpašības) un norādīti [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// // U + 009C, VIRSMAS TERMINATORS
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Atgriež vērtību `true`, ja šim `char` ir rekvizīts `Grapheme_Extend`.
    ///
    /// `Grapheme_Extend` ir aprakstīts [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] un norādīts [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Atgriež vērtību `true`, ja šai `char` ir viena no vispārīgākajām skaitļu kategorijām.
    ///
    /// Vispārīgās skaitļu kategorijas (`Nd` decimālzīmēm, `Nl` burtiem līdzīgām ciparu rakstzīmēm un `No` citām ciparu rakstzīmēm) ir norādītas [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Atgriež atkārtotāju, kas nodrošina šī `char` mazo burtu kartēšanu kā vienu vai vairākus
    /// `char`s.
    ///
    /// Ja šim `char` nav mazo burtu kartēšanas, iterators iegūst to pašu `char`.
    ///
    /// Ja šim `char` ir viens pret vienu mazo kartējums, ko nodrošina [Unicode Character Database][ucd] [`UnicodeData.txt`], iterators iegūst šo `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Ja šim `char` ir nepieciešami īpaši apsvērumi (piemēram, vairākas `char`), tad iterators dod [`SpecialCasing.txt`] dotās `char` (s).
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Šī darbība veic beznosacījumu kartēšanu bez pielāgošanas.Tas ir, pārveidošana nav atkarīga no konteksta un valodas.
    ///
    /// Lietotāja [Unicode Standard] 4. nodaļā (Rakstzīmju īpašības) tiek apspriesta lietu kartēšana kopumā un 3. nodaļā (Conformance)-noklusējuma algoritms lietu pārveidošanai.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Kā atkārtotājs:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Izmantojot `println!` tieši:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Abi ir līdzvērtīgi:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// Izmantojot `to_string`:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // Dažreiz rezultāts ir vairāk nekā viena rakstzīme:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Rakstzīmes, kurām nav gan lielo, gan mazo burtu, pārvēršas par sevi.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Atgriež iteratoru, kas nodrošina šī `char` lielo burtu kartēšanu kā vienu vai vairākus
    /// `char`s.
    ///
    /// Ja šim `char` nav lielo burtu kartēšanas, iterators iegūst to pašu `char`.
    ///
    /// Ja šim `char` ir viens pret vienu lielo kartējumu, ko nodrošina [Unicode Character Database][ucd] [`UnicodeData.txt`], iterators iegūst šo `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Ja šim `char` ir nepieciešami īpaši apsvērumi (piemēram, vairākas `char`), tad iterators dod [`SpecialCasing.txt`] dotās `char` (s).
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Šī darbība veic beznosacījumu kartēšanu bez pielāgošanas.Tas ir, pārveidošana nav atkarīga no konteksta un valodas.
    ///
    /// Lietotāja [Unicode Standard] 4. nodaļā (Rakstzīmju īpašības) tiek apspriesta lietu kartēšana kopumā un 3. nodaļā (Conformance)-noklusējuma algoritms lietu pārveidošanai.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Kā atkārtotājs:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Izmantojot `println!` tieši:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Abi ir līdzvērtīgi:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// Izmantojot `to_string`:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // Dažreiz rezultāts ir vairāk nekā viena rakstzīme:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Rakstzīmes, kurām nav gan lielo, gan mazo burtu, pārvēršas par sevi.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Piezīme par lokalizāciju
    ///
    /// Turku valodā 'i' ekvivalentam latīņu valodā ir piecas formas, nevis divas:
    ///
    /// * 'Dotless': I/ı, dažreiz rakstīts ï
    /// * 'Dotted': Es/i
    ///
    /// Ņemiet vērā, ka mazie punktiņi 'i' ir vienādi ar latīņu.Tādēļ:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// `upper_i` vērtība šeit ir atkarīga no teksta valodas: ja atrodamies `en-US`, tam vajadzētu būt `"I"`, bet, ja `tr_TR`, `"İ"`.
    /// `to_uppercase()` to neņem vērā, un tāpēc:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// darbojas dažādās valodās.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Pārbauda, vai vērtība ir ASCII diapazonā.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Izveido vērtības kopiju ASCII lielo burtu ekvivalentā.
    ///
    /// ASCII burti 'a' līdz 'z' tiek kartēti ar 'A' līdz 'Z', bet burti, kas nav ASCII, nemainās.
    ///
    /// Lai palielinātu vērtību vietā, izmantojiet [`make_ascii_uppercase()`].
    ///
    /// Lai pievienotu ASCII rakstzīmes lielajiem burtiem papildus rakstzīmēm, kas nav ASCII, izmantojiet [`to_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Veido vērtības kopiju ASCII mazo burtu ekvivalentā.
    ///
    /// ASCII burti 'A' līdz 'Z' tiek kartēti ar 'a' līdz 'z', bet burti, kas nav ASCII, nemainās.
    ///
    /// Lai mazo vērtību ievietotu vietā, izmantojiet [`make_ascii_lowercase()`].
    ///
    /// Lai papildus mazajām ASCII rakstzīmēm lietotu mazās burtus, izmantojiet [`to_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Pārbauda, vai divas vērtības sakrīt ar ASCII reģistru.
    ///
    /// Ekvivalents `to_ascii_lowercase(a) == to_ascii_lowercase(b)`.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Pārvērš šo tipu par tā vietā esošo ASCII lielo burtu.
    ///
    /// ASCII burti 'a' līdz 'z' tiek kartēti ar 'A' līdz 'Z', bet burti, kas nav ASCII, nemainās.
    ///
    /// Lai atgrieztu jaunu lielās vērtības vērtību, nemodificējot esošo, izmantojiet [`to_ascii_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Pārvērš šo veidu par tā vietā esošo ASCII mazo burtu.
    ///
    /// ASCII burti 'A' līdz 'Z' tiek kartēti ar 'a' līdz 'z', bet burti, kas nav ASCII, nemainās.
    ///
    /// Lai atgrieztu jaunu vērtību ar mazāku burtu, nemainot esošo, izmantojiet [`to_ascii_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Pārbauda, vai vērtība ir ASCII alfabēta raksturs:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z' vai
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Pārbauda, vai vērtība ir ASCII lielais raksturs:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Pārbauda, vai vērtība ir ASCII mazais burts:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Pārbauda, vai vērtība ir ASCII burtciparu rakstzīme:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z' vai
    /// - U + 0061 'a' ..=U + 007A 'z' vai
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Pārbauda, vai vērtība ir ASCII cipars aiz komata:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Pārbauda, vai vērtība ir ASCII heksadecimālais cipars:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9' vai
    /// - U + 0041 'A' ..=U + 0046 'F' vai
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Pārbauda, vai vērtība ir ASCII pieturzīme:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /` vai
    /// - U + 003A ..=U + 0040 `: ; < = > ? @` vai
    /// - U + 005B ..=U + 0060 "[\] ^ _" `` vai
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Pārbauda, vai vērtība ir ASCII grafiskais raksturs:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Pārbauda, vai vērtība ir ASCII atstarpes rakstzīme:
    /// U + 0020 SPACE, U + 0009 HORIZONTĀLA TABULA, U + 000A LĪNIJAS PADEVE, U + 000C FORMAS PADEVE vai U + 000D PĀRVADĀJUMU ATGRIEŠANA.
    ///
    /// Rust izmanto WhatWG Infra Standard [definition of ASCII whitespace][infra-aw].Plaši tiek izmantotas vairākas citas definīcijas.
    /// Piemēram, [the POSIX locale][pct] ietver U + 000B VERTICAL TAB, kā arī visas iepriekš minētās rakstzīmes, taču-no tās pašas specifikācijas-[noklusējuma noteikums "field splitting" Bourne shell][bfs] uzskata *tikai* SPACE, HORIZONTAL TAB un LĪNIJAS PADEVES kā atstarpi.
    ///
    ///
    /// Ja rakstāt programmu, kas apstrādās esošu faila formātu, pirms šīs funkcijas izmantošanas pārbaudiet, kāda ir šī formāta atstarpes definīcija.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Pārbauda, vai vērtība ir ASCII vadības rakstzīme:
    /// U + 0000 NUL ..=U + 001F VIENĪBU Separators vai U + 007F DZĒST.
    /// Ņemiet vērā, ka lielākā daļa ASCII atstarpju rakstzīmju ir vadības rakstzīmes, bet SPACE nav.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Norādītajā baitu buferī kodē neapstrādātu u32 vērtību kā UTF-8 un pēc tam atgriež bufera apakšslāni, kas satur kodēto rakstzīmi.
///
///
/// Atšķirībā no `char::encode_utf8`, šī metode apstrādā arī koda punktus surogātu diapazonā.
/// (`char` izveide aizstājēja diapazonā ir UB.) Rezultāts ir derīgs [generalized UTF-8], bet nav derīgs UTF-8.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics, ja buferis nav pietiekami liels.
/// Četru garumu buferis ir pietiekami liels, lai kodētu jebkuru `char`.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// Kodē neapstrādātu u32 vērtību kā UTF-16 paredzētajā `u16` buferī un pēc tam atgriež bufera apakšslāni, kas satur kodēto rakstzīmi.
///
///
/// Atšķirībā no `char::encode_utf16`, šī metode apstrādā arī koda punktus surogātu diapazonā.
/// (`char` izveide aizstājēja diapazonā ir UB.)
///
/// # Panics
///
/// Panics, ja buferis nav pietiekami liels.
/// 2. garuma buferis ir pietiekami liels, lai kodētu jebkuru `char`.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // DROŠĪBA: katra roka pārbauda, vai ir pietiekami daudz bitu, lai tajā ierakstītu
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // BMP izkrīt
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Papildu plaknes sadalās aizstājējos.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}