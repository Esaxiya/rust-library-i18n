//! Komponējama asinhronā iterācija.
//!
//! Ja futures ir asinhronas vērtības, tad straumes ir asinhroni iteratori.
//! Ja esat atradis kaut kāda veida asinhronu kolekciju un jums vajadzēja veikt operāciju ar minētās kolekcijas elementiem, jūs ātri nokļūsit 'streams'.
//! Straumes tiek daudz lietotas idiomātiskā asinhronā Rust kodā, tāpēc ir vērts ar tām iepazīties.
//!
//! Pirms paskaidrot vairāk, parunāsim par šī moduļa struktūru:
//!
//! # Organization
//!
//! Šis modulis lielā mērā ir sakārtots pēc veida:
//!
//! * [Traits] ir galvenā daļa: šie traits nosaka, kāda veida straumes pastāv un ko jūs varat ar tām darīt.Šo traits metodēm ir vērts veltīt papildu mācību laiku.
//! * Funkcijas nodrošina dažus noderīgus veidus, kā izveidot dažas pamata plūsmas.
//! * Struktūras bieži ir šī modeļa traits dažādu metožu atgriešanās veidi.Parasti vēlaties apskatīt metodi, kas rada `struct`, nevis pašu `struct`.
//! Lai iegūtu sīkāku informāciju par iemeslu, skatiet sadaļu `[Īstenošanas straume](#ieviešanas straume)`.
//!
//! [Traits]: #traits
//!
//! Tieši tā!Rausimies straumēs.
//!
//! # Stream
//!
//! Šī moduļa sirds un dvēsele ir [`Stream`] trait.[`Stream`] kodols izskatās šādi:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! Atšķirībā no `Iterator`, `Stream` izšķir [`poll_next`] metodi, kas tiek izmantota, ieviešot `Stream`, un (to-be-implemented) `next` metodi, ko izmanto straumes patērēšanai.
//!
//! `Stream` patērētājiem ir jāņem vērā tikai `next`, kas, izsaucot, atgriež future, kas dod `Option<Stream::Item>`.
//!
//! `next` atgrieztais future radīs `Some(Item)`, kamēr ir elementi, un, kad tie visi būs izsmelti, tiks iegūts `None`, kas norāda, ka iterācija ir pabeigta.
//! Ja mēs gaidām kaut ko asinhronu, lai atrisinātu problēmu, future gaidīs, kamēr straume būs gatava atkal dot.
//!
//! Atsevišķas straumes var izvēlēties atjaunot atkārtojumu, un tāpēc `next` atkārtota izsaukšana var kaut kādā brīdī atkal radīt `Some(Item)`.
//!
//! Pilna [`Stream`] definīcija ietver arī vairākas citas metodes, taču tās ir noklusējuma metodes, kas veidotas virs [`poll_next`], un tāpēc jūs tās saņemat bez maksas.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Straumes ieviešana
//!
//! Lai izveidotu savu straumi, ir jāveic divas darbības: `struct` izveidošana straumes stāvokļa noturēšanai un pēc tam [`Stream`] ieviešana šai `struct`.
//!
//! Izveidosim straumi ar nosaukumu `Counter`, kas skaitīs no `1` līdz `5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Pirmkārt, struct:
//!
//! /// Straume, kas skaitās no viena līdz piecām
//! struct Counter {
//!     count: usize,
//! }
//!
//! // mēs vēlamies, lai mūsu skaitīšana sākas ar vienu, tāpēc pievienosim new() metodi, lai palīdzētu.
//! // Tas nav absolūti nepieciešams, bet ir ērti.
//! // Ņemiet vērā, ka mēs sākam `count` ar nulli, mēs redzēsim, kāpēc `poll_next()`'s ieviešanā.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Pēc tam mēs ieviešam `Stream` savam `Counter`:
//!
//! impl Stream for Counter {
//!     // mēs skaitīsim ar usize
//!     type Item = usize;
//!
//!     // poll_next() ir vienīgā nepieciešamā metode
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Palieliniet mūsu skaitu.Tāpēc mēs sākām no nulles.
//!         self.count += 1;
//!
//!         // Pārbaudiet, vai mēs esam pabeiguši skaitīšanu vai nē.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Straumes ir *slinkas*.Tas nozīmē, ka, tikai izveidojot straumi, _do_ nav daudz.Nekas īsti nenotiek, kamēr nezvanāt uz `next`.
//! Dažreiz tas rada neskaidrības, veidojot straumi tikai tās blakusparādību dēļ.
//! Sastādītājs mūs brīdinās par šāda veida rīcību:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;