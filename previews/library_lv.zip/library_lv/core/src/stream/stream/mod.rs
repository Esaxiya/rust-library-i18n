use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Interfeiss darbībai ar asinhroniem iteratoriem.
///
/// Šī ir galvenā trait straume.
/// Lai uzzinātu vairāk par straumju jēdzienu kopumā, lūdzu, skatiet [module-level documentation].
/// Jo īpaši jūs varētu vēlēties zināt, kā [implement `Stream`][impl].
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// Straumes iegūto vienumu veids.
    type Item;

    /// Mēģiniet izvilkt nākamo šīs straumes vērtību, reģistrējot pašreizējo uzdevumu modināšanai, ja vērtība vēl nav pieejama, un atgriežot `None`, ja straume ir izsmelta.
    ///
    /// # Atgriešanās vērtība
    ///
    /// Ir vairākas iespējamās atgriešanās vērtības, no kurām katra norāda atšķirīgu straumes stāvokli:
    ///
    /// - `Poll::Pending` nozīmē, ka šīs straumes nākamā vērtība vēl nav gatava.Īstenošana nodrošinās, ka par pašreizējo uzdevumu tiks paziņots, kad nākamā vērtība būs gatava.
    ///
    /// - `Poll::Ready(Some(val))` nozīmē, ka straume ir veiksmīgi izveidojusi vērtību `val` un var radīt turpmākas vērtības nākamajos `poll_next` zvanos.
    ///
    /// - `Poll::Ready(None)` nozīmē, ka straume ir pārtraukta, un `poll_next` vairs nevajadzētu izsaukt.
    ///
    /// # Panics
    ///
    /// Kad straume ir pabeigta (atgriezta `Ready(None)` from `poll_next`), atkārtoti izsaucot tās `poll_next` metodi, panic var bloķēties uz visiem laikiem vai radīt cita veida problēmas; `Stream` trait nenosaka prasības šāda zvana ietekmei.
    ///
    /// Tomēr, tā kā `poll_next` metode nav atzīmēta ar `unsafe`, tiek piemēroti Rust parastie noteikumi: zvani nekad nedrīkst izraisīt nedefinētu uzvedību (atmiņas bojājumus, nepareizu `unsafe` funkciju izmantošanu vai tamlīdzīgi), neatkarīgi no straumes stāvokļa.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Atgriež robežas atlikušajam straumes garumam.
    ///
    /// Konkrēti, `size_hint()` atgriež kopu, kur pirmais elements ir apakšējā robeža, bet otrais elements ir augšējais.
    ///
    /// Atgrieztā dubultā otrā puse ir [`Option`]`<`[`usize`] `>`.
    /// [`None`] šeit nozīmē, ka vai nu nav zināma augšējā robeža, vai arī augšējā robeža ir lielāka par [`usize`].
    ///
    /// # Īstenošanas piezīmes
    ///
    /// Nav ieviests, ka straumes ieviešana dod deklarēto elementu skaitu.Bagiju plūsma var radīt mazāk nekā elementu apakšējā robeža vai vairāk nekā augšējā robeža.
    ///
    /// `size_hint()` galvenokārt paredzēts izmantot optimizācijai, piemēram, vietas rezervēšanai straumes elementiem, taču tam nedrīkst uzticēties, piemēram, nedrošā kodā izlaist robežu pārbaudes.
    /// Nepareiza `size_hint()` ieviešana nedrīkst izraisīt atmiņas drošības pārkāpumus.
    ///
    /// Tas nozīmē, ka ieviešanai vajadzētu sniegt pareizu novērtējumu, jo pretējā gadījumā tas būtu trait protokola pārkāpums.
    ///
    /// Noklusējuma ieviešana atgriež "(0," ["Neviens"] ")", kas ir pareizs jebkurai straumei.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}