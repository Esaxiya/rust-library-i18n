use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Lai gan šī funkcija tiek izmantota vienā vietā un tās ieviešana varētu būt vienkārša, iepriekšējie mēģinājumi to darīt padarīja rustc lēnāku:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Atmiņas bloka izkārtojums.
///
/// `Layout` eksemplārs apraksta noteiktu atmiņas izkārtojumu.
/// Jūs izveidojat `Layout` kā ievadi, ko dot sadalītājam.
///
/// Visiem izkārtojumiem ir saistīts izmērs un divu pielīdzināšana.
///
/// (Ņemiet vērā, ka izkārtojumiem *nav* obligāti jābūt ar nulles lielumu, pat ja `GlobalAlloc` pieprasa, lai visiem atmiņas pieprasījumiem būtu lielums, kas nav nulle.
/// Zvanītājam ir vai nu jāpārliecinās, vai tiek ievēroti šādi nosacījumi, vai arī jāizmanto īpaši sadalītāji, kuru prasības ir vājākas, vai jāizmanto saudzīgāka `Allocator` saskarne.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // pieprasītā atmiņas bloka lielums, mērot baitos.
    size_: usize,

    // pieprasītā atmiņas bloka izlīdzināšana, mērot baitos.
    // mēs nodrošinām, ka tas vienmēr ir spēks no diviem, jo API, piemēram, `posix_memalign`, to prasa, un tas ir saprātīgs ierobežojums, kas jāuzliek izkārtojuma konstruktoriem.
    //
    //
    // (Tomēr mums analogi nav nepieciešama `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Veido `Layout` no dotajiem `size` un `align` vai atgriež `LayoutError`, ja nav izpildīts kāds no šiem nosacījumiem:
    ///
    /// * `align` nedrīkst būt nulle,
    ///
    /// * `align` jābūt divu spēku spēkam,
    ///
    /// * `size`, noapaļojot līdz `align` tuvākajam reizinājumam, nedrīkst pārplūst (ti, noapaļotajai vērtībai jābūt mazākai vai vienādai ar `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (divu spēks nozīmē izlīdzināt!=0.)

        // Noapaļots lielums ir:
        //   size_rounded_up=(izmērs + izlīdzināt, 1)&! (izlīdzināt, 1);
        //
        // Mēs no augšas zinām, ka tas jāsaskaņo!=0.
        // Ja pievienošana (izlīdzināt, 1) nepārplūst, noapaļošana uz augšu būs laba.
        //
        // Un otrādi,&maskējot ar! (Izlīdzināt, 1), tiks atņemti tikai zema pasūtījuma biti.
        // Tādējādi, ja pārpilde notiek ar summu,&-mask nevar atņemt pietiekami daudz, lai atsauktu šo pārpildi.
        //
        //
        // Iepriekš minētais nozīmē, ka summēšanas pārpildes pārbaude ir nepieciešama un pietiekama.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // DROŠĪBA: `from_size_align_unchecked` nosacījumi ir bijuši
        // pārbaudīts iepriekš.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Izveido izkārtojumu, apejot visas pārbaudes.
    ///
    /// # Safety
    ///
    /// Šī funkcija nav droša, jo tā nepārbauda [`Layout::from_size_align`] priekšnosacījumus.
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // DROŠĪBA: zvanītājam jāpārliecinās, ka `align` ir lielāks par nulli.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Minimālais šī izkārtojuma atmiņas bloka lielums baitos.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// Minimālais šī izkārtojuma atmiņas bloka baitu izlīdzinājums.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Konstruē `Layout`, kas piemērots `T` tipa vērtības turēšanai.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // DROŠĪBA: Rust garantē izlīdzināšanu kā divu un
        // kombinācija size + align ir garantēta, lai tā ietilptu mūsu adrešu telpā.
        // Rezultātā izmantojiet šeit nepārbaudīto konstruktoru, lai izvairītos no panics koda ievietošanas, ja tas nav pietiekami labi optimizēts.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Izgatavo izkārtojumu, kurā aprakstīts ieraksts, ko varētu izmantot, lai piešķirtu `T` atbalsta struktūru (kas varētu būt trait vai cita izmēra tips, piemēram, šķēle).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // DROŠĪBA: skatiet `new` pamatojumu, kāpēc tas izmanto nedrošu variantu
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Izgatavo izkārtojumu, kurā aprakstīts ieraksts, ko varētu izmantot, lai piešķirtu `T` atbalsta struktūru (kas varētu būt trait vai cita izmēra tips, piemēram, šķēle).
    ///
    /// # Safety
    ///
    /// Šo funkciju var droši izsaukt tikai tad, ja ir spēkā šādi nosacījumi:
    ///
    /// - Ja `T` ir `Sized`, šo funkciju vienmēr var droši izsaukt.
    /// - Ja `T` izmērs bez izmēra ir:
    ///     - [slice], tad šķēles astes garumam jābūt intializētam skaitlim, un *visas vērtības* lielumam (dinamiskā astes garums + statiski izmēra prefikss) jāatbilst `isize`.
    ///     - [trait object], tad rādītāja vtable daļai jānorāda uz derīgu vtable `T` tipam, kas iegūts ar izmēru nesamērīgu koeriju, un *visas vērtības* lielumam (dinamiskā astes garums + statiskā izmēra prefikss) jāatbilst `isize`.
    ///
    ///     - (unstable) [extern type], tad šo funkciju vienmēr var droši izsaukt, taču tā var panic vai citādi atgriezt nepareizu vērtību, jo ārējā tipa izkārtojums nav zināms.
    ///     Tā ir tāda pati darbība kā [`Layout::for_value`], atsaucoties uz ārējā tipa asti.
    ///     - pretējā gadījumā konservatīvi nav atļauts izsaukt šo funkciju.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // DROŠĪBA: mēs nododam zvanītājam šo funkciju priekšnoteikumus
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // DROŠĪBA: skatiet `new` pamatojumu, kāpēc tas izmanto nedrošu variantu
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Izveido `NonNull`, kas ir piekārts, bet labi izlīdzināts šim izkārtojumam.
    ///
    /// Ņemiet vērā, ka rādītāja vērtība, iespējams, apzīmē derīgu rādītāju, kas nozīmē, ka to nedrīkst izmantot kā "not yet initialized" sentinel vērtību.
    /// Veidiem, kurus slinki piešķir, ir jāizseko inicializācija ar citiem līdzekļiem.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // DROŠĪBA: izlīdzināšana tiek garantēta kā nulle
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Izveido izkārtojumu, kas apraksta ierakstu, kurā var atrasties tāda paša izkārtojuma vērtība kā `self`, bet kas ir arī izlīdzināts ar izlīdzinājumu `align` (mērot baitos).
    ///
    ///
    /// Ja `self` jau atbilst noteiktajai izlīdzināšanai, atgriež vērtību `self`.
    ///
    /// Ņemiet vērā, ka šī metode kopējam izmēram nepievieno nevienu pildījumu neatkarīgi no tā, vai atgrieztajam izkārtojumam ir atšķirīgs izlīdzinājums.
    /// Citiem vārdiem sakot, ja `K` ir 16. izmērs, `K.align_to(32)`*joprojām* būs 16. izmērs.
    ///
    /// Atgriež kļūdu, ja `self.size()` un norādītā `align` kombinācija pārkāpj nosacījumus, kas uzskaitīti [`Layout::from_size_align`].
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Atgriež polsterējuma daudzumu, kas jāievieto aiz `self`, lai nodrošinātu, ka šī adrese apmierinās `align` (mērot baitos).
    ///
    /// piem., ja `self.size()` ir 9, tad `self.padding_needed_for(4)` atgriež 3, jo tas ir minimālais aizpildīšanas baitu skaits, kas nepieciešams, lai iegūtu 4 izlīdzinātu adresi (pieņemot, ka attiecīgais atmiņas bloks sākas ar 4 līdzinātu adresi).
    ///
    ///
    /// Šīs funkcijas atgriešanās vērtībai nav nozīmes, ja `align` nav divu spēks.
    ///
    /// Ņemiet vērā, ka atgrieztās vērtības lietderībai ir nepieciešams, lai `align` būtu mazāks vai vienāds ar sākuma adreses izlīdzinājumu visam piešķirtajam atmiņas blokam.Viens no veidiem, kā apmierināt šo ierobežojumu, ir nodrošināt `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Noapaļotā vērtība ir:
        //   len_rounded_up=(len + izlīdzināt, 1)&! (izlīdzināt, 1);
        // un pēc tam mēs atgriežam polsterējuma starpību: `len_rounded_up - len`.
        //
        // Mēs visur izmantojam modulāru aritmētiku:
        //
        // 1. izlīdzināšanas garantija ir> 0, tāpēc vienmērot, 1 vienmēr ir derīgs.
        //
        // 2.
        // `len + align - 1` var pārsniegt ne vairāk kā `align - 1`, tāpēc&-mask ar `!(align - 1)` nodrošinās, ka pārpildes gadījumā `len_rounded_up` pati par sevi būs 0.
        //
        //    Tādējādi atgrieztais polsterējums, pievienojot `len`, dod 0, kas triviāli apmierina izlīdzinājumu `align`.
        //
        // (Protams, mēģinājumiem piešķirt atmiņas blokus, kuru lielums un polsterējums pārpildās iepriekš minētajā veidā, vienalga, ka alokatoram tomēr būs jāiegūst kļūda.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Izveido izkārtojumu, noapaļojot šī izkārtojuma lielumu līdz izkārtojuma izlīdzināšanas reizinājumam.
    ///
    ///
    /// Tas ir līdzvērtīgs `padding_needed_for` rezultāta pievienošanai izkārtojuma pašreizējam lielumam.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Tas nevar pārplūst.Citējot no izkārtojuma nemainīgā varianta:
        // > `size`, noapaļojot līdz `align` tuvākajam reizinājumam,
        // > nedrīkst pārplūst (ti, noapaļotajai vērtībai jābūt mazākai par
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Izveido izkārtojumu, kurā aprakstīts `self` gadījumu `n` ieraksts, starp katru piemērotu daudzumu polsterējumu, lai nodrošinātu, ka katram gadījumam tiek piešķirts pieprasītais lielums un izlīdzinājums.
    /// Pēc panākumiem atgriež vērtību `(k, offs)`, kur `k` ir masīva izkārtojums, un `offs` ir attālums starp katra masīva elementa sākumu.
    ///
    /// Aritmētiskās pārpildes gadījumā atgriež vērtību `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Tas nevar pārplūst.Citējot no izkārtojuma nemainīgā varianta:
        // > `size`, noapaļojot līdz `align` tuvākajam reizinājumam,
        // > nedrīkst pārplūst (ti, noapaļotajai vērtībai jābūt mazākai par
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // DROŠĪBA: self.align jau ir derīgs, un piešķiršanas_mērs ir bijis
        // polsterēts jau.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Izveido izkārtojumu, kurā aprakstīts ieraksts `self`, kam seko `next`, ieskaitot visus nepieciešamos polsterējumus, lai nodrošinātu, ka `next` tiks pareizi izlīdzināts, bet *bez aizpildīšanas*.
    ///
    /// Lai saskaņotu C attēlojuma izkārtojumu `repr(C)`, pēc izkārtojuma paplašināšanas ar visiem laukiem jums jāzvana uz `pad_to_align`.
    /// (Nekādi nevar saskaņot noklusējuma Rust attēlojuma izkārtojumu `repr(Rust)`, as it is unspecified.)
    ///
    /// Ņemiet vērā, ka iegūtā izkārtojuma izlīdzināšana būs maksimālā `self` un `next` izkārtojuma, lai nodrošinātu abu daļu izlīdzināšanu.
    ///
    /// Atgriež `Ok((k, offset))`, kur `k` ir sasietā ieraksta izkārtojums, un `offset` ir relatīvais savienotajā ierakstā iegultā `next` sākuma relatīvais izvietojums baitos (pieņemot, ka pats ieraksts sākas ar 0 nobīdi).
    ///
    ///
    /// Aritmētiskās pārpildes gadījumā atgriež vērtību `LayoutError`.
    ///
    /// # Examples
    ///
    /// Lai aprēķinātu `#[repr(C)]` struktūras izkārtojumu un lauku nobīdes no tās lauku izkārtojuma:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Atcerieties pabeigt darbu ar `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // pārbaudiet, vai tas darbojas
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Izveido izkārtojumu, kurā aprakstīts `self` gadījumu `n` ieraksts, bez katras instances.
    ///
    /// Ņemiet vērā, ka atšķirībā no `repeat`, `repeat_packed` negarantē, ka atkārtoti `self` gadījumi tiks pareizi izlīdzināti, pat ja konkrētais `self` gadījums ir pareizi izlīdzināts.
    /// Citiem vārdiem sakot, ja masīva piešķiršanai izmanto `repeat_packed` atgriezto izkārtojumu, netiek garantēts, ka visi masīva elementi tiks pareizi izlīdzināti.
    ///
    /// Aritmētiskās pārpildes gadījumā atgriež vērtību `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Izveido izkārtojumu, kurā aprakstīts ieraksts `self`, kam seko `next`, bez abiem papildu pildījumiem.
    /// Tā kā nav ievietots polsterējums, `next` izlīdzināšana nav būtiska, un rezultātā izveidotajā izkārtojumā tā vispār nav iekļauta *.
    ///
    ///
    /// Aritmētiskās pārpildes gadījumā atgriež vērtību `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Izveido izkārtojumu, kurā aprakstīts `[T; n]` ieraksts.
    ///
    /// Aritmētiskās pārpildes gadījumā atgriež vērtību `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// `Layout::from_size_align` vai kādam citam `Layout` konstruktoram piešķirtie parametri neatbilst tā dokumentētajiem ierobežojumiem.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (mums tas ir vajadzīgs trait kļūdas pakārtotajai daļai)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}