use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// Atmiņas sadalītājs, kuru var reģistrēt kā standarta bibliotēkas noklusējumu, izmantojot atribūtu `#[global_allocator]`.
///
/// Dažas no metodēm prasa, lai atmiņas bloks *pašlaik tiktu piešķirts*, izmantojot sadalītāju.Tas nozīmē ka:
///
/// * šī atmiņas bloka sākuma adrese iepriekš tika atgriezta ar iepriekšēju izsaukumu uz piešķiršanas metodi, piemēram, `alloc`, un
///
/// * atmiņas bloks pēc tam nav sadalīts, kur bloki tiek sadalīti vai nu nododot darījumu izvietošanas metodei, piemēram, `dealloc`, vai nododot pārdales metodei, kas atgriež rādītāju, kas nav nulle.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// `GlobalAlloc` trait ir `unsafe` trait vairāku iemeslu dēļ, un īstenotājiem ir jānodrošina, ka viņi ievēro šos līgumus:
///
/// * Tā ir nedefinēta rīcība, ja globālie sadalītāji atpūšas.Šis ierobežojums future var tikt atcelts, taču pašlaik panic no jebkuras no šīm funkcijām var izraisīt atmiņas nedrošību.
///
/// * `Layout` vaicājumiem un aprēķiniem kopumā jābūt pareiziem.trait zvanītājiem ir atļauts paļauties uz līgumiem, kas noteikti katrā metodē, un īstenotājiem ir jānodrošina, lai šādi līgumi paliktu patiesi.
///
/// * Jūs nedrīkstat paļauties uz faktiski notiekošajiem piešķīrumiem, pat ja avotā ir skaidri izteikti kaudzes piešķīrumi.
/// Optimizētājs var atklāt neizmantotus piešķīrumus, kurus var pilnībā novērst vai pāriet uz kaudzi, un tādējādi nekad neizsaukt sadalītāju.
/// Optimizētājs var arī pieņemt, ka piešķīrums ir nekļūdīgs, tāpēc kods, kas agrāk neizdevās sadalītāja kļūmju dēļ, tagad var pēkšņi darboties, jo optimizētājs apieta nepieciešamību pēc piešķīruma.
/// Konkrētāk, šāds koda piemērs ir nepamatots neatkarīgi no tā, vai jūsu pielāgotais sadalītājs ļauj skaitīt, cik daudz piešķiršanas gadījumu ir noticis.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Ņemiet vērā, ka iepriekš minētās optimizācijas nav vienīgās piemērojamās optimizācijas.Jūs parasti nevarat paļauties uz kaudzes piešķiršanu, ja tos var noņemt, nemainot programmas uzvedību.
///   Neatkarīgi no tā, vai piešķiršana notiek vai ne, tā nav daļa no programmas uzvedības, pat ja to varētu noteikt, izmantojot sadalītāju, kas izseko izsekošanu, drukājot vai citādi radot blakusparādības.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Piešķiriet atmiņu, kā aprakstīts dotajā `layout`.
    ///
    /// Atgriež rādītāju nesen piešķirtajā atmiņā vai nulli, lai norādītu piešķiršanas kļūmi.
    ///
    /// # Safety
    ///
    /// Šī funkcija ir nedroša, jo nedefinēta rīcība var rasties, ja zvanītājs nenodrošina, ka `layout` izmērs nav nulle.
    ///
    /// (Paplašinājuma apakškategorijas var noteikt konkrētākas robežas uzvedībai, piemēram, garantēt uzrauga adresi vai nulles rādītāju, atbildot uz nulles lieluma piešķiršanas pieprasījumu.)
    ///
    /// Piešķirto atmiņas bloku var inicializēt vai nē.
    ///
    /// # Errors
    ///
    /// Nulles rādītāja atgriešana norāda, ka atmiņa ir iztukšota vai `layout` neatbilst šī sadalītāja lieluma vai izlīdzināšanas ierobežojumiem.
    ///
    /// Ieteikumi tiek mudināti atgriezties atmiņā, nevis pārtraucot atmiņu, taču tā nav stingra prasība.
    /// (Konkrēti:*likumīgi* ir ieviest šo trait pamatā esošās vietējās piešķiršanas bibliotēkas augšpusē, kas pārtrauc atmiņas izsmelšanu.)
    ///
    /// Klienti, kuri vēlas pārtraukt aprēķinu, reaģējot uz piešķiršanas kļūdu, tiek aicināti izsaukt funkciju [`handle_alloc_error`], nevis tieši izsaukt `panic!` vai tamlīdzīgu.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Atdaliet atmiņas bloku dotajā `ptr` rādītājā ar norādīto `layout`.
    ///
    /// # Safety
    ///
    /// Šī funkcija ir nedroša, jo nenoteiktu rīcību var izraisīt, ja zvanītājs nenodrošina visas šīs darbības:
    ///
    ///
    /// * `ptr` jānorāda atmiņas bloks, kas pašlaik piešķirts, izmantojot šo sadalītāju,
    ///
    /// * `layout` jābūt tādam pašam izkārtojumam, kāds tika izmantots šī atmiņas bloka piešķiršanai.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// Uzvedas tāpat kā `alloc`, bet arī nodrošina, ka saturs tiek iestatīts uz nulli, pirms tas tiek atgriezts.
    ///
    /// # Safety
    ///
    /// Šī funkcija ir nedroša tādu pašu iemeslu dēļ kā `alloc`.
    /// Tomēr tiek garantēts, ka piešķirtais atmiņas bloks tiek inicializēts.
    ///
    /// # Errors
    ///
    /// Nulles rādītāja atgriešana norāda, ka vai nu atmiņa ir iztukšota, vai arī `layout` neatbilst sadalītāja lieluma vai izlīdzināšanas ierobežojumiem, tāpat kā `alloc`.
    ///
    /// Klienti, kuri vēlas pārtraukt aprēķinu, reaģējot uz piešķiršanas kļūdu, tiek aicināti izsaukt funkciju [`handle_alloc_error`], nevis tieši izsaukt `panic!` vai tamlīdzīgu.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // DROŠĪBA: zvanītājam jāievēro `alloc` drošības līgums.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // DROŠĪBA: tā kā piešķiršana izdevās, reģions no `ptr`
            // `size` lielums ir garantēts, ka tas ir derīgs rakstīšanai.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Samaziniet vai palieliniet atmiņas bloku līdz dotajam `new_size`.
    /// Bloku apraksta dotais `ptr` rādītājs un `layout`.
    ///
    /// Ja tas atgriež nulles rādītāju, kas nav nulle, īpašumtiesības uz atmiņas bloku, uz kuru atsaucas `ptr`, ir nodotas šim sadalītājam.
    /// Iespējams, ka atmiņa ir vai nav sadalīta, un tā jāuzskata par nelietojamu (ja vien, protams, tā vēlreiz nav pārsūtīta atpakaļ zvanītājam, izmantojot šīs metodes atgriešanās vērtību).
    /// Jaunais atmiņas bloks tiek piešķirts ar `layout`, bet ar `size` atjaunināts uz `new_size`.
    /// Šis jaunais izkārtojums ir jāizmanto, ja tiek sadalīts jaunais atmiņas bloks ar `dealloc`.
    /// Jaunā atmiņas bloka diapazonam `0..min(layout.size(), new_size) `tiek garantētas tādas pašas vērtības kā sākotnējam blokam.
    ///
    /// Ja šī metode atgriež nulli, tad atmiņas bloka īpašumtiesības šim piešķīrējam nav nodotas, un atmiņas bloka saturs netiek mainīts.
    ///
    /// # Safety
    ///
    /// Šī funkcija ir nedroša, jo nenoteiktu rīcību var izraisīt, ja zvanītājs nenodrošina visas šīs darbības:
    ///
    /// * `ptr` pašlaik jāpiešķir, izmantojot šo sadalītāju,
    ///
    /// * `layout` jābūt tādam pašam izkārtojumam, kāds tika izmantots šī atmiņas bloka piešķiršanai,
    ///
    /// * `new_size` jābūt lielākai par nulli.
    ///
    /// * `new_size`, noapaļojot līdz `layout.align()` tuvākajam reizinājumam, nedrīkst pārplūst (ti, noapaļotajai vērtībai jābūt mazākai par `usize::MAX`).
    ///
    /// (Paplašinājuma apakškategorijas var noteikt konkrētākas robežas uzvedībai, piemēram, garantēt uzrauga adresi vai nulles rādītāju, atbildot uz nulles lieluma piešķiršanas pieprasījumu.)
    ///
    /// # Errors
    ///
    /// Atgriež nulli, ja jaunais izkārtojums neatbilst sadalītāja lieluma un izlīdzināšanas ierobežojumiem vai ja pārdalīšana citādi neizdodas.
    ///
    /// Īstenojumi tiek mudināti atgriezties atmiņā, nevis panikā vai pārtraukumā, taču tā nav stingra prasība.
    /// (Konkrēti:*likumīgi* ir ieviest šo trait pamatā esošās vietējās piešķiršanas bibliotēkas augšpusē, kas pārtrauc atmiņas izsmelšanu.)
    ///
    /// Klienti, kuri vēlas pārtraukt aprēķinu, reaģējot uz pārdales kļūdu, tiek aicināti izsaukt funkciju [`handle_alloc_error`], nevis tieši izsaukt `panic!` vai tamlīdzīgu.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // DROŠĪBA: zvanītājam jāpārliecinās, ka `new_size` nepārplūst.
        // `layout.align()` nāk no `Layout` un tādējādi tiek garantēts, ka tā ir derīga.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // DROŠĪBA: zvanītājam jāpārliecinās, ka `new_layout` ir lielāks par nulli.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // DROŠĪBA: iepriekš piešķirtais bloks nevar pārklāties ar tikko piešķirto bloku.
            // Zvanītājam jāievēro `dealloc` drošības līgums.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}