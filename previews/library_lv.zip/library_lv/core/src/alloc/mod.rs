//! Atmiņas piešķiršanas API

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// `AllocError` kļūda norāda uz sadalījuma kļūmi, kas var rasties resursu izsmelšanas dēļ vai kaut kā nepareizi, apvienojot dotos ievades argumentus ar šo sadalītāju.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (mums tas ir vajadzīgs trait kļūdas pakārtotajai daļai)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// `Allocator` ieviešana var piešķirt, palielināt, samazināt un sadalīt patvaļīgus datu blokus, kas aprakstīti, izmantojot [`Layout`][].
///
/// `Allocator` ir paredzēts ieviešanai ZST, atsaucēs vai viedajos rādītājos, jo tādu sadalītāju kā `MyAlloc([u8; N])` nevar pārvietot, neatjauninot rādītājus atvēlētajā atmiņā.
///
/// Atšķirībā no [`GlobalAlloc`][], `Allocator` ir atļauts piešķirt nulles lieluma piešķīrumus.
/// Ja pamatā esošais sadalītājs to neatbalsta (piemēram, jemalloc) vai atgriež nulles rādītāju (piemēram, `libc::malloc`), tas ir jānoķer ieviešanai.
///
/// ### Pašlaik atvēlētā atmiņa
///
/// Dažas no metodēm prasa, lai atmiņas bloks *pašlaik tiktu piešķirts*, izmantojot sadalītāju.Tas nozīmē ka:
///
/// * šī atmiņas bloka sākuma adresi iepriekš atgrieza [`allocate`], [`grow`] vai [`shrink`] un
///
/// * Atmiņas bloks pēc tam nav sadalīts, kur bloki tiek vai nu tieši sadalīti, nododot tos [`deallocate`], vai arī mainīti, nododot [`grow`] vai [`shrink`], kas atgriež `Ok`.
///
/// Ja `grow` vai `shrink` ir atgriezuši `Err`, nodotais rādītājs paliek derīgs.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Atmiņas pielāgošana
///
/// Dažas no metodēm prasa, lai izkārtojums *ietilptu* atmiņas blokā.
/// "fit" izkārtojuma nozīme ir atmiņas bloks (vai līdzvērtīgi, ja atmiņas blokam "fit" ir izkārtojums) ir tas, ka ir jāievēro šādi nosacījumi:
///
/// * Bloks jāpiešķir ar tādu pašu izlīdzinājumu kā [`layout.align()`], un
///
/// * Iesniegtajam [`layout.size()`] ir jābūt diapazonā `min ..= max`, kur:
///   - `min` ir bloka piešķiršanai pēdējā laikā izmantotā izkārtojuma lielums un
///   - `max` ir jaunākais faktiskais izmērs, kas atgriezts no [`allocate`], [`grow`] vai [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Atmiņas blokiem, kas atgriezti no sadalītāja, jānorāda uz derīgu atmiņu un jāsaglabā to derīgums, līdz eksemplārs un visi tā kloni tiek nomesti,
///
/// * atdalītāja klonēšana vai pārvietošana nedrīkst padarīt nederīgus atmiņas blokus, kas atgriezti no šī sadalītāja.Klonētajam sadalītājam ir jāuzvedas tāpat kā tam pašam sadalītājam, un
///
/// * jebkuru norādi uz atmiņas bloku, kas ir [*currently allocated*], var nodot jebkurai citai sadalītāja metodei.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Mēģinājumi piešķirt atmiņas bloku.
    ///
    /// Pēc panākumiem atgriež [`NonNull<[u8]>`][NonNull], kas atbilst `layout` lieluma un izlīdzināšanas garantijām.
    ///
    /// Atgriežamajam blokam var būt lielāks izmērs, nekā norādīts `layout.size()`, un tā saturs var būt inicializēts.
    ///
    /// # Errors
    ///
    /// Atgriežamais `Err` norāda, ka atmiņa ir iztukšota vai `layout` neatbilst sadalītāja lieluma vai izlīdzināšanas ierobežojumiem.
    ///
    /// Ieviesumi tiek mudināti atgriezt `Err` atmiņas izsīkuma vietā, nevis panikā vai pārtraukumā, taču tā nav stingra prasība.
    /// (Konkrēti:*likumīgi* ir ieviest šo trait pamatā esošās vietējās piešķiršanas bibliotēkas augšpusē, kas pārtrauc atmiņas izsmelšanu.)
    ///
    /// Klienti, kuri vēlas pārtraukt aprēķinu, reaģējot uz piešķiršanas kļūdu, tiek aicināti izsaukt funkciju [`handle_alloc_error`], nevis tieši izsaukt `panic!` vai tamlīdzīgu.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Uzvedas tāpat kā `allocate`, bet arī nodrošina, ka atgrieztā atmiņa tiek inicializēta nulle.
    ///
    /// # Errors
    ///
    /// Atgriežamais `Err` norāda, ka atmiņa ir iztukšota vai `layout` neatbilst sadalītāja lieluma vai izlīdzināšanas ierobežojumiem.
    ///
    /// Ieviesumi tiek mudināti atgriezt `Err` atmiņas izsīkuma vietā, nevis panikā vai pārtraukumā, taču tā nav stingra prasība.
    /// (Konkrēti:*likumīgi* ir ieviest šo trait pamatā esošās vietējās piešķiršanas bibliotēkas augšpusē, kas pārtrauc atmiņas izsmelšanu.)
    ///
    /// Klienti, kuri vēlas pārtraukt aprēķinu, reaģējot uz piešķiršanas kļūdu, tiek aicināti izsaukt funkciju [`handle_alloc_error`], nevis tieši izsaukt `panic!` vai tamlīdzīgu.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // DROŠĪBA: `alloc` atgriež derīgu atmiņas bloku
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Izkliedē atmiņu, uz kuru norāda `ptr`.
    ///
    /// # Safety
    ///
    /// * `ptr` caur šo sadalītāju jāatzīmē atmiņas bloks [*currently allocated*], un
    /// * `layout` ir [*fit*], ka atmiņas bloks.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Mēģinājumi paplašināt atmiņas bloku.
    ///
    /// Atgriež jaunu [`NonNull<[u8]>`][NonNull], kas satur rādītāju un piešķirto atmiņu faktisko lielumu.Rādītājs ir piemērots `new_layout` aprakstīto datu glabāšanai.
    /// Lai to paveiktu, piešķīrējs var paplašināt piešķiršanu, uz kuru norāda `ptr`, lai tā atbilstu jaunajam izkārtojumam.
    ///
    /// Ja tas atgriež `Ok`, īpašumtiesības uz atmiņas bloku, uz kuru atsaucas `ptr`, ir nodotas šim sadalītājam.
    /// Iespējams, ka atmiņa ir vai nav atbrīvojusies, un tā jāuzskata par nelietojamu, ja vien tā netiek atkārtoti pārsūtīta atpakaļ zvanītājam, izmantojot šīs metodes atgriešanās vērtību.
    ///
    /// Ja šī metode atgriež `Err`, tad atmiņas bloka īpašumtiesības šim piešķīrējam nav nodotas, un atmiņas bloka saturs netiek mainīts.
    ///
    /// # Safety
    ///
    /// * `ptr` caur šo atdalītāju jānorāda atmiņas bloks [*currently allocated*].
    /// * `old_layout` jāpievieno [*fit*] šis atmiņas bloks (argumentam `new_layout` tas nav jāatbilst.).
    /// * `new_layout.size()` jābūt lielākai par `old_layout.size()` vai vienādai ar to.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Atgriež vērtību `Err`, ja jaunais izkārtojums neatbilst sadalītāja lieluma un izlīdzinātāja ierobežojumiem vai ja augšana citādi neizdodas.
    ///
    /// Ieviesumi tiek mudināti atgriezt `Err` atmiņas izsīkuma vietā, nevis panikā vai pārtraukumā, taču tā nav stingra prasība.
    /// (Konkrēti:*likumīgi* ir ieviest šo trait pamatā esošās vietējās piešķiršanas bibliotēkas augšpusē, kas pārtrauc atmiņas izsmelšanu.)
    ///
    /// Klienti, kuri vēlas pārtraukt aprēķinu, reaģējot uz piešķiršanas kļūdu, tiek aicināti izsaukt funkciju [`handle_alloc_error`], nevis tieši izsaukt `panic!` vai tamlīdzīgu.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // DROŠĪBA: jo `new_layout.size()` jābūt lielākam par vai vienādam ar
        // `old_layout.size()`, gan vecā, gan jaunā atmiņas piešķiršana ir derīga lasījumiem un ierakstiem `old_layout.size()` baitiem.
        // Tā kā vecais sadalījums vēl nebija sadalīts, tas nevar pārklāties ar `new_ptr`.
        // Tādējādi zvans uz `copy_nonoverlapping` ir drošs.
        // Zvanītājam jāievēro `dealloc` drošības līgums.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Rīkojas kā `grow`, bet arī nodrošina, ka jaunais saturs tiek iestatīts uz nulli, pirms tas tiek atgriezts.
    ///
    /// Pēc veiksmīga zvana uz atmiņas bloku būs šāds saturs
    /// `grow_zeroed`:
    ///   * Biti `0..old_layout.size()` tiek saglabāti no sākotnējā piešķīruma.
    ///   * Biti `old_layout.size()..old_size` tiks vai nu saglabāti, vai nulles līmenī, atkarībā no sadalītāja ieviešanas.
    ///   `old_size` attiecas uz atmiņas bloka lielumu pirms `grow_zeroed` zvana, kas var būt lielāks par sākotnēji pieprasīto lielumu, kad tas tika piešķirts.
    ///   * Bytes `old_size..new_size` tiek nulle.`new_size` attiecas uz atmiņas bloka lielumu, ko atdeva `grow_zeroed` zvans.
    ///
    /// # Safety
    ///
    /// * `ptr` caur šo atdalītāju jānorāda atmiņas bloks [*currently allocated*].
    /// * `old_layout` jāpievieno [*fit*] šis atmiņas bloks (argumentam `new_layout` tas nav jāatbilst.).
    /// * `new_layout.size()` jābūt lielākai par `old_layout.size()` vai vienādai ar to.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Atgriež vērtību `Err`, ja jaunais izkārtojums neatbilst sadalītāja lieluma un izlīdzinātāja ierobežojumiem vai ja augšana citādi neizdodas.
    ///
    /// Ieviesumi tiek mudināti atgriezt `Err` atmiņas izsīkuma vietā, nevis panikā vai pārtraukumā, taču tā nav stingra prasība.
    /// (Konkrēti:*likumīgi* ir ieviest šo trait pamatā esošās vietējās piešķiršanas bibliotēkas augšpusē, kas pārtrauc atmiņas izsmelšanu.)
    ///
    /// Klienti, kuri vēlas pārtraukt aprēķinu, reaģējot uz piešķiršanas kļūdu, tiek aicināti izsaukt funkciju [`handle_alloc_error`], nevis tieši izsaukt `panic!` vai tamlīdzīgu.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // DROŠĪBA: jo `new_layout.size()` jābūt lielākam par vai vienādam ar
        // `old_layout.size()`, gan vecā, gan jaunā atmiņas piešķiršana ir derīga lasījumiem un ierakstiem `old_layout.size()` baitiem.
        // Tā kā vecais sadalījums vēl nebija sadalīts, tas nevar pārklāties ar `new_ptr`.
        // Tādējādi zvans uz `copy_nonoverlapping` ir drošs.
        // Zvanītājam jāievēro `dealloc` drošības līgums.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Mēģinājumi samazināt atmiņas bloku.
    ///
    /// Atgriež jaunu [`NonNull<[u8]>`][NonNull], kas satur rādītāju un piešķirto atmiņu faktisko lielumu.Rādītājs ir piemērots `new_layout` aprakstīto datu glabāšanai.
    /// Lai to paveiktu, sadalītājs var samazināt `ptr` norādīto piešķīrumu, lai tas atbilstu jaunajam izkārtojumam.
    ///
    /// Ja tas atgriež `Ok`, īpašumtiesības uz atmiņas bloku, uz kuru atsaucas `ptr`, ir nodotas šim sadalītājam.
    /// Iespējams, ka atmiņa ir vai nav atbrīvojusies, un tā jāuzskata par nelietojamu, ja vien tā netiek atkārtoti pārsūtīta atpakaļ zvanītājam, izmantojot šīs metodes atgriešanās vērtību.
    ///
    /// Ja šī metode atgriež `Err`, tad atmiņas bloka īpašumtiesības šim piešķīrējam nav nodotas, un atmiņas bloka saturs netiek mainīts.
    ///
    /// # Safety
    ///
    /// * `ptr` caur šo atdalītāju jānorāda atmiņas bloks [*currently allocated*].
    /// * `old_layout` jāpievieno [*fit*] šis atmiņas bloks (argumentam `new_layout` tas nav jāatbilst.).
    /// * `new_layout.size()` jābūt mazākam vai vienādam ar `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Atgriež `Err`, ja jaunais izkārtojums neatbilst sadalītāja lieluma un izlīdzinātāja ierobežojumiem vai ja samazināšana citādi neizdodas.
    ///
    /// Ieviesumi tiek mudināti atgriezt `Err` atmiņas izsīkuma vietā, nevis panikā vai pārtraukumā, taču tā nav stingra prasība.
    /// (Konkrēti:*likumīgi* ir ieviest šo trait pamatā esošās vietējās piešķiršanas bibliotēkas augšpusē, kas pārtrauc atmiņas izsmelšanu.)
    ///
    /// Klienti, kuri vēlas pārtraukt aprēķinu, reaģējot uz piešķiršanas kļūdu, tiek aicināti izsaukt funkciju [`handle_alloc_error`], nevis tieši izsaukt `panic!` vai tamlīdzīgu.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // DROŠĪBA: jo `new_layout.size()` jābūt zemākam vai vienādam ar
        // `old_layout.size()`, gan vecā, gan jaunā atmiņas piešķiršana ir derīga lasījumiem un ierakstiem `new_layout.size()` baitiem.
        // Tā kā vecais sadalījums vēl nebija sadalīts, tas nevar pārklāties ar `new_ptr`.
        // Tādējādi zvans uz `copy_nonoverlapping` ir drošs.
        // Zvanītājam jāievēro `dealloc` drošības līgums.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Izveido "by reference" adapteri šim `Allocator` gadījumam.
    ///
    /// Atgrieztais adapteris arī ievieš `Allocator` un vienkārši to aizņemsies.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // DROŠĪBA: zvanītājam jāievēro drošības līgums
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // DROŠĪBA: zvanītājam jāievēro drošības līgums
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // DROŠĪBA: zvanītājam jāievēro drošības līgums
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // DROŠĪBA: zvanītājam jāievēro drošības līgums
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}