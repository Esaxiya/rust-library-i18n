//! Definē `IntoIter` piederošo masīvu iteratoru.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// [array] iterators ar blakus vērtību.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Tas ir masīvs, kuru mēs atkārtojam.
    ///
    /// Elementi ar indeksu `i`, kur `alive.start <= i < alive.end` vēl nav iegūti, ir derīgi masīva ieraksti.
    /// Elementi ar indeksu `i < alive.start` vai `i >= alive.end` jau ir iegūti, un tiem vairs nedrīkst piekļūt!Tie mirušie elementi varētu būt pat pilnīgi neinicializētā stāvoklī!
    ///
    ///
    /// Tātad invarianti ir:
    /// - `data[alive]` ir dzīvs (ti, satur derīgus elementus)
    /// - `data[..alive.start]` un `data[alive.end..]` ir miruši (ti, elementi jau bija lasīti un tos vairs nedrīkst pieskarties!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// `data` elementi, kas vēl nav iegūti.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Izveido jaunu iteratoru pār doto `array`.
    ///
    /// *Piezīme*: šī metode var būt novecojusi future pēc [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // Šeit `value` tips ir `i32`, nevis `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // DROŠĪBA: Transmute šeit ir faktiski droša.`MaybeUninit` dokumenti
        // promise:
        //
        // > `MaybeUninit<T>` tiek garantēts vienāds izmērs un izlīdzinājums
        // > kā `T`.
        //
        // Dokumentos pat tiek parādīts pārveidojums no `MaybeUninit<T>` masīva uz `T` masīvu.
        //
        //
        // Ar to šī inicializācija apmierina invariantus.

        // FIXME(LukasKalbertodt): šeit faktiski izmantojiet `mem::transmute`, tiklīdz tas darbojas ar gener generics:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Līdz tam mēs varam izmantot `mem::transmute_copy`, lai izveidotu bitu kopiju kā citu tipu, pēc tam aizmirstam `array`, lai tā netiktu nomesta.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Atgriež nemaināmu visu vēl neizdoto elementu šķēli.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // DROŠĪBA: Mēs zinām, ka visi `alive` elementi ir pareizi inicializēti.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Atgriež visu to elementu maināmo daļu, kuri vēl nav iegūti.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // DROŠĪBA: Mēs zinām, ka visi `alive` elementi ir pareizi inicializēti.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Iegūstiet nākamo indeksu no priekšpuses.
        //
        // `alive.start` palielināšana par 1 saglabā nemainīgo attiecībā uz `alive`.
        // Tomēr šo izmaiņu dēļ uz īsu brīdi dzīvā zona vairs nav `data[alive]`, bet gan `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Izlasiet masīva elementu.
            // DROŠĪBA: `idx` ir rādītājs bijušajā "alive" reģionā
            // masīvs.Šī elementa lasīšana nozīmē, ka `data[idx]` tagad tiek uzskatīts par mirušu (ti, nepieskarieties).
            // Tā kā `idx` bija dzīvās zonas sākums, dzīvā zona tagad atkal ir `data[alive]`, atjaunojot visus invariantus.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Iegūstiet nākamo indeksu no aizmugures.
        //
        // `alive.end` samazināšana par 1 saglabā nemainīgo attiecībā uz `alive`.
        // Tomēr šo izmaiņu dēļ uz īsu brīdi dzīvā zona vairs nav `data[alive]`, bet gan `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Izlasiet masīva elementu.
            // DROŠĪBA: `idx` ir rādītājs bijušajā "alive" reģionā
            // masīvs.Šī elementa lasīšana nozīmē, ka `data[idx]` tagad tiek uzskatīts par mirušu (ti, nepieskarieties).
            // Tā kā `idx` bija dzīvās zonas beigas, dzīvā zona tagad atkal ir `data[alive]`, atjaunojot visus invariantus.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // DROŠĪBA: Tas ir droši: `as_mut_slice` atgriež tieši apakšslāni
        // elementu, kas vēl nav pārvietoti un kuri vēl ir jāizmet.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Nekad nepieplūdīs nemainīgā `dzīvā.sākt <=dēļ
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Atkārtotājs patiešām ziņo par pareizo garumu.
// "alive" elementu skaits (kas joprojām tiks iegūts) ir diapazona `alive` garums.
// Šī diapazona garums tiek samazināts `next` vai `next_back`.
// Šajās metodēs to vienmēr samazina ar 1, bet tikai tad, ja `Some(_)` tiek atgriezts.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Ņemiet vērā, ka mums patiesībā nav jāsaskaņo tieši ar to pašu dzīvo diapazonu, tāpēc mēs varam vienkārši klonēt 0 nobīdē neatkarīgi no tā, kur atrodas `self`.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Klonējiet visus dzīvos elementus.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Ierakstiet klonu jaunajā masīvā, pēc tam atjauniniet tā dzīvo diapazonu.
            // Ja klonē panics, mēs pareizi nometīsim iepriekšējos vienumus.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Drukājiet tikai tos elementus, kuri vēl nav iegūti: mēs vairs nevaram piekļūt iegūtajiem elementiem.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}