use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Iesaiņojums ap neapstrādātu nulles vērtību `*mut T`, kas norāda, ka šī iesaiņojuma īpašniekam pieder referents.
/// Noderīgi ēku abstrakcijām, piemēram, `Box<T>`, `Vec<T>`, `String` un `HashMap<K, V>`.
///
/// Atšķirībā no `*mut T`, `Unique<T>` izturas "as if", tas bija `T` gadījums.
/// Tas ievieš `Send`/`Sync`, ja `T` ir `Send`/`Sync`.
/// Tas nozīmē arī spēcīgas pseidonīmu garantijas, kuras `T` eksemplārs var sagaidīt:
/// rādītāja atsauci nevajadzētu modificēt, ja nav unikāla ceļa, lai atrastos unikāls.
///
/// Ja neesat pārliecināts, vai ir pareizi izmantot `Unique` jūsu mērķiem, apsveriet iespēju izmantot `NonNull`, kam ir vājāka semantika.
///
///
/// Atšķirībā no `*mut T`, rādītājam vienmēr jābūt nullei pat tad, ja rādītājs nekad netiek noraidīts.
/// Tas ir tāpēc, ka enums var izmantot šo aizliegto vērtību kā diskriminantu-`Option<Unique<T>>` ir tāds pats izmērs kā `Unique<T>`.
/// Tomēr rādītājs joprojām var šūpoties, ja tas nav norādīts.
///
/// Atšķirībā no `*mut T`, `Unique<T>` ir mainīgs pār `T`.
/// Tam vienmēr jābūt pareizam jebkuram tipam, kurš ievēro Unique aizstājvārda prasības.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: šim marķierim nav ietekmes uz dispersiju, bet tas ir nepieciešams
    // lai dropck saprastu, ka mums loģiski pieder `T`.
    //
    // Sīkāku informāciju skatiet šeit:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` rādītāji ir `Send`, ja `T` ir `Send`, jo dati, uz kuriem tie atsaucas, nav alias.
/// Ņemiet vērā, ka šo aizstājējinvariantu tipa sistēma nepiespiež;abstrakcijai, izmantojot `Unique`, tas jāpiespiež.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` rādītāji ir `Sync`, ja `T` ir `Sync`, jo dati, uz kuriem tie atsaucas, nav alias.
/// Ņemiet vērā, ka šo aizstājējinvariantu tipa sistēma nepiespiež;abstrakcijai, izmantojot `Unique`, tas jāpiespiež.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Izveido jaunu `Unique`, kas ir piekārts, bet labi izlīdzināts.
    ///
    /// Tas ir noderīgi, lai inicializētu tipus, kurus slinki piešķir, piemēram, `Vec::new`.
    ///
    /// Ņemiet vērā, ka rādītāja vērtība, iespējams, apzīmē derīgu `T` rādītāju, kas nozīmē, ka to nedrīkst izmantot kā "not yet initialized" sentinel vērtību.
    /// Veidiem, kurus slinki piešķir, ir jāizseko inicializācija ar citiem līdzekļiem.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // DROŠĪBA: mem::align_of() atgriež derīgu rādītāju, kas nav nulle.The
        // tādējādi tiek ievēroti nosacījumi, lai izsauktu new_unchecked().
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Izveido jaunu `Unique`.
    ///
    /// # Safety
    ///
    /// `ptr` jābūt nullei.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // DROŠĪBA: zvanītājam jāgarantē, ka `ptr` nav nulle.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Ja `ptr` nav nulle, izveido jaunu `Unique`.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // DROŠĪBA: rādītājs jau ir pārbaudīts, un tas nav nulle.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Iegūst pamatā esošo `*mut` rādītāju.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Novirza saturu.
    ///
    /// Iegūtais dzīves ilgums ir saistīts ar sevi, tāpēc tas darbojas "as if", tas faktiski bija T gadījums, kas tiek aizņemts.
    /// Ja nepieciešams ilgāks (unbound) kalpošanas laiks, izmantojiet `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // DROŠĪBA: zvanītājam ir jāgarantē, ka `self` atbilst visiem
        // prasības atsaucei.
        unsafe { &*self.as_ptr() }
    }

    /// Maināmi novirza saturu.
    ///
    /// Iegūtais dzīves ilgums ir saistīts ar sevi, tāpēc tas darbojas "as if", tas faktiski bija T gadījums, kas tiek aizņemts.
    /// Ja nepieciešams ilgāks (unbound) kalpošanas laiks, izmantojiet `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // DROŠĪBA: zvanītājam ir jāgarantē, ka `self` atbilst visiem
        // prasības mainīgai atsaucei.
        unsafe { &mut *self.as_ptr() }
    }

    /// Apraida cita veida rādītāju.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // DROŠĪBA: Unique::new_unchecked() rada jaunu unikumu un vajadzības
        // dotais rādītājs nav nulle.
        // Tā kā mēs nododam sevi kā rādītāju, tas nevar būt nulle.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // DROŠĪBA: maināma atsauce nevar būt nulle
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}