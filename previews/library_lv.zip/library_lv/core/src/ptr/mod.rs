//! Manuāli pārvaldiet atmiņu, izmantojot neapstrādātas norādes.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Daudzas funkcijas šajā modulī neapstrādātas norādes uzskata par argumentiem un no tām lasa vai raksta.Lai tas būtu droši, šiem rādītājiem jābūt *derīgiem*.
//! Tas, vai rādītājs ir derīgs, ir atkarīgs no operācijas, kurai tas tiek izmantots (lasīšana vai rakstīšana), un no atmiņas apjoma, kuram tiek piekļūts (ti, cik baitu ir read/written).
//! Lielākā daļa funkciju izmanto `*mut T` un `* const T`, lai piekļūtu tikai vienai vērtībai. Šajā gadījumā dokumentācijā nav norādīts lielums un netieši tiek pieņemts, ka tā ir `size_of::<T>()` baiti.
//!
//! Precīzi derīguma noteikumi vēl nav noteikti.Šajā brīdī sniegtās garantijas ir ļoti minimālas:
//!
//! * [null] rādītājs * nekad nav derīgs pat [size zero][zst] piekļuvēm.
//! * Lai rādītājs būtu derīgs, ir nepieciešams, bet ne vienmēr pietiekams, lai rādītājs būtu *novirzāms*: norādītā lieluma atmiņas diapazonam, kas sākas ar rādītāju, visiem jābūt viena piešķirtā objekta robežās.
//!
//! Ņemiet vērā, ka programmā Rust katrs mainīgais (stack-allocated) tiek uzskatīts par atsevišķu piešķirtu objektu.
//! * Pat operācijām [size zero][zst] rādītājs nedrīkst norādīt uz atdalīto atmiņu, ti, darījumu izvietošana padara rādītājus nederīgus pat nulles lieluma operācijām.
//! Tomēr jebkura nulles vesela skaitļa *literāla* nodošana rādītājā ir derīga nulles lieluma piekļuvēm, pat ja šajā adresē pastāv kāda atmiņa un tā tiek sadalīta.
//! Tas atbilst paša piešķīrēja rakstīšanai: nulles lieluma objektu piešķiršana nav ļoti grūta.
//! Kanoniskais veids, kā iegūt rādītāju, kas derīgs nulles lieluma piekļuvēm, ir [`NonNull::dangling`].
//! * Visas piekļuves, kuras veic šī moduļa funkcijas, X *X nozīmē nav atomu*, ko izmanto, lai sinhronizētu starp pavedieniem.
//! Tas nozīmē, ka nav noteikta rīcība, veicot divas vienlaicīgas piekļuves vienai un tai pašai vietai, izmantojot dažādas tēmas, ja vien abas piekļuves nelasa tikai no atmiņas.
//! Ievērojiet, ka tas nepārprotami ietver [`read_volatile`] un [`write_volatile`]: Nepastāvīgas piekļuves nevar izmantot sinhronizācijai starp pavedieniem.
//! * Atsauces uz rādītāju nodošanas rezultāts ir derīgs tik ilgi, kamēr pamatā esošais objekts ir aktīvs, un, lai piekļūtu tai pašai atmiņai, netiek izmantota atsauce (tikai neapstrādātas norādes).
//!
//! Šīs aksiomas kopā ar rūpīgu [`offset`] izmantošanu rādītāju aritmētikā ir pietiekamas, lai pareizi ieviestu daudzas noderīgas lietas nedrošā kodā.
//! Galu galā tiks nodrošinātas stingrākas garantijas, jo tiek noteikti [aliasing] noteikumi.
//! Lai iegūtu vairāk informācijas, skatiet [book], kā arī sadaļu atsaucē, kas veltīta [undefined behavior][ub].
//!
//! ## Alignment
//!
//! Derīgi neapstrādāti rādītāji, kā definēts iepriekš, ne vienmēr ir pareizi izlīdzināti (ja "proper" līdzinājumu nosaka pointee tips, ti, `*const T` ir jāsaskaņo ar `mem::align_of::<T>()`).
//! Tomēr lielākajai daļai funkciju viņu argumenti ir pareizi jāsaskaņo, un šī prasība tiks skaidri norādīta viņu dokumentācijā.
//! Ievērojami izņēmumi ir [`read_unaligned`] un [`write_unaligned`].
//!
//! Ja funkcijai nepieciešama pareiza izlīdzināšana, tā to dara pat tad, ja piekļuves lielums ir 0, ti, pat ja atmiņa faktiski netiek pieskāries.Apsveriet iespēju izmantot [`NonNull::dangling`] šādos gadījumos.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Izpilda norādītās vērtības iznīcinātāju (ja tāds ir).
///
/// Tas ir semantiski ekvivalents [`ptr::read`] izsaukšanai un rezultāta atmešanai, taču tam ir šādas priekšrocības:
///
/// * Lai izmestu tādus lieluma veidus kā trait objekti, ir *nepieciešams* izmantot `drop_in_place`, jo tos nevar nolasīt kaudzē un normāli nomest.
///
/// * Optimizatoram ir draudzīgāk to darīt, izmantojot [`ptr::read`], nometot manuāli piešķirto atmiņu (piem., `Box`/`Rc`/`Vec` ieviešanā), jo kompilatoram nav jāpierāda, ka tas ir skaists, lai nokopētu kopiju.
///
///
/// * To var izmantot, lai nomestu [pinned] datus, ja `T` nav `repr(packed)` (piespraustos datus nedrīkst pārvietot, pirms tie tiek nomesti).
///
/// Nesalīdzinātas vērtības nevar nomest vietā, tās vispirms jāpārkopē līdzinātā vietā, izmantojot [`ptr::read_unaligned`].Iesaiņotiem fragmentiem kompilators šo kustību veic automātiski.
/// Tas nozīmē, ka iesaiņoto struktūru lauki netiek nomesti vietā.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// Uzvedība nav definēta, ja tiek pārkāpts kāds no šiem nosacījumiem:
///
/// * `to_drop` jābūt [valid] gan lasīšanai, gan rakstīšanai.
///
/// * `to_drop` jābūt pareizi izlīdzinātam.
///
/// * Vērtībai `to_drop` norāda līdz jābūt derīgai, lai nomestu, kas var nozīmēt, ka tai ir jāuztur papildu invarianti, tas ir atkarīgs no veida.
///
/// Turklāt, ja `T` nav [`Copy`], izmantojot norādīto vērtību pēc izsaukšanas uz `drop_in_place`, var izraisīt nedefinētu rīcību.Ņemiet vērā, ka `*to_drop = foo` tiek uzskatīts par lietojumu, jo tas atkal samazinās vērtību.
/// [`write()`] var izmantot, lai pārrakstītu datus, neizraisot to nomešanu.
///
/// Ņemiet vērā, ka pat tad, ja `T` ir `0` izmērs, rādītājam nav jābūt NULL un tam jābūt pareizi izlīdzinātam.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Manuāli noņemiet pēdējo vienumu no vector:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Iegūstiet neapstrādātu rādītāju uz pēdējo `v` elementu.
///     let ptr = &mut v[1] as *mut _;
///     // Saīsiniet `v`, lai nepieļautu pēdējā vienuma nomēšanu.
///     // Mēs to darām vispirms, lai novērstu problēmas, ja `drop_in_place` ir zemāks par panics.
///     v.set_len(1);
///     // Bez zvana `drop_in_place` pēdējā vienība nekad netiktu nomesta, un tā pārvaldītā atmiņa tiktu nopludināta.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Pārliecinieties, ka pēdējais vienums tika nomests.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Ievērojiet, ka kompilators šo kopiju veic automātiski, kad tiek izmesti iesaiņoti sūtījumi, ti, jums parasti nav jāuztraucas par šādām problēmām, ja vien jūs pats nezvanāt uz `drop_in_place`.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Šeit esošajam kodam nav nozīmes, kompilators to aizstāj ar īsto pilienu līmi.
    //

    // DROŠĪBA: skatīt komentāru iepriekš
    unsafe { drop_in_place(to_drop) }
}

/// Izveido nulles neapstrādātu rādītāju.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Izveido nulles maināmu neapstrādātu rādītāju.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// Lai izvairītos no saistīšanas ar `T: Clone`, nepieciešama manuāla impl.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// Lai izvairītos no saistīšanas ar `T: Copy`, nepieciešama manuāla impl.
impl<T> Copy for FatPtr<T> {}

/// No rādītāja un garuma veido neapstrādātu šķēli.
///
/// `len` arguments ir **elementu** skaits, nevis baitu skaits.
///
/// Šī funkcija ir droša, taču faktiski atgriešanās vērtības izmantošana nav droša.
/// Sadaļu drošības prasības skatiet [`slice::from_raw_parts`] dokumentācijā.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // izveidojiet šķēles rādītāju, sākot ar rādītāju pirmajam elementam
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // DROŠĪBA: Piekļuve vērtībai no savienojuma `Repr` ir droša, jo * const [T]
        //
        // un FatPtr ir vienādi atmiņas izkārtojumi.Tikai std var sniegt šo garantiju.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Veic tādu pašu funkcionalitāti kā [`slice_from_raw_parts`], izņemot to, ka tiek atgriezta neapstrādāta mainīga šķēle, atšķirībā no neapstrādātas nemainīgas šķēles.
///
///
/// Plašāku informāciju skatiet [`slice_from_raw_parts`] dokumentācijā.
///
/// Šī funkcija ir droša, taču faktiski atgriešanās vērtības izmantošana nav droša.
/// Skatiet sadaļu drošības prasības [`slice::from_raw_parts_mut`] dokumentācijā.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // piešķiriet vērtību šķēles indeksā
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // DROŠĪBA: Piekļuve vērtībai no savienojuma `Repr` ir droša, jo * mut [T]
        // un FatPtr ir vienādi atmiņas izkārtojumi
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Maina vērtības divās viena veida mainīgās vietās, neveicot arī deinicializāciju.
///
/// Bet attiecībā uz šādiem diviem izņēmumiem šī funkcija ir semantiski ekvivalenta [`mem::swap`]:
///
///
/// * Tas darbojas ar neapstrādātiem rādītājiem, nevis atsaucēm.
/// Kad ir pieejamas atsauces, priekšroka jādod [`mem::swap`].
///
/// * Abas norādītās vērtības var pārklāties.
/// Ja vērtības pārklājas, tiks izmantots atmiņas apgabals, kas pārklājas no `x`.
/// Tas ir parādīts otrajā piemērā zemāk.
///
/// # Safety
///
/// Uzvedība nav definēta, ja tiek pārkāpts kāds no šiem nosacījumiem:
///
/// * Gan `x`, gan `y` jābūt [valid] gan lasīšanai, gan rakstīšanai.
///
/// * Gan `x`, gan `y` ir pareizi jāsaskaņo.
///
/// Ņemiet vērā, ka pat tad, ja `T` ir `0` izmērs, rādītājiem nav jābūt NULL un pareizi izlīdzinātiem.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Mainot divus reģionus, kas nepārklājas:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // tas ir `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // tas ir `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Mainot divus reģionus, kas pārklājas:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // tas ir `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // tas ir `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // Šķēles indeksi `1..3` pārklājas starp `x` un `y`.
///     // Saprātīgi rezultāti būtu, ja viņiem būtu `[2, 3]`, tāpēc, ka indeksi `0..3` ir `[1, 2, 3]` (atbilst `y` pirms `swap`);vai arī, lai tie būtu `[0, 1]`, lai indeksi `1..4` būtu `[0, 1, 2]` (pirms `swap` sakrīt ar `x`).
/////
///     // Šī ieviešana ir definēta, lai izdarītu pēdējo izvēli.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Dodiet sev nedaudz vietas, lai strādātu.
    // Mums nav jāuztraucas par pilieniem: nokrītot, `MaybeUninit` nedara neko.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Veiciet mijmaiņas DROŠĪBU: zvanītājam jāgarantē, ka `x` un `y` ir derīgi rakstīšanai un pareizi izlīdzināti.
    // `tmp` nevar pārklāties ne `x`, ne `y`, jo `tmp` tikko tika piešķirts kaudzītē kā atsevišķs piešķirts objekts.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` un `y` var pārklāties
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Apmaina `count * size_of::<T>()` baitus starp abiem atmiņas reģioniem, sākot no `x` un `y`.
/// Abi reģioni nedrīkst * pārklāties.
///
/// # Safety
///
/// Uzvedība nav definēta, ja tiek pārkāpts kāds no šiem nosacījumiem:
///
/// * Gan `x`, gan `y` jābūt [valid] gan skaitot, gan lasot *
///   ::<T>() `baiti.
///
/// * Gan `x`, gan `y` ir pareizi jāsaskaņo.
///
/// * Atmiņas reģions, kas sākas `x` un kura lielums ir `count *
///   ::<T>() `baiti nedrīkst * pārklāties ar tāda paša izmēra atmiņas reģionu, kas sākas `y`.
///
/// Ņemiet vērā, ka pat tad, ja faktiski nokopētais lielums (`skaits * izmērs: <T>()`) ir `0`, rādītājiem nedrīkst būt NULL un pareizi jāsaskaņo.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Pamata lietojums:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // DROŠĪBA: zvanītājam ir jāgarantē, ka `x` un `y` ir
    // derīgs rakstīšanai un pareizi izlīdzināts.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // Tiem tipiem, kas ir mazāki par zemāk norādīto bloka optimizāciju, vienkārši nomainiet tieši, lai izvairītos no pesimizācijas kodegen.
    //
    if mem::size_of::<T>() < 32 {
        // DROŠĪBA: zvanītājam jāgarantē, ka `x` un `y` ir derīgi
        // rakstiem, pareizi izlīdzināti un nepārklājas.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // DROŠĪBA: zvanītājam jāievēro `swap_nonoverlapping` drošības līgums.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // Šeit pieeja ir simd izmantošana, lai efektīvi apmainītu x&y.
    // Pārbaudot tiek atklāts, ka 32 vai 64 baitu nomaiņa vienlaikus ir visefektīvākā Intel Haswell E procesoriem.
    // LLVM spēj vairāk optimizēt, ja struktūrai piešķiram #[repr(simd)], pat ja šo struktūru faktiski neizmantojam tieši.
    //
    //
    // FIXME repr(simd) sadalīts emscripten un redox
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Loop caur x&y, kopējot tos `Block` vienlaikus Optimizatoram vajadzētu pilnībā atritināt cilpu lielākajai daļai NB
    // Mēs nevaram izmantot for loop, jo `range` impls izsauc `mem::swap` rekursīvi
    //
    let mut i = 0;
    while i + block_size <= len {
        // Izveidojiet kādu neinicializētu atmiņu kā tukšu vietu. Šeit deklarējot `t`, tiek novērsta kaudzes izlīdzināšana, ja šī cilpa nav izmantota
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // DROŠĪBA: Kā `i < len` un kā zvanītājam ir jāgarantē, ka `x` un `y` ir derīgi
        // `len` baitiem `x + i` un `y + i` ir jābūt derīgām adresēm, kas atbilst `add` drošības līgumam.
        //
        // Tāpat zvanītājam ir jāgarantē, ka `x` un `y` ir derīgi ierakstiem, pareizi izlīdzināti un nepārklājas, kas atbilst `copy_nonoverlapping` drošības līgumam.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Apmainiet x&y baitu bloku, izmantojot t kā pagaidu buferi. Tas būtu jāoptimizē efektīvām SIMD darbībām, ja tādas ir pieejamas
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Apmaini visus atlikušos baitus
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // DROŠĪBA: skatīt iepriekšējo drošības komentāru.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// Pārvieto `src` uz smailu `dst`, atgriežot iepriekšējo `dst` vērtību.
///
/// Neviena no vērtībām netiek nomesta.
///
/// Šī funkcija ir semantiski ekvivalenta [`mem::replace`], izņemot to, ka tā darbojas ar neapstrādātiem rādītājiem, nevis atsaucēm.
/// Kad ir pieejamas atsauces, priekšroka jādod [`mem::replace`].
///
/// # Safety
///
/// Uzvedība nav definēta, ja tiek pārkāpts kāds no šiem nosacījumiem:
///
/// * `dst` jābūt [valid] gan lasīšanai, gan rakstīšanai.
///
/// * `dst` jābūt pareizi izlīdzinātam.
///
/// * `dst` jānorāda uz pareizi inicializētu `T` tipa vērtību.
///
/// Ņemiet vērā, ka pat tad, ja `T` ir `0` izmērs, rādītājam nav jābūt NULL un tam jābūt pareizi izlīdzinātam.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` būtu tāds pats efekts, neprasot nedrošo bloķēšanu.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // DROŠĪBA: zvanītājam ir jāgarantē, ka `dst` ir derīgs
    // apraidīts uz maināmu atsauci (derīgs rakstīšanai, izlīdzināšanai, inicializēšanai) un nevar pārklāties ar `src`, jo `dst` jānorāda uz atšķirīgu piešķirto objektu.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // nevar pārklāties
    }
    src
}

/// Nolasa vērtību no `src`, to nepārvietojot.Tādējādi atmiņa operētājsistēmā `src` netiek mainīta.
///
/// # Safety
///
/// Uzvedība nav definēta, ja tiek pārkāpts kāds no šiem nosacījumiem:
///
/// * `src` lasījumiem jābūt [valid].
///
/// * `src` jābūt pareizi izlīdzinātam.Ja tas tā nav, izmantojiet [`read_unaligned`].
///
/// * `src` jānorāda uz pareizi inicializētu `T` tipa vērtību.
///
/// Ņemiet vērā, ka pat tad, ja `T` ir `0` izmērs, rādītājam nav jābūt NULL un tam jābūt pareizi izlīdzinātam.
///
/// # Examples
///
/// Pamata lietojums:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Manuāli ieviest [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Izveidojiet vērtības `a` vērtību bitā kopiju `tmp`.
///         let tmp = ptr::read(a);
///
///         // Iziešana šajā brīdī (vai nu skaidri atgriežoties, vai izsaucot funkciju, kuru panics) izraisīs `tmp` vērtības kritumu, kamēr uz to pašu vērtību joprojām atsaucas `a`.
///         // Tas var izraisīt nedefinētu rīcību, ja `T` nav `Copy`.
/////
/////
///
///         // Izveidojiet vērtības `b` vērtību bitā kopiju `a`.
///         // Tas ir droši, jo maināmās atsauces nevar aizstājvārdu.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Kā iepriekš, iziešana šeit var izraisīt nedefinētu rīcību, jo uz to pašu vērtību atsaucas `a` un `b`.
/////
///
///         // Pārvietojiet `tmp` uz `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` ir pārvietots (`write` pārņem savu otro argumentu īpašumtiesības), tāpēc šeit nekas netieši tiek nomests.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Īpašumtiesības uz atgriezto vērtību
///
/// `read` izveido `T` bitu kopiju neatkarīgi no tā, vai `T` ir [`Copy`].
/// Ja `T` nav [`Copy`], izmantojot gan atgriezto vērtību, gan vērtību pie `*src`, var tikt pārkāpta atmiņas drošība.
/// Ņemiet vērā, ka piešķiršana `*src` tiek uzskatīta par lietojumu, jo tā mēģinās nomest vērtību pie `* src`.
///
/// [`write()`] var izmantot, lai pārrakstītu datus, neizraisot to nomešanu.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` tagad norāda uz to pašu pamata atmiņu kā `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // Piešķirot `s2`, tā sākotnējā vērtība tiek pazemināta.
///     // Pēc šī punkta `s` vairs nedrīkst izmantot, jo pamatā esošā atmiņa ir atbrīvota.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // Piešķirot `s`, vecā vērtība atkal tiek nomesta, kā rezultātā tiek noteikta nedefinēta darbība.
/////
///     // s= String::from("bar");//KĻŪDA
///
///     // `ptr::write` var izmantot, lai pārrakstītu vērtību, nenometot to.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // DROŠĪBA: zvanītājam jāgarantē, ka `src` der der lasījumiem.
    // `src` nevar pārklāties ar `tmp`, jo `tmp` tika tikko piešķirts kaudzē kā atsevišķs piešķirtais objekts.
    //
    //
    // Turklāt, tā kā `tmp` tikko ierakstījām derīgu vērtību, tiek garantēts, ka tā tiks pareizi inicializēta.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Nolasa vērtību no `src`, to nepārvietojot.Tādējādi atmiņa operētājsistēmā `src` netiek mainīta.
///
/// Atšķirībā no [`read`], `read_unaligned` darbojas ar nesaskaņotiem rādītājiem.
///
/// # Safety
///
/// Uzvedība nav definēta, ja tiek pārkāpts kāds no šiem nosacījumiem:
///
/// * `src` lasījumiem jābūt [valid].
///
/// * `src` jānorāda uz pareizi inicializētu `T` tipa vērtību.
///
/// Tāpat kā [`read`], arī `read_unaligned` izveido `T` bitu kopiju neatkarīgi no tā, vai `T` ir [`Copy`].
/// Ja `T` nav [`Copy`], [violate memory safety][read-ownership] var izmantot gan atgriezto vērtību, gan vērtību `*src`.
///
/// Ņemiet vērā, ka pat tad, ja `T` ir `0` izmērs, rādītājam jābūt NULL.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## Uz `packed` struktūrām
///
/// Pašlaik nav iespējams izveidot neapstrādātas norādes uz nesaskaņotiem iepakotas struktūras laukiem.
///
/// Mēģinot izveidot neapstrādātu rādītāju `unaligned` struktūras laukam ar izteiksmi, piemēram, `&packed.unaligned as *const FieldType`, tiek izveidota starpposma nesalīdzināta atsauce, pirms tā tiek pārveidota par neapstrādātu rādītāju.
///
/// Tas, ka šī atsauce ir īslaicīga un nekavējoties nodota, nav nozīmes, jo sastādītājs vienmēr sagaida, ka atsauces tiks pareizi izlīdzinātas.
/// Rezultātā `&packed.unaligned as *const FieldType` lietošana izraisa tūlītēju* nenoteiktu uzvedību * jūsu programmā.
///
/// Piemērs, ko nedarīt un kā tas attiecas uz `read_unaligned`, ir šāds:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Šeit mēs mēģinām ņemt 32 bitu vesela skaitļa adresi, kas nav izlīdzināta.
///     let unaligned =
///         // Šeit tiek izveidota pagaidu nesaskaņota atsauce, kuras rezultāts ir nedefinēta darbība neatkarīgi no tā, vai atsauce tiek izmantota vai nē.
/////
///         &packed.unaligned
///         // Apstrāde ar neapstrādātu rādītāju nepalīdz;kļūda jau notika.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Tieša piekļuve nelīdzinātiem laukiem, piemēram, ar `packed.unaligned` ir droša.
///
///
///
///
///
///
// FIXME: Atjauniniet dokumentus, pamatojoties uz RFC #2582 un draugu rezultātiem.
/// # Examples
///
/// Lietojuma vērtības nolasīšana no baita bufera:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // DROŠĪBA: zvanītājam jāgarantē, ka `src` der der lasījumiem.
    // `src` nevar pārklāties ar `tmp`, jo `tmp` tika tikko piešķirts kaudzē kā atsevišķs piešķirtais objekts.
    //
    //
    // Turklāt, tā kā `tmp` tikko ierakstījām derīgu vērtību, tiek garantēts, ka tā tiks pareizi inicializēta.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Pārraksta atmiņas vietu ar norādīto vērtību, nelasot un nenometot veco vērtību.
///
/// `write` nemet `dst` saturu.
/// Tas ir droši, taču tas var nopludināt piešķīrumus vai resursus, tāpēc vajadzētu būt uzmanīgiem, lai nepārrakstītu objektu, kas būtu jānomet.
///
///
/// Turklāt tas nemet `src`.Semantiski `src` tiek pārvietots uz vietu, uz kuru norāda `dst`.
///
/// Tas ir piemērots, lai inicializētu neinicializēto atmiņu vai pārrakstītu atmiņu, kas iepriekš ir bijusi [`read`].
///
/// # Safety
///
/// Uzvedība nav definēta, ja tiek pārkāpts kāds no šiem nosacījumiem:
///
/// * `dst` rakstiem jābūt [valid].
///
/// * `dst` jābūt pareizi izlīdzinātam.Ja tas tā nav, izmantojiet [`write_unaligned`].
///
/// Ņemiet vērā, ka pat tad, ja `T` ir `0` izmērs, rādītājam nav jābūt NULL un tam jābūt pareizi izlīdzinātam.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Pamata lietojums:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Manuāli ieviest [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Izveidojiet vērtības `a` vērtību bitā kopiju `tmp`.
///         let tmp = ptr::read(a);
///
///         // Iziešana šajā brīdī (vai nu skaidri atgriežoties, vai izsaucot funkciju, kuru panics) izraisīs `tmp` vērtības kritumu, kamēr uz to pašu vērtību joprojām atsaucas `a`.
///         // Tas var izraisīt nedefinētu rīcību, ja `T` nav `Copy`.
/////
/////
///
///         // Izveidojiet vērtības `b` vērtību bitā kopiju `a`.
///         // Tas ir droši, jo maināmās atsauces nevar aizstājvārdu.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Kā iepriekš, iziešana šeit var izraisīt nedefinētu rīcību, jo uz to pašu vērtību atsaucas `a` un `b`.
/////
///
///         // Pārvietojiet `tmp` uz `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` ir pārvietots (`write` pārņem savu otro argumentu īpašumtiesības), tāpēc šeit nekas netieši tiek nomests.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Mēs tieši zvanām uz būtību, lai izvairītos no funkciju izsaukumiem ģenerētajā kodā, jo `intrinsics::copy_nonoverlapping` ir iesaiņošanas funkcija.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // DROŠĪBA: zvanītājam ir jāgarantē, ka `dst` ir derīgs rakstīšanai.
    // `dst` nevar pārklāties ar `src`, jo zvanītājam ir maināma piekļuve `dst`, kamēr `src` pieder šai funkcijai.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Pārraksta atmiņas vietu ar norādīto vērtību, nelasot un nenometot veco vērtību.
///
/// Atšķirībā no [`write()`], rādītājs var būt nelīdzināts.
///
/// `write_unaligned` nemet `dst` saturu.Tas ir droši, taču tas var nopludināt piešķīrumus vai resursus, tāpēc vajadzētu būt uzmanīgiem, lai nepārrakstītu objektu, kas būtu jānomet.
///
/// Turklāt tas nemet `src`.Semantiski `src` tiek pārvietots uz vietu, uz kuru norāda `dst`.
///
/// Tas ir piemērots, lai inicializētu neinicializēto atmiņu vai pārrakstītu atmiņu, kas iepriekš ir lasīta ar [`read_unaligned`].
///
/// # Safety
///
/// Uzvedība nav definēta, ja tiek pārkāpts kāds no šiem nosacījumiem:
///
/// * `dst` rakstiem jābūt [valid].
///
/// Ņemiet vērā, ka pat tad, ja `T` ir `0` izmērs, rādītājam jābūt NULL.
///
/// [valid]: self#safety
///
/// ## Uz `packed` struktūrām
///
/// Pašlaik nav iespējams izveidot neapstrādātas norādes uz nesaskaņotiem iepakotas struktūras laukiem.
///
/// Mēģinot izveidot neapstrādātu rādītāju `unaligned` struktūras laukam ar izteiksmi, piemēram, `&packed.unaligned as *const FieldType`, tiek izveidota starpposma nesalīdzināta atsauce, pirms tā tiek pārveidota par neapstrādātu rādītāju.
///
/// Tas, ka šī atsauce ir īslaicīga un nekavējoties nodota, nav nozīmes, jo sastādītājs vienmēr sagaida, ka atsauces tiks pareizi izlīdzinātas.
/// Rezultātā `&packed.unaligned as *const FieldType` lietošana izraisa tūlītēju* nenoteiktu uzvedību * jūsu programmā.
///
/// Piemērs, ko nedarīt un kā tas attiecas uz `write_unaligned`, ir šāds:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Šeit mēs mēģinām ņemt 32 bitu vesela skaitļa adresi, kas nav izlīdzināta.
///     let unaligned =
///         // Šeit tiek izveidota pagaidu nesaskaņota atsauce, kuras rezultāts ir nedefinēta darbība neatkarīgi no tā, vai atsauce tiek izmantota vai nē.
/////
///         &mut packed.unaligned
///         // Apstrāde ar neapstrādātu rādītāju nepalīdz;kļūda jau notika.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Tieša piekļuve nelīdzinātiem laukiem, piemēram, ar `packed.unaligned` ir droša.
///
///
///
///
///
///
///
///
///
// FIXME: Atjauniniet dokumentus, pamatojoties uz RFC #2582 un draugu rezultātiem.
/// # Examples
///
/// Uzrakstiet izmantošanas vērtību baitu buferī:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // DROŠĪBA: zvanītājam ir jāgarantē, ka `dst` ir derīgs rakstīšanai.
    // `dst` nevar pārklāties ar `src`, jo zvanītājam ir maināma piekļuve `dst`, kamēr `src` pieder šai funkcijai.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Mēs izsaucam iekšējo tieši, lai izvairītos no funkciju izsaukumiem ģenerētajā kodā.
        intrinsics::forget(src);
    }
}

/// Veic nepastāvīgu vērtības nolasīšanu no `src`, to nepārvietojot.Tādējādi atmiņa operētājsistēmā `src` netiek mainīta.
///
/// Nepastāvīgās darbības ir paredzētas darbam ar I/O atmiņu, un tiek garantēts, ka kompilators tos neizlemj un nepārkārtos citās nepastāvīgās darbībās.
///
/// # Notes
///
/// Rust pašlaik nav stingri un formāli definēts atmiņas modelis, tāpēc laika gaitā var mainīties precīza semantika, ko šeit nozīmē "volatile".
/// Tas nozīmē, ka semantika gandrīz vienmēr beigsies diezgan līdzīga [C11's definition of volatile][c11].
///
/// Sastādītājam nevajadzētu mainīt gaistošās atmiņas darbību relatīvo secību vai skaitu.
/// Tomēr gaistošās atmiņas darbības ar nulles lieluma tipiem (piemēram, ja nulles lieluma tips tiek nodots `read_volatile`) ir tukšs un tos var ignorēt.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Uzvedība nav definēta, ja tiek pārkāpts kāds no šiem nosacījumiem:
///
/// * `src` lasījumiem jābūt [valid].
///
/// * `src` jābūt pareizi izlīdzinātam.
///
/// * `src` jānorāda uz pareizi inicializētu `T` tipa vērtību.
///
/// Tāpat kā [`read`], arī `read_volatile` izveido `T` bitu kopiju neatkarīgi no tā, vai `T` ir [`Copy`].
/// Ja `T` nav [`Copy`], [violate memory safety][read-ownership] var izmantot gan atgriezto vērtību, gan vērtību `*src`.
/// Tomēr gandrīz [nepareizu] atmiņu uzglabāšana [[Copy`] veidos ir gandrīz nekorekta.
///
/// Ņemiet vērā, ka pat tad, ja `T` ir `0` izmērs, rādītājam nav jābūt NULL un tam jābūt pareizi izlīdzinātam.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Tāpat kā C, operācijas nestabilitātei nav nekādas nozīmes jautājumiem, kas saistīti ar vienlaicīgu piekļuvi no vairākiem pavedieniem.Nepastāvīgas piekļuves šajā ziņā rīkojas tieši tāpat kā ar atomu nesaistītas piekļuves.
///
/// Konkrēti, sacensība starp `read_volatile` un jebkuru rakstīšanas operāciju tajā pašā vietā ir nedefinēta uzvedība.
///
/// # Examples
///
/// Pamata lietojums:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Nav panikas, lai kodegēna ietekme būtu mazāka.
        abort();
    }
    // DROŠĪBA: zvanītājam jāievēro `volatile_load` drošības līgums.
    unsafe { intrinsics::volatile_load(src) }
}

/// Veic nepastāvīgu atmiņas vietas ierakstīšanu ar norādīto vērtību, nelasot un nenometot veco vērtību.
///
/// Nepastāvīgās darbības ir paredzētas darbam ar I/O atmiņu, un tiek garantēts, ka kompilators tos neizlemj un nepārkārtos citās nepastāvīgās darbībās.
///
/// `write_volatile` nemet `dst` saturu.Tas ir droši, taču tas var nopludināt piešķīrumus vai resursus, tāpēc vajadzētu būt uzmanīgiem, lai nepārrakstītu objektu, kas būtu jānomet.
///
/// Turklāt tas nemet `src`.Semantiski `src` tiek pārvietots uz vietu, uz kuru norāda `dst`.
///
/// # Notes
///
/// Rust pašlaik nav stingri un formāli definēts atmiņas modelis, tāpēc laika gaitā var mainīties precīza semantika, ko šeit nozīmē "volatile".
/// Tas nozīmē, ka semantika gandrīz vienmēr beigsies diezgan līdzīga [C11's definition of volatile][c11].
///
/// Sastādītājam nevajadzētu mainīt gaistošās atmiņas darbību relatīvo secību vai skaitu.
/// Tomēr gaistošās atmiņas darbības ar nulles lieluma tipiem (piemēram, ja nulles lieluma tips tiek nodots `write_volatile`) ir tukšs un tos var ignorēt.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Uzvedība nav definēta, ja tiek pārkāpts kāds no šiem nosacījumiem:
///
/// * `dst` rakstiem jābūt [valid].
///
/// * `dst` jābūt pareizi izlīdzinātam.
///
/// Ņemiet vērā, ka pat tad, ja `T` ir `0` izmērs, rādītājam nav jābūt NULL un tam jābūt pareizi izlīdzinātam.
///
/// [valid]: self#safety
///
/// Tāpat kā C, operācijas nestabilitātei nav nekādas nozīmes jautājumiem, kas saistīti ar vienlaicīgu piekļuvi no vairākiem pavedieniem.Nepastāvīgas piekļuves šajā ziņā rīkojas tieši tāpat kā ar atomu nesaistītas piekļuves.
///
/// Jo īpaši sacensība starp `write_volatile` un jebkuru citu darbību (lasīšanu vai rakstīšanu) vienā un tajā pašā vietā ir nedefinēta uzvedība.
///
/// # Examples
///
/// Pamata lietojums:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Nav panikas, lai kodegēna ietekme būtu mazāka.
        abort();
    }
    // DROŠĪBA: zvanītājam jāievēro `volatile_store` drošības līgums.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Izlīdziniet rādītāju `p`.
///
/// Aprēķiniet nobīdi (ņemot vērā `stride` soļa elementus), kas jāpielieto rādītājam `p`, lai rādītājs `p` tiktu pielīdzināts `a`.
///
/// Note: Šī ieviešana ir rūpīgi pielāgota nevis panic.panic tas ir UB.
/// Vienīgās reālās izmaiņas, ko šeit var veikt, ir `INV_TABLE_MOD_16` un ar to saistīto konstantu maiņa.
///
/// Ja mēs kādreiz izlemsim, ka ar `a` var saukt par sevi raksturīgo, kas nav divu spēks, iespējams, ir saprātīgāk vienkārši pāriet uz naivu ieviešanu, nevis mēģināt to pielāgot, lai pielāgotos šīm izmaiņām.
///
///
/// Visi jautājumi ir adresēti@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): Šo tiešo līdzekļu tieša izmantošana uzlabo kodegēnu opt līmenī <=
    // 1, kur šo darbību metožu versijas nav ieskicētas.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Aprēķiniet `x` modulo `m` multiplikatīvo modulāro apgriezto vērtību.
    ///
    /// Šī ieviešana ir pielāgota `align_offset`, un tai ir šādi priekšnosacījumi:
    ///
    /// * `m` ir divu spēks;
    /// * `x < m`; (ja `x ≥ m`, ievadiet vietā `x % m`)
    ///
    /// Šīs funkcijas ieviešana nedrīkst būt panic.Kādreiz.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Multiplikatīvā modulārā apgrieztā tabula modulo 2⁴=16.
        ///
        /// Ņemiet vērā, ka šajā tabulā nav vērtību, kur inverss nepastāv (ti, `0⁻¹ mod 16`, `2⁻¹ mod 16` utt.)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Modulo, kam paredzēts `INV_TABLE_MOD_16`.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // DROŠĪBA: `m` ir jābūt spēkam no diviem, tātad nav nulle.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Mēs atkārtojam "up", izmantojot šādu formulu:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // līdz 2²ⁿ ≥ m.Tad mēs varam samazināt līdz vēlamajam `m`, ņemot rezultātu `mod m`.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // Ņemiet vērā, ka mēs iesaiņošanas operācijas šeit izmantojam ar nodomu-sākotnējā formulā tiek izmantota, piemēram, `mod n` atņemšana.
                // Tas ir pilnīgi labi, ja to vietā veicam `mod usize::MAX`, jo rezultātu tomēr mēs ņemam beigās `mod n`.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // DROŠĪBA: `a` ir spēks no diviem, tāpēc nav nulle.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` Lietu var aprēķināt vienkāršāk, izmantojot `-p (mod a)`, taču tas kavē LLVM spēju izvēlēties tādas instrukcijas kā `lea`.Tā vietā mēs aprēķinām
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // kas sadala operācijas ap nesošo, bet pietiekami pesimizē `and`, lai LLVM varētu izmantot dažādas zināmās optimizācijas.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Jau izlīdzināts.Jā!
        return 0;
    } else if stride == 0 {
        // Ja rādītājs nav izlīdzināts un elements ir nulle izmēra, tad nekāds elementu daudzums rādītāju nekad nesaskaņos.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // DROŠĪBA: a ir divu jauda, tātad nulle.stride==0 lieta tiek izskatīta iepriekš.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // DROŠĪBA: gcdpow ir augšējā robeža, kas ir ne vairāk par bitu skaitu usize.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // DROŠĪBA: gcd vienmēr ir lielāks vai vienāds ar 1.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // Šis branch atrisina šādu lineāro kongruences vienādojumu:
        //
        // ` p + so = 0 mod a `
        //
        // `p` šeit ir rādītāja vērtība `s`, `T` solis, `o` nobīde `T` un `a`, pieprasītā izlīdzināšana.
        //
        // Ja `g = gcd(a, s)` un iepriekšminētais nosacījums apgalvo, ka `p` ir arī dalāms ar `g`, mēs varam apzīmēt `a' = a/g`, `s' = s/g`, `p' = p/g`, tad tas kļūst līdzvērtīgs:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // Pirmais termins ir "the relative alignment of `p` to `a`" (dalīts ar `g`), otrais termins ir "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (atkal dalīts ar `g`).
        //
        // Dalīšana ar `g` ir nepieciešama, lai apgrieztā vērtība būtu labi izveidota, ja `a` un `s` nav līdzfinansēti.
        //
        // Turklāt šī šķīduma rezultāts nav "minimal", tāpēc ir nepieciešams ņemt rezultātu `o mod lcm(s, a)`.Mēs varam aizstāt `lcm(s, a)` ar tikai `a'`.
        //
        //
        //
        //
        //

        // DROŠĪBA: `gcdpow` augšējā robeža nav lielāka par pēdējo 0 bitu skaitu `a`.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // DROŠĪBA: `a2` nav nulle.Pārvietojot `a` ar `gcdpow`, nevar pārvietot nevienu no iestatītajiem bitiem
        // `a` (no kuriem tai ir tieši viens).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // DROŠĪBA: `gcdpow` augšējā robeža nav lielāka par pēdējo 0 bitu skaitu `a`.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // DROŠĪBA: `gcdpow` augšējā robeža nav lielāka par pēdējo 0 bitu skaitu
        // `a`.
        // Turklāt atņemšana nevar pārplūst, jo `a2 = a >> gcdpow` vienmēr būs stingri lielāks par `(p % a) >> gcdpow`.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // DROŠĪBA: `a2` ir divu cilvēku spēks, kā pierādīts iepriekš.`s2` ir stingri mazāks par `a2`
        // jo `(s % a) >> gcdpow` ir stingri mazāks par `a >> gcdpow`.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // To vispār nevar izlīdzināt.
    usize::MAX
}

/// Salīdzina izejvielas vienlīdzībai.
///
/// Tas ir tas pats, kas izmantot `==` operatoru, bet mazāk vispārīgs:
/// Argumentiem jābūt `*const T` neapstrādātiem rādītājiem, nevis kaut ko tādu, kas ievieš `PartialEq`.
///
/// To var izmantot, lai salīdzinātu `&T` atsauces (kuras netieši piespiež `*const T`) pēc to adreses, nevis salīdzina vērtības, uz kurām viņi norāda (uz ko `PartialEq for &T` ieviešana dara).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Šķēles salīdzina arī pēc to garuma (tauku rādītāji):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Traits tiek salīdzināti arī pēc to ieviešanas:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Rādītājiem ir vienādas adreses.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Objektiem ir vienādas adreses, bet `Trait` ir dažādas ieviešanas iespējas.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Konvertējot atsauci uz `*const u8`, salīdzina pēc adreses.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Hash neapstrādātu rādītāju.
///
/// To var izmantot, lai jauktu `&T` atsauci (kas netieši piespiež `*const T`) pēc adreses, nevis pēc vērtības, uz kuru tā norāda (tieši to dara `Hash for &T` ieviešana).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Impls funkciju rādītājiem
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: AVR ir nepieciešams starpposma dalībnieku sastāvs
                // tā, lai avota funkcijas rādītāja adreses telpa tiktu saglabāta pēdējā funkciju rādītājā.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: AVR ir nepieciešams starpposma dalībnieku sastāvs
                // tā, lai avota funkcijas rādītāja adreses telpa tiktu saglabāta pēdējā funkciju rādītājā.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // Nav variadic funkciju ar 0 parametriem
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Izveidojiet `const` neapstrādātu rādītāju uz vietu, neradot starpposma atsauci.
///
/// Atsauces izveide ar `&`/`&mut` ir atļauta tikai tad, ja rādītājs ir pareizi izlīdzināts un norāda uz inicializētiem datiem.
/// Gadījumos, kad šīs prasības neatbilst, tā vietā jāizmanto neapstrādātas norādes.
/// Tomēr `&expr as *const _` pirms atsauces uz neapstrādātu rādītāju izveido atsauci, un uz šo atsauci attiecas tie paši noteikumi kā uz visām pārējām atsaucēm.
///
/// Šis makro var izveidot neapstrādātu rādītāju *, vispirms neizveidojot atsauci.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` radītu nesalīdzinātu atsauci un tādējādi būtu nedefinēta uzvedība!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Izveidojiet `mut` neapstrādātu rādītāju uz vietu, neradot starpposma atsauci.
///
/// Atsauces izveide ar `&`/`&mut` ir atļauta tikai tad, ja rādītājs ir pareizi izlīdzināts un norāda uz inicializētiem datiem.
/// Gadījumos, kad šīs prasības neatbilst, tā vietā jāizmanto neapstrādātas norādes.
/// Tomēr `&mut expr as *mut _` pirms atsauces uz neapstrādātu rādītāju izveido atsauci, un uz šo atsauci attiecas tie paši noteikumi kā uz visām pārējām atsaucēm.
///
/// Šis makro var izveidot neapstrādātu rādītāju *, vispirms neizveidojot atsauci.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` radītu nesalīdzinātu atsauci un tādējādi būtu nedefinēta uzvedība!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` liek kopēt lauku, nevis izveidot atsauci.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}