use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` bet nav nulle un kovariāns.
///
/// Bieži vien tas ir pareizi jāizmanto, veidojot datu struktūras, izmantojot neapstrādātus rādītājus, taču galu galā to ir bīstamāk izmantot papildu īpašību dēļ.Ja neesat pārliecināts, vai jums vajadzētu izmantot `NonNull<T>`, vienkārši izmantojiet `*mut T`!
///
/// Atšķirībā no `*mut T`, rādītājam vienmēr jābūt nullei pat tad, ja rādītājs nekad netiek noraidīts.Tas ir tāpēc, ka enums var izmantot šo aizliegto vērtību kā diskriminantu-`Option<NonNull<T>>` ir tāds pats izmērs kā `* mut T`.
/// Tomēr rādītājs joprojām var šūpoties, ja tas nav norādīts.
///
/// Atšķirībā no `*mut T`, `NonNull<T>` tika izvēlēts kā mainīgs pār `T`.Tas dod iespēju izmantot `NonNull<T>`, veidojot kovariāna veidus, bet rada nepamatotības risku, ja to lieto tipā, kuram faktiski nevajadzētu būt kovariētam.
/// (`*mut T` tika izdarīta pretēja izvēle, lai arī tehniski nepietiekamību varēja izraisīt tikai nedrošu funkciju izsaukšana.)
///
/// Kovariācija ir pareiza lielākajai daļai drošo abstrakciju, piemēram, `Box`, `Rc`, `Arc`, `Vec` un `LinkedList`.Tas tā ir tāpēc, ka tie nodrošina publisku API, kas atbilst parastajiem kopīgotajiem XOR mainīgajiem noteikumiem Rust.
///
/// Ja jūsu tips nevar droši būt mainīgs, jums jāpārliecinās, ka tajā ir papildu lauks, lai nodrošinātu nemainīgumu.Bieži vien šis lauks būs [`PhantomData`] tips, piemēram, `PhantomData<Cell<T>>` vai `PhantomData<&'a mut T>`.
///
/// Ievērojiet, ka `NonNull<T>` ir `From` gadījums `&T`.Tomēr tas nemaina faktu, ka mutācija ar (rādītāju, kas iegūts no a) kopīgas atsauces ir nedefinēta rīcība, ja vien mutācija nenotiek [`UnsafeCell<T>`] iekšienē.Tas pats attiecas uz maināmas atsauces izveidošanu no kopīgas atsauces.
///
/// Lietojot šo `From` gadījumu bez `UnsafeCell<T>`, jūsu pienākums ir nodrošināt, lai `as_mut` nekad netiktu izsaukts un `as_ptr` nekad netiktu izmantots mutācijām.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` rādītāji nav `Send`, jo dati, uz kuriem tie atsaucas, var būt aizstājvārdi.
// NB, šis impliks nav vajadzīgs, taču tam vajadzētu nodrošināt labākus kļūdu ziņojumus.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` rādītāji nav `Sync`, jo dati, uz kuriem tie atsaucas, var būt aizstājvārdi.
// NB, šis impliks nav vajadzīgs, taču tam vajadzētu nodrošināt labākus kļūdu ziņojumus.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Izveido jaunu `NonNull`, kas ir piekārts, bet labi izlīdzināts.
    ///
    /// Tas ir noderīgi, lai inicializētu tipus, kurus slinki piešķir, piemēram, `Vec::new`.
    ///
    /// Ņemiet vērā, ka rādītāja vērtība, iespējams, apzīmē derīgu `T` rādītāju, kas nozīmē, ka to nedrīkst izmantot kā "not yet initialized" sentinel vērtību.
    /// Veidiem, kurus slinki piešķir, ir jāizseko inicializācija ar citiem līdzekļiem.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // DROŠĪBA: mem::align_of() atgriež lietojumu, kas nav nulle, un pēc tam tiek nodots
        // līdz * mut T.
        // Tāpēc `ptr` nav nulle un tiek ievēroti new_unchecked() izsaukšanas nosacījumi.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Atgriež kopīgas atsauces uz vērtību.Atšķirībā no [`as_ref`], tas neprasa, lai vērtība būtu inicializēta.
    ///
    /// Maināmo kolēģi skatiet [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Zvanot uz šo metodi, jums jāpārliecinās, vai ir spēkā visi šie nosacījumi:
    ///
    /// * Rādītājam jābūt pareizi izlīdzinātam.
    ///
    /// * Tam jābūt "dereferencable" tādā nozīmē, kā noteikts [the module documentation].
    ///
    /// * Jums ir jāievieš Rust aizstājvārdu kārtulas, jo atgrieztais dzīves ilgums `'a` tiek izvēlēts patvaļīgi un ne vienmēr atspoguļo faktisko datu kalpošanas laiku.
    ///
    ///   Jo īpaši šī mūža laikā atmiņa, uz kuru norāda rādītājs, nedrīkst kļūt mutēta (izņemot `UnsafeCell` iekšpusē).
    ///
    /// Tas attiecas pat tad, ja šīs metodes rezultāts netiek izmantots!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // DROŠĪBA: zvanītājam ir jāgarantē, ka `self` atbilst visiem
        // prasības atsaucei.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Atgriež unikālas atsauces uz vērtību.Atšķirībā no [`as_mut`], tas neprasa, lai vērtība būtu inicializēta.
    ///
    /// Koplietojamo kolēģi skatiet [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Zvanot uz šo metodi, jums jāpārliecinās, vai ir spēkā visi šie nosacījumi:
    ///
    /// * Rādītājam jābūt pareizi izlīdzinātam.
    ///
    /// * Tam jābūt "dereferencable" tādā nozīmē, kā noteikts [the module documentation].
    ///
    /// * Jums ir jāievieš Rust aizstājvārdu kārtulas, jo atgrieztais dzīves ilgums `'a` tiek izvēlēts patvaļīgi un ne vienmēr atspoguļo faktisko datu kalpošanas laiku.
    ///
    ///   Jo īpaši šī mūža laikā atmiņai, uz kuru norāda rādītājs, nedrīkst piekļūt (lasīt vai rakstīt), izmantojot citu rādītāju.
    ///
    /// Tas attiecas pat tad, ja šīs metodes rezultāts netiek izmantots!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // DROŠĪBA: zvanītājam ir jāgarantē, ka `self` atbilst visiem
        // prasības atsaucei.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Izveido jaunu `NonNull`.
    ///
    /// # Safety
    ///
    /// `ptr` jābūt nullei.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // DROŠĪBA: zvanītājam jāgarantē, ka `ptr` nav nulle.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Ja `ptr` nav nulle, izveido jaunu `NonNull`.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // DROŠĪBA: rādītājs jau ir pārbaudīts un nav null
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Veic tādu pašu funkcionalitāti kā [`std::ptr::from_raw_parts`], izņemot to, ka `NonNull` rādītājs tiek atgriezts, atšķirībā no neapstrādāta `*const` rādītāja.
    ///
    ///
    /// Plašāku informāciju skatiet [`std::ptr::from_raw_parts`] dokumentācijā.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // DROŠĪBA: `ptr::from::raw_parts_mut` rezultāts nav nulle, jo `data_address` ir.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Sadalīt (iespējams, plašu) rādītāju adreses un metadatu komponentos.
    ///
    /// Rādītāju vēlāk var rekonstruēt ar [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Iegūst pamatā esošo `*mut` rādītāju.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Atgriež kopīgu atsauci uz vērtību.Ja vērtība var nebūt inicializēta, tā vietā jāizmanto [`as_uninit_ref`].
    ///
    /// Maināmo kolēģi skatiet [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Zvanot uz šo metodi, jums jāpārliecinās, vai ir spēkā visi šie nosacījumi:
    ///
    /// * Rādītājam jābūt pareizi izlīdzinātam.
    ///
    /// * Tam jābūt "dereferencable" tādā nozīmē, kā noteikts [the module documentation].
    ///
    /// * Rādītājam jānorāda uz inicializētu `T` instanci.
    ///
    /// * Jums ir jāievieš Rust aizstājvārdu kārtulas, jo atgrieztais dzīves ilgums `'a` tiek izvēlēts patvaļīgi un ne vienmēr atspoguļo faktisko datu kalpošanas laiku.
    ///
    ///   Jo īpaši šī mūža laikā atmiņa, uz kuru norāda rādītājs, nedrīkst kļūt mutēta (izņemot `UnsafeCell` iekšpusē).
    ///
    /// Tas attiecas pat tad, ja šīs metodes rezultāts netiek izmantots!
    /// (Daļa par inicializēšanu vēl nav pilnībā izlemta, bet, kamēr tā nav, vienīgā drošā pieeja ir nodrošināt, ka tās patiešām tiek inicializētas.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // DROŠĪBA: zvanītājam ir jāgarantē, ka `self` atbilst visiem
        // prasības atsaucei.
        unsafe { &*self.as_ptr() }
    }

    /// Atgriež unikālu atsauci uz vērtību.Ja vērtība var nebūt inicializēta, tā vietā jāizmanto [`as_uninit_mut`].
    ///
    /// Koplietojamo kolēģi skatiet [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Zvanot uz šo metodi, jums jāpārliecinās, vai ir spēkā visi šie nosacījumi:
    ///
    /// * Rādītājam jābūt pareizi izlīdzinātam.
    ///
    /// * Tam jābūt "dereferencable" tādā nozīmē, kā noteikts [the module documentation].
    ///
    /// * Rādītājam jānorāda uz inicializētu `T` instanci.
    ///
    /// * Jums ir jāievieš Rust aizstājvārdu kārtulas, jo atgrieztais dzīves ilgums `'a` tiek izvēlēts patvaļīgi un ne vienmēr atspoguļo faktisko datu kalpošanas laiku.
    ///
    ///   Jo īpaši šī mūža laikā atmiņai, uz kuru norāda rādītājs, nedrīkst piekļūt (lasīt vai rakstīt), izmantojot citu rādītāju.
    ///
    /// Tas attiecas pat tad, ja šīs metodes rezultāts netiek izmantots!
    /// (Daļa par inicializēšanu vēl nav pilnībā izlemta, bet, kamēr tā nav, vienīgā drošā pieeja ir nodrošināt, ka tās patiešām tiek inicializētas.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // DROŠĪBA: zvanītājam ir jāgarantē, ka `self` atbilst visiem
        // prasības mainīgai atsaucei.
        unsafe { &mut *self.as_ptr() }
    }

    /// Apraida cita veida rādītāju.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // DROŠĪBA: `self` ir `NonNull` rādītājs, kas noteikti nav nulle
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// No plānā rādītāja un garuma izveido nulle neapstrādātu šķēli.
    ///
    /// `len` arguments ir **elementu** skaits, nevis baitu skaits.
    ///
    /// Šī funkcija ir droša, taču atgriešanās vērtības novirzīšana nav droša.
    /// Sadaļu drošības prasības skatiet [`slice::from_raw_parts`] dokumentācijā.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // izveidojiet šķēles rādītāju, sākot ar rādītāju pirmajam elementam
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Ņemiet vērā, ka šis piemērs mākslīgi parāda šīs metodes izmantošanu, bet `let slice= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // DROŠĪBA: `data` ir `NonNull` rādītājs, kas noteikti nav nulle
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Atgriež nulles neapstrādātas šķēles garumu.
    ///
    /// Atgrieztā vērtība ir **elementu** skaits, nevis baitu skaits.
    ///
    /// Šī funkcija ir droša pat tad, ja nulles neapstrādātu šķēli nevar novirzīt uz šķēli, jo rādītājam nav derīgas adreses.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Atgriež nulles rādītāju šķēles buferī.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // DROŠĪBA: Mēs zinām, ka `self` nav nulle.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Atgriež neapstrādātu rādītāju šķēles buferī.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Atgriež kopīgu atsauci uz iespējami neinicializētu vērtību šķēli.Atšķirībā no [`as_ref`], tas neprasa, lai vērtība būtu inicializēta.
    ///
    /// Maināmo kolēģi skatiet [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Zvanot uz šo metodi, jums jāpārliecinās, vai ir spēkā visi šie nosacījumi:
    ///
    /// * Rādītājam jābūt [valid], lai lasītu `ptr.len() * mem::size_of::<T>()` daudz baitus, un tam jābūt pareizi izlīdzinātam.Tas jo īpaši nozīmē:
    ///
    ///     * Visam šīs šķēles atmiņas diapazonam jābūt vienā piešķirtajā objektā!
    ///       Šķēles nekad nevar aptvert vairākus piešķirtus objektus.
    ///
    ///     * Rādītājs ir jāsaskaņo pat nulles garuma šķēlēs.
    ///     Viens no iemesliem ir tas, ka uzskaites izkārtojuma optimizācija var balstīties uz atsauču (ieskaitot jebkura garuma šķēles) izlīdzināšanu un nebūtību, lai tās atšķirtu no citiem datiem.
    ///
    ///     Izmantojot [`NonNull::dangling()`], varat iegūt rādītāju, kas ir izmantojams kā `data` nulles garuma šķēlītēm.
    ///
    /// * Šķēles kopējais izmērs `ptr.len() * mem::size_of::<T>()` nedrīkst būt lielāks par `isize::MAX`.
    ///   Skatiet [`pointer::offset`] drošības dokumentāciju.
    ///
    /// * Jums ir jāievieš Rust aizstājvārdu kārtulas, jo atgrieztais dzīves ilgums `'a` tiek izvēlēts patvaļīgi un ne vienmēr atspoguļo faktisko datu kalpošanas laiku.
    ///   Jo īpaši šī mūža laikā atmiņa, uz kuru norāda rādītājs, nedrīkst kļūt mutēta (izņemot `UnsafeCell` iekšpusē).
    ///
    /// Tas attiecas pat tad, ja šīs metodes rezultāts netiek izmantots!
    ///
    /// Skatiet arī [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // DROŠĪBA: zvanītājam jāievēro `as_uninit_slice` drošības līgums.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Atgriež unikālu atsauci uz iespējami neinicializētu vērtību šķēli.Atšķirībā no [`as_mut`], tas neprasa, lai vērtība būtu inicializēta.
    ///
    /// Koplietojamo kolēģi skatiet [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Zvanot uz šo metodi, jums jāpārliecinās, vai ir spēkā visi šie nosacījumi:
    ///
    /// * Rādītājam jābūt [valid], lai lasītu un rakstītu `ptr.len() * mem::size_of::<T>()` daudz baitus, un tam jābūt pareizi izlīdzinātam.Tas jo īpaši nozīmē:
    ///
    ///     * Visam šīs šķēles atmiņas diapazonam jābūt vienā piešķirtajā objektā!
    ///       Šķēles nekad nevar aptvert vairākus piešķirtus objektus.
    ///
    ///     * Rādītājs ir jāsaskaņo pat nulles garuma šķēlēs.
    ///     Viens no iemesliem ir tas, ka uzskaites izkārtojuma optimizācija var balstīties uz atsauču (ieskaitot jebkura garuma šķēles) izlīdzināšanu un nebūtību, lai tās atšķirtu no citiem datiem.
    ///
    ///     Izmantojot [`NonNull::dangling()`], varat iegūt rādītāju, kas ir izmantojams kā `data` nulles garuma šķēlītēm.
    ///
    /// * Šķēles kopējais izmērs `ptr.len() * mem::size_of::<T>()` nedrīkst būt lielāks par `isize::MAX`.
    ///   Skatiet [`pointer::offset`] drošības dokumentāciju.
    ///
    /// * Jums ir jāievieš Rust aizstājvārdu kārtulas, jo atgrieztais dzīves ilgums `'a` tiek izvēlēts patvaļīgi un ne vienmēr atspoguļo faktisko datu kalpošanas laiku.
    ///   Jo īpaši šī mūža laikā atmiņai, uz kuru norāda rādītājs, nedrīkst piekļūt (lasīt vai rakstīt), izmantojot citu rādītāju.
    ///
    /// Tas attiecas pat tad, ja šīs metodes rezultāts netiek izmantots!
    ///
    /// Skatiet arī [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Tas ir droši, jo `memory` der daudzu baitu lasīšanai un rakstīšanai `memory.len()`.
    /// // Ņemiet vērā, ka šeit nav atļauts piezvanīt uz `memory.as_mut()`, jo saturs var nebūt inicializēts.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // DROŠĪBA: zvanītājam jāievēro `as_uninit_slice_mut` drošības līgums.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Atgriež neapstrādātu rādītāju elementam vai apakšslānim, neveicot robežu pārbaudi.
    ///
    /// Zvanīt šai metodei ar ārpus robežas esošo indeksu vai kad `self` nav iespējams noraidīt, ir *[nenoteikta uzvedība]*, pat ja iegūtais rādītājs netiek izmantots.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // DROŠĪBA: zvanītājs nodrošina, ka `self` ir norobežojams un `index` ir ierobežots.
        // Tā rezultātā iegūtais rādītājs nevar būt NULL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // DROŠĪBA: unikāls rādītājs nevar būt nulle, tāpēc nosacījumi
        // new_unchecked() tiek ievēroti.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // DROŠĪBA: maināma atsauce nevar būt nulle.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // DROŠĪBA: Atsauce nevar būt nulle, tāpēc nosacījumi
        // new_unchecked() tiek ievēroti.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}