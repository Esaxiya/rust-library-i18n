use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::slice::{self, SliceIndex};

#[lang = "mut_ptr"]
impl<T: ?Sized> *mut T {
    /// Atgriež vērtību `true`, ja rādītājs nav derīgs.
    ///
    /// Ņemiet vērā, ka lieluma tipiem ir daudz iespējamu nulles rādītāju, jo tiek ņemts vērā tikai neapstrādātu datu rādītājs, nevis to garums, redzamais utt.
    /// Tāpēc divus rādītājus, kas ir nulle, joprojām nevar salīdzināt vienādi.
    ///
    /// ## Uzvedība konst vērtēšanas laikā
    ///
    /// Ja šī funkcija tiek izmantota konst novērtēšanas laikā, tā var atgriezt `false` rādītājiem, kas izpildes laikā izrādās nulle.
    /// Konkrēti, kad rādītājs uz kādu atmiņu tiek nobīdīts ārpus tā robežām tādā veidā, ka iegūtais rādītājs ir nulle, funkcija joprojām atgriezīs `false`.
    ///
    /// CTFE nekādā veidā nevar zināt šīs atmiņas absolūto stāvokli, tāpēc mēs nevaram pateikt, vai rādītājs ir nulle vai nē.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Salīdziniet, izmantojot apmetumu, ar plānu rādītāju, tāpēc treknrādītāji uzskata, ka viņu "data" daļa nav derīga.
        //
        (self as *mut u8).guaranteed_eq(null_mut())
    }

    /// Apraida cita veida rādītāju.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *mut U {
        self as _
    }

    /// Sadalīt (iespējams, plašu) rādītāju adreses un metadatu komponentos.
    ///
    /// Rādītāju vēlāk var rekonstruēt ar [`from_raw_parts_mut`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*mut (), <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self))
    }

    /// Atgriež vērtību `None`, ja rādītājs nav derīgs, vai arī atgriež kopīgu atsauci uz vērtību, kas ietīta `Some`.Ja vērtība var nebūt inicializēta, tā vietā jāizmanto [`as_uninit_ref`].
    ///
    /// Maināmo kolēģi skatiet [`as_mut`].
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    /// [`as_mut`]: #method.as_mut
    ///
    /// # Safety
    ///
    /// Zvanot uz šo metodi, jums jāpārliecinās, ka *vai nu* rādītājs ir NULL *, vai* visi šie nosacījumi atbilst patiesībai:
    ///
    /// * Rādītājam jābūt pareizi izlīdzinātam.
    ///
    /// * Tam jābūt "dereferencable" tādā nozīmē, kā noteikts [the module documentation].
    ///
    /// * Rādītājam jānorāda uz inicializētu `T` instanci.
    ///
    /// * Jums ir jāievieš Rust aizstājvārdu kārtulas, jo atgrieztais dzīves ilgums `'a` tiek izvēlēts patvaļīgi un ne vienmēr atspoguļo faktisko datu kalpošanas laiku.
    ///   Jo īpaši šī mūža laikā atmiņa, uz kuru norāda rādītājs, nedrīkst kļūt mutēta (izņemot `UnsafeCell` iekšpusē).
    ///
    /// Tas attiecas pat tad, ja šīs metodes rezultāts netiek izmantots!
    /// (Daļa par inicializēšanu vēl nav pilnībā izlemta, bet, kamēr tā nav, vienīgā drošā pieeja ir nodrošināt, ka tās patiešām tiek inicializētas.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Nekontrolēta versija
    ///
    /// Ja esat pārliecināts, ka rādītājs nekad nevar būt nulle un meklējat kaut kādu `as_ref_unchecked`, kas `Option<&T>` vietā atgriež `&T`, ziniet, ka varat tieši novirzīt rādītāju.
    ///
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // DROŠĪBA: zvanītājam jāgarantē, ka `self` ir derīgs
        // atsauce, ja tā nav nulle.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Atgriež vērtību `None`, ja rādītājs nav derīgs, vai arī atgriež kopīgu atsauci uz vērtību, kas iesaiņota `Some`.
    /// Atšķirībā no [`as_ref`], tas neprasa, lai vērtība būtu inicializēta.
    ///
    /// Maināmo kolēģi skatiet [`as_uninit_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    ///
    /// # Safety
    ///
    /// Zvanot uz šo metodi, jums jāpārliecinās, ka *vai nu* rādītājs ir NULL *, vai* visi šie nosacījumi atbilst patiesībai:
    ///
    /// * Rādītājam jābūt pareizi izlīdzinātam.
    ///
    /// * Tam jābūt "dereferencable" tādā nozīmē, kā noteikts [the module documentation].
    ///
    /// * Jums ir jāievieš Rust aizstājvārdu kārtulas, jo atgrieztais dzīves ilgums `'a` tiek izvēlēts patvaļīgi un ne vienmēr atspoguļo faktisko datu kalpošanas laiku.
    ///
    ///   Jo īpaši šī mūža laikā atmiņa, uz kuru norāda rādītājs, nedrīkst kļūt mutēta (izņemot `UnsafeCell` iekšpusē).
    ///
    /// Tas attiecas pat tad, ja šīs metodes rezultāts netiek izmantots!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // DROŠĪBA: zvanītājam ir jāgarantē, ka `self` atbilst visiem
        // prasības atsaucei.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Aprēķina nobīdi no rādītāja.
    ///
    /// `count` ir T vienībās;piemēram, `count` ar 3 norāda `3 * size_of::<T>()` baitu rādītāja nobīdi.
    ///
    /// # Safety
    ///
    /// Ja tiek pārkāpts kāds no šiem nosacījumiem, rezultāts ir nedefinēta uzvedība:
    ///
    /// * Gan sākuma, gan rezultāta rādītājam jābūt vai nu robežās, vai vienam baitam aiz tā paša piešķirtā objekta beigām.
    /// Ņemiet vērā, ka programmā Rust katrs mainīgais (stack-allocated) tiek uzskatīts par atsevišķu piešķirtu objektu.
    ///
    /// * Aprēķinātā nobīde **baitos** nevar pārpildīt `isize`.
    ///
    /// * Nobīde, kas atrodas robežās, nevar paļauties uz adreses vietu "wrapping around".Tas ir, bezgalīgas precizitātes summai **baitos** ir jāiekļaujas usize.
    ///
    /// Sastādītājs un standarta bibliotēka parasti cenšas nodrošināt, lai piešķīrumi nekad nesasniegtu lielumu, kurā nobīde rada bažas.
    /// Piemēram, `Vec` un `Box` nodrošina, ka tie nekad nepiešķir vairāk par `isize::MAX` baitiem, tāpēc `vec.as_ptr().add(vec.len())` vienmēr ir drošībā.
    ///
    /// Lielākā daļa platformu pat nespēj izveidot šādu sadalījumu.
    /// Piemēram, neviena zināma 64 bitu platforma nekad nevar apkalpot pieprasījumu par 2 <sup>63</sup> baitiem lapas tabulas ierobežojumu vai adreses vietas sadalīšanas dēļ.
    /// Tomēr dažas 32 bitu un 16 bitu platformas var veiksmīgi apkalpot vairāk nekā `isize::MAX` baitu pieprasījumu ar tādām lietām kā fiziskās adreses paplašinājums.
    ///
    /// Atmiņa, kas iegūta tieši no sadalītājiem, vai atmiņas kartētie faili *, var būt pārāk liela, lai to varētu izmantot ar šo funkciju.
    ///
    /// Ja šos ierobežojumus ir grūti izpildīt, apsveriet iespēju izmantot [`wrapping_offset`].
    /// Vienīgā šīs metodes priekšrocība ir tā, ka tā ļauj agresīvāk veikt kompilatoru optimizāciju.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1));
    ///     println!("{}", *ptr.offset(2));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // DROŠĪBA: zvanītājam jāievēro `offset` drošības līgums.
        // Iegūtais rādītājs ir derīgs rakstīšanai, jo zvanītājam ir jāgarantē, ka tas norāda uz to pašu piešķirto objektu kā `self`.
        //
        unsafe { intrinsics::offset(self, count) as *mut T }
    }

    /// Aprēķina nobīdi no rādītāja, izmantojot ietīšanas aritmētiku.
    /// `count` ir T vienībās;piemēram, `count` ar 3 norāda `3 * size_of::<T>()` baitu rādītāja nobīdi.
    ///
    /// # Safety
    ///
    /// Šī operācija vienmēr ir droša, bet iegūtā rādītāja izmantošana nav.
    ///
    /// Iegūtais rādītājs paliek piesaistīts tam pašam piešķirtajam objektam, uz kuru norāda `self`.
    /// To *nedrīkst* izmantot, lai piekļūtu citam piešķirtajam objektam.Ņemiet vērā, ka programmā Rust katrs mainīgais (stack-allocated) tiek uzskatīts par atsevišķu piešķirtu objektu.
    ///
    /// Citiem vārdiem sakot, `let z = x.wrapping_offset((y as isize) - (x as isize))` * nepadara `z` tādu pašu kā `y`, pat ja pieņemam, ka `T` ir `1` izmērs un nav pārpildes: `z` joprojām ir pievienots objektam, pie kura `x` ir pievienots, un tā novirzīšana ir nedefinēta uzvedība, ja vien `x` un `y` punkts tajā pašā piešķirtajā objektā.
    ///
    /// Salīdzinot ar [`offset`], šī metode būtībā aizkavē prasību uzturēties tajā pašā piešķirtajā objektā: [`offset`] ir tūlītēja nedefinēta uzvedība, šķērsojot objekta robežas;`wrapping_offset` rada rādītāju, bet joprojām noved pie nedefinētas uzvedības, ja rādītājs tiek novirzīts, ja tas ir ārpus objekta, kuram tas ir pievienots, robežas.
    /// [`offset`] var labāk optimizēt, un tāpēc tas ir vēlams ar veiktspēju jutīgā kodā.
    ///
    /// Novēlotajā pārbaudē tiek ņemta vērā tikai norādītā rādītāja vērtība, nevis starpvērtības, kas izmantotas gala rezultāta aprēķināšanā.
    /// Piemēram, `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` vienmēr ir tāds pats kā `x`.Citiem vārdiem sakot, atļauts atstāt piešķirto objektu un pēc tam atkārtoti ievadīt to vēlāk.
    ///
    /// Ja jums jāpārsniedz objekta robežas, nomest rādītāju uz veselu skaitli un veikt aritmētiku tur.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// // Atkārtojiet, izmantojot neapstrādātu rādītāju ar diviem elementiem
    /// let mut data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *mut u8 = data.as_mut_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         *ptr = 0;
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// assert_eq!(&data, &[0, 2, 0, 4, 0]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // DROŠĪBA: `arith_offset` iekšējam nav priekšnoteikumu, lai to izsauktu.
        unsafe { intrinsics::arith_offset(self, count) as *mut T }
    }

    /// Atgriež `None`, ja rādītājs nav derīgs, vai arī atgriež unikālu atsauci uz vērtību, kas ietīta `Some`.Ja vērtība var nebūt inicializēta, tā vietā jāizmanto [`as_uninit_mut`].
    ///
    /// Koplietojamo kolēģi skatiet [`as_ref`].
    ///
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    /// [`as_ref`]: #method.as_ref-1
    ///
    /// # Safety
    ///
    /// Zvanot uz šo metodi, jums jāpārliecinās, ka *vai nu* rādītājs ir NULL *, vai* visi šie nosacījumi atbilst patiesībai:
    ///
    /// * Rādītājam jābūt pareizi izlīdzinātam.
    ///
    /// * Tam jābūt "dereferencable" tādā nozīmē, kā noteikts [the module documentation].
    ///
    /// * Rādītājam jānorāda uz inicializētu `T` instanci.
    ///
    /// * Jums ir jāievieš Rust aizstājvārdu kārtulas, jo atgrieztais dzīves ilgums `'a` tiek izvēlēts patvaļīgi un ne vienmēr atspoguļo faktisko datu kalpošanas laiku.
    ///   Jo īpaši šī mūža laikā atmiņai, uz kuru norāda rādītājs, nedrīkst piekļūt (lasīt vai rakstīt), izmantojot citu rādītāju.
    ///
    /// Tas attiecas pat tad, ja šīs metodes rezultāts netiek izmantots!
    /// (Daļa par inicializēšanu vēl nav pilnībā izlemta, bet, kamēr tā nav, vienīgā drošā pieeja ir nodrošināt, ka tās patiešām tiek inicializētas.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { ptr.as_mut().unwrap() };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Tas tiks izdrukāts: "[4, 2, 3]".
    /// ```
    ///
    /// # Nekontrolēta versija
    ///
    /// Ja esat pārliecināts, ka rādītājs nekad nevar būt nulle un meklējat kaut kādu `as_mut_unchecked`, kas `Option<&mut T>` vietā atgriež `&mut T`, ziniet, ka varat tieši novirzīt rādītāju.
    ///
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { &mut *ptr };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Tas tiks izdrukāts: "[4, 2, 3]".
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_mut<'a>(self) -> Option<&'a mut T> {
        // DROŠĪBA: zvanītājam ir jāgarantē, ka `self` ir derīgs
        // maināma atsauce, ja tā nav nulle.
        if self.is_null() { None } else { unsafe { Some(&mut *self) } }
    }

    /// Atgriež `None`, ja rādītājs nav derīgs, vai arī atgriež unikālu atsauci uz vērtību, kas ietīta `Some`.
    /// Atšķirībā no [`as_mut`], tas neprasa, lai vērtība būtu inicializēta.
    ///
    /// Koplietojamo kolēģi skatiet [`as_uninit_ref`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    ///
    /// # Safety
    ///
    /// Zvanot uz šo metodi, jums jāpārliecinās, ka *vai nu* rādītājs ir NULL *, vai* visi šie nosacījumi atbilst patiesībai:
    ///
    /// * Rādītājam jābūt pareizi izlīdzinātam.
    ///
    /// * Tam jābūt "dereferencable" tādā nozīmē, kā noteikts [the module documentation].
    ///
    /// * Jums ir jāievieš Rust aizstājvārdu kārtulas, jo atgrieztais dzīves ilgums `'a` tiek izvēlēts patvaļīgi un ne vienmēr atspoguļo faktisko datu kalpošanas laiku.
    ///
    ///   Jo īpaši šī mūža laikā atmiņai, uz kuru norāda rādītājs, nedrīkst piekļūt (lasīt vai rakstīt), izmantojot citu rādītāju.
    ///
    /// Tas attiecas pat tad, ja šīs metodes rezultāts netiek izmantots!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut<'a>(self) -> Option<&'a mut MaybeUninit<T>>
    where
        T: Sized,
    {
        // DROŠĪBA: zvanītājam ir jāgarantē, ka `self` atbilst visiem
        // prasības atsaucei.
        if self.is_null() { None } else { Some(unsafe { &mut *(self as *mut MaybeUninit<T>) }) }
    }

    /// Atgriež, vai divi rādītāji tiek garantēti vienādi.
    ///
    /// Izpildes laikā šī funkcija darbojas kā `self == other`.
    /// Tomēr dažos kontekstos (piemēram, sastādīšanas laika novērtēšana) ne vienmēr ir iespējams noteikt divu rādītāju vienlīdzību, tāpēc šī funkcija var nepareizi atgriezt `false` rādītājiem, kas vēlāk faktiski izrādās vienādi.
    ///
    /// Bet, atgriežot `true`, rādītāji tiek garantēti vienādi.
    ///
    /// Šī funkcija ir [`guaranteed_ne`] spogulis, bet ne tās apgrieztā vērtība.Ir rādītāju salīdzinājumi, kuriem abas funkcijas atgriež `false`.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// Atgriešanās vērtība var mainīties atkarībā no kompilatora versijas, un nedrošais kods var nebūt atkarīgs no šīs funkcijas rezultāta.
    /// Ieteicams šo funkciju izmantot tikai veiktspējas optimizācijai, ja šīs funkcijas viltus `false` atgriešanās vērtības neietekmē rezultātu, bet tikai veiktspēju.
    /// Šīs metodes izmantošanas sekas izpildlaika un sastādīšanas laika koda atšķirīgai uzvedībai nav izpētītas.
    /// Šo metodi nevajadzētu izmantot, lai ieviestu šādas atšķirības, un tā arī nebūtu jāstabilizē, pirms mums nav labākas zināšanas par šo jautājumu.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self as *const _, other as *const _)
    }

    /// Atgriež, vai divi rādītāji tiek garantēti nevienlīdzīgi.
    ///
    /// Izpildes laikā šī funkcija darbojas kā `self != other`.
    /// Tomēr dažos kontekstos (piemēram, sastādīšanas laika novērtēšana) ne vienmēr ir iespējams noteikt divu rādītāju nevienlīdzību, tāpēc šī funkcija var nepareizi atgriezt `false` rādītājiem, kas vēlāk faktiski izrādās nevienlīdzīgi.
    ///
    /// Bet, atgriežot `true`, rādītāji tiek garantēti nevienlīdzīgi.
    ///
    /// Šī funkcija ir [`guaranteed_eq`] spogulis, bet ne tās apgrieztā vērtība.Ir rādītāju salīdzinājumi, kuriem abas funkcijas atgriež `false`.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// Atgriešanās vērtība var mainīties atkarībā no kompilatora versijas, un nedrošais kods var nebūt atkarīgs no šīs funkcijas rezultāta.
    /// Ieteicams šo funkciju izmantot tikai veiktspējas optimizācijai, ja šīs funkcijas viltus `false` atgriešanās vērtības neietekmē rezultātu, bet tikai veiktspēju.
    /// Šīs metodes izmantošanas sekas izpildlaika un sastādīšanas laika koda atšķirīgai uzvedībai nav izpētītas.
    /// Šo metodi nevajadzētu izmantot, lai ieviestu šādas atšķirības, un tā arī nebūtu jāstabilizē, pirms mums nav labākas zināšanas par šo jautājumu.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const unsafe fn guaranteed_ne(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self as *const _, other as *const _)
    }

    /// Aprēķina attālumu starp diviem rādītājiem.Atgrieztā vērtība ir izteikta T vienībās: attālums baitos tiek dalīts ar `mem::size_of::<T>()`.
    ///
    /// Šī funkcija ir [`offset`] apgrieztā vērtība.
    ///
    /// [`offset`]: #method.offset-1
    ///
    /// # Safety
    ///
    /// Ja tiek pārkāpts kāds no šiem nosacījumiem, rezultāts ir nedefinēta uzvedība:
    ///
    /// * Gan sākuma, gan citam rādītājam jābūt vai nu robežās, vai vienam baitam aiz tā paša piešķirtā objekta beigām.
    /// Ņemiet vērā, ka programmā Rust katrs mainīgais (stack-allocated) tiek uzskatīts par atsevišķu piešķirtu objektu.
    ///
    /// * Abiem rādītājiem jābūt *atvasinātiem no* tā paša objekta rādītāja.
    ///   (Skatiet piemēru zemāk.)
    ///
    /// * Attālumam starp rādītājiem baitos jābūt precīzam `T` lieluma reizinājumam.
    ///
    /// * Attālums starp rādītājiem **baitos** nevar pārpildīt `isize`.
    ///
    /// * Attālums, kas ir robežās, nevar paļauties uz adreses vietu "wrapping around".
    ///
    /// Rust tipi nekad nav lielāki par `isize::MAX`, un Rust piešķīrumi nekad neaptver adrešu telpu, tāpēc divi rādītāji jebkura Rust tipa `T` noteiktā vērtībā vienmēr atbilst pēdējiem diviem nosacījumiem.
    ///
    /// Standarta bibliotēka arī nodrošina, ka piešķīrumi nekad nesasniedz lielumu, kurā nobīde rada bažas.
    /// Piemēram, `Vec` un `Box` nodrošina, ka tie nekad nepiešķir vairāk par `isize::MAX` baitiem, tāpēc `ptr_into_vec.offset_from(vec.as_ptr())` vienmēr atbilst pēdējiem diviem nosacījumiem.
    ///
    /// Lielākā daļa platformu pat nespēj izveidot tik lielu piešķīrumu.
    /// Piemēram, neviena zināma 64 bitu platforma nekad nevar apkalpot pieprasījumu par 2 <sup>63</sup> baitiem lapas tabulas ierobežojumu vai adreses vietas sadalīšanas dēļ.
    /// Tomēr dažas 32 bitu un 16 bitu platformas var veiksmīgi apkalpot vairāk nekā `isize::MAX` baitu pieprasījumu ar tādām lietām kā fiziskās adreses paplašinājums.
    /// Atmiņa, kas iegūta tieši no sadalītājiem, vai atmiņas kartētie faili *, var būt pārāk liela, lai to varētu izmantot ar šo funkciju.
    /// (Ņemiet vērā, ka [`offset`] un [`add`] ir arī līdzīgs ierobežojums, tāpēc tos nevar izmantot arī tik lielos piešķīrumos.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Šī funkcija panics, ja `T` ir nulles tipa ("ZST") tips.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let mut a = [0; 5];
    /// let ptr1: *mut i32 = &mut a[1];
    /// let ptr2: *mut i32 = &mut a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Nepareizs* lietojums:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8));
    /// let ptr2 = Box::into_raw(Box::new(1u8));
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Padariet ptr2_other par "alias" no ptr2, bet atvasinātu no ptr1.
    /// let ptr2_other = (ptr1 as *mut u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Tā kā ptr2_other un ptr2 ir atvasināti no rādītājiem uz dažādiem objektiem, to nobīdes aprēķināšana ir nenoteikta rīcība, kaut arī tie norāda uz vienu un to pašu adresi!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Nedefinēta uzvedība
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        // DROŠĪBA: zvanītājam jāievēro `offset_from` drošības līgums.
        unsafe { (self as *const T).offset_from(origin) }
    }

    /// Aprēķina nobīdi no rādītāja (ērtības `.offset(count as isize)`).
    ///
    /// `count` ir T vienībās;piemēram, `count` ar 3 norāda `3 * size_of::<T>()` baitu rādītāja nobīdi.
    ///
    /// # Safety
    ///
    /// Ja tiek pārkāpts kāds no šiem nosacījumiem, rezultāts ir nedefinēta uzvedība:
    ///
    /// * Gan sākuma, gan rezultāta rādītājam jābūt vai nu robežās, vai vienam baitam aiz tā paša piešķirtā objekta beigām.
    /// Ņemiet vērā, ka programmā Rust katrs mainīgais (stack-allocated) tiek uzskatīts par atsevišķu piešķirtu objektu.
    ///
    /// * Aprēķinātā nobīde **baitos** nevar pārpildīt `isize`.
    ///
    /// * Nobīde, kas atrodas robežās, nevar paļauties uz adreses vietu "wrapping around".Tas ir, bezgalīgas precizitātes summai jāiekļaujas `usize`.
    ///
    /// Sastādītājs un standarta bibliotēka parasti cenšas nodrošināt, lai piešķīrumi nekad nesasniegtu lielumu, kurā nobīde rada bažas.
    /// Piemēram, `Vec` un `Box` nodrošina, ka tie nekad nepiešķir vairāk par `isize::MAX` baitiem, tāpēc `vec.as_ptr().add(vec.len())` vienmēr ir drošībā.
    ///
    /// Lielākā daļa platformu pat nespēj izveidot šādu sadalījumu.
    /// Piemēram, neviena zināma 64 bitu platforma nekad nevar apkalpot pieprasījumu par 2 <sup>63</sup> baitiem lapas tabulas ierobežojumu vai adreses vietas sadalīšanas dēļ.
    /// Tomēr dažas 32 bitu un 16 bitu platformas var veiksmīgi apkalpot vairāk nekā `isize::MAX` baitu pieprasījumu ar tādām lietām kā fiziskās adreses paplašinājums.
    ///
    /// Atmiņa, kas iegūta tieši no sadalītājiem, vai atmiņas kartētie faili *, var būt pārāk liela, lai to varētu izmantot ar šo funkciju.
    ///
    /// Ja šos ierobežojumus ir grūti izpildīt, apsveriet iespēju izmantot [`wrapping_add`].
    /// Vienīgā šīs metodes priekšrocība ir tā, ka tā ļauj agresīvāk veikt kompilatoru optimizāciju.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // DROŠĪBA: zvanītājam jāievēro `offset` drošības līgums.
        unsafe { self.offset(count as isize) }
    }

    /// Aprēķina nobīdi no rādītāja (ērtības `.offset ((tiek skaitīts kā isize).wrapping_neg())`).
    ///
    /// `count` ir T vienībās;piemēram, `count` ar 3 norāda `3 * size_of::<T>()` baitu rādītāja nobīdi.
    ///
    /// # Safety
    ///
    /// Ja tiek pārkāpts kāds no šiem nosacījumiem, rezultāts ir nedefinēta uzvedība:
    ///
    /// * Gan sākuma, gan rezultāta rādītājam jābūt vai nu robežās, vai vienam baitam aiz tā paša piešķirtā objekta beigām.
    /// Ņemiet vērā, ka programmā Rust katrs mainīgais (stack-allocated) tiek uzskatīts par atsevišķu piešķirtu objektu.
    ///
    /// * Aprēķinātais nobīde nedrīkst pārsniegt `isize::MAX`**baitus**.
    ///
    /// * Nobīde, kas atrodas robežās, nevar paļauties uz adreses vietu "wrapping around".Tas ir, bezgalīgas precizitātes summai jāiekļaujas usiz.
    ///
    /// Sastādītājs un standarta bibliotēka parasti cenšas nodrošināt, lai piešķīrumi nekad nesasniegtu lielumu, kurā nobīde rada bažas.
    /// Piemēram, `Vec` un `Box` nodrošina, ka tie nekad nepiešķir vairāk par `isize::MAX` baitiem, tāpēc `vec.as_ptr().add(vec.len()).sub(vec.len())` vienmēr ir drošībā.
    ///
    /// Lielākā daļa platformu pat nespēj izveidot šādu sadalījumu.
    /// Piemēram, neviena zināma 64 bitu platforma nekad nevar apkalpot pieprasījumu par 2 <sup>63</sup> baitiem lapas tabulas ierobežojumu vai adreses vietas sadalīšanas dēļ.
    /// Tomēr dažas 32 bitu un 16 bitu platformas var veiksmīgi apkalpot vairāk nekā `isize::MAX` baitu pieprasījumu ar tādām lietām kā fiziskās adreses paplašinājums.
    ///
    /// Atmiņa, kas iegūta tieši no sadalītājiem, vai atmiņas kartētie faili *, var būt pārāk liela, lai to varētu izmantot ar šo funkciju.
    ///
    /// Ja šos ierobežojumus ir grūti izpildīt, apsveriet iespēju izmantot [`wrapping_sub`].
    /// Vienīgā šīs metodes priekšrocība ir tā, ka tā ļauj agresīvāk veikt kompilatoru optimizāciju.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // DROŠĪBA: zvanītājam jāievēro `offset` drošības līgums.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Aprēķina nobīdi no rādītāja, izmantojot ietīšanas aritmētiku.
    /// (ērtības `.wrapping_offset(count as isize)`)
    ///
    /// `count` ir T vienībās;piemēram, `count` ar 3 norāda `3 * size_of::<T>()` baitu rādītāja nobīdi.
    ///
    /// # Safety
    ///
    /// Šī operācija vienmēr ir droša, bet iegūtā rādītāja izmantošana nav.
    ///
    /// Iegūtais rādītājs paliek piesaistīts tam pašam piešķirtajam objektam, uz kuru norāda `self`.
    /// To *nedrīkst* izmantot, lai piekļūtu citam piešķirtajam objektam.Ņemiet vērā, ka programmā Rust katrs mainīgais (stack-allocated) tiek uzskatīts par atsevišķu piešķirtu objektu.
    ///
    /// Citiem vārdiem sakot, `let z = x.wrapping_add((y as usize) - (x as usize))` * nepadara `z` tādu pašu kā `y`, pat ja mēs pieņemam, ka `T` ir `1` izmērs un nav pārpildes: `z` joprojām ir pievienots objektam, pie kura `x` ir pievienots, un tā novirzīšana ir nedefinēta uzvedība, ja vien `x` un `y` punkts tajā pašā piešķirtajā objektā.
    ///
    /// Salīdzinot ar [`add`], šī metode būtībā aizkavē prasību uzturēties tajā pašā piešķirtajā objektā: [`add`] ir tūlītēja nedefinēta uzvedība, šķērsojot objekta robežas;`wrapping_add` rada rādītāju, bet joprojām noved pie nedefinētas uzvedības, ja rādītājs tiek novirzīts, ja tas ir ārpus objekta, kuram tas ir pievienots, robežas.
    /// [`add`] var labāk optimizēt, un tāpēc tas ir vēlams ar veiktspēju jutīgā kodā.
    ///
    /// Novēlotajā pārbaudē tiek ņemta vērā tikai norādītā rādītāja vērtība, nevis starpvērtības, kas izmantotas gala rezultāta aprēķināšanā.
    /// Piemēram, `x.wrapping_add(o).wrapping_sub(o)` vienmēr ir tāds pats kā `x`.Citiem vārdiem sakot, atļauts atstāt piešķirto objektu un pēc tam atkārtoti ievadīt to vēlāk.
    ///
    /// Ja jums jāpārsniedz objekta robežas, nomest rādītāju uz veselu skaitli un veikt aritmētiku tur.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// // Atkārtojiet, izmantojot neapstrādātu rādītāju ar diviem elementiem
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Šī cilpa izdrukā "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Aprēķina nobīdi no rādītāja, izmantojot ietīšanas aritmētiku.
    /// (ērtības par. .wrapping_offset ((tiek skaitīts kā isize).wrapping_neg())`)
    ///
    /// `count` ir T vienībās;piemēram, `count` ar 3 norāda `3 * size_of::<T>()` baitu rādītāja nobīdi.
    ///
    /// # Safety
    ///
    /// Šī operācija vienmēr ir droša, bet iegūtā rādītāja izmantošana nav.
    ///
    /// Iegūtais rādītājs paliek piesaistīts tam pašam piešķirtajam objektam, uz kuru norāda `self`.
    /// To *nedrīkst* izmantot, lai piekļūtu citam piešķirtajam objektam.Ņemiet vērā, ka programmā Rust katrs mainīgais (stack-allocated) tiek uzskatīts par atsevišķu piešķirtu objektu.
    ///
    /// Citiem vārdiem sakot, `let z = x.wrapping_sub((x as usize) - (y as usize))` * nepadara `z` tādu pašu kā `y`, pat ja mēs pieņemam, ka `T` ir `1` izmērs un nav pārpildes: `z` joprojām ir pievienots objektam, pie kura `x` ir pievienots, un tā novirzīšana ir nedefinēta uzvedība, ja vien `x` un `y` punkts tajā pašā piešķirtajā objektā.
    ///
    /// Salīdzinot ar [`sub`], šī metode būtībā aizkavē prasību uzturēties tajā pašā piešķirtajā objektā: [`sub`] ir tūlītēja nedefinēta uzvedība, šķērsojot objekta robežas;`wrapping_sub` rada rādītāju, bet joprojām noved pie nedefinētas uzvedības, ja rādītājs tiek novirzīts, ja tas ir ārpus objekta, kuram tas ir pievienots, robežas.
    /// [`sub`] var labāk optimizēt, un tāpēc tas ir vēlams ar veiktspēju jutīgā kodā.
    ///
    /// Novēlotajā pārbaudē tiek ņemta vērā tikai norādītā rādītāja vērtība, nevis starpvērtības, kas izmantotas gala rezultāta aprēķināšanā.
    /// Piemēram, `x.wrapping_add(o).wrapping_sub(o)` vienmēr ir tāds pats kā `x`.Citiem vārdiem sakot, atļauts atstāt piešķirto objektu un pēc tam atkārtoti ievadīt to vēlāk.
    ///
    /// Ja jums jāpārsniedz objekta robežas, nomest rādītāju uz veselu skaitli un veikt aritmētiku tur.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// // Atkārtojiet, izmantojot neapstrādātu rādītāju ar diviem elementiem (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Šī cilpa izdrukā "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Norāda rādītāja vērtību uz `ptr`.
    ///
    /// Gadījumā, ja `self` ir (fat) rādītājs uz lieluma, šī darbība ietekmēs tikai rādītāja daļu, turpretī (thin) rādītājiem ar lieluma tipiem tas ir tāds pats kā vienkāršs uzdevums.
    ///
    /// Iegūtajam rādītājam būs `val` izcelsme, ti, tauku rādītājam šī darbība semantiski ir tāda pati kā jauna tauku rādītāja izveidošana ar datu rādītāja vērtību `val`, bet `self` metadatus.
    ///
    ///
    /// # Examples
    ///
    /// Šī funkcija ir galvenokārt noderīga, lai atļautu baitu rādītāju aritmētiku potenciāli tauku rādītājiem:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let mut arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &mut arr[0] as *mut dyn Debug;
    /// let thin = ptr as *mut u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *mut i32), 3);
    ///     println!("{:?}", &*ptr); // izdrukās "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *mut u8) -> Self {
        let thin = &mut self as *mut *mut T as *mut *mut u8;
        // DROŠĪBA: Plānas rādītāja gadījumā šīs darbības ir identiskas
        // uz vienkāršu uzdevumu.
        // Tauku rādītāja gadījumā, izmantojot pašreizējo tauku rādītāja izkārtojuma ieviešanu, šāda rādītāja pirmais lauks vienmēr ir datu rādītājs, kas tāpat tiek piešķirts.
        //
        unsafe { *thin = val };
        self
    }

    /// Nolasa vērtību no `self`, to nepārvietojot.
    /// Tādējādi atmiņa operētājsistēmā `self` netiek mainīta.
    ///
    /// Drošības apsvērumus un piemērus skatiet [`ptr::read`].
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // DROŠĪBA: zvanītājam jāievēro `` drošības līgums.
        unsafe { read(self) }
    }

    /// Veic nepastāvīgu vērtības nolasīšanu no `self`, to nepārvietojot.Tādējādi atmiņa operētājsistēmā `self` netiek mainīta.
    ///
    /// Nepastāvīgās darbības ir paredzētas darbam ar I/O atmiņu, un tiek garantēts, ka kompilators tos neizlemj un nepārkārtos citās nepastāvīgās darbībās.
    ///
    ///
    /// Drošības apsvērumus un piemērus skatiet [`ptr::read_volatile`].
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // DROŠĪBA: zvanītājam jāievēro `read_volatile` drošības līgums.
        unsafe { read_volatile(self) }
    }

    /// Nolasa vērtību no `self`, to nepārvietojot.
    /// Tādējādi atmiņa operētājsistēmā `self` netiek mainīta.
    ///
    /// Atšķirībā no `read`, rādītājs var būt nelīdzināts.
    ///
    /// Drošības apsvērumus un piemērus skatiet [`ptr::read_unaligned`].
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // DROŠĪBA: zvanītājam jāievēro `read_unaligned` drošības līgums.
        unsafe { read_unaligned(self) }
    }

    /// Kopē `count * size_of<T>` baitus no `self` uz `dest`.
    /// Avots un galamērķis var pārklāties.
    ///
    /// NOTE: tam ir *tā pati* argumentu secība kā [`ptr::copy`].
    ///
    /// Drošības apsvērumus un piemērus skatiet [`ptr::copy`].
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // DROŠĪBA: zvanītājam jāievēro `copy` drošības līgums.
        unsafe { copy(self, dest, count) }
    }

    /// Kopē `count * size_of<T>` baitus no `self` uz `dest`.
    /// Avots un galamērķis var * nepārklāties.
    ///
    /// NOTE: tam ir *tā pati* argumentu secība kā [`ptr::copy_nonoverlapping`].
    ///
    /// Drošības apsvērumus un piemērus skatiet [`ptr::copy_nonoverlapping`].
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // DROŠĪBA: zvanītājam jāievēro `copy_nonoverlapping` drošības līgums.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Kopē `count * size_of<T>` baitus no `src` uz `self`.
    /// Avots un galamērķis var pārklāties.
    ///
    /// NOTE: tam ir *pretējā* argumentu secība [`ptr::copy`].
    ///
    /// Drošības apsvērumus un piemērus skatiet [`ptr::copy`].
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // DROŠĪBA: zvanītājam jāievēro `copy` drošības līgums.
        unsafe { copy(src, self, count) }
    }

    /// Kopē `count * size_of<T>` baitus no `src` uz `self`.
    /// Avots un galamērķis var * nepārklāties.
    ///
    /// NOTE: tam ir *pretējā* argumentu secība [`ptr::copy_nonoverlapping`].
    ///
    /// Drošības apsvērumus un piemērus skatiet [`ptr::copy_nonoverlapping`].
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from_nonoverlapping(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // DROŠĪBA: zvanītājam jāievēro `copy_nonoverlapping` drošības līgums.
        unsafe { copy_nonoverlapping(src, self, count) }
    }

    /// Izpilda norādītās vērtības iznīcinātāju (ja tāds ir).
    ///
    /// Drošības apsvērumus un piemērus skatiet [`ptr::drop_in_place`].
    ///
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn drop_in_place(self) {
        // DROŠĪBA: zvanītājam jāievēro `drop_in_place` drošības līgums.
        unsafe { drop_in_place(self) }
    }

    /// Pārraksta atmiņas vietu ar norādīto vērtību, nelasot un nenometot veco vērtību.
    ///
    ///
    /// Drošības apsvērumus un piemērus skatiet [`ptr::write`].
    ///
    /// [`ptr::write`]: crate::ptr::write()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write(self, val: T)
    where
        T: Sized,
    {
        // DROŠĪBA: zvanītājam jāievēro `write` drošības līgums.
        unsafe { write(self, val) }
    }

    /// Izsauc memset norādītajā rādītājā, iestatot atmiņas `count * size_of::<T>()` baitus, sākot no `self` līdz `val`.
    ///
    ///
    /// Drošības apsvērumus un piemērus skatiet [`ptr::write_bytes`].
    ///
    /// [`ptr::write_bytes`]: crate::ptr::write_bytes()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_bytes(self, val: u8, count: usize)
    where
        T: Sized,
    {
        // DROŠĪBA: zvanītājam jāievēro `write_bytes` drošības līgums.
        unsafe { write_bytes(self, val, count) }
    }

    /// Veic nepastāvīgu atmiņas vietas ierakstīšanu ar norādīto vērtību, nelasot un nenometot veco vērtību.
    ///
    /// Nepastāvīgās darbības ir paredzētas darbam ar I/O atmiņu, un tiek garantēts, ka kompilators tos neizlemj un nepārkārtos citās nepastāvīgās darbībās.
    ///
    ///
    /// Drošības apsvērumus un piemērus skatiet [`ptr::write_volatile`].
    ///
    /// [`ptr::write_volatile`]: crate::ptr::write_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_volatile(self, val: T)
    where
        T: Sized,
    {
        // DROŠĪBA: zvanītājam jāievēro `write_volatile` drošības līgums.
        unsafe { write_volatile(self, val) }
    }

    /// Pārraksta atmiņas vietu ar norādīto vērtību, nelasot un nenometot veco vērtību.
    ///
    ///
    /// Atšķirībā no `write`, rādītājs var būt nelīdzināts.
    ///
    /// Drošības apsvērumus un piemērus skatiet [`ptr::write_unaligned`].
    ///
    /// [`ptr::write_unaligned`]: crate::ptr::write_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
    #[inline]
    pub const unsafe fn write_unaligned(self, val: T)
    where
        T: Sized,
    {
        // DROŠĪBA: zvanītājam jāievēro `write_unaligned` drošības līgums.
        unsafe { write_unaligned(self, val) }
    }

    /// `self` vērtību aizstāj ar `src`, atgriežot veco vērtību, nenometot nevienu no tām.
    ///
    ///
    /// Drošības apsvērumus un piemērus skatiet [`ptr::replace`].
    ///
    /// [`ptr::replace`]: crate::ptr::replace()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn replace(self, src: T) -> T
    where
        T: Sized,
    {
        // DROŠĪBA: zvanītājam jāievēro `replace` drošības līgums.
        unsafe { replace(self, src) }
    }

    /// Maina vērtības divās viena veida mainīgās vietās, neveicot arī deinicializāciju.
    /// Tie var pārklāties, atšķirībā no `mem::swap`, kas citādi ir līdzvērtīgs.
    ///
    /// Drošības apsvērumus un piemērus skatiet [`ptr::swap`].
    ///
    /// [`ptr::swap`]: crate::ptr::swap()
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn swap(self, with: *mut T)
    where
        T: Sized,
    {
        // DROŠĪBA: zvanītājam jāievēro `swap` drošības līgums.
        unsafe { swap(self, with) }
    }

    /// Aprēķina nobīdi, kas jāpielieto rādītājam, lai tas būtu izlīdzināts ar `align`.
    ///
    /// Ja rādītāju nav iespējams izlīdzināt, ieviešana atgriež `usize::MAX`.
    /// Īstenošanai ir atļauts *vienmēr* atgriezt `usize::MAX`.
    /// Tikai jūsu algoritma veiktspēja var būt atkarīga no tā, vai šeit iegūstat izmantojamu kompensāciju, nevis no tā pareizības.
    ///
    /// Nobīde tiek izteikta `T` elementu skaitā, nevis baiti.Atgriezto vērtību var izmantot ar metodi `wrapping_add`.
    ///
    /// Nav nekādu garantiju, ka rādītāja ieskaite nepārsniegs un nepārsniegs rādītāja norādīto sadalījumu.
    ///
    /// Zvanītāja ziņā ir nodrošināt, lai atgrieztais nobīde būtu pareiza visos citos noteikumos, izņemot izlīdzināšanu.
    ///
    /// # Panics
    ///
    /// Funkcija panics, ja `align` nav divu spēks.
    ///
    /// # Examples
    ///
    /// Piekļuve blakus esošajam `u8` kā `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // kamēr rādītāju var izlīdzināt, izmantojot `offset`, tas norāda ārpus piešķīruma
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // DROŠĪBA: Pārbaudīts, vai `align` ir augstāka par 2
        unsafe { align_offset(self, align) }
    }
}

#[lang = "mut_slice_ptr"]
impl<T> *mut [T] {
    /// Atgriež neapstrādātas šķēles garumu.
    ///
    /// Atgrieztā vērtība ir **elementu** skaits, nevis baitu skaits.
    ///
    /// Šī funkcija ir droša, pat ja neapstrādātu šķēli nevar nodot uz šķēles atsauci, jo rādītājs ir nulle vai nav izlīdzināts.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // DROŠĪBA: tas ir droši, jo `*const [T]` un `FatPtr<T>` ir vienāds izkārtojums.
            // Šo garantiju var sniegt tikai `std`.
            unsafe { Repr { rust_mut: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Atgriež neapstrādātu rādītāju šķēles buferī.
    ///
    /// Tas ir līdzvērtīgs `self` liešanai uz `*mut T`, taču tas ir drošāks tipam.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 0 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self as *mut T
    }

    /// Atgriež neapstrādātu rādītāju elementam vai apakšslānim, neveicot robežu pārbaudi.
    ///
    /// Zvanīt šai metodei ar ārpus robežas esošo indeksu vai kad `self` nav iespējams noraidīt, ir *[nenoteikta uzvedība]*, pat ja iegūtais rādītājs netiek izmantots.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &mut [1, 2, 4] as *mut [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1), x.as_mut_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> *mut I::Output
    where
        I: SliceIndex<[T]>,
    {
        // DROŠĪBA: zvanītājs nodrošina, ka `self` ir norobežojams un `index` ir ierobežots.
        unsafe { index.get_unchecked_mut(self) }
    }

    /// Atgriež vērtību `None`, ja rādītājs nav derīgs, vai arī koplietoto šķēli atgriež vērtību, kas iesaiņota `Some`.
    /// Atšķirībā no [`as_ref`], tas neprasa, lai vērtība būtu inicializēta.
    ///
    /// Maināmo kolēģi skatiet [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_slice_mut`]: #method.as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Zvanot uz šo metodi, jums jāpārliecinās, ka *vai nu* rādītājs ir NULL *, vai* visi šie nosacījumi atbilst patiesībai:
    ///
    /// * Rādītājam jābūt [valid], lai lasītu `ptr.len() * mem::size_of::<T>()` daudz baitus, un tam jābūt pareizi izlīdzinātam.Tas jo īpaši nozīmē:
    ///
    ///     * Visam šīs šķēles atmiņas diapazonam jābūt vienā piešķirtajā objektā!
    ///       Šķēles nekad nevar aptvert vairākus piešķirtus objektus.
    ///
    ///     * Rādītājs ir jāsaskaņo pat nulles garuma šķēlēs.
    ///     Viens no iemesliem ir tas, ka uzskaites izkārtojuma optimizācija var balstīties uz atsauču (ieskaitot jebkura garuma šķēles) izlīdzināšanu un nebūtību, lai tās atšķirtu no citiem datiem.
    ///
    ///     Izmantojot [`NonNull::dangling()`], varat iegūt rādītāju, kas ir izmantojams kā `data` nulles garuma šķēlītēm.
    ///
    /// * Šķēles kopējais izmērs `ptr.len() * mem::size_of::<T>()` nedrīkst būt lielāks par `isize::MAX`.
    ///   Skatiet [`pointer::offset`] drošības dokumentāciju.
    ///
    /// * Jums ir jāievieš Rust aizstājvārdu kārtulas, jo atgrieztais dzīves ilgums `'a` tiek izvēlēts patvaļīgi un ne vienmēr atspoguļo faktisko datu kalpošanas laiku.
    ///   Jo īpaši šī mūža laikā atmiņa, uz kuru norāda rādītājs, nedrīkst kļūt mutēta (izņemot `UnsafeCell` iekšpusē).
    ///
    /// Tas attiecas pat tad, ja šīs metodes rezultāts netiek izmantots!
    ///
    /// Skatiet arī [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // DROŠĪBA: zvanītājam jāievēro `as_uninit_slice` drošības līgums.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }

    /// Atgriež vērtību `None`, ja rādītājs nav derīgs, vai arī atgriež unikālu šķēli vērtībai, kas iesaiņota `Some`.
    /// Atšķirībā no [`as_mut`], tas neprasa, lai vērtība būtu inicializēta.
    ///
    /// Koplietojamo kolēģi skatiet [`as_uninit_slice`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_slice`]: #method.as_uninit_slice-1
    ///
    /// # Safety
    ///
    /// Zvanot uz šo metodi, jums jāpārliecinās, ka *vai nu* rādītājs ir NULL *, vai* visi šie nosacījumi atbilst patiesībai:
    ///
    /// * Rādītājam jābūt [valid], lai lasītu un rakstītu `ptr.len() * mem::size_of::<T>()` daudz baitus, un tam jābūt pareizi izlīdzinātam.Tas jo īpaši nozīmē:
    ///
    ///     * Visam šīs šķēles atmiņas diapazonam jābūt vienā piešķirtajā objektā!
    ///       Šķēles nekad nevar aptvert vairākus piešķirtus objektus.
    ///
    ///     * Rādītājs ir jāsaskaņo pat nulles garuma šķēlēs.
    ///     Viens no iemesliem ir tas, ka uzskaites izkārtojuma optimizācija var balstīties uz atsauču (ieskaitot jebkura garuma šķēles) izlīdzināšanu un nebūtību, lai tās atšķirtu no citiem datiem.
    ///
    ///     Izmantojot [`NonNull::dangling()`], varat iegūt rādītāju, kas ir izmantojams kā `data` nulles garuma šķēlītēm.
    ///
    /// * Šķēles kopējais izmērs `ptr.len() * mem::size_of::<T>()` nedrīkst būt lielāks par `isize::MAX`.
    ///   Skatiet [`pointer::offset`] drošības dokumentāciju.
    ///
    /// * Jums ir jāievieš Rust aizstājvārdu kārtulas, jo atgrieztais dzīves ilgums `'a` tiek izvēlēts patvaļīgi un ne vienmēr atspoguļo faktisko datu kalpošanas laiku.
    ///   Jo īpaši šī mūža laikā atmiņai, uz kuru norāda rādītājs, nedrīkst piekļūt (lasīt vai rakstīt), izmantojot citu rādītāju.
    ///
    /// Tas attiecas pat tad, ja šīs metodes rezultāts netiek izmantots!
    ///
    /// Skatiet arī [`slice::from_raw_parts_mut`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut<'a>(self) -> Option<&'a mut [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // DROŠĪBA: zvanītājam jāievēro `as_uninit_slice_mut` drošības līgums.
            Some(unsafe { slice::from_raw_parts_mut(self as *mut MaybeUninit<T>, self.len()) })
        }
    }
}

// Vienlīdzība rādītājiem
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *mut T {
    #[inline]
    fn eq(&self, other: &*mut T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *mut T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *mut T {
    #[inline]
    fn cmp(&self, other: &*mut T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *mut T {
    #[inline]
    fn partial_cmp(&self, other: &*mut T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*mut T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*mut T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*mut T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*mut T) -> bool {
        *self >= *other
    }
}