#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Norāda jebkura norādītā tipa rādītāja metadatu tipu.
///
/// # Rādītāja metadati
///
/// Rust neapstrādātus rādītāju tipus un atsauces tipus var uzskatīt par izgatavotiem no divām daļām:
/// datu rādītājs, kas satur vērtības atmiņas adresi un dažus metadatus.
///
/// Statiskā lieluma tipiem (kas ievieš `Sized` traits), kā arī `extern` tipiem norādes tiek uzskatītas par `plānām`: metadatu lielums ir nulle un to tips ir `()`.
///
///
/// Norādes uz [dynamically-sized types][dst] ir `platas` vai `resnas`, tām ir metadati, kas nav nulles lielumi:
///
/// * Struktūrām, kuru pēdējais lauks ir DST, metadati ir pēdējā lauka metadati
/// * `str` tipam metadati ir garums baitos kā `usize`
/// * Tādiem šķēļu veidiem kā `[T]` metadati ir vienumu garums kā `usize`
/// * trait objektiem, piemēram, `dyn SomeTrait`, metadati ir [`DynMetadata<Self>`][DynMetadata] (piemēram, `DynMetadata<dyn SomeTrait>`)
///
/// future valodā Rust valoda var iegūt jauna veida veidus, kuriem ir atšķirīgi rādītāju metadati.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait
///
/// Šī trait punkts ir ar `Metadata` saistītais tips, kas ir `()` vai `usize` vai `DynMetadata<_>`, kā aprakstīts iepriekš.
/// Tas tiek automātiski ieviests katram tipam.
/// Var pieņemt, ka to īsteno vispārīgā kontekstā, pat bez attiecīgas saistības.
///
/// # Usage
///
/// Neapstrādātus rādītājus var sadalīt datu adresēs un metadatu komponentos, izmantojot to metodi [`to_raw_parts`].
///
/// Alternatīvi, tikai metadatus var iegūt ar [`metadata`] funkciju.
/// Atsauci var nodot [`metadata`] un netieši piespiest.
///
/// (possibly-wide) rādītāju no tā adreses un metadatiem var salikt kopā ar [`from_raw_parts`] vai [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Metadatu tips norādēs un atsauces uz `Self`.
    #[lang = "metadata_type"]
    // NOTE: Saglabājiet trait bounds `static_assert_expected_bounds_for_metadata`
    //
    // `library/core/src/ptr/metadata.rs` sinhronizācijā ar šeit redzamajiem:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Norādes uz tipiem, kas ievieš šo trait aizstājvārdu, ir `plānas`.
///
/// Tas ietver statiski `izmēra` un `extern` tipus.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: nestabilizē to, pirms trait aizstājvārdi nav stabili valodā?
pub trait Thin = Pointee<Metadata = ()>;

/// Izvelciet rādītāja metadatu komponentu.
///
/// `*mut T`, `&T` vai `&mut T` tipa vērtības var tieši nodot šai funkcijai, jo tās netieši piespiež `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // DROŠĪBA: Piekļuve vērtībai no savienojuma `PtrRepr` ir droša, jo * const T
    // un PtrComponents<T>ir vienādi atmiņas izkārtojumi.
    // Tikai std var sniegt šo garantiju.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// No datu adreses un metadatiem veido neapstrādātu rādītāju (possibly-wide).
///
/// Šī funkcija ir droša, taču novirzītais rādītājs nav obligāti drošs.
/// Attiecībā uz šķēlēm drošības prasības skatiet [`slice::from_raw_parts`] dokumentācijā.
/// trait objektiem metadatiem jānāk no rādītāja uz to pašu izdzēsto tipu.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // DROŠĪBA: Piekļuve vērtībai no savienojuma `PtrRepr` ir droša, jo * const T
    // un PtrComponents<T>ir vienādi atmiņas izkārtojumi.
    // Tikai std var sniegt šo garantiju.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Veic tādu pašu funkcionalitāti kā [`from_raw_parts`], izņemot to, ka tiek atgriezts neapstrādāts `*mut` rādītājs, atšķirībā no neapstrādāta `* const` rādītāja.
///
///
/// Plašāku informāciju skatiet [`from_raw_parts`] dokumentācijā.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // DROŠĪBA: Piekļuve vērtībai no savienojuma `PtrRepr` ir droša, jo * const T
    // un PtrComponents<T>ir vienādi atmiņas izkārtojumi.
    // Tikai std var sniegt šo garantiju.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Lai izvairītos no saistīšanas ar `T: Copy`, nepieciešama manuāla impl.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Lai izvairītos no saistīšanas ar `T: Clone`, nepieciešama manuāla impl.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// `Dyn = dyn SomeTrait` trait objekta tipa metadati.
///
/// Tas ir rādītājs uz vtable (virtuālā zvana tabula), kas atspoguļo visu nepieciešamo informāciju, lai manipulētu ar konkrēto tipu, kas glabājas trait objektā.
/// Vtable, jo īpaši tas satur:
///
/// * tipa izmērs
/// * tipa izlīdzināšana
/// * rādītājs uz tipa `drop_in_place` impl (var būt aizliegts opcijai plain-old-data)
/// * Norādes uz visām trait tipa ieviešanas metodēm
///
/// Ņemiet vērā, ka pirmie trīs ir īpaši, jo tie ir nepieciešami jebkura trait objekta piešķiršanai, nomešanai un izvietošanai.
///
/// Šo struktūru ir iespējams nosaukt ar tipa parametru, kas nav `dyn` trait objekts (piemēram, `DynMetadata<u64>`), bet nevar iegūt šīs struktūras jēgpilnu vērtību.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Visu vtable kopīgais prefikss.Tam seko funkciju rādītāji trait metodēm.
///
/// Privāta `DynMetadata::size_of` utt. Ieviešanas detaļa
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Atgriež ar šo vtable saistītā tipa lielumu.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Atgriež ar šo vtable saistītā tipa izlīdzinājumu.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Atgriež izmēru un līdzinājumu kopā kā `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // DROŠĪBA: kompilators izstaroja šo redzamo betona Rust tipam
        // ir zināms, ka tam ir derīgs izkārtojums.Tāds pats pamatojums kā `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Manuālie implanti nepieciešami, lai izvairītos no `Dyn: $Trait` robežas.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}