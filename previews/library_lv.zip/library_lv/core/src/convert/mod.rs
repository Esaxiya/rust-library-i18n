//! Traits reklāmguvumiem starp tipiem.
//!
//! Šajā modulī esošais traits nodrošina veidu, kā pārveidot no viena tipa uz citu.
//! Katram trait ir atšķirīgs mērķis:
//!
//! - Ieviesiet [`AsRef`] trait, lai iegūtu lētus atsauces uz atsauci pārveidojumus
//! - Ieviesiet [`AsMut`] trait, lai veiktu lētus maināmus maināmus pārveidojumus
//! - Ieviesiet [`From`] trait vērtību-vērtības reklāmguvumu patērēšanai
//! - Ieviesiet [`Into`] trait vērtības-vērtības reklāmguvumu patērēšanai tipos, kas nav pašreizējie crate
//! - [`TryFrom`] un [`TryInto`] traits rīkojas tāpat kā [`From`] un [`Into`], taču tie ir jāievieš, kad pārveidošana var neizdoties.
//!
//! Šajā modulī esošie traits bieži tiek izmantoti kā trait bounds vispārīgām funkcijām tā, lai tiktu atbalstīti vairāku veidu argumenti.Piemērus skatiet katra trait dokumentācijā.
//!
//! Kā bibliotēkas autoram jums vienmēr vajadzētu dot priekšroku [`From<T>`][`From`] vai [`TryFrom<T>`][`TryFrom`] ieviešanai, nevis [`Into<U>`][`Into`] vai [`TryInto<U>`][`TryInto`], jo [`From`] un [`TryFrom`] nodrošina lielāku elastību un bez maksas piedāvā līdzvērtīgas [`Into`] vai [`TryInto`] ieviešanas iespējas, pateicoties standarta ieviešanai standarta bibliotēkā.
//! Mērķējot versiju, kas ir vecāka par Rust 1.41, var būt nepieciešams tieši ieviest [`Into`] vai [`TryInto`], pārveidojot par tipu ārpus pašreizējā crate.
//!
//! # Vispārīgas ieviešanas
//!
//! - [`AsRef`] un [`AsMut`] automātiskā novirze, ja iekšējais tips ir atsauce
//! - ["No"] <U>T apzīmē ["Into"]</u><T><U>par U`</u>
//! - [`TryFrom`] ' <U>T' nozīmē [`TryInto`] '</u><T><U>par U`</u>
//! - [`From`] un [`Into`] ir refleksīvi, kas nozīmē, ka visi tipi var `into` paši un `from` paši
//!
//! Lietošanas piemērus skatiet katrā trait.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Identitātes funkcija.
///
/// Par šo funkciju ir svarīgi atzīmēt divas lietas:
///
/// - Tas ne vienmēr ir līdzvērtīgs slēgumam, piemēram, `|x| x`, jo aizvēršana var piespiest `x` citā tipā.
///
/// - Tas pārvieto funkcijai nodoto ievadi `x`.
///
/// Lai gan varētu šķist dīvaini, ka ir funkcija, kas vienkārši atgriež ievadi, ir daži interesanti izmantošanas veidi.
///
///
/// # Examples
///
/// `identity` izmantošana, lai neko nedarītu citu interesantu funkciju secībā:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Izliksimies, ka vienas pievienošana ir interesanta funkcija.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Izmantojot `identity` kā "do nothing" bāzes gadījumu ar nosacījumu:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Dariet vairāk interesantu lietu ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Izmantojot `identity`, lai saglabātu `Option<T>` iteratora `Some` variantus:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Izmanto, lai veiktu lētu atsauces atsauces pārveidošanu.
///
/// Šis trait ir līdzīgs [`AsMut`], ko izmanto konvertēšanai starp maināmām atsaucēm.
/// Ja jums jāveic dārga konversija, labāk ir ieviest [`From`] ar `&T` tipu vai uzrakstīt pielāgotu funkciju.
///
/// `AsRef` ir tāds pats paraksts kā [`Borrow`], bet [`Borrow`] atšķiras dažos aspektos:
///
/// - Atšķirībā no `AsRef`, [`Borrow`] ir vispārējs implants jebkuram `T`, un to var izmantot, lai pieņemtu vai nu atsauci, vai vērtību.
/// - [`Borrow`] prasa arī, lai [`Hash`], [`Eq`] un [`Ord`] aizņemtajai vērtībai būtu līdzvērtīgi piederošās vērtības vērtībām.
/// Šī iemesla dēļ, ja vēlaties aizņemties tikai vienu struktūras lauku, varat ieviest `AsRef`, bet ne [`Borrow`].
///
/// **Note: Šis trait nedrīkst izgāzties **.Ja konvertēšana var neizdoties, izmantojiet īpašu metodi, kas atgriež [`Option<T>`] vai [`Result<T, E>`].
///
/// # Vispārīgas ieviešanas
///
/// - `AsRef` automātiskas novirzes, ja iekšējais tips ir atsauce vai maināma atsauce (piemēram: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Izmantojot trait bounds, mēs varam pieņemt dažāda veida argumentus, ja vien tos var pārveidot par norādīto `T` tipu.
///
/// Piemēram: Izveidojot vispārīgu funkciju, kas aizņem `AsRef<str>`, mēs izsakām, ka mēs vēlamies pieņemt visas atsauces, kuras var pārveidot par [`&str`], kā argumentu.
/// Tā kā gan [`String`], gan [`&str`] ievieš `AsRef<str>`, abus mēs varam pieņemt kā ievades argumentus.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Veic konvertēšanu.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Izmanto, lai veiktu lētu maināmu uz maināmu atsauces pārveidošanu.
///
/// Šis trait ir līdzīgs [`AsRef`], bet tiek izmantots konvertēšanai starp maināmām atsaucēm.
/// Ja jums jāveic dārga konversija, labāk ir ieviest [`From`] ar `&mut T` tipu vai uzrakstīt pielāgotu funkciju.
///
/// **Note: Šis trait nedrīkst izgāzties **.Ja konvertēšana var neizdoties, izmantojiet īpašu metodi, kas atgriež [`Option<T>`] vai [`Result<T, E>`].
///
/// # Vispārīgas ieviešanas
///
/// - `AsMut` automātiskas novirzes, ja iekšējais tips ir maināma atsauce (piemēram: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Izmantojot vispārīgo funkciju `AsMut` kā trait bound, mēs varam pieņemt visas mainīgās atsauces, kuras var pārveidot par `&mut T` tipu.
/// Tā kā [`Box<T>`] ievieš `AsMut<T>`, mēs varam uzrakstīt funkciju `add_one`, kas ņem visus argumentus, kurus var pārveidot par `&mut u64`.
/// Tā kā [`Box<T>`] ievieš `AsMut<T>`, `add_one` pieņem arī `&mut Box<u64>` tipa argumentus:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Veic konvertēšanu.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Konvertēšana no vērtības uz vērtību, kas patērē ievades vērtību.[`From`] pretstats.
///
/// Jāizvairās no [`Into`] ieviešanas un tā vietā jāievieš [`From`].
/// [`From`] ieviešana automātiski nodrošina [`Into`] ieviešanu, pateicoties standarta ieviešanai standarta bibliotēkā.
///
/// Ja vispārīgajai funkcijai norādāt trait bounds, dodiet priekšroku [`Into`], nevis [`From`] lietošanai, lai nodrošinātu, ka var izmantot arī tipus, kas ievieš tikai [`Into`].
///
/// **Note: Šis trait nedrīkst izgāzties **.Ja konvertēšana var neizdoties, izmantojiet [`TryInto`].
///
/// # Vispārīgas ieviešanas
///
/// - ["No"]<T>par U` nozīmē `Into<U> for T`
/// - [`Into`] ir refleksīvs, kas nozīmē, ka `Into<T> for T` ir ieviests
///
/// # [`Into`] ieviešana reklāmguvumiem uz ārējiem tipiem vecajās Rust versijās
///
/// Pirms Rust 1.41, ja galamērķa tips nebija pašreizējā crate sastāvdaļa, nevarēja tieši ieviest [`From`].
/// Piemēram, ņemiet šo kodu:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Tas neizdosies apkopot vecākās valodas versijās, jo Rust bāreņu likumi kādreiz bija nedaudz stingrāki.
/// Lai to apietu, jūs varētu tieši ieviest [`Into`]:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Ir svarīgi saprast, ka [`Into`] nenodrošina [`From`] ieviešanu (kā [`From`] dara ar [`Into`]).
/// Tāpēc vienmēr jācenšas ieviest [`From`] un pēc tam atgriezties pie [`Into`], ja [`From`] nevar ieviest.
///
/// # Examples
///
/// [`String`] īsteno [`Into`] <<[[Vec`]` <`[` u8`]`>>`:
///
/// Lai izteiktu, ka mēs vēlamies, lai vispārējā funkcija ņemtu visus argumentus, kurus var pārveidot par noteiktu `T` tipu, mēs varam izmantot trait bound vērtību [`Into`] '<T>".
///
/// Piemēram: Funkcija `is_hello` ņem visus argumentus, kurus var pārveidot par [`Vec`]`<`[`u8`] `>`.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Veic konvertēšanu.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Izmanto, lai veiktu vērtības-vērtības pārveidojumus, vienlaikus patērējot ievades vērtību.Tas ir abpusējs [`Into`].
///
/// Vienmēr vajadzētu dot priekšroku `From` ieviešanai, nevis [`Into`], jo `From` ieviešana automātiski nodrošina [`Into`] ieviešanu, pateicoties vispārējai ieviešanai standarta bibliotēkā.
///
///
/// [`Into`] ieviesiet tikai tad, ja mērķauditorija tiek atlasīta pirms Rust 1.41 un pārveidojot par tipu, kas nav pašreizējais crate.
/// `From` nevarēja veikt šāda veida reklāmguvumus iepriekšējās versijās Rust bāreņu likumu dēļ.
/// Plašāku informāciju skatiet [`Into`].
///
/// Ja vispārīgajai funkcijai norādāt trait bounds, izvēlieties [`Into`], nevis `From`.
/// Tādā veidā tipus, kas tieši ievieš [`Into`], var izmantot arī kā argumentus.
///
/// `From` ir arī ļoti noderīgs, veicot kļūdu apstrādi.Veidojot funkciju, kas spēj nedarboties, atgriešanās tips parasti būs `Result<T, E>` forma.
/// `From` trait vienkāršo kļūdu apstrādi, ļaujot funkcijai atgriezt vienu kļūdas tipu, kas iekapsulē vairākus kļūdu veidus.Plašāku informāciju skatiet sadaļā "Examples" un [the book][book].
///
/// **Note: Šis trait nedrīkst izgāzties **.Ja konvertēšana var neizdoties, izmantojiet [`TryFrom`].
///
/// # Vispārīgas ieviešanas
///
/// - `From<T> for U` nozīmē ["Into"] <U>par T</u>
/// - `From` ir refleksīvs, kas nozīmē, ka `From<T> for T` ir ieviests
///
/// # Examples
///
/// [`String`] darbarīki `From<&str>`:
///
/// Skaidra konvertēšana no `&str` uz virkni tiek veikta šādi:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Veicot kļūdu apstrādi, bieži ir lietderīgi ieviest `From` savam kļūdas tipam.
/// Konvertējot pamatā esošos kļūdu veidus uz mūsu pašu pielāgoto kļūdu tipu, kas iekapsulē pamatā esošo kļūdu tipu, mēs varam atgriezt vienu kļūdas veidu, nezaudējot informāciju par galveno cēloni.
/// '?' operators automātiski pārveido pamatā esošo kļūdas tipu par mūsu pielāgoto kļūdas tipu, izsaucot `Into<CliError>::into`, kas tiek automātiski nodrošināts, ieviešot `From`.
/// Tad kompilators secina, kura `Into` ieviešana būtu jāizmanto.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Veic konvertēšanu.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Pārveidošanas mēģinājums, kas patērē `self`, kas var būt dārgs vai ne.
///
/// Bibliotēkas autoriem parasti nevajadzētu tieši ieviest šo trait, bet viņiem vajadzētu dot priekšroku [`TryFrom`] trait ieviešanai, kas piedāvā lielāku elastību un nodrošina līdzvērtīgu `TryInto` ieviešanu bez maksas, pateicoties vispārējai ieviešanai standarta bibliotēkā.
/// Lai iegūtu papildinformāciju par to, skatiet [`Into`] dokumentāciju.
///
/// # `TryInto` ieviešana
///
/// Tam ir tādi paši ierobežojumi un pamatojums kā [`Into`] ieviešanai. Sīkāku informāciju skatiet tur.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Veids, kas atgriezts reklāmguvuma kļūdas gadījumā.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Veic konvertēšanu.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Vienkārši un droši konvertēšana, kas noteiktos apstākļos var kontrolēti izgāzties.Tas ir abpusējs [`TryInto`].
///
/// Tas ir noderīgi, ja veicat tipa pārveidošanu, kas var nebūt veiksmīga, taču, iespējams, nepieciešama īpaša apstrāde.
/// Piemēram, [`i64`] nevar pārveidot par [`i32`], izmantojot [`From`] trait, jo [`i64`] var būt vērtība, kuru [`i32`] nevar attēlot, un tādējādi pārveidošana zaudētu datus.
///
/// To var paveikt, saīsinot [`i64`] uz [`i32`] (būtībā piešķirot [i64`] vērtību modulo [`i32::MAX`]) vai vienkārši atgriežot [`i32::MAX`], vai izmantojot kādu citu metodi.
/// [`From`] trait ir paredzēts ideālai konvertēšanai, tāpēc `TryFrom` trait informē programmētāju, kad tipa pārveidošana var kļūt slikta, un ļauj viņiem izlemt, kā ar to rīkoties.
///
/// # Vispārīgas ieviešanas
///
/// - `TryFrom<T> for U` nozīmē [`TryInto`]`<U>par T`</u>
/// - [`try_from`] ir refleksīvs, kas nozīmē, ka `TryFrom<T> for T` ir ieviests un nevar izgāzties-saistītais `Error` tips, lai izsauktu `T::try_from()` uz `T` tipa vērtību, ir [`Infallible`].
/// Kad [`!`] tips ir stabilizēts, [`Infallible`] un [`!`] būs ekvivalenti.
///
/// `TryFrom<T>` var īstenot šādi:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Kā aprakstīts, [`i32`] ievieš "TryFrom <" ["i64`]">:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Klusi saīsina `big_number`, ir nepieciešams noteikt un apstrādāt saīsinājumu pēc fakta.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Atgriež kļūdu, jo `big_number` ir pārāk liels, lai ietilptu `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Atgriež `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Veids, kas atgriezts reklāmguvuma kļūdas gadījumā.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Veic konvertēšanu.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// VISPĀRĒJĀS IETEKMES
////////////////////////////////////////////////////////////////////////////////

// Kā pacelšanās
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Pacelšanās laikā virs &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): aizstājiet iepriekš minētos&/&mut implus ar šādu vispārīgāku:
// // Kā paceļas pāri Derefam
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Izmērs> AsRef <U>D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut paceļas virs &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): aizstājiet iepriekš minēto &mut implantu ar šādu vispārīgāku:
// // AsMut paceļas virs DerefMut
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Izmērs> AsMut <U>priekš D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// No nozīmē Into
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// From (un līdz ar to Into) ir refleksīvs
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Piezīme par stabilitāti:** Šis implekts vēl nepastāv, taču mēs esam "reserving space", lai to pievienotu future.
/// Sīkāku informāciju skatiet [rust-lang/rust#64715][#64715].
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): tā vietā veic principiālu labojumu.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom nozīmē TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Nekļūdīgie reklāmguvumi ir semantiski līdzvērtīgi kļūdainiem reklāmguvumiem ar neapdzīvotu kļūdas veidu.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// BETONA IMPLS
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// NEKĻŪDAS KĻŪDAS VEIDS
////////////////////////////////////////////////////////////////////////////////

/// Kļūdu veids kļūdām, kuras nekad nevar notikt.
///
/// Tā kā šim skaitlim nav variantu, šāda veida vērtība nekad nevar pastāvēt.
/// Tas var būt noderīgi vispārīgām API, kas izmanto [`Result`] un parametrizē kļūdas veidu, lai norādītu, ka rezultāts vienmēr ir [`Ok`].
///
/// Piemēram, [`TryFrom`] trait (konversija, kas atgriež [`Result`]) ir vispārēja ieviešana visiem tipiem, ja pastāv reversā [`Into`] ieviešana.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Future saderība
///
/// Šim uzskaitījumam ir tāda pati loma kā [the `!`“never”type][never], kas šajā Rust versijā ir nestabils.
/// Kad `!` ir stabilizēts, mēs plānojam `Infallible` padarīt par tā aizstājvārdu:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// ... un galu galā noveco `Infallible`.
///
/// Tomēr ir viens gadījums, kad `!` sintaksi var izmantot, pirms `!` tiek stabilizēts kā pilnvērtīgs tips: funkcijas atgriešanās veida pozīcijā.
/// Konkrēti, ir iespējami divu dažādu funkciju rādītāju veidi:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Tā kā `Infallible` ir uzskaitījums, šis kods ir derīgs.
/// Tomēr, kad `Infallible` kļūs par never type aizstājvārdu, abi implanti sāks pārklāties, un tāpēc valodas trait saskaņotības noteikumi tos neatļaus.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}