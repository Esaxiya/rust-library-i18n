use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// Iesaiņojuma veids, lai izveidotu neinicializētus `T` gadījumus.
///
/// # Inicializācija nemainīga
///
/// Sastādītājs parasti pieņem, ka mainīgais ir pareizi inicializēts atbilstoši mainīgā tipa prasībām.Piemēram, atsauces tipa mainīgajam jābūt izlīdzinātam un NULL.
/// Tas ir nemainīgais, kas *vienmēr* ir jāievēro, pat nedrošā kodā.
/// Tā rezultātā atsauces tipa mainīgā nulles inicializēšana izraisa momentānu [undefined behavior][ub], neatkarīgi no tā, vai šī atsauce kādreiz tiek izmantota, lai piekļūtu atmiņai:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // nedefinēta uzvedība!⚠️
/// // Ekvivalents kods ar `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // nedefinēta uzvedība!⚠️
/// ```
///
/// Kompilators to izmanto dažādām optimizācijām, piemēram, izpildes laika pārbaudēm un `enum` izkārtojuma optimizēšanai.
///
/// Līdzīgi pilnībā neinicializētajā atmiņā var būt jebkurš saturs, savukārt `bool` vienmēr jābūt `true` vai `false`.Tādējādi neinicializēta `bool` izveide ir nedefinēta rīcība:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // nedefinēta uzvedība!⚠️
/// // Ekvivalents kods ar `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // nedefinēta uzvedība!⚠️
/// ```
///
/// Turklāt neinicializētā atmiņa ir īpaša ar to, ka tai nav fiksētas vērtības ("fixed" nozīmē "it won't change without being written to").Vairākas reizes lasot vienu un to pašu neinicializēto baitu, var iegūt atšķirīgus rezultātus.
/// Tas padara nenoteiktu rīcību, ja mainīgajā ir neinicializēti dati, pat ja šim mainīgajam ir vesela skaitļa tips, kas citādi var saturēt jebkuru *fiksētu* bitu modeli:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // nedefinēta uzvedība!⚠️
/// // Ekvivalents kods ar `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // nedefinēta uzvedība!⚠️
/// ```
/// (Ievērojiet, ka noteikumi par neinicializētiem veseliem skaitļiem vēl nav pabeigti, taču, kamēr tie nav, ieteicams no tiem izvairīties.)
///
/// Papildus tam atcerieties, ka lielākajai daļai veidu ir papildu invarianti, ne tikai tiek uzskatīti par inicializētiem tipa līmenī.
/// Piemēram, par 1 inicializēts [`Vec<T>`] tiek uzskatīts par inicializētu (saskaņā ar pašreizējo ieviešanu; tas nav stabils garantija), jo vienīgā prasība, ko kompilators zina par to, ir tas, ka datu rādītājam nav jābūt nullei.
/// Šāda `Vec<T>` izveide neizraisa *tūlītēju* nedefinētu uzvedību, bet ar visdrošākajām darbībām (ieskaitot tās atmetšanu) izraisīs nedefinētu rīcību.
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` kalpo tam, lai nedrošs kods varētu tikt izmantots ar neinicializētiem datiem.
/// Tas ir signāls kompilatoram, kas norāda, ka šeit esošos datus *nevar* inicializēt:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Izveidojiet skaidri neinicializētu atsauci.
/// // Sastādītājs zina, ka `MaybeUninit<T>` iekšējie dati var būt nederīgi, un tāpēc tas nav UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Iestatiet to uz derīgu vērtību.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Iegūstiet inicializētus datus-tas ir atļauts tikai *pēc* pareizi inicializēt `x`!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Tad sastādītājs zina, ka šim kodam nav jāpieņem nepareizi pieņēmumi vai optimizācijas.
///
/// Jūs varat iedomāties, ka `MaybeUninit<T>` ir mazliet līdzīgs `Option<T>`, bet bez darbības laika izsekošanas un bez drošības pārbaudēm.
///
/// ## out-pointers
///
/// Lai ieviestu "out-pointers", varat izmantot `MaybeUninit<T>`: tā vietā, lai atgrieztu datus no funkcijas, pārsūtiet tam rādītāju uz kādu (uninitialized) atmiņu, lai ievietotu rezultātu.
/// Tas var būt noderīgi, ja zvanītājam ir svarīgi kontrolēt, kā tiek saglabāta atmiņa, kurā tiek saglabāts rezultāts, un vēlaties izvairīties no nevajadzīgām kustībām.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` nenomet veco saturu, kas ir svarīgi.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Tagad mēs zinām, ka `v` ir inicializēts!Tas arī nodrošina, ka vector tiek pareizi nomests.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Inicializē masīvu pēc elementa
///
/// `MaybeUninit<T>` var izmantot, lai inicializētu lielu masīvu elementiem pa elementiem:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Izveidojiet neinicializētu `MaybeUninit` masīvu.
///     // `assume_init` ir drošs, jo tips, kuru mēs apgalvojam, ka šeit esam inicializējuši, ir virkne `VarbūtUninit`, kuriem nav nepieciešama inicializācija.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Nometot `MaybeUninit`, nekas nedara.
///     // Tādējādi neapstrādāta rādītāja piešķiršanas izmantošana `ptr::write` vietā neizraisa vecās neinicializētās vērtības kritumu.
/////
///     // Arī tad, ja šīs cilpas laikā ir panic, mums ir atmiņas noplūde, taču nav atmiņas drošības problēmu.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Viss tiek inicializēts.
///     // Pārveidojiet masīvu uz inicializēto tipu.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Varat arī strādāt ar daļēji inicializētām masīvām, kuras varētu atrast zema līmeņa datastruktūrās.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Izveidojiet neinicializētu `MaybeUninit` masīvu.
/// // `assume_init` ir drošs, jo tips, kuru mēs apgalvojam, ka šeit esam inicializējuši, ir virkne `VarbūtUninit`, kuriem nav nepieciešama inicializācija.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Saskaitiet mums piešķirto elementu skaitu.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Katram masīva vienumam nomest, ja mēs to piešķirām.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Struktūras inicializēšana katrā laukā
///
/// Varat izmantot `MaybeUninit<T>` un makro [`std::ptr::addr_of_mut`], lai inicializētu struktūras laukā pēc lauka:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Inicializē lauku `name`
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // `list` lauka inicializēšana Ja šeit ir panic, `String` laukā `name` noplūst.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Visi lauki ir inicializēti, tāpēc mēs piezvanām uz `assume_init`, lai iegūtu inicializētu Foo.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` tiek garantēts tāds pats izmērs, izlīdzinājums un ABI kā `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Tomēr atcerieties, ka tips *, kas satur*`MaybeUninit<T>`, nav obligāti tāds pats izkārtojums;Rust parasti negarantē, ka `Foo<T>` laukiem ir tāda pati secība kā `Foo<U>`, pat ja `T` un `U` ir vienāds izmērs un izlīdzinājums.
///
/// Turklāt, tā kā `MaybeUninit<T>` ir derīga jebkura bitu vērtība, kompilators nevar piemērot non-zero/niche-filling optimizāciju, kas var radīt lielāku izmēru:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Ja `T` ir drošs ar FFI, tad arī `MaybeUninit<T>`.
///
/// Lai gan `MaybeUninit` ir `#[repr(transparent)]` (norādot, ka tas garantē tādu pašu izmēru, izlīdzinājumu un ABI kā `T`), tas *nemaina* nevienu no iepriekšējiem brīdinājumiem.
/// `Option<T>` un `Option<MaybeUninit<T>>` joprojām var būt dažādi izmēri, un tipus, kas satur `T` tipa lauku, var izkārtot (un izmēru) atšķirīgi, nekā tad, ja šis lauks būtu `MaybeUninit<T>`.
/// `MaybeUninit` ir savienības tips, un savienojumos `#[repr(transparent)]` ir nestabils (sk. [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Laika gaitā var attīstīties precīzas `#[repr(transparent)]` garantijas arodbiedrībām, un `MaybeUninit` var palikt `#[repr(transparent)]` vai nē.
/// Tas nozīmē, ka `MaybeUninit<T>`*vienmēr* garantēs, ka tam ir tāds pats izmērs, līdzinājums un ABI kā `T`;vienkārši var attīstīties veids, kā `MaybeUninit` īsteno šo garantiju.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Lang priekšmetu, lai mēs varētu tajā ietīt citus veidus.Tas ir noderīgi ģeneratoriem.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Nezvanot uz `T::clone()`, mēs nevaram zināt, vai mums tas ir pietiekami inicializēts.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Izveido jaunu `MaybeUninit<T>`, kas inicializēts ar norādīto vērtību.
    /// Var droši piezvanīt uz [`assume_init`] uz šīs funkcijas atgriešanās vērtību.
    ///
    /// Ņemiet vērā, ka, nometot `MaybeUninit<T>`, nekad netiks izsaukts `T` kritiena kods.
    /// Jūsu pienākums ir pārliecināties, ka `T` tiek nomests, ja tas tika inicializēts.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Neinicializētā stāvoklī izveido jaunu `MaybeUninit<T>`.
    ///
    /// Ņemiet vērā, ka, nometot `MaybeUninit<T>`, nekad netiks izsaukts `T` kritiena kods.
    /// Jūsu pienākums ir pārliecināties, ka `T` tiek nomests, ja tas tika inicializēts.
    ///
    /// Dažus piemērus skatiet [type-level documentation][MaybeUninit].
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Izveidojiet jaunu `MaybeUninit<T>` vienību masīvu neinicializētā stāvoklī.
    ///
    /// Note: future Rust versijā šī metode var kļūt nevajadzīga, ja masīva burtiskā sintakse ļauj [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// Tālāk sniegtajā piemērā varētu izmantot `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Atgriež (iespējams, mazāku) reāli nolasīto datu šķēli
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // DROŠĪBA: Inicializēts `[MaybeUninit<_>; LEN]` ir derīgs.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Tiek izveidots jauns `MaybeUninit<T>` neinicializētā stāvoklī, atmiņa tiek piepildīta ar `0` baitiem.Vai tas jau nodrošina pareizu inicializāciju, ir atkarīgs no `T`.
    ///
    /// Piemēram, `MaybeUninit<usize>::zeroed()` tiek inicializēts, bet `MaybeUninit<&'static i32>::zeroed()` nav tāpēc, ka atsauces nedrīkst būt nulles.
    ///
    /// Ņemiet vērā, ka, nometot `MaybeUninit<T>`, nekad netiks izsaukts `T` kritiena kods.
    /// Jūsu pienākums ir pārliecināties, ka `T` tiek nomests, ja tas tika inicializēts.
    ///
    /// # Example
    ///
    /// Pareiza šīs funkcijas izmantošana: inicializē struktūru ar nulli, kur visos struktūras laukos bitu modelis 0 var būt derīga vērtība.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Nepareizs* šīs funkcijas lietojums: `x.zeroed().assume_init()` izsaukšana, ja `0` tipam nav derīgs bitu modelis:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Pāra iekšpusē mēs izveidojam `NotZero`, kuram nav derīga diskriminanta.
    /// // Tā ir nedefinēta uzvedība.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // DROŠĪBA: `u.as_mut_ptr()` norāda uz piešķirto atmiņu.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Iestata `MaybeUninit<T>` vērtību.
    /// Tas pārraksta jebkuru iepriekšējo vērtību, nenometot to, tāpēc esiet piesardzīgs un nelietojiet to divreiz, ja vien nevēlaties izlaist destruktora palaišanu.
    ///
    /// Jūsu ērtībām tas atgriež arī maināmu atsauci uz (tagad droši inicializētu) `self` saturu.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // DROŠĪBA: Mēs tikko inicializējām šo vērtību.
        unsafe { self.assume_init_mut() }
    }

    /// Iegūst rādītāju uz ierobežoto vērtību.
    /// Lasīšana no šī rādītāja vai tā pārveidošana par atsauci nav noteikta rīcība, ja vien `MaybeUninit<T>` nav inicializēts.
    /// Rakstīšana atmiņā, uz kuru norāda šis rādītājs (non-transitively), ir nedefinēta rīcība (izņemot `UnsafeCell<T>` iekšpusē).
    ///
    /// # Examples
    ///
    /// Pareiza šīs metodes izmantošana:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Izveidojiet atsauci uz `MaybeUninit<T>`.Tas ir labi, jo mēs to inicializējām.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *Nepareiza* šīs metodes izmantošana:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Mēs esam izveidojuši atsauci uz neinicializētu vector!Tā ir nedefinēta uzvedība.⚠️
    /// ```
    ///
    /// (Ievērojiet, ka noteikumi par atsaucēm uz neinicializētiem datiem vēl nav pabeigti, taču, kamēr tie nav, ieteicams no tiem izvairīties.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` un `ManuallyDrop` abi ir `repr(transparent)`, lai mēs varētu izmest rādītāju.
        self as *const _ as *const T
    }

    /// Tiek iegūts maināms rādītājs uz ietverto vērtību.
    /// Lasīšana no šī rādītāja vai tā pārveidošana par atsauci nav noteikta rīcība, ja vien `MaybeUninit<T>` nav inicializēts.
    ///
    /// # Examples
    ///
    /// Pareiza šīs metodes izmantošana:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Izveidojiet atsauci uz `MaybeUninit<Vec<u32>>`.
    /// // Tas ir labi, jo mēs to inicializējām.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *Nepareiza* šīs metodes izmantošana:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Mēs esam izveidojuši atsauci uz neinicializētu vector!Tā ir nedefinēta uzvedība.⚠️
    /// ```
    ///
    /// (Ievērojiet, ka noteikumi par atsaucēm uz neinicializētiem datiem vēl nav pabeigti, taču, kamēr tie nav, ieteicams no tiem izvairīties.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` un `ManuallyDrop` abi ir `repr(transparent)`, lai mēs varētu izmest rādītāju.
        self as *mut _ as *mut T
    }

    /// Izvelk vērtību no konteinera `MaybeUninit<T>`.Tas ir lielisks veids, kā nodrošināt datu kritumu, jo iegūtais `T` tiek pakļauts parastajai kritienu apstrādei.
    ///
    /// # Safety
    ///
    /// Zvanītāja ziņā ir garantēt, ka `MaybeUninit<T>` patiešām ir inicializēts.Tā saukšana, kad saturs vēl nav pilnībā inicializēts, rada tūlītēju nedefinētu rīcību.
    /// [type-level documentation][inv] satur vairāk informācijas par šo inicializācijas nemainīgo.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Papildus tam atcerieties, ka lielākajai daļai veidu ir papildu invarianti, ne tikai tiek uzskatīti par inicializētiem tipa līmenī.
    /// Piemēram, par 1 inicializēts [`Vec<T>`] tiek uzskatīts par inicializētu (saskaņā ar pašreizējo ieviešanu; tas nav stabils garantija), jo vienīgā prasība, ko kompilators zina par to, ir tas, ka datu rādītājam nav jābūt nullei.
    ///
    /// Šāda `Vec<T>` izveide neizraisa *tūlītēju* nedefinētu uzvedību, bet ar visdrošākajām darbībām (ieskaitot tās atmetšanu) izraisīs nedefinētu rīcību.
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Pareiza šīs metodes izmantošana:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *Nepareiza* šīs metodes izmantošana:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` vēl nebija inicializēts, tāpēc šī pēdējā līnija izraisīja nedefinētu uzvedību.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // DROŠĪBA: zvanītājam ir jāgarantē `self` inicializēšana.
        // Tas arī nozīmē, ka `self` ir jābūt `value` variantam.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Izlasa vērtību no konteinera `MaybeUninit<T>`.Iegūtais `T` tiek pakļauts parastajai pilienu apstrādei.
    ///
    /// Kad vien iespējams, tā vietā ir ieteicams izmantot [`assume_init`], kas novērš `MaybeUninit<T>` satura dublēšanu.
    ///
    /// # Safety
    ///
    /// Zvanītāja ziņā ir garantēt, ka `MaybeUninit<T>` patiešām ir inicializēts.Zvanīšana tam, kad saturs vēl nav pilnībā inicializēts, izraisa nedefinētu rīcību.
    /// [type-level documentation][inv] satur vairāk informācijas par šo inicializācijas nemainīgo.
    ///
    /// Turklāt tas atstāj to pašu datu kopiju `MaybeUninit<T>`.
    /// Izmantojot vairākas datu kopijas (vairākas reizes piezvanot uz `assume_init_read` vai vispirms piezvanot uz `assume_init_read` un pēc tam uz [`assume_init`]), jūsu pienākums ir nodrošināt, ka šie dati patiešām var tikt dublēti.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Pareiza šīs metodes izmantošana:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` ir `Copy`, tāpēc mēs varam lasīt vairākas reizes.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `None` vērtības kopēšana ir kārtībā, tāpēc mēs varam lasīt vairākas reizes.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *Nepareiza* šīs metodes izmantošana:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Tagad mēs esam izveidojuši divas viena un tā paša vector kopijas, kas noved pie dubultas bezmaksas versijas, kad tās abas nokrīt!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // DROŠĪBA: zvanītājam ir jāgarantē `self` inicializēšana.
        // Lasīšana no `self.as_ptr()` ir droša, jo `self` ir jāinicializē.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Nomet ierobežoto vērtību vietā.
    ///
    /// Ja jums pieder `MaybeUninit`, tā vietā varat izmantot [`assume_init`].
    ///
    /// # Safety
    ///
    /// Zvanītāja ziņā ir garantēt, ka `MaybeUninit<T>` patiešām ir inicializēts.Zvanīšana tam, kad saturs vēl nav pilnībā inicializēts, izraisa nedefinētu rīcību.
    ///
    /// Papildus tam ir jāapmierina visi `T` tipa papildu invarianti, jo uz to var paļauties `T` (vai tā dalībnieku) `Drop` ieviešana.
    /// Piemēram, par 1 inicializēts [`Vec<T>`] tiek uzskatīts par inicializētu (saskaņā ar pašreizējo ieviešanu; tas nav stabils garantija), jo vienīgā prasība, ko kompilators zina par to, ir tas, ka datu rādītājam nav jābūt nullei.
    ///
    /// Nometot šādu `Vec<T>`, radīsies nedefinēta rīcība.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // DROŠĪBA: zvanītājam ir jāgarantē, ka `self` tiek inicializēts un
        // apmierina visus `T` invariantus.
        // Vērtības nomešana vietā ir droša, ja tas tā ir.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Iegūst kopīgu atsauci uz ietverto vērtību.
    ///
    /// Tas var būt noderīgi, ja mēs vēlamies piekļūt `MaybeUninit`, kas ir inicializēts, bet nepieder `MaybeUninit` īpašumtiesībām (novēršot `.assume_init()`) izmantošanu.
    ///
    /// # Safety
    ///
    /// Zvanīšana tam, kad saturs vēl nav pilnībā inicializēts, izraisa nedefinētu rīcību: zvanītāja ziņā ir garantēt, ka `MaybeUninit<T>` patiešām ir inicializēts.
    ///
    ///
    /// # Examples
    ///
    /// ### Pareiza šīs metodes izmantošana:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Inicializēt `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Tagad, kad ir zināms, ka mūsu `MaybeUninit<_>` ir inicializēts, ir pareizi izveidot kopīgu atsauci uz to:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // DROŠĪBA: `x` ir inicializēts.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *Nepareizi* šīs metodes pielietojumi:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Mēs esam izveidojuši atsauci uz neinicializētu vector!Tā ir nedefinēta uzvedība.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Inicializējiet `MaybeUninit`, izmantojot `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Atsauce uz neinicializētu `Cell<bool>`: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // DROŠĪBA: zvanītājam ir jāgarantē `self` inicializēšana.
        // Tas arī nozīmē, ka `self` ir jābūt `value` variantam.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Iegūst mainīgu (unique) atsauci uz ietverto vērtību.
    ///
    /// Tas var būt noderīgi, ja mēs vēlamies piekļūt `MaybeUninit`, kas ir inicializēts, bet nepieder `MaybeUninit` īpašumtiesībām (novēršot `.assume_init()`) izmantošanu.
    ///
    /// # Safety
    ///
    /// Zvanīšana tam, kad saturs vēl nav pilnībā inicializēts, izraisa nedefinētu rīcību: zvanītāja ziņā ir garantēt, ka `MaybeUninit<T>` patiešām ir inicializēts.
    /// Piemēram, `.assume_init_mut()` nevar izmantot, lai inicializētu `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### Pareiza šīs metodes izmantošana:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Inicializē *visus* ievades bufera baitus.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Inicializēt `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Tagad mēs zinām, ka `buf` ir inicializēts, tāpēc mēs to varētu `.assume_init()`.
    /// // Tomēr `.assume_init()` izmantošana var izraisīt 2048 baitu `memcpy`.
    /// // Lai apgalvotu, ka mūsu buferis ir inicializēts, to nekopējot, mēs jauninām `&mut MaybeUninit<[u8; 2048]>` uz `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // DROŠĪBA: `buf` ir inicializēts.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Tagad mēs varam izmantot `buf` kā parasto šķēli:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *Nepareizi* šīs metodes pielietojumi:
    ///
    /// Vērtības inicializēšanai nevar izmantot `.assume_init_mut()`:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Mēs esam izveidojuši (mutable) atsauci uz neinicializētu `bool`!
    ///     // Tā ir nedefinēta uzvedība.⚠️
    /// }
    /// ```
    ///
    /// Piemēram, jūs nevarat [`Read`] iekļaut neinicializētā buferī:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) atsauce uz neinicializēto atmiņu!
    ///                             // Tā ir nedefinēta uzvedība.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Jūs nevarat arī izmantot tiešu piekļuvi laukam, lai veiktu pakāpenisku inicializāciju katrā laukā:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) atsauce uz neinicializēto atmiņu!
    ///                  // Tā ir nedefinēta uzvedība.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) atsauce uz neinicializēto atmiņu!
    ///                  // Tā ir nedefinēta uzvedība.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Pašlaik mēs paļaujamies uz to, ka iepriekš minētais ir nepareizs, ti, mums ir atsauces uz neinicializētiem datiem (piemēram, `libcore/fmt/float.rs`).
    // Pirms stabilizācijas mums jāpieņem galīgais lēmums par noteikumiem.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // DROŠĪBA: zvanītājam ir jāgarantē `self` inicializēšana.
        // Tas arī nozīmē, ka `self` ir jābūt `value` variantam.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Izvelk vērtības no masīvu `MaybeUninit` konteineriem.
    ///
    /// # Safety
    ///
    /// Zvanītāja ziņā ir garantēt, ka visi masīva elementi atrodas inicializētā stāvoklī.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // DROŠĪBA: Tagad droši, kad mēs inicializējām visus elementus
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Zvanītājs garantē, ka visi masīva elementi tiek inicializēti
        // * `MaybeUninit<T>` un T ir vienāds izkārtojums
        // * VarbūtUnint nepazeminās, tāpēc nav dubultbrīvību. Tādējādi pārveidošana ir droša
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Pieņemot, ka visi elementi ir inicializēti, iegūstiet tiem šķēli.
    ///
    /// # Safety
    ///
    /// Zvanītāja ziņā ir garantēt, ka `MaybeUninit<T>` elementi patiešām ir inicializētā stāvoklī.
    ///
    /// Zvanīšana tam, kad saturs vēl nav pilnībā inicializēts, izraisa nedefinētu rīcību.
    ///
    /// Plašāku informāciju un piemērus skatiet [`assume_init_ref`].
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // DROŠĪBA: šķēles liešana uz `*const [T]` ir droša, jo zvanītājs to garantē
        // `slice` tiek inicializēts, un garantēts, ka `Varbūt Uninit` izkārtojums ir tāds pats kā `T`.
        // Iegūtais rādītājs ir derīgs, jo tas attiecas uz atmiņu, kas pieder `slice`, kas ir atsauce un tādējādi tiek garantēta, ka tā būs derīga lasījumiem.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Pieņemot, ka visi elementi ir inicializēti, iegūstiet tiem maināmu daļu.
    ///
    /// # Safety
    ///
    /// Zvanītāja ziņā ir garantēt, ka `MaybeUninit<T>` elementi patiešām ir inicializētā stāvoklī.
    ///
    /// Zvanīšana tam, kad saturs vēl nav pilnībā inicializēts, izraisa nedefinētu rīcību.
    ///
    /// Plašāku informāciju un piemērus skatiet [`assume_init_mut`].
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // DROŠĪBA: līdzīgi drošības norādījumiem par `slice_get_ref`, taču mums ir
        // maināma atsauce, kas ir garantēta arī derīga rakstīšanai.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Tiek novirzīts uz masīva pirmo elementu.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Iegūst maināmu rādītāju masīva pirmajam elementam.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Kopē elementus no `src` uz `this`, atgriežot maināmu atsauci uz tagad inicializēto `this` saturu.
    ///
    /// Ja `T` neievieš `Copy`, izmantojiet [`write_slice_cloned`]
    ///
    /// Tas ir līdzīgs [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Šī funkcija būs panic, ja abām šķēlītēm ir atšķirīgs garums.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // DROŠĪBA: mēs tikko esam nokopējuši visus len elementus rezerves jaudā
    /// // pirmie veco src.len() elementi ir derīgi tagad.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // DROŠĪBA: &[T] un&[VarbūtUninit<T>] ir vienāds izkārtojums
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // DROŠĪBA: Derīgie elementi ir tikko iekopēti `this`, tāpēc tas tiek inicializēts
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Klonē elementus no `src` līdz `this`, atgriežot maināmu atsauci uz tagad inicializēto `this` saturu.
    /// Visi jau inicializētie elementi netiks nomesti.
    ///
    /// Ja `T` ievieš `Copy`, izmantojiet [`write_slice`]
    ///
    /// Tas ir līdzīgs [`slice::clone_from_slice`], taču esošie elementi netiek nomesti.
    ///
    /// # Panics
    ///
    /// Šī funkcija būs panic, ja abām šķēlēm ir atšķirīgs garums vai `Clone` panics ieviešana.
    ///
    /// Ja ir panic, jau klonētie elementi tiks nomesti.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // DROŠĪBA: mēs tikko klonējām visus len elementus rezerves jaudā
    /// // pirmie veco src.len() elementi ir derīgi tagad.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // Atšķirībā no copy_from_slice tas nesauc clone_from_slice uz šķēles, tas ir tāpēc, ka `MaybeUninit<T: Clone>` neievieš klonu.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // DROŠĪBA: šajā neapstrādātajā šķēlē būs tikai inicializēti objekti
                // tāpēc ir atļauts to nomest.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Mums tie ir skaidri jāsagriež vienā garumā
        // lai robežkontrole tiktu izdzēsta, un optimizētājs ģenerēs memcpy vienkāršiem gadījumiem (piemēram, T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // nepieciešams aizsargs b/c panic var notikt klona laikā
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // DROŠĪBA: Derīgi elementi ir tikko ierakstīti `this`, tāpēc tas tiek inicializēts
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}