//! Pamatfunkcijas atmiņas apstrādei.
//!
//! Šis modulis satur funkcijas vaicājumu saņemšanai par izmēru un veidu izlīdzināšanu, inicializēšanu un atmiņas apstrādi.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Uzņemas īpašumtiesības un vērtību "forgets" par vērtību **, nedarbinot tās iznīcinātāju**.
///
/// Visi resursi, ko pārvalda vērtība, piemēram, kaudzes atmiņa vai faila rokturis, uz visiem laikiem kavēsies nepieejamā stāvoklī.Tomēr tas negarantē, ka norādes uz šo atmiņu paliks derīgas.
///
/// * Ja vēlaties iztukšot atmiņu, skatiet sadaļu [`Box::leak`].
/// * Ja vēlaties iegūt neapstrādātu rādītāju atmiņā, skatiet [`Box::into_raw`].
/// * Ja vēlaties pareizi izmest vērtību, palaižot tās iznīcinātāju, skatiet [`mem::drop`].
///
/// # Safety
///
/// `forget` nav atzīmēts kā `unsafe`, jo Rust drošības garantijās nav garantijas, ka destruktori vienmēr darbosies.
/// Piemēram, programma var izveidot atsauces ciklu, izmantojot [`Rc`][rc], vai izsaukt [`process::exit`][exit], lai izietu, nedarbinot destruktorus.
/// Tādējādi `mem::forget` atļaušana no droša koda būtiski nemaina Rust drošības garantijas.
///
/// Tas nozīmē, ka tādu resursu noplūde kā atmiņa vai I/O objekti parasti nav vēlama.
/// Nepieciešamība rodas dažos specializētos FFI vai nedroša koda lietošanas gadījumos, taču pat tad parasti priekšroka tiek dota [`ManuallyDrop`].
///
/// Tā kā ir atļauts aizmirst vērtību, jebkuram jūsu rakstītajam `unsafe` kodam ir jāļauj izmantot šo iespēju.Jūs nevarat atgriezt vērtību un sagaidīt, ka zvanītājs obligāti palaidīs vērtības iznīcinātāju.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// Kanoniska droša `mem::forget` izmantošana ir apiet vērtības iznīcinātāju, ko ieviesis `Drop` trait.Piemēram, tas noplūdīs `File`, ti
/// atgūt mainīgā aizņemto vietu, bet nekad neaizveriet pamatā esošo sistēmas resursu:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Tas ir noderīgi, ja pamatā esošā resursa īpašumtiesības iepriekš tika nodotas kodam ārpus Rust, piemēram, pārsūtot neapstrādāta faila deskriptoru uz C kodu.
///
/// # Attiecības ar `ManuallyDrop`
///
/// Lai gan `mem::forget` var izmantot arī *atmiņas* īpašumtiesību nodošanai, tas tiek darīts ar kļūdām.
/// [`ManuallyDrop`] jālieto tā vietā.Apsveriet, piemēram, šo kodu:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Veidojiet `String`, izmantojot `v` saturu
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // noplūde `v`, jo tā atmiņu tagad pārvalda `s`
/// mem::forget(v);  // ERROR, v nav derīgs, un to nedrīkst nodot funkcijai
/// assert_eq!(s, "Az");
/// // `s` tiek netieši nomests, un tā atmiņa ir sadalīta.
/// ```
///
/// Iepriekš minētajā piemērā ir divas problēmas:
///
/// * Ja starp `String` konstruēšanu un `mem::forget()` izsaukšanu tiktu pievienots vairāk koda, panic tajā radītu dubultu brīvu darbību, jo to pašu atmiņu apstrādā gan `v`, gan `s`.
/// * Pēc `v.as_mut_ptr()` izsaukšanas un datu īpašumtiesību nodošanas `s` `v` vērtība nav derīga.
/// Pat tad, kad vērtība tiek tikko pārvietota uz `mem::forget` (kas to nepārbaudīs), dažu veidu vērtībām ir noteiktas stingras prasības, kas padara tās nederīgas, ja tās ir pakarināmas vai vairs nepieder.
/// Jebkurā veidā nederīgu vērtību izmantošana, ieskaitot to nodošanu funkcijām, atgriešana no funkcijām, ir nedefinēta rīcība un var sabojāt sastādītāja pieņēmumus.
///
/// Pārslēdzoties uz `ManuallyDrop`, tiek novērsti abi jautājumi:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Pirms mēs izjaucam `v` tā neapstrādātās daļās, pārliecinieties, ka tas nenokrīt!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Tagad izjauciet `v`.Šīs darbības nevar panic, tāpēc nevar būt noplūde.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Visbeidzot, izveidojiet `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` tiek netieši nomests, un tā atmiņa ir sadalīta.
/// ```
///
/// `ManuallyDrop` stingri novērš dubultu atbrīvošanu, jo pirms kāda cita darbības mēs atspējojam `v` iznīcinātāju.
/// `mem::forget()` to nepieļauj, jo tas patērē savu argumentu, liekot mums to saukt tikai pēc tam, kad no `v` esam izvilkuši visu nepieciešamo.
/// Pat ja panic tiktu ieviests starp `ManuallyDrop` būvniecību un virknes izveidošanu (kas nevar notikt kodā, kā parādīts attēlā), tas radītu noplūdi, nevis dubultu bezmaksas.
/// Citiem vārdiem sakot, `ManuallyDrop` kļūdās noplūdes pusē, nevis kļūdās (dubultās) nomešanas pusē.
///
/// Pēc tam, kad īpašumtiesības ir nodotas `s`, `ManuallyDrop` neļauj mums izmantot "touch" `v`-pilnībā tiek novērsts pēdējais mijiedarbības solis ar `v`, lai to iznīcinātu, nedarbinot tā iznīcinātāju.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Tāpat kā [`forget`], bet arī pieņem lieluma vērtības.
///
/// Šī funkcija ir tikai aizsargplāksne, kuru paredzēts noņemt, kad `unsized_locals` funkcija stabilizējas.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Atgriež veida lielumu baitos.
///
/// Precīzāk, tas ir nobāžu nobīde starp secīgiem masīva elementiem ar šī vienuma tipu, ieskaitot izlīdzināšanas polsterējumu.
///
/// Tādējādi jebkura veida `T` un garumam `n` `[T; n]` ir `n * size_of::<T>()` izmērs.
///
/// Parasti sastāva lielums nav stabils, bet konkrēti tipi, piemēram, primitīvi.
///
/// Šajā tabulā ir norādīts primitīvu lielums.
///
/// Tips |: :_ lielums<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 char |4
///
/// Turklāt `usize` un `isize` ir vienāda izmēra.
///
/// `*const T`, `&T`, `Box<T>`, `Option<&T>` un `Option<Box<T>>` tipiem visiem ir vienāds izmērs.
/// Ja `T` ir izmērs, visiem šiem veidiem ir tāds pats izmērs kā `usize`.
///
/// Rādītāja mainīgums nemaina tā lielumu.Tādējādi `&T` un `&mut T` ir vienāda izmēra.
/// Tāpat arī `*const T` un `* mut T`.
///
/// # `#[repr(C)]` vienumu izmērs
///
/// `C` vienumu attēlojumam ir noteikts izkārtojums.
/// Izmantojot šo izkārtojumu, vienumu izmērs ir stabils, kamēr visiem laukiem ir stabils izmērs.
///
/// ## Struktūru lielums
///
/// `structs` izmēru nosaka šāds algoritms.
///
/// Katram struktūras laukam, kas sakārtots pēc deklarācijas pasūtījuma:
///
/// 1. Pievienojiet lauka lielumu.
/// 2. Noapaļojiet pašreizējo izmēru līdz nākamā lauka [alignment] tuvākajam reizinājumam.
///
/// Visbeidzot, noapaļojiet struktūras lielumu līdz tuvākajam [alignment] reizinājumam.
/// Struktūras līdzinājums parasti ir lielākais visu lauku līdzinājums;to var mainīt, izmantojot `repr(align(N))`.
///
/// Atšķirībā no `C`, nulles izmēra struktūras nav noapaļotas līdz vienam baitam.
///
/// ## Enumu lielums
///
/// Enumiem, kuriem nav citu datu, izņemot diskriminējošu informāciju, ir tāds pats izmērs kā C enums platformā, kurai tie ir apkopoti.
///
/// ## Savienību lielums
///
/// Savienības lielums ir tās lielākā lauka lielums.
///
/// Atšķirībā no `C`, nulles lieluma savienības netiek noapaļotas līdz vienam baitam.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Daži primitīvi
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Daži masīvi
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Rādītāja lieluma vienlīdzība
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Izmantojot `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Pirmā lauka izmērs ir 1, tāpēc pievienojiet izmēram 1.Izmērs ir 1.
/// // Otrā lauka izlīdzinājums ir 2, tāpēc polsterējuma izmēram pievienojiet 1.Izmērs ir 2.
/// // Otrā lauka lielums ir 2, tāpēc izmēram pievienojiet 2.Izmērs ir 4.
/// // Trešā lauka izlīdzinājums ir 1, tāpēc polsterējuma izmēram pievienojiet 0.Izmērs ir 4.
/// // Trešā lauka lielums ir 1, tāpēc izmēram pievienojiet 1.Izmērs ir 5.
/// // Visbeidzot, struktūras izlīdzinājums ir 2 (jo lielākais izlīdzinājums starp tā laukiem ir 2), tāpēc polsterējuma izmēram pievienojiet 1.
/// // Izmērs ir 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Tuples struktūras ievēro tos pašus noteikumus.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Ņemiet vērā, ka lauku pārkārtošana var samazināt izmēru.
/// // Abus polsterējuma baitus mēs varam noņemt, ievietojot `third` pirms `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Savienības lielums ir lielākā lauka lielums.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Atgriež norādītās vērtības lielumu baitos.
///
/// Parasti tas ir tāds pats kā `size_of::<T>()`.
/// Tomēr, ja `T` * nav statiski zināma izmēra, piemēram, [`[T]`][slice] vai [trait object] šķēle, tad `size_of_val` var izmantot, lai iegūtu dinamiski zināmo izmēru.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // DROŠĪBA: `val` ir atsauce, tāpēc tas ir derīgs neapstrādāts rādītājs
    unsafe { intrinsics::size_of_val(val) }
}

/// Atgriež norādītās vērtības lielumu baitos.
///
/// Parasti tas ir tāds pats kā `size_of::<T>()`.Tomēr, ja `T` * nav statiski zināma izmēra, piemēram, [`[T]`][slice] vai [trait object] šķēle, tad `size_of_val_raw` var izmantot, lai iegūtu dinamiski zināmo izmēru.
///
/// # Safety
///
/// Šo funkciju var droši izsaukt tikai tad, ja ir spēkā šādi nosacījumi:
///
/// - Ja `T` ir `Sized`, šo funkciju vienmēr var droši izsaukt.
/// - Ja `T` izmērs bez izmēra ir:
///     - [slice], tad šķēles astes garumam jābūt inicializētam veselam skaitlim, un *visas vērtības* lielumam (dinamiskā astes garums + statiski izmēra prefikss) jāatbilst `isize`.
///     - [trait object], tad rādītāja vtable daļai jānorāda uz derīgu vtable, kas iegūta, nemērojot piespiešanu, un visas vērtības * lielumam (dinamiskā astes garums + statiski izmēra prefikss) jāatbilst `isize`.
///
///     - (unstable) [extern type], tad šo funkciju vienmēr var droši izsaukt, taču tā var panic vai citādi atgriezt nepareizu vērtību, jo ārējā tipa izkārtojums nav zināms.
///     Tā ir tāda pati darbība kā [`size_of_val`], atsaucoties uz tipu ar ārējā tipa asti.
///     - pretējā gadījumā konservatīvi nav atļauts izsaukt šo funkciju.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // DROŠĪBA: zvanītājam ir jānorāda derīgs neapstrādāts rādītājs
    unsafe { intrinsics::size_of_val(val) }
}

/// Atgriež [ABI] nepieciešamo tipa minimālo izlīdzinājumu.
///
/// Katrai atsaucei uz `T` tipa vērtību jābūt šī skaitļa daudzkārtnei.
///
/// Šis ir līdzinājums, ko izmanto strukturēšanas laukos.Tas var būt mazāks par vēlamo izlīdzinājumu.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Atgriež [ABI] nepieciešamo minimālo izlīdzinājumu vērtības tipam, uz kuru norāda `val`.
///
/// Katrai atsaucei uz `T` tipa vērtību jābūt šī skaitļa daudzkārtnei.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // DROŠĪBA: val ir atsauce, tāpēc tas ir derīgs neapstrādāts rādītājs
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Atgriež [ABI] nepieciešamo tipa minimālo izlīdzinājumu.
///
/// Katrai atsaucei uz `T` tipa vērtību jābūt šī skaitļa daudzkārtnei.
///
/// Šis ir līdzinājums, ko izmanto strukturēšanas laukos.Tas var būt mazāks par vēlamo izlīdzinājumu.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Atgriež [ABI] nepieciešamo minimālo izlīdzinājumu vērtības tipam, uz kuru norāda `val`.
///
/// Katrai atsaucei uz `T` tipa vērtību jābūt šī skaitļa daudzkārtnei.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // DROŠĪBA: val ir atsauce, tāpēc tas ir derīgs neapstrādāts rādītājs
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Atgriež [ABI] nepieciešamo minimālo izlīdzinājumu vērtības tipam, uz kuru norāda `val`.
///
/// Katrai atsaucei uz `T` tipa vērtību jābūt šī skaitļa daudzkārtnei.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Šo funkciju var droši izsaukt tikai tad, ja ir spēkā šādi nosacījumi:
///
/// - Ja `T` ir `Sized`, šo funkciju vienmēr var droši izsaukt.
/// - Ja `T` izmērs bez izmēra ir:
///     - [slice], tad šķēles astes garumam jābūt inicializētam veselam skaitlim, un *visas vērtības* lielumam (dinamiskā astes garums + statiski izmēra prefikss) jāatbilst `isize`.
///     - [trait object], tad rādītāja vtable daļai jānorāda uz derīgu vtable, kas iegūta, nemērojot piespiešanu, un visas vērtības * lielumam (dinamiskā astes garums + statiski izmēra prefikss) jāatbilst `isize`.
///
///     - (unstable) [extern type], tad šo funkciju vienmēr var droši izsaukt, taču tā var panic vai citādi atgriezt nepareizu vērtību, jo ārējā tipa izkārtojums nav zināms.
///     Tā ir tāda pati darbība kā [`align_of_val`], atsaucoties uz tipu ar ārējā tipa asti.
///     - pretējā gadījumā konservatīvi nav atļauts izsaukt šo funkciju.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // DROŠĪBA: zvanītājam ir jānorāda derīgs neapstrādāts rādītājs
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Atgriež vērtību `true`, ja ir svarīga `T` tipa vērtību samazināšanās.
///
/// Tas ir tikai optimizācijas ieteikums, un to var ieviest konservatīvi:
/// tas var atgriezt `true` tipiem, kurus faktiski nevajag nomest.
/// Tā vienmēr `true` atgriešana būtu derīga šīs funkcijas ieviešana.Tomēr, ja šī funkcija faktiski atgriež `false`, tad varat būt drošs, ka `T` nomešanai nav blakusparādību.
///
/// Zema līmeņa lietām, piemēram, kolekcijām, kurām manuāli jānomet dati, jāizmanto šī funkcija, lai izvairītos no nevajadzīga mēģinājuma nomest visu to saturu, kad tie tiek iznīcināti.
///
/// Tas, iespējams, neietekmē izlaišanas būvējumus (kur cilpa, kurai nav blakus efektu, ir viegli atpazīstama un novērsta), bet bieži vien tā ir liela atkļūdošanas būvju uzvara.
///
/// Ņemiet vērā, ka [`drop_in_place`] jau veic šo pārbaudi, tādēļ, ja jūsu darba apjomu var samazināt līdz nelielam skaitam [`drop_in_place`] zvanu, tas nav vajadzīgs.
/// Īpaši ņemiet vērā, ka jūs varat [`drop_in_place`] šķēli, un tas pārbaudīs vienu needs_drop visām vērtībām.
///
/// Tādi tipi kā Vec tāpēc vienkārši izmanto `drop_in_place(&mut self[..])`, tieši neizmantojot `needs_drop`.
/// Savukārt tādiem tipiem kā [`HashMap`] ir jānomet vērtības pa vienam, un viņiem jāizmanto šī API.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Lūk, piemērs tam, kā kolekcija varētu izmantot `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // nomest datus
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Atgriež `T` tipa vērtību, ko attēlo visu nulles baitu modelis.
///
/// Tas nozīmē, ka, piemēram, `(u8, u16)` polsterējuma baits ne vienmēr tiek nulle.
///
/// Nav garantijas, ka viss nulle baitu modelis parāda derīgu kāda veida `T` vērtību.
/// Piemēram, viss nulles baitu modelis nav derīga atsauces tipu (`&T`, `&mut T`) un funkciju rādītāju vērtība.
/// `zeroed` izmantošana šādos veidos izraisa tūlītēju [undefined behavior][ub], jo [the Rust compiler assumes][inv], ka mainīgajā, kuru tā uzskata par inicializētu, vienmēr ir derīga vērtība.
///
///
/// Tam ir tāds pats efekts kā [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// Dažreiz tas ir noderīgs FFI, taču no tā parasti vajadzētu izvairīties.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Pareiza šīs funkcijas izmantošana: vesela skaitļa inicializēšana ar nulli.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Nepareizs* šīs funkcijas lietojums: atsauces inicializēšana ar nulli.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Nedefinēta uzvedība!
/// let _y: fn() = unsafe { mem::zeroed() }; // Un atkal!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // DROŠĪBA: zvanītājam jāgarantē, ka `T` ir derīga vērtība ar nulli.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Apiet Rust parastās atmiņas inicializācijas pārbaudes, izliekoties, ka iegūst `T` tipa vērtību, vienlaikus neko nedarot.
///
/// **Šī funkcija ir novecojusi.** Tā vietā izmantojiet [`MaybeUninit<T>`].
///
/// Novecošanas iemesls ir tas, ka funkciju būtībā nevar pareizi lietot: tai ir tāds pats efekts kā [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// Kā paskaidro [`assume_init` documentation][assume_init], vērtības [the Rust compiler assumes][inv] ir pareizi inicializētas.
/// Tā rezultātā zvana, piem
/// `mem::uninitialized::<bool>()` izraisa tūlītēju nedefinētu rīcību, atdodot `bool`, kas noteikti nav ne `true`, ne `false`.
/// Sliktāka, patiesi neinicializēta atmiņa, piemēram, tas, kas šeit tiek atgriezts, ir īpašs ar to, ka sastādītājs zina, ka tai nav fiksētas vērtības.
/// Tas padara nenoteiktu rīcību, ja mainīgajā ir neinicializēti dati, pat ja šim mainīgajam ir vesela skaitļa tips.
/// (Ievērojiet, ka noteikumi par neinicializētiem veseliem skaitļiem vēl nav pabeigti, taču, kamēr tie nav, ieteicams no tiem izvairīties.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // DROŠĪBA: zvanītājam jāgarantē, ka `T` ir derīga vienota vērtība.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Maina vērtības divās mainīgās vietās, nevienu no tām neinicializējot.
///
/// * Ja vēlaties nomainīt noklusējuma vai manekena vērtību, skatiet [`take`].
/// * Ja vēlaties nomainīt vērtību ar nodotu vērtību, atgriežot veco vērtību, skatiet sadaļu [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // DROŠĪBA: neapstrādātie rādītāji ir izveidoti no drošām maināmām atsaucēm, kas atbilst visām prasībām
    // `ptr::swap_nonoverlapping_one` ierobežojumi
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Aizstāj `dest` ar noklusējuma vērtību `T`, atgriežot iepriekšējo `dest` vērtību.
///
/// * Ja vēlaties aizstāt divu mainīgo vērtības, skatiet sadaļu [`swap`].
/// * Ja vēlaties aizstāt ar noklusējuma vērtības nodoto vērtību, skatiet [`replace`].
///
/// # Examples
///
/// Vienkāršs piemērs:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` ļauj iegūt īpašumtiesības uz strukturēto lauku, aizstājot to ar "empty" vērtību.
/// Bez `take` jūs varat saskarties ar šādiem jautājumiem:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Ņemiet vērā, ka `T` ne vienmēr ievieš [`Clone`], tāpēc tas nevar pat klonēt un atiestatīt `self.buf`.
/// Bet `take` var izmantot, lai atdalītu `self.buf` sākotnējo vērtību no `self`, ļaujot to atgriezt:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Pārvieto `src` uz atsauces `dest`, atgriežot iepriekšējo `dest` vērtību.
///
/// Neviena no vērtībām netiek nomesta.
///
/// * Ja vēlaties aizstāt divu mainīgo vērtības, skatiet sadaļu [`swap`].
/// * Ja vēlaties aizstāt ar noklusējuma vērtību, skatiet [`take`].
///
/// # Examples
///
/// Vienkāršs piemērs:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` ļauj patērēt strukturēto lauku, aizstājot to ar citu vērtību.
/// Bez `replace` jūs varat saskarties ar šādiem jautājumiem:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Ņemiet vērā, ka `T` ne vienmēr ievieš [`Clone`], tāpēc mēs pat nevaram klonēt `self.buf[i]`, lai izvairītos no pārvietošanās.
/// Bet `replace` var izmantot, lai atdalītu sākotnējo vērtību šajā indeksā no `self`, ļaujot to atgriezt:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // DROŠĪBA: Mēs lasām no `dest`, bet pēc tam tajā tieši ierakstām `src`,
    // tāds, ka vecā vērtība netiek dublēta.
    // Nekas netiek nomests un nekas šeit nevar panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Atsavina vērtību.
///
/// Tas tiek darīts, izsaucot argumenta [`Drop`][drop] ieviešanu.
///
/// Tas faktiski neko nedara tipiem, kas ievieš `Copy`, piem
/// integers.
/// Šādas vērtības tiek kopētas un _then_ tiek pārvietotas uz funkciju, tāpēc vērtība saglabājas pēc šī funkcijas izsaukuma.
///
///
/// Šī funkcija nav maģija;tas ir burtiski definēts kā
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Tā kā `_x` tiek pārvietots uz funkciju, tas tiek automātiski nomests, pirms funkcija atgriežas.
///
/// [drop]: Drop
///
/// # Examples
///
/// Pamata lietojums:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // skaidri nometiet vector
/// ```
///
/// Tā kā [`RefCell`] izpilda aizņēmuma noteikumus izpildes laikā, `drop` var atbrīvot [`RefCell`] aizņēmumu:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // atteikties no mainīgā aizņēmuma šajā laika nišā
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// `drop` neietekmē veselos skaitļus un citus veidus, kas ievieš [`Copy`].
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // `x` kopija tiek pārvietota un nomesta
/// drop(y); // `y` kopija tiek pārvietota un nomesta
///
/// println!("x: {}, y: {}", x, y.0); // joprojām pieejams
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Interpretē `src` kā tipu `&U` un pēc tam nolasa `src`, nepārvietojot ietverto vērtību.
///
/// Šī funkcija nedroši pieņems, ka rādītājs `src` ir derīgs [`size_of::<U>`][size_of] baitiem, pārveidojot `&T` uz `&U` un pēc tam nolasot `&U` (izņemot to, ka tas tiek izdarīts pareizi, pat ja `&U` nosaka stingrākas izlīdzināšanas prasības nekā `&T`).
/// Tā arī nedroši izveidos ietvertās vērtības kopiju, nevis pārvietosies no `src`.
///
/// Ja kompilācijas laika kļūda ir `T` un `U`, tā nav kompilācijas laika kļūda, taču ir ļoti ieteicams šo funkciju izmantot tikai tad, ja `T` un `U` ir vienāds.Šī funkcija iedarbina [undefined behavior][ub], ja `U` ir lielāks par `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Kopējiet datus no 'foo_array' un apstrādājiet tos kā 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Modificēt kopētos datus
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // 'foo_array' saturam nevajadzēja mainīties
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Ja U ir augstāka izlīdzināšanas prasība, src, iespējams, nav atbilstoši izlīdzināts.
    if align_of::<U>() > align_of::<T>() {
        // DROŠĪBA: `src` ir atsauce, kas ir derīga lasījumiem.
        // Zvanītājam jāgarantē, ka faktiskā transmutācija ir droša.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // DROŠĪBA: `src` ir atsauce, kas ir derīga lasījumiem.
        // Mēs tikko pārbaudījām, vai `src as *const U` ir pareizi izlīdzināts.
        // Zvanītājam jāgarantē, ka faktiskā transmutācija ir droša.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Necaurspīdīgs tips, kas apzīmē enum atšķirīgo.
///
/// Lai iegūtu papildinformāciju, skatiet šī moduļa funkciju [`discriminant`].
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Šīs trait realizācijas nevar atvasināt, jo mēs nevēlamies, lai T. būtu nekādas robežas.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Atgriež vērtību, kas unikāli identificē `v` enum variantu.
///
/// Ja `T` nav uzskaite, šīs funkcijas izsaukšana neradīs nedefinētu rīcību, bet atgriešanās vērtība nav norādīta.
///
///
/// # Stability
///
/// Enum varianta atšķirīgais var mainīties, ja mainās enum definīcija.
/// Dažu variantu diskriminants nemainīsies starp kompilācijām ar vienu un to pašu kompilatoru.
///
/// # Examples
///
/// To var izmantot, lai salīdzinātu apkopojumus, kuros ir dati, neņemot vērā faktiskos datus:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Atgriež variantu skaitu uzskaites tipā `T`.
///
/// Ja `T` nav uzskaite, šīs funkcijas izsaukšana neradīs nedefinētu rīcību, bet atgriešanās vērtība nav norādīta.
/// Tāpat, ja `T` ir uzskaitījums, kurā ir vairāk variantu nekā `usize::MAX`, atgriešanās vērtība nav norādīta.
/// Neapdzīvotie varianti tiks skaitīti.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}