use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Iesaiņotājs, kas kavē kompilatoru automātiski izsaukt `T` iznīcinātāju.
/// Šis iesaiņojums ir 0 izmaksu.
///
/// `ManuallyDrop<T>` tiek pakļautas tādām pašām izkārtojuma optimizācijām kā `T`.
/// Rezultātā tam *nav ietekmes* uz pieņēmumiem, ko sastādītājs izvirza par tā saturu.
/// Piemēram, `ManuallyDrop<&mut T>` inicializēšana ar [`mem::zeroed`] ir nedefinēta rīcība.
/// Ja jums ir jāapstrādā neinicializēti dati, tā vietā izmantojiet [`MaybeUninit<T>`].
///
/// Ņemiet vērā, ka piekļuve vērtībai `ManuallyDrop<T>` iekšpusē ir droša.
/// Tas nozīmē, ka `ManuallyDrop<T>`, kura saturs ir izmests, nedrīkst atklāt, izmantojot publiski pieejamu API.
/// Attiecīgi `ManuallyDrop::drop` ir nedrošs.
///
/// # `ManuallyDrop` un nomest kārtību.
///
/// Rust ir precīzi definēta vērtību [drop order].
/// Lai pārliecinātos, ka lauki vai vietējie iedzīvotāji tiek izmesti noteiktā secībā, pārkārtojiet deklarācijas tā, lai netiešā nomešanas kārtība būtu pareiza.
///
/// Lai kontrolētu nomešanas kārtību, ir iespējams izmantot `ManuallyDrop`, taču tam nepieciešams nedrošs kods, un, to attinot, ir grūti pareizi izdarīt.
///
///
/// Piemēram, ja vēlaties pārliecināties, ka noteikts lauks tiek nomests aiz pārējiem, padariet to par struktūras pēdējo lauku:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` tiks nomests pēc `children`.
///     // Rust garantē, ka lauki tiek nomesti deklarēšanas secībā.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Aptiniet vērtību, kas jānomet manuāli.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Jūs joprojām varat droši darboties ar vērtību
    /// assert_eq!(*x, "Hello");
    /// // Bet `Drop` šeit netiks palaists
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Izvelk vērtību no konteinera `ManuallyDrop`.
    ///
    /// Tas ļauj atkal nomest vērtību.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Tādējādi tiek nomests `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Izņem vērtību no `ManuallyDrop<T>` konteinera.
    ///
    /// Šī metode galvenokārt ir paredzēta vērtību pārvietošanai kritienā.
    /// Tā vietā, lai vērtību manuāli nomestu, izmantojiet [`ManuallyDrop::drop`], varat izmantot šo metodi, lai ņemtu vērtību un izmantotu to pēc vēlēšanās.
    ///
    /// Kad vien iespējams, tā vietā ir ieteicams izmantot [`into_inner`][`ManuallyDrop::into_inner`], kas novērš `ManuallyDrop<T>` satura dublēšanu.
    ///
    ///
    /// # Safety
    ///
    /// Šī funkcija semantiski pārvieto ietverto vērtību, nenovēršot turpmāku izmantošanu, atstājot nemainīgu šī konteinera stāvokli.
    /// Jūsu pienākums ir nodrošināt, lai šis `ManuallyDrop` netiktu izmantots atkārtoti.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // DROŠĪBA: mēs lasām no atsauces, kas ir garantēta
        // lai derētu lasījumiem.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Manuāli nomest iekļauto vērtību.Tas ir tieši ekvivalents [`ptr::drop_in_place`] izsaukšanai ar rādītāju iekļautajai vērtībai.
    /// Tādējādi, ja vien ietvertā vērtība nav iesaiņota struktūra, iznīcinātājs tiks izsaukts vietā, nepārvietojot vērtību, un tādējādi to var izmantot, lai droši nomestu [pinned] datus.
    ///
    /// Ja vērtība pieder jums, tā vietā varat izmantot [`ManuallyDrop::into_inner`].
    ///
    /// # Safety
    ///
    /// Šī funkcija palaiž ierobežotās vērtības iznīcinātāju.
    /// Izņemot paša iznīcinātāja veiktās izmaiņas, atmiņa paliek nemainīga, un, ciktāl tas attiecas uz kompilatoru, joprojām ir bitu modelis, kas ir derīgs `T` tipam.
    ///
    ///
    /// Tomēr šai "zombie" vērtībai nevajadzētu pakļaut drošu kodu, un šo funkciju nevajadzētu izsaukt vairāk nekā vienu reizi.
    /// Vērtības izmantošana pēc tam, kad tā ir nomesta, vai vairākas reizes samazinot vērtību, var izraisīt nedefinētu uzvedību (atkarībā no tā, ko dara `drop`).
    /// To parasti novērš tipa sistēma, taču `ManuallyDrop` lietotājiem šīs garantijas jāuztur bez kompilatora palīdzības.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // DROŠĪBA: mēs nokrītam vērtību, uz kuru norāda mainīga atsauce
        // kas tiek garantēts, ka tas ir derīgs rakstīšanai.
        // Zvanītāja ziņā ir pārliecināties, vai `slot` vairs netiek nomests.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}