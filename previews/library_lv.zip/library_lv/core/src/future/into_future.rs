use crate::future::Future;

/// Pārvēršana par `Future`.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// Rezultāts, ko future radīs pēc pabeigšanas.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// Par kādu future veidu mēs to pārvēršam?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// No vērtības izveido future.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}