#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// future apzīmē asinhronu aprēķinu.
///
/// future ir vērtība, kas, iespējams, vēl nav pabeigta skaitļošana.
/// Šāda veida "asynchronous value" ļauj pavedienam turpināt darīt noderīgu darbu, kamēr tas gaida, kamēr vērtība būs pieejama.
///
///
/// # `poll` metode
///
/// future, `poll` galvenā metode *mēģina* atrisināt future galīgajā vērtībā.
/// Šī metode nebloķē, ja vērtība nav gatava.
/// Tā vietā pašreizējo uzdevumu ir paredzēts pamodināt, kad ir iespējams panākt turpmāku progresu, vēlreiz veicot aptauju.
/// `context`, kas nodots `poll` metodei, var nodrošināt [`Waker`], kas ir rokturis pašreizējā uzdevuma pamodināšanai.
///
/// Izmantojot future, jūs parasti nezvanīsit tieši uz `poll`, bet tā vietā vērtību `.await`.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Pēc pabeigšanas radītās vērtības veids.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Mēģiniet atrisināt future līdz galīgai vērtībai, reģistrējot pašreizējo uzdevumu modināšanai, ja vērtība vēl nav pieejama.
    ///
    /// # Atgriešanās vērtība
    ///
    /// Šī funkcija atgriež:
    ///
    /// - [`Poll::Pending`] ja future vēl nav gatavs
    /// - [`Poll::Ready(val)`] ar šīs future rezultātu `val`, ja tas veiksmīgi pabeigts.
    ///
    /// Kad future ir pabeigts, klientiem to vairs nevajadzētu `poll`.
    ///
    /// Kad future vēl nav gatavs, `poll` atgriež `Poll::Pending` un saglabā [`Waker`] klonu, kas nokopēts no pašreizējā [`Context`].
    /// Pēc tam šis [`Waker`] tiek modināts, tiklīdz future var panākt progresu.
    /// Piemēram, future, kas gaida ligzdas kļūšanu lasāmu, izsauktu `.clone()` uz [`Waker`] un saglabātu to.
    /// Kad citur pienāk signāls, kas norāda, ka ligzda ir lasāma, tiek izsaukta [`Waker::wake`] un tiek pamodināts ligzdas future uzdevums.
    /// Kad uzdevums ir pamodināts, tam vēlreiz jāmēģina `poll` atjaunot future, kas var radīt galīgo vērtību vai nē.
    ///
    /// Ņemiet vērā, ka, veicot vairākus zvanus uz `poll`, modinātāja saņemšanai jāplāno tikai [`Waker`] no [`Context`], kas nodots pēdējam zvanam.
    ///
    /// # Izpildlaika raksturojums
    ///
    /// Futures atsevišķi ir *inerti*;lai panāktu progresu, tie ir *aktīvi* jāaptaujā, tas nozīmē, ka katru reizi, kad tiek pamodināts pašreizējais uzdevums, tam vajadzētu aktīvi atkārtoti aptaujāt gaidāmo futures, par kuru tas joprojām ir ieinteresēts.
    ///
    /// `poll` funkcija netiek atkārtoti izsaukta ciešā lokā-tā vietā to vajadzētu izsaukt tikai tad, kad future norāda, ka tā ir gatava progresēt (zvanot uz `wake()`).
    /// Ja esat iepazinies ar `poll(2)` vai `select(2)` sistēmas zvaniem uz Unix, ir vērts atzīmēt, ka futures parasti * necieš tādas pašas problēmas kā "all wakeups must poll all events";tie ir vairāk kā `epoll(4)`.
    ///
    /// `poll` ieviešanai ir jācenšas ātri atgriezties un nevajadzētu bloķēt.Ātra atgriešanās novērš nevajadzīgu pavedienu vai notikumu cilpu aizsērēšanu.
    /// Ja pirms laika ir zināms, ka zvans uz `poll` var ilgt kādu laiku, darbs jāpārkrauj pavedienu kopā (vai kaut kas līdzīgs), lai nodrošinātu, ka `poll` var ātri atgriezties.
    ///
    /// # Panics
    ///
    /// Kad future ir pabeigts (`Ready` atgriezis no `poll`), tā `poll` metodes izsaukšana atkal var panic bloķēt uz visiem laikiem vai izraisīt cita veida problēmas;`Future` trait nenosaka prasības par šāda zvana sekām.
    /// Tomēr, tā kā metode `poll` nav atzīmēta ar `unsafe`, tiek piemēroti Rust parastie noteikumi: zvani nekad nedrīkst izraisīt nedefinētu uzvedību (atmiņas bojājumus, nepareizu `unsafe` funkciju izmantošanu vai tamlīdzīgi), neatkarīgi no future stāvokļa.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}