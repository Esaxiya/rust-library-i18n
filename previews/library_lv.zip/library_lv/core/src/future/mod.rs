#![stable(feature = "futures_api", since = "1.36.0")]

//! Asinhronās vērtības.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// Šis tips ir nepieciešams, jo:
///
/// a) Ģeneratori nevar ieviest `for<'a, 'b> Generator<&'a mut Context<'b>>`, tāpēc mums ir jānodod neapstrādāts rādītājs (sk. <https://github.com/rust-lang/rust/issues/68923>).
///
/// b) Neapstrādāti rādītāji un `NonNull` nav `Send` vai `Sync`, tāpēc tas padarītu arī katru future non-Send/Sync, un mēs to nevēlamies.
///
/// Tas arī vienkāršo `.await` HIR nolaišanu.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Aptiniet ģeneratoru future.
///
/// Šī funkcija atgriež `GenFuture` apakšā, bet paslēpj to `impl Trait`, lai iegūtu labākus kļūdu ziņojumus (`impl Future`, nevis `GenFuture<[closure.....]>`).
///
// Tas ir `const`, lai izvairītos no papildu kļūdām pēc atkopšanas no `const async fn`
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // Mēs paļaujamies uz to, ka async/await futures ir nekustīgi, lai radītu pašreferenciālus aizņēmumus pamatā esošajā ģeneratorā.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // DROŠĪBA: Droša, jo mēs esam !Unpin + !Drop, un tā ir tikai lauka projekcija.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // Atsāciet ģeneratoru, pārveidojot `&mut Context` par neapstrādātu rādītāju `NonNull`.
            // `.await` nolaišana droši atgriezīsies pie `&mut Context`.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // DROŠĪBA: zvanītājam jāgarantē, ka `cx.0` ir derīgs rādītājs
    // kas atbilst visām mainīgas atsauces prasībām.
    unsafe { &mut *cx.0.as_ptr().cast() }
}