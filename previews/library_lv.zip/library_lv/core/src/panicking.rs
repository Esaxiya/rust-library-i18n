//! Panic atbalsts libcore
//!
//! Pamata bibliotēka nevar definēt paniku, bet tā * paziņo par paniku.
//! Tas nozīmē, ka funkcijas libcore iekšpusē ir atļautas panic, taču, lai crate augšpus straumes būtu noderīga, ir jādefinē panika, lai libcore varētu izmantot.
//! Pašreizējā panikas saskarne ir:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Šī definīcija ļauj krist panikā ar jebkuru vispārīgu ziņojumu, taču tā neļauj izgāzties ar `Box<Any>` vērtību.
//! (`PanicInfo` satur tikai `&(dyn Any + Send)`, kuram mēs aizpildām fiktīvu vērtību sadaļā `PanicInfo: : internal_constructor`.) Iemesls tam ir tāds, ka libcore nav atļauts piešķirt.
//!
//!
//! Šis modulis satur dažas citas panikas funkcijas, taču tās ir tikai nepieciešamās kompilatora lang vienības.Izmantojot šo vienu funkciju, visi panics tiek piltuvē.
//! Faktiskais simbols tiek deklarēts, izmantojot atribūtu `#[panic_handler]`.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Libcore `panic!` makro pamatā esošā ieviešana, ja netiek izmantots formatējums.
#[cold]
// nekad neievietojiet, ja vien panic_immediate_abort, lai pēc iespējas izvairītos no koda uzpūšanās zvanu vietnēs
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // kodenam nepieciešami panic pārplūdes un citiem `Assert` MIR terminatoriem
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Izmantojiet Arguments::new_v1, nevis format_args! ("{}", Expr), lai potenciāli samazinātu izmēru pieskaitāmās izmaksas.
    // Formāts_args!makro izmanto str displeju trait, lai uzrakstītu izteicienu, kas izsauc Formatter::pad, kuram jāiekļauj virknes saīsināšana un pildīšana (kaut arī šeit neviens netiek izmantots).
    //
    // Izmantojot Arguments::new_v1, kompilators var ļaut izlaist Formatter::pad no izejas binārā, ietaupot līdz pat dažiem kilobaitiem.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // vajadzīgs konst-novērtētajam panics
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // nepieciešami kodegenam panic piekļuvei OOB array/slice
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Libcore `panic!` makro pamatā esošā ieviešana, kad tiek izmantots formatējums.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // PIEZĪME Šī funkcija nekad nepārsniedz FFI robežu;tas ir Rust-to-Rust zvans, kas tiek atrisināts ar funkciju `#[panic_handler]`.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // DROŠĪBA: `panic_impl` ir definēts drošā Rust kodā, tāpēc ir droši piezvanīt.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Iekšējā funkcija `assert_eq!` un `assert_ne!` makro
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}