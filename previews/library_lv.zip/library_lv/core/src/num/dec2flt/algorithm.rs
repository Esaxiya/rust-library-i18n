//! Dažādie darba algoritmi.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Nozīmīgo bitu skaits Fp
const P: u32 = 64;

// Mēs vienkārši glabājam vislabāko tuvinājumu *visiem* eksponentiem, tāpēc mainīgo "h" un ar to saistītos nosacījumus var izlaist.
// Tas tirgo veiktspēju pāris kilobaitiem vietas.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// Lielākajā daļā arhitektūru peldošā komata operācijām ir nepārprotams bitu lielums, tāpēc aprēķina precizitāti nosaka pēc operācijas.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// Operētājsistēmā x86 x87 FPU tiek izmantots pludiņa operācijām, ja SSE/SSE2 paplašinājumi nav pieejami.
// Pēc noklusējuma x87 FPU darbojas ar 80 bitu precizitāti, kas nozīmē, ka darbības noapaļos līdz 80 bitiem, izraisot dubultu noapaļošanu, kad vērtības galu galā tiek attēlotas kā
//
// 32/64 bitu peldošās vērtības.Lai to pārvarētu, FPU vadības vārdu var iestatīt tā, lai aprēķini tiktu veikti vēlamajā precizitātē.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// Struktūra, ko izmanto, lai saglabātu FPU vadības vārda sākotnējo vērtību, lai to varētu atjaunot, kad struktūra tiek nomesta.
    ///
    ///
    /// x87 FPU ir 16 bitu reģistrs, kura lauki ir šādi:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// Visu lauku dokumentācija ir pieejama programmatūras IA-32 Architectures izstrādātāja rokasgrāmatā (1. sējums).
    ///
    /// Vienīgais lauks, kas attiecas uz šo kodu, ir PC, Precision Control.
    /// Šis lauks nosaka FPU veikto darbību precizitāti.
    /// To var iestatīt uz:
    ///  - 0b00, viena precizitāte, ti, 32 biti
    ///  - 0b10, dubultā precizitāte, ti, 64 biti
    ///  - 0b11, dubultā pagarinātā precizitāte, ti, 80 biti (noklusējuma stāvoklis) 0b01 vērtība ir rezervēta, un to nedrīkst izmantot.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // DROŠĪBA: `fldcw` instrukcija ir pārbaudīta, lai varētu pareizi darboties
        // jebkura `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: Mēs izmantojam ATT sintaksi, lai atbalstītu LLVM 8 un LLVM 9.
                options(att_syntax, nostack),
            )
        }
    }

    /// Iestata FPU precizitātes lauku uz `T` un atgriež `FPUControlWord`.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Aprēķiniet lauka Precision Control vērtību, kas piemērota `T`.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 biti
            8 => 0x0200, // 64 biti
            _ => 0x0300, // noklusējums, 80 biti
        };

        // Iegūstiet vadības vārda sākotnējo vērtību, lai to atjaunotu vēlāk, kad `FPUControlWord` struktūra tiek atcelta. DROŠĪBA: `fnstcw` instrukcija ir pārbaudīta, lai varētu pareizi darboties ar jebkuru `u16`
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: Mēs izmantojam ATT sintaksi, lai atbalstītu LLVM 8 un LLVM 9.
                options(att_syntax, nostack),
            )
        }

        // Iestatiet vadības vārdu vēlamajai precizitātei.
        // To panāk, maskējot veco precizitāti (8. un 9. bits, 0x300) un aizstājot to ar iepriekš aprēķināto precizitātes karodziņu.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// Ātrais Bellerophon ceļš, izmantojot mašīnas lieluma veselus skaitļus un pludiņus.
///
/// Tas tiek izvilkts atsevišķā funkcijā, lai to varētu mēģināt pirms bignuma konstruēšanas.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Mēs salīdzinām precīzu vērtību ar MAX_SIG beigās, tas ir tikai ātrs, lēts noraidījums (un arī pārējais kods tiek atbrīvots no raizēm par nepietiekamu plūsmu).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // Ātrais ceļš ir atkarīgs no tā, vai aritmētika tiek noapaļota līdz pareizajam bitu skaitam bez starpposma noapaļošanas.
    // Operētājsistēmā x86 (bez SSE vai SSE2) ir jāmaina x87 FPU kaudzes precizitāte, lai tā tieši noapaļotu uz 64/32 bitu.
    // Funkcija `set_precision` rūpējas par precizitātes iestatīšanu arhitektūrām, kurām tā jāiestata, mainot globālo stāvokli (piemēram, x87 FPU vadības vārds).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // Gadījumu e <0 nevar salocīt citā zarā.
    // Negatīvo spēku rezultātā atkārtojas daļēja daļa binārā, kas ir noapaļota, kas galarezultātā rada reālas (un reizēm diezgan nozīmīgas!) Kļūdas.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// Algoritms Belerofons ir triviāls kods, ko pamato ar nenozīmīgu skaitlisko analīzi.
///
/// Tas noapaļo "f" līdz pludiņam ar 64 bitu nozīmēm un reizina to ar labāko `10^e` tuvinājumu (tajā pašā peldošā komata formātā).Bieži vien ar to pietiek, lai iegūtu pareizu rezultātu.
/// Tomēr, ja rezultāts ir tuvu pusceļam starp diviem blakus esošajiem (ordinary) pludiņiem, salikta noapaļošanas kļūda, reizinot divus tuvinājumus, nozīmē, ka rezultāts var tikt izslēgts ar dažiem bitiem.
/// Kad tas notiek, iteratīvais algoritms R novērš lietas.
///
/// Ar roku viļņoto "close to halfway" precīzi nosaka papīra skaitliskā analīze.
/// Klingera vārdiem sakot:
///
/// > Slīpums, kas izteikts vismazāk nozīmīgā bita vienībās, ir kļūdas saistošs ierobežojums
/// > kas uzkrājies aproksimācijas aprēėina tuvināšanai f * 10 ^ e.(Slīpums ir
/// > nav saistīts ar patieso kļūdu, bet ierobežo tuvinājumu z un
/// > vislabākā iespējamā aproksimācija, kurā tiek izmantoti p nozīmes biti.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // Gadījumi abs(e) <log5(2^N) ir fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // Vai slīpums ir pietiekami liels, lai kaut ko mainītu, noapaļojot līdz n bitiem?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// Iteratīvs algoritms, kas uzlabo `f * 10^e` peldošā komata tuvinājumu.
///
/// Katrs atkārtojums iegūst vienu vienību pēdējā vietā tuvāk, kuras saplūšana, protams, prasa šausmīgi ilgu laiku, ja `z0` ir pat nedaudz izslēgts.
/// Par laimi, ja to izmanto kā rezerves Bellerophon, sākuma aproksimāciju izslēdz ne vairāk kā viens ULP.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Atrodiet pozitīvos skaitļus `x`, `y` tā, lai `x / y` būtu tieši `(f *10^e) / (m* 2^k)`.
        // Tas ne tikai ļauj izvairīties no `e` un `k` zīmju novēršanas, bet arī izslēdz divu `10^e` un `2^k` kopīgo spēku, lai skaitļi būtu mazāki.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Tas ir rakstīts mazliet neveikli, jo mūsu bignumi neatbalsta negatīvos skaitļus, tāpēc mēs izmantojam absolūto vērtību + zīmju informāciju.
        // Reizināšana ar m_digits nevar pārplūst.
        // Ja `x` vai `y` ir pietiekami lieli, ka mums jāuztraucas par pārplūdi, tad tie ir arī pietiekami lieli, lai `make_ratio` samazinātu daļu par koeficientu 2 ^ 64 vai vairāk.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Jums vairs nav nepieciešams x, saglabājiet clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Joprojām ir nepieciešams y, izveidojiet kopiju.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// Ņemot vērā `x = f` un `y = m`, kur `f` kā parasti apzīmē ievades decimālciparus, un `m` ir peldošā komata aproksimācijas nozīme, `x / y` koeficientu padariet vienādu ar `(f *10^e) / (m* 2^k)`, iespējams, samazinātu ar abu jaudu, abiem ir kopīgs.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, izņemot to, ka mēs samazinām daļu ar kādu divu spēku.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m Tas nevar pārplūst, jo tam ir nepieciešams pozitīvs `e` un negatīvs `k`, kas var notikt tikai vērtībām, kas ir ļoti tuvu 1, kas nozīmē, ka `e` un `k` būs salīdzinoši niecīgas.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Arī tas nevar pārplūst, skatiet iepriekš.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), atkal samazinot ar divu kopēju spēku.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Konceptuāli algoritms M ir vienkāršākais veids, kā decimāldaļu pārveidot par pludiņu.
///
/// Mēs izveidojam koeficientu, kas ir vienāds ar `f * 10^e`, pēc tam iemetot divus spēkus, līdz tas dod derīgu pludiņa nozīmes vērtību.
/// Binārais eksponents `k` ir reižu skaits, kad mēs reizinājām skaitītāju vai saucēju ar diviem, ti, vienmēr `f *10^e` ir vienāds ar `(u / v)* 2^k`.
/// Kad esam noskaidrojuši nozīmīgumu, mums ir jāapļo tikai, pārbaudot atlikušo dalījumu, kas tiek veikts palīgu funkcijās tālāk.
///
///
/// Šis algoritms ir ļoti lēns pat ar `quick_start()` aprakstīto optimizāciju.
/// Tomēr tas ir vienkāršākais no algoritmiem, lai pielāgotos pārplūdes, nepietiekamas plūsmas un subnormālu rezultātu iegūšanai.
/// Šī ieviešana tiek pārņemta, kad Bellerophon un Algorithm R ir pārņemti.
/// Pazemināšanas un pārplūdes noteikšana ir vienkārša: attiecība joprojām nav diapazona nozīmes zīme, tomēr minimum/maximum eksponents ir sasniegts.
/// Pārplūdes gadījumā mēs vienkārši atgriežam bezgalību.
///
/// Apstrāde ar nepietiekamu plūsmu un subnormāliem apstākļiem ir sarežģītāka.
/// Viena liela problēma ir tā, ka ar minimālo eksponentu attiecība joprojām var būt pārāk liela nozīmes skaitlim.
/// Sīkāku informāciju skatiet underflow().
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // Labot iespējamo optimizāciju: vispāriniet lielo_to_fp, lai šeit varētu izdarīt fp_to_float(big_to_fp(u)) ekvivalentu, tikai bez dubultas noapaļošanas.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Mums jāapstājas pie minimālā eksponenta, ja mēs gaidām līdz `k < T::MIN_EXP_INT`, tad mēs esam izslēgti ar koeficientu divi.
            // Diemžēl tas nozīmē, ka mums ir jāparedz normālie skaitļi ar minimālo eksponentu.
            // FIXME atrod elegantāku formulējumu, taču izpildiet `tiny-pow10` testu, lai pārliecinātos, ka tas tiešām ir pareizs!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Izlaižot lielāko daļu M algoritma atkārtojumu, pārbaudot bitu garumu.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // Bitu garums ir divu pamatlogaritmu novērtējums un log(u / v) = log(u), log(v).
    // Aprēķins ir izslēgts ne vairāk kā par 1, bet vienmēr par zemu, tāpēc kļūdai log(u) un log(v) ir viena zīme un tā tiek atcelta (ja abas ir lielas).
    // Tāpēc log(u / v) kļūda ir arī viena.
    // Mērķa attiecība ir tāda, kur u/v atrodas diapazona nozīmē.Tādējādi mūsu izbeigšanas nosacījums ir log2(u / v), kas ir nozīmības biti, plus/minus viens.
    // FIXME Aplūkojot otro bitu, aplēses varētu uzlaboties un izvairīties no vēl vairāk sadalījumiem.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Nepietiekama vai subnormāla.Atstājiet to galvenajai funkcijai.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Pārplūde.Atstājiet to galvenajai funkcijai.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // Attiecība nav diapazona nozīmes zīme ar minimālo eksponentu, tāpēc mums jānoapaļo liekie biti un attiecīgi jāpielāgo eksponents.
    // Patiesā vērtība tagad izskatās šādi:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q trunc.(pārstāv rem)
    //
    // Tāpēc, kad noapaļotie biti ir!= 0.5 ULP, viņi noapaļošanu izlemj paši.
    // Kad tie ir vienādi un atlikums nav nulle, vērtība joprojām ir jānoapaļo uz augšu.
    // Tikai tad, kad noapaļotie biti ir 1/2 un atlikušais ir nulle, mums ir puse līdzvērtīga situācija.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Parasts noapaļots līdz izlīdzinājums, kas ir apmulsināts ar nepieciešamību noapaļot, pamatojoties uz atlikušo dalījumu.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}