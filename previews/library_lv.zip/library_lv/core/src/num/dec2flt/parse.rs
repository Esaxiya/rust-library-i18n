//! Veidlapas decimāldaļas virknes pārbaude un sadalīšana:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! Citiem vārdiem sakot, standarta peldošā komata sintakse, izņemot divus izņēmumus: bez zīmes un bez "inf" un "NaN" apstrādes.Tos apstrādā vadītāja funkcija (super::dec2flt).
//!
//! Lai gan derīgu ievadu atpazīšana ir salīdzinoši vienkārša, šim modulim ir jānoraida arī neskaitāmās nederīgās variācijas, nekad panic, un jāveic daudzas pārbaudes, uz kurām citi moduļi paļaujas nevis uz panic (vai pārplūdi).
//!
//! Vēl sliktāk ir tas, ka viss, kas notiek vienā reizē ar ievadi.
//! Tāpēc esiet piesardzīgs, kaut ko pārveidojot, un vēlreiz pārbaudiet citus moduļus.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// Interesantas decimāldaļas virknes daļas.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// Decimāldaļskaitļa eksponents, garantēts, ka tajā ir mazāk nekā 18 cipari aiz komata
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// Pārbauda, vai ievades virkne ir derīgs peldošā komata skaitlis, un, ja tā, atrodiet tajā neatņemamo daļu, daļu un eksponentu.
/// Netiek galā ar zīmēm.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // Pirms 'e' nav ciparu
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // Pirms vai pēc punkta mums ir nepieciešams vismaz viens cipars.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // Trailing junk pēc daļējas daļas
            }
        }
        _ => Invalid, // Aiz pēdējās junk pēc pirmā cipara virknes
    }
}

/// Izgriež decimālzīmes līdz pirmajam ciparam bez cipariem.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// Eksponenta iegūšana un kļūdu pārbaude.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // Galīgais junk pēc eksponenta
    }
    if number.is_empty() {
        return Invalid; // Tukšs eksponents
    }
    // Šajā brīdī mums noteikti ir derīga ciparu virkne.Tas var būt pārāk garš, lai ievietotu `i64`, bet, ja tas ir tik milzīgs, ievade noteikti ir nulle vai bezgalība.
    // Tā kā katra nulle decimāldaļskaitļos tikai pielāgo eksponentu par +/-1, pie exp=10 ^ 18 ievadei jābūt 17 eksabaitiem (!) nulles, lai pat attālināti tuvotos galīgajam skaitlim.
    //
    // Tas nav gluži tāds lietošanas gadījums, par kuru mums jārūpējas.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}