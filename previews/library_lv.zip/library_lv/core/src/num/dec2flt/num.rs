//! Lietderības funkcijas bignums, kurām nav pārāk jēgas pārvērsties par metodēm.

// FIXME Šī moduļa nosaukums ir mazliet nožēlojams, jo citi moduļi arī importē `core::num`.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Pārbaudiet, vai visu bitu saīsināšana, kas nav tik nozīmīga kā `ones_place`, rada relatīvo kļūdu, kas ir mazāka, vienāda vai lielāka par 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Ja visi atlikušie biti ir nulle, tas ir= 0.5 ULP, pretējā gadījumā> 0.5 Ja bitu vairs nav (half_bit==0), zemāk redzamais arī pareizi atgriež vienādu.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Pārvērš ASCII virkni, kurā ir tikai cipari aiz komata, par `u64`.
///
/// Nepārbauda pārpildes vai nederīgas rakstzīmes, tādēļ, ja zvanītājs nav uzmanīgs, rezultāts ir viltus un var panic (lai gan tas nebūs `unsafe`).
/// Turklāt tukšās virknes tiek uzskatītas par nulli.
/// Šī funkcija pastāv, jo
///
/// 1. lietojot `FromStr` operētājsistēmā `&[u8]`, nepieciešama `from_utf8_unchecked`, kas ir slikti, un
/// 2. `integral.parse()` un `fractional.parse()` rezultātu apkopošana ir sarežģītāka nekā visa šī funkcija.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Pārvērš virkni ASCII ciparu par bignum.
///
/// Tāpat kā `from_str_unchecked`, arī šī funkcija ir atkarīga no parsētāja, lai atsijātu bez cipariem.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Atsauc bignumu 64 bitu vesels skaitlis.Panics, ja skaitlis ir pārāk liels.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Izvelk virkni bitu.

/// Indekss 0 ir vismazāk nozīmīgais bits, un diapazons ir pusi atvērts, kā parasti.
/// Panics, ja tiek prasīts iegūt vairāk bitu nekā ietilpināt atgriešanas tipā.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}