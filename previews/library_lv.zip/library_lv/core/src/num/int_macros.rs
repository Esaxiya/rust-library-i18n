macro_rules! int_impl {
    ($SelfT:ty, $ActualT:ident, $UnsignedT:ty, $BITS:expr, $Min:expr, $Max:expr,
     $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
     $reversed:expr, $le_bytes:expr, $be_bytes:expr,
     $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// Mazākā vērtība, ko var attēlot ar šo vesela skaitļa tipu.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, ", stringify!($Min), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = !0 ^ ((!0 as $UnsignedT) >> 1) as Self;

        /// Lielākā vērtība, ko var attēlot ar šo vesela skaitļa tipu.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($Max), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !Self::MIN;

        /// Šī vesela skaitļa veida lielums bitos.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Konvertē virknes daļu noteiktā bāzē uz veselu skaitli.
        ///
        /// Paredzams, ka virkne būs izvēles zīme `+` vai `-`, kam sekos cipari.
        /// Vadošā un aizmugurējā atstarpe ir kļūda.
        /// Cipari ir šo rakstzīmju apakškopa atkarībā no `radix`:
        ///
        ///  * `0-9`
        ///  * `a-z`
        ///  * `A-Z`
        ///
        /// # Panics
        ///
        /// Šī funkcija panics, ja `radix` nav diapazonā no 2 līdz 36.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// Atgriež `self` binārā attēlojuma vienību skaitu.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        #[doc = concat!("let n = 0b100_0000", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 1);
        ///
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 { (self as $UnsignedT).count_ones() }

        /// Atgriež nulļu skaitu `self` binārā attēlojumā.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// Atgriež vadošo nulļu skaitu `self` binārā attēlojumā.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]
        /// assert_eq!(n.leading_zeros(), 0);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            (self as $UnsignedT).leading_zeros()
        }

        /// Atgriež beigu nulļu skaitu `self` binārā attēlojumā.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        #[doc = concat!("let n = -4", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            (self as $UnsignedT).trailing_zeros()
        }

        /// Atgriež `self` binārā attēlojuma vadošo skaitu.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]

        #[doc = concat!("assert_eq!(n.leading_ones(), ", stringify!($BITS), ");")]
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (self as $UnsignedT).leading_ones()
        }

        /// Atgriež skaitļu `self` bināro attēlojumu skaitu.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        #[doc = concat!("let n = 3", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (self as $UnsignedT).trailing_ones()
        }

        /// Pārvieto bitus pa kreisi par noteiktu summu `n`, apņemot saīsinātos bitus līdz iegūtā veselā skaitļa beigām.
        ///
        ///
        /// Lūdzu, ņemiet vērā, ka šī nav tā pati darbība kā `<<` pārslēgšanas operators!
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_left(n) as Self
        }

        /// Pārvieto bitus pa labi par noteiktu summu `n`, aptinot saīsinātos bitus līdz iegūtā veselā skaitļa sākumam.
        ///
        ///
        /// Lūdzu, ņemiet vērā, ka šī nav tā pati darbība kā `>>` pārslēgšanas operators!
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_right(n) as Self
        }

        /// Apgriež vesela skaitļa baitu secību.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// ļaujiet m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            (self as $UnsignedT).swap_bytes() as Self
        }

        /// Apmaina veselu skaitļu bitu secību.
        /// Mazāk nozīmīgais bits kļūst par nozīmīgāko bitu, otrs vismazāk nozīmīgais bits kļūst par otro nozīmīgāko bitu utt.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// ļaujiet m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            (self as $UnsignedT).reverse_bits() as Self
        }

        /// Pārvērš veselu skaitli no lielā endiana par mērķa endianitāti.
        ///
        /// Lielā mērogā tas ir aizliegums.Mazajā endijā baiti tiek apmainīti.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ja cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } cits
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Pārvērš veselu skaitli no mazā endiāna uz mērķa endianitāti.
        ///
        /// Mazajā endiānā tas ir aizliegums.Lielajā endijā baiti tiek apmainīti.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ja cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } cits
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// Pārvērš `self` par lielo endiānu no mērķa endianitātes.
        ///
        /// Lielā mērogā tas ir aizliegums.Mazajā endijā baiti tiek apmainīti.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ja cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } cits { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // vai nebūt?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// Pārvērš `self` par mazu endiānu no mērķa endianitātes.
        ///
        /// Mazajā endiānā tas ir aizliegums.Lielajā endijā baiti tiek apmainīti.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ja cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } cits { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Pārbaudīts veselā skaitļa papildinājums.
        /// Aprēķina `self + rhs`, atgriežot `None`, ja ir notikusi pārpilde.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), Some(", stringify!($SelfT), "::MAX - 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Nepārbaudīts vesela skaitļa papildinājums.Aprēķina `self + rhs`, pieņemot, ka pārplūde nevar notikt.
        /// Tā rezultātā nedefinēta uzvedība, kad
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // DROŠĪBA: zvanītājam jāievēro `unchecked_add` drošības līgums.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Pārbaudīta veselu skaitļu atņemšana.
        /// Aprēķina `self - rhs`, atgriežot `None`, ja ir notikusi pārpilde.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(1), Some(", stringify!($SelfT), "::MIN + 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Nepārbaudīta veselu skaitļu atņemšana.Aprēķina `self - rhs`, pieņemot, ka pārplūde nevar notikt.
        /// Tā rezultātā nedefinēta uzvedība, kad
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // DROŠĪBA: zvanītājam jāievēro `unchecked_sub` drošības līgums.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Pārbaudīta vesela skaitļa reizināšana.
        /// Aprēķina `self * rhs`, atgriežot `None`, ja ir notikusi pārpilde.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(1), Some(", stringify!($SelfT), "::MAX));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Nepārbaudīta vesela skaitļa reizināšana.Aprēķina `self * rhs`, pieņemot, ka pārplūde nevar notikt.
        /// Tā rezultātā nedefinēta uzvedība, kad
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // DROŠĪBA: zvanītājam jāievēro `unchecked_mul` drošības līgums.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Pārbaudīts veselā skaitļa dalījums.
        /// Aprēķina `self / rhs`, atgriežot `None`, ja `rhs == 0` vai sadalījums izraisa pārplūdi.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // DROŠĪBA: iepriekš pārbaudītas div ar nulli un ar INT_MIN
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Pārbaudīts Eiklida šķelšanās.
        /// Aprēķina `self.div_euclid(rhs)`, atgriežot `None`, ja `rhs == 0` vai sadalījums rada pārplūdi.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div_euclid(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div_euclid(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }

        /// Pārbaudīts veselā skaitļa atlikums.
        /// Aprēķina `self % rhs`, atgriežot `None`, ja `rhs == 0` vai sadalījums izraisa pārplūdi.
        ///
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem(-1), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // DROŠĪBA: iepriekš pārbaudītas div ar nulli un ar INT_MIN
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Pārbaudīts Eiklida laika atlikums.
        /// Aprēķina `self.rem_euclid(rhs)`, atgriežot `None`, ja `rhs == 0` vai sadalījums izraisa pārplūdi.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem_euclid(-1), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Pārbaudīta negācija.
        /// Aprēķina `-self`, atgriežot `None`, ja `self == MIN`.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_neg(), Some(-5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Pārbaudīta maiņa pa kreisi.
        /// Aprēķina `self << rhs`, atgriežot `None`, ja `rhs` ir lielāks vai vienāds ar bitu skaitu `self`.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Pārbaudīta maiņa pa labi.
        /// Aprēķina `self >> rhs`, atgriežot `None`, ja `rhs` ir lielāks vai vienāds ar bitu skaitu `self`.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(128), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Pārbaudīta absolūtā vērtība.
        /// Aprēķina `self.abs()`, atgriežot `None`, ja `self == MIN`.
        ///
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-5", stringify!($SelfT), ").checked_abs(), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_abs(), None);")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_abs(self) -> Option<Self> {
            if self.is_negative() {
                self.checked_neg()
            } else {
                Some(self)
            }
        }

        /// Pārbaudīta eksponācija.
        /// Aprēķina `self.pow(exp)`, atgriežot `None`, ja ir notikusi pārpilde.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        #[doc = concat!("assert_eq!(8", stringify!($SelfT), ".checked_pow(2), Some(64));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```

        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }
            // tā kā exp!=0, visbeidzot, exp jābūt 1.
            // Ar eksponenta pēdējo bitu rīkojieties atsevišķi, jo pamatnes kvadrātišana pēc tam nav nepieciešama un var izraisīt nevajadzīgu pārplūdi.
            //
            //
            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Piesātinošs vesels skaitlis.
        /// Aprēķina `self + rhs`, piesātinot skaitliskās robežas, nevis pārpildot.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(100), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_add(-1), ", stringify!($SelfT), "::MIN);")]
        /// ```

        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Piesātinošs vesela skaitļa atņemšana.
        /// Aprēķina `self - rhs`, piesātinot skaitliskās robežas, nevis pārpildot.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(127), -27);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_sub(100), ", stringify!($SelfT), "::MIN);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_sub(-1), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Piesātinoša vesela skaitļa noliegums.
        /// Aprēķina `-self`, atgriežot `MAX`, ja `self == MIN` ir pārpildīts.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_neg(), -100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_neg(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_neg(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_neg(), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_neg(self) -> Self {
            intrinsics::saturating_sub(0, self)
        }

        /// Piesātinošā absolūtā vērtība.
        /// Aprēķina `self.abs()`, atgriežot `MAX`, ja `self == MIN` ir pārpildīts.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_abs(self) -> Self {
            if self.is_negative() {
                self.saturating_neg()
            } else {
                self
            }
        }

        /// Piesātinoša vesela skaitļa reizināšana.
        /// Aprēķina `self * rhs`, piesātinot skaitliskās robežas, nevis pārpildot.
        ///
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".saturating_mul(12), 120);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_mul(10), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_mul(10), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => if (self < 0) == (rhs < 0) {
                    Self::MAX
                } else {
                    Self::MIN
                }
            }
        }

        /// Piesātinoša vesela skaitļa eksponēšana.
        /// Aprēķina `self.pow(exp)`, piesātinot skaitliskās robežas, nevis pārpildot.
        ///
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-4", stringify!($SelfT), ").saturating_pow(3), -64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(3), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None if self < 0 && exp % 2 == 1 => Self::MIN,
                None => Self::MAX,
            }
        }

        /// (modular) papildināšanas iesaiņošana.
        /// Aprēķina `self + rhs`, aptinoties pie tipa robežas.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_add(27), 127);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_add(2), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// (modular) atņemšanas iesaiņošana.
        /// Aprēķina `self - rhs`, aptinoties pie tipa robežas.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".wrapping_sub(127), -127);")]
        #[doc = concat!("assert_eq!((-2", stringify!($SelfT), ").wrapping_sub(", stringify!($SelfT), "::MAX), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// (modular) reizināšanas ietīšana.
        /// Aprēķina `self * rhs`, aptinoties pie tipa robežas.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".wrapping_mul(12), 120);")]
        /// assert_eq!(11i8.wrapping_mul(12), -124);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// (modular) sadalījuma iesaiņošana.Aprēķina `self / rhs`, aptinoties pie tipa robežas.
        ///
        /// Vienīgais gadījums, kad šāda iesaiņošana var notikt, ir tad, kad `MIN / -1` dala ar parakstītu tipu (kur `MIN` ir tipa negatīvā minimālā vērtība);tas ir ekvivalents `-MIN`, pozitīvajai vērtībai, kas ir pārāk liela, lai attēlotu tipā.
        /// Šādā gadījumā šī funkcija atgriež `MIN` pati.
        ///
        /// # Panics
        ///
        /// Šī funkcija būs panic, ja `rhs` ir 0.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div(-1), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self.overflowing_div(rhs).0
        }

        /// Eiklida dalījuma ietīšana.
        /// Aprēķina `self.div_euclid(rhs)`, aptinoties pie tipa robežas.
        ///
        /// Iesaiņošana `MIN / -1` notiks tikai ar parakstītu tipu (kur `MIN` ir tipa negatīvā minimālā vērtība).
        /// Tas ir ekvivalents `-MIN`-pozitīvajai vērtībai, kas ir pārāk liela, lai attēlotu tipā.
        /// Šajā gadījumā šī metode atgriež `MIN` pati.
        ///
        /// # Panics
        ///
        /// Šī funkcija būs panic, ja `rhs` ir 0.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div_euclid(-1), -128);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self.overflowing_div_euclid(rhs).0
        }

        /// (modular) atlikuma iesaiņošana.Aprēķina `self % rhs`, aptinoties pie tipa robežas.
        ///
        /// Šāda aptīšana nekad faktiski nenotiek matemātiski;ieviešanas artefakti padara `x % y` nederīgu `MIN / -1` parakstītam tipam (kur `MIN` ir negatīvā minimālā vērtība).
        ///
        /// Šādā gadījumā šī funkcija atgriež `0`.
        ///
        /// # Panics
        ///
        /// Šī funkcija būs panic, ja `rhs` ir 0.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem(-1), 0);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self.overflowing_rem(rhs).0
        }

        /// Eiklida atlikuma iesaiņošana.Aprēķina `self.rem_euclid(rhs)`, aptinoties pie tipa robežas.
        ///
        /// Iesaiņošana `MIN % -1` notiks tikai ar parakstītu tipu (kur `MIN` ir tipa negatīvā minimālā vērtība).
        /// Šajā gadījumā šī metode atgriež 0.
        ///
        /// # Panics
        ///
        /// Šī funkcija būs panic, ja `rhs` ir 0.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem_euclid(-1), 0);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self.overflowing_rem_euclid(rhs).0
        }

        /// (modular) negācijas iesaiņošana.Aprēķina `-self`, aptinoties pie tipa robežas.
        ///
        /// Vienīgais gadījums, kad šāda iesaiņošana var notikt, ir tas, ka `MIN` tiek noraidīts uz parakstītu tipu (kur `MIN` ir tipa negatīvā minimālā vērtība);šī ir pozitīva vērtība, kas ir pārāk liela, lai to attēlotu tipā.
        /// Šādā gadījumā šī funkcija atgriež `MIN` pati.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_neg(), -100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_neg(), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic bez bitu kustības pa kreisi;iegūst `self << mask(rhs)`, kur `mask` noņem visus augstas kārtas `rhs` bitus, kuru dēļ nobīde pārsniegtu veida bitu platumu.
        ///
        /// Ņemiet vērā, ka tas *nav* tas pats, kas pagriezt pa kreisi;ietīšanas kreisās puses RHS ir ierobežots ar tipa diapazonu, nevis no LHS pārvietotie biti tiek atgriezti otrā galā.
        ///
        /// Visi primitīvie veselu skaitļu tipi īsteno [`rotate_left`](Self::rotate_left) funkciju, kas var būt tā, ko jūs vēlaties.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(7), -128);")]
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(128), -1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // DROŠĪBA: maskēšana ar tipa bitsiju nodrošina, ka mēs nemaināmies
            // ārpus robežas
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic bez bitu kustības pa labi;iegūst `self >> mask(rhs)`, kur `mask` noņem visus augstas kārtas `rhs` bitus, kuru dēļ nobīde pārsniegtu veida bitu platumu.
        ///
        /// Ņemiet vērā, ka tas *nav* tas pats, kas pagriezt pa labi;ietīšanas labās puses RHS ir ierobežots ar tipa diapazonu, nevis no LHS pārvietotie biti tiek atgriezti otrā galā.
        ///
        /// Visi primitīvie veselu skaitļu tipi īsteno [`rotate_right`](Self::rotate_right) funkciju, kas var būt tā, ko jūs vēlaties.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-128", stringify!($SelfT), ").wrapping_shr(7), -1);")]
        /// assert_eq!((-128i16).wrapping_shr(64), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // DROŠĪBA: maskēšana ar tipa bitsiju nodrošina, ka mēs nemaināmies
            // ārpus robežas
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// (modular) absolūtās vērtības ietīšana.Aprēķina `self.abs()`, aptinoties pie tipa robežas.
        ///
        /// Vienīgais gadījums, kad šāda iesaiņošana var notikt, ir tad, kad tiek ņemta tipa negatīvās minimālās vērtības absolūtā vērtība;šī ir pozitīva vērtība, kas ir pārāk liela, lai to attēlotu tipā.
        /// Šādā gadījumā šī funkcija atgriež `MIN` pati.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_abs(), ", stringify!($SelfT), "::MIN);")]
        /// assert_eq!((-128i8).wrapping_abs() as u8, 128);
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        pub const fn wrapping_abs(self) -> Self {
             if self.is_negative() {
                 self.wrapping_neg()
             } else {
                 self
             }
        }

        /// Aprēķina `self` absolūto vērtību bez ietīšanas un panikas.
        ///
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        /// assert_eq!((-128i8).unsigned_abs(), 128u8);
        /// ```
        #[stable(feature = "unsigned_abs", since = "1.51.0")]
        #[rustc_const_stable(feature = "unsigned_abs", since = "1.51.0")]
        #[inline]
        pub const fn unsigned_abs(self) -> $UnsignedT {
             self.wrapping_abs() as $UnsignedT
        }

        /// (modular) eksponences iesaiņošana.
        /// Aprēķina `self.pow(exp)`, aptinoties pie tipa robežas.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(4), 81);")]
        /// assert_eq!(3i8.wrapping_pow(5), -13);
        /// assert_eq!(3i8.wrapping_pow(6), -39);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // tā kā exp!=0, visbeidzot, exp jābūt 1.
            // Ar eksponenta pēdējo bitu rīkojieties atsevišķi, jo pamatnes kvadrātišana pēc tam nav nepieciešama un var izraisīt nevajadzīgu pārplūdi.
            //
            //
            acc.wrapping_mul(base)
        }

        /// Aprēķina `self` + `rhs`
        ///
        /// Atgriež pievienojuma kopu kopā ar būla skaitli, kas norāda, vai notiks aritmētiska pārpilde.
        /// Ja būtu notikusi pārpilde, tad atgrieztā vērtība tiek atgriezta.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Aprēķina `self`, `rhs`
        ///
        /// Atgriež atņemšanas kopu kopā ar būla skaitli, kas norāda, vai notiks aritmētiska pārpilde.
        /// Ja būtu notikusi pārpilde, tad atgrieztā vērtība tiek atgriezta.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Aprēķina `self` un `rhs` reizinājumu.
        ///
        /// Atgriež reizināšanas reizinājumu kopā ar būla skaitli, kas norāda, vai notiks aritmētiska pārpilde.
        /// Ja būtu notikusi pārpilde, tad atgrieztā vērtība tiek atgriezta.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_mul(2), (10, false));")]
        /// assert_eq!(1_000_000_000i32.overflowing_mul(10), (1410065408, taisnība));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Aprēķina dalītāju, kad `self` dala ar `rhs`.
        ///
        /// Atgriež dalītāja kopu kopā ar būla skaitli, kas norāda, vai notiks aritmētiska pārpilde.
        /// Ja notiktu pārplūde, pats tiek atgriezts.
        ///
        /// # Panics
        ///
        /// Šī funkcija būs panic, ja `rhs` ir 0.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self / rhs, false)
            }
        }

        /// Aprēķina Eiklida dalījuma `self.div_euclid(rhs)` koeficientu.
        ///
        /// Atgriež dalītāja kopu kopā ar būla skaitli, kas norāda, vai notiks aritmētiska pārpilde.
        /// Ja notiktu pārplūde, `self` tiek atgriezts.
        ///
        /// # Panics
        ///
        /// Šī funkcija būs panic, ja `rhs` ir 0.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div_euclid(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self.div_euclid(rhs), false)
            }
        }

        /// Aprēķina atlikumu, kad `self` dala ar `rhs`.
        ///
        /// Pēc dalīšanas kopā ar būla skaitli atgriež atlikuma kopu, norādot, vai notiks aritmētiska pārpilde.
        /// Ja notiktu pārplūde, 0 tiek atgriezta.
        ///
        /// # Panics
        ///
        /// Šī funkcija būs panic, ja `rhs` ir 0.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem(-1), (0, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self % rhs, false)
            }
        }


        /// Pārpildīta eiklīda atlikums.Aprēķina `self.rem_euclid(rhs)`.
        ///
        /// Pēc dalīšanas kopā ar būla skaitli atgriež atlikuma kopu, norādot, vai notiks aritmētiska pārpilde.
        /// Ja notiktu pārplūde, 0 tiek atgriezta.
        ///
        /// # Panics
        ///
        /// Šī funkcija būs panic, ja `rhs` ir 0.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem_euclid(-1), (0, true));")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self.rem_euclid(rhs), false)
            }
        }


        /// Negatīvs pats par sevi, pārpildīts, ja tas ir vienāds ar minimālo vērtību.
        ///
        /// Atgriež sevis noliegtās versijas kopu kopā ar būla skaitli, kas norāda, vai ir notikusi pārpilde.
        /// Ja `self` ir minimālā vērtība (piem., `i32::MIN` `i32` tipa vērtībām), tad minimālā vērtība tiks atgriezta atkal un `true` tiks atgriezta, ja notiek pārplūde.
        ///
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_neg(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            if unlikely!(self == Self::MIN) {
                (Self::MIN, true)
            } else {
                (-self, false)
            }
        }

        /// Pārslēdz sevi, ko atstāj `rhs` biti.
        ///
        /// Atgriež sevis pārvietotās versijas kopu kopā ar būla skaitli, kas norāda, vai nobīdes vērtība bija lielāka vai vienāda ar bitu skaitu.
        /// Ja nobīdes vērtība ir pārāk liela, vērtība tiek maskēta ar (N-1), kur N ir bitu skaits, un pēc tam šo vērtību izmanto, lai veiktu nobīdi.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT),".overflowing_shl(4), (0x10, false));")]
        /// assert_eq!(0x1i32.overflowing_shl(36), (0x10, taisnība));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// Pārslēdzas pa labi ar `rhs` bitiem.
        ///
        /// Atgriež sevis pārvietotās versijas kopu kopā ar būla skaitli, kas norāda, vai nobīdes vērtība bija lielāka vai vienāda ar bitu skaitu.
        /// Ja nobīdes vērtība ir pārāk liela, vērtība tiek maskēta ar (N-1), kur N ir bitu skaits, un pēc tam šo vērtību izmanto, lai veiktu nobīdi.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        /// assert_eq!(0x10i32.overflowing_shr(36), (0x1, taisnība));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// Aprēķina `self` absolūto vērtību.
        ///
        /// Atgriež sevis absolūtās versijas kopu kopā ar būla skaitli, kas norāda, vai ir notikusi pārpilde.
        /// Ja pats ir minimālā vērtība
        #[doc = concat!("(e.g., ", stringify!($SelfT), "::MIN for values of type ", stringify!($SelfT), "),")]
        /// tad minimālā vērtība tiks atgriezta vēlreiz, un patiesā vērtība tiks atgriezta, ja notiek pārpilde.
        ///
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN).overflowing_abs(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn overflowing_abs(self) -> (Self, bool) {
            (self.wrapping_abs(), self == Self::MIN)
        }

        /// Paaugstina sevi līdz `exp` jaudai, izmantojot eksponenci kvadrātā.
        ///
        /// Atgriež eksponences kopu kopā ar bool, norādot, vai notikusi pārpilde.
        ///
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(4), (81, false));")]
        /// assert_eq!(3i8.overflowing_pow(5), (-13, taisnība));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0 {
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Scratch space overflowing_mul rezultātu uzglabāšanai.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // tā kā exp!=0, visbeidzot, exp jābūt 1.
            // Ar eksponenta pēdējo bitu rīkojieties atsevišķi, jo pamatnes kvadrātišana pēc tam nav nepieciešama un var izraisīt nevajadzīgu pārplūdi.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;
            r
        }

        /// Paaugstina sevi līdz `exp` jaudai, izmantojot eksponenci kvadrātā.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        #[doc = concat!("let x: ", stringify!($SelfT), " = 2; // or any other integer type")]
        /// assert_eq!(x.pow(5), 32);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // tā kā exp!=0, visbeidzot, exp jābūt 1.
            // Ar eksponenta pēdējo bitu rīkojieties atsevišķi, jo pamatnes kvadrātišana pēc tam nav nepieciešama un var izraisīt nevajadzīgu pārplūdi.
            //
            //
            acc * base
        }

        /// Aprēķina `self` Eiklida dalījuma ar `rhs` koeficientu.
        ///
        /// Tas aprēķina veselu skaitli `n` tā, lai `self = n * rhs + self.rem_euclid(rhs)`, ar `0 <= self.rem_euclid(rhs) < rhs`.
        ///
        ///
        /// Citiem vārdiem sakot, rezultāts tiek `self / rhs` noapaļots līdz veselam skaitlim `n` tā, lai `self >= n * rhs`.
        /// Ja `self > 0`, tas ir vienāds ar apaļo pret nulli (noklusējums Rust);
        /// ja `self < 0`, tas ir vienāds ar apaļu virzienā uz +/-bezgalību.
        ///
        /// # Panics
        ///
        /// Šī funkcija būs panic, ja `rhs` ir 0 vai sadalīšana rada pārplūdi.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// ļaujiet b=4;
        ///
        /// assert_eq!(a.div_euclid(b), 1); //7>=4 *1 assert_eq!(a.div_euclid(-b), -1);//7>= -4*-1 assert_eq!((-a).div_euclid(b), -2);-7>=4 *-2 assert_eq!((-a).div_euclid(-b), 2);//-7>= -4* 2
        ///
        /// ```
        ///
        ///
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            let q = self / rhs;
            if self % rhs < 0 {
                return if rhs > 0 { q - 1 } else { q + 1 }
            }
            q
        }


        /// Aprēķina vismazāk negatīvo negatīvo `self (mod rhs)` atlikumu.
        ///
        /// Tas tiek darīts tā, it kā ar Eiklida dalīšanas algoritmu-dotu `r = self.rem_euclid(rhs)`, `self = rhs * self.div_euclid(rhs) + r` un `0 <= r < abs(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Šī funkcija būs panic, ja `rhs` ir 0 vai sadalīšana rada pārplūdi.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// ļaujiet b=4;
        ///
        /// assert_eq!(a.rem_euclid(b), 3);
        /// assert_eq!((-a).rem_euclid(b), 1);
        /// assert_eq!(a.rem_euclid(-b), 3);
        /// assert_eq!((-a).rem_euclid(-b), 1);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            let r = self % rhs;
            if r < 0 {
                if rhs < 0 {
                    r - rhs
                } else {
                    r + rhs
                }
            } else {
                r
            }
        }

        /// Aprēķina `self` absolūto vērtību.
        ///
        /// # Pārplūdes uzvedība
        ///
        /// Absolūtā vērtība
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// nevar attēlot kā
        #[doc = concat!("`", stringify!($SelfT), "`,")]
        /// un mēģinājums to aprēķināt izraisīs pārplūdi.
        /// Tas nozīmē, ka kods atkļūdošanas režīmā šajā gadījumā aktivizēs panic un atgriezīsies optimizētais kods
        ///
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// bez panic.
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".abs(), 10);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").abs(), 10);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn abs(self) -> Self {
            // Ņemiet vērā, ka iepriekšminētais#[inline] nozīmē, ka atņemšanas pārpildes semantika ir atkarīga no crate, kurā mēs esam iekļauti.
            //
            //
            if self.is_negative() {
                -self
            } else {
                self
            }
        }

        /// Atgriež skaitli, kas apzīmē `self` zīmi.
        ///
        ///  - `0` ja skaitlis ir nulle
        ///  - `1` ja skaitlis ir pozitīvs
        ///  - `-1` ja skaitlis ir negatīvs
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".signum(), 1);")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".signum(), 0);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").signum(), -1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_sign", since = "1.47.0")]
        #[inline]
        pub const fn signum(self) -> Self {
            match self {
                n if n > 0 =>  1,
                0          =>  0,
                _          => -1,
            }
        }

        /// Atgriež vērtību `true`, ja `self` ir pozitīvs, un `false`, ja skaitlis ir nulle vai negatīvs.
        ///
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        #[doc = concat!("assert!(10", stringify!($SelfT), ".is_positive());")]
        #[doc = concat!("assert!(!(-10", stringify!($SelfT), ").is_positive());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_positive(self) -> bool { self > 0 }

        /// Atgriež vērtību `true`, ja `self` ir negatīvs, un `false`, ja skaitlis ir nulle vai pozitīvs.
        ///
        ///
        /// # Examples
        ///
        /// Pamata lietojums:
        ///
        /// ```
        #[doc = concat!("assert!((-10", stringify!($SelfT), ").is_negative());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_negative());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_negative(self) -> bool { self < 0 }

        /// Atgrieziet šī vesela skaitļa atmiņas attēlojumu kā baitu masīvu lielā endiāna (network) baitu secībā.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Atgrieziet šī vesela skaitļa atmiņas attēlojumu kā baitu masīvu mazo endiātu baitu secībā.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Atgrieziet šī vesela skaitļa atmiņas attēlojumu kā baitu masīvu vietējo baitu secībā.
        ///
        /// Tā kā tiek izmantota mērķa platformas dzimtā endianitāte, portatīvā koda vietā tā vietā vajadzētu izmantot [`to_be_bytes`] vai [`to_le_bytes`].
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     baiti, ja cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } cits
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // DROŠĪBA: konst skaņa, jo veseli skaitļi ir vienkārši veci datu tipi, tāpēc mēs vienmēr varam
        // pārveidojiet tos baitu masīvos
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // DROŠĪBA: veseli skaitļi ir vienkārši veci datu tipi, tāpēc mēs vienmēr varam tos pārveidot
            // baitu masīvi
            unsafe { mem::transmute(self) }
        }

        /// Atgrieziet šī vesela skaitļa atmiņas attēlojumu kā baitu masīvu vietējo baitu secībā.
        ///
        ///
        /// [`to_ne_bytes`] jādod priekšroka salīdzinājumā ar šo, kad vien iespējams.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// ļaut baitus= num.as_ne_bytes();
        /// assert_eq!(
        ///     baiti, ja cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } cits
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // DROŠĪBA: veseli skaitļi ir vienkārši veci datu tipi, tāpēc mēs vienmēr varam tos pārveidot
            // baitu masīvi
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Izveidojiet veselu skaitli no tā attēlojuma kā baitu masīvu lielajā endiānā.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// izmantot std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * ievade=atpūta;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Izveidojiet veselu skaitli no tā attēlojuma kā baitu masīvu mazajā endiānā.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// izmantot std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * ievade=atpūta;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Izveidojiet vesela skaitļa vērtību no tā atmiņas attēlojuma kā baitu masīvu vietējā endiānā.
        ///
        /// Tā kā tiek izmantota mērķa platformas dzimtā endianitāte, portatīvais kods, visticamāk, tā vietā vēlas izmantot [`from_be_bytes`] vai [`from_le_bytes`].
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes)]
        /// } cits
        #[doc = concat!("    ", $le_bytes)]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// izmantot std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * ievade=atpūta;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // DROŠĪBA: konst skaņa, jo veseli skaitļi ir vienkārši veci datu tipi, tāpēc mēs vienmēr varam
        // pārvērst viņiem
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // DROŠĪBA: veseli skaitļi ir vienkārši veci datu tipi, tāpēc mēs vienmēr varam tos pārveidot
            unsafe { mem::transmute(bytes) }
        }

        /// Jaunajam kodam vajadzētu dot priekšroku
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Atgriež mazāko vērtību, ko var attēlot ar šo vesela skaitļa tipu.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_min_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self {
            Self::MIN
        }

        /// Jaunajam kodam vajadzētu dot priekšroku
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Atgriež lielāko vērtību, ko var attēlot ar šī vesela skaitļa tipu.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self {
            Self::MAX
        }
    }
}