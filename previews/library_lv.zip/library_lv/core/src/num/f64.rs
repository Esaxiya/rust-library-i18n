//! Konstantes, kas raksturīgas `f64` dubultprecizitātes peldošā komata tipam.
//!
//! *[See also the `f64` primitive type][f64].*
//!
//! Matemātiski nozīmīgi skaitļi ir norādīti `consts` apakšmodulī.
//!
//! Konstantēm, kas tieši definētas šajā modulī (atšķirībā no tām, kas definētas `consts` apakšmodulī), jaunajam kodam tā vietā jāizmanto saistītās konstantes, kas definētas tieši `f64` tipam.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// `f64` iekšējā attēla radikss vai pamats.
/// Tā vietā izmantojiet [`f64::RADIX`].
///
/// # Examples
///
/// ```rust
/// // novecojis veids
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f64::RADIX;
///
/// // paredzētajā veidā
/// let r = f64::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f64`")]
pub const RADIX: u32 = f64::RADIX;

/// Nozīmīgo ciparu skaits 2. bāzē.
/// Tā vietā izmantojiet [`f64::MANTISSA_DIGITS`].
///
/// # Examples
///
/// ```rust
/// // novecojis veids
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f64::MANTISSA_DIGITS;
///
/// // paredzētajā veidā
/// let d = f64::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f64`"
)]
pub const MANTISSA_DIGITS: u32 = f64::MANTISSA_DIGITS;

/// Aptuvenais nozīmīgo ciparu skaits 10. bāzē.
/// Tā vietā izmantojiet [`f64::DIGITS`].
///
/// # Examples
///
/// ```rust
/// // novecojis veids
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f64::DIGITS;
///
/// // paredzētajā veidā
/// let d = f64::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f64`")]
pub const DIGITS: u32 = f64::DIGITS;

/// [Machine epsilon] `f64` vērtība.
/// Tā vietā izmantojiet [`f64::EPSILON`].
///
/// Šī ir atšķirība starp `1.0` un nākamo lielāko attēlojamo skaitli.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // novecojis veids
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f64::EPSILON;
///
/// // paredzētajā veidā
/// let e = f64::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f64`"
)]
pub const EPSILON: f64 = f64::EPSILON;

/// Mazākā ierobežotā `f64` vērtība.
/// Tā vietā izmantojiet [`f64::MIN`].
///
/// # Examples
///
/// ```rust
/// // novecojis veids
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN;
///
/// // paredzētajā veidā
/// let min = f64::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f64`")]
pub const MIN: f64 = f64::MIN;

/// Mazākā pozitīvā normālā `f64` vērtība.
/// Tā vietā izmantojiet [`f64::MIN_POSITIVE`].
///
/// # Examples
///
/// ```rust
/// // novecojis veids
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_POSITIVE;
///
/// // paredzētajā veidā
/// let min = f64::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f64`"
)]
pub const MIN_POSITIVE: f64 = f64::MIN_POSITIVE;

/// Lielākā ierobežotā `f64` vērtība.
/// Tā vietā izmantojiet [`f64::MAX`].
///
/// # Examples
///
/// ```rust
/// // novecojis veids
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX;
///
/// // paredzētajā veidā
/// let max = f64::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f64`")]
pub const MAX: f64 = f64::MAX;

/// Viens lielāks par minimālo iespējamo 2 eksponenta normālo jaudu.
/// Tā vietā izmantojiet [`f64::MIN_EXP`].
///
/// # Examples
///
/// ```rust
/// // novecojis veids
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_EXP;
///
/// // paredzētajā veidā
/// let min = f64::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f64`"
)]
pub const MIN_EXP: i32 = f64::MIN_EXP;

/// Maksimālā iespējamā 2 eksponenta jauda.
/// Tā vietā izmantojiet [`f64::MAX_EXP`].
///
/// # Examples
///
/// ```rust
/// // novecojis veids
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX_EXP;
///
/// // paredzētajā veidā
/// let max = f64::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f64`"
)]
pub const MAX_EXP: i32 = f64::MAX_EXP;

/// Minimālā iespējamā 10 eksponenta normālā jauda.
/// Tā vietā izmantojiet [`f64::MIN_10_EXP`].
///
/// # Examples
///
/// ```rust
/// // novecojis veids
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_10_EXP;
///
/// // paredzētajā veidā
/// let min = f64::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f64`"
)]
pub const MIN_10_EXP: i32 = f64::MIN_10_EXP;

/// Maksimālā iespējamā 10 eksponenta jauda.
/// Tā vietā izmantojiet [`f64::MAX_10_EXP`].
///
/// # Examples
///
/// ```rust
/// // novecojis veids
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX_10_EXP;
///
/// // paredzētajā veidā
/// let max = f64::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f64`"
)]
pub const MAX_10_EXP: i32 = f64::MAX_10_EXP;

/// Nav skaitlis (NaN).
/// Tā vietā izmantojiet [`f64::NAN`].
///
/// # Examples
///
/// ```rust
/// // novecojis veids
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f64::NAN;
///
/// // paredzētajā veidā
/// let nan = f64::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f64`")]
pub const NAN: f64 = f64::NAN;

/// Infinity (∞).
/// Tā vietā izmantojiet [`f64::INFINITY`].
///
/// # Examples
///
/// ```rust
/// // novecojis veids
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f64::INFINITY;
///
/// // paredzētajā veidā
/// let inf = f64::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f64`"
)]
pub const INFINITY: f64 = f64::INFINITY;

/// Negatīva bezgalība (−∞).
/// Tā vietā izmantojiet [`f64::NEG_INFINITY`].
///
/// # Examples
///
/// ```rust
/// // novecojis veids
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f64::NEG_INFINITY;
///
/// // paredzētajā veidā
/// let ninf = f64::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f64`"
)]
pub const NEG_INFINITY: f64 = f64::NEG_INFINITY;

/// Matemātiskās konstantes.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: aizstāt ar matemātiskām konstantām no cmath.

    /// Arhimēda konstante (π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f64 = 3.14159265358979323846264338327950288_f64;

    /// Pilna apļa konstante (τ)
    ///
    /// Vienāds ar 2π.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f64 = 6.28318530717958647692528676655900577_f64;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f64 = 1.57079632679489661923132169163975144_f64;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f64 = 1.04719755119659774615421446109316763_f64;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f64 = 0.785398163397448309615660845819875721_f64;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f64 = 0.52359877559829887307710723054658381_f64;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f64 = 0.39269908169872415480783042290993786_f64;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f64 = 0.318309886183790671537767526745028724_f64;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f64 = 0.636619772367581343075535053490057448_f64;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f64 = 1.12837916709551257389615890312154517_f64;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f64 = 1.41421356237309504880168872420969808_f64;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f64 = 0.707106781186547524400844362104849039_f64;

    /// Eulera numurs (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f64 = 2.71828182845904523536028747135266250_f64;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f64 = 3.32192809488736234787031942948939018_f64;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f64 = 1.44269504088896340735992468100189214_f64;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f64 = 0.301029995663981195213738894724493027_f64;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f64 = 0.434294481903251827651128918916605082_f64;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f64 = 0.693147180559945309417232121458176568_f64;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f64 = 2.30258509299404568401799145468436421_f64;
}

#[lang = "f64"]
#[cfg(not(test))]
impl f64 {
    /// `f64` iekšējā attēla radikss vai pamats.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// Nozīmīgo ciparu skaits 2. bāzē.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 53;
    /// Aptuvenais nozīmīgo ciparu skaits 10. bāzē.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 15;

    /// [Machine epsilon] `f64` vērtība.
    ///
    /// Šī ir atšķirība starp `1.0` un nākamo lielāko attēlojamo skaitli.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f64 = 2.2204460492503131e-16_f64;

    /// Mazākā ierobežotā `f64` vērtība.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f64 = -1.7976931348623157e+308_f64;
    /// Mazākā pozitīvā normālā `f64` vērtība.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f64 = 2.2250738585072014e-308_f64;
    /// Lielākā ierobežotā `f64` vērtība.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f64 = 1.7976931348623157e+308_f64;

    /// Viens lielāks par minimālo iespējamo 2 eksponenta normālo jaudu.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -1021;
    /// Maksimālā iespējamā 2 eksponenta jauda.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 1024;

    /// Minimālā iespējamā 10 eksponenta normālā jauda.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -307;
    /// Maksimālā iespējamā 10 eksponenta jauda.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 308;

    /// Nav skaitlis (NaN).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f64 = 0.0_f64 / 0.0_f64;
    /// Infinity (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f64 = 1.0_f64 / 0.0_f64;
    /// Negatīva bezgalība (−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f64 = -1.0_f64 / 0.0_f64;

    /// Atgriež vērtību `true`, ja šī vērtība ir `NaN`.
    ///
    /// ```
    /// let nan = f64::NAN;
    /// let f = 7.0_f64;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): `abs` nav publiski pieejams libcore, jo pastāv bažas par pārnesamību, tāpēc šī ieviešana ir paredzēta privātai lietošanai iekšēji.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f64 {
        f64::from_bits(self.to_bits() & 0x7fff_ffff_ffff_ffff)
    }

    /// Atgriež vērtību `true`, ja šī vērtība ir pozitīva bezgalība vai negatīva bezgalība, un citādi `false`.
    ///
    ///
    /// ```
    /// let f = 7.0f64;
    /// let inf = f64::INFINITY;
    /// let neg_inf = f64::NEG_INFINITY;
    /// let nan = f64::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// Atgriež `true`, ja šis skaitlis nav ne bezgalīgs, ne `NaN`.
    ///
    /// ```
    /// let f = 7.0f64;
    /// let inf: f64 = f64::INFINITY;
    /// let neg_inf: f64 = f64::NEG_INFINITY;
    /// let nan: f64 = f64::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // Nav nepieciešams atsevišķi rīkoties ar NaN: ja pats esmu NaN, salīdzinājums nav patiess, tieši tā, kā vēlaties.
        //
        self.abs_private() < Self::INFINITY
    }

    /// Atgriež vērtību `true`, ja skaitlis ir [subnormal].
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f64::MIN_POSITIVE; // 2.2250738585072014e-308_f64
    /// let max = f64::MAX;
    /// let lower_than_min = 1.0e-308_f64;
    /// let zero = 0.0_f64;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f64::NAN.is_subnormal());
    /// assert!(!f64::INFINITY.is_subnormal());
    /// // Vērtības starp `0` un `min` ir nenormālas.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// Atgriež vērtību `true`, ja skaitlis nav nulle, bezgalīgs, [subnormal] vai `NaN`.
    ///
    ///
    /// ```
    /// let min = f64::MIN_POSITIVE; // 2.2250738585072014e-308f64
    /// let max = f64::MAX;
    /// let lower_than_min = 1.0e-308_f64;
    /// let zero = 0.0f64;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f64::NAN.is_normal());
    /// assert!(!f64::INFINITY.is_normal());
    /// // Vērtības starp `0` un `min` ir nenormālas.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// Atgriež skaitļa peldošā komata kategoriju.
    /// Ja tiks pārbaudīts tikai viens rekvizīts, tā vietā parasti ir ātrāk izmantot konkrēto predikātu.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f64;
    /// let inf = f64::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u64 = 0x7ff0000000000000;
        const MAN_MASK: u64 = 0x000fffffffffffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// Atgriež `true`, ja `self` ir pozitīva zīme, ieskaitot `+0.0`, `NaN` ar pozitīvas zīmes bitu un pozitīvu bezgalību.
    ///
    ///
    /// ```
    /// let f = 7.0_f64;
    /// let g = -7.0_f64;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.0.0", reason = "renamed to is_sign_positive")]
    #[inline]
    #[doc(hidden)]
    pub fn is_positive(self) -> bool {
        self.is_sign_positive()
    }

    /// Atgriež `true`, ja `self` ir negatīva zīme, ieskaitot `-0.0`, `NaN`s ar negatīvu zīmes bitu un negatīvu bezgalību.
    ///
    ///
    /// ```
    /// let f = 7.0_f64;
    /// let g = -7.0_f64;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        self.to_bits() & 0x8000_0000_0000_0000 != 0
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.0.0", reason = "renamed to is_sign_negative")]
    #[inline]
    #[doc(hidden)]
    pub fn is_negative(self) -> bool {
        self.is_sign_negative()
    }

    /// Ņem skaitļa abpusējo (inverse), `1/x`.
    ///
    /// ```
    /// let x = 2.0_f64;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f64 {
        1.0 / self
    }

    /// Pārvērš radiānus grādos.
    ///
    /// ```
    /// let angle = std::f64::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_degrees(self) -> f64 {
        // Sadalījums šeit ir pareizi noapaļots attiecībā pret patieso vērtību 180/π.
        // (Tas atšķiras no f32, kur, lai nodrošinātu pareizi noapaļotu rezultātu, ir jāizmanto konstante.)
        //
        self * (180.0f64 / consts::PI)
    }

    /// Pārvērš grādus par radiāniem.
    ///
    /// ```
    /// let angle = 180.0_f64;
    ///
    /// let abs_difference = (angle.to_radians() - std::f64::consts::PI).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_radians(self) -> f64 {
        let value: f64 = consts::PI;
        self * (value / 180.0)
    }

    /// Atgriež divu skaitļu maksimumu.
    ///
    /// ```
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// Ja viens no argumentiem ir NaN, tiek atgriezts otrs arguments.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f64) -> f64 {
        intrinsics::maxnumf64(self, other)
    }

    /// Atgriež divu skaitļu minimumu.
    ///
    /// ```
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// Ja viens no argumentiem ir NaN, tiek atgriezts otrs arguments.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f64) -> f64 {
        intrinsics::minnumf64(self, other)
    }

    /// Riņķo uz nulli un pārveido par jebkuru primitīvu vesela skaitļa tipu, pieņemot, ka vērtība ir ierobežota un iekļaujas šajā tipā.
    ///
    ///
    /// ```
    /// let value = 4.6_f64;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f64;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// Vērtībai jābūt:
    ///
    /// * Neesi `NaN`
    /// * Neesi bezgalīgs
    /// * Esiet reprezentabls atgriešanās tipā `Int`, pēc tā daļas saīsināšanas
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // DROŠĪBA: zvanītājam jāievēro `FloatToInt::to_int_unchecked` drošības līgums.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// Neapstrādāta transmutācija uz `u64`.
    ///
    /// Pašlaik tas ir identisks `transmute::<f64, u64>(self)` visās platformās.
    ///
    /// Skatiet `from_bits`, lai apspriestu šīs operācijas pārnesamību (gandrīz nav problēmu).
    ///
    /// Ņemiet vērā, ka šī funkcija atšķiras no `as` apraides, kas mēģina saglabāt vērtību *ciparu*, nevis vērtību bitiem.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((1f64).to_bits() != 1f64 as u64); // to_bits() nav liešana!
    /// assert_eq!((12.5f64).to_bits(), 0x4029000000000000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u64 {
        // DROŠĪBA: `u64` ir vienkāršs vecs datu tips, tāpēc mēs vienmēr varam to pārveidot
        unsafe { mem::transmute(self) }
    }

    /// Neapstrādāta transmutācija no `u64`.
    ///
    /// Pašlaik tas ir identisks `transmute::<u64, f64>(v)` visās platformās.
    /// Izrādās, ka tas ir neticami pārnēsājams divu iemeslu dēļ:
    ///
    /// * Pludiņiem un Intiem ir vienāds endianitāte uz visām atbalstītajām platformām.
    /// * IEEE-754 ļoti precīzi nosaka pludiņu bitu izkārtojumu.
    ///
    /// Tomēr ir viens brīdinājums: pirms IEEE-754 2008. gada versijas faktiski netika norādīts, kā interpretēt NaN signalizācijas bitu.
    /// Lielākā daļa platformu (īpaši x86 un ARM) izvēlējās interpretāciju, kas galu galā tika standartizēta 2008. gadā, bet dažas to nedarīja (īpaši MIPS).
    /// Rezultātā visi signalizējošie NaN uz MIPS ir klusie NaN uz x86 un otrādi.
    ///
    /// Tā vietā, lai mēģinātu saglabāt signalizācijas trūkumu starpplatformā, šī ieviešana dod priekšroku precīzu bitu saglabāšanai.
    /// Tas nozīmē, ka visas lietderīgās kravas, kas kodētas NaN, tiks saglabātas pat tad, ja šīs metodes rezultāts tiks nosūtīts pa tīklu no x86 mašīnas uz MIPS.
    ///
    ///
    /// Ja šīs metodes rezultātus manipulē tikai tā pati arhitektūra, kas tos izstrādājusi, tad pārnesamība nav saistīta.
    ///
    /// Ja ievade nav NaN, tad nav problēmu par pārnesamību.
    ///
    /// Ja jums vienalga par signalizēšanu (ļoti iespējams), tad pārnesamība neuztraucas.
    ///
    /// Ņemiet vērā, ka šī funkcija atšķiras no `as` apraides, kas mēģina saglabāt vērtību *ciparu*, nevis vērtību bitiem.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f64::from_bits(0x4029000000000000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u64) -> Self {
        // DROŠĪBA: `u64` ir vienkāršs vecs datu tips, tāpēc mēs vienmēr varam to pārveidot
        // Izrādās, drošības jautājumi ar sNaN bija pārspīlēti!Urā!
        unsafe { mem::transmute(v) }
    }

    /// Atgrieziet šī peldošā komata skaitļa atmiņas attēlojumu kā baitu masīvu lielā endiāna (network) baitu secībā.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_be_bytes();
    /// assert_eq!(bytes, [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 8] {
        self.to_bits().to_be_bytes()
    }

    /// Atgrieziet šī peldošā komata skaitļa atmiņas attēlojumu kā baitu masīvu mazo endiātu baitu secībā.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 8] {
        self.to_bits().to_le_bytes()
    }

    /// Atgrieziet šī peldošā komata skaitļa atmiņas attēlojumu kā baitu masīvu vietējā baitu secībā.
    ///
    /// Tā kā tiek izmantota mērķa platformas dzimtā endianitāte, portatīvā koda vietā tā vietā vajadzētu izmantot [`to_be_bytes`] vai [`to_le_bytes`].
    ///
    ///
    /// [`to_be_bytes`]: f64::to_be_bytes
    /// [`to_le_bytes`]: f64::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 8] {
        self.to_bits().to_ne_bytes()
    }

    /// Atgrieziet šī peldošā komata skaitļa atmiņas attēlojumu kā baitu masīvu vietējā baitu secībā.
    ///
    ///
    /// [`to_ne_bytes`] jādod priekšroka salīdzinājumā ar šo, kad vien iespējams.
    ///
    /// [`to_ne_bytes`]: f64::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f64;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 8] {
        // DROŠĪBA: `f64` ir vienkāršs vecs datu tips, tāpēc mēs vienmēr varam to pārveidot
        unsafe { &*(self as *const Self as *const _) }
    }

    /// Izveidojiet peldošā komata vērtību no tās attēlojuma kā baitu masīvu lielajā endiānā.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_be_bytes([0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_be_bytes(bytes))
    }

    /// Izveidojiet peldošā komata vērtību no tās attēlojuma kā baitu masīvu mazajā endiānā.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_le_bytes([0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_le_bytes(bytes))
    }

    /// Izveidojiet peldošā komata vērtību no tās attēlojuma kā baitu masīvu vietējā endiānā.
    ///
    /// Tā kā tiek izmantota mērķa platformas dzimtā endianitāte, portatīvais kods, visticamāk, tā vietā vēlas izmantot [`from_be_bytes`] vai [`from_le_bytes`].
    ///
    ///
    /// [`from_be_bytes`]: f64::from_be_bytes
    /// [`from_le_bytes`]: f64::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_ne_bytes(bytes))
    }

    /// Atgriež pasūtījumu starp sevi un citām vērtībām.
    /// Atšķirībā no standarta daļēja salīdzinājuma ar peldošā komata skaitļiem, šis salīdzinājums vienmēr rada pasūtījumu saskaņā ar totalOrder predikātu, kā noteikts IEEE 754 (2008. gada redakcija) peldošā komata standartā.
    /// Vērtības ir sakārtotas šādā secībā:
    /// - Negatīvs kluss NaN
    /// - Negatīvs signāls NaN
    /// - Negatīva bezgalība
    /// - Negatīvie skaitļi
    /// - Negatīvi subnormāli skaitļi
    /// - Negatīva nulle
    /// - Pozitīva nulle
    /// - Pozitīvi subnormāli skaitļi
    /// - Pozitīvi skaitļi
    /// - Pozitīva bezgalība
    /// - Pozitīvs signāls NaN
    /// - Pozitīvs kluss NaN
    ///
    /// Ņemiet vērā, ka šī funkcija ne vienmēr saskan ar `f64` ieviešanu [`PartialOrd`] un [`PartialEq`].Jo īpaši viņi negatīvo un pozitīvo nulli uzskata par vienādu, bet `total_cmp` ne.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f64,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f64::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f64::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f64::INFINITY, f64::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i64;
        let mut right = other.to_bits() as i64;

        // Negatīvu gadījumā apgrieziet visus bitus, izņemot zīmi, lai iegūtu līdzīgu izkārtojumu kā divu papildinājumu veseli skaitļi
        //
        // Kāpēc tas darbojas?IEEE 754 pludiņi sastāv no trim laukiem:
        // Paraksta bits, eksponents un mantissa.Eksponenta un mantisas lauku kopumam kopumā ir īpašība, ka to bitu secība ir vienāda ar skaitlisko lielumu, kur ir noteikts lielums.
        // Lielums parasti nav noteikts pēc NaN vērtībām, bet IEEE 754 totalOrder nosaka NaN vērtības arī pēc bitrindas.Tas noved pie kārtības, kas paskaidrota doc komentārā.
        // Tomēr lieluma attēlojums negatīvajiem un pozitīvajiem skaitļiem ir vienāds-atšķiras tikai zīmes bits.
        // Lai viegli salīdzinātu pludiņus kā parakstītus veselus skaitļus, negatīvu skaitļu gadījumā mums jāpārvērš eksponenta un mantissa biti.
        // Mēs efektīvi konvertējam skaitļus "two's complement" formā.
        //
        // Lai veiktu flipping, mēs uzbūvējam masku un XOR pret to.
        // Mēs bezzari aprēķinām "all-ones except for the sign bit" masku no negatīvi parakstītām vērtībām: ar labo novirzīšanas zīmi pagarina veselu skaitli, tāpēc mēs "fill" masku ar zīmes bitiem un pēc tam pārvēršam par neparakstīto, lai vēl vienu nulles bitu virzītu.
        //
        // Pozitīvās vērtības gadījumā maska ir visas nulles, tāpēc tas ir aizliegts.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 63) as u64) >> 1) as i64;
        right ^= (((right >> 63) as u64) >> 1) as i64;

        left.cmp(&right)
    }

    /// Ierobežojiet vērtību līdz noteiktam intervālam, ja vien tā nav NaN.
    ///
    /// Atgriež `max`, ja `self` ir lielāks par `max`, un `min`, ja `self` ir mazāks par `min`.
    /// Pretējā gadījumā tas atgriež `self`.
    ///
    /// Ņemiet vērā, ka šī funkcija atgriež NaN, ja sākotnējā vērtība bija arī NaN.
    ///
    /// # Panics
    ///
    /// Panics, ja `min > max`, `min` ir NaN vai `max` ir NaN.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f64).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f64).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f64).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f64::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f64, max: f64) -> f64 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}