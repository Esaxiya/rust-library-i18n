//! Grisu3 algoritma Rust adaptācija, kas aprakstīta "Peldošo punktu numuru ātrā un precīzā drukāšanā ar skaitļiem" [^ 1].
//! Tas izmanto apmēram 1 KB iepriekš aprēķinātas tabulas, un tas lielākoties ir ļoti ātrs.
//!
//! [^1]: Florian Loitsch.2010. Peldošā komata numuru ātrā drukāšana un
//!   precīzi ar veseliem skaitļiem.SIGPLAN Nav.45, 6 (2010. gada jūnijs), 233. - 243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// pamatojumu skatiet komentāros `format_shortest_opt`.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-i;e=4* i, 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f, e, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// Ņemot vērā `x > 0`, atgriež vērtību `(k, 10^k)`, kas `10^k <= x < 10^(k+1)`.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// Īsākā režīma ieviešana Grisu.
///
/// Tas atgriež `None`, ja citādi atgrieztu neprecīzu attēlojumu.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // mums nepieciešama vismaz trīs bitu papildu precizitāte

    // sāciet ar normalizētajām vērtībām ar kopīgo eksponentu
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // atrodiet jebkuru `cached = 10^minusk` tādu `ALPHA <= minusk + plus.e + 64 <= GAMMA`.
    // tā kā `plus` ir normalizēts, tas nozīmē `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`;
    // ņemot vērā mūsu izvēli `ALPHA` un `GAMMA`, tas `plus * cached` iekļauj `[4, 2^32)`.
    //
    // acīmredzami ir vēlams maksimizēt `GAMMA - ALPHA`, lai mums nebūtu vajadzīgas daudzas kešatmiņā esošās 10 jaudas, taču ir daži apsvērumi:
    //
    //
    // 1. mēs vēlamies saglabāt `floor(plus * cached)` `u32`, jo tam nepieciešams dārgs sadalījums.
    //    (no tā patiesībā nav iespējams izvairīties, precizitātes novērtēšanai nepieciešama atlikusī daļa.)
    // 2.
    // `floor(plus * cached)` atlikums atkārtoti tiek reizināts ar 10, un tam nevajadzētu pārplūst.
    //
    // pirmais dod `64 + GAMMA <= 32`, bet otrais dod `10 * 2^-ALPHA <= 2^64`;
    // -60 un -32 ir maksimālais diapazons ar šo ierobežojumu, un V8 tos arī izmanto.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // mēroga fps.tas dod maksimālo kļūdu 1 ulp (pierādīts no 5.1 teorēmas).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-faktiskais mīnus diapazons
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // virs `minus`, `v` un `plus` tiek *kvantēti* aproksimēti (kļūda <1 ulp).
    // tā kā mēs nezinām, ka kļūda ir pozitīva vai negatīva, mēs izmantojam divus tuvinājumus, kas izvietoti vienādi, un maksimālā kļūda ir 2 ulps.
    //
    // "unsafe region" ir liberāls intervāls, ko mēs sākotnēji ģenerējam.
    // "safe region" ir konservatīvs intervāls, kuru mēs pieņemam tikai.
    // mēs sākam ar pareizo repr nedrošajā reģionā un mēģinām atrast vistuvāko repr līdz `v`, kas atrodas arī drošajā reģionā.
    // ja nevaram, atsakāmies.
    //
    let plus1 = plus.f + 1;
    // ļaujiet plus0 = plus.f, 1;//tikai paskaidrojumam minus0 = minus.f + 1;//tikai skaidrojumam
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // kopīgs eksponents

    // sadaliet `plus1` neatņemamās un daļējās daļās.
    // neatņemamās daļas tiek garantētas, lai ietilptu u32, jo kešatmiņā saglabātā jauda garantē `plus < 2^32`, un precizētās prasības dēļ normalizētā `plus.f` vienmēr ir mazāka par `2^64 - 2^4`.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // aprēķiniet lielāko `10^max_kappa` ne vairāk kā `plus1` (tādējādi `plus1 < 10^(max_kappa+1)`).
    // šī ir `kappa` augšējā robeža zemāk.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // Teorēma 6.2: ja `k` ir lielākais vesels skaitlis st
    // `0 <= y mod 10^k <= y - x`,              tad `V = floor(y / 10^k) * 10^k` ir `[x, y]` un viens no īsākajiem attēlojumiem (ar minimālu nozīmīgu ciparu skaitu) šajā diapazonā.
    //
    //
    // atrodiet ciparu garumu `kappa` starp `(minus1, plus1)` saskaņā ar 6.2 teorēmu.
    // 6.2 teorēmu var pieņemt, lai izslēgtu `x`, tā vietā pieprasot `y mod 10^k < y - x`.
    // (piem., `x` =32000, `y` =32777; `kappa` =2, jo `y mod 10 ^ 3=777 <y, x=777`.) Algoritms paļaujas uz vēlāku verifikācijas fāzi, lai izslēgtu `y`.
    //
    let delta1 = plus1 - minus1;
    // ļaujiet delta1int=(delta1>> e) izmantot;//tikai skaidrojumam
    let delta1frac = delta1 & ((1 << e) - 1);

    // atveido neatņemamas daļas, vienlaikus pārbaudot precizitāti katrā solī.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // cipari, kas vēl jāatveido
    loop {
        // mums vienmēr ir vismaz viens cipars, ko atveidot, jo `plus1 >= 10^kappa` nemainīgie:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (no tā izriet, ka `remainder = plus1int % 10^(kappa+1)`)
        //
        //

        // daliet `remainder` ar `10^kappa`.abas ir mērogotas ar `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; mēs esam atraduši pareizo `kappa`.
            let ten_kappa = (ten_kappa as u64) << e; // skalot 10 ^ kappa atpakaļ uz kopīgo eksponentu
            return round_and_weed(
                // DROŠĪBA: mēs iepriekš inicializējām šo atmiņu.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // pārtrauciet cilpu, kad mēs esam atveidojuši visus integrālos ciparus.
        // precīzs ciparu skaits ir `max_kappa + 1` kā `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // atjaunot invariantus
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // atveido daļējas daļas, vienlaikus pārbaudot precizitāti katrā solī.
    // šoreiz mēs paļaujamies uz atkārtotu reizināšanu, jo dalīšana zaudēs precizitāti.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // nākamajam ciparam jābūt nozīmīgam, jo mēs to pārbaudījām pirms invariantu izdalīšanas, kur `m = max_kappa + 1` (ciparu skaits neatņemamajā daļā):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // nepārplūdīs, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // daliet `remainder` ar `10^kappa`.
        // abas ir mērogotas ar `2^e / 10^kappa`, tāpēc pēdējais šeit ir netiešs.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // netiešs dalītājs
            return round_and_weed(
                // DROŠĪBA: mēs iepriekš inicializējām šo atmiņu.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // atjaunot invariantus
        kappa -= 1;
        remainder = r;
    }

    // mēs esam izveidojuši visus nozīmīgos `plus1` ciparus, taču nezinām, vai tas ir optimālākais.
    // piemēram, ja `minus1` ir 3.14153 ... un `plus1` ir 3.14158 ..., ir 5 dažādi īsākie attēli no 3.14154 līdz 3.14158, bet mums ir tikai vislielākais.
    // mums ir secīgi jāsamazina pēdējais cipars un jāpārbauda, vai tas ir optimālais repr.
    // ir ne vairāk kā 9 kandidāti (.1 līdz ..9), tāpēc tas notiek diezgan ātri.("rounding" fāze)
    //
    // funkcija pārbauda, vai šī "optimal" repr faktiski atrodas ulp diapazonos, un ir arī iespējams, ka "second-to-optimal" repr faktiski var būt optimāls noapaļošanas kļūdas dēļ.
    // jebkurā gadījumā tas atgriež `None`.
    // ("weeding" fāze)
    //
    // visi šeit esošie argumenti tiek mērogoti ar kopējo (bet netiešo) vērtību `k`, lai:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (un arī `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (un arī `threshold > plus1v` no iepriekšējiem invariantiem)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // uzrāda divas aproksimācijas līdz `v` (faktiski `plus1 - v`) 1.5 ulps.
        // iegūtajam attēlojumam jābūt vistuvāk abiem.
        //
        // šeit tiek izmantots `plus1 - v`, jo aprēķini tiek veikti attiecībā uz `plus1`, lai izvairītos no overflow/underflow (tātad šķietami nomainīti nosaukumi).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1 ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ulp)

        // samaziniet pēdējo ciparu un apstājieties pie vistuvākā attēlojuma `v + 1 ulp`.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // mēs strādājam ar aptuvenajiem cipariem `w(n)`, kas sākotnēji ir vienāds ar `plus1 - plus1 % 10^kappa`.pēc cilpas korpusa palaišanas `n` reizes, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // mēs iestatām `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` (tādējādi `atlikums= plus1w(0)`), lai vienkāršotu pārbaudes.
            // ņemiet vērā, ka `plus1w(n)` vienmēr palielinās.
            //
            // mums ir trīs nosacījumi, lai izbeigtu.jebkurš no tiem padarīs cilpu nespējīgu turpināt, bet pēc tam mums ir vismaz viena derīga pārstāvība, kas ir vistuvāk `v + 1 ulp`.
            // Mēs tos īsumā apzīmēsim kā TC1 līdz TC3.
            //
            // TC1: `w(n) <= v + 1 ulp`, ti, tas ir pēdējais atkārtojums, kas var būt vistuvākais.
            // tas ir līdzvērtīgs `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up`.
            // apvienojumā ar TC2 (kas pārbauda, vai `w(n+1)` is valid), tas novērš iespējamo `plus1w(n)` aprēķina pārpildi.
            //
            // TC2: `w(n+1) < minus1`, ti, nākamais atkārtojums noteikti nav noapaļots līdz `v`.
            // tas ir līdzvērtīgs `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold`.
            // kreisā puse var pārplūst, bet mēs zinām `threshold > plus1v`, tādēļ, ja TC1 ir nepatiesa, `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` un mēs varam droši pārbaudīt, vai `threshold - plus1w(n) < 10^kappa`.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, ti, nākamais repr ir
            // ne tuvāk `v + 1 ulp` kā pašreizējais repr.
            // ņemot vērā `z(n) = plus1v_up - plus1w(n)`, tas kļūst par `abs(z(n)) <= abs(z(n+1))`.atkal pieņemot, ka TC1 ir nepatiesa, mums ir `z(n) > 0`.mums jāapsver divi gadījumi:
            //
            // - kad `z(n+1) >= 0`: TC3 kļūst par `z(n) <= z(n+1)`.
            // tā kā `plus1w(n)` palielinās, `z(n)` vajadzētu samazināties, un tas ir acīmredzami nepatiesi.
            // - kad `z(n+1) < 0`:
            //   - TC3a: priekšnosacījums ir `plus1v_up < plus1w(n) + 10^kappa`.pieņemot, ka TC2 ir nepatiesa, `threshold >= plus1w(n) + 10^kappa`, tāpēc tā nevar pārplūst.
            //   - TC3b: TC3 kļūst par `z(n) <= -z(n+1)`, ti, `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   noraidītais TC1 dod `plus1v_up > plus1w(n)`, tāpēc, apvienojot to ar TC3a, tas nevar pārplūst vai pārplūst.
            //
            // līdz ar to mums jāpārtrauc, kad `TC1 || TC2 || (TC3a && TC3b)`.sekojošais ir vienāds ar tā apgriezto vērtību, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // īsākais repr nevar beigties ar `0`
                plus1w += ten_kappa;
            }
        }

        // pārbaudiet, vai šis attēlojums ir arī vistuvākais attēlam `v - 1 ulp`.
        //
        // tas vienkārši ir tāds pats kā `v + 1 ulp` izbeigšanas nosacījumiem, visu `plus1v_up` vietā aizstājot ar `plus1v_down`.
        // pārplūdes analīze ir vienāda.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // Tagad mums ir vistuvāk `v` attēlojums starp `plus1` un `minus1`.
        // tomēr tas ir pārāk liberāli, tāpēc mēs noraidām jebkuru `w(n)`, kas nav starp `plus0` un `minus0`, ti, `plus1 - plus1w(n) <= minus0` vai `plus1 - plus1w(n) >= plus0`.
        // mēs izmantojam faktus, kas `threshold = plus1 - minus1` un `plus1 - plus0 = minus0 - minus1 = 2 ulp`.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// Īsākā režīma ieviešana programmai Grisu with Dragon.
///
/// Tas jāizmanto vairumā gadījumu.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // DROŠĪBA: Aizņemšanās pārbaudītājs nav pietiekami gudrs, lai ļautu mums izmantot `buf`
    // otrajā branch, tāpēc mēs šeit mazgājam mūžu.
    // Bet mēs atkārtoti izmantojam `buf` tikai tad, ja `format_shortest_opt` atgrieza `None`, tāpēc tas ir labi.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// Precīza un fiksēta režīma ieviešana Grisu.
///
/// Tas atgriež `None`, ja citādi atgrieztu neprecīzu attēlojumu.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // mums nepieciešama vismaz trīs bitu papildu precizitāte
    assert!(!buf.is_empty());

    // normalizēt un mērogot `v`.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // sadaliet `v` neatņemamās un daļējās daļās.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // gan vecajai `v`, gan jaunajai `v` (mērogota ar `10^-k`) kļūda ir <1 ulp (teorēma 5.1).
    // tā kā mēs nezinām, ka kļūda ir pozitīva vai negatīva, mēs izmantojam divus tuvinājumus, kas izvietoti vienādi, un maksimālā kļūda ir 2 ulps (tas pats īsākajā gadījumā).
    //
    //
    // mērķis ir atrast precīzi noapaļotas ciparu sērijas, kas ir kopīgas gan `v - 1 ulp`, gan `v + 1 ulp`, lai mēs būtu maksimāli pārliecināti.
    // ja tas nav iespējams, mēs nezinām, kurš no tiem ir pareizs `v` izvads, tāpēc mēs atsakāmies un atkrītam.
    //
    // `err` šeit tiek definēts kā `1 ulp * 2^e` (tāds pats kā `vfrac` ulp), un mēs to mērogosim, kad `v` tiks mērogots.
    //
    //
    //
    let mut err = 1;

    // aprēķiniet lielāko `10^max_kappa` ne vairāk kā `v` (tādējādi `v < 10^(max_kappa+1)`).
    // šī ir `kappa` augšējā robeža zemāk.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // ja mēs strādājam ar pēdējā cipara ierobežojumu, mums ir jāsaīsina buferis pirms faktiskās renderēšanas, lai izvairītos no dubultas noapaļošanas.
    //
    // ņemiet vērā, ka, veicot noapaļošanu uz augšu, buferis ir jāpalielina vēlreiz!
    let len = if exp <= limit {
        // oi, mēs pat nevaram uzrādīt *vienu* ciparu.
        // tas ir iespējams, ja, piemēram, mums ir kaut kas līdzīgs 9.5 un tas tiek noapaļots līdz 10.
        //
        // principā mēs varam nekavējoties izsaukt `possibly_round` ar tukšu buferi, bet `max_ten_kappa << e` mērogošana par 10 var izraisīt pārplūdi.
        //
        // tādējādi mēs šeit esam pavirši un paplašinām kļūdu diapazonu ar koeficientu 10.
        // tas palielinās viltus negatīvo līmeni, bet tikai ļoti,*ļoti* nedaudz;
        // tam var būt nozīmīga nozīme tikai tad, kad mantissa ir lielāka par 60 bitiem.
        //
        // DROŠĪBA: `len=0`, tāpēc pienākums inicializēt šo atmiņu ir niecīgs.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // padarīt neatņemamas daļas.
    // kļūda ir pilnībā daļēja, tāpēc mums tā nav jāpārbauda šajā daļā.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // cipari, kas vēl jāatveido
    loop {
        // mums vienmēr ir vismaz viens cipars, lai padarītu invariantus:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (no tā izriet, ka `remainder = vint % 10^(kappa+1)`)
        //
        //

        // daliet `remainder` ar `10^kappa`.abas ir mērogotas ar `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // vai buferis ir pilns?palaist apaļo piespēli ar atlikušo daļu.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ kappa) * 2 ^ e
            // DROŠĪBA: mēs esam inicializējuši `len` daudz baitu.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // pārtrauciet cilpu, kad mēs esam atveidojuši visus integrālos ciparus.
        // precīzs ciparu skaits ir `max_kappa + 1` kā `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // atjaunot invariantus
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // renderēt daļas.
    //
    // principā mēs varam turpināt līdz pēdējam pieejamajam ciparam un pārbaudīt precizitāti.
    // diemžēl mēs strādājam ar ierobežota lieluma veseliem skaitļiem, tāpēc mums ir nepieciešams kāds kritērijs, lai noteiktu pārplūdi.
    // V8 izmanto `remainder > err`, kas kļūst nepatiesa, ja `v - 1 ulp` un `v` pirmie `i` nozīmīgie cipari atšķiras.
    // tomēr tas noraida pārāk daudz citādi derīgu ievadi.
    //
    // tā kā vēlākai fāzei ir pareiza pārplūdes noteikšana, mēs tā vietā izmantojam stingrāku kritēriju:
    // mēs turpinām, līdz `err` pārsniedz `10^kappa / 2`, tāpēc diapazonā starp `v - 1 ulp` un `v + 1 ulp` noteikti ir divi vai vairāki noapaļoti attēlojumi.
    //
    // tas pats attiecas uz pirmajiem diviem `possibly_round` salīdzinājumiem.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // invarianti, kur `m = max_kappa + 1` (ciparu skaits neatņemamajā daļā):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // nepārplūdīs, `2^e * 10 < 2^64`
        err *= 10; // nepārplūdīs, `err * 10 < 2^e * 5 < 2^64`

        // daliet `remainder` ar `10^kappa`.
        // abas ir mērogotas ar `2^e / 10^kappa`, tāpēc pēdējais šeit ir netiešs.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // vai buferis ir pilns?palaist apaļo piespēli ar atlikušo daļu.
        if i == len {
            // DROŠĪBA: mēs esam inicializējuši `len` daudz baitu.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // atjaunot invariantus
        remainder = r;
    }

    // turpmāks aprēķins ir bezjēdzīgs (`possibly_round` noteikti neizdodas), tāpēc mēs atsakāmies.
    return None;

    // mēs esam izveidojuši visus pieprasītos `v` ciparus, kuriem arī jābūt vienādiem ar atbilstošajiem `v - 1 ulp` cipariem.
    // tagad mēs pārbaudām, vai ir unikāls attēlojums, kas ir kopīgs gan `v - 1 ulp`, gan `v + 1 ulp`;tas var būt vai nu tas pats, kas ģenerētajiem cipariem, vai šo ciparu noapaļotajai versijai.
    //
    // ja diapazonā ir vairāki vienāda garuma attēlojumi, mēs nevaram būt droši un tā vietā jāatgriež `None`.
    //
    // visi šeit esošie argumenti tiek mērogoti ar kopējo (bet netiešo) vērtību `k`, lai:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // DROŠĪBA: jāinicializē `buf` pirmie `len` baiti.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (atsaucei punktētā līnija norāda precīzu iespējamo attēlojumu vērtību norādītajā ciparu skaitā.)
        //
        //
        // kļūda ir pārāk liela, ka starp `v - 1 ulp` un `v + 1 ulp` ir vismaz trīs iespējamie attēlojumi.
        // mēs nevaram noteikt, kurš no tiem ir pareizs.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // Patiesībā 1/2 ulp ir pietiekami, lai ieviestu divus iespējamos attēlojumus.
        // (atcerieties, ka mums ir nepieciešams unikāls attēlojums gan `v - 1 ulp`, gan `v + 1 ulp`.) Tas netiks pārpildīts, jo `ulp < ten_kappa` no pirmās pārbaudes.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ kappa-- -------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // ja `v + 1 ulp` ir tuvāk noapaļotajam attēlam (kas jau ir `buf`), tad mēs varam droši atgriezties.
        // ņemiet vērā, ka `v - 1 ulp`*var* būt mazāks par pašreizējo attēlojumu, taču kā `1 ulp < 10^kappa / 2` šis nosacījums ir pietiekams:
        // attālums starp `v - 1 ulp` un pašreizējo attēlojumu nedrīkst pārsniegt `10^kappa / 2`.
        //
        // nosacījums ir vienāds ar `remainder + ulp < 10^kappa / 2`.
        // tā kā tas var viegli pārplūst, vispirms pārbaudiet, vai `remainder < 10^kappa / 2`.
        // mēs jau esam pārbaudījuši, vai `ulp < 10^kappa / 2`, tāpēc, kamēr `10^kappa` galu galā nepārplūda, otrā pārbaude ir piemērota.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // DROŠĪBA: mūsu zvanītājs inicializēja šo atmiņu.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------atlikušais------> |:
        //   :                          |   :
        //   : <---------10 ^ kappa-- ------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // no otras puses, ja `v - 1 ulp` ir tuvāk noapaļotajam attēlojumam, mums vajadzētu noapaļot uz augšu un atgriezties.
        // tā paša iemesla dēļ mums nav jāpārbauda `v + 1 ulp`.
        //
        // nosacījums ir vienāds ar `remainder - ulp >= 10^kappa / 2`.
        // atkal mēs vispirms pārbaudām, vai `remainder > ulp` (ņemiet vērā, ka tas nav `remainder >= ulp`, jo `10^kappa` nekad nav nulle).
        //
        // ņemiet vērā arī to, ka `remainder - ulp <= 10^kappa`, tāpēc otrā pārbaude nepārplūst.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // DROŠĪBA: mūsu zvanītājam jābūt inicializētai šai atmiņai.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // Pievienojiet papildu ciparu tikai tad, kad mums ir pieprasīta fiksēta precizitāte.
                // mums arī jāpārbauda, vai, ja sākotnējais buferis bija tukšs, papildu ciparu var pievienot tikai tad, kad `exp == limit` (edge gadījums).
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // DROŠĪBA: mēs un mūsu zvanītājs inicializējām šo atmiņu.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // pretējā gadījumā mēs esam nolemti (ti, dažas vērtības starp `v - 1 ulp` un `v + 1 ulp` noapaļo uz leju, bet citas noapaļo uz augšu) un atsakāmies.
        //
        None
    }
}

/// Precīza un fiksēta režīma ieviešana Grisu ar Dragon atkāpšanos.
///
/// Tas jāizmanto vairumā gadījumu.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // DROŠĪBA: Aizņemšanās pārbaudītājs nav pietiekami gudrs, lai ļautu mums izmantot `buf`
    // otrajā branch, tāpēc mēs šeit mazgājam mūžu.
    // Bet mēs atkārtoti izmantojam `buf` tikai tad, ja `format_exact_opt` atgrieza `None`, tāpēc tas ir labi.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}