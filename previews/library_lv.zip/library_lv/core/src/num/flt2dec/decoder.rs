//! Atšifrē peldošā komata vērtību atsevišķās daļās un kļūdu diapazonos.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Atkodēta neparakstīta galīgā vērtība, piemēram:
///
/// - Sākotnējā vērtība ir vienāda ar `mant * 2^exp`.
///
/// - Jebkurš skaitlis no `(mant - minus)*2^exp` līdz `(mant + plus)* 2^exp` tiks noapaļots līdz sākotnējai vērtībai.
/// Diapazons ir iekļauts tikai tad, ja `inclusive` ir `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Mērogotā mantissa.
    pub mant: u64,
    /// Zemāks kļūdu diapazons.
    pub minus: u64,
    /// Augšējais kļūdu diapazons.
    pub plus: u64,
    /// 2. bāzes kopīgais eksponents.
    pub exp: i16,
    /// Patiesi, ja kļūdu diapazons ir iekļauts.
    ///
    /// IEEE 754 tas ir taisnība, kad sākotnējā mantissa bija vienmērīga.
    pub inclusive: bool,
}

/// Atkodēta neparakstīta vērtība.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Bezgalība, vai nu pozitīva, vai negatīva.
    Infinite,
    /// Nulle, pozitīva vai negatīva.
    Zero,
    /// Galīgi skaitļi ar tālāk atšifrētiem laukiem.
    Finite(Decoded),
}

/// Peldošā komata tips, kuru var "atšifrēt" d.
pub trait DecodableFloat: RawFloat + Copy {
    /// Minimālā pozitīvā normalizētā vērtība.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Atgriež zīmi (taisnība, kad negatīva) un `FullDecoded` vērtību no norādītā peldošā komata skaitļa.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // kaimiņi: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode vienmēr saglabā eksponentu, tāpēc mantissa tiek mērogota pēc subnormāliem.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // kaimiņi: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // kur maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // kaimiņi: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}