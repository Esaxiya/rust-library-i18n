//! Kļūdu veidi pārveidošanai par integrāliem tipiem.

use crate::convert::Infallible;
use crate::fmt;

/// Kļūdas veids tika atgriezts, ja pārbaudītā integrālā tipa pārveidošana neizdodas.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Spēlējiet, nevis piespiedu kārtā, lai pārliecinātos, ka kods, piemēram, `From<Infallible> for TryFromIntError`, iepriekš darbosies, kad `Infallible` kļūs par `!` aizstājvārdu.
        //
        //
        match never {}
    }
}

/// Kļūda, ko var atgriezt, analizējot veselu skaitli.
///
/// Šī kļūda tiek izmantota kā kļūdas veids `from_str_radix()` funkcijām primitīviem veselu skaitļu tipiem, piemēram, [`i8::from_str_radix`].
///
/// # Iespējamie cēloņi
///
/// Starp citiem iemesliem `ParseIntError` var izmest virknes priekšējā vai aizmugurējā atstarpes dēļ, piemēram, ja tas iegūts no standarta ievades.
///
/// Izmantojot [`str::trim()`] metodi, tiek nodrošināts, ka pirms parsēšanas nepaliek atstarpes.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum uzglabā dažāda veida kļūdas, kuru dēļ vesela skaitļa parsēšana var neizdoties.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Parsējamā vērtība ir tukša.
    ///
    /// Cita iemesla dēļ šis variants tiks izveidots, analizējot tukšu virkni.
    Empty,
    /// Kontekstā ir nederīgs cipars.
    ///
    /// Cita iemesla dēļ šis variants tiks izveidots, analizējot virkni, kas satur ne-ASCII rakstzīmi.
    ///
    /// Šis variants tiek veidots arī tad, kad `+` vai `-` tiek ievietots virknē nepareizi vai nu atsevišķi, vai skaitļa vidū.
    ///
    ///
    InvalidDigit,
    /// Vesels skaitlis ir pārāk liels, lai to saglabātu mērķa veselā skaitļa tipā.
    PosOverflow,
    /// Vesels skaitlis ir pārāk mazs, lai to saglabātu mērķa veselā skaitļa tipā.
    NegOverflow,
    /// Vērtība bija Nulle
    ///
    /// Šis variants tiks izstarots, kad parsēšanas virknes vērtība būs nulle, kas būtu nelegāli tipiem, kas nav nulle.
    ///
    Zero,
}

impl ParseIntError {
    /// Tiek izvadīts detalizēts vesela skaitļa kļūmes parsēšanas cēlonis.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}