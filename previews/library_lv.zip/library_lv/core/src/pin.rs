//! Veidi, kas piesaista datus tā atrašanās vietai atmiņā.
//!
//! Dažreiz ir noderīgi objekti, kas tiek pārvietoti garantēti tādā nozīmē, ka to ievietošana atmiņā nemainās un tādējādi uz tiem var paļauties.
//! Galvenais šāda scenārija piemērs būtu pašreferenciālu struktūru veidošana, jo, pārvietojot objektu ar rādītājiem uz sevi, tie kļūs nederīgi, kas varētu izraisīt nedefinētu rīcību.
//!
//! Augstā līmenī [`Pin<P>`] nodrošina, ka jebkura veida `P` rādītāja adresātam ir stabila vieta atmiņā, tas nozīmē, ka to nevar pārvietot citur un tā atmiņu nevar novirzīt, kamēr tā netiek nomesta.Mēs sakām, ka rādītājs ir "pinned".Lietas kļūst smalkākas, apspriežot veidus, kas apvienoti piesprausti ar nepiestiprinātiem datiem;[see below](#projections-and-structural-pinning), lai iegūtu sīkāku informāciju.
//!
//! Pēc noklusējuma visi Rust veidi ir pārvietojami.
//! Rust ļauj nodot visu veidu blakus vērtības, un parastie viedo rādītāju veidi, piemēram, [`Box<T>`] un `&mut T`, ļauj aizstāt un pārvietot tajos esošās vērtības: jūs varat pārvietoties no [`Box<T>`] vai izmantot [`mem::swap`].
//! [`Pin<P>`] aptin `P` tipa rādītāju, tāpēc [`Pin ']` <`[` Box'] `<T>>`darbojas līdzīgi kā parasts
//!
//! [`Box<T>`]: when a [`Pin ']` <`[` Box'] `<T>>`pazeminās, tāpat arī tā saturs, un atmiņa kļūst
//!
//! izdalīts.Līdzīgi [`Pin`] <&mut T>` līdzinās `&mut T`.Tomēr [`Pin<P>`] neļauj klientiem faktiski iegūt piespraustajiem datiem [`Box<T>`] vai `&mut T`, kas nozīmē, ka nevar izmantot tādas darbības kā [`mem::swap`]:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` nepieciešama `&mut T`, taču mēs to nevaram iegūt.
//!     // Mēs esam iestrēguši, mēs nevaram apmainīt šo atsauču saturu.
//!     // Mēs varētu izmantot `Pin::get_unchecked_mut`, taču tas ir nedrošs kāda iemesla dēļ:
//!     // mums nav atļauts to izmantot, lai pārvietotu lietas no `Pin`.
//! }
//! ```
//!
//! Ir vērts atkārtot, ka [`Pin<P>`]*nemaina* faktu, ka Rust kompilators visu veidu uzskata par pārvietojamu.[`mem::swap`] joprojām ir izsaucams jebkuram `T`.Tā vietā [`Pin<P>`] neļauj pārvietot noteiktas *vērtības*(uz kurām norāda rādītāji, kas iesaiņoti [`Pin<P>`]), padarot neiespējamu izsaukt metodes, kurām nepieciešama `&mut T` (piemēram, [`mem::swap`]).
//!
//! [`Pin<P>`] var izmantot jebkura veida `P` rādītāja iesaiņošanai un kā tāds mijiedarbojas ar [`Deref`] un [`DerefMut`].[`Pin<P>`], kur `P: Deref` jāuzskata par piespraustā `P::Target` kā "`P`-style pointer"-tātad, ["Pin"] <"[" Box "]"<T>> `ir piespraustajam `T` piederošais rādītājs un [` Pin '] <<[[Rc`]`<T>> `ir atsauces skaitīts rādītājs piespraustajam `T`.
//! Pareizības labad [`Pin<P>`] paļaujas uz to, ka [`Deref`] un [`DerefMut`] ieviešana neizkļūst no sava parametra `self` un vienmēr atgriež rādītāju pie piespraustajiem datiem, kad tie tiek izsaukti uz piespraustā rādītāja.
//!
//! # `Unpin`
//!
//! Daudzi veidi vienmēr ir brīvi pārvietojami, pat ja tie ir piestiprināti, jo tie nepaļaujas uz stabilu adresi.Tas ietver visus pamata veidus (piemēram, [`bool`], [`i32`] un atsauces), kā arī tipus, kas sastāv tikai no šiem veidiem.Veidi, kuriem nav nozīmes piespraušanā, ievieš [`Unpin`] auto-trait, kas atceļ [`Pin<P>`] iedarbību.
//! Operētājsistēmai `T: Unpin`: [`Pin ']` ```` ``Box````<T>> `un [`Box<T>`] darbojas vienādi, tāpat kā [` Pin`]`<&mut T>` un `&mut T`.
//!
//! Ņemiet vērā, ka piespraušana un [`Unpin`] ietekmē tikai smailu tipa `P::Target`, nevis pašu rādītāja veidu `P`, kas tika iesaiņots [`Pin<P>`].Piemēram, neatkarīgi no tā, vai [`Box<T>`] ir [`Unpin`], nav ietekmes uz [`Pin`]`<`[`Box`]`uzvedību.<T>>"(šeit `T` ir norādītais tips).
//!
//! # Piemērs: pašreferenciāla struktūra
//!
//! Pirms iedziļināmies sīkāk, lai izskaidrotu ar `Pin<T>` saistītās garantijas un izvēli, mēs apspriežam dažus piemērus, kā to izmantot.
//! Jūtieties brīvi izmantot [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Šī ir pašreferenciāla struktūra, jo griezuma lauks norāda uz datu lauku.
//! // Mēs nevaram par to informēt sastādītāju, izmantojot parasto atsauci, jo šo modeli nevar aprakstīt ar parastajiem aizņēmuma noteikumiem.
//! //
//! // Tā vietā mēs izmantojam neapstrādātu rādītāju, kaut arī zināms, ka tas nav nulle, jo mēs zinām, ka tas norāda uz virkni.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Lai nodrošinātu, ka dati, kad funkcija atgriežas, nepārvietojas, mēs tos ievietojam kaudzē, kur tie paliks objekta kalpošanas laikā, un vienīgais veids, kā piekļūt tiem, būtu ar rādītāju uz to.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // rādītāju mēs izveidojam tikai tad, kad dati ir ievietoti, pretējā gadījumā tas jau būs pārvietojies, pirms mēs pat sākām
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // mēs zinām, ka tas ir droši, jo lauka pārveidošana nepārvieto visu struktūru
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // Rādītājam jānorāda uz pareizo vietu, ja vien struktūra nav pārvietota.
//! //
//! // Tikmēr mēs varam brīvi pārvietot rādītāju apkārt.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Tā kā mūsu tips neievieš atvienošanu, to neizdosies apkopot:
//! // let mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Piemērs: uzmācīgs divkārši saistīts saraksts
//!
//! Uzbāzīgā divkārši saistītā sarakstā kolekcija faktiski nepiešķir atmiņu pašiem elementiem.
//! Piešķiršanu kontrolē klienti, un elementi var dzīvot uz kaudzes rāmja, kas dzīvo īsāk nekā kolekcija.
//!
//! Lai tas darbotos, katram elementam ir norādes uz tā priekšgājēju un pēcteci sarakstā.Elementus var pievienot tikai tad, kad tie ir piesprausti, jo, pārvietojot elementus apkārt, rādītāji kļūs nederīgi.Turklāt saistītā saraksta elementa [`Drop`] ieviešana aizlāpīs tā priekšgājēja un pēcteces norādes, lai noņemtu sevi no saraksta.
//!
//! Būtiski, ka mums jāspēj paļauties uz [`drop`] izsaukšanu.Ja kādu elementu varētu izdalīt vai citādi padarīt nederīgu, neizsaucot [`drop`], tajā esošās norādes no blakus esošajiem elementiem kļūtu nederīgas, kas izjauktu datu struktūru.
//!
//! Tāpēc piespraušanai ir arī garantija, kas saistīta ar [pilienu].
//!
//! # `Drop` guarantee
//!
//! Piespraudes mērķis ir spēt paļauties uz dažu datu ievietošanu atmiņā.
//! Lai tas darbotos, ir ierobežota ne tikai datu pārvietošana;Ir ierobežota arī datu glabāšanai izmantotās atmiņas izvietošana, atkārtota izvietošana vai cita veida nederīga darbība.
//! Konkrēti, attiecībā uz piespraustajiem datiem jums jāuztur nemainīgais, ka *tā atmiņa netiks nederīga vai mainīta no brīža, kad tā tiks piesprausta, līdz brīdim, kad tiks izsaukta [`drop`]*.Tikai tad, kad [`drop`] atgriežas, vai panics, atmiņu var izmantot atkārtoti.
//!
//! Atmiņa var būt "invalidated", veicot darījumu izvietošanu, bet arī aizstājot [`Some(v)`] ar [`None`], vai izsaucot [`Vec::set_len`] uz "kill" dažus elementus no vector.To var mainīt, izmantojot [`ptr::write`], lai to pārrakstītu, vispirms neizsaucot destruktoru.Neviens no tiem nav atļauts piespraustajiem datiem, neizsaucot [`drop`].
//!
//! Tas ir tieši tāds garantijas veids, kā pareizi darboties iepriekšējās sadaļas uzmācīgajam saistītajam sarakstam.
//!
//! Ievērojiet, ka šī garantija *nenozīmē, ka atmiņa neplūst!Joprojām ir pilnīgi labi, ka nekad nevar piezvanīt uz [`drop`] piespraustajā elementā (piemēram, jūs joprojām varat piezvanīt uz [`mem::forget`] uz [`Pin`]<T>> `).Divkārši saistītā saraksta piemērā šis elements vienkārši paliks sarakstā.Tomēr jūs nevarat atbrīvot vai atkārtoti izmantot krātuvi*, neizsaucot [`drop`] *.
//!
//! # `Drop` implementation
//!
//! Ja jūsu tips izmanto piespraušanu (piemēram, divus iepriekš minētos piemērus), jums jābūt uzmanīgiem, ieviešot [`Drop`].[`drop`] funkcija aizņem `&mut self`, taču to sauc par *, pat ja jūsu tips iepriekš bija piesprausts*!Tas ir tā, it kā kompilators automātiski izsauktu [`Pin::get_unchecked_mut`].
//!
//! Tas nekad nevar radīt problēmas drošajā kodā, jo, lai ieviestu tipu, kas balstās uz piespraušanu, ir nepieciešams nedrošs kods, taču ņemiet vērā, ka, nolemjot izmantot piespraušanu savā tipā (piemēram, veicot kādu darbību ar [`Pin`]`<&Self>`vai [`Piespraust`] `<&mut Self>`) ietekmē arī jūsu [`Drop`] ieviešanu: ja jūsu tipa elements varētu būt piesprausts, jums jāaplūko [`Drop`] kā netieši paņemot [`Pin`]`<&mut Pats>`.
//!
//!
//! Piemēram, jūs varētu ieviest `Drop` šādi:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` ir labi, jo mēs zinām, ka šī vērtība pēc kritiena vairs nekad netiek izmantota.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Faktiskais nomešanas kods iet šeit.
//!         }
//!     }
//! }
//! ```
//!
//! Funkcijai `inner_drop` ir tips, kas vajadzētu būt [`drop`] *, tāpēc tas nodrošina, ka nejauši nelietojat `self`/`this` veidā, kas ir pretrunā ar piespraušanu.
//!
//! Turklāt, ja jūsu tips ir `#[repr(packed)]`, kompilators automātiski pārvietos laukus, lai tos varētu nomest.Tas varētu pat darīt, ja lauki, kas notiek, ir pietiekami izlīdzināti.Tā rezultātā jūs nevarat izmantot piespraušanu ar `#[repr(packed)]` tipu.
//!
//! # Projekcijas un strukturālā piestiprināšana
//!
//! Strādājot ar piespraustajiem strukturiem, rodas jautājums, kā piekļūt šīs struktūras laukiem metodē, kas prasa tikai [`Pin`]`<&mut Struct>`.
//! Parastā pieeja ir rakstīt palīgmetodes (tā sauktās *projekcijas*), kas pārvērš [`Pin`] <&mut Struct> par atsauci uz lauku, bet kāda veida šai atsaucei jābūt?Vai tas ir [`Pin`]`<&mut Field>`vai `&mut Field`?
//! Tas pats jautājums rodas ar `enum` laukiem un arī, ņemot vērā container/wrapper tipus, piemēram, [`Vec<T>`], [`Box<T>`] vai [`RefCell<T>`].
//! (Šis jautājums attiecas gan uz maināmām, gan uz koplietojamām atsaucēm, ilustrācijai mēs vienkārši izmantojam šeit biežāk lietojamo mainīgo atsauču gadījumus.)
//!
//! Izrādās, ka patiesībā datu struktūras autoram ir jāizlemj, vai piespraustā projekcija konkrētam laukam pārvērš [`Pin`] <&mut Struct> par [`Pin`] `<&mut Field> vai `&mut Field`.Tomēr ir daži ierobežojumi, un vissvarīgākais ierobežojums ir *konsekvence*:
//! katru lauku var vai nu projicēt uz piespraustās atsauces, vai arī * noņemot piespraudi kā daļu no projekcijas.
//! Ja abi tiek veikti vienā laukā, tas, visticamāk, būs nepamatoti!
//!
//! Kā datu struktūras autoram jums katram laukam jāizlemj, vai "propagates" piespraust šajā laukā.
//! Spraudi, kas izplatās, sauc arī par "structural", jo tas seko tipa struktūrai.
//! Turpmākajās apakšnodaļās mēs aprakstām apsvērumus, kas jāizdara jebkurai izvēlei.
//!
//! ## Piespiešana * nav strukturāla `field`
//!
//! Var šķist pret intuitīvi, ka piespraustās struktūras lauks, iespējams, nav piesprausts, taču tā faktiski ir vieglākā izvēle: ja nekad netiek izveidots [`Piespraust]] <&mut lauku>, nekas nevar noiet greizi!Tātad, ja jūs nolemjat, ka kādā laukā nav strukturālas piespraudes, jums tikai jānodrošina, ka jūs nekad neveidojat piesprausto atsauci uz šo lauku.
//!
//! Laukos bez strukturālas piespraudes var būt projekcijas metode, kas pārvērš ["Pin"] "<&mut Struct>" par `&mut Field`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Tas ir labi, jo `field` nekad netiek uzskatīts par piespraustu.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Jūs varat arī `impl Unpin for Struct`*, pat ja*`field` tips nav [`Unpin`].Tas, ko šis tips domā par piespraušanu, nav būtisks, ja nekad nav izveidots ["Pin"] "<&mut Field>".
//!
//! ## Piespiešana * ir `field` strukturālā
//!
//! Otra iespēja ir izlemt, ka piespraušana ir "structural" `field`, kas nozīmē, ka, ja struktūra ir piesprausta, tad ir arī lauks.
//!
//! Tas ļauj rakstīt projekciju, kas izveido [`Pin ']` <&mut Field> `, tādējādi liecinot, ka lauks ir piesprausts:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Tas ir labi, jo `field` ir piesprausts, kad `self` ir.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Tomēr strukturālajai piestiprināšanai ir dažas papildu prasības:
//!
//! 1. Struktūrai jābūt [`Unpin`] tikai tad, ja visi strukturālie lauki ir [`Unpin`].Tas ir noklusējums, bet [`Unpin`] ir drošs trait, tāpēc kā struktūras autors jūs esat atbildīgs *nevis* pievienot kaut ko līdzīgu `impl<T> Unpin for Struct<T>`.
//! (Ievērojiet, ka projekcijas darbības pievienošanai ir nepieciešams nedrošs kods, tāpēc fakts, ka [`Unpin`] ir drošs trait, nepārkāpj principu, ka par visu šo ir jāuztraucas tikai tad, ja izmantojat `nedrošu`.)
//! 2. Struktūras iznīcinātājs nedrīkst pārvietot strukturālos laukus no sava argumenta.Šis ir precīzs jautājums, kas tika izvirzīts [previous section][drop-impl]: `drop` aizņem `&mut self`, taču struktūra (un līdz ar to arī tās lauki), iespējams, jau bija piesprausta.
//!     Jums ir jāgarantē, ka [`Drop`] ieviešanas laikā jūs nepārvietojat lauku.
//!     Jo īpaši, kā paskaidrots iepriekš, tas nozīmē, ka jūsu struktūrai *nedrīkst* būt `#[repr(packed)]`.
//!     Skatiet šo sadaļu, lai rakstītu [`drop`] tā, lai kompilators varētu jums nejauši neizjaukt piespraušanu.
//! 3. Jums jāpārliecinās, vai jūs atbalstāt [`Drop` guarantee][drop-guarantee]:
//!     Kad struktūra ir piestiprināta, atmiņa, kurā ir saturs, netiek pārrakstīta vai sadalīta, neizsaucot satura iznīcinātājus.
//!     Tas var būt sarežģīti, par ko liecina [`VecDeque<T>`]: [`VecDeque<T>`] iznīcinātājs var neizdoties izsaukt [`drop`] uz visiem elementiem, ja kāds no destruktoriem ir panics.Tas pārkāpj [`Drop`] garantiju, jo tas var novest pie tā, ka elementi tiek izvietoti, neizsaucot to iznīcinātāju.([`VecDeque<T>`] nav piespraudes projekcijas, tāpēc tas neizraisa nepietiekamību.)
//! 4. Jūs nedrīkstat piedāvāt citas darbības, kuru dēļ dati varētu tikt pārvietoti no strukturālajiem laukiem, kad jūsu tips ir piesprausts.Piemēram, ja struktūrā ir [`Option<T>`] un `fn(Pin<&mut Struct<T>>) -> Option<T>` tipā ir `take` veida darbība, šo darbību var izmantot, lai pārvietotu `T` no piespraustā `Struct<T>`-tas nozīmē, ka piespraušana nevar būt strukturāla laukam, kas tur šo dati.
//!
//!     Lai iegūtu sarežģītāku piemēru datu pārvietošanai no piespraustā tipa, iedomājieties, vai [`RefCell<T>`] būtu metode `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>`.
//!     Tad mēs varētu rīkoties šādi:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Tas ir katastrofāli, tas nozīmē, ka mēs vispirms varam piestiprināt [`RefCell<T>`] saturu (izmantojot `RefCell::get_pin_mut`) un pēc tam pārvietot šo saturu, izmantojot maināmo atsauci, ko mēs saņēmām vēlāk.
//!
//! ## Examples
//!
//! Tādam tipam kā [`Vec<T>`] ir jēga abām iespējām (strukturālai piespraušanai vai nē).
//! [`Vec<T>`] ar strukturālu piespraušanu varētu būt `get_pin`/`get_pin_mut` metodes, lai iegūtu piespraustas atsauces uz elementiem.Tomēr tas nevarēja *ne* atļaut izsaukt [`pop`][Vec::pop] piespraustajā [`Vec<T>`], jo tas pārvietotu (strukturāli piesprausto) saturu!Tas arī nevarēja atļaut [`push`][Vec::push], kas varētu pārdalīt un tādējādi arī pārvietot saturu.
//!
//! [`Vec<T>`] bez strukturālas piespraudes varētu `impl<T> Unpin for Vec<T>`, jo saturs nekad nav piesprausts, un pats [`Vec<T>`] ir labi pārvietojams.
//! Tajā brīdī piespiešana vienkārši neietekmē vector.
//!
//! Standarta bibliotēkā rādītāju tipiem parasti nav strukturālas piespraušanas, un tādējādi tie nepiedāvā piespraudes projekcijas.Tāpēc `Box<T>: Unpin` ir piemērots visiem `T`.
//! Ir lietderīgi to darīt rādītāju tipiem, jo, pārvietojot `Box<T>`, `T` faktiski netiek pārvietots: [`Box<T>`] var būt brīvi pārvietojams (pazīstams arī kā `Unpin`), pat ja `T` nav.Patiesībā pat [`Pin`]`<`[`Box ']`<T>> `un [` Piespraust`]`<&mut T>` vienmēr ir [`Unpin`] paši, tā paša iemesla dēļ: to saturs (`T`) ir piesprausts, bet pašas rādītājus var pārvietot, nepārvietojot piespraustos datus.
//! Gan [`Box<T>`], gan ["Pin"] "<" ["Box"]<T>>, vai saturs ir piesprausts, ir pilnīgi neatkarīgs no tā, vai rādītājs ir piesprausts, tas nozīmē, ka piespraušana *nav* strukturāla.
//!
//! Ieviešot [`Future`] kombinatoru, ligzdotajam futures parasti būs nepieciešama strukturāla piespraude, jo, lai izsauktu [`poll`], jums jāsaņem piespraustas atsauces uz tiem.
//! Bet, ja jūsu kombinatorā ir kādi citi dati, kas nav jāpiesprauž, jūs varat padarīt šos laukus strukturālus un tādējādi brīvi piekļūt tiem ar maināmu atsauci, pat ja jums vienkārši ir [`Pin`]`<&mut Self>`(piemēram, kā jūsu pašu [`poll`] ieviešanā).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// Piesprausts rādītājs.
///
/// Tas ir aptinums ap sava veida rādītāju, kas padara šo rādītāju "pin" tā vietā, neļaujot pārvietot rādītāja norādīto vērtību, ja vien tas neievieš [`Unpin`].
///
///
/// *Piespraušanas skaidrojumu skatiet [`pin` module] dokumentācijā.*
///
/// [`pin` module]: self
///
// Note: zemāk esošais `Clone` atvasinājums izraisa nepietiekamību, jo to ir iespējams ieviest
// `Clone` maināmām atsaucēm.
// Plašāku informāciju skatiet <https://internals.rust-lang.org/t/unsoundness-in-pin/11311>.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Tālāk minētie ieviešanas veidi nav atvasināti, lai izvairītos no drošuma problēmām.
// `&self.pointer` nedrīkst būt pieejams neuzticamām trait ieviešanām.
//
// Plašāku informāciju skatiet <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73>.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Konstruējiet jaunu `Pin<P>` ap rādītāju dažiem datiem, kas ievieš [`Unpin`].
    ///
    /// Atšķirībā no `Pin::new_unchecked`, šī metode ir droša, jo rādītāja `P` novirzes uz [`Unpin`] tipu tiek atceltas piespraušanas garantijas.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // DROŠĪBA: norādītā vērtība ir `Unpin`, un tāpēc tai nav prasību
        // ap piespraušanu.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Atceļ šo `Pin<P>`, atgriežot pamatā esošo rādītāju.
    ///
    /// Tas prasa, lai dati šajā `Pin` iekšienē būtu [`Unpin`], lai mēs, to atritinot, varētu ignorēt piespraužamos invariantus.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Konstruējiet jaunu `Pin<P>` ap atsauci uz dažiem tāda veida datiem, kas var vai neievieš `Unpin`.
    ///
    /// Ja `pointer` novirzes uz `Unpin` tipu, tā vietā jāizmanto `Pin::new`.
    ///
    /// # Safety
    ///
    /// Šis konstruktors ir nedrošs, jo mēs nevaram garantēt, ka dati, uz kuriem norāda `pointer`, ir piesprausti, tas nozīmē, ka dati netiks pārvietoti vai to krātuve kļūs nederīga, kamēr tie netiks nomesti.
    /// Ja konstruētais `Pin<P>` negarantē, ka dati, uz kuriem norāda `P`, ir piesprausti, tas ir API līguma pārkāpums un var izraisīt nedefinētu rīcību turpmākajās (safe) darbībās.
    ///
    /// Izmantojot šo metodi, jūs izveidojat promise par `P::Deref` un `P::DerefMut` ieviešanu, ja tādas pastāv.
    /// Vissvarīgākais ir tas, ka viņi nedrīkst izkļūt no saviem `self` argumentiem: `Pin::as_mut` un `Pin::as_ref` piespraustajā rādītājā *izsauks `DerefMut::deref_mut` un `Deref::deref`* un sagaida, ka šīs metodes atbalstīs piespraužamos invariantus.
    /// Turklāt, izsaucot šo metodi, jūs promise, no kuras atsauces `P` novirzes vairs netiks pārvietotas;jo īpaši nedrīkst būt iespējams iegūt `&mut P::Target` un pēc tam pārvietoties no šīs atsauces (izmantojot, piemēram, [`mem::swap`]).
    ///
    ///
    /// Piemēram, `Pin::new_unchecked` izsaukšana uz `&'a mut T` nav droša, jo, kamēr jūs to varat piespraust noteiktā dzīves laikā `'a`, jūs nevarat kontrolēt, vai tas tiek piesprausts, tiklīdz `'a` beidzas:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Tam vajadzētu nozīmēt, ka pointee `a` nekad vairs nevar pārvietoties.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // `a` adrese tika mainīta uz `b` steka slotu, tāpēc `a` tika pārvietots, kaut arī mēs to iepriekš esam piesprauduši!Mēs esam pārkāpuši piespraušanas API līgumu.
    /////
    /// }
    /// ```
    ///
    /// Kad vērtība ir piestiprināta, tai jāpaliek piespraustai uz visiem laikiem (ja vien tās tips neievieš `Unpin`).
    ///
    /// Tāpat `Pin::new_unchecked` izsaukšana uz `Rc<T>` nav droša, jo tiem pašiem datiem var būt pseidonīmi, uz kuriem neattiecas piespraušanas ierobežojumi:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Tam vajadzētu nozīmēt, ka rādītājs nekad vairs nevar pārvietoties.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Tagad, ja `x` bija vienīgā atsauce, mums ir maināma atsauce uz datiem, kurus mēs piestiprinājām iepriekš, un kurus mēs varētu izmantot, lai tos pārvietotu, kā redzējām iepriekšējā piemērā.
    ///     // Mēs esam pārkāpuši piespraušanas API līgumu.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// No šī piespraustā rādītāja iegūst piespraustu koplietojamo atsauci.
    ///
    /// Šī ir vispārēja metode, lai pārietu no `&Pin<Pointer<T>>` uz `Pin<&T>`.
    /// Tas ir droši, jo kā daļa no līguma `Pin::new_unchecked` līgumslēdzējs nevar pārvietoties pēc tam, kad `Pin<Pointer<T>>` ir izveidots.
    ///
    /// "Malicious" `Pointer::Deref` ieviešana tiek izslēgta arī ar `Pin::new_unchecked` līgumu.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // DROŠĪBA: skatiet šīs funkcijas dokumentāciju
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Atceļ šo `Pin<P>`, atgriežot pamatā esošo rādītāju.
    ///
    /// # Safety
    ///
    /// Šī funkcija ir nedroša.Jums ir jāgarantē, ka pēc šīs funkcijas izsaukšanas jūs turpināsiet apstrādāt rādītāju `P` kā piespraustu, lai `Pin` tipa invarianti tiktu saglabāti.
    /// Ja kods, izmantojot iegūto `P`, neturpina piespraužamo invariantu uzturēšanu, tas ir API līguma pārkāpums un var izraisīt nedefinētu rīcību turpmākajās (safe) darbībās.
    ///
    ///
    /// Ja pamatā esošie dati ir [`Unpin`], tā vietā jāizmanto [`Pin::into_inner`].
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// No šī piespraustā rādītāja iegūst piespraustu maināmu atsauci.
    ///
    /// Šī ir vispārēja metode, lai pārietu no `&mut Pin<Pointer<T>>` uz `Pin<&mut T>`.
    /// Tas ir droši, jo kā daļa no līguma `Pin::new_unchecked` līgumslēdzējs nevar pārvietoties pēc tam, kad `Pin<Pointer<T>>` ir izveidots.
    ///
    /// "Malicious" `Pointer::DerefMut` ieviešana tiek izslēgta arī ar `Pin::new_unchecked` līgumu.
    ///
    /// Šī metode ir noderīga, veicot vairākus izsaukumus uz funkcijām, kas patērē piesprausto tipu.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // dari kaut ko
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` patērē `self`, tāpēc atkārtoti aizdodiet `Pin<&mut Self>`, izmantojot `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // DROŠĪBA: skatiet šīs funkcijas dokumentāciju
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Piešķir jaunu vērtību atmiņai aiz piespraustās atsauces.
    ///
    /// Tas pārraksta piespraustos datus, taču tas ir labi: tā iznīcinātājs tiek palaists pirms pārrakstīšanas, tāpēc netiek pārkāptas piespraušanas garantijas.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Konstruē jaunu tapu, kartējot interjera vērtību.
    ///
    /// Piemēram, ja vēlaties iegūt `Pin` no kaut kā lauka, varat to izmantot, lai piekļūtu šim laukam vienā koda rindā.
    /// Tomēr ar šiem "pinning projections" ir vairākas gotchas;
    /// Plašāku informāciju par šo tēmu skatiet [`pin` module] dokumentācijā.
    ///
    /// # Safety
    ///
    /// Šī funkcija ir nedroša.
    /// Jums jāgarantē, ka atgrieztie dati netiks pārvietoti tik ilgi, kamēr nepārvietojas argumenta vērtība (piemēram, tāpēc, ka tas ir viens no šīs vērtības laukiem), kā arī tas, ka neizkļūstat no saņemtā argumenta iekšējā funkcija.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // DROŠĪBA: jābūt noslēgtam `new_unchecked` drošības līgumam
        // apstiprina zvanītājs.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Izgūst kopīgu atsauci no piespraudes.
    ///
    /// Tas ir droši, jo nav iespējams pārvietoties no koplietotās atsauces.
    /// Var šķist, ka šeit ir problēma ar salona mainīgumu: faktiski *ir* iespējams pārvietot `T` no `&RefCell<T>`.
    /// Tomēr tā nav problēma, kamēr nepastāv arī `Pin<&T>`, kas norāda uz tiem pašiem datiem, un `RefCell<T>` neļauj izveidot piespraustu atsauci uz tā saturu.
    ///
    /// Plašāku informāciju skatiet diskusijā par ["pinning projections"].
    ///
    /// Note: `Pin` mērķim ievieš arī `Deref`, kuru var izmantot, lai piekļūtu iekšējai vērtībai.
    /// Tomēr `Deref` sniedz tikai atsauci, kas dzīvo tik ilgi, kamēr aizņemas `Pin`, nevis paša `Pin` kalpošanas laiku.
    /// Šī metode ļauj pārveidot `Pin` par atsauci ar tādu pašu kalpošanas laiku kā sākotnējam `Pin`.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Pārvērš šo `Pin<&mut T>` par `Pin<&T>` ar tādu pašu kalpošanas laiku.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Iegūst mainīgu atsauci uz datiem, kas atrodas šajā `Pin`.
    ///
    /// Tas prasa, lai dati šajā `Pin` būtu `Unpin`.
    ///
    /// Note: `Pin` arī ievieš datiem `DerefMut`, kurus var izmantot, lai piekļūtu iekšējai vērtībai.
    /// Tomēr `DerefMut` sniedz tikai atsauci, kas dzīvo tik ilgi, kamēr aizņemas `Pin`, nevis paša `Pin` kalpošanas laiku.
    ///
    /// Šī metode ļauj pārveidot `Pin` par atsauci ar tādu pašu kalpošanas laiku kā sākotnējam `Pin`.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Iegūst mainīgu atsauci uz datiem, kas atrodas šajā `Pin`.
    ///
    /// # Safety
    ///
    /// Šī funkcija ir nedroša.
    /// Jums ir jāgarantē, ka jūs nekad nepārvietosiet datus no maināmās atsauces, ko saņemat, izsaucot šo funkciju, lai `Pin` tipa invarianti tiktu saglabāti.
    ///
    ///
    /// Ja pamatā esošie dati ir `Unpin`, tā vietā jāizmanto `Pin::get_mut`.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Konstruējiet jaunu tapu, kartējot interjera vērtību.
    ///
    /// Piemēram, ja vēlaties iegūt `Pin` no kaut kā lauka, varat to izmantot, lai piekļūtu šim laukam vienā koda rindā.
    /// Tomēr ar šiem "pinning projections" ir vairākas gotchas;
    /// Plašāku informāciju par šo tēmu skatiet [`pin` module] dokumentācijā.
    ///
    /// # Safety
    ///
    /// Šī funkcija ir nedroša.
    /// Jums jāgarantē, ka atgrieztie dati netiks pārvietoti tik ilgi, kamēr nepārvietojas argumenta vērtība (piemēram, tāpēc, ka tas ir viens no šīs vērtības laukiem), kā arī tas, ka neizkļūstat no saņemtā argumenta iekšējā funkcija.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // DROŠĪBA: zvanītājs ir atbildīgs par tālruņa nepārvietošanu
        // vērtību no šīs atsauces.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // DROŠĪBA: tā kā `this` vērtībai garantēti nav
        // pārvietots, šis zvans uz `new_unchecked` ir drošs.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Saņemiet piesprausto atsauci no statiskās atsauces.
    ///
    /// Tas ir droši, jo `T` tiek aizņemts uz `'static` kalpošanas laiku, kas nekad nebeidzas.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // DROŠĪBA: statiskais aizņēmums garantē, ka dati nebūs
        // moved/invalidated līdz tas nokritīs (kas nekad nav).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Iegūstiet piestiprinātu maināmu atsauci no statiskas maināmas atsauces.
    ///
    /// Tas ir droši, jo `T` tiek aizņemts uz `'static` kalpošanas laiku, kas nekad nebeidzas.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // DROŠĪBA: statiskais aizņēmums garantē, ka dati nebūs
        // moved/invalidated līdz tas nokritīs (kas nekad nav).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: tas nozīmē, ka jebkurš `CoerceUnsized` implants, kas ļauj piespiest no
// tips, kas nozīmē `Deref<Target=impl !Unpin>` uz tipu, kas nozīmē `Deref<Target=Unpin>`, nav pamatots.
// Jebkurš šāds implants, iespējams, būtu nepamatots citu iemeslu dēļ, tāpēc mums vienkārši jārūpējas, lai šādus implikus nepieļautu std.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}