#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Satur strukturālās definīcijas kompilatoru iebūvēto tipu izkārtojumam.
//!
//! Tos var izmantot kā trafiku mērķus nedrošā kodā, lai tieši manipulētu ar neapstrādātiem attēlojumiem.
//!
//!
//! Viņu definīcijai vienmēr jāatbilst ABI, kas definēta `rustc_middle::ty::layout`.
//!

/// trait objekta, piemēram, `&dyn SomeTrait`, attēlojums.
///
/// Šai struktūrai ir tāds pats izkārtojums kā tipiem, piemēram, `&dyn SomeTrait` un `Box<dyn AnotherTrait>`.
///
/// `TraitObject` tiek garantēts, ka tas sakrīt ar izkārtojumiem, taču tas nav trait objektu tips (piemēram, lauki nav tieši pieejami `&dyn SomeTrait`), kā arī tas nekontrolē šo izkārtojumu (mainot definīciju, nemainīsies `&dyn SomeTrait` izkārtojums).
///
/// Tā ir paredzēta tikai nedroša koda lietošanai, kurai ir jārīkojas ar zema līmeņa detaļām.
///
/// Uz visiem trait objektiem nav iespējams atsaukties vispārīgi, tāpēc vienīgais veids, kā izveidot šāda veida vērtības, ir tādas funkcijas kā [`std::mem::transmute`][transmute].
/// Tāpat vienīgais veids, kā no `TraitObject` vērtības izveidot patiesu trait objektu, ir `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// trait objekta sintezēšana ar neatbilstošiem tipiem-tādu, kur vtable neatbilst vērtības tipam, uz kuru norāda datu rādītājs, visticamāk, novedīs pie nedefinētas uzvedības.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // piemērs trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // ļaujiet kompilatoram izveidot objektu trait
/// let object: &dyn Foo = &value;
///
/// // apskatīt neapstrādātu pārstāvību
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // datu rādītājs ir `value` adrese
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // uzbūvējiet jaunu objektu, norādot uz citu `i32`, uzmanīgi lietojot `i32` vtable no `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // tam vajadzētu darboties tieši tā, it kā mēs būtu tieši uzbūvējuši trait objektu no `other_value`
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}