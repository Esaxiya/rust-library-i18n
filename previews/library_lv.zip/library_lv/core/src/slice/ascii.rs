//! Darbības ar ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Pārbauda, vai visi šīs šķēles baiti ir ASCII diapazonā.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Pārbauda, vai divas šķēles atbilst ASCII lielajiem un mazajiem burtiem.
    ///
    /// Tas pats, kas `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, bet nepiešķirot un nekopējot īslaicīgus.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Pārvērš šo šķēli savā ASCII lielo burtu ekvivalentā vietā.
    ///
    /// ASCII burti 'a' līdz 'z' tiek kartēti ar 'A' līdz 'Z', bet burti, kas nav ASCII, nemainās.
    ///
    /// Lai atgrieztu jaunu lielās vērtības vērtību, nemodificējot esošo, izmantojiet [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Pārvērš šo šķēli savā ASCII mazo burtu ekvivalentā vietā.
    ///
    /// ASCII burti 'A' līdz 'Z' tiek kartēti ar 'a' līdz 'z', bet burti, kas nav ASCII, nemainās.
    ///
    /// Lai atgrieztu jaunu vērtību ar mazāku burtu, nemainot esošo, izmantojiet [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Atgriež vērtību `true`, ja kāds vārda `v` baits ir nonascii (>=128).
/// Snarfed no `../str/mod.rs`, kas utf8 validācijai veic kaut ko līdzīgu.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Optimizēts ASCII tests, kurā tiks izmantotas operācijas vienā reizē, nevis operācijas pa vienai (ja iespējams).
///
/// Algoritms, ko mēs šeit izmantojam, ir diezgan vienkāršs.Ja `s` ir pārāk īss, mēs vienkārši pārbaudām katru baitu un esam ar to galā.Pretējā gadījumā:
///
/// - Izlasiet pirmo vārdu ar nesaskaņotu slodzi.
/// - Izlīdziniet rādītāju, izlasiet nākamos vārdus līdz beigām ar izlīdzinātām slodzēm.
/// - Nolasiet pēdējo `usize` no `s` ar nesaskaņotu slodzi.
///
/// Ja kāda no šīm slodzēm rada kaut ko tādu, kam `contains_nonascii` (above) atgriež patiesu vērtību, tad mēs zinām, ka atbilde ir nepatiesa.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Ja mēs neko neiegūtu no ieviešanas vienā reizē, atgriezieties pie skalārā cikla.
    //
    // Mēs to darām arī arhitektūrām, kur `size_of::<usize>()` nav pietiekama izlīdzināšana `usize`, jo tas ir dīvains edge gadījums.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Pirmo vārdu mēs vienmēr lasām nesaskaņoti, kas nozīmē, ka `align_offset` ir
    // 0, mēs atkal nolasītu to pašu vērtību izlīdzinātajam lasījumam.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // DROŠĪBA: Mēs pārbaudām `len < USIZE_SIZE` iepriekš.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Mēs to kaut kā netieši pārbaudījām iepriekš.
    // Ņemiet vērā, ka `offset_to_aligned` ir vai nu `align_offset`, vai `USIZE_SIZE`, abi ir skaidri pārbaudīti iepriekš.
    //
    debug_assert!(offset_to_aligned <= len);

    // DROŠĪBA: word_ptr ir (pareizi izlīdzināts) usize ptr, kuru izmantojam, lai lasītu
    // šķēles vidējā daļa.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` ir `word_ptr` baitu indekss, ko izmanto cilpas beigu pārbaudēm.
    let mut byte_pos = offset_to_aligned;

    // Paranoja pārbauda izlīdzināšanu, jo mēs gatavojamies veikt daudz nesaskaņotu slodžu.
    // Tomēr praksē tam vajadzētu būt neiespējamam, lai novērstu kļūdu `align_offset`.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Lasiet nākamos vārdus līdz pēdējam izlīdzinātajam vārdam, izņemot pēdējo izlīdzināto vārdu, kas jāveic astes pārbaudē vēlāk, lai pārliecinātos, ka aste vienmēr ir viena `usize`, bet ne vairāk kā branch `byte_pos == len`.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Saprāta pārbaude, vai lasījums ir ierobežots
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // Un ka mūsu pieņēmumi par `byte_pos` ir spēkā.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // DROŠĪBA: Mēs zinām, ka `word_ptr` ir pareizi izlīdzināts (dēļ
        // `align_offset`), un mēs zinām, ka mums ir pietiekami daudz baitu starp `word_ptr` un beigām
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // DROŠĪBA: Mēs zinām, ka `byte_pos <= len - USIZE_SIZE`, tas nozīmē
        // pēc šī `add` `word_ptr` būs ne vairāk kā viens.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Veselības pārbaude, lai pārliecinātos, ka patiešām ir palicis tikai viens `usize`.
    // Tas jāgarantē mūsu cilpas stāvoklim.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // DROŠĪBA: Tas ir atkarīgs no `len >= USIZE_SIZE`, kuru mēs pārbaudām sākumā.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}