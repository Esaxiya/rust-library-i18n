// ignore-tidy-filelength

//! Šķēles pārvaldība un manipulācijas.
//!
//! Lai iegūtu sīkāku informāciju, skatiet [`std::slice`].
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// Tīra rust memchr ieviešana, ņemta no rust-memchr
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// Šī funkcija ir publiska tikai tāpēc, ka nav cita veida, kā testēt heapsort.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// Atgriež šķēlē esošo elementu skaitu.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // DROŠĪBA: const skaņa, jo mēs pārveidojam garuma lauku kā usize (kam tam jābūt)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // DROŠĪBA: tas ir droši, jo `&[T]` un `FatPtr<T>` ir vienāds izkārtojums.
            // Šo garantiju var sniegt tikai `std`.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: Nomainiet ar `crate::ptr::metadata(self)`, ja tas ir stabils.
            // Šajā rakstā tas izraisa "Const-stable functions can only call other const-stable functions" kļūdu.
            //

            // DROŠĪBA: Piekļuve vērtībai no savienojuma `PtrRepr` ir droša, jo * const T
            // un PtrComponents<T>ir vienādi atmiņas izkārtojumi.
            // Tikai std var sniegt šo garantiju.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// Atgriež vērtību `true`, ja šķēles garums ir 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Atgriež šķēles pirmo elementu vai `None`, ja tas ir tukšs.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Atgriež maināmu rādītāju šķēles pirmajam elementam vai `None`, ja tas ir tukšs.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Atgriež pirmo un visus pārējos šķēles elementus vai `None`, ja tas ir tukšs.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Atgriež pirmo un visus pārējos šķēles elementus vai `None`, ja tas ir tukšs.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Atgriež šķēles pēdējo un visus pārējos elementus vai `None`, ja tas ir tukšs.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Atgriež šķēles pēdējo un visus pārējos elementus vai `None`, ja tas ir tukšs.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Atgriež šķēles pēdējo elementu vai `None`, ja tas ir tukšs.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Atgriež maināmu rādītāju šķēles pēdējā vienumā.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Atgriež atsauci uz elementu vai apakšslāni atkarībā no indeksa veida.
    ///
    /// - Ja tiek dota pozīcija, atgriež atsauci uz elementu šajā pozīcijā vai `None`, ja tā ir ārpus robežas.
    ///
    /// - Ja tiek dots diapazons, atgriež apakšslāni, kas atbilst šim diapazonam, vai `None`, ja tā ir ārpus robežas.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// Atgriež maināmu atsauci uz elementu vai apakšslāni atkarībā no indeksa veida (sk. [`get`]) vai `None`, ja indekss ir ārpus robežas.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// Atgriež atsauci uz elementu vai apakšslāni, neveicot robežu pārbaudi.
    ///
    /// Drošu alternatīvu skatiet [`get`].
    ///
    /// # Safety
    ///
    /// Šīs metodes izsaukšana ar ārpus robežas esošo indeksu ir *[nenoteikta uzvedība]*, pat ja iegūtā atsauce netiek izmantota.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // DROŠĪBA: zvanītājam jāievēro lielākā daļa `get_unchecked` drošības prasību;
        // šķēle ir norobežojama, jo `self` ir droša atsauce.
        // Atgrieztais rādītājs ir drošs, jo `SliceIndex` implikiem ir jāgarantē, ka tas ir.
        unsafe { &*index.get_unchecked(self) }
    }

    /// Atgriež maināmu atsauci uz elementu vai apakšslāni, neveicot robežu pārbaudi.
    ///
    /// Drošu alternatīvu skatiet [`get_mut`].
    ///
    /// # Safety
    ///
    /// Šīs metodes izsaukšana ar ārpus robežas esošo indeksu ir *[nenoteikta uzvedība]*, pat ja iegūtā atsauce netiek izmantota.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // DROŠĪBA: zvanītājam jāievēro `get_unchecked_mut` drošības prasības;
        // šķēle ir norobežojama, jo `self` ir droša atsauce.
        // Atgrieztais rādītājs ir drošs, jo `SliceIndex` implikiem ir jāgarantē, ka tas ir.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// Atgriež neapstrādātu rādītāju šķēles buferī.
    ///
    /// Zvanītājam ir jānodrošina, lai šķēle pārdzīvotu rādītāju, kuru šī funkcija atgriež, pretējā gadījumā tā galu galā norādīs uz atkritumiem.
    ///
    /// Zvanītājam ir arī jānodrošina, lai atmiņa, uz kuru norāda rādītājs (non-transitively), nekad netiktu ierakstīta (izņemot `UnsafeCell` iekšpusē), izmantojot šo rādītāju vai jebkuru no tā atvasinātu rādītāju.
    /// Ja jums ir nepieciešams pārveidot šķēles saturu, izmantojiet [`as_mut_ptr`].
    ///
    /// Pārveidojot konteineru, uz kuru atsaucas šī šķēle, tā buferis var tikt pārdalīts, kā rezultātā visas norādes uz to būs nederīgas.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// Atgriež nedrošu maināmu rādītāju šķēles buferī.
    ///
    /// Zvanītājam ir jānodrošina, lai šķēle pārdzīvotu rādītāju, kuru šī funkcija atgriež, pretējā gadījumā tā galu galā norādīs uz atkritumiem.
    ///
    /// Pārveidojot konteineru, uz kuru atsaucas šī šķēle, tā buferis var tikt pārdalīts, kā rezultātā visas norādes uz to būs nederīgas.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// Atgriež divus neapstrādātus rādītājus, kas aptver šķēli.
    ///
    /// Atgrieztais diapazons ir pa pusei atvērts, kas nozīmē, ka gala rādītājs norāda *vienu pagātni* pēdējo šķēles elementu.
    /// Tādā veidā tukšu šķēli attēlo divi vienādi rādītāji, un starpība starp abiem rādītājiem norāda šķēles lielumu.
    ///
    /// Brīdinājumus par šo rādītāju lietošanu skatiet [`as_ptr`].Gala rādītājs prasa īpašu piesardzību, jo tas nenorāda uz derīgu elementu šķēlē.
    ///
    /// Šī funkcija ir noderīga, lai mijiedarbotos ar svešām saskarnēm, kas izmanto divus rādītājus, lai atsauktos uz atmiņas elementu diapazonu, kā tas ir kopīgi C++ .
    ///
    ///
    /// Var būt arī noderīgi pārbaudīt, vai rādītājs uz elementu attiecas uz šīs šķēles elementu:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // DROŠĪBA: `add` šeit ir drošs, jo:
        //
        //   - Abi rādītāji ir viena un tā paša objekta daļa, jo ir svarīga arī norādīšana tieši gar objektu.
        //
        //   - Šķēles lielums nekad nav lielāks par isize::MAX baitiem, kā norādīts šeit:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - Iesaistītais nav iesaiņojams, jo šķēles neaptinās gar adreses vietas beigām.
        //
        // Skatiet pointer::add dokumentāciju.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Atgriež divus nedrošos maināmos rādītājus, kas aptver šķēli.
    ///
    /// Atgrieztais diapazons ir pa pusei atvērts, kas nozīmē, ka gala rādītājs norāda *vienu pagātni* pēdējo šķēles elementu.
    /// Tādā veidā tukšu šķēli attēlo divi vienādi rādītāji, un starpība starp abiem rādītājiem norāda šķēles lielumu.
    ///
    /// Brīdinājumus par šo rādītāju lietošanu skatiet [`as_mut_ptr`].
    /// Gala rādītājs prasa īpašu piesardzību, jo tas nenorāda uz derīgu elementu šķēlē.
    ///
    /// Šī funkcija ir noderīga, lai mijiedarbotos ar svešām saskarnēm, kas izmanto divus rādītājus, lai atsauktos uz atmiņas elementu diapazonu, kā tas ir kopīgi C++ .
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // DROŠĪBA: Skatiet as_ptr_range() iepriekš, lai uzzinātu, kāpēc `add` šeit ir drošs.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Maina divus elementus šķēlē.
    ///
    /// # Arguments
    ///
    /// * a, Pirmā elementa indekss
    /// * b, otrā elementa indekss
    ///
    /// # Panics
    ///
    /// Panics, ja `a` vai `b` ir ārpus robežas.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // Nevar ņemt divus maināmus aizdevumus no viena vector, tāpēc izmantojiet neapstrādātas norādes.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // DROŠĪBA: `pa` un `pb` ir izveidoti no drošām mainīgām atsaucēm un atsaucēm
        // elementiem, un tāpēc tiek garantēts, ka tie ir derīgi un izlīdzināti.
        // Ņemiet vērā, ka piekļuve elementiem, kas atrodas aiz `a` un `b`, tiek pārbaudīta, un, ja tas nav atļauts, tas tiks panic.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// Apgriež elementu secību šķēlē vietā.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // Ļoti maziem tipiem visi indivīdi, kuri lasa normālā ceļā, darbojas slikti.
        // Mēs varam paveikt labāk, ņemot vērā efektīvo nesaskaņoto load/store, ielādējot lielāku gabalu un mainot reģistru.
        //

        // Ideālā gadījumā LLVM to darītu mūsu vietā, jo labāk nekā mēs zinām, vai nelīdzināti lasījumi ir efektīvi (jo tas, piemēram, mainās starp dažādām ARM versijām) un kāds būtu labākais gabala lielums.
        // Diemžēl, sākot ar LLVM 4.0 (2017-05), tas tikai atritina cilpu, tāpēc tas jādara mums pašiem.
        // (Hipotēze: reverss ir apgrūtinošs, jo malas var izlīdzināt atšķirīgi-būs, ja garums ir nepāra-tāpēc nav iespējas izstarot iepriekšēju un pēcnodokļu, lai vidū izmantotu pilnībā izlīdzinātu SIMD.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // Izmantojiet llvm.bswap raksturīgo, lai mainītu u8 lietotājā
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // DROŠĪBA: Šeit ir jāpārbauda vairākas lietas:
                //
                // - Ņemiet vērā, ka `chunk` ir vai nu 4, vai 8 iepriekšminētās cfg pārbaudes dēļ.Tātad `chunk - 1` ir pozitīvs.
                // - Indeksēšana ar indeksu `i` ir laba, jo cilpas pārbaude garantē
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - Indeksēšana ar indeksu `ln - i - chunk = ln - (i + chunk)` ir piemērota:
                //   - `i + chunk > 0` ir triviāli taisnība.
                //   - Cilpas pārbaude garantē:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, tādējādi atņemšana nepietiek.
                // - `read_unaligned` un `write_unaligned` zvani ir labi:
                //   - `pa` norāda uz indeksu `i`, kur `i < ln / 2 - (chunk - 1)` (skatīt iepriekš) un `pb` norāda uz indeksu `ln - i - chunk`, tāpēc abi ir vismaz `chunk` daudz baitu attālumā no `self` beigām.
                //
                //   - Jebkura inicializēta atmiņa ir derīga `usize`.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // Izmantojiet rotāciju par 16, lai mainītu u16 X X X
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // DROŠĪBA: Nesaskaņotu u32 var nolasīt no `i`, ja `i + 1 < ln`
                // (un acīmredzot `i < ln`), jo katrs elements ir 2 baiti un mēs lasām 4.
                //
                // `i + chunk - 1 < ln / 2` # kamēr stāvoklis
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // Tā kā tas ir mazāks par garumu, kas dalīts ar 2, tam ir jābūt robežās.
                //
                // Tas arī nozīmē, ka vienmēr tiek ievērots nosacījums `0 < i + chunk <= ln`, nodrošinot, ka `pb` rādītāju var droši izmantot.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // DROŠĪBA: `i` ir mazāks par pusi no šķēles garuma
            // piekļuve `i` un `ln - i - 1` ir droša (`i` sākas ar 0 un netiks tālāk par `ln / 2 - 1`).
            // Rezultātā iegūtās norādes `pa` un `pb` ir derīgas un izlīdzinātas, un no tām var nolasīt un rakstīt.
            //
            //
            unsafe {
                // Nedrošs mijmaiņas darījums, lai izvairītos no robežas pārbaudes drošā mijmaiņā.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// Atgriež iteratoru virs šķēles.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// Atgriež atkārtotāju, kas ļauj modificēt katru vērtību.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// Atgriež iteratoru visā blakus esošajā windows garumā `size`.
    /// windows pārklājas.
    /// Ja šķēle ir īsāka par `size`, iterators neatgriež vērtības.
    ///
    /// # Panics
    ///
    /// Panics, ja `size` ir 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Ja šķēle ir īsāka par `size`:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// Atgriež iteratoru virs `chunk_size` šķēles elementiem vienlaikus, sākot no šķēles sākuma.
    ///
    /// Gabali ir šķēles un nepārklājas.Ja `chunk_size` nedala šķēles garumu, tad pēdējam gabalam nebūs garuma `chunk_size`.
    ///
    /// Skatiet [`chunks_exact`], lai uzzinātu šī iteratora variantu, kas vienmērīgi atdod `chunk_size` elementu fragmentus, un [`rchunks`] tam pašam iteratoram, bet sākot no šķēles beigām.
    ///
    ///
    /// # Panics
    ///
    /// Panics, ja `chunk_size` ir 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// Atgriež iteratoru virs `chunk_size` šķēles elementiem vienlaikus, sākot no šķēles sākuma.
    ///
    /// Gabali ir maināmas šķēles un nepārklājas.Ja `chunk_size` nedala šķēles garumu, tad pēdējam gabalam nebūs garuma `chunk_size`.
    ///
    /// Skatiet [`chunks_exact_mut`], lai uzzinātu šī iteratora variantu, kas vienmērīgi atdod `chunk_size` elementu fragmentus, un [`rchunks_mut`] tam pašam iteratoram, bet sākot no šķēles beigām.
    ///
    ///
    /// # Panics
    ///
    /// Panics, ja `chunk_size` ir 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// Atgriež iteratoru virs `chunk_size` šķēles elementiem vienlaikus, sākot no šķēles sākuma.
    ///
    /// Gabali ir šķēles un nepārklājas.
    /// Ja `chunk_size` nedala šķēles garumu, pēdējie līdz `chunk_size-1` elementi tiks izlaisti un tos var iegūt no iteratora funkcijas `remainder`.
    ///
    ///
    /// Tā kā katram gabalam ir precīzi `chunk_size` elementi, kompilators bieži var optimizēt iegūto kodu labāk nekā [`chunks`] gadījumā.
    ///
    /// Sk. [`chunks`], lai iegūtu šī iteratora variantu, kas arī atdod atlikušo daļu kā mazāku gabalu, un [`rchunks_exact`]-tam pašam iteratoram, bet sākot no šķēles beigām.
    ///
    /// # Panics
    ///
    /// Panics, ja `chunk_size` ir 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// Atgriež iteratoru virs `chunk_size` šķēles elementiem vienlaikus, sākot no šķēles sākuma.
    ///
    /// Gabali ir maināmas šķēles un nepārklājas.
    /// Ja `chunk_size` nedala šķēles garumu, pēdējie līdz `chunk_size-1` elementi tiks izlaisti un tos var iegūt no iteratora funkcijas `into_remainder`.
    ///
    ///
    /// Tā kā katram gabalam ir precīzi `chunk_size` elementi, kompilators bieži var optimizēt iegūto kodu labāk nekā [`chunks_mut`] gadījumā.
    ///
    /// Sk. [`chunks_mut`], lai iegūtu šī iteratora variantu, kas arī atdod atlikušo daļu kā mazāku gabalu, un [`rchunks_exact_mut`]-tam pašam iteratoram, bet sākot no šķēles beigām.
    ///
    /// # Panics
    ///
    /// Panics, ja `chunk_size` ir 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// Sadaliet šķēli "N" elementu masīvu šķēlē, pieņemot, ka nav atlikuma.
    ///
    ///
    /// # Safety
    ///
    /// To var saukt tikai tad, kad
    /// - Šķēle precīzi sadalās N elementa gabalos (jeb `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // DROŠĪBA: 1 elementa gabaliem nekad nav atlikuma
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // DROŠĪBA: šķēles garums (6) ir 3 reizinājums
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // Tas būtu nepamatoti:
    /// // ļaujiet gabaliņiem: &[[_;5]]= slice.as_chunks_unchecked()//Šķēles garums nav reizinājums ar 5 ļautiem gabaliem:&[[_;0]]= slice.as_chunks_unchecked()//Nulles garuma gabali nekad nav atļauti
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // DROŠĪBA: Mūsu priekšnoteikums ir tieši tas, kas vajadzīgs, lai to sauktu
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // DROŠĪBA: Mēs ievietojam `new_len * N` elementu šķēli
        // `new_len` šķēle ar daudziem `N` elementu gabaliņiem.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// Sadaliet šķēli "N" elementu masīvu šķēlē, sākot no šķēles sākuma, un pārējā šķēlē, kuras garums ir stingri mazāks par `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics, ja `N` ir 0. Šī pārbaude, visticamāk, tiks mainīta uz kompilēšanas laika kļūdu, pirms šī metode tiek stabilizēta.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // DROŠĪBA: Mēs jau bijām panikā par nulli, un to nodrošināja būvniecība
        // ka apakšslāņa garums ir N reizinājums.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// Sadaliet šķēli "N" elementu masīvu šķēlē, sākot no šķēles beigām, un pārējā šķēlē, kuras garums ir stingri mazāks par `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics, ja `N` ir 0. Šī pārbaude, visticamāk, tiks mainīta uz kompilēšanas laika kļūdu, pirms šī metode tiek stabilizēta.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // DROŠĪBA: Mēs jau bijām panikā par nulli, un to nodrošināja būvniecība
        // ka apakšslāņa garums ir N reizinājums.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// Atgriež iteratoru virs `N` šķēles elementiem vienlaikus, sākot no šķēles sākuma.
    ///
    /// Gabali ir masīva atsauces un nepārklājas.
    /// Ja `N` nedala šķēles garumu, pēdējie līdz `N-1` elementi tiks izlaisti un tos var iegūt no iteratora funkcijas `remainder`.
    ///
    ///
    /// Šī metode ir [`chunks_exact`] konstettais ekvivalents.
    ///
    /// # Panics
    ///
    /// Panics, ja `N` ir 0. Šī pārbaude, visticamāk, tiks mainīta uz kompilēšanas laika kļūdu, pirms šī metode tiek stabilizēta.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// Sadaliet šķēli "N" elementu masīvu šķēlē, pieņemot, ka nav atlikuma.
    ///
    ///
    /// # Safety
    ///
    /// To var saukt tikai tad, kad
    /// - Šķēle precīzi sadalās N elementa gabalos (jeb `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // DROŠĪBA: 1 elementa gabaliem nekad nav atlikuma
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // DROŠĪBA: šķēles garums (6) ir 3 reizinājums
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // Tas būtu nepamatoti:
    /// // ļaujiet gabaliņiem: &[[_;5]]= slice.as_chunks_unchecked_mut()//Šķēles garums nav reizinājums ar 5 ļautiem gabaliem:&[[_;0]]= slice.as_chunks_unchecked_mut()//Nulles garuma gabali nekad nav atļauti
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // DROŠĪBA: Mūsu priekšnoteikums ir tieši tas, kas vajadzīgs, lai to sauktu
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // DROŠĪBA: Mēs ievietojam `new_len * N` elementu šķēli
        // `new_len` šķēle ar daudziem `N` elementu gabaliņiem.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// Sadaliet šķēli "N" elementu masīvu šķēlē, sākot no šķēles sākuma, un pārējā šķēlē, kuras garums ir stingri mazāks par `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics, ja `N` ir 0. Šī pārbaude, visticamāk, tiks mainīta uz kompilēšanas laika kļūdu, pirms šī metode tiek stabilizēta.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // DROŠĪBA: Mēs jau bijām panikā par nulli, un to nodrošināja būvniecība
        // ka apakšslāņa garums ir N reizinājums.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// Sadaliet šķēli "N" elementu masīvu šķēlē, sākot no šķēles beigām, un pārējā šķēlē, kuras garums ir stingri mazāks par `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics, ja `N` ir 0. Šī pārbaude, visticamāk, tiks mainīta uz kompilēšanas laika kļūdu, pirms šī metode tiek stabilizēta.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // DROŠĪBA: Mēs jau bijām panikā par nulli, un to nodrošināja būvniecība
        // ka apakšslāņa garums ir N reizinājums.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// Atgriež iteratoru virs `N` šķēles elementiem vienlaikus, sākot no šķēles sākuma.
    ///
    /// Gabali ir maināmas masīva atsauces un nepārklājas.
    /// Ja `N` nedala šķēles garumu, pēdējie līdz `N-1` elementi tiks izlaisti un tos var iegūt no iteratora funkcijas `into_remainder`.
    ///
    ///
    /// Šī metode ir [`chunks_exact_mut`] konstettais ekvivalents.
    ///
    /// # Panics
    ///
    /// Panics, ja `N` ir 0. Šī pārbaude, visticamāk, tiks mainīta uz kompilēšanas laika kļūdu, pirms šī metode tiek stabilizēta.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// Atgriež atkārtotāju, kas pārklāj windows daļas `N` elementus, sākot no šķēles sākuma.
    ///
    ///
    /// Tas ir [`windows`] konst generālais ekvivalents.
    ///
    /// Ja `N` ir lielāks par šķēles lielumu, windows netiek atgriezts.
    ///
    /// # Panics
    ///
    /// Panics, ja `N` ir 0.
    /// Šī pārbaude, visticamāk, tiks mainīta uz kompilēšanas laika kļūdu, pirms šī metode tiks stabilizēta.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// Atgriež iteratoru virs `chunk_size` šķēles elementiem vienlaikus, sākot no šķēles beigām.
    ///
    /// Gabali ir šķēles un nepārklājas.Ja `chunk_size` nedala šķēles garumu, tad pēdējam gabalam nebūs garuma `chunk_size`.
    ///
    /// Skatiet [`rchunks_exact`], lai uzzinātu šī iteratora variantu, kas atgriež vienmērīgi `chunk_size` elementu fragmentus, un [`chunks`] tam pašam iteratoram, bet sākot no šķēles sākuma.
    ///
    ///
    /// # Panics
    ///
    /// Panics, ja `chunk_size` ir 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// Atgriež iteratoru virs `chunk_size` šķēles elementiem vienlaikus, sākot no šķēles beigām.
    ///
    /// Gabali ir maināmas šķēles un nepārklājas.Ja `chunk_size` nedala šķēles garumu, tad pēdējam gabalam nebūs garuma `chunk_size`.
    ///
    /// Skatiet [`rchunks_exact_mut`], lai uzzinātu šī iteratora variantu, kas vienmērīgi atdod elementus ar precīzi `chunk_size` elementiem, un [`chunks_mut`]-par to pašu iteratoru, bet sākot no šķēles sākuma.
    ///
    ///
    /// # Panics
    ///
    /// Panics, ja `chunk_size` ir 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// Atgriež iteratoru virs `chunk_size` šķēles elementiem vienlaikus, sākot no šķēles beigām.
    ///
    /// Gabali ir šķēles un nepārklājas.
    /// Ja `chunk_size` nedala šķēles garumu, pēdējie līdz `chunk_size-1` elementi tiks izlaisti un tos var iegūt no iteratora funkcijas `remainder`.
    ///
    /// Tā kā katram gabalam ir precīzi `chunk_size` elementi, kompilators bieži var optimizēt iegūto kodu labāk nekā [`chunks`] gadījumā.
    ///
    /// Skatiet [`rchunks`], lai iegūtu šī iteratora variantu, kas arī atdod atlikušo daļu kā mazāku daļu, un [`chunks_exact`]-tam pašam iteratoram, bet sākot no šķēles sākuma.
    ///
    ///
    /// # Panics
    ///
    /// Panics, ja `chunk_size` ir 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// Atgriež iteratoru virs `chunk_size` šķēles elementiem vienlaikus, sākot no šķēles beigām.
    ///
    /// Gabali ir maināmas šķēles un nepārklājas.
    /// Ja `chunk_size` nedala šķēles garumu, pēdējie līdz `chunk_size-1` elementi tiks izlaisti un tos var iegūt no iteratora funkcijas `into_remainder`.
    ///
    /// Tā kā katram gabalam ir precīzi `chunk_size` elementi, kompilators bieži var optimizēt iegūto kodu labāk nekā [`chunks_mut`] gadījumā.
    ///
    /// Skatiet [`rchunks_mut`], lai skatītu šī iteratora variantu, kas arī pārējo atgriež kā mazāku daļu, un [`chunks_exact_mut`]-tam pašam iteratoram, bet sākot no šķēles sākuma.
    ///
    ///
    /// # Panics
    ///
    /// Panics, ja `chunk_size` ir 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// Atgriež iteratoru pār šķēli, kas ražo elementus, kas nepārklājas, izmantojot predikātu, lai tos atdalītu.
    ///
    /// Predikāts tiek izsaukts uz diviem elementiem, kuri seko paši sev, tas nozīmē, ka predikāts tiek izsaukts uz `slice[0]` un `slice[1]`, pēc tam uz `slice[1]` un `slice[2]` utt.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Šo metodi var izmantot, lai izgūtu sakārtotās apakšgrupas:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// Atgriež iteratoru pār šķēli, kas rada nepārklājas mainīgus elementu posmus, izmantojot predikātu, lai tos atdalītu.
    ///
    /// Predikāts tiek izsaukts uz diviem elementiem, kuri seko paši sev, tas nozīmē, ka predikāts tiek izsaukts uz `slice[0]` un `slice[1]`, pēc tam uz `slice[1]` un `slice[2]` utt.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Šo metodi var izmantot, lai izgūtu sakārtotās apakšgrupas:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// Indeksā vienu šķēli sadala divās.
    ///
    /// Pirmajā būs visi indeksi no `[0, mid)` (izņemot pašu indeksu `mid`), bet otrajā-visi indeksi no `[mid, len)` (izņemot pašu indeksu `len`).
    ///
    ///
    /// # Panics
    ///
    /// Panics, ja `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // DROŠĪBA: `[ptr; mid]` un `[mid; len]` atrodas `self` iekšpusē, kas
        // atbilst `from_raw_parts_mut` prasībām.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// Indeksā vienu maināmo šķēli sadala divās.
    ///
    /// Pirmajā būs visi indeksi no `[0, mid)` (izņemot pašu indeksu `mid`), bet otrajā-visi indeksi no `[mid, len)` (izņemot pašu indeksu `len`).
    ///
    ///
    /// # Panics
    ///
    /// Panics, ja `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // DROŠĪBA: `[ptr; mid]` un `[mid; len]` atrodas `self` iekšpusē, kas
        // atbilst `from_raw_parts_mut` prasībām.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// Indeksā vienu šķēli sadala divās, neveicot robežu pārbaudi.
    ///
    /// Pirmajā būs visi indeksi no `[0, mid)` (izņemot pašu indeksu `mid`), bet otrajā-visi indeksi no `[mid, len)` (izņemot pašu indeksu `len`).
    ///
    ///
    /// Drošu alternatīvu skatiet [`split_at`].
    ///
    /// # Safety
    ///
    /// Šīs metodes izsaukšana ar ārpus robežas esošo indeksu ir *[nenoteikta uzvedība]*, pat ja iegūtā atsauce netiek izmantota.Zvanītājam ir jānodrošina, lai `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // DROŠĪBA: Zvanītājam jāpārbauda, vai `0 <= mid <= self.len()`
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// Indeksā vienu maināmu šķēli sadala divās, neveicot robežu pārbaudi.
    ///
    /// Pirmajā būs visi indeksi no `[0, mid)` (izņemot pašu indeksu `mid`), bet otrajā-visi indeksi no `[mid, len)` (izņemot pašu indeksu `len`).
    ///
    ///
    /// Drošu alternatīvu skatiet [`split_at_mut`].
    ///
    /// # Safety
    ///
    /// Šīs metodes izsaukšana ar ārpus robežas esošo indeksu ir *[nenoteikta uzvedība]*, pat ja iegūtā atsauce netiek izmantota.Zvanītājam ir jānodrošina, lai `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // DROŠĪBA: Zvanītājam jāpārbauda, vai `0 <= mid <= self.len()`.
        //
        // `[ptr; mid]` un `[mid; len]` nepārklājas, tāpēc mainīgas atsauces atdošana ir piemērota.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// Atgriež iteratoru virs apakšslāņiem, kas atdalīti ar elementiem, kas atbilst `pred`.
    /// Atbilstošais elements apakšslānīs nav ietverts.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Ja pirmais elements ir saskaņots, tukša šķēle būs pirmais vienums, ko atdos atkārtotājs.
    /// Līdzīgi, ja tiek saskaņots pēdējais šķēles elements, tukša šķēle būs pēdējā iteratora atdotā vienība:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Ja divi saskaņoti elementi atrodas tieši blakus, starp tiem būs tukša šķēle:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// Atgriež atkārtotāju pār maināmām apakšslēmām, kuras atdala ar elementiem, kas atbilst `pred`.
    /// Atbilstošais elements apakšslānīs nav ietverts.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// Atgriež iteratoru virs apakšslāņiem, kas atdalīti ar elementiem, kas atbilst `pred`.
    /// Saskaņotais elements ir iekļauts iepriekšējā apakšslāņa beigās kā terminators.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Ja tiek saskaņots šķēles pēdējais elements, šis elements tiks uzskatīts par iepriekšējās šķēles beigu daļu.
    ///
    /// Šī šķēle būs pēdējā iteratora atdotā vienība.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// Atgriež atkārtotāju pār maināmām apakšslēmām, kuras atdala ar elementiem, kas atbilst `pred`.
    /// Saskaņotais elements ir iekļauts iepriekšējā apakšslānī kā terminators.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// Atgriež iteratoru virs apakšslāņiem, kas atdalīti ar elementiem, kas atbilst `pred`, sākot no šķēles beigām un strādājot atpakaļ.
    /// Atbilstošais elements apakšslānīs nav ietverts.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Tāpat kā ar `split()`, ja pirmais vai pēdējais elements ir saskaņots, tukša šķēle būs pirmais (vai pēdējais) vienums, ko atgriezis atkārtotājs.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// Atgriež atkārtotāju maināmām apakšslāņiem, kas atdalīti ar elementiem, kas atbilst `pred`, sākot no šķēles beigām un strādājot atpakaļ.
    /// Atbilstošais elements apakšslānīs nav ietverts.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// Atgriež iteratoru virs apakšgrupām, kas atdalītas ar elementiem, kas atbilst `pred`, ierobežojot līdz maksimāli `n` vienumu atgriešanai.
    /// Atbilstošais elements apakšslānīs nav ietverts.
    ///
    /// Pēdējais atgrieztais elements, ja tāds ir, satur atlikušo daļu.
    ///
    /// # Examples
    ///
    /// Izdrukājiet šķēles sadalījumu vienu reizi pēc skaitļiem, kas dalās ar 3 (ti, `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// Atgriež iteratoru virs apakšgrupām, kas atdalītas ar elementiem, kas atbilst `pred`, ierobežojot līdz maksimāli `n` vienumu atgriešanai.
    /// Atbilstošais elements apakšslānīs nav ietverts.
    ///
    /// Pēdējais atgrieztais elements, ja tāds ir, satur atlikušo daļu.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// Atgriež atkārtotāju apakškārtām, kas atdalītas ar elementiem, kas atbilst `pred`, kas ierobežots līdz maksimāli `n` vienumu atgriešanai.
    /// Tas sākas šķēles beigās un darbojas atpakaļ.
    /// Atbilstošais elements apakšslānīs nav ietverts.
    ///
    /// Pēdējais atgrieztais elements, ja tāds ir, satur atlikušo daļu.
    ///
    /// # Examples
    ///
    /// Izdrukājiet šķēles sadalījumu vienu reizi, sākot no beigām, ar skaitļiem, kas dalās ar 3 (ti, `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// Atgriež atkārtotāju apakškārtām, kas atdalītas ar elementiem, kas atbilst `pred`, kas ierobežots līdz maksimāli `n` vienumu atgriešanai.
    /// Tas sākas šķēles beigās un darbojas atpakaļ.
    /// Atbilstošais elements apakšslānīs nav ietverts.
    ///
    /// Pēdējais atgrieztais elements, ja tāds ir, satur atlikušo daļu.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// Atgriež `true`, ja šķēlē ir elements ar norādīto vērtību.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// Ja jums nav `&T`, bet tikai `&U`, piemēram, `T: Borrow<U>` (piem.,
    /// `Stīga: aizņemies<str>`), varat izmantot `iter().any`:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // `String` šķēle
    /// assert!(v.iter().any(|e| e == "hello")); // meklēt ar `&str`
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// Atgriež `true`, ja `needle` ir šķēles prefikss.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// Vienmēr atgriež `true`, ja `needle` ir tukša šķēle:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// Atgriež vērtību `true`, ja `needle` ir šķēles sufikss.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// Vienmēr atgriež `true`, ja `needle` ir tukša šķēle:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// Atgriež apakšslāni ar noņemtu prefiksu.
    ///
    /// Ja šķēle sākas ar `prefix`, pēc prefiksa atgriež apakšslāni, ietinot `Some`.
    /// Ja `prefix` ir tukšs, vienkārši atgriež sākotnējo šķēli.
    ///
    /// Ja šķēle nesākas ar `prefix`, atgriež vērtību `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Šī funkcija būs jāpārraksta, ja un kad SlicePattern kļūs sarežģītāka.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// Atgriež apakšslāni ar noņemtu sufiksu.
    ///
    /// Ja šķēle beidzas ar `suffix`, atgriež apakšslāni pirms sufiksa, ietinot `Some`.
    /// Ja `suffix` ir tukšs, vienkārši atgriež sākotnējo šķēli.
    ///
    /// Ja šķēle nebeidzas ar `suffix`, atgriež vērtību `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Šī funkcija būs jāpārraksta, ja un kad SlicePattern kļūs sarežģītāka.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// Binārais meklē doto elementu šajā sakārtotajā šķēlē.
    ///
    /// Ja vērtība ir atrasta, tiek atgriezta [`Result::Ok`], kas satur atbilstošā elementa indeksu.
    /// Ja ir vairākas spēles, tad jebkuru no tām var atgriezt.
    /// Ja vērtība nav atrasta, tiek atgriezta [`Result::Err`], kas satur indeksu, kurā varētu ievietot atbilstošu elementu, saglabājot sakārtoto secību.
    ///
    ///
    /// Skatiet arī [`binary_search_by`], [`binary_search_by_key`] un [`partition_point`].
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Uzmeklē četru elementu sēriju.
    /// Pirmais ir atrasts ar unikāli noteiktu pozīciju;otrais un trešais nav atrasts;ceturtais varētu atbilst jebkurai pozīcijai `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// Ja vēlaties ievietot vienumu sakārtotā vector, saglabājot kārtošanas kārtību:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// Binārais meklē šo sakārtoto šķēli ar salīdzināšanas funkciju.
    ///
    /// Salīdzinošajai funkcijai jāievieš kārtība, kas atbilst pamatā esošās šķēles kārtojuma kārtībai, atgriežot pasūtījuma kodu, kas norāda, vai tās arguments ir vēlamais mērķis `Less`, `Equal` vai `Greater`.
    ///
    ///
    /// Ja vērtība ir atrasta, tiek atgriezta [`Result::Ok`], kas satur atbilstošā elementa indeksu.Ja ir vairākas spēles, tad jebkuru no tām var atgriezt.
    /// Ja vērtība nav atrasta, tiek atgriezta [`Result::Err`], kas satur indeksu, kurā varētu ievietot atbilstošu elementu, saglabājot sakārtoto secību.
    ///
    /// Skatiet arī [`binary_search`], [`binary_search_by_key`] un [`partition_point`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Uzmeklē četru elementu sēriju.Pirmais ir atrasts ar unikāli noteiktu pozīciju;otrais un trešais nav atrasts;ceturtais varētu atbilst jebkurai pozīcijai `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // DROŠĪBA: zvanu padara drošu šādi nemainīgie:
            // - `mid >= 0`
            // - `mid < size`: `mid` ir ierobežots ar saistītu `[left; right)`.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // Iemesls, kāpēc mēs izmantojam if/else vadības plūsmu, nevis spēli, ir tāpēc, ka spēles pārkārto salīdzināšanas operācijas, kas ir ļoti jutīgas.
            //
            // u8 ir x86 asm: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// Binārais meklē šo sakārtoto šķēli ar atslēgas izvilkšanas funkciju.
    ///
    /// Pieņem, ka šķēle ir sakārtota pēc atslēgas, piemēram, ar [`sort_by_key`], izmantojot to pašu atslēgas izvilkšanas funkciju.
    ///
    /// Ja vērtība ir atrasta, tiek atgriezta [`Result::Ok`], kas satur atbilstošā elementa indeksu.
    /// Ja ir vairākas spēles, tad jebkuru no tām var atgriezt.
    /// Ja vērtība nav atrasta, tiek atgriezta [`Result::Err`], kas satur indeksu, kurā varētu ievietot atbilstošu elementu, saglabājot sakārtoto secību.
    ///
    ///
    /// Skatiet arī [`binary_search`], [`binary_search_by`] un [`partition_point`].
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Pārmeklē četru elementu sēriju pāru šķēlē, kas sakārtoti pēc viņu otrajiem elementiem.
    /// Pirmais ir atrasts ar unikāli noteiktu pozīciju;otrais un trešais nav atrasts;ceturtais varētu atbilst jebkurai pozīcijai `[1, 4]`.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // Lint rustdoc::broken_intra_doc_links ir atļauts, jo `slice::sort_by_key` ir crate `alloc`, un kā tāds vēl nav, veidojot `core`.
    //
    // saites uz pakārtoto crate: #74481.Tā kā primitīvi ir dokumentēti tikai libstd (#73423), praksē tas nekad nenoved pie sašķeltām saitēm.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Šķēle šķēle, bet var nebūt saglabāta vienādu elementu secība.
    ///
    /// Šis veids ir nestabils (ti, var pārkārtot vienādus elementus), atrodas vietā (ti, nepiešķir) un *O*(*n*\*log(* n*)) sliktākajā gadījumā.
    ///
    /// # Pašreizējā ieviešana
    ///
    /// Pašreizējais algoritms ir balstīts uz Orsona Pītersa [pattern-defeating quicksort][pdqsort], kas apvieno randomizēto pikasortu ātro vidējo gadījumu ar ātrāko sliktāko heapsort gadījumu, vienlaikus sasniedzot lineāru laiku šķēlēs ar noteiktiem modeļiem.
    /// Lai izvairītos no deģenerētiem gadījumiem, tas izmanto zināmu randomizāciju, bet ar fiksētu seed vienmēr nodrošina deterministisku uzvedību.
    ///
    /// Parasti tā ir ātrāka nekā stabila šķirošana, izņemot dažus īpašus gadījumus, piemēram, kad šķēle sastāv no vairākām saķepinātām sakārtotām sekvencēm.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// Šķēle šķēle ar salīdzināšanas funkciju, taču var netikt saglabāta vienādu elementu secība.
    ///
    /// Šis veids ir nestabils (ti, var pārkārtot vienādus elementus), atrodas vietā (ti, nepiešķir) un *O*(*n*\*log(* n*)) sliktākajā gadījumā.
    ///
    /// Komparatora funkcijai ir jānosaka kopējais elementu secība šķēlē.Ja pasūtījums nav pilnīgs, elementu secība nav noteikta.Pasūtījums ir kopējais pasūtījums, ja tāds ir (visiem `a`, `b` un `c`):
    ///
    /// * kopējais un antisimetriskais: precīzi viens no `a < b`, `a == b` vai `a > b` ir patiess, un
    /// * transitīvs, `a < b` un `b < c` nozīmē `a < c`.Tas pats jāattiecina gan uz `==`, gan uz `>`.
    ///
    /// Piemēram, lai gan [`f64`] neievieš [`Ord`], jo `NaN != NaN`, mēs varam izmantot `partial_cmp` kā savu kārtošanas funkciju, ja zinām, ka šķēle nesatur `NaN`.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # Pašreizējā ieviešana
    ///
    /// Pašreizējais algoritms ir balstīts uz Orsona Pītersa [pattern-defeating quicksort][pdqsort], kas apvieno randomizēto pikasortu ātro vidējo gadījumu ar ātrāko sliktāko heapsort gadījumu, vienlaikus sasniedzot lineāru laiku šķēlēs ar noteiktiem modeļiem.
    /// Lai izvairītos no deģenerētiem gadījumiem, tas izmanto zināmu randomizāciju, bet ar fiksētu seed vienmēr nodrošina deterministisku uzvedību.
    ///
    /// Parasti tā ir ātrāka nekā stabila šķirošana, izņemot dažus īpašus gadījumus, piemēram, kad šķēle sastāv no vairākām saķepinātām sakārtotām sekvencēm.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // reversā šķirošana
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// Šķēle šķēle ar atslēgas izvilkšanas funkciju, taču var netikt saglabāta vienādu elementu secība.
    ///
    /// Šis veids ir nestabils (ti, var pārkārtot vienādus elementus), atrodas vietā (ti, nepiešķir) un *O*(m\* * n *\* log(*n*)) sliktākajā gadījumā, kur galvenā funkcija ir *O*(*m*).
    ///
    /// # Pašreizējā ieviešana
    ///
    /// Pašreizējais algoritms ir balstīts uz Orsona Pītersa [pattern-defeating quicksort][pdqsort], kas apvieno randomizēto pikasortu ātro vidējo gadījumu ar ātrāko sliktāko heapsort gadījumu, vienlaikus sasniedzot lineāru laiku šķēlēs ar noteiktiem modeļiem.
    /// Lai izvairītos no deģenerētiem gadījumiem, tas izmanto zināmu randomizāciju, bet ar fiksētu seed vienmēr nodrošina deterministisku uzvedību.
    ///
    /// Sakarā ar galveno zvana stratēģiju, [`sort_unstable_by_key`](#method.sort_unstable_by_key), visticamāk, būs lēnāks nekā [`sort_by_cached_key`](#method.sort_by_cached_key) gadījumos, kad atslēgas funkcija ir dārga.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Pārkārtojiet šķēli tā, lai elements `index` būtu tā kārtotajā pozīcijā.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// Pārkārtojiet šķēli ar salīdzināšanas funkciju tā, lai `index` elements būtu pēdējā sakārtotajā pozīcijā.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// Pārkārtojiet šķēli ar atslēgas izvilkšanas funkciju tā, lai `index` elements būtu pēdējā sakārtotajā pozīcijā.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// Pārkārtojiet šķēli tā, lai elements `index` būtu tā kārtotajā pozīcijā.
    ///
    /// Šai pārkārtošanai ir papildu īpašība, ka jebkura vērtība `i < index` pozīcijā būs mazāka vai vienāda ar jebkuru vērtību `j > index` pozīcijā.
    /// Turklāt šī pārkārtošana ir nestabila (ti
    /// jebkurš vienādu elementu skaits var nonākt pozīcijā `index`), vietā (ti
    /// nepiešķir), un *O*(*n*) sliktākajā gadījumā.
    /// Šī funkcija citās bibliotēkās ir/ir pazīstama arī kā "kth element".
    /// Tas atgriež šādu vērtību tripletu: visi elementi, kas ir mazāki par elementu dotajā indeksā, vērtība dotajā indeksā un visi elementi, kas ir lielāki par norādītajā indeksā esošo.
    ///
    ///
    /// # Pašreizējā ieviešana
    ///
    /// Pašreizējais algoritms ir balstīts uz tā paša quicksort algoritma quickselect daļu, ko izmanto [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics, kad `index >= len()`, tas nozīmē, ka tas vienmēr ir panics tukšās šķēlēs.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Atrodiet vidējo
    /// v.select_nth_unstable(2);
    ///
    /// // Mums tiek garantēts, ka šķēle būs viena no šīm, pamatojoties uz veidu, kā mēs kārtojam norādīto indeksu.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// Pārkārtojiet šķēli ar salīdzināšanas funkciju tā, lai `index` elements būtu pēdējā sakārtotajā pozīcijā.
    ///
    /// Šai pārkārtošanai ir papildu īpašība, ka jebkura vērtība `i < index` pozīcijā būs mazāka vai vienāda ar jebkuru vērtību `j > index` pozīcijā, izmantojot salīdzināšanas funkciju.
    /// Turklāt šī pārkārtošana ir nestabila (ti, jebkurš vienādu elementu skaits var nonākt pozīcijā `index`), atrodas vietā (ti, nepiešķir) un sliktākajā gadījumā *O*(*n*).
    /// Šī funkcija citās bibliotēkās ir pazīstama arī kā "kth element".
    /// Tas atgriež šādu vērtību tripletu: visi elementi, kas ir mazāki par elementu dotajā indeksā, vērtība dotajā indeksā un visi elementi, kas ir lielāki par norādītajā indeksā esošo, izmantojot norādīto salīdzinošo funkciju.
    ///
    ///
    /// # Pašreizējā ieviešana
    ///
    /// Pašreizējais algoritms ir balstīts uz tā paša quicksort algoritma quickselect daļu, ko izmanto [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics, kad `index >= len()`, tas nozīmē, ka tas vienmēr ir panics tukšās šķēlēs.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Atrodiet mediānu tā, it kā šķēle būtu sakārtota dilstošā secībā.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // Mums tiek garantēts, ka šķēle būs viena no šīm, pamatojoties uz veidu, kā mēs kārtojam norādīto indeksu.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// Pārkārtojiet šķēli ar atslēgas izvilkšanas funkciju tā, lai `index` elements būtu pēdējā sakārtotajā pozīcijā.
    ///
    /// Šai pārkārtošanai ir papildu īpašība, ka jebkura vērtība `i < index` pozīcijā būs mazāka vai vienāda ar jebkuru vērtību `j > index` pozīcijā, izmantojot taustiņu izvilkšanas funkciju.
    /// Turklāt šī pārkārtošana ir nestabila (ti, jebkurš vienādu elementu skaits var nonākt pozīcijā `index`), atrodas vietā (ti, nepiešķir) un sliktākajā gadījumā *O*(*n*).
    /// Šī funkcija citās bibliotēkās ir pazīstama arī kā "kth element".
    /// Tas atgriež šādu vērtību tripletu: visi elementi, kas ir mazāki par elementu dotajā indeksā, vērtība dotajā indeksā un visi elementi, kas ir lielāki par norādītajā indeksā esošo, izmantojot norādīto atslēgas izvilkšanas funkciju.
    ///
    ///
    /// # Pašreizējā ieviešana
    ///
    /// Pašreizējais algoritms ir balstīts uz tā paša quicksort algoritma quickselect daļu, ko izmanto [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics, kad `index >= len()`, tas nozīmē, ka tas vienmēr ir panics tukšās šķēlēs.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Atgrieziet mediānu tā, it kā masīvs būtu sakārtots pēc absolūtās vērtības.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // Mums tiek garantēts, ka šķēle būs viena no šīm, pamatojoties uz veidu, kā mēs kārtojam norādīto indeksu.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// Pārvieto visus secīgos atkārtotos elementus uz šķēles galu atbilstoši [`PartialEq`] trait ieviešanai.
    ///
    ///
    /// Atgriež divas šķēles.Pirmajā nav secīgu atkārtotu elementu.
    /// Otrais satur visus dublikātus noteiktā secībā.
    ///
    /// Ja šķēle ir sakārtota, pirmā atgrieztā šķēle nesatur dublikātus.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// Pārvieto visus, izņemot pirmo no secīgajiem elementiem, uz šķēles beigām, kas atbilst noteiktajai vienlīdzības attiecībai.
    ///
    /// Atgriež divas šķēles.Pirmajā nav secīgu atkārtotu elementu.
    /// Otrais satur visus dublikātus noteiktā secībā.
    ///
    /// Funkcijai `same_bucket` tiek nodotas atsauces uz diviem elementa elementiem, un tai jānosaka, vai elementi ir vienādi.
    /// Elementi tiek nodoti pretējā secībā nekā to secība šķēlītē, tādēļ, ja `same_bucket(a, b)` atgriež `true`, `a` tiek pārvietots šķēles beigās.
    ///
    ///
    /// Ja šķēle ir sakārtota, pirmā atgrieztā šķēle nesatur dublikātus.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // Lai gan mums ir maināma atsauce uz `self`, mēs nevaram veikt *patvaļīgas* izmaiņas.`same_bucket` zvani varētu būt panic, tāpēc mums jānodrošina, lai šķēle vienmēr būtu derīgā stāvoklī.
        //
        // Mēs to apstrādājam, izmantojot mijmaiņas līgumus;mēs atkārtojam visus elementus, ejot maināmies tā, ka beigās elementi, kurus mēs vēlamies paturēt, atrodas priekšā, un tie, kurus mēs vēlamies noraidīt, ir aizmugurē.
        // Pēc tam mēs varam sadalīt šķēli.
        // Šī darbība joprojām ir `O(n)`.
        //
        // Piemērs: mēs sākam šajā stāvoklī, kur `r` apzīmē "nākamo"
        // lasiet "un `w` apzīmē" next_write ".
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // Salīdzinot self[r] ar sevi [w-1], tas nav dublikāts, tāpēc mēs apmainām self[r] un self[w] (bez efekta kā r==w) un pēc tam palielinām gan r, gan w, atstājot mums:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Salīdzinot self[r] ar sevi [w-1], šī vērtība ir dublikāts, tāpēc mēs palielinām `r`, bet visu pārējo atstājam nemainītu:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Salīdzinot self[r] ar sevi [w-1], tas nav dublikāts, tāpēc apmainiet self[r] un self[w] un virziet r un w:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // Nav dublikāts, atkārtojiet:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // Dublikāts, advance r. End šķēles.Sadalīt pie w.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // DROŠĪBA: `while` nosacījums garantē `next_read` un `next_write`
        // ir mazāki par `len`, tādējādi atrodas `self` iekšpusē.
        // `prev_ptr_write` norāda uz vienu elementu pirms `ptr_write`, bet `next_write` sākas ar 1, tāpēc `prev_ptr_write` nekad nav mazāks par 0 un atrodas šķēles iekšpusē.
        // Tas atbilst `ptr_read`, `prev_ptr_write` un `ptr_write` novirzīšanas un `ptr.add(next_read)`, `ptr.add(next_write - 1)` un `prev_ptr_write.offset(1)` izmantošanas prasībām.
        //
        //
        // `next_write` arī tiek palielināts ne vairāk kā vienu reizi vienā cilpā, tas nozīmē, ka neviens elements netiek izlaists, kad tas var būt nepieciešams nomainīt.
        //
        // `ptr_read` un `prev_ptr_write` nekad nenorāda uz vienu un to pašu elementu.Tas ir nepieciešams, lai `&mut *ptr_read`, `&mut* prev_ptr_write` būtu droši.
        // Izskaidrojums ir vienkārši tas, ka `next_read >= next_write` vienmēr ir patiesa, līdz ar to arī `next_read > next_write - 1`.
        //
        //
        //
        //
        //
        unsafe {
            // Izvairieties no ierobežojošām pārbaudēm, izmantojot neapstrādātas norādes.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// Pārvieto visus elementus, izņemot pirmo no secīgajiem elementiem, uz tās daļas beigām, kurā tiek izmantota tā pati atslēga.
    ///
    ///
    /// Atgriež divas šķēles.Pirmajā nav secīgu atkārtotu elementu.
    /// Otrais satur visus dublikātus noteiktā secībā.
    ///
    /// Ja šķēle ir sakārtota, pirmā atgrieztā šķēle nesatur dublikātus.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// Pagriež šķēli vietā tā, lai pirmie šķēles `mid` elementi pārvietotos uz beigām, bet pēdējie `self.len() - mid` elementi virzītos uz priekšu.
    /// Pēc izsaukšanas uz `rotate_left` elements, kas iepriekš atradās indeksā `mid`, kļūs par pirmo elementu šķēlē.
    ///
    /// # Panics
    ///
    /// Šī funkcija būs panic, ja `mid` ir lielāks par šķēles garumu.Ņemiet vērā, ka `mid == self.len()` veic _not_ panic un ir rotācija bez opcijas.
    ///
    /// # Complexity
    ///
    /// Notiek lineāri (`self.len()`) laikā.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// Apakšgrupas pagriešana:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // DROŠĪBA: `[p.add(mid) - mid, p.add(mid) + k)` diapazons ir triviāli
        // derīgs lasīšanai un rakstīšanai, kā to prasa `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Pagriež šķēli vietā tā, lai pirmie šķēles `self.len() - k` elementi pārvietotos uz beigām, bet pēdējie `k` elementi virzītos uz priekšu.
    /// Pēc izsaukšanas uz `rotate_right` elements, kas iepriekš atradās indeksā `self.len() - k`, kļūs par pirmo elementu šķēlē.
    ///
    /// # Panics
    ///
    /// Šī funkcija būs panic, ja `k` ir lielāks par šķēles garumu.Ņemiet vērā, ka `k == self.len()` veic _not_ panic un ir rotācija bez opcijas.
    ///
    /// # Complexity
    ///
    /// Notiek lineāri (`self.len()`) laikā.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// Pagrieziet apakšslāni:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // DROŠĪBA: `[p.add(mid) - mid, p.add(mid) + k)` diapazons ir triviāli
        // derīgs lasīšanai un rakstīšanai, kā to prasa `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Aizpilda `self` ar elementiem, klonējot `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// Piepilda `self` ar elementiem, kas atgriezti, atkārtoti izsaucot slēgšanu.
    ///
    /// Šī metode izmanto slēgšanu, lai izveidotu jaunas vērtības.Ja vēlaties, lai [`Clone`] dotu vērtību, izmantojiet [`fill`].
    /// Ja vērtību ģenerēšanai vēlaties izmantot [`Default`] trait, kā argumentu varat nodot [`Default::default`].
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// Kopē elementus no `src` uz `self`.
    ///
    /// `src` garumam jābūt tādam pašam kā `self`.
    ///
    /// Ja `T` ievieš `Copy`, var būt efektīvāk izmantot [`copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Šī funkcija būs panic, ja abām šķēlītēm ir atšķirīgs garums.
    ///
    /// # Examples
    ///
    /// Divu elementu klonēšana no šķēles citā:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Tā kā šķēlēm jābūt vienāda garuma, avota šķēli sagriežam no četriem elementiem uz diviem.
    /// // Ja mēs to nedarīsim, tas būs panic.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust nodrošina, ka var būt tikai viena maināma atsauce bez maināmām atsaucēm uz konkrētu datu gabalu noteiktā darbības jomā.
    /// Tāpēc, mēģinot izmantot `clone_from_slice` vienā šķēlē, kompilēšanas kļūda:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Lai to novērstu, mēs varam izmantot [`split_at_mut`], lai no šķēles izveidotu divus atšķirīgus apakšslāņus:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// Kopē visus elementus no `src` uz `self`, izmantojot memcpy.
    ///
    /// `src` garumam jābūt tādam pašam kā `self`.
    ///
    /// Ja `T` neievieš `Copy`, izmantojiet [`clone_from_slice`].
    ///
    /// # Panics
    ///
    /// Šī funkcija būs panic, ja abām šķēlītēm ir atšķirīgs garums.
    ///
    /// # Examples
    ///
    /// Divu elementu kopēšana no šķēles citā:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Tā kā šķēlēm jābūt vienāda garuma, avota šķēli sagriežam no četriem elementiem uz diviem.
    /// // Ja mēs to nedarīsim, tas būs panic.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust nodrošina, ka var būt tikai viena maināma atsauce bez maināmām atsaucēm uz konkrētu datu gabalu noteiktā darbības jomā.
    /// Tāpēc, mēģinot izmantot `copy_from_slice` vienā šķēlē, kompilēšanas kļūda:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Lai to novērstu, mēs varam izmantot [`split_at_mut`], lai no šķēles izveidotu divus atšķirīgus apakšslāņus:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // panic koda ceļš tika ievietots aukstā funkcijā, lai nepieblīvētu zvana vietni.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // DROŠĪBA: `self` pēc definīcijas ir derīgs `self.len()` elementiem, un `src` bija
        // pārbaudīts, vai tiem ir vienāds garums.
        // Šķēles nevar pārklāties, jo maināmās atsauces ir ekskluzīvas.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// Izmantojot memmove, elementi tiek kopēti no vienas šķēles daļas uz otru tās daļu.
    ///
    /// `src` ir diapazons `self` robežās, no kura kopēt.
    /// `dest` ir sākuma indekss diapazonam `self` robežās, uz kuru kopēt, un kura garums būs vienāds ar `src`.
    /// Abi diapazoni var pārklāties.
    /// Divu diapazonu galiem jābūt mazākiem vai vienādiem ar `self.len()`.
    ///
    /// # Panics
    ///
    /// Šī funkcija būs panic, ja kāds no diapazoniem pārsniedz šķēles beigas vai ja `src` beigas ir pirms sākuma.
    ///
    ///
    /// # Examples
    ///
    /// Četru baitu kopēšana šķēlē:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // DROŠĪBA: visi `ptr::copy` nosacījumi ir pārbaudīti iepriekš,
        // tāpat kā `ptr::add`.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// Visus `self` elementus apmaina ar `other` elementiem.
    ///
    /// `other` garumam jābūt tādam pašam kā `self`.
    ///
    /// # Panics
    ///
    /// Šī funkcija būs panic, ja abām šķēlītēm ir atšķirīgs garums.
    ///
    /// # Example
    ///
    /// Divu elementu maiņa pa šķēlēm:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust nosaka, ka var būt tikai viena maināma atsauce uz konkrētu datu gabalu noteiktā darbības jomā.
    ///
    /// Tāpēc, mēģinot izmantot `swap_with_slice` vienā šķēlē, kompilēšanas kļūda:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// Lai to novērstu, mēs varam izmantot [`split_at_mut`], lai no šķēles izveidotu divas atšķirīgas maināmas apakšsloksnes:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // DROŠĪBA: `self` pēc definīcijas ir derīgs `self.len()` elementiem, un `src` bija
        // pārbaudīts, vai tiem ir vienāds garums.
        // Šķēles nevar pārklāties, jo maināmās atsauces ir ekskluzīvas.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// Funkcija, lai aprēķinātu `align_to{,_mut}` vidējās un aizmugurējās šķēles garumus.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // Tas, ko mēs darīsim ar `rest`, ir noskaidrot, kādus `U` daudzkārtīgus skaitļus mēs varam ievietot mazākajā skaitā `T`.
        //
        // Un cik `T` mums vajag katram šādam "multiple".
        //
        // Apsveriet, piemēram, T=u8 U=u16.Tad mēs varam ievietot 1 U 2 Ts.Vienkārši.
        // Apsveriet, piemēram, gadījumu, kad size_of: :<T>=16, izmērs: <U>=24.</u>
        // Mēs varam ievietot 2 Us katras 3 Ts vietā `rest` šķēlē.
        // Mazliet sarežģītāk.
        //
        // Formula, lai to aprēķinātu, ir:
        //
        // Mēs= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // Paplašināta un vienkāršota:
        //
        // Mēs=izmērs: <T>/gcd(size_of::<T>, size_of::<U>) Ts=izmērs: <U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // Par laimi, tā kā tas viss tiek pastāvīgi novērtēts ... sniegumam šeit nav nozīmes!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // iteratīvā steina algoritms Mums tomēr vajadzētu padarīt šo `const fn` (un atgriezties pie rekursīvā algoritma, ja mēs to darām), jo paļauties uz llvm, lai to visu kontrolētu, ir ... labi, tas padara mani neērti.
            //
            //

            // DROŠĪBA: tiek pārbaudīts, vai `a` un `b` vērtības nav nulles vērtības.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // noņemt visus faktorus 2 no b
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // DROŠĪBA: tiek pārbaudīts, vai `b` nav nulle.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // Bruņojušies ar šīm zināšanām, mēs varam atrast, cik `U` mēs varam ievietot!
        let us_len = self.len() / ts * us;
        // Un cik `T` būs beigu daļā!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Pārveidojiet šķēli uz cita veida šķēli, nodrošinot veidu izlīdzināšanu.
    ///
    /// Ar šo metodi šķēle tiek sadalīta trīs atšķirīgās šķēlēs: prefikss, pareizi izlīdzināta jauna veida vidējā šķēle un sufiksa šķēle.
    /// Metode var padarīt vidējo šķēli pēc iespējas lielāku garumu konkrētam tipam un ievades šķēlītei, taču no tā ir atkarīga tikai jūsu algoritma veiktspēja, nevis tās pareizība.
    ///
    /// Ir atļauts visus ievades datus atgriezt kā prefiksa vai sufiksa šķēlēs.
    ///
    /// Šai metodei nav mērķa, ja vai nu ievades elements `T`, vai izvades elements `U` ir nulles lieluma un atgriezīs sākotnējo šķēli, neko nesadalot.
    ///
    /// # Safety
    ///
    /// Šī metode būtībā ir `transmute` attiecībā uz atgrieztās vidējās daļas elementiem, tāpēc šeit tiek piemēroti arī visi parastie brīdinājumi, kas attiecas uz `transmute::<T, U>`.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // Ņemiet vērā, ka lielāko daļu šīs funkcijas novērtēs nemainīgi,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // speciāli rīkojieties ar ZST, tas ir-neizmantojiet tos vispār.
            return (self, &[], &[]);
        }

        // Vispirms atrodiet, kurā brīdī mēs sadalāmies starp pirmo un otro šķēli.
        // Vienkārši ar ptr.align_offset.
        let ptr = self.as_ptr();
        // DROŠĪBA: Detalizētu drošības komentāru skatiet `align_to_mut` metodē.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // DROŠĪBA: tagad `rest` noteikti ir izlīdzināts, tāpēc `from_raw_parts` zemāk ir kārtībā,
            // tā kā zvanītājs garantē, ka mēs varam droši pārveidot `T` uz `U`.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Pārveidojiet šķēli uz cita veida šķēli, nodrošinot veidu izlīdzināšanu.
    ///
    /// Ar šo metodi šķēle tiek sadalīta trīs atšķirīgās šķēlēs: prefikss, pareizi izlīdzināta jauna veida vidējā šķēle un sufiksa šķēle.
    /// Metode var padarīt vidējo šķēli pēc iespējas lielāku garumu konkrētam tipam un ievades šķēlītei, taču no tā ir atkarīga tikai jūsu algoritma veiktspēja, nevis tās pareizība.
    ///
    /// Ir atļauts visus ievades datus atgriezt kā prefiksa vai sufiksa šķēlēs.
    ///
    /// Šai metodei nav mērķa, ja vai nu ievades elements `T`, vai izvades elements `U` ir nulles lieluma un atgriezīs sākotnējo šķēli, neko nesadalot.
    ///
    /// # Safety
    ///
    /// Šī metode būtībā ir `transmute` attiecībā uz atgrieztās vidējās daļas elementiem, tāpēc šeit tiek piemēroti arī visi parastie brīdinājumi, kas attiecas uz `transmute::<T, U>`.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // Ņemiet vērā, ka lielāko daļu šīs funkcijas novērtēs nemainīgi,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // speciāli rīkojieties ar ZST, tas ir-neizmantojiet tos vispār.
            return (self, &mut [], &mut []);
        }

        // Vispirms atrodiet, kurā brīdī mēs sadalāmies starp pirmo un otro šķēli.
        // Vienkārši ar ptr.align_offset.
        let ptr = self.as_ptr();
        // DROŠĪBA: Šeit mēs nodrošinām, ka mēs izmantosim U izlīdzinātus rādītājus
        // pārējā metode.Tas tiek darīts, nododot rādītāju&[T] ar izlīdzinājumu, kas paredzēts U.
        // `crate::ptr::align_offset` tiek izsaukts ar pareizi izlīdzinātu un derīgu rādītāju `ptr` (tas nāk no atsauces uz `self`) un ar izmēru, kas ir divu jauda (jo tas nāk no U izlīdzināšanas), kas atbilst tā drošības ierobežojumiem.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // Pēc tam mēs vairs nevaram izmantot `rest`, tas nederētu tā aizstājvārdu `mut_ptr`!DROŠĪBA: skatiet `align_to` komentārus.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// Pārbauda, vai šīs šķēles elementi ir sakārtoti.
    ///
    /// Tas ir, katram elementam `a` un tam sekojošajam elementam `b` ir jāatbilst `a <= b`.Ja šķēle dod tieši nulli vai vienu elementu, `true` tiek atgriezts.
    ///
    /// Ņemiet vērā, ka, ja `Self::Item` ir tikai `PartialOrd`, bet ne `Ord`, iepriekšminētā definīcija nozīmē, ka šī funkcija atgriež `false`, ja divi secīgi vienumi nav salīdzināmi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// Pārbauda, vai šīs šķēles elementi ir sakārtoti, izmantojot norādīto salīdzināšanas funkciju.
    ///
    /// Tā vietā, lai izmantotu `PartialOrd::partial_cmp`, šī funkcija izmanto norādīto `compare` funkciju, lai noteiktu divu elementu secību.
    /// Bez tam tas ir līdzvērtīgs [`is_sorted`];Plašāku informāciju skatiet tās dokumentācijā.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// Pārbauda, vai šīs šķēles elementi ir sakārtoti, izmantojot norādīto atslēgas izvilkšanas funkciju.
    ///
    /// Tā vietā, lai tieši salīdzinātu šķēles elementus, šī funkcija salīdzina elementu taustiņus, ko nosaka `f`.
    /// Bez tam tas ir līdzvērtīgs [`is_sorted`];Plašāku informāciju skatiet tās dokumentācijā.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// Atgriež nodalījuma punkta indeksu atbilstoši dotajam predikātam (otrā nodalījuma pirmā elementa indekss).
    ///
    /// Tiek pieņemts, ka šķēle ir sadalīta atbilstoši dotajam predikātam.
    /// Tas nozīmē, ka visi elementi, kuriem predikāts atgriežas kā taisnība, atrodas šķēles sākumā un visi elementi, kuriem predikāts atgriež viltus, ir beigās.
    ///
    /// Piemēram, [7, 15, 3, 5, 4, 12, 6] ir sadalīts zem predikāta x% 2!=0 (visi nepāra skaitļi ir sākumā, visi pat beigās).
    ///
    /// Ja šī šķēle nav sadalīta, atgrieztais rezultāts ir nenoteikts un bezjēdzīgs, jo šī metode veic sava veida bināro meklēšanu.
    ///
    /// Skatiet arī [`binary_search`], [`binary_search_by`] un [`binary_search_by_key`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // DROŠĪBA: Kad `left < right`, `left <= mid < right`.
            // Tāpēc `left` vienmēr palielinās un `right` vienmēr samazinās, un tiek izvēlēts kāds no tiem.Abos gadījumos `left <= right` ir apmierināts.Tāpēc, ja `left < right` solī, `left <= right` nākamajā solī ir apmierināts.
            //
            // Tāpēc, kamēr vien `left != right`, `0 <= left < right <= len` ir apmierināts, un, ja šajā gadījumā ir apmierināts arī `0 <= mid < len`.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: Mums tie ir skaidri jāsagriež vienā garumā
        // lai optimizētājam būtu vieglāk novērst ierobežojumus.
        // Bet, tā kā uz to nevar paļauties, mums ir arī skaidra specializācija T: Copy.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// Izveido tukšu šķēli.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// Izveido maināmu tukšu šķēli.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// Šobrīd šķēlēs esošos modeļus izmanto tikai `strip_prefix` un `strip_suffix`.
/// future punktā mēs ceram `core::str::Pattern` (kas rakstīšanas laikā aprobežojas ar `str`) vispārināt par šķēlītēm, un tad šis trait tiks aizstāts vai atcelts.
///
pub trait SlicePattern {
    /// Sagatavotās šķēles elementa tips.
    type Item;

    /// Pašlaik `SlicePattern` patērētājiem ir nepieciešama šķēle.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}