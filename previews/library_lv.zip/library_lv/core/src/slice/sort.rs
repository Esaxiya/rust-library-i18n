//! Šķēļu šķirošana
//!
//! Šis modulis satur šķirošanas algoritmu, kas balstīts uz Orsona Pītersa modeli pārvarošo ātrsortu, kas publicēts vietnē: <https://github.com/orlp/pdqsort>
//!
//!
//! Nestabila šķirošana ir saderīga ar libcore, jo tā nepiešķir atmiņu, atšķirībā no mūsu stabilās šķirošanas ieviešanas.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Nometot, kopijas no `src` uz `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // DROŠĪBA: Šī ir palīgu klase.
        //          Lūdzu, skatiet tā lietošanas pareizību.
        //          Proti, ir jāpārliecinās, ka `src` un `dst` nepārklājas, kā to prasa `ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Pārvieto pirmo elementu pa labi, līdz tas sastop lielāku vai vienādu elementu.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // DROŠĪBA: Turpmāk norādītās nedrošās darbības ietver indeksēšanu bez saistošas pārbaudes (`get_unchecked` un `get_unchecked_mut`)
    // un atmiņas kopēšana (`ptr::copy_nonoverlapping`).
    //
    // a.Indeksēšana:
    //  1. Mēs pārbaudījām masīva lielumu uz>=2.
    //  2. Visas indeksācijas, kuras mēs veiksim, vienmēr ir ne vairāk kā starp {0 <= index < len}.
    //
    // b.Atmiņas kopēšana
    //  1. Mēs iegūstam norādes uz atsaucēm, kuras ir garantētas derīgas.
    //  2. Tie nevar pārklāties, jo mēs iegūstam norādes uz šķēles atšķirības indeksiem.
    //     Proti, `i` un `i-1`.
    //  3. Ja šķēle ir pareizi izlīdzināta, elementi ir pareizi izlīdzināti.
    //     Zvanītāja pienākums ir pārliecināties, vai šķēle ir pareizi izlīdzināta.
    //
    // Sīkāku informāciju skatiet zemāk esošajos komentāros.
    unsafe {
        // Ja pirmie divi elementi nav kārtībā ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Pirmo elementu nolasiet kaudzē piešķirtajā mainīgajā.
            // Ja šāda salīdzināšanas operācija panics, `hole` tiks nomesta un automātiski ierakstīs elementu atpakaļ šķēlē.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Pārvietojiet i-tā elementa vietu pa kreisi, tādējādi pārvietojot caurumu pa labi.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` tiek nomests un tādējādi kopē `tmp` atlikušajā caurumā `v`.
        }
    }
}

/// Pārvieto pēdējo elementu pa kreisi, līdz tas saskaras ar mazāku vai vienādu elementu.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // DROŠĪBA: Turpmāk norādītās nedrošās darbības ietver indeksēšanu bez saistošas pārbaudes (`get_unchecked` un `get_unchecked_mut`)
    // un atmiņas kopēšana (`ptr::copy_nonoverlapping`).
    //
    // a.Indeksēšana:
    //  1. Mēs pārbaudījām masīva lielumu uz>=2.
    //  2. Visas indeksācijas, kuras mēs veiksim, vienmēr ir ne vairāk kā starp `0 <= index < len-1`.
    //
    // b.Atmiņas kopēšana
    //  1. Mēs iegūstam norādes uz atsaucēm, kuras ir garantētas derīgas.
    //  2. Tie nevar pārklāties, jo mēs iegūstam norādes uz šķēles atšķirības indeksiem.
    //     Proti, `i` un `i+1`.
    //  3. Ja šķēle ir pareizi izlīdzināta, elementi ir pareizi izlīdzināti.
    //     Zvanītāja pienākums ir pārliecināties, vai šķēle ir pareizi izlīdzināta.
    //
    // Sīkāku informāciju skatiet zemāk esošajos komentāros.
    unsafe {
        // Ja pēdējie divi elementi nav kārtībā ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Izlasiet pēdējo elementu kaudzē piešķirtajā mainīgajā.
            // Ja šāda salīdzināšanas operācija panics, `hole` tiks nomesta un automātiski ierakstīs elementu atpakaļ šķēlē.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Pārvietojiet i-tā elementa vietu pa labi, tādējādi pārvietojot atveri pa kreisi.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` tiek nomests un tādējādi kopē `tmp` atlikušajā caurumā `v`.
        }
    }
}

/// Daļēji šķiro šķēli, pārvietojot vairākus nederīgus elementus apkārt.
///
/// Atgriež `true`, ja šķēle ir sakārtota beigās.Šī funkcija ir *O*(*n*) sliktākajā gadījumā.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Maksimālais blakus esošo ārpus kārtas esošo pāru skaits, kas tiks pārvietoti.
    const MAX_STEPS: usize = 5;
    // Ja šķēle ir īsāka par šo, nepārvietojiet nevienu elementu.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // DROŠĪBA: Mēs jau nepārprotami veicām saistošo pārbaudi ar `i < len`.
        // Visa mūsu turpmākā indeksēšana ir tikai diapazonā `0 <= index < len`
        unsafe {
            // Atrodiet nākamo blakus esošo elementu pāri.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Vai mēs esam pabeiguši?
        if i == len {
            return true;
        }

        // Nemainiet elementus īsos blokos, kam ir veiktspējas izmaksas.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Apmaini atrasto elementu pāri.Tas tos ievieto pareizā secībā.
        v.swap(i - 1, i);

        // Pārvietojiet mazāko elementu pa kreisi.
        shift_tail(&mut v[..i], is_less);
        // Pārvietojiet lielāko elementu pa labi.
        shift_head(&mut v[i..], is_less);
    }

    // Neizdevās kārtot šķēli ierobežotā soļu skaitā.
    false
}

/// Šķiro šķēle, izmantojot ievietošanas kārtojumu, kas ir *O*(*n*^ 2) sliktākais gadījums.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Sašķiro `v`, izmantojot heapsort, kas garantē *O*(*n*\*log(* n*)) sliktākajā gadījumā.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Šis binārais kaudze respektē nemainīgo `parent >= child`.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // `node` bērni:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Izvēlieties lielāku bērnu.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Pārtrauciet, ja nemainīgais turas pie `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Apmainiet `node` ar lielāko bērnu, pārvietojieties vienu soli uz leju un turpiniet sijāšanu.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Veidojiet kaudzi lineārā laikā.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Pop maksimāli elementi no kaudzes.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Sadaliet `v` elementos, kas ir mazāki par `pivot`, kam seko elementi, kas ir lielāki vai vienādi ar `pivot`.
///
///
/// Atgriež elementu skaitu, kas mazāks par `pivot`.
///
/// Sadalīšana tiek veikta pa blokiem, lai samazinātu atzarošanas darbību izmaksas.
/// Šī ideja ir izklāstīta [BlockQuicksort][pdf] dokumentā.
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Elementu skaits tipiskā blokā.
    const BLOCK: usize = 128;

    // Sadalīšanas algoritms līdz pabeigšanai atkārto šādas darbības:
    //
    // 1. Izsekojiet bloku no kreisās puses, lai identificētu elementus, kas ir lielāki vai vienādi ar pagrieziena punktu.
    // 2. Izsekojiet bloku no labās puses, lai identificētu elementus, kas ir mazāki par šarnīru.
    // 3. Apmainiet identificētos elementus starp kreiso un labo pusi.
    //
    // Elementu blokam mēs saglabājam šādus mainīgos:
    //
    // 1. `block` - Elementu skaits blokā.
    // 2. `start` - Sāciet rādītāju masīvā `offsets`.
    // 3. `end` - Gala rādītājs masīvā `offsets`.
    // 4. `nobīdes, ārpusrindas elementu rādītāji blokā.

    // Pašreizējais bloks kreisajā pusē (no `l` līdz `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Pašreizējais bloks labajā pusē (no `r.sub(block_r)` to `r`).
    // DROŠĪBA: .add() dokumentācijā ir īpaši norādīts, ka `vec.as_ptr().add(vec.len())` vienmēr ir drošs "
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Kad mēs saņemam VLA, mēģiniet izveidot vienu masīvu ar garumu `min(v.len(), 2 * BLOCK)
    // nekā divi fiksēta izmēra bloki, kuru garums ir `BLOCK`.VLA varētu būt efektīvāka kešatmiņā.

    // Atgriež elementu skaitu starp rādītājiem `l` (inclusive) un `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Kad `l` un `r` ir ļoti tuvu, mēs esam pabeiguši sadalīšanu pa blokiem.
        // Tad mēs veicam dažus labojumus, lai sadalītu atlikušos elementus starp tiem.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Atlikušo elementu skaits (joprojām nav salīdzināts ar pagrieziena punktu).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Pielāgojiet bloku izmērus tā, lai kreisais un labais bloks nepārklājas, bet būtu pilnīgi izlīdzināts, lai pārklātu visu atlikušo atstarpi.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Izsekojiet `block_l` elementus no kreisās puses.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // DROŠĪBA: Turpmāk norādītās nedrošības darbības ietver `offset` lietošanu.
                //         Saskaņā ar funkcijas pieprasītajiem nosacījumiem mēs tos izpildām, jo:
                //         1. `offsets_l` ir piešķirts kaudzei un tādējādi tiek uzskatīts par atsevišķu piešķirtu objektu.
                //         2. Funkcija `is_less` atgriež `bool`.
                //            Lietojot `bool`, `isize` nekad netiks pārpildīts.
                //         3. Mēs esam garantējuši, ka `block_l` būs `<= BLOCK`.
                //            Turklāt `end_l` sākotnēji tika iestatīts uz `offsets_` sākuma rādītāju, kas tika deklarēts uz kaudzes.
                //            Tādējādi mēs zinām, ka pat sliktākajā gadījumā (visi `is_less` izsaukumi atgriež viltus) mēs beigsim tikai vienu baitu.
                //        Vēl viena nedroša darbība šeit ir `elem` novirzīšana.
                //        Tomēr sākotnēji `elem` bija sākuma rādītājs uz šķēli, kas vienmēr ir derīga.
                unsafe {
                    // Bezzaru salīdzinājums.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Izsekojiet `block_r` elementus no labās puses.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // DROŠĪBA: Turpmāk norādītās nedrošības darbības ietver `offset` lietošanu.
                //         Saskaņā ar funkcijas pieprasītajiem nosacījumiem mēs tos izpildām, jo:
                //         1. `offsets_r` ir piešķirts kaudzei un tādējādi tiek uzskatīts par atsevišķu piešķirtu objektu.
                //         2. Funkcija `is_less` atgriež `bool`.
                //            Lietojot `bool`, `isize` nekad netiks pārpildīts.
                //         3. Mēs esam garantējuši, ka `block_r` būs `<= BLOCK`.
                //            Turklāt `end_r` sākotnēji tika iestatīts uz `offsets_` sākuma rādītāju, kas tika deklarēts uz kaudzes.
                //            Tādējādi mēs zinām, ka pat sliktākajā gadījumā (visi `is_less` izsaukumi atgriežas patiesā vērtībā) mēs beigsim tikai vienu baitu.
                //        Vēl viena nedroša darbība šeit ir `elem` novirzīšana.
                //        Tomēr sākotnēji `elem` bija `1 *sizeof(T)` pāri beigām, un pirms piekļuves tam mēs to samazinām par `1* sizeof(T)`.
                //        Turklāt tika apgalvots, ka `block_r` ir mazāks par `BLOCK`, un tāpēc `elem` galvenokārt norāda uz šķēles sākumu.
                unsafe {
                    // Bezzaru salīdzinājums.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Nepareizu elementu skaits, kas jāpārvieto starp kreiso un labo pusi.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Tā vietā, lai vienlaikus nomainītu vienu pāri, efektīvāk ir veikt ciklisku permutāciju.
            // Tas nav stingri ekvivalents maiņai, bet rada līdzīgu rezultātu, izmantojot mazāk atmiņas darbību.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Visi ārpus pasūtījuma esošie elementi kreisajā blokā tika pārvietoti.Pāriet uz nākamo bloku.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Visi labajā blokā esošie ārpus pasūtījuma esošie elementi tika pārvietoti.Pāriet uz iepriekšējo bloku.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Tagad paliek tikai viens bloks (vai nu pa kreisi, vai pa labi) ar elementiem, kas nav kārtībā, kas jāpārvieto.
    // Šādus atlikušos elementus to blokā var vienkārši novirzīt līdz beigām.
    //

    if start_l < end_l {
        // Kreisais bloks paliek.
        // Pārvietojiet tās atlikušos ārpus pasūtījuma esošos elementus uz galēji labo pusi.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Pareizais bloks paliek.
        // Pārvietojiet tā atlikušos ārpus pasūtījuma esošos elementus pa kreisi.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Neko citu darīt, mēs esam galā.
        width(v.as_mut_ptr(), l)
    }
}

/// Sadaliet `v` elementos, kas ir mazāki par `v[pivot]`, kam seko elementi, kas ir lielāki vai vienādi ar `v[pivot]`.
///
///
/// Atgriež kopu ar:
///
/// 1. Elementu skaits, kas mazāks par `v[pivot]`.
/// 2. Tiesa, ja `v` jau bija sadalīts.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Novietojiet pagrieziena daļu šķēles sākumā.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Efektivitātes labad izlasiet rakurstaciju kaudzē piešķirtajā mainīgajā.
        // Ja tiek veikta šāda salīdzināšanas darbība panics, pagrieziena punkts automātiski tiks ierakstīts atpakaļ šķēlē.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Atrodiet pirmo pāri neveikto elementu pāri.
        let mut l = 0;
        let mut r = v.len();

        // DROŠĪBA: zemāk esošajā nedrošībā ietilpst masīva indeksēšana.
        // Pirmajam: mēs jau veicam robežas, pārbaudot šeit ar `l < r`.
        // Otrajam: sākotnēji mums ir `l == 0` un `r == v.len()`, un mēs pārbaudījām šo `l < r` katrā indeksēšanas operācijā.
        //                     No šejienes mēs zinām, ka `r` ir jābūt vismaz `r == l`, kas izrādījās derīgs no pirmā.
        unsafe {
            // Atrodiet pirmo elementu, kas ir lielāks vai vienāds ar pagrieziena punktu.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Atrodiet pēdējo elementu, kas ir mazāks par pagrieziena punktu.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` iziet no darbības sfēras un raksta pagrieziena punktu (kas ir kaudzei piešķirts mainīgais) atpakaļ tajā vietā, kur tā sākotnēji bija.
        // Šis solis ir ļoti svarīgs, lai nodrošinātu drošību!
        //
    };

    // Novietojiet pagrieziena punktu starp abiem nodalījumiem.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Sadaliet `v` elementos, kas vienādi ar `v[pivot]`, kam seko elementi, kas lielāki par `v[pivot]`.
///
/// Atgriež elementu skaitu, kas vienāds ar pagrieziena punktu.
/// Tiek pieņemts, ka `v` nesatur elementus, kas ir mazāki par šarnīru.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Novietojiet pagrieziena daļu šķēles sākumā.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Efektivitātes labad izlasiet rakurstaciju kaudzē piešķirtajā mainīgajā.
    // Ja tiek veikta šāda salīdzināšanas darbība panics, pagrieziena punkts automātiski tiks ierakstīts atpakaļ šķēlē.
    // DROŠĪBA: Rādītājs šeit ir derīgs, jo to iegūst no atsauces uz šķēli.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Tagad sadaliet šķēli.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // DROŠĪBA: zemāk esošajā nedrošībā ietilpst masīva indeksēšana.
        // Pirmajam: mēs jau veicam robežas, pārbaudot šeit ar `l < r`.
        // Otrajam: sākotnēji mums ir `l == 0` un `r == v.len()`, un mēs pārbaudījām šo `l < r` katrā indeksēšanas operācijā.
        //                     No šejienes mēs zinām, ka `r` ir jābūt vismaz `r == l`, kas izrādījās derīgs no pirmā.
        unsafe {
            // Atrodiet pirmo elementu, kas ir lielāks par pagrieziena punktu.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Atrodiet pēdējo elementu, kas vienāds ar pagrieziena punktu.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Vai mēs esam pabeiguši?
            if l >= r {
                break;
            }

            // Apmainiet atrasto nepieņemto elementu pāri.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Mēs atradām `l` elementus, kas vienādi ar pagrieziena punktu.Pievienojiet 1, lai ņemtu vērā pašu pagrieziena punktu.
    l + 1

    // `_pivot_guard` iziet no darbības sfēras un raksta pagrieziena punktu (kas ir kaudzei piešķirts mainīgais) atpakaļ tajā vietā, kur tā sākotnēji bija.
    // Šis solis ir ļoti svarīgs, lai nodrošinātu drošību!
}

/// Izkliedē dažus elementus, mēģinot salauzt modeļus, kas varētu izraisīt nesabalansētas starpsienas ātrsortā.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Džordža Marsaglijas pseidorandomālo skaitļu ģenerators no "Xorshift RNGs" papīra.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Veikt nejaušus skaitļus modulo šo skaitli.
        // Numurs ietilpst `usize`, jo `len` nav lielāks par `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Daži rakursa kandidāti atradīsies šī indeksa tuvumā.Randomizēsim tos.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Ģenerējiet nejaušu skaitli modulo `len`.
            // Tomēr, lai izvairītos no dārgām darbībām, mēs vispirms to pieņemam ar moduli divu jaudu un pēc tam samazinām par `len`, līdz tas iekļaujas `[0, len - 1]` diapazonā.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` tiek garantēta mazāka par `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Izvēlas šarnīru `v` un atgriež indeksu un `true`, ja šķēle, visticamāk, jau ir sakārtota.
///
/// `v` elementi procesā var tikt pārkārtoti.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Minimālais garums, lai izvēlētos mediānas-mediānas metodi.
    // Īsākās šķēlēs tiek izmantota vienkāršā vidējā-trīs metode.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Maksimālais mijmaiņas darījumu skaits, ko var veikt ar šo funkciju.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Trīs indeksi, kuru tuvumā mēs izvēlēsimies šarnīru.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Uzskaita kopējo mijmaiņas darījumu skaitu, ko mēs gatavojamies veikt, kārtojot indeksus.
    let mut swaps = 0;

    if len >= 8 {
        // Maina indeksus tā, lai `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Maina indeksus tā, lai `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Atrod `v[a - 1], v[a], v[a + 1]` mediānu un saglabā indeksu `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Atrodiet mediānus `a`, `b` un `c` apkaimēs.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Atrodiet vidējo vērtību starp `a`, `b` un `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Tika veikts maksimālais mijmaiņas darījumu skaits.
        // Iespējams, ka šķēle ir lejupejoša vai galvenokārt dilstoša, tāpēc atpakaļgaita, iespējams, palīdzēs to ātrāk kārtot.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Kārto `v` rekursīvi.
///
/// Ja šķēlē sākotnējā masīvā bija priekšgājējs, tas tiek norādīts kā `pred`.
///
/// `limit` ir atļauto nesabalansēto nodalījumu skaits pirms pārslēgšanās uz `heapsort`.
/// Ja nulle, šī funkcija nekavējoties pārslēgsies uz straumju.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Šķēles, kuru garums nepārsniedz šo garumu, tiek kārtotas, izmantojot ievietošanas kārtojumu.
    const MAX_INSERTION: usize = 20;

    // Patiesi, ja pēdējā sadalīšana bija pietiekami līdzsvarota.
    let mut was_balanced = true;
    // Patiesi, ja pēdējā sadalīšana nejauca elementus (šķēle jau bija sadalīta).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Ļoti īsas šķēles tiek kārtotas, izmantojot ievietošanas kārtojumu.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Ja tika izdarīts pārāk daudz sliktu šarnīra izvēles iespēju, vienkārši atgriezieties galvenajā sportā, lai garantētu `O(n * log(n))` sliktāko gadījumu.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Ja pēdējā sadalīšana nebija līdzsvarota, mēģiniet sadalīt šķēles modeļus, sajaucot dažus elementus apkārt.
        // Cerams, ka šoreiz izvēlēsimies labāku pagrieziena punktu.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Izvēlieties pagrieziena punktu un mēģiniet uzminēt, vai šķēle jau ir sakārtota.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Ja pēdējais sadalījums bija pienācīgi līdzsvarots un nejauca elementus, un, ja rakursu atlase paredz, ka šķēle, visticamāk, jau ir sakārtota ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Mēģiniet identificēt vairākus ārpus pasūtījuma esošus elementus un pārvietot tos uz pareizām pozīcijām.
            // Ja šķēle galu galā tiek pilnībā sašķirota, mēs esam pabeiguši.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Ja izvēlētais pagrieziena punkts ir vienāds ar priekšgājēju, tad tas ir mazākais šķēles elements.
        // Sadaliet šķēli elementos, kas ir vienādi ar un lielāki par pagrieziena punktu.
        // Šis gadījums parasti tiek skarts, ja šķēle satur daudz dublikātu elementu.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Turpiniet kārtot elementus, kas ir lielāki par pagrieziena punktu.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Sadaliet šķēli.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Sadaliet šķēli `left`, `pivot` un `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Atgriezieties tikai īsākajā pusē, lai samazinātu kopējo rekursīvo zvanu skaitu un patērētu mazāk vietas kaudzē.
        // Tad vienkārši turpiniet ar garāko pusi (tas ir līdzīgs astes rekursijai).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Kārto `v`, izmantojot modeli izkropļojošo ātrsortu, kas ir *O*(*n*\*log(* n*)) sliktākajā gadījumā.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Kārtošanai nav nozīmīgas uzvedības attiecībā uz nulles lieluma tipiem.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Ierobežojiet nesabalansēto nodalījumu skaitu līdz `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Šķēlēm, kuru garums nepārsniedz šo garumu, iespējams, ir ātrāk tās vienkārši kārtot.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Izvēlieties pagrieziena punktu
        let (pivot, _) = choose_pivot(v, is_less);

        // Ja izvēlētais pagrieziena punkts ir vienāds ar priekšgājēju, tad tas ir mazākais šķēles elements.
        // Sadaliet šķēli elementos, kas ir vienādi ar un lielāki par pagrieziena punktu.
        // Šis gadījums parasti tiek skarts, ja šķēle satur daudz dublikātu elementu.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Ja mēs esam izturējuši savu indeksu, tad mēs esam labi.
                if mid > index {
                    return;
                }

                // Pretējā gadījumā turpiniet kārtot elementus, kas ir lielāki par pagrieziena punktu.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Sadaliet šķēli `left`, `pivot` un `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Ja vidus==indekss, tad mēs esam pabeiguši, jo partition() garantēja, ka visi elementi pēc vidus ir lielāki vai vienādi ar vidu.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Kārtošanai nav nozīmīgas uzvedības attiecībā uz nulles lieluma tipiem.Neko nedarīt.
    } else if index == v.len() - 1 {
        // Atrodiet maksimālo elementu un ievietojiet to masīva pēdējā pozīcijā.
        // Mēs šeit varam izmantot `unwrap()`, jo mēs zinām, ka v nedrīkst būt tukšs.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Atrodiet min elementu un ievietojiet to masīva pirmajā pozīcijā.
        // Mēs šeit varam izmantot `unwrap()`, jo mēs zinām, ka v nedrīkst būt tukšs.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}