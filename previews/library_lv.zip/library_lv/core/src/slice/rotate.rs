// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Pagriež diapazonu `[mid-left, mid+right)` tā, lai elements `mid` kļūtu par pirmo elementu.Līdzīgi pagriež diapazona `left` elementus pa kreisi vai `right` elementus pa labi.
///
/// # Safety
///
/// Norādītajam diapazonam jābūt derīgam lasīšanai un rakstīšanai.
///
/// # Algorithm
///
/// 1. algoritmu izmanto mazām `left + right` vērtībām vai lielām `T` vērtībām.
/// Elementi tiek pārvietoti galīgajās pozīcijās pa vienam, sākot no `mid - left` un virzoties pa `right` pakāpieniem modulo `left + right`, tā, ka nepieciešams tikai viens īslaicīgs.
/// Galu galā mēs atgriežamies `mid - left`.
/// Tomēr, ja `gcd(left + right, right)` nav 1, iepriekš minētās darbības tika izlaistas pāri elementiem.
/// Piemēram:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Par laimi, izlaisto elementu skaits starp pabeigtajiem elementiem vienmēr ir vienāds, tāpēc mēs varam vienkārši kompensēt savu sākuma pozīciju un veikt vairāk apļu (kopējais apļu skaits ir `gcd(left + right, right)` value).
///
/// Gala rezultāts ir tāds, ka visi elementi tiek pabeigti vienreiz un vienreiz.
///
/// 2. algoritms tiek izmantots, ja `left + right` ir liels, bet `min(left, right)` ir pietiekami mazs, lai ietilptu kaudzes buferī.
/// `min(left, right)` elementi tiek kopēti uz bufera, `memmove` tiek uzklāti uz pārējiem, un tie, kas atrodas uz bufera, tiek pārvietoti atpakaļ caurumā, kas atrodas pretējā pusē, kur tie radušies.
///
/// Algoritmi, kurus var vektorizēt, pārspēj iepriekš minēto, tiklīdz `left + right` kļūst pietiekami liels.
/// 1. algoritmu var vektorizēt, sadalot un veicot daudzas kārtas vienlaikus, taču vidēji ir pārāk maz kārtas, līdz `left + right` ir milzīgs, un vissliktākais vienas kārtas gadījums vienmēr ir.
/// Tā vietā 3. algoritms izmanto atkārtotu `min(left, right)` elementu maiņu, līdz paliek mazāka pagriešanas problēma.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// kad `left < right` maiņa notiek no kreisās puses.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. zemāk minētie algoritmi var neizdoties, ja šie gadījumi netiek pārbaudīti
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // 1. algoritma mikropiezīmes norāda, ka vidējā veiktspēja nejaušām maiņām ir labāka visu laiku līdz apmēram `left + right == 32`, bet sliktākajā gadījumā veiktspēja sabojājas pat ap 16.
            // 24 tika izvēlēts kā vidusceļš.
            // Ja `T` izmērs ir lielāks par 4 `usize`, šis algoritms pārspēj arī citus algoritmus.
            //
            //
            let x = unsafe { mid.sub(left) };
            // pirmās kārtas sākums
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` var atrast pirms rokas, aprēķinot `gcd(left + right, right)`, bet ātrāk ir izdarīt vienu cilpu, kas aprēķina gcd kā blakus efektu, pēc tam veicot pārējo gabalu
            //
            //
            let mut gcd = right;
            // etaloni atklāj, ka ir ātrāk visu laiku apmainīt, nevis vienreiz izlasīt vienu pagaidu, kopēt atpakaļ un pēc tam ierakstīt šo pagaidu pašā beigās.
            // Iespējams, tas ir saistīts ar faktu, ka, nomainot vai aizstājot pagaidu datus, lokā tiek izmantota tikai viena atmiņas adrese, nevis divas.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // tā vietā, lai palielinātu `i` un pēc tam pārbaudītu, vai tas atrodas ārpus robežām, mēs pārbaudām, vai `i` nākamajā solī nonāks ārpus robežām.
                // Tas novērš jebkādu rādītāju vai `usize` iesaiņošanu.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // pirmās kārtas beigas
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // šim nosacījumam jābūt šeit, ja `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // pabeidziet gabalu ar vairākām kārtām
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` nav nulles lieluma tips, tāpēc ir pareizi sadalīt pēc tā lieluma.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // 2. algoritms `[T; 0]` šeit ir jānodrošina, lai tas būtu atbilstoši saskaņots ar T
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // 3. algoritms Ir alternatīvs mijmaiņas veids, kas ietver meklēšanu, kur būtu pēdējais šī algoritma mijmaiņa, un mijmaiņu, izmantojot šo pēdējo daļu, nevis nomainot blakus esošās daļas, kā to dara šis algoritms, taču šis veids joprojām ir ātrāks.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // 3. algoritms, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}