//! Bezmaksas funkcijas `&[T]` un `&mut [T]` izveidošanai.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// No rādītāja un garuma veido šķēli.
///
/// `len` arguments ir **elementu** skaits, nevis baitu skaits.
///
/// # Safety
///
/// Uzvedība nav definēta, ja tiek pārkāpts kāds no šiem nosacījumiem:
///
/// * `data` ir jābūt [valid], lai lasītu `len * mem::size_of::<T>()` daudzus baitus, un tam jābūt pareizi izlīdzinātam.Tas jo īpaši nozīmē:
///
///     * Visam šīs šķēles atmiņas diapazonam jābūt vienā piešķirtajā objektā!
///       Šķēles nekad nevar aptvert vairākus piešķirtus objektus.Nepareizi neņemot vērā piemēru, skatiet [below](#incorrect-usage).
///     * `data` jābūt nullei un jāsaskaņo pat nulles garuma šķēlēs.
///     Viens no iemesliem ir tas, ka uzskaites izkārtojuma optimizācija var balstīties uz atsauču (ieskaitot jebkura garuma šķēles) izlīdzināšanu un nebūtību, lai tās atšķirtu no citiem datiem.
///     Izmantojot [`NonNull::dangling()`], varat iegūt rādītāju, kas ir izmantojams kā `data` nulles garuma šķēlītēm.
///
/// * `data` jānorāda uz `len` secīgi pareizi inicializētām `T` tipa vērtībām.
///
/// * Atmiņu, uz kuru atsauc atgrieztā šķēle, `'a` dzīves laikā nedrīkst mutēt, izņemot `UnsafeCell`.
///
/// * Šķēles kopējais izmērs `len * mem::size_of::<T>()` nedrīkst būt lielāks par `isize::MAX`.
///   Skatiet [`pointer::offset`] drošības dokumentāciju.
///
/// # Caveat
///
/// Atgrieztās šķēles kalpošanas laiks tiek secināts no tā izmantošanas.
/// Lai novērstu nejaušu ļaunprātīgu izmantošanu, ir ieteicams saistīt dzīves ilgumu ar to, kurš avota mūžs šajā kontekstā ir drošs, piemēram, nodrošinot palīga funkciju, kas ņem vērā daļas saimniekdatora vērtību, vai ar skaidru anotāciju.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // manifestēt atsevišķa elementa šķēli
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Nepareiza lietošana
///
/// Šī `join_slices` funkcija ir **neskaņota** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // Iepriekš minētais apgalvojums nodrošina, ka `fst` un `snd` ir blakus, taču tie joprojām var būt ietverti _different allocated objects_, un tādā gadījumā šīs šķēles izveide nav noteikta rīcība.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` un `b` ir dažādi piešķirtie objekti ...
///     let a = 42;
///     let b = 27;
///     // ... ko tomēr var salikt blakus atmiņā: a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // DROŠĪBA: zvanītājam jāievēro `from_raw_parts` drošības līgums.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Veic tādu pašu funkcionalitāti kā [`from_raw_parts`], izņemot to, ka tiek atgriezta maināma šķēle.
///
/// # Safety
///
/// Uzvedība nav definēta, ja tiek pārkāpts kāds no šiem nosacījumiem:
///
/// * `data` jābūt gan [valid] gan lasot, gan rakstot `len * mem::size_of::<T>()` daudziem baitiem, un tam jābūt pareizi izlīdzinātam.Tas jo īpaši nozīmē:
///
///     * Visam šīs šķēles atmiņas diapazonam jābūt vienā piešķirtajā objektā!
///       Šķēles nekad nevar aptvert vairākus piešķirtus objektus.
///     * `data` jābūt nullei un jāsaskaņo pat nulles garuma šķēlēs.
///     Viens no iemesliem ir tas, ka uzskaites izkārtojuma optimizācija var balstīties uz atsauču (ieskaitot jebkura garuma šķēles) izlīdzināšanu un nebūtību, lai tās atšķirtu no citiem datiem.
///
///     Izmantojot [`NonNull::dangling()`], varat iegūt rādītāju, kas ir izmantojams kā `data` nulles garuma šķēlītēm.
///
/// * `data` jānorāda uz `len` secīgi pareizi inicializētām `T` tipa vērtībām.
///
/// * Atmiņā, uz kuru atsauc atgrieztā šķēle, `'a` dzīves laikā nedrīkst piekļūt, izmantojot citu rādītāju (kas nav atvasināts no atgriešanās vērtības).
///   Gan lasīšanas, gan rakstīšanas piekļuve ir aizliegta.
///
/// * Šķēles kopējais izmērs `len * mem::size_of::<T>()` nedrīkst būt lielāks par `isize::MAX`.
///   Skatiet [`pointer::offset`] drošības dokumentāciju.
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // DROŠĪBA: zvanītājam jāievēro `from_raw_parts_mut` drošības līgums.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Pārvērš atsauci uz T šķēlē ar garumu 1 (bez kopēšanas).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Pārvērš atsauci uz T šķēlē ar garumu 1 (bez kopēšanas).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}