//! Makro, ko izmanto šķēles iteratori.

// Ievietošana is_empty un len padara milzīgu veiktspējas atšķirību
macro_rules! is_empty {
    // Tas, kā mēs kodējam ZST iteratora garumu, tas darbojas gan ZST, gan ārpus ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Lai atbrīvotos no dažām robežpārbaudēm (sk. `position`), mēs nedaudz negaidīti aprēķinām garumu.
// (Pārbaudīts ar `codegen/slice-position-bounds-check`.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // dažreiz mēs tiekam izmantoti nedrošā blokā

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Šis _cannot_ izmanto `unchecked_sub`, jo mēs esam atkarīgi no iesaiņošanas, lai attēlotu garo ZST slāņu atkārtotāju garumu.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Mēs zinām, ka `start <= end`, tāpēc to var paveikt labāk nekā `offset_from`, kuram jārīkojas parakstīti.
            // Iestatot šeit atbilstošus karodziņus, mēs to varam pateikt LLVM, kas palīdz noņemt robežu pārbaudes.
            // DROŠĪBA: pēc nemainīgā veida, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Arī pasakot LLVM, ka rādītāji ir atdalīti ar precīzu tipa lieluma reizinājumu, tas var optimizēt `len() == 0` līdz `start == end`, nevis `(end - start) < size`.
            //
            // DROŠĪBA: Rādītāji tiek izlīdzināti pēc veida nemainīgā
            //         attālumam starp tiem jābūt reizināmajam ar pointee lielumu
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// `Iter` un `IterMut` atkārtotāju kopīga definīcija
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Atgriež pirmo elementu un pārvieto iteratora sākumu uz priekšu par 1.
        // Ļoti uzlabo veiktspēju, salīdzinot ar iestrādāto funkciju.
        // Atkārtotājs nedrīkst būt tukšs.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Atgriež pēdējo elementu un pārvieto iteratora galu par 1 atpakaļ.
        // Ļoti uzlabo veiktspēju, salīdzinot ar iestrādāto funkciju.
        // Atkārtotājs nedrīkst būt tukšs.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Samazina iteratoru, kad T ir ZST, pārvietojot iteratora galu par `n` atpakaļ.
        // `n` nedrīkst pārsniegt `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Palīga funkcija griezuma izveidošanai no iteratora.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // DROŠĪBA: iterators tika izveidots no šķēles ar rādītāju
                // `self.ptr` un garums `len!(self)`.
                // Tas garantē, ka visi `from_raw_parts` priekšnosacījumi ir izpildīti.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Palīdzētāja funkcija iteratora sākuma virzīšanai uz priekšu pa `offset` elementiem, atgriežot veco sākumu.
            //
            // Nedrošs, jo nobīde nedrīkst pārsniegt `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // DROŠĪBA: zvanītājs garantē, ka `offset` nepārsniedz `self.len()`,
                    // tāpēc šis jaunais rādītājs atrodas `self` iekšpusē un tādējādi tiek garantēts, ka tas nebūs nulle.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Palīdzētāja funkcija iteratora gala pārvietošanai ar `offset` elementiem atpakaļ, atgriežot jauno galu.
            //
            // Nedrošs, jo nobīde nedrīkst pārsniegt `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // DROŠĪBA: zvanītājs garantē, ka `offset` nepārsniedz `self.len()`,
                    // kas garantē, ka nepārsniegs `isize`.
                    // Iegūtais rādītājs atrodas arī `slice` robežās, kas atbilst citām `offset` prasībām.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // varētu ieviest ar šķēlītēm, taču tas ļauj izvairīties no robežkontroles

                // DROŠĪBA: `assume` zvani ir droši, jo šķēles sākuma rādītājs
                // nav jābūt nullei, un arī šķēlēm, kas nav ZST, jābūt gala rādītājam, kas nav nulle.
                // Zvans uz `next_unchecked!` ir drošs, jo mēs vispirms pārbaudām, vai iterators ir tukšs.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Šis atkārtotājs tagad ir tukšs.
                    if mem::size_of::<T>() == 0 {
                        // Mums tas jādara šādā veidā, jo `ptr` nekad nevar būt 0, bet `end` varētu būt (iesaiņošanas dēļ).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // DROŠĪBA: beigas nevar būt 0, ja T nav ZST, jo ptr nav 0 un beigas>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // DROŠĪBA: Mēs esam robežās.`post_inc_start` pareizi rīkojas pat ZST.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Mēs ignorējam noklusējuma ieviešanu, kas izmanto `try_fold`, jo šī vienkāršā ieviešana rada mazāk LLVM IR un ir ātrāk apkopojama.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Mēs ignorējam noklusējuma ieviešanu, kas izmanto `try_fold`, jo šī vienkāršā ieviešana rada mazāk LLVM IR un ir ātrāk apkopojama.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Mēs ignorējam noklusējuma ieviešanu, kas izmanto `try_fold`, jo šī vienkāršā ieviešana rada mazāk LLVM IR un ir ātrāk apkopojama.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Mēs ignorējam noklusējuma ieviešanu, kas izmanto `try_fold`, jo šī vienkāršā ieviešana rada mazāk LLVM IR un ir ātrāk apkopojama.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Mēs ignorējam noklusējuma ieviešanu, kas izmanto `try_fold`, jo šī vienkāršā ieviešana rada mazāk LLVM IR un ir ātrāk apkopojama.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Mēs ignorējam noklusējuma ieviešanu, kas izmanto `try_fold`, jo šī vienkāršā ieviešana rada mazāk LLVM IR un ir ātrāk apkopojama.
            // Tāpat `assume` izvairās no robežu pārbaudes.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // DROŠĪBA: mums tiek garantēts, ka cilpas nemainīgais:
                        // kad `i >= n`, `self.next()` atgriež `None` un cilpa pārtrauc.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Mēs ignorējam noklusējuma ieviešanu, kas izmanto `try_fold`, jo šī vienkāršā ieviešana rada mazāk LLVM IR un ir ātrāk apkopojama.
            // Tāpat `assume` izvairās no robežu pārbaudes.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // DROŠĪBA: `i` jābūt zemākam par `n`, jo tas sākas ar `n`
                        // un tikai samazinās.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // DROŠĪBA: zvanītājam jāgarantē, ka `i` ir robežās
                // pamatā esošā šķēle, tāpēc `i` nevar pārpildīt `isize`, un atgrieztās atsauces tiek garantētas kā atsauces uz šķēles elementu un tādējādi garantētas kā derīgas.
                //
                // Ņemiet vērā arī to, ka zvanītājs garantē arī to, ka mēs nekad vairs netiek zvanīti ar to pašu indeksu un ka netiek izmantotas citas metodes, kas piekļūs šai apakšslicei, tāpēc ir derīgi, ja atgrieztā atsauce ir maināma.
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // varētu ieviest ar šķēlītēm, taču tas ļauj izvairīties no robežkontroles

                // DROŠĪBA: `assume` zvani ir droši, jo daļas sākuma rādītājam nav jābūt nullei,
                // un sadaļām, kas nav ZST, jābūt arī gala rādītājam, kas nav nulle.
                // Zvans uz `next_back_unchecked!` ir drošs, jo mēs vispirms pārbaudām, vai iterators ir tukšs.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Šis atkārtotājs tagad ir tukšs.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // DROŠĪBA: Mēs esam robežās.`pre_dec_end` pareizi rīkojas pat ZST.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}