//! Modulis darbam ar aizņemtajiem datiem.

#![stable(feature = "rust1", since = "1.0.0")]

/// trait datu aizņemšanai.
///
/// Programmā Rust parasti tiek piedāvāti dažādi tipa attēlojumi dažādiem lietošanas gadījumiem.
/// Piemēram, vērtības glabāšanas vietu un pārvaldību var īpaši izvēlēties kā piemērotu konkrētai lietošanai, izmantojot rādītāju tipus, piemēram, [`Box<T>`] vai [`Rc<T>`].
/// Papildus šiem vispārīgajiem iesaiņotājiem, kurus var izmantot ar jebkuru veidu, daži veidi nodrošina izvēles šķautnes, kas nodrošina potenciāli dārgu funkcionalitāti.
/// Šāda veida piemērs ir [`String`], kas pievieno virknes pagarināšanas iespēju pamata [`str`].
/// Tas prasa papildu informācijas glabāšanu vienkāršai, nemainīgai virknei.
///
/// Šie veidi nodrošina piekļuvi pamatā esošajiem datiem, izmantojot atsauces uz šo datu tipu.Tiek teikts, ka viņi ir "aizņemti kā" šāda veida.
/// Piemēram, [`Box<T>`] var aizņemties kā `T`, bet [`String`]-`str`.
///
/// Veidi izsaka to, ka tos var aizņemties kā dažus `T` tipus, ieviešot `Borrow<T>`, sniedzot atsauci uz `T` trait [`borrow`] metodē.Veids var aizņemties kā vairākus dažādus veidus.
/// Ja tā vēlas savstarpēji aizņemties kā veidu-ļaujot modificēt pamatā esošos datus, tā var papildus ieviest [`BorrowMut<T>`].
///
/// Turklāt, nodrošinot papildu traits ieviešanu, ir jāapsver, vai viņiem vajadzētu rīkoties identiski pamata tipam, darbojoties kā pamatā esošā tipa attēlam.
/// Vispārējais kods parasti izmanto `Borrow<T>`, ja tas paļaujas uz šo papildu trait ieviešanas identisku rīcību.
/// Šie traits, visticamāk, parādīsies kā papildu trait bounds.
///
/// Īpaši `Eq`, `Ord` un `Hash` jābūt ekvivalentām aizņemtajām un piederošajām vērtībām: `x.borrow() == y.borrow()` vajadzētu dot tādu pašu rezultātu kā `x == y`.
///
/// Ja vispārīgajam kodam ir jādarbojas tikai visiem tipiem, kas var sniegt atsauci uz saistīto `T` tipu, bieži vien labāk ir izmantot [`AsRef<T>`], jo vairāku veidu to var droši ieviest.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Kā datu kolekcijai [`HashMap<K, V>`] pieder gan atslēgas, gan vērtības.Ja atslēgas faktiskie dati ir iesaiņoti kāda veida pārvaldības veidos, tomēr joprojām vajadzētu būt iespējai meklēt vērtību, izmantojot atsauci uz atslēgas datiem.
/// Piemēram, ja atslēga ir virkne, tā, visticamāk, tiek saglabāta ar jaukšanas karti kā [`String`], bet tai vajadzētu būt iespējai meklēt, izmantojot [`&str`][`str`].
/// Tādējādi `insert` ir jādarbojas ar `String`, savukārt `get` jāspēj izmantot `&str`.
///
/// Nedaudz vienkāršoti, attiecīgās `HashMap<K, V>` daļas izskatās šādi:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // lauki ir izlaisti
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// Visa hash karte ir vispārīga, izmantojot atslēgas veidu `K`.Tā kā šie taustiņi tiek glabāti kopā ar jaukšanas karti, šim tipam ir jāpieder atslēgas datiem.
/// Ievietojot atslēgu un vērtību pāri, kartei tiek piešķirts šāds `K`, un tai jāatrod pareizais jaucējkrāns un jāpārbauda, vai atslēga jau ir, pamatojoties uz šo `K`.Tāpēc tam ir nepieciešama `K: Hash + Eq`.
///
/// Tomēr, meklējot vērtību kartē, vienmēr jānorāda atsauce uz `K` kā meklējamo atslēgu.
/// Virknes atslēgām tas nozīmētu, ka `String` vērtība ir jāizveido tikai tādu gadījumu meklēšanai, kur ir pieejams tikai `str`.
///
/// Tā vietā `get` metode ir vispārīga attiecībā uz pamatā esošo galveno datu tipu, kas iepriekš aprakstītajā metodes parakstā tiek saukts par `Q`.Tajā teikts, ka `K` aizņemas kā `Q`, pieprasot šo `K: Borrow<Q>`.
/// Papildus pieprasot `Q: Hash + Eq`, tas norāda uz prasību, ka `K` un `Q` ir `Hash` un `Eq` traits ieviešana, kas rada identiskus rezultātus.
///
/// `get` ieviešana jo īpaši balstās uz identiskām `Hash` ieviešanām, nosakot atslēgas jaucējkrānu, izsaucot `Hash::hash` uz `Q` vērtību, pat ja tā ievietoja atslēgu, pamatojoties uz hash vērtību, kas aprēķināta no `K` vērtības.
///
///
/// Tā rezultātā jaukšanas karte saplīst, ja `K`, kas iesaiņo `Q` vērtību, rada citu jaukšanu nekā `Q`.Piemēram, iedomājieties, ka jums ir tips, kas ietin virkni, bet salīdzina ASCII burtus, ignorējot to reģistru:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Tā kā divām vienādām vērtībām ir jāveido viena un tā pati jaukšanas vērtība, `Hash` ieviešanai ir jāignorē arī ASCII gadījums:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// Vai `CaseInsensitiveString` var ieviest `Borrow<str>`?Tas noteikti var sniegt atsauci uz virknes šķēli, izmantojot tai piederošo virkni.
/// Bet tā kā tā `Hash` ieviešana atšķiras, tā uzvedas atšķirīgi no `str` un tāpēc faktiski nedrīkst ieviest `Borrow<str>`.
/// Ja tā vēlas ļaut citiem piekļūt pamatā esošajam `str`, to var izdarīt, izmantojot `AsRef<str>`, kam nav nekādu papildu prasību.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Neaizmirstami aizņemas no īpašumā esošas vērtības.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// trait, lai savstarpēji aizņemtos datus.
///
/// trait kā [`Borrow<T>`] pavadonis ļauj tipam aizņemties kā pamata tipu, nodrošinot maināmu atsauci.
/// Skatiet [`Borrow<T>`], lai iegūtu plašāku informāciju par aizņemšanos kā citu veidu.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Mainīgi aizņemas no īpašumā esošas vērtības.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}