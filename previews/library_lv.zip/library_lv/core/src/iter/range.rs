use crate::char;
use crate::convert::TryFrom;
use crate::mem;
use crate::ops::{self, Try};

use super::{FusedIterator, TrustedLen};

/// Objekti, kuriem ir jēdziens *pēctecis* un *priekšgājējs*.
///
/// Darbība *pēctecis* virzās uz vērtībām, kas ir lielākas.
/// *Priekšgājēja* darbība virzās uz vērtībām, kuras salīdzina mazāk.
///
/// # Safety
///
/// Šis trait ir `unsafe`, jo tā ieviešanai ir jābūt pareizai, lai nodrošinātu `unsafe trait TrustedLen` ieviešanas drošību, un citādi ar trait izmantošanas rezultātiem var uzticēties `unsafe` kods, lai tie būtu pareizi un izpildītu uzskaitītās saistības.
///
///
///
#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
pub unsafe trait Step: Clone + PartialOrd + Sized {
    /// Atgriež *pēctecības* soļu skaitu, kas nepieciešams, lai pārietu no `start` uz `end`.
    ///
    /// Atgriež vērtību `None`, ja darbību skaits pārpildīs `usize` (vai ir bezgalīgs vai ja `end` nekad netiks sasniegts).
    ///
    ///
    /// # Invariants
    ///
    /// Jebkuram `a`, `b` un `n`:
    ///
    /// * `steps_between(&a, &b) == Some(n)` tikai tad, ja `Step::forward_checked(&a, n) == Some(b)`
    /// * `steps_between(&a, &b) == Some(n)` tikai tad, ja `Step::backward_checked(&a, n) == Some(a)`
    /// * `steps_between(&a, &b) == Some(n)` tikai tad, ja `a <= b`
    ///   * Secinājums: `steps_between(&a, &b) == Some(0)` tikai tad, ja `a == b`
    ///   * Ņemiet vērā, ka `a <= b` nozīmē, ka _not_ nozīmē `steps_between(&a, &b) != None`;
    ///     tas ir gadījums, kad, lai nokļūtu `b`, būtu nepieciešami vairāk nekā `usize::MAX` soļi
    /// * `steps_between(&a, &b) == None` ja `a > b`
    fn steps_between(start: &Self, end: &Self) -> Option<usize>;

    /// Atgriež vērtību, kas tiktu iegūta, ņemot `self` `count` reizes *pēcteci*.
    ///
    /// Ja tas pārpildīs vērtību diapazonu, ko atbalsta `Self`, atgriež vērtību `None`.
    ///
    /// # Invariants
    ///
    /// Jebkuram `a`, `n` un `m`:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, m).and_then(|x| Step::forward_checked(x, n))`
    ///
    ///
    /// Jebkuram `a`, `n` un `m`, kur `n + m` nepārplūst:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, n + m)`
    ///
    /// Jebkuram `a` un `n`:
    ///
    /// * `Step::forward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::forward_checked(&x, 1))`
    ///   * Corollary: `Step::forward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward_checked(start: Self, count: usize) -> Option<Self>;

    /// Atgriež vērtību, kas tiktu iegūta, ņemot `self` `count` reizes *pēcteci*.
    ///
    /// Ja tas pārsniegtu `Self` atbalstīto vērtību diapazonu, šai funkcijai ir atļauts panic, ietīt vai piesātināt.
    ///
    /// Ieteicamā rīcība ir panic, ja ir iespējoti atkļūdošanas apgalvojumi, un citādi ietīt vai piesātināt.
    ///
    /// Nedrošam kodam nevajadzētu paļauties uz uzvedības pareizību pēc pārpildes.
    ///
    /// # Invariants
    ///
    /// Jebkuram `a`, `n` un `m`, kur nepārsniedz pārpildi:
    ///
    /// * `Step::forward(Step::forward(a, n), m) == Step::forward(a, n + m)`
    ///
    /// Jebkuram `a` un `n`, kur nepārsniedz pārpildi:
    ///
    /// * `Step::forward_checked(a, n) == Some(Step::forward(a, n))`
    /// * `Step::forward(a, n) == (0..n).fold(a, |x, _| Step::forward(x, 1))`
    ///   * Corollary: `Step::forward(a, 0) == a`
    /// * `Step::forward(a, n) >= a`
    /// * `Step::backward(Step::forward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward(start: Self, count: usize) -> Self {
        Step::forward_checked(start, count).expect("overflow in `Step::forward`")
    }

    /// Atgriež vērtību, kas tiktu iegūta, ņemot `self` `count` reizes *pēcteci*.
    ///
    /// # Safety
    ///
    /// Šīs operācijas rīcība ir nenoteikta, lai pārpildītu `Self` atbalstīto vērtību diapazonu.
    /// Ja nevarat garantēt, ka tas netiks pārpildīts, tā vietā izmantojiet `forward` vai `forward_checked`.
    ///
    /// # Invariants
    ///
    /// Jebkuram `a`:
    ///
    /// * ja pastāv `b`, piemēram, `b > a`, droši var piezvanīt uz `Step::forward_unchecked(a, 1)`
    /// * ja pastāv `b`, `n`, piemēram, `steps_between(&a, &b) == Some(n)`, droši var piezvanīt uz `Step::forward_unchecked(a, m)` jebkuram `m <= n`.
    ///
    ///
    /// Jebkuram `a` un `n`, kur nepārsniedz pārpildi:
    ///
    /// * `Step::forward_unchecked(a, n)` ir ekvivalents `Step::forward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn forward_unchecked(start: Self, count: usize) -> Self {
        Step::forward(start, count)
    }

    /// Atgriež vērtību, kas tiktu iegūta, ņemot `self` `count` reizes *priekšgājēju*.
    ///
    /// Ja tas pārpildīs vērtību diapazonu, ko atbalsta `Self`, atgriež vērtību `None`.
    ///
    /// # Invariants
    ///
    /// Jebkuram `a`, `n` un `m`:
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == n.checked_add(m).and_then(|x| Step::backward_checked(a, x))`
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == try { Step::backward_checked(a, n.checked_add(m)?) }`
    ///
    /// Jebkuram `a` un `n`:
    ///
    /// * `Step::backward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::backward_checked(&x, 1))`
    ///   * Corollary: `Step::backward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward_checked(start: Self, count: usize) -> Option<Self>;

    /// Atgriež vērtību, kas tiktu iegūta, ņemot `self` `count` reizes *priekšgājēju*.
    ///
    /// Ja tas pārsniegtu `Self` atbalstīto vērtību diapazonu, šai funkcijai ir atļauts panic, ietīt vai piesātināt.
    ///
    /// Ieteicamā rīcība ir panic, ja ir iespējoti atkļūdošanas apgalvojumi, un citādi ietīt vai piesātināt.
    ///
    /// Nedrošam kodam nevajadzētu paļauties uz uzvedības pareizību pēc pārpildes.
    ///
    /// # Invariants
    ///
    /// Jebkuram `a`, `n` un `m`, kur nepārsniedz pārpildi:
    ///
    /// * `Step::backward(Step::backward(a, n), m) == Step::backward(a, n + m)`
    ///
    /// Jebkuram `a` un `n`, kur nepārsniedz pārpildi:
    ///
    /// * `Step::backward_checked(a, n) == Some(Step::backward(a, n))`
    /// * `Step::backward(a, n) == (0..n).fold(a, |x, _| Step::backward(x, 1))`
    ///   * Corollary: `Step::backward(a, 0) == a`
    /// * `Step::backward(a, n) <= a`
    /// * `Step::forward(Step::backward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward(start: Self, count: usize) -> Self {
        Step::backward_checked(start, count).expect("overflow in `Step::backward`")
    }

    /// Atgriež vērtību, kas tiktu iegūta, ņemot `self` `count` reizes *priekšgājēju*.
    ///
    /// # Safety
    ///
    /// Šīs operācijas rīcība ir nenoteikta, lai pārpildītu `Self` atbalstīto vērtību diapazonu.
    /// Ja nevarat garantēt, ka tas netiks pārpildīts, tā vietā izmantojiet `backward` vai `backward_checked`.
    ///
    /// # Invariants
    ///
    /// Jebkuram `a`:
    ///
    /// * ja pastāv `b`, piemēram, `b < a`, droši var piezvanīt uz `Step::backward_unchecked(a, 1)`
    /// * ja pastāv `b`, `n`, piemēram, `steps_between(&b, &a) == Some(n)`, droši var piezvanīt uz `Step::backward_unchecked(a, m)` jebkuram `m <= n`.
    ///
    ///
    /// Jebkuram `a` un `n`, kur nepārsniedz pārpildi:
    ///
    /// * `Step::backward_unchecked(a, n)` ir ekvivalents `Step::backward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn backward_unchecked(start: Self, count: usize) -> Self {
        Step::backward(start, count)
    }
}

// Tie joprojām tiek veidoti makro, jo veselu skaitļu literāļi atšķiras no dažādiem tipiem.
macro_rules! step_identical_methods {
    () => {
        #[inline]
        unsafe fn forward_unchecked(start: Self, n: usize) -> Self {
            // DROŠĪBA: zvanītājam ir jāgarantē, ka `start + n` nepārplūst.
            unsafe { start.unchecked_add(n as Self) }
        }

        #[inline]
        unsafe fn backward_unchecked(start: Self, n: usize) -> Self {
            // DROŠĪBA: zvanītājam ir jāgarantē, ka `start - n` nepārplūst.
            unsafe { start.unchecked_sub(n as Self) }
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn forward(start: Self, n: usize) -> Self {
            // Atkļūdošanas būvēs aktivizējiet panic pārplūdi.
            // Tam pilnībā vajadzētu optimizēt izlaišanas versijās.
            if Self::forward_checked(start, n).is_none() {
                let _ = Self::MAX + 1;
            }
            // Veiciet iesaiņošanas matemātiku, lai atļautu, piem `Step::forward(-128i8, 255)`.
            start.wrapping_add(n as Self)
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn backward(start: Self, n: usize) -> Self {
            // Atkļūdošanas būvēs aktivizējiet panic pārplūdi.
            // Tam pilnībā vajadzētu optimizēt izlaišanas versijās.
            if Self::backward_checked(start, n).is_none() {
                let _ = Self::MIN - 1;
            }
            // Veiciet iesaiņošanas matemātiku, lai atļautu, piem `Step::backward(127i8, 255)`.
            start.wrapping_sub(n as Self)
        }
    };
}

macro_rules! step_integer_impls {
    {
        narrower than or same width as usize:
            $( [ $u_narrower:ident $i_narrower:ident ] ),+;
        wider than usize:
            $( [ $u_wider:ident $i_wider:ident ] ),+;
    } => {
        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Tas paļaujas uz $u_narrower <=usize
                        Some((*end - *start) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_add(n),
                        Err(_) => None, // ja n ir ārpus diapazona, arī `unsigned_start + n`
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_sub(n),
                        Err(_) => None, // ja n ir ārpus diapazona, arī `unsigned_start - n`
                    }
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Tas paļaujas uz $i_narrower <=usize
                        //
                        // Lietošana pēc izmēra pagarina platumu, bet saglabā zīmi.
                        // Izmantojiet wrapping_sub isize telpā un lietojiet, lai izmantotu, lai aprēķinātu atšķirību, kas, iespējams, neietilpst isize diapazonā.
                        //
                        Some((*end as isize).wrapping_sub(*start as isize) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Aptinumi rokturi, piemēram, `Step::forward(-120_i8, 200) == Some(80_i8)`, pat ja 200 ir ārpus i8 diapazona.
                            //
                            //
                            let wrapped = start.wrapping_add(n as Self);
                            if wrapped >= start {
                                Some(wrapped)
                            } else {
                                None // Papildinājums pārpildīts
                            }
                        }
                        // Ja n ir ārpus piem
                        // u8, tad tas ir lielāks nekā viss i8 diapazons ir plašs, tāpēc `any_i8 + n` obligāti pārpilda i8.
                        //
                        Err(_) => None,
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Aptinumi rokturi, piemēram, `Step::forward(-120_i8, 200) == Some(80_i8)`, pat ja 200 ir ārpus i8 diapazona.
                            //
                            //
                            let wrapped = start.wrapping_sub(n as Self);
                            if wrapped <= start {
                                Some(wrapped)
                            } else {
                                None // Atņemšana ir pārpildīta
                            }
                        }
                        // Ja n ir ārpus piem
                        // u8, tad tas ir lielāks nekā viss i8 diapazons ir plašs, tāpēc `any_i8 - n` obligāti pārpilda i8.
                        //
                        Err(_) => None,
                    }
                }
            }
        )+

        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        usize::try_from(*end - *start).ok()
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        match end.checked_sub(*start) {
                            Some(result) => usize::try_from(result).ok(),
                            // Ja starpība ir pārāk liela, piem
                            // i128, tas arī būs pārāk liels, lai to izmantotu ar mazāk bitiem.
                            None => None,
                        }
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }
        )+
    };
}

#[cfg(target_pointer_width = "64")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [u64 i64], [usize isize];
    wider than usize: [u128 i128];
}

#[cfg(target_pointer_width = "32")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [usize isize];
    wider than usize: [u64 i64], [u128 i128];
}

#[cfg(target_pointer_width = "16")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [usize isize];
    wider than usize: [u32 i32], [u64 i64], [u128 i128];
}

#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
unsafe impl Step for char {
    #[inline]
    fn steps_between(&start: &char, &end: &char) -> Option<usize> {
        let start = start as u32;
        let end = end as u32;
        if start <= end {
            let count = end - start;
            if start < 0xD800 && 0xE000 <= end {
                usize::try_from(count - 0x800).ok()
            } else {
                usize::try_from(count).ok()
            }
        } else {
            None
        }
    }

    #[inline]
    fn forward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::forward_checked(start, count)?;
        if start < 0xD800 && 0xD800 <= res {
            res = Step::forward_checked(res, 0x800)?;
        }
        if res <= char::MAX as u32 {
            // DROŠĪBA: res ir derīgs unikoda skalārs
            // (zem 0x110000 un nav 0xD800..0xE000)
            Some(unsafe { char::from_u32_unchecked(res) })
        } else {
            None
        }
    }

    #[inline]
    fn backward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::backward_checked(start, count)?;
        if start >= 0xE000 && 0xE000 > res {
            res = Step::backward_checked(res, 0x800)?;
        }
        // DROŠĪBA: res ir derīgs unikoda skalārs
        // (zem 0x110000 un nav 0xD800..0xE000)
        Some(unsafe { char::from_u32_unchecked(res) })
    }

    #[inline]
    unsafe fn forward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // DROŠĪBA: zvanītājam jāgarantē, ka tas nepārplūst
        // char diapazona vērtību diapazons.
        let mut res = unsafe { Step::forward_unchecked(start, count) };
        if start < 0xD800 && 0xD800 <= res {
            // DROŠĪBA: zvanītājam jāgarantē, ka tas nepārplūst
            // char diapazona vērtību diapazons.
            res = unsafe { Step::forward_unchecked(res, 0x800) };
        }
        // DROŠĪBA: iepriekšējā līguma dēļ tas tiek garantēts
        // zvanītāja norādītais derīgums.
        unsafe { char::from_u32_unchecked(res) }
    }

    #[inline]
    unsafe fn backward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // DROŠĪBA: zvanītājam jāgarantē, ka tas nepārplūst
        // char diapazona vērtību diapazons.
        let mut res = unsafe { Step::backward_unchecked(start, count) };
        if start >= 0xE000 && 0xE000 > res {
            // DROŠĪBA: zvanītājam jāgarantē, ka tas nepārplūst
            // char diapazona vērtību diapazons.
            res = unsafe { Step::backward_unchecked(res, 0x800) };
        }
        // DROŠĪBA: iepriekšējā līguma dēļ tas tiek garantēts
        // zvanītāja norādītais derīgums.
        unsafe { char::from_u32_unchecked(res) }
    }
}

macro_rules! range_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl ExactSizeIterator for ops::Range<$t> { }
    )*)
}

macro_rules! range_incl_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "inclusive_range", since = "1.26.0")]
        impl ExactSizeIterator for ops::RangeInclusive<$t> { }
    )*)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::Range<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.start < self.end {
            // DROŠĪBA: tikko pārbaudīts priekšnosacījums
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            Some(mem::replace(&mut self.start, n))
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.start < self.end {
            let hint = Step::steps_between(&self.start, &self.end);
            (hint.unwrap_or(usize::MAX), hint)
        } else {
            (0, Some(0))
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            if plus_n < self.end {
                // DROŠĪBA: tikko pārbaudīts priekšnosacījums
                self.start = unsafe { Step::forward_unchecked(plus_n.clone(), 1) };
                return Some(plus_n);
            }
        }

        self.start = self.end.clone();
        None
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

// Šie makro ģenerē `ExactSizeIterator` implus dažādiem diapazona tipiem.
//
// * `ExactSizeIterator::len` ir nepieciešams, lai vienmēr atgrieztu precīzu `usize`, tāpēc neviens diapazons nevar būt garāks par `usize::MAX`.
//
// * Veselu skaitļu tipiem `Range<_>` gadījumā tas attiecas uz tipiem, kas ir šaurāki vai platāki par `usize`.
//   Veselu skaitļu tipiem `RangeInclusive<_>` tas attiecas uz tipiem *stingri šaurākiem* nekā `usize`, jo piem
//   `(0..=u64::MAX).len()` būtu `u64::MAX + 1`.
//
range_exact_iter_impl! {
    usize u8 u16
    isize i8 i16

    // Tie ir iekļauti saskaņā ar iepriekš minēto pamatojumu, taču to noņemšana būtu pārsteidzoša izmaiņa, jo tie tika stabilizēti Rust 1.0.0.
    // Tā, piem
    // `(0..66_000_u32).len()` piemēram, kompilēs bez kļūdām vai brīdinājumiem 16 bitu platformās, bet turpinās dot nepareizu rezultātu.
    //
    u32
    i32
}
range_incl_exact_iter_impl! {
    u8
    i8

    // Tie ir iekļauti saskaņā ar iepriekš minēto pamatojumu, taču to noņemšana būtu pārsteidzoša izmaiņa, jo tie tika stabilizēti Rust 1.26.0.
    // Tā, piem
    // `(0..=u16::MAX).len()` piemēram, kompilēs bez kļūdām vai brīdinājumiem 16 bitu platformās, bet turpinās dot nepareizu rezultātu.
    //
    u16
    i16
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> DoubleEndedIterator for ops::Range<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.start < self.end {
            // DROŠĪBA: tikko pārbaudīts priekšnosacījums
            self.end = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            Some(self.end.clone())
        } else {
            None
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            if minus_n > self.start {
                // DROŠĪBA: tikko pārbaudīts priekšnosacījums
                self.end = unsafe { Step::backward_unchecked(minus_n, 1) };
                return Some(self.end.clone());
            }
        }

        self.end = self.start.clone();
        None
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::Range<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::Range<A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::RangeFrom<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let n = Step::forward(self.start.clone(), 1);
        Some(mem::replace(&mut self.start, n))
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        let plus_n = Step::forward(self.start.clone(), n);
        self.start = Step::forward(plus_n.clone(), 1);
        Some(plus_n)
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeFrom<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeFrom<A> {}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> Iterator for ops::RangeInclusive<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // DROŠĪBA: tikko pārbaudīts priekšnosacījums
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            mem::replace(&mut self.start, n)
        } else {
            self.exhausted = true;
            self.start.clone()
        })
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.is_empty() {
            return (0, Some(0));
        }

        match Step::steps_between(&self.start, &self.end) {
            Some(hint) => (hint.saturating_add(1), hint.checked_add(1)),
            None => (usize::MAX, None),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            use crate::cmp::Ordering::*;

            match plus_n.partial_cmp(&self.end) {
                Some(Less) => {
                    self.start = Step::forward(plus_n.clone(), 1);
                    return Some(plus_n);
                }
                Some(Equal) => {
                    self.start = plus_n.clone();
                    self.exhausted = true;
                    return Some(plus_n);
                }
                _ => {}
            }
        }

        self.start = self.end.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // DROŠĪBA: tikko pārbaudīts priekšnosacījums
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            let n = mem::replace(&mut self.start, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn fold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(f)).unwrap()
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> DoubleEndedIterator for ops::RangeInclusive<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // DROŠĪBA: tikko pārbaudīts priekšnosacījums
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            mem::replace(&mut self.end, n)
        } else {
            self.exhausted = true;
            self.end.clone()
        })
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            use crate::cmp::Ordering::*;

            match minus_n.partial_cmp(&self.start) {
                Some(Greater) => {
                    self.end = Step::backward(minus_n.clone(), 1);
                    return Some(minus_n);
                }
                Some(Equal) => {
                    self.end = minus_n.clone();
                    self.exhausted = true;
                    return Some(minus_n);
                }
                _ => {}
            }
        }

        self.end = self.start.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // DROŠĪBA: tikko pārbaudīts priekšnosacījums
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            let n = mem::replace(&mut self.end, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn rfold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_rfold(init, ok(f)).unwrap()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeInclusive<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeInclusive<A> {}