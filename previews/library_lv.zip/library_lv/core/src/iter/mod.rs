//! Komponējama ārējā iterācija.
//!
//! Ja esat atradis kādu kolekciju un jums vajadzēja veikt operāciju ar minētās kolekcijas elementiem, jūs ātri nokļūsit 'iterators'.
//! Iteratori tiek daudz izmantoti idiomātiskajā Rust kodā, tāpēc ir vērts ar tiem iepazīties.
//!
//! Pirms paskaidrot vairāk, parunāsim par šī moduļa struktūru:
//!
//! # Organization
//!
//! Šis modulis lielā mērā ir sakārtots pēc veida:
//!
//! * [Traits] ir galvenā daļa: šie traits nosaka, kādi iteratori pastāv un ko jūs varat darīt ar tiem.Šo traits metodēm ir vērts veltīt papildu mācību laiku.
//! * [Functions] sniedziet dažus noderīgus veidus, kā izveidot dažus pamata atkārtotājus.
//! * [Structs] bieži ir šī moduļa traits dažādu metožu atgriešanās veidi.Parasti vēlaties apskatīt metodi, kas rada `struct`, nevis pašu `struct`.
//! Lai iegūtu sīkāku informāciju par iemeslu, skatiet sadaļu `[Iteratora ieviešana](#ieviešanas atkārtotājs)`.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Tieši tā!Iegremdēsimies atkārtotājus.
//!
//! # Iterator
//!
//! Šī moduļa sirds un dvēsele ir [`Iterator`] trait.[`Iterator`] kodols izskatās šādi:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Atkārtotājam ir metode [`next`], kas, izsaukta, atgriež [`Option`]<Item>".
//! [`next`] atgriezīs [`Some(Item)`], kamēr vien ir elementi, un, kad tie visi būs izsmelti, atgriezīsies `None`, lai norādītu, ka iterācija ir pabeigta.
//! Atsevišķi atkārtotāji var izvēlēties atjaunot atkārtojumu, un tāpēc [`next`] atkārtota izsaukšana var kaut kādā brīdī atsākt [`Some(Item)`] atgriešanos (piemēram, sk. [`TryIter`]).
//!
//!
//! [`Iterator`] pilnā definīcijā ietilpst arī vairākas citas metodes, taču tās ir noklusējuma metodes, kas veidotas virs [`next`], un tāpēc jūs tās saņemat bez maksas.
//!
//! Iteratori ir arī saliekami, un parasti tos savieno kopā, lai veiktu sarežģītākas apstrādes formas.Sīkāku informāciju skatiet zemāk esošajā sadaļā [Adapters](#adapters).
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Trīs atkārtojuma formas
//!
//! Ir trīs izplatītas metodes, kas var izveidot atkārtotājus no kolekcijas:
//!
//! * `iter()`, kas atkārtojas pa `&T`.
//! * `iter_mut()`, kas atkārtojas pa `&mut T`.
//! * `into_iter()`, kas atkārtojas pa `T`.
//!
//! Dažādas lietas standarta bibliotēkā vajadzības gadījumā var īstenot vienu vai vairākus no trim.
//!
//! # Iteratora ieviešana
//!
//! Lai izveidotu savu iteratoru, ir jāveic divas darbības: `struct` izveidošana iteratora stāvokļa noturēšanai un pēc tam [`Iterator`] ieviešana šai `struct`.
//! Tāpēc šajā modulī ir tik daudz `struct`s: katram iteratoram un iteratora adapterim ir viens.
//!
//! Izveidosim iteratoru ar nosaukumu `Counter`, kas skaitīs no `1` līdz `5`:
//!
//! ```
//! // Pirmkārt, struct:
//!
//! /// Atkārtotājs, kas skaita no viena līdz pieciem
//! struct Counter {
//!     count: usize,
//! }
//!
//! // mēs vēlamies, lai mūsu skaitīšana sākas ar vienu, tāpēc pievienosim new() metodi, lai palīdzētu.
//! // Tas nav absolūti nepieciešams, bet ir ērti.
//! // Ņemiet vērā, ka mēs sākam `count` ar nulli, mēs redzēsim, kāpēc `next()`'s ieviešanā.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Pēc tam mēs ieviešam `Iterator` savam `Counter`:
//!
//! impl Iterator for Counter {
//!     // mēs skaitīsim ar usize
//!     type Item = usize;
//!
//!     // next() ir vienīgā nepieciešamā metode
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Palieliniet mūsu skaitu.Tāpēc mēs sākām no nulles.
//!         self.count += 1;
//!
//!         // Pārbaudiet, vai mēs esam pabeiguši skaitīšanu vai nē.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // Un tagad mēs to varam izmantot!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Šādi zvanot uz [`next`], tas atkārtojas.Rust ir konstrukcija, kas iteratorā var izsaukt [`next`], līdz tā sasniedz `None`.Turpināsim to tālāk.
//!
//! Ņemiet vērā arī to, ka `Iterator` nodrošina noklusējuma metožu ieviešanu, piemēram, `nth` un `fold`, kuras iekšēji izsauc `next`.
//! Tomēr ir iespējams arī uzrakstīt tādu metožu kā `nth` un `fold` pielāgotu ieviešanu, ja iterators var tās efektīvāk aprēķināt, neizsaucot `next`.
//!
//! # `for` cilpas un `IntoIterator`
//!
//! Rust `for` cilpas sintakse faktiski ir cukurs iteratoriem.Šeit ir `for` pamatpiemērs:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Tas izdrukās skaitļus no viena līdz pieciem, katrs uz savas līnijas.Bet jūs kaut ko pamanīsit šeit: mēs nekad savā vector neko nezvanījām, lai izveidotu iteratoru.Kas dod?
//!
//! Lai pārveidotu kaut ko par iteratoru, standarta bibliotēkā ir trait: [`IntoIterator`].
//! Šim trait ir viena metode [`into_iter`], kas pārvērš lietu [`IntoIterator`] par iteratoru.
//! Apskatīsim vēlreiz šo `for` cilpu un to, ko kompilators to pārvērš:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust no tā cukurojas:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Pirmkārt, mēs izsaucam vērtību `into_iter()`.Tad mēs saskaņojamies ar iteratoru, kas atgriežas, atkārtoti izsaucot [`next`], līdz redzam `None`.
//! Tajā brīdī mēs `break` esam ārpus cilpas, un mēs esam paveikuši atkārtojumu.
//!
//! Šeit ir vēl viens smalks bits: standarta bibliotēkā ir interesanta [`IntoIterator`] ieviešana:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Citiem vārdiem sakot, visi [`Iterator`] ievieš [`IntoIterator`], vienkārši atgriežoties paši.Tas nozīmē divas lietas:
//!
//! 1. Ja rakstāt [`Iterator`], varat to izmantot kopā ar `for` cilpu.
//! 2. Ja veidojat kolekciju, [`IntoIterator`] ieviešana tai ļaus kolekciju izmantot kopā ar `for` cilpu.
//!
//! # Atkārtojot pēc atsauces
//!
//! Tā kā [`into_iter()`] ņem vērtību `self`, izmantojot `for` cilpu, lai atkārtotu kolekciju, šī kolekcija tiek patērēta.Bieži vien jūs varētu vēlēties atkārtot kolekciju, to neizmantojot.
//! Daudzās kolekcijās tiek piedāvātas metodes, kas nodrošina iteratorus salīdzinājumā ar atsaucēm, ko parasti sauc par attiecīgi `iter()` un `iter_mut()`:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` joprojām pieder šai funkcijai.
//! ```
//!
//! Ja kolekcijas tips `C` nodrošina `iter()`, tas parasti arī ievieš `IntoIterator` operētājsistēmai `&C` ar ieviešanu, kas vienkārši izsauc `iter()`.
//! Tāpat kolekcija `C`, kas nodrošina `iter_mut()`, parasti ievieš `IntoIterator` operētājsistēmai `&mut C`, deleģējot `iter_mut()`.Tas nodrošina ērtu stenogrāfiju:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // tāds pats kā `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // tāds pats kā `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Lai gan daudzās kolekcijās tiek piedāvāts `iter()`, ne visās tiek piedāvāts `iter_mut()`.
//! Piemēram, mutējot [`HashSet<T>`] vai [`HashMap<K, V>`] taustiņus, kolekcija var nonākt nekonsekventā stāvoklī, ja mainās atslēgu jaukšana, tāpēc šīs kolekcijas piedāvā tikai `iter()`.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Funkcijas, kas ņem [`Iterator`] un atgriež citu [`Iterator`], bieži sauc par `iteratora adapteriem`, jo tās ir `adaptera` formas
//! pattern'.
//!
//! Kopējie iteratora adapteri ietver [`map`], [`take`] un [`filter`].
//! Lai uzzinātu vairāk, skatiet viņu dokumentāciju.
//!
//! Ja iteratora adapteris panics, iterators būs nenoteiktā (bet atmiņā drošā) stāvoklī.
//! Šis stāvoklis arī netiek garantēts, ka tas paliks nemainīgs visās Rust versijās, tāpēc jums nevajadzētu paļauties uz precīzām vērtībām, kuras atgriezis panikā radies iterators.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Iteratori (un iterators [adapters](#adapters)) ir *slinks*. Tas nozīmē, ka tikai ar iteratora izveidošanu _do_ viss nenotiek. Nekas īsti nenotiek, kamēr nezvanāt uz [`next`].
//! Dažreiz tas rada neskaidrības, veidojot iteratoru tikai tā blakusparādību dēļ.
//! Piemēram, metode [`map`] izsauc katra elementa slēgšanu, kurā tas atkārtojas:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Tas nedrukās nevienu vērtību, jo mēs to izveidojām, nevis izmantojām.Sastādītājs mūs brīdinās par šāda veida rīcību:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Idiomātisks veids, kā rakstīt [`map`] tā blakusparādībām, ir izmantot `for` cilpu vai izsaukt metodi [`for_each`]:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Vēl viens izplatīts veids, kā novērtēt iteratoru, ir [`collect`] metodes izmantošana, lai izveidotu jaunu kolekciju.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Iteratoriem nav jābūt ierobežotiem.Piemēram, atvērts diapazons ir bezgalīgs atkārtotājs:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! [`take`] iteratora adapteri parasti izmanto, lai bezgalīgu iteratoru pārvērstu par ierobežotu:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Tādējādi tiks izdrukāti skaitļi `0` līdz `4`, katrs uz savas līnijas.
//!
//! Paturiet prātā, ka metodes bezgalīgos atkārtotājos, pat tādas, kuru rezultātu matemātiski var noteikt ierobežotā laikā, var nebūt beigušās.
//! Konkrēti, tādas metodes kā [`min`], kas parasti prasa šķērsot katru iteratora elementu, visticamāk, neatgriezīsies nevienam bezgalīgam atkārtotājam.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Ak nē!Bezgalīga cilpa!
//! // `ones.min()` izraisa bezgalīgu cilpu, tāpēc mēs šo punktu nesasniegsim!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;