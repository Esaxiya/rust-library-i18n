use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// Šis trait nodrošina pārejošu piekļuvi avota stadijai interatora-adaptera cauruļvadā ar nosacījumiem, ka
/// * iteratora avots `S` pats ievieš `SourceIter<Source = S>`
/// * tiek deleģēta šī trait ieviešana katram adapterim cauruļvadā starp avotu un cauruļvada patērētāju.
///
/// Ja avots ir iteratora struktūras īpašnieks (parasti saukts par `IntoIter`), tas var būt noderīgs, lai specializētos [`FromIterator`] ieviešanā vai atkoptu atlikušos elementus pēc tam, kad iterators ir daļēji izsmelts.
///
///
/// Ņemiet vērā, ka ieviešanai nav obligāti jānodrošina piekļuve cauruļvada iekšējam iekšējam avotam.Stacionārs starpposma adapteris varētu ar nepacietību novērtēt cauruļvada daļu un atklāt tā iekšējo atmiņu kā avotu.
///
/// trait ir nedrošs, jo ieviesējiem ir jāievēro papildu drošības īpašības.
/// Sīkāku informāciju skatiet [`as_inner`].
///
/// # Examples
///
/// Daļēji patērēta avota iegūšana:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// Avota posms iteratora cauruļvadā.
    type Source: Iterator;

    /// Ielādēt iteratora cauruļvada avotu.
    ///
    /// # Safety
    ///
    /// Lietojumprogrammām ir jāatgriež tā pati mainīgā atsauce uz visu mūžu, ja vien to neaizstāj zvanītājs.
    /// Zvanītāji drīkst nomainīt atsauci tikai tad, kad pārtrauca iterāciju un pēc avota ieguves nomet iteratora cauruļvadu.
    ///
    /// Tas nozīmē, ka iteratora adapteri var paļauties uz to, ka avots nemainās iterācijas laikā, taču viņi nevar paļauties uz to, veicot Drop ieviešanu.
    ///
    /// Šīs metodes ieviešana nozīmē, ka adapteri atsakās no privāta piekļuves savam avotam un var paļauties tikai uz garantijām, kas izteiktas, pamatojoties uz metožu uztvērēju tipiem.
    /// Ierobežotas piekļuves trūkums arī prasa, lai adapteriem būtu jāuztur avota publiskā API pat tad, ja viņiem ir piekļuve tā iekšējai daļai.
    ///
    /// Zvanītājiem savukārt ir jācer, ka avots atrodas jebkurā stāvoklī, kas atbilst tā publiskajai API, jo starp to un avotu sēdošajiem adapteriem ir vienāda piekļuve.
    /// Konkrēti, adapteris var patērēt vairāk elementu, nekā tas ir absolūti nepieciešams.
    ///
    /// Šo prasību vispārējais mērķis ir ļaut patērētājam izmantot cauruļvadu
    /// * viss, kas paliek avotā pēc iterācijas pārtraukšanas
    /// * atmiņa, kas ir kļuvusi neizmantota, virzot patērētāju atkārtotāju
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// Iteratora adapteris, kas rada izvadi, kamēr pamatā esošais iterators rada `Result::Ok` vērtības.
///
///
/// Ja rodas kļūda, iterators apstājas un kļūda tiek saglabāta.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// Apstrādājiet doto atkārtotāju tā, it kā no tā iegūtu `T`, nevis `Result<T, _>`.
/// Jebkuras kļūdas apturēs iekšējo atkārtotāju, un kopējais rezultāts būs kļūda.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}