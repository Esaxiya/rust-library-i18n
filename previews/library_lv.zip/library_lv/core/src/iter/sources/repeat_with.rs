use crate::iter::{FusedIterator, TrustedLen};

/// Izveido jaunu iteratoru, kas bezgalīgi atkārto `A` tipa elementus, pielietojot paredzēto aizvērēju, atkārtotāju, `F: FnMut() -> A`.
///
/// `repeat_with()` funkcija atkārtotāju izsauc atkārtoti.
///
/// Bezgalīgi iteratori, piemēram, `repeat_with()`, bieži tiek izmantoti ar tādiem adapteriem kā [`Iterator::take()`], lai padarītu tos ierobežotus.
///
/// Ja nepieciešamā iteratora elementa tips ievieš [`Clone`] un ir pareizi saglabāt avota elementu atmiņā, tā vietā jāizmanto funkcija [`repeat()`].
///
///
/// `repeat_with()` ražots iterators nav [`DoubleEndedIterator`].
/// Ja [`DoubleEndedIterator`] ir nepieciešams [`DoubleEndedIterator`] atgriešanai, lūdzu, atveriet GitHub problēmu, kurā izskaidrots jūsu lietošanas gadījums.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Pamata lietojums:
///
/// ```
/// use std::iter;
///
/// // Pieņemsim, ka mums ir kāda veida vērtība, kas nav `Clone` vai kura vēl nevēlas būt atmiņā, jo tā ir dārga:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // noteikta vērtība uz visiem laikiem:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Mutācijas izmantošana un ierobežota darbība:
///
/// ```rust
/// use std::iter;
///
/// // No nulles līdz divu trešajam spēkam:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... un tagad mēs esam pabeiguši
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// Atkārtotājs, kas bezgalīgi atkārto `A` tipa elementus, pieliekot pievienoto aizvaru `F: FnMut() -> A`.
///
///
/// Šo `struct` izveido funkcija [`repeat_with()`].
/// Plašāku informāciju skatiet tās dokumentācijā.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}