use crate::iter::{FusedIterator, TrustedLen};

/// Izveido jaunu iteratoru, kas bezgalīgi atkārto vienu elementu.
///
/// `repeat()` funkcija atkal un atkal atkārto vienu vērtību.
///
/// Bezgalīgi iteratori, piemēram, `repeat()`, bieži tiek izmantoti ar tādiem adapteriem kā [`Iterator::take()`], lai padarītu tos ierobežotus.
///
/// Ja nepieciešamā iteratora elementa tips neievieš `Clone` vai ja nevēlaties saglabāt atkārtoto elementu atmiņā, tā vietā varat izmantot funkciju [`repeat_with()`].
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Pamata lietojums:
///
/// ```
/// use std::iter;
///
/// // skaitlis četri 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // jā, joprojām četri
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Ar [`Iterator::take()`] būs ierobežots:
///
/// ```
/// use std::iter;
///
/// // pēdējais piemērs bija pārāk daudz četrinieku.Būsim tikai četri četrinieki.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... un tagad mēs esam pabeiguši
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Atkārtotājs, kas bezgalīgi atkārto elementu.
///
/// Šo `struct` izveido funkcija [`repeat()`].Plašāku informāciju skatiet tās dokumentācijā.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}