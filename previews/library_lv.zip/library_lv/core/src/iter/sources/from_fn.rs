use crate::fmt;

/// Izveido jaunu iteratoru, kur katrs atkārtojums izsauc paredzēto slēgšanu `F: FnMut() -> Option<T>`.
///
/// Tas ļauj izveidot pielāgotu iteratoru ar jebkādu rīcību, neizmantojot daudznozīmīgāku sintaksi, izveidojot īpašu tipu un ieviešot tam [`Iterator`] trait.
///
/// Ņemiet vērā, ka `FromFn` atkārtotājs neveic pieņēmumus par slēgšanas darbību, un tāpēc konservatīvi neievieš [`FusedIterator`] vai ignorē [`Iterator::size_hint()`] no noklusējuma `(0, None)`.
///
///
/// Slēgšana var izmantot attēlus un tā vidi, lai izsekotu stāvokli visā atkārtojumos.Atkarībā no tā, kā tiek izmantots iterators, slēgšanai var būt nepieciešams norādīt atslēgvārdu [`move`].
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Atkārtoti ieviesīsim skaitītāja iteratoru no [module-level documentation]:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Palieliniet mūsu skaitu.Tāpēc mēs sākām no nulles.
///     count += 1;
///
///     // Pārbaudiet, vai mēs esam pabeiguši skaitīšanu vai nē.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// Iterators, kur katrs atkārtojums izsauc paredzēto slēgšanu `F: FnMut() -> Option<T>`.
///
/// Šo `struct` izveido funkcija [`iter::from_fn()`].
/// Plašāku informāciju skatiet tās dokumentācijā.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}