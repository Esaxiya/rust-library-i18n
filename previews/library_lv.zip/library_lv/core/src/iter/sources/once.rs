use crate::iter::{FusedIterator, TrustedLen};

/// Izveido iteratoru, kas elementu iegūst precīzi vienu reizi.
///
/// To parasti izmanto, lai pielāgotu vienu vērtību cita veida atkārtojuma [`chain()`].
/// Varbūt jums ir iterators, kas aptver gandrīz visu, bet jums ir nepieciešams papildu īpašs gadījums.
/// Varbūt jums ir funkcija, kas darbojas iteratoros, taču jums jāapstrādā tikai viena vērtība.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Pamata lietojums:
///
/// ```
/// use std::iter;
///
/// // viens ir vientuļākais skaitlis
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // tikai viens, tas ir viss, ko mēs iegūstam
/// assert_eq!(None, one.next());
/// ```
///
/// Ķēdes kopā ar citu iteratoru.
/// Pieņemsim, ka mēs vēlamies atkārtot katru `.foo` direktorija failu, bet arī konfigurācijas failu,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // mums jāpārvērš no DirEntry-s iteratora par PathBufs iteratoru, tāpēc mēs izmantojam karti
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // tagad mūsu iterators tikai mūsu konfigurācijas failam
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // ķēdē abus atkārtotājus vienā lielā atkārtotājā
/// let files = dirs.chain(config);
///
/// // tas mums dos visus failus .foo, kā arī .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// Atkārtotājs, kas elementu iegūst precīzi vienu reizi.
///
/// Šo `struct` izveido funkcija [`once()`].Plašāku informāciju skatiet tās dokumentācijā.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}