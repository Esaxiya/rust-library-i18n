/// Atkārtotājs, kas vienmēr turpina iegūt `None`, kad tas ir izsmelts.
///
/// Zvanot nākamajam ar sakausētu iteratoru, kurš vienreiz ir atgriezies ar `None`, garantē, ka [`None`] atkal tiks atgriezts.
/// Šis trait ir jāievieš visiem iteratoriem, kuri rīkojas šādi, jo tas ļauj optimizēt [`Iterator::fuse()`].
///
///
/// Note: Parasti jums nevajadzētu izmantot `FusedIterator` vispārīgās robežās, ja jums ir nepieciešams sakausēts iterators.
/// Tā vietā jums vienkārši jāaicina [`Iterator::fuse()`] uz iteratora.
/// Ja iterators jau ir sakausēts, papildu [`Fuse`] iesaiņotājs būs aizliegts bez izpildes soda.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// Atkārtotājs, kas ziņo par precīzu garumu, izmantojot size_hint.
///
/// Atkārtotājs ziņo par izmēra mājienu, kur tas ir vai nu precīzs (apakšējā robeža ir vienāda ar augšējo robežu), vai augšējā robeža ir [`None`].
///
/// Augšējai robežai jābūt [`None`] tikai tad, ja faktiskais iteratora garums ir lielāks par [`usize::MAX`].
/// Tādā gadījumā apakšējai robežai jābūt [`usize::MAX`], kā rezultātā iegūst [`Iterator::size_hint()`] [`Iterator::size_hint()`].
///
/// Atkārtotājam ir jāsagatavo precīzi to elementu skaits, par kuriem tā ziņoja, vai tie jānovirza pirms beigām.
///
/// # Safety
///
/// Šis trait ir jāievieš tikai tad, kad tiek ievērots līgums.
/// Šī trait patērētājiem jāpārbauda [`Iterator::size_hint()`]’s augšējā robeža.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// Atkārtotājs, kas, iegūstot priekšmetu, būs paņēmis vismaz vienu elementu no tā pamatā esošās [`SourceIter`].
///
/// Zvanot uz jebkuru metodi, kas veicina iteratoru, piemēram,
/// [`next()`] vai [`try_fold()`] garantē, ka katram solim vismaz viena iteratora pamatā esošā avota vērtība ir pārvietota un iteratora ķēdes rezultātu varētu ievietot tās vietā, pieņemot, ka avota strukturālie ierobežojumi pieļauj šādu ievietošanu.
///
/// Citiem vārdiem sakot, šis trait norāda, ka iteratora cauruļvadu var savākt vietā.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}