/// Konvertēšana no [`Iterator`].
///
/// Īstenojot `FromIterator` tipam, jūs definējat, kā tas tiks izveidots no iteratora.
/// Tas ir raksturīgi tipiem, kas apraksta kāda veida kolekciju.
///
/// [`FromIterator::from_iter()`] tiek reti izsaukts skaidri, un tā vietā tiek izmantots, izmantojot [`Iterator::collect()`] metodi.
///
/// Citus piemērus skatiet [`Iterator::collect()`]'s dokumentācijā.
///
/// Skatīt arī: [`IntoIterator`].
///
/// # Examples
///
/// Pamata lietojums:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Izmantojot [`Iterator::collect()`], lai netieši izmantotu `FromIterator`:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// `FromIterator` ieviešana jūsu tipam:
///
/// ```
/// use std::iter::FromIterator;
///
/// // Paraugu kolekcija, tas ir tikai iesaiņojums virs Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Piešķirsim tai dažas metodes, lai mēs varētu izveidot tādu un pievienot tam lietas.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // un mēs ieviesīsim FromIterator
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Tagad mēs varam izveidot jaunu iteratoru ...
/// let iter = (0..5).into_iter();
///
/// // ... un izveidojiet no tā MyCollection
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // vāc arī darbus!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Izveido vērtību no iteratora.
    ///
    /// Lai uzzinātu vairāk, skatiet [module-level documentation].
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Pārvēršana par [`Iterator`].
///
/// Īstenojot `IntoIterator` tipam, jūs definējat, kā tas tiks pārveidots par iteratoru.
/// Tas ir raksturīgi tipiem, kas apraksta kāda veida kolekciju.
///
/// Viens no `IntoIterator` ieviešanas ieguvumiem ir tas, ka jūsu tips būs [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator).
///
///
/// Skatīt arī: [`FromIterator`].
///
/// # Examples
///
/// Pamata lietojums:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// `IntoIterator` ieviešana jūsu tipam:
///
/// ```
/// // Paraugu kolekcija, tas ir tikai iesaiņojums virs Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Piešķirsim tai dažas metodes, lai mēs varētu izveidot tādu un pievienot tam lietas.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // un mēs ieviesīsim IntoIterator
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Tagad mēs varam izveidot jaunu kolekciju ...
/// let mut c = MyCollection::new();
///
/// // ... pievienojiet tam dažas lietas ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... un pēc tam pārvērtiet to par Iteratoru:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// Parasti `IntoIterator` lieto kā trait bound.Tas ļauj mainīt ievades kolekcijas veidu, ja vien tas joprojām ir iterators.
/// Papildu robežas var norādīt, ierobežojot
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// Atkārtoto elementu tips.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Par kādu iteratoru mēs to pārvēršam?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// No vērtības izveido iteratoru.
    ///
    /// Lai uzzinātu vairāk, skatiet [module-level documentation].
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Paplašiniet kolekciju ar iteratora saturu.
///
/// Iteratori rada virkni vērtību, un kolekcijas var uzskatīt arī par vērtību virkni.
/// `Extend` trait pārvar šo plaisu, ļaujot paplašināt kolekciju, iekļaujot šī iteratora saturu.
/// Paplašinot kolekciju ar jau esošu atslēgu, šis ieraksts tiek atjaunināts vai, ja kolekcijas atļauj vairākus ierakstus ar vienādām atslēgām, šis ieraksts tiek ievietots.
///
///
/// # Examples
///
/// Pamata lietojums:
///
/// ```
/// // Jūs varat paplašināt virkni ar dažām rakstzīmēm:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// `Extend` ieviešana:
///
/// ```
/// // Paraugu kolekcija, tas ir tikai iesaiņojums virs Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Piešķirsim tai dažas metodes, lai mēs varētu izveidot tādu un pievienot tam lietas.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // Tā kā MyCollection ir i32 saraksts, mēs ieviešam paplašinājumu i32
/// impl Extend<i32> for MyCollection {
///
///     // Tas ir mazliet vienkāršāk ar konkrētā tipa parakstu: mēs varam izsaukt paplašinājumu jebkuram, ko var pārvērst par Iteratoru, kas dod mums i32.
///     // Tāpēc, ka mums ir nepieciešami i32, lai tos ievietotu MyCollection.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // Īstenošana ir ļoti vienkārša: cilpa caur iteratoru un add() katrs elements pie mums.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // paplašināsim savu kolekciju ar vēl trim numuriem
/// c.extend(vec![1, 2, 3]);
///
/// // mēs esam pievienojuši šos elementus beigās
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Paplašina kolekciju ar iteratora saturu.
    ///
    /// Tā kā šī ir vienīgā nepieciešamā metode šim trait, [trait-level] dokumentos ir sīkāka informācija.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// // Jūs varat paplašināt virkni ar dažām rakstzīmēm:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Paplašina kolekciju ar tieši vienu elementu.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Rezervē krājumā ietilpību norādītajam papildu elementu skaitam.
    ///
    /// Noklusējuma ieviešana neko nedara.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}