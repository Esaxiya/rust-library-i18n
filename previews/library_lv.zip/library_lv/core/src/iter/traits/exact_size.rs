/// Atkārtotājs, kas zina precīzu tā garumu.
///
/// Daudzi [Iterator`s nezina, cik reizes viņi atkārtosies, bet daži to dara.
/// Ja atkārtotājs zina, cik reizes tas var atkārtoties, piekļuves nodrošināšana šai informācijai var būt noderīga.
/// Piemēram, ja vēlaties atkārtot atpakaļ, labs sākums ir zināt, kur ir beigas.
///
/// Īstenojot `ExactSizeIterator`, jums jāievieš arī [`Iterator`].
/// To darot, [`Iterator::size_hint`]*ieviešanai* jāatgriež precīzs atkārtotāja lielums.
///
/// [`len`] metodei ir noklusējuma ieviešana, tāpēc to parasti nevajadzētu ieviest.
/// Tomēr jūs, iespējams, varēsit nodrošināt efektīvāku ieviešanu nekā noklusējums, tāpēc šajā gadījumā ir lietderīgi to ignorēt.
///
///
/// Ievērojiet, ka šis trait ir drošs trait un tādējādi *negarantē* un *nevar* garantēt, ka atgrieztais garums ir pareizs.
/// Tas nozīmē, ka `unsafe` kods ** nedrīkst paļauties uz [`Iterator::size_hint`] pareizību.
/// Nestabils un nedrošs [`TrustedLen`](super::marker::TrustedLen) trait dod šo papildu garantiju.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Pamata lietojums:
///
/// ```
/// // ierobežots diapazons precīzi zina, cik reizes tas atkārtosies
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// [module-level docs] ierīcē mēs ieviesām [`Iterator`], `Counter`.
/// Īstenosim arī `ExactSizeIterator`:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Mēs varam viegli aprēķināt atlikušo atkārtojumu skaitu.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // Un tagad mēs to varam izmantot!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Atgriež precīzu atkārtotāja garumu.
    ///
    /// Īstenošana nodrošina, ka pirms [`None`] atgriešanas iterators precīzi atgriezīs `len()` vairāk nekā [`Some(T)`] vērtību.
    ///
    /// Šai metodei ir noklusējuma ieviešana, tāpēc jums to nevajadzētu ieviest tieši.
    /// Tomēr, ja jūs varat nodrošināt efektīvāku ieviešanu, varat to izdarīt.
    /// Piemēru skatiet dokumentos [trait-level].
    ///
    /// Šai funkcijai ir tādas pašas drošības garantijas kā [`Iterator::size_hint`] funkcijai.
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// // ierobežots diapazons precīzi zina, cik reizes tas atkārtosies
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Šis apgalvojums ir pārāk aizsargājošs, taču tas pārbauda nemainīgo
        // garantē trait.
        // Ja šis trait būtu rust-internal, mēs varētu izmantot debug_assert !;assert_eq!pārbaudīs arī visas Rust lietotāju realizācijas.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Atgriež `true`, ja iterators ir tukšs.
    ///
    /// Šai metodei ir noklusējuma ieviešana, izmantojot [`ExactSizeIterator::len()`], tāpēc jums tā nav jāievieš pašam.
    ///
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}