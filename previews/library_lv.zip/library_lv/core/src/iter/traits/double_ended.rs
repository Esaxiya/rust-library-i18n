use crate::ops::{ControlFlow, Try};

/// Atkārtotājs, kas spēj iegūt elementus no abiem galiem.
///
/// Kaut kam, kas ievieš `DoubleEndedIterator`, ir viena papildu iespēja pār kaut ko, kas ievieš [`Iterator`]: spēja paņemt preces arī no aizmugures, kā arī priekšpuses.
///
///
/// Ir svarīgi atzīmēt, ka gan turp, gan atpakaļ darbojas vienā un tajā pašā diapazonā un nekrustojas: iterācija ir beigusies, kad viņi satiekas vidū.
///
/// Līdzīgi kā [`Iterator`] protokolā, kad `DoubleEndedIterator` atgriež [`None`] no [`next_back()`], to atkārtoti izsaucot, var atgriezties [`Some`].
/// [`next()`] un [`next_back()`] šim nolūkam ir savstarpēji aizvietojami.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Pamata lietojums:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Noņem un atgriež elementu no iteratora beigām.
    ///
    /// Atgriež `None`, ja vairs nav elementu.
    ///
    /// [trait-level] dokumentos ir sīkāka informācija.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// Elementi, kas iegūti ar "DoubleEndedIterator" metodēm, var atšķirties no tiem, kas iegūti ar ""Iterator"] metodēm:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Ar `n` elementiem paver iteratoru no aizmugures.
    ///
    /// `advance_back_by` ir [`advance_by`] reversā versija.Šī metode ar nepacietību izlaidīs `n` elementus, sākot no aizmugures, izsaucot [`next_back`] līdz `n` reizes, līdz tiek parādīts [`None`].
    ///
    /// `advance_back_by(n)` atgriezīs [`Ok(())`], ja iterators veiksmīgi virzīsies uz priekšu ar `n` elementiem, vai [`Err(k)`], ja rodas [`None`], kur `k` ir elementu skaits, ar kuru iteratoru tiek virzīts pirms elementu beigām (ti,
    /// iteratora garums).
    /// Ņemiet vērā, ka `k` vienmēr ir mazāks par `n`.
    ///
    /// Zvanot uz `advance_back_by(0)`, netiek patērēti elementi, un vienmēr tiek atgriezta [`Ok(())`].
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // tika izlaists tikai `&3`
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Atgriež `n`th elementu no iteratora beigām.
    ///
    /// Būtībā šī ir [`Iterator::nth()`] apgrieztā versija.
    /// Lai gan tāpat kā lielākajai daļai indeksēšanas operāciju, skaitīšana sākas no nulles, tāpēc `nth_back(0)` atgriež pirmo vērtību no beigām, `nth_back(1)` otro un tā tālāk.
    ///
    ///
    /// Ņemiet vērā, ka tiks patērēti visi elementi starp galu un atgriezto elementu, ieskaitot atgriezto elementu.
    /// Tas arī nozīmē, ka vairākas reizes izsaucot `nth_back(0)` vienā un tajā pašā atkārtotājā, tiks atgriezti dažādi elementi.
    ///
    /// `nth_back()` atgriezīs [`None`], ja `n` ir lielāks vai vienāds ar iteratora garumu.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// Vairākas reizes piezvanot uz `nth_back()`, iterators netiek pārtīts:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// Atgriežot `None`, ja elementu ir mazāk nekā `n + 1`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Šī ir [`Iterator::try_fold()`] reversā versija: tā aizņem elementus, sākot no iteratora aizmugures.
    ///
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Tā kā tas bija īssavienots, pārējie elementi joprojām ir pieejami caur iteratoru.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Iteratora metode, kas samazina iteratora elementus līdz vienai galīgai vērtībai, sākot no aizmugures.
    ///
    /// Šī ir [`Iterator::fold()`] reversā versija: tā aizņem elementus, sākot no iteratora aizmugures.
    ///
    /// `rfold()` ir divi argumenti: sākotnējā vērtība un noslēgums ar diviem argumentiem: 'accumulator' un elementu.
    /// Aizvēršana atgriež vērtību, kāda akumulatoram vajadzētu būt nākamajam atkārtojumam.
    ///
    /// Sākotnējā vērtība ir vērtība, kas akumulatoram būs pirmā zvana laikā.
    ///
    /// Pēc šīs aizvēršanas piemērošanas visiem iteratora elementiem `rfold()` atgriež akumulatoru.
    ///
    /// Šo darbību dažreiz sauc par 'reduce' vai 'inject'.
    ///
    /// Saliekšana ir noderīga ikreiz, kad jums ir kaut kas kolekcija un vēlaties no tā radīt vienu vērtību.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // visu a elementu summa
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Šis piemērs veido virkni, sākot ar sākotnējo vērtību un turpinot katru elementu no aizmugures līdz priekšpusei:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// No aizmugures meklē iteratora elementu, kas apmierina predikātu.
    ///
    /// `rfind()` veic slēgšanu, kas atgriež `true` vai `false`.
    /// Tas piemēro šo aizvēršanu katram iteratora elementam, sākot no beigām, un, ja kāds no tiem atgriež `true`, tad `rfind()` atgriež [`Some(element)`].
    /// Ja viņi visi atgriež `false`, tas atgriež [`None`].
    ///
    /// `rfind()` ir īssavienojums;citiem vārdiem sakot, tā pārtrauks apstrādi, tiklīdz slēgšana atgriezīs `true`.
    ///
    /// Tā kā `rfind()` ņem atsauci un daudzi atkārtotāji atkārto atsauces, tas rada potenciāli mulsinošu situāciju, kad arguments ir divkārša atsauce.
    ///
    /// Šo efektu var redzēt zemāk esošajos piemēros ar `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Apstāšanās pie pirmā `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // mēs joprojām varam izmantot `iter`, jo ir vairāk elementu.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}