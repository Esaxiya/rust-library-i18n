// ignore-tidy-filelength Šis fails gandrīz tikai sastāv no `Iterator` definīcijas.
// Mēs to nevaram sadalīt vairākos failos.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// Saskarne darbībai ar iteratoriem.
///
/// Tas ir galvenais iterators trait.
/// Plašāku informāciju par iteratoru jēdzienu, lūdzu, skatiet [module-level documentation].
/// Jo īpaši jūs varētu vēlēties zināt, kā [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// Atkārtoto elementu tips.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Virza iteratoru un atgriež nākamo vērtību.
    ///
    /// Atgriež [`None`], kad iterācija ir pabeigta.
    /// Atsevišķi iteratora ieviešanas gadījumi var izvēlēties atkārtot atkārtojumu, un tāpēc `next()` atkārtota izsaukšana var beigties vai ne, bet kādā brīdī atkal atsākt [`Some(Item)`].
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // Zvans uz next() atgriež nākamo vērtību ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... un pēc tam Neviens, kad tas ir beidzies.
    /// assert_eq!(None, iter.next());
    ///
    /// // Vairāk zvanu var atgriezties vai neatgriezties `None`.Lūk, viņi vienmēr to darīs.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Atgriež ierobežojumus atlikušajam atkārtotāja garumam.
    ///
    /// Konkrēti, `size_hint()` atgriež kopu, kur pirmais elements ir apakšējā robeža, bet otrais elements ir augšējais.
    ///
    /// Atgrieztā dubultā otrā puse ir [`Option`]`<`[`usize`] `>`.
    /// [`None`] šeit nozīmē, ka vai nu nav zināma augšējā robeža, vai arī augšējā robeža ir lielāka par [`usize`].
    ///
    /// # Īstenošanas piezīmes
    ///
    /// Nav ieviests, ka iteratora ieviešana dod deklarēto elementu skaitu.Buggy iterators var radīt mazāk nekā elementu apakšējā robeža vai vairāk nekā augšējā robeža.
    ///
    /// `size_hint()` galvenokārt paredzēts izmantot optimizācijai, piemēram, vietas rezervēšanai iteratora elementiem, taču tam nedrīkst uzticēties, piemēram, izlaist robežu pārbaudes nedrošā kodā.
    /// Nepareiza `size_hint()` ieviešana nedrīkst izraisīt atmiņas drošības pārkāpumus.
    ///
    /// Tas nozīmē, ka ieviešanai vajadzētu sniegt pareizu novērtējumu, jo pretējā gadījumā tas būtu trait protokola pārkāpums.
    ///
    /// Noklusējuma ieviešana atgriež "(0," ["Neviens"] ")", kas ir pareizs jebkuram atkārtotājam.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// Sarežģītāks piemērs:
    ///
    /// ```
    /// // Pāra skaitļi no nulles līdz desmit.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Mēs varētu atkārtot no nulles līdz desmit reizēm.
    /// // Zināt, ka precīzi ir pieci, bez filter() izpildes nebūtu iespējams.
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Pievienosim vēl piecus skaitļus ar chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // tagad abas robežas ir palielinātas par piecām
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Atgriežot `None` augšējai robežai:
    ///
    /// ```
    /// // bezgalīgam atkārtotājam nav augšējās robežas un maksimāli iespējamās apakšējās robežas
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Patērē atkārtotāju, skaitot atkārtojumu skaitu un atdodot to.
    ///
    /// Šī metode atkārtoti izsauks [`next`], līdz tiek parādīts [`None`], atgriežot [`Some`] redzēšanas reižu skaitu.
    /// Ņemiet vērā, ka [`next`] ir jāizsauc vismaz vienu reizi, pat ja iteratoram nav elementu.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Pārplūdes uzvedība
    ///
    /// Metode nepasargā no pārplūdēm, tāpēc iteratora elementu skaitīšana ar vairāk nekā [`usize::MAX`] elementiem rada nepareizu rezultātu vai panics.
    ///
    /// Ja atkļūdošanas apgalvojumi ir iespējoti, tiek garantēta panic.
    ///
    /// # Panics
    ///
    /// Šī funkcija var būt panic, ja iteratoram ir vairāk nekā [`usize::MAX`] elementi.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Patērē atkārtotāju, atgriežot pēdējo elementu.
    ///
    /// Ar šo metodi iterators tiks novērtēts, līdz tas atgriezīs [`None`].
    /// To darot, tā seko līdzi pašreizējam elementam.
    /// Pēc [`None`] atdošanas `last()` atgriezīs pēdējo redzēto elementu.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Paaugstina iteratoru par `n` elementiem.
    ///
    /// Šī metode ar nepacietību izlaidīs `n` elementus, izsaucot [`next`] līdz `n` reizēm, līdz tiek parādīts [`None`].
    ///
    /// `advance_by(n)` atgriezīs [`Ok(())`][Ok], ja iterators veiksmīgi virzīsies uz priekšu ar `n` elementiem, vai [`Err(k)`][Err], ja rodas [`None`], kur `k` ir elementu skaits, ar kuru iteratoru tiek virzīts pirms elementu beigām (ti,
    /// iteratora garums).
    /// Ņemiet vērā, ka `k` vienmēr ir mazāks par `n`.
    ///
    /// Zvanot uz `advance_by(0)`, netiek patērēti elementi, un vienmēr tiek atgriezta [`Ok(())`][Ok].
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // tika izlaists tikai `&4`
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Atgriež iteratora elementa n. Elementu.
    ///
    /// Tāpat kā vairumam indeksēšanas darbību, skaitīšana sākas no nulles, tāpēc `nth(0)` atgriež pirmo vērtību, `nth(1)` otro un tā tālāk.
    ///
    /// Ņemiet vērā, ka visi iepriekšējie elementi, kā arī atgrieztais elements tiks patērēti no iteratora.
    /// Tas nozīmē, ka iepriekšējie elementi tiks izmesti, kā arī tas, ka vairākas reizes izsaucot `nth(0)` vienā un tajā pašā atkārtotājā, tiks atgriezti dažādi elementi.
    ///
    ///
    /// `nth()` atgriezīs [`None`], ja `n` ir lielāks vai vienāds ar iteratora garumu.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Vairākas reizes piezvanot uz `nth()`, iterators netiek pārtīts:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Atgriežot `None`, ja elementu ir mazāk nekā `n + 1`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Izveido iteratoru, kas sākas tajā pašā punktā, bet katrā iterācijā pakāpj pa norādīto summu.
    ///
    /// 1. piezīme. Iteratora pirmais elements vienmēr tiks atgriezts neatkarīgi no norādītā soļa.
    ///
    /// 2. piezīme. Laiks, kurā tiek vilkti ignorētie elementi, nav noteikts.
    /// `StepBy` uzvedas kā secība `next(), nth(step-1), nth(step-1),…`, bet var arī brīvi rīkoties kā secība
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Lietošanas veids dažiem iteratoriem var mainīties veiktspējas apsvērumu dēļ.
    /// Otrais veids veicinās atkārtotāju agrāk un var patērēt vairāk vienumu.
    ///
    /// `advance_n_and_return_first` ir ekvivalents:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// Metode būs panic, ja dotais solis ir `0`.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Paņem divus atkārtotājus un secīgi izveido jaunu iteratoru pār abiem.
    ///
    /// `chain()` atgriezīs jaunu iteratoru, kas vispirms atkārtos vērtības no pirmā iteratora un pēc tam pār vērtībām no otrā iteratora.
    ///
    /// Citiem vārdiem sakot, tas savieno divus atkārtotājus ķēdē.🔗
    ///
    /// [`once`] tiek parasti izmantots, lai pielāgotu vienu vērtību cita veida atkārtojuma ķēdē.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Tā kā arguments `chain()` izmanto [`IntoIterator`], mēs varam nodot visu, ko var pārveidot par [`Iterator`], ne tikai pašu [`Iterator`].
    /// Piemēram, (`&[T]`) šķēles īsteno [`IntoIterator`], un to var tieši nodot `chain()`:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ja strādājat ar Windows API, iespējams, vēlēsities pārveidot [`OsStr`] uz `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// Divus atkārtotājus saslēdz vienā pāru atkārtotājā.
    ///
    /// `zip()` atgriež jaunu iteratoru, kas atkārtos divus citus iteratorus, atgriežot kopu, kur pirmais elements nāk no pirmā iteratora, bet otrais elements nāk no otrā iteratora.
    ///
    ///
    /// Citiem vārdiem sakot, tas apvieno divus atkārtotājus vienā vienībā.
    ///
    /// Ja kāds no iteratoriem atgriež [`None`], [`next`] no rāvējslēdzēja iteratora atgriezīs [`None`].
    /// Ja pirmais iterators atgriež [`None`], `zip` īssavienojums un `next` netiks izsaukts otrajā iteratorā.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Tā kā arguments `zip()` izmanto [`IntoIterator`], mēs varam nodot visu, ko var pārveidot par [`Iterator`], ne tikai pašu [`Iterator`].
    /// Piemēram, (`&[T]`) šķēles īsteno [`IntoIterator`], un to var tieši nodot `zip()`:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` bieži tiek izmantots, lai bezgalīgu iteratoru sasaistītu ar ierobežotu.
    /// Tas darbojas, jo ierobežotais atkārtotājs galu galā atgriezīs [`None`], beidzot rāvējslēdzēju.Zipošana ar `(0..)` var līdzināties [`enumerate`]:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Izveido jaunu iteratoru, kas novieto `separator` kopiju starp blakus esošajiem sākotnējā iteratora elementiem.
    ///
    /// Gadījumā, ja `separator` neievieš [`Clone`] vai ir jāaprēķina katru reizi, izmantojiet [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // Pirmais elements no `a`.
    /// assert_eq!(a.next(), Some(&100)); // Atdalītājs.
    /// assert_eq!(a.next(), Some(&1));   // Nākamais elements no `a`.
    /// assert_eq!(a.next(), Some(&100)); // Atdalītājs.
    /// assert_eq!(a.next(), Some(&2));   // Pēdējais elements no `a`.
    /// assert_eq!(a.next(), None);       // Iterators ir pabeigts.
    /// ```
    ///
    /// `intersperse` var būt ļoti noderīgi pievienoties iteratora elementiem, izmantojot kopīgu elementu:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Izveido jaunu iteratoru, kas novieto `separator` ģenerēto vienumu starp blakus esošajiem sākotnējā iteratora elementiem.
    ///
    /// Slēgšana tiks izsaukta precīzi vienu reizi katru reizi, kad vienums tiek ievietots starp diviem blakus esošajiem elementiem no pamata iteratora;
    /// Konkrēti, slēgšana netiek izsaukta, ja pamatā esošais atkārtotājs dod mazāk nekā divus posteņus un pēc pēdējās pozīcijas iegūšanas.
    ///
    ///
    /// Ja iteratora vienums ievieš [`Clone`], [`intersperse`] var būt vieglāk izmantot.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // Pirmais elements no `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Atdalītājs.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // Nākamais elements no `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Atdalītājs.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // Pēdējais elements no `v`.
    /// assert_eq!(it.next(), None);               // Iterators ir pabeigts.
    /// ```
    ///
    /// `intersperse_with` var izmantot situācijās, kad separators jāaprēķina:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // Slēgšana mainīgi aizņemas kontekstu, lai ģenerētu vienumu.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Aizver un izveido iteratoru, kas izsauc šo aizvēršanu katram elementam.
    ///
    /// `map()` pārveido vienu iteratoru citā, izmantojot savu argumentu:
    /// kaut kas, kas ievieš [`FnMut`].Tas rada jaunu iteratoru, kas izsauc šo slēgšanu katram sākotnējā iteratora elementam.
    ///
    /// Ja jūs labi domājat tipos, varat domāt par `map()` šādi:
    /// Ja jums ir iterators, kas dod jums kāda veida `A` elementus, un jūs vēlaties cita veida `B` iteratoru, varat izmantot `map()`, nododot slēgumu, kas ņem `A` un atgriež `B`.
    ///
    ///
    /// `map()` ir konceptuāli līdzīgs [`for`] lokam.Tomēr, tā kā `map()` ir slinks, to vislabāk izmantot, kad jūs jau strādājat ar citiem iteratoriem.
    /// Ja jūs veicat kaut kādu cilpu, lai iegūtu blakus efektu, tiek uzskatīts par idiomātiskāku izmantot [`for`] nekā `map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ja veicat kāda veida blakusparādību, dodiet priekšroku [`for`], nevis `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // nedari to:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // tas pat netiks izpildīts, jo tas ir slinks.Rust jūs par to brīdinās.
    ///
    /// // Tā vietā izmantojiet:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Pieprasa katra iteratora elementa slēgšanu.
    ///
    /// Tas ir līdzvērtīgs [`for`] cilpas izmantošanai iteratorā, lai gan `break` un `continue` nav iespējams no aizvēršanas.
    /// Parasti ir idiomātiskāk izmantot `for` cilpu, taču `for_each` var būt salasāmāks, apstrādājot vienumus garāku iteratoru ķēžu beigās.
    ///
    /// Dažos gadījumos `for_each` var būt arī ātrāks par cilpu, jo tas izmantos iekšējo iterāciju tādos adapteros kā `Chain`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// Šādam nelielam piemēram, `for` cilpa var būt tīrāka, taču `for_each` varētu būt vēlams, lai saglabātu funkcionālu stilu ar garākiem atkārtotājiem:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Izveido iteratoru, kas izmanto aizvēršanu, lai noteiktu, vai jāizveido elements.
    ///
    /// Ņemot vērā elementu, aizdarei jāatgriež `true` vai `false`.Atgrieztais atkārtotājs radīs tikai tos elementus, kuriem slēgšana atgriežas kā patiesa.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Tā kā `filter()` nodotajai slēgšanai ir atsauce, un daudzi atkārtotāji atkārto atsauces, tas noved pie iespējami mulsinošas situācijas, kad slēgšanas veids ir divkārša atsauce:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // vajag divas *!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Tā vietā parasti argumentā tiek izmantota destrukturēšana, lai to noņemtu:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // gan&, gan *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// vai abi:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // divi &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// no šiem slāņiem.
    ///
    /// Ņemiet vērā, ka `iter.filter(f).next()` ir ekvivalents `iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Izveido iteratoru, kas filtrē un kartē.
    ///
    /// Atgrieztais iterators dod tikai tās vērtības, kurām piegādātais slēgums atgriež `Some(value)`.
    ///
    /// `filter_map` var izmantot, lai padarītu [`filter`] un [`map`] ķēdes kodolīgākas.
    /// Tālāk sniegtajā piemērā parādīts, kā `map().filter().map()` var saīsināt līdz vienam izsaukumam uz `filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Šis ir tas pats piemērs, bet ar [`filter`] un [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Izveido iteratoru, kas dod pašreizējo atkārtojumu skaitu, kā arī nākamo vērtību.
    ///
    /// Atgriežot atkārtotāju, tiek iegūti pāri `(i, val)`, kur `i` ir pašreizējais atkārtojuma indekss un `val` ir iteratora atgrieztā vērtība.
    ///
    ///
    /// `enumerate()` saglabā savu skaitli kā [`usize`].
    /// Ja vēlaties skaitīt pēc cita lieluma vesela skaitļa, funkcija [`zip`] nodrošina līdzīgu funkcionalitāti.
    ///
    /// # Pārplūdes uzvedība
    ///
    /// Metode nepasargā no pārplūdēm, tāpēc vairāk nekā [`usize::MAX`] elementu uzskaitīšana rada nepareizu rezultātu vai panics.
    /// Ja atkļūdošanas apgalvojumi ir iespējoti, tiek garantēta panic.
    ///
    /// # Panics
    ///
    /// Atgrieztais iterators var panic, ja atdodamais indekss pārpildīs [`usize`].
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Izveido iteratoru, kas var izmantot [`peek`], lai apskatītu nākamo iteratora elementu, to neizmantojot.
    ///
    /// Pievieno [`peek`] metodi iteratoram.Plašāku informāciju skatiet tās dokumentācijā.
    ///
    /// Ņemiet vērā, ka pamatā esošais iterators joprojām ir uzlabots, pirmo reizi izsaucot [`peek`]: Lai izgūtu nākamo elementu, pamatā esošajam itatoram tiek izsaukts [`next`], līdz ar to arī visas blakusparādības (ti,
    ///
    /// kas notiks, izņemot nākamās vērtības iegūšanu) [`next`] metodē.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() ļauj mums ieskatīties future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // mēs varam peek() vairākas reizes, atkārtotājs netiks virzīts uz priekšu
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // pēc iteratora pabeigšanas, tāpat kā peek()
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Izveido iteratoru, kura elementi [izlaist], pamatojoties uz predikātu.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` uzskata argumentu par slēgšanu.Tas izsauks šo aizvēršanu katram iteratora elementam un ignorēs elementus, līdz tas atgriezīs `false`.
    ///
    /// Pēc `false` atdošanas `skip_while()`'s darbs ir beidzies, un tiek iegūti pārējie elementi.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Tā kā `skip_while()` nodotajai slēgšanai ir atsauce, un daudzi atkārtotāji atkārto atsauces, tas noved pie iespējami mulsinošas situācijas, kad slēgšanas argumenta veids ir divkārša atsauce:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // vajag divas *!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Apstāšanās pēc sākotnējā `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // lai gan tas būtu nepatiesi, jo mums jau ir nepatiesa informācija, skip_while() vairs netiek izmantots
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Izveido iteratoru, kas dod elementus, pamatojoties uz predikātu.
    ///
    /// `take_while()` uzskata argumentu par slēgšanu.Tas sauks šo aizvēršanu katram iteratora elementam un iegūs elementus, kamēr tas atgriezīs `true`.
    ///
    /// Pēc `false` atdošanas `take_while()`'s darbs ir beidzies, un pārējie elementi tiek ignorēti.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Tā kā `take_while()` nodotajai slēgšanai ir atsauce, un daudzi atkārtotāji atkārto atsauces, tas noved pie iespējami mulsinošas situācijas, kad slēgšanas veids ir divkārša atsauce:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // vajag divas *!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Apstāšanās pēc sākotnējā `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Mums ir vairāk elementu, kas ir mazāki par nulli, taču, tā kā mēs jau esam ieguvuši nepatiesu vērtību, take_while() vairs netiek izmantots
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Tā kā `take_while()` ir jāaplūko vērtība, lai redzētu, vai tā ir jāiekļauj vai nav, patērētāji iteratori redzēs, ka tā ir noņemta:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` vairs nav, jo tas tika patērēts, lai pārliecinātos, vai iterācija ir jāpārtrauc, taču tā netika ievietota atpakaļ iteratorā.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Izveido iteratoru, kas dod elementus, pamatojoties uz predikātu un kartēm.
    ///
    /// `map_while()` uzskata argumentu par slēgšanu.
    /// Tas sauks šo aizvēršanu katram iteratora elementam un iegūs elementus, kamēr tas atgriezīs [`Some(_)`][`Some`].
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Šis ir tas pats piemērs, bet ar [`take_while`] un [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Apstāšanās pēc sākotnējā [`None`]:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Mums ir vairāk elementu, kas varētu ietilpt u32 (4, 5), bet `map_while` atgrieza `None` `-3` (kā `predicate` atgriezās `None`) un `collect` apstājas pirmajā `None`.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Tā kā `map_while()` ir jāaplūko vērtība, lai redzētu, vai tā ir jāiekļauj vai nav, patērētāji iteratori redzēs, ka tā ir noņemta:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `-3` vairs nav, jo tas tika patērēts, lai pārliecinātos, vai iterācija ir jāpārtrauc, taču tā netika ievietota atpakaļ iteratorā.
    ///
    /// Ņemiet vērā, ka atšķirībā no [`take_while`], šis iterators **nav** sapludināts.
    /// Nav arī norādīts, ko šis iterators atgriež pēc pirmā [`None`] atgriešanas.
    /// Ja jums ir nepieciešams sakausēts iterators, izmantojiet [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Izveido iteratoru, kas izlaiž pirmos `n` elementus.
    ///
    /// Pēc tam, kad tie ir iztērēti, tiek iegūti pārējie elementi.
    /// Tā vietā, lai tieši ignorētu šo metodi, tā vietā ignorējiet metodi `nth`.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Izveido iteratoru, kas dod pirmos `n` elementus.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` bieži tiek izmantots ar bezgalīgu atkārtotāju, lai padarītu to galīgu:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ja ir pieejami mazāk nekā `n` elementi, `take` aprobežojas ar pamata iteratora lielumu:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// XerX līdzīgs iteratora adapteris, kas uztur iekšējo stāvokli un rada jaunu iteratoru.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` ir divi argumenti: sākotnējā vērtība, kas izsaka iekšējo stāvokli, un aizvēršana ar diviem argumentiem, no kuriem pirmais ir maināma atsauce uz iekšējo stāvokli un otrais ir iteratora elements.
    ///
    /// Slēgšana var piešķirt iekšējam stāvoklim dalīties stāvoklī starp atkārtojumiem.
    ///
    /// Veicot atkārtojumu, katram iteratora elementam tiks piemērota aizvēršana, un atkārtošanas vērtību no aizvēršanas [`Option`] iegūst iterators.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // katrā atkārtojumā mēs reizināsim stāvokli ar elementu
    ///     *state = *state * x;
    ///
    ///     // tad mēs iegūsim valsts noliegumu
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Izveido iteratoru, kas darbojas kā karte, bet izlīdzina ligzdoto struktūru.
    ///
    /// [`map`] adapteris ir ļoti noderīgs, taču tikai tad, kad aizvēršanas arguments rada vērtības.
    /// Ja tā vietā tiek izveidots iterators, ir papildu indirection slānis.
    /// `flat_map()` noņems šo papildu slāni pats.
    ///
    /// Jūs varat domāt par `flat_map(f)` kā semantisko ekvivalentu pingam [`map`] un pēc tam [`saplacināt`] kā `map(f).flatten()`.
    ///
    /// Vēl viens domāšanas veids par `flat_map()`: [`map`] aizvēršana katram elementam atgriež vienu vienumu, bet `flat_map()`'s aizvēršana-katram elementam atkārtotāju.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() atgriež atkārtotāju
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Izveido iteratoru, kas izlīdzina ligzdoto struktūru.
    ///
    /// Tas ir noderīgi, ja jums ir iteratoru iterators vai iterators par lietām, kuras var pārvērst par iteratoriem, un vēlaties noņemt viena līmeņa netiešo virzienu.
    ///
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Kartēšana un pēc tam saplacināšana:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() atgriež atkārtotāju
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Varat to arī pārrakstīt ar [`flat_map()`], kas šajā gadījumā ir vēlams, jo tas skaidrāk nodod nodomu:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() atgriež atkārtotāju
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Saplacināšana vienlaikus noņem tikai vienu ligzdošanas līmeni:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Šeit mēs redzam, ka `flatten()` neveic "deep" saplacināšanu.
    /// Tā vietā tiek noņemts tikai viens ligzdošanas līmenis.Tas ir, ja `flatten()` izmantojat trīsdimensiju masīvu, rezultāts būs divdimensiju, nevis viendimensionāls.
    /// Lai iegūtu viendimensiju struktūru, jums vēlreiz jāveic `flatten()`.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Izveido iteratoru, kas beidzas pēc pirmā [`None`].
    ///
    /// Pēc tam, kad iterators atgriež [`None`], future zvani var atkal radīt [`Some(T)`] vai nē.
    /// `fuse()` pielāgo iteratoru, nodrošinot, ka pēc [`None`] piešķiršanas tas vienmēr atgriezīs [`None`] uz visiem laikiem.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// // iterators, kas mijas starp Daži un Neviens
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // ja tas ir pat, Some(i32), citādi nav
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // mēs varam redzēt, kā mūsu atkārtotājs iet turp un atpakaļ
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // tomēr, kad mēs to sakausēsim ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // tas vienmēr atgriezīs `None` pēc pirmās reizes.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Kaut ko dara ar katru iteratora elementu, nododot vērtību tālāk.
    ///
    /// Izmantojot iteratorus, jūs bieži ķēdē vairākus no tiem.
    /// Strādājot ar šādu kodu, iespējams, vēlēsities pārbaudīt, kas notiek dažādās cauruļvada daļās.Lai to izdarītu, ievietojiet zvanu uz `inspect()`.
    ///
    /// Biežāk `inspect()` tiek izmantots kā atkļūdošanas rīks, nekā tas pastāv jūsu gala kodā, taču lietojumprogrammām tas var būt noderīgs noteiktās situācijās, kad kļūdas jāpiesaka pirms izmetšanas.
    ///
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // šī iteratora secība ir sarežģīta.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // pievienosim dažus inspect() zvanus, lai izpētītu notiekošo
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Tas izdrukās:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Reģistrēšanas kļūdas, pirms tās izmetat:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Tas izdrukās:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Aizņemas iteratoru, nevis patērē to.
    ///
    /// Tas ir noderīgi, lai atļautu lietot iteratora adapterus, saglabājot sākotnējā iteratora īpašumtiesības.
    ///
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // ja mēģināsim atkārtoti izmantot iter, tas nedarbosies.
    /// // Šajā rindā ir dota kļūda: pārvietotās vērtības izmantošana: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // mēģināsim to vēlreiz
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // tā vietā mēs pievienojam .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // tagad tas ir tikai labi:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Pārveido iteratoru par kolekciju.
    ///
    /// `collect()` var paņemt visu iespējamo un pārvērst to par atbilstošu kolekciju.
    /// Šī ir viena no jaudīgākajām metodēm standarta bibliotēkā, ko izmanto dažādos kontekstos.
    ///
    /// Visvienkāršākais modelis, kurā tiek izmantots `collect()`, ir vienas kolekcijas pārvēršana citā.
    /// Jūs paņemat kolekciju, izsaucat tajā [`iter`], veicat virkni pārveidojumu un pēc tam beigās `collect()`.
    ///
    /// `collect()` var arī izveidot tādu tipu gadījumus, kas nav tipiskas kolekcijas.
    /// Piemēram, [`String`] var uzbūvēt no [`char`s], un [`Result<T, E>`][`Result`] vienumu iteratoru var savākt `Result<Collection<T>, E>`.
    ///
    /// Plašāku informāciju skatiet tālāk sniegtajos piemēros.
    ///
    /// Tā kā `collect()` ir tik vispārīgs, tas var radīt problēmas ar tipa secinājumiem.
    /// Tādējādi `collect()` ir viena no retajām reizēm, kad jūs redzēsiet sintaksi, ko mīļi dēvē par 'turbofish': `::<>`.
    /// Tas palīdz secināšanas algoritmam precīzi saprast, kurā kolekcijā jūs mēģināt kolekcionēt.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Ņemiet vērā, ka mums kreisajā pusē bija nepieciešams `: Vec<i32>`.Tas ir tāpēc, ka tā vietā mēs varētu savākt, piemēram, [`VecDeque<T>`]:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// 'turbofish' izmantošana, nevis `doubled` anotēšana:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Tā kā `collect()` rūpējas tikai par to, ko jūs kolekcionējat, jūs joprojām varat izmantot daļēju tipa norādījumu `_` ar turbofishu:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Izmantojot `collect()`, lai izveidotu [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Ja jums ir saraksts ar [`Rezultāts<T, E>`][`Rezultāts`] s, varat izmantot `collect()`, lai pārbaudītu, vai kāds no tiem neizdevās:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // dod mums pirmo kļūdu
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // sniedz mums atbilžu sarakstu
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Patērē iteratoru, izveidojot no tā divas kolekcijas.
    ///
    /// Predikāts, kas nodots `partition()`, var atgriezt `true` vai `false`.
    /// `partition()` atgriež pāri, visus elementus, par kuriem tā atgrieza `true`, un visus elementus, par kuriem tā atgrieza `false`.
    ///
    ///
    /// Skatīt arī [`is_partitioned()`] un [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Pārkārto šī iteratora *vietā* elementus atbilstoši dotajam predikātam tā, ka visi, kas atgriežas ar `true`, ir pirms visiem, kas atgriež `false`.
    ///
    /// Atgriež atrasto `true` elementu skaitu.
    ///
    /// Sadalīto priekšmetu relatīvā kārtība netiek uzturēta.
    ///
    /// Skatīt arī [`is_partitioned()`] un [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Sadaliet savā starpā starp izlīdzinājumiem un koeficientiem
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: vai mums būtu jāuztraucas par to, ka skaitlis ir pārpildīts?Vienīgais veids, kā iegūt vairāk nekā
        // `usize::MAX` maināmas atsauces ir ar ZST, kuras nav noderīgas nodalīšanai ...

        // Šīs "factory" aizvēršanas funkcijas pastāv, lai izvairītos no `Self` dāsnuma.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Atkārtoti atrodiet pirmo `false` un nomainiet to ar pēdējo `true`.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Pārbauda, vai šī iteratora elementi ir sadalīti atbilstoši dotajam predikātam tā, lai visi, kas atgriež `true`, būtu pirms visiem, kas atgriež `false`.
    ///
    ///
    /// Skatīt arī [`partition()`] un [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Vai nu visi vienumi tiek pārbaudīti ar `true`, vai arī pirmais punkts apstājas pie `false`, un mēs pārbaudām, vai pēc tam vairs nav `true` vienumu.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// Iteratora metode, kas funkciju lieto tik ilgi, kamēr tā veiksmīgi atgriežas, iegūstot vienu galīgo vērtību.
    ///
    /// `try_fold()` ir divi argumenti: sākotnējā vērtība un noslēgums ar diviem argumentiem: 'accumulator' un elementu.
    /// Aizvēršana vai nu veiksmīgi atgriežas ar vērtību, kas akumulatoram vajadzētu būt nākamajam atkārtojumam, vai arī atgriež neveiksmi ar kļūdas vērtību, kas nekavējoties tiek izplatīta zvanītājam (short-circuiting).
    ///
    ///
    /// Sākotnējā vērtība ir vērtība, kas akumulatoram būs pirmā zvana laikā.Ja aizvēršana tika veiksmīgi piemērota katram iteratora elementam, `try_fold()` kā veiksmīgu atgriež galīgo akumulatoru.
    ///
    /// Saliekšana ir noderīga ikreiz, kad jums ir kaut kas kolekcija un vēlaties no tā radīt vienu vērtību.
    ///
    /// # Piezīme īstenotājiem
    ///
    /// Vairākām citām (forward) metodēm ir noklusējuma ieviešanas iespējas attiecībā uz šo metodi, tāpēc mēģiniet to skaidri ieviest, ja tā var paveikt kaut ko labāku nekā noklusējuma `for` cilpas ieviešana.
    ///
    /// Īpaši mēģiniet, lai šis zvans `try_fold()` būtu iekšējās daļās, no kurām sastāv šis iterators.
    /// Ja ir nepieciešami vairāki zvani, `?` operators var būt ērti, lai akumulatora vērtību sasaistītu pa ķēdi, taču piesargāties no visiem invariantiem, kas jāuztur spēkā pirms šīs agrās atgriešanās.
    /// Šī ir `&mut self` metode, tāpēc pēc kļūdas nospiešanas šeit ir jāatsāk atkārtojums.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // visu masīva elementu pārbaudītā summa
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Pievienojot 100 elementu, šī summa pārpilda
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Tā kā tas bija īssavienots, pārējie elementi joprojām ir pieejami caur iteratoru.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Iteratora metode, kas katram iteratora vienumam piemēro kļūdainu funkciju, apstājoties pie pirmās kļūdas un atgriežot šo kļūdu.
    ///
    ///
    /// To var uzskatīt arī par [`for_each()`] kļūdainu formu vai par [`try_fold()`] bezvalstnieku versiju.
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Tas bija īssavienojums, tāpēc pārējie vienumi joprojām ir iteratorā:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Katru elementu saliek akumulatorā, piemērojot operāciju, atgriežot gala rezultātu.
    ///
    /// `fold()` ir divi argumenti: sākotnējā vērtība un noslēgums ar diviem argumentiem: 'accumulator' un elementu.
    /// Aizvēršana atgriež vērtību, kāda akumulatoram vajadzētu būt nākamajam atkārtojumam.
    ///
    /// Sākotnējā vērtība ir vērtība, kas akumulatoram būs pirmā zvana laikā.
    ///
    /// Pēc šīs aizvēršanas piemērošanas visiem iteratora elementiem `fold()` atgriež akumulatoru.
    ///
    /// Šo darbību dažreiz sauc par 'reduce' vai 'inject'.
    ///
    /// Saliekšana ir noderīga ikreiz, kad jums ir kaut kas kolekcija un vēlaties no tā radīt vienu vērtību.
    ///
    /// Note: `fold()` un līdzīgas metodes, kas šķērso visu iteratoru, var nebeigties bezgalīgiem iteratoriem pat uz traits, kuru rezultāts ir nosakāms ierobežotā laikā.
    ///
    /// Note: [`reduce()`] var izmantot, lai pirmo elementu izmantotu kā sākotnējo vērtību, ja akumulatora tips un vienuma tips ir vienādi.
    ///
    /// # Piezīme īstenotājiem
    ///
    /// Vairākām citām (forward) metodēm ir noklusējuma ieviešanas iespējas attiecībā uz šo metodi, tāpēc mēģiniet to skaidri ieviest, ja tā var paveikt kaut ko labāku nekā noklusējuma `for` cilpas ieviešana.
    ///
    ///
    /// Īpaši mēģiniet, lai šis zvans `fold()` būtu iekšējās daļās, no kurām sastāv šis iterators.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // visu masīva elementu summa
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Apskatīsim katru atkārtojuma soli šeit:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// Un tā, mūsu galīgais rezultāts, `6`.
    ///
    /// Cilvēki, kuri nav daudz izmantojuši iteratorus, parasti izmanto `for` cilpu ar lietu sarakstu, lai izveidotu rezultātu.Tos var pārveidot par `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // cilpai:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // viņi ir vienādi
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Samazina elementus līdz vienam, atkārtoti izmantojot reducēšanas darbību.
    ///
    /// Ja iterators ir tukšs, atgriež [`None`];pretējā gadījumā atgriež samazināšanas rezultātu.
    ///
    /// Atkārtotājiem ar vismaz vienu elementu tas ir tāds pats kā [`fold()`], kura sākotnējais lielums ir pirmais iteratora elements, katru nākamo elementu saliekot tajā.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Atrodiet maksimālo vērtību:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Pārbauda, vai katrs iteratora elements atbilst predikātam.
    ///
    /// `all()` veic slēgšanu, kas atgriež vērtību `true` vai `false`.Tas piemēro šo aizvēršanu katram iteratora elementam, un, ja viņi visi atgriež `true`, tad to dara arī `all()`.
    /// Ja kāds no viņiem atgriež `false`, tas atgriež `false`.
    ///
    /// `all()` ir īssavienojums;citiem vārdiem sakot, tā pārtrauks apstrādi, tiklīdz atradīs `false`, ņemot vērā to, ka neatkarīgi no tā, kas vēl notiek, rezultāts būs arī `false`.
    ///
    ///
    /// Tukšs atkārtotājs atgriež `true`.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Apstāšanās pie pirmā `false`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // mēs joprojām varam izmantot `iter`, jo ir vairāk elementu.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Pārbauda, vai kāds iteratora elements atbilst predikātam.
    ///
    /// `any()` veic slēgšanu, kas atgriež vērtību `true` vai `false`.Tas piemēro šo aizvēršanu katram iteratora elementam, un, ja kāds no tiem atgriež `true`, tad to dara arī `any()`.
    /// Ja viņi visi atgriež `false`, tas atgriež `false`.
    ///
    /// `any()` ir īssavienojums;citiem vārdiem sakot, tā pārtrauks apstrādi, tiklīdz atradīs `true`, ņemot vērā to, ka neatkarīgi no tā, kas vēl notiek, rezultāts būs arī `true`.
    ///
    ///
    /// Tukšs atkārtotājs atgriež `false`.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Apstāšanās pie pirmā `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // mēs joprojām varam izmantot `iter`, jo ir vairāk elementu.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Meklē iteratora elementu, kas apmierina predikātu.
    ///
    /// `find()` veic slēgšanu, kas atgriež `true` vai `false`.
    /// Tas piemēro šo aizvēršanu katram iteratora elementam, un, ja kāds no tiem atgriež `true`, tad `find()` atgriež [`Some(element)`].
    /// Ja viņi visi atgriež `false`, tas atgriež [`None`].
    ///
    /// `find()` ir īssavienojums;citiem vārdiem sakot, tā pārtrauks apstrādi, tiklīdz slēgšana atgriezīs `true`.
    ///
    /// Tā kā `find()` ņem atsauci un daudzi atkārtotāji atkārto atsauces, tas rada potenciāli mulsinošu situāciju, kad arguments ir divkārša atsauce.
    ///
    /// Šo efektu var redzēt zemāk esošajos piemēros ar `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Apstāšanās pie pirmā `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // mēs joprojām varam izmantot `iter`, jo ir vairāk elementu.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Ņemiet vērā, ka `iter.find(f)` ir ekvivalents `iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Pielieto funkciju iteratora elementiem un atgriež pirmo rezultātu, kas nav neviens.
    ///
    ///
    /// `iter.find_map(f)` ir ekvivalents `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Pielieto funkciju iteratora elementiem un atgriež pirmo patieso rezultātu vai pirmo kļūdu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Elementā meklē elementu, atgriežot tā indeksu.
    ///
    /// `position()` veic slēgšanu, kas atgriež `true` vai `false`.
    /// Tas piemēro šo aizvēršanu katram iteratora elementam, un, ja kāds no tiem atgriež `true`, tad `position()` atgriež [`Some(index)`].
    /// Ja visi no tiem atgriež `false`, tas atgriež [`None`].
    ///
    /// `position()` ir īssavienojums;citiem vārdiem sakot, tā pārtrauks apstrādi, tiklīdz atradīs `true`.
    ///
    /// # Pārplūdes uzvedība
    ///
    /// Metode nepasargā no pārplūdēm, tādēļ, ja ir vairāk nekā [`usize::MAX`] nesakritoši elementi, tā rada nepareizu rezultātu vai panics.
    ///
    /// Ja atkļūdošanas apgalvojumi ir iespējoti, tiek garantēta panic.
    ///
    /// # Panics
    ///
    /// Šī funkcija var būt panic, ja iteratoram ir vairāk nekā `usize::MAX` neatbilstoši elementi.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Apstāšanās pie pirmā `true`:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // mēs joprojām varam izmantot `iter`, jo ir vairāk elementu.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Atgrieztais indekss ir atkarīgs no iteratora stāvokļa
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// No labās puses iteratorā meklē elementu, atgriežot tā indeksu.
    ///
    /// `rposition()` veic slēgšanu, kas atgriež `true` vai `false`.
    /// Tas piemēro šo aizvēršanu katram iteratora elementam, sākot no beigām, un, ja kāds no tiem atgriež `true`, tad `rposition()` atgriež [`Some(index)`].
    ///
    /// Ja visi no tiem atgriež `false`, tas atgriež [`None`].
    ///
    /// `rposition()` ir īssavienojums;citiem vārdiem sakot, tā pārtrauks apstrādi, tiklīdz atradīs `true`.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Apstāšanās pie pirmā `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // mēs joprojām varam izmantot `iter`, jo ir vairāk elementu.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Šeit nav jāveic pārpildes pārbaude, jo `ExactSizeIterator` nozīmē, ka elementu skaits iekļaujas `usize`.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Atgriež maksimālo iteratora elementu.
    ///
    /// Ja vairāki elementi ir vienādi maksimāli, tiek atgriezts pēdējais elements.
    /// Ja iterators ir tukšs, [`None`] tiek atgriezts.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Atgriež minimālo iteratora elementu.
    ///
    /// Ja vairāki elementi ir vienādi minimāli, pirmais elements tiek atgriezts.
    /// Ja iterators ir tukšs, [`None`] tiek atgriezts.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Atgriež elementu, kas dod maksimālo vērtību no norādītās funkcijas.
    ///
    ///
    /// Ja vairāki elementi ir vienādi maksimāli, tiek atgriezts pēdējais elements.
    /// Ja iterators ir tukšs, [`None`] tiek atgriezts.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Atgriež elementu, kas dod maksimālo vērtību attiecībā pret norādīto salīdzināšanas funkciju.
    ///
    ///
    /// Ja vairāki elementi ir vienādi maksimāli, tiek atgriezts pēdējais elements.
    /// Ja iterators ir tukšs, [`None`] tiek atgriezts.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Atgriež elementu, kas dod minimālo vērtību no norādītās funkcijas.
    ///
    ///
    /// Ja vairāki elementi ir vienādi minimāli, pirmais elements tiek atgriezts.
    /// Ja iterators ir tukšs, [`None`] tiek atgriezts.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Atgriež elementu, kas dod minimālo vērtību attiecībā pret norādīto salīdzināšanas funkciju.
    ///
    ///
    /// Ja vairāki elementi ir vienādi minimāli, pirmais elements tiek atgriezts.
    /// Ja iterators ir tukšs, [`None`] tiek atgriezts.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Apgriež iteratora virzienu.
    ///
    /// Parasti atkārtotāji atkārtojas no kreisās uz labo pusi.
    /// Pēc `rev()` izmantošanas iterators iterēs no labās uz kreiso.
    ///
    /// Tas ir iespējams tikai tad, ja iteratoram ir beigas, tāpēc `rev()` darbojas tikai uz [`DoubleEndedIterator`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Pārvērš pāru atkārtotāju par konteineru pāri.
    ///
    /// `unzip()` patērē visu pāru atkārtotāju, veidojot divas kolekcijas: vienu no pāru kreisajiem elementiem un otru no labajiem elementiem.
    ///
    ///
    /// Šī funkcija savā ziņā ir pretēja [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Izveido iteratoru, kas kopē visus tā elementus.
    ///
    /// Tas ir noderīgi, ja jums ir iterators virs `&T`, bet jums ir nepieciešams iterators virs `T`.
    ///
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // kopēts ir tas pats, kas .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Izveido iteratoru, kas [klonē] visus tā elementus.
    ///
    /// Tas ir noderīgi, ja jums ir iterators virs `&T`, bet jums ir nepieciešams iterators virs `T`.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // vesels skaitlis ir tāds pats kā .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Bezgalīgi atkārto atkārtotāju.
    ///
    /// Tā vietā, lai apstātos pie [`None`], iterators tiks sākts no jauna.Pēc atkārtotas atkārtošanas tas tiks sākts no jauna.Un atkal.
    /// Un atkal.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Apkopo iteratora elementus.
    ///
    /// Ņem katru elementu, saskaita tos kopā un atgriež rezultātu.
    ///
    /// Tukšs atkārtotājs atgriež tipa nulles vērtību.
    ///
    /// # Panics
    ///
    /// Zvanot uz `sum()` un tiek atgriezts primitīvs vesela skaitļa tips, šī metode būs panic, ja ir iespējotas skaitļošanas pārpildes un atkļūdošanas apgalvojumi.
    ///
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Atkārtojas visā iteratorā, reizinot visus elementus
    ///
    /// Tukšs atkārtotājs atgriež viena veida vērtību.
    ///
    /// # Panics
    ///
    /// Zvanot uz `product()` un tiek atgriezts primitīvs vesela skaitļa tips, metode būs panic, ja ir iespējotas skaitļošanas pārpildes un atkļūdošanas apgalvojumi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) salīdzina šī [`Iterator`] elementus ar cita elementiem.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) salīdzina šī [`Iterator`] elementus ar cita elementiem, ņemot vērā norādīto salīdzināšanas funkciju.
    ///
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) salīdzina šī [`Iterator`] elementus ar cita elementiem.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) salīdzina šī [`Iterator`] elementus ar cita elementiem, ņemot vērā norādīto salīdzināšanas funkciju.
    ///
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Nosaka, vai šī [`Iterator`] elementi ir vienādi ar cita elementiem.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Nosaka, vai šī [`Iterator`] elementi attiecībā uz norādīto vienlīdzības funkciju ir vienādi ar cita elementiem.
    ///
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Nosaka, vai šī [`Iterator`] elementi nav vienādi ar cita elementiem.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Nosaka, vai šī [`Iterator`] elementi ir [lexicographically](Ord#lexicographical-comparison) mazāki nekā cita elementi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Nosaka, vai šī [`Iterator`] elementi ir [lexicographically](Ord#lexicographical-comparison) mazāki vai vienādi ar cita elementiem.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Nosaka, vai šī [`Iterator`] elementi ir [lexicographically](Ord#lexicographical-comparison) lielāki nekā cita elementi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Nosaka, vai šī [`Iterator`] elementi ir [lexicographically](Ord#lexicographical-comparison) lielāki vai vienādi ar citu elementiem.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Pārbauda, vai šī iteratora elementi ir sakārtoti.
    ///
    /// Tas ir, katram elementam `a` un tam sekojošajam elementam `b` ir jāatbilst `a <= b`.Ja iterators dod tieši nulli vai vienu elementu, `true` tiek atgriezts.
    ///
    /// Ņemiet vērā, ka, ja `Self::Item` ir tikai `PartialOrd`, bet ne `Ord`, iepriekšminētā definīcija nozīmē, ka šī funkcija atgriež `false`, ja divi secīgi vienumi nav salīdzināmi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Pārbauda, vai šī iteratora elementi ir sakārtoti, izmantojot norādīto salīdzināšanas funkciju.
    ///
    /// Tā vietā, lai izmantotu `PartialOrd::partial_cmp`, šī funkcija izmanto norādīto `compare` funkciju, lai noteiktu divu elementu secību.
    /// Bez tam tas ir līdzvērtīgs [`is_sorted`];Plašāku informāciju skatiet tās dokumentācijā.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Pārbauda, vai šī iteratora elementi ir sakārtoti, izmantojot norādīto atslēgas izvilkšanas funkciju.
    ///
    /// Tā vietā, lai tieši salīdzinātu iteratora elementus, šī funkcija salīdzina elementu taustiņus, ko nosaka `f`.
    /// Bez tam tas ir līdzvērtīgs [`is_sorted`];Plašāku informāciju skatiet tās dokumentācijā.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// Skatiet [TrustedRandomAccess]
    // Neparasts nosaukums ir izvairīties no nosaukuma sadursmēm metodes izšķirtspējā, sk. #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}