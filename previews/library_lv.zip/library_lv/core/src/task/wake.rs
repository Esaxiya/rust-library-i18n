#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// `RawWaker` ļauj uzdevuma izpildītājam izveidot [`Waker`], kas nodrošina pielāgotu modināšanas darbību.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// Tas sastāv no datu rādītāja un [virtual function pointer table (vtable)][vtable], kas pielāgo `RawWaker` darbību.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// Datu rādītājs, kuru var izmantot patvaļīgu datu glabāšanai, kā to prasa izpildītājs.
    /// Tas varētu būt, piemēram,
    /// tipa dzēsts rādītājs `Arc`, kas ir saistīts ar uzdevumu.
    /// Šī lauka vērtība tiek nodota visām funkcijām, kas ir daļa no vtable kā pirmais parametrs.
    ///
    data: *const (),
    /// Virtuālo funkciju rādītāju tabula, kas pielāgo šī modinātāja darbību.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Izveido jaunu `RawWaker` no norādītā `data` rādītāja un `vtable`.
    ///
    /// `data` rādītāju var izmantot patvaļīgu datu glabāšanai, kā to prasa izpildītājs.Tas varētu būt, piemēram,
    /// tipa dzēsts rādītājs `Arc`, kas ir saistīts ar uzdevumu.
    /// Šī rādītāja vērtība tiks nodota visām funkcijām, kas ir `vtable` daļa kā pirmais parametrs.
    ///
    /// `vtable` pielāgo `Waker` darbību, kas tiek izveidota no `RawWaker`.
    /// Katrai `Waker` operācijai tiks izsaukta saistītā funkcija `vtable` pamatā esošajā `RawWaker`.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// Virtuālo funkciju rādītāju tabula (vtable), kas norāda [`RawWaker`] darbību.
///
/// Rādītājs, kas tiek nodots visām vtable iekšpusē esošajām funkcijām, ir `data` rādītājs no norobežojošā objekta [`RawWaker`].
///
/// Funkcijas, kas atrodas šīs struktūras iekšienē, ir paredzētas izsaukšanai tikai uz pareizi izveidota [`RawWaker`] objekta `data` rādītāja no [`RawWaker`] ieviešanas iekšpuses.
/// Zvanīšana uz kādu no iekļautajām funkcijām, izmantojot jebkuru citu `data` rādītāju, izraisīs nedefinētu rīcību.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// Šī funkcija tiks izsaukta, kad [`RawWaker`] tiks klonēts, piemēram, kad tiks klonēts [`Waker`], kurā glabājas [`RawWaker`].
    ///
    /// Īstenojot šo funkciju, jāsaglabā visi resursi, kas nepieciešami šim [`RawWaker`] un saistītā uzdevuma papildu gadījumam.
    /// Zvanot uz `wake` ar iegūto [`RawWaker`], vajadzētu pamodināt to pašu uzdevumu, kuru būtu pamodinājis sākotnējais [`RawWaker`].
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Šī funkcija tiks izsaukta, kad [`Waker`] tiek izsaukta uz `wake`.
    /// Tam ir jāpamodina uzdevums, kas saistīts ar šo [`RawWaker`].
    ///
    /// Šīs funkcijas ieviešanai noteikti jāizlaiž visi resursi, kas ir saistīti ar šo [`RawWaker`] un saistītā uzdevuma gadījumu.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Šī funkcija tiks izsaukta, kad [`Waker`] tiek izsaukta uz `wake_by_ref`.
    /// Tam ir jāpamodina uzdevums, kas saistīts ar šo [`RawWaker`].
    ///
    /// Šī funkcija ir līdzīga `wake`, taču tā nedrīkst patērēt norādīto datu rādītāju.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Šī funkcija tiek izsaukta, kad tiek nomests [`RawWaker`].
    ///
    /// Šīs funkcijas ieviešanai noteikti jāizlaiž visi resursi, kas ir saistīti ar šo [`RawWaker`] un saistītā uzdevuma gadījumu.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Izveido jaunu `RawWakerVTable` no paredzētajām funkcijām `clone`, `wake`, `wake_by_ref` un `drop`.
    ///
    /// # `clone`
    ///
    /// Šī funkcija tiks izsaukta, kad [`RawWaker`] tiks klonēts, piemēram, kad tiks klonēts [`Waker`], kurā glabājas [`RawWaker`].
    ///
    /// Īstenojot šo funkciju, jāsaglabā visi resursi, kas nepieciešami šim [`RawWaker`] un saistītā uzdevuma papildu gadījumam.
    /// Zvanot uz `wake` ar iegūto [`RawWaker`], vajadzētu pamodināt to pašu uzdevumu, kuru būtu pamodinājis sākotnējais [`RawWaker`].
    ///
    /// # `wake`
    ///
    /// Šī funkcija tiks izsaukta, kad [`Waker`] tiek izsaukta uz `wake`.
    /// Tam ir jāpamodina uzdevums, kas saistīts ar šo [`RawWaker`].
    ///
    /// Šīs funkcijas ieviešanai noteikti jāizlaiž visi resursi, kas ir saistīti ar šo [`RawWaker`] un saistītā uzdevuma gadījumu.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Šī funkcija tiks izsaukta, kad [`Waker`] tiek izsaukta uz `wake_by_ref`.
    /// Tam ir jāpamodina uzdevums, kas saistīts ar šo [`RawWaker`].
    ///
    /// Šī funkcija ir līdzīga `wake`, taču tā nedrīkst patērēt norādīto datu rādītāju.
    ///
    /// # `drop`
    ///
    /// Šī funkcija tiek izsaukta, kad tiek nomests [`RawWaker`].
    ///
    /// Šīs funkcijas ieviešanai noteikti jāizlaiž visi resursi, kas ir saistīti ar šo [`RawWaker`] un saistītā uzdevuma gadījumu.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// Asinhronā uzdevuma `Context`.
///
/// Pašlaik `Context` kalpo tikai tam, lai nodrošinātu piekļuvi `&Waker`, ko var izmantot pašreizējā uzdevuma aktivizēšanai.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Pārliecinieties, ka mēs ar future esam izturīgi pret dispersiju izmaiņām, piespiežot dzīves ilgumu būt nemainīgam (argumentu un pozīciju mūžs ir pretrunīgs, savukārt atgriešanās pozīcijas dzīves ilgums ir kovariants).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Izveidojiet jaunu `Context` no `&Waker`.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Atgriež atsauci uz pašreizējā uzdevuma `Waker`.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// `Waker` ir rokturis uzdevuma pamodināšanai, paziņojot izpildītājam, ka tas ir gatavs izpildīšanai.
///
/// Šis rokturis iekapsulē [`RawWaker`] gadījumu, kas nosaka izpildītājam raksturīgo modināšanas darbību.
///
///
/// Ievieš [`Clone`], [`Send`] un [`Sync`].
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Pamodiniet uzdevumu, kas saistīts ar šo `Waker`.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // Faktiskais modināšanas zvans, izmantojot virtuālo funkciju izsaukumu, tiek deleģēts izpildītājam, kuru nosaka izpildītājs.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // Nezvaniet uz `drop`-modinātāju patērēs `wake`.
        crate::mem::forget(self);

        // DROŠĪBA: Tas ir droši, jo `Waker::from_raw` ir vienīgais veids
        // lai inicializētu `wake` un `data`, pieprasot, lai lietotājs atzīst, ka tiek ievērots `RawWaker` līgums.
        //
        unsafe { (wake)(data) };
    }

    /// Pamodiniet uzdevumu, kas saistīts ar šo `Waker`, neizmantojot `Waker`.
    ///
    /// Tas ir līdzīgs `wake`, taču var būt nedaudz mazāk efektīvs gadījumā, ja ir pieejams īpašumā esošais `Waker`.
    /// Šai metodei vajadzētu dot priekšroku, nevis zvanīt uz `waker.clone().wake()`.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // Faktiskais modināšanas zvans, izmantojot virtuālo funkciju izsaukumu, tiek deleģēts izpildītājam, kuru nosaka izpildītājs.
        //

        // DROŠĪBA: skatiet `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Atgriež vērtību `true`, ja šī `Waker` un cita `Waker` ir modinājusi to pašu uzdevumu.
    ///
    /// Šī funkcija darbojas pēc vislabākajiem centieniem un var atgriezties nepatiesi, pat ja `Waker`s pamodinās to pašu uzdevumu.
    /// Tomēr, ja šī funkcija atgriež `true`, tiek garantēts, ka `Waker`s pamodinās to pašu uzdevumu.
    ///
    /// Šo funkciju galvenokārt izmanto optimizācijas nolūkos.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// Izveido jaunu `Waker` no [`RawWaker`].
    ///
    /// Atgrieztā `Waker` darbība nav definēta, ja netiek ievērots [RawWaker`] un [`RawWakerVTable`` dokumentācijā definētais līgums.
    ///
    /// Tāpēc šī metode ir nedroša.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // DROŠĪBA: Tas ir droši, jo `Waker::from_raw` ir vienīgais veids
            // lai inicializētu `clone` un `data`, pieprasot, lai lietotājs atzīst, ka tiek ievērots [`RawWaker`] līgums.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // DROŠĪBA: Tas ir droši, jo `Waker::from_raw` ir vienīgais veids
        // lai inicializētu `drop` un `data`, pieprasot, lai lietotājs atzīst, ka tiek ievērots `RawWaker` līgums.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}