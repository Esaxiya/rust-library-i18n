//! Primitīvi traits un tipi, kas pārstāv tipu pamatīpašības.
//!
//! Rust tipus var klasificēt dažādos noderīgos veidos pēc to raksturīgajām īpašībām.
//! Šīs klasifikācijas tiek attēlotas kā traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Veidi, kurus var pārvietot pāri pavedienu robežām.
///
/// Šis trait tiek automātiski ieviests, kad kompilators nosaka, ka tas ir piemērots.
///
/// Tipa, kas nav `Nosūtīt`, piemērs ir atsauces skaitīšanas rādītājs [`rc::Rc`][`Rc`].
/// Ja divi pavedieni mēģina klonēt [`Rc`], kas norāda uz to pašu atskaites skaitīto vērtību, viņi var mēģināt vienlaikus atjaunināt atsauču skaitu, kas ir [undefined behavior][ub], jo [`Rc`] neizmanto atomu darbības.
///
/// Tās brālēns [`sync::Arc`][arc] izmanto atomu operācijas (radot nedaudz virs galvas) un tādējādi ir `Send`.
///
/// Plašāku informāciju skatiet [the Nomicon](../../nomicon/send-and-sync.html).
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Veidi ar nemainīgu izmēru, kas zināmi sastādīšanas laikā.
///
/// Visiem tipa parametriem ir netieša saistība ar `Sized`.Īpašo sintaksi `?Sized` var izmantot, lai noņemtu šo saiti, ja tas nav piemērots.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struktūras FooUse(Foo<[i32]>);//kļūda: [i32] nav ieviests izmērs
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Vienīgais izņēmums ir netiešais trait tips `Self`.
/// trait nav netieši saistīts `Sized`, jo tas nav saderīgs ar [trait objektu], kur pēc definīcijas trait ir jāsadarbojas ar visiem iespējamiem īstenotājiem, un tādējādi tas varētu būt jebkura izmēra.
///
///
/// Lai gan Rust ļaus jums saistīt `Sized` ar trait, vēlāk to nevarēsit izmantot trait objekta veidošanai:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // ļaujiet y: &dyn josla= &Impl;//kļūda: trait `Bar` nevar padarīt par objektu
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // piemēram, Default, kas prasa, lai `[T]: !Default` būtu novērtējams
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Veidi, kas var būt "unsized" līdz dinamiski lielam tipam.
///
/// Piemēram, izmēra masīva tips `[i8; 2]` ievieš `Unsize<[i8]>` un `Unsize<dyn fmt::Debug>`.
///
/// Kompilators automātiski nodrošina visas `Unsize` ieviešanas iespējas.
///
/// `Unsize` tiek ieviesta:
///
/// - `[T; N]` ir `Unsize<[T]>`
/// - `T` ir `Unsize<dyn Trait>`, kad `T: Trait`
/// - `Foo<..., T, ...>` ir `Unsize<Foo<..., U, ...>>`, ja:
///   - `T: Unsize<U>`
///   - Foo ir struktūra
///   - Tikai pēdējā `Foo` laukā ir tips, kas ietver `T`
///   - `T` nav daļa no citu lauku tipiem
///   - `Bar<T>: Unsize<Bar<U>>`, ja `Foo` pēdējam laukam ir `Bar<T>` tips
///
/// `Unsize` tiek izmantots kopā ar [`ops::CoerceUnsized`], lai "user-defined" konteineros, piemēram, [`Rc`], būtu dinamiski lieluma veidi.
/// Plašāku informāciju skatiet [DST coercion RFC][RFC982] un [the nomicon entry on coercion][nomicon-coerce].
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Nepieciešams trait konstantēm, kuras tiek izmantotas modeļu spēlēs.
///
/// Jebkurš tips, kas iegūst `PartialEq`, automātiski ievieš šo trait, * neatkarīgi no tā, vai tā tipa parametri ievieš `Eq`.
///
/// Ja `const` vienumā ir kāds tips, kas neievieš šo trait, tad šis tips vai nu (1.) neievieš `PartialEq` (tas nozīmē, ka konstante nenodrošinās šo salīdzināšanas metodi, kuras pieņemšana koda pieņemšanai ir pieejama), vai (2.), kuru tā ievieš *savu*`PartialEq` versija (kas, pēc mūsu domām, neatbilst strukturālās vienlīdzības salīdzinājumam).
///
///
/// Jebkurā no diviem iepriekš minētajiem scenārijiem mēs noraidām šādas konstantes izmantošanu parauga atbilstībā.
///
/// Skatiet arī [structural match RFC][RFC1445] un [issue 63438], kas motivēja migrēt no atribūtiem balstīta dizaina uz šo trait.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Nepieciešams trait konstantēm, kuras tiek izmantotas modeļu spēlēs.
///
/// Jebkurš tips, kas iegūst `Eq`, automātiski ievieš šo trait, * neatkarīgi no tā, vai tā tipa parametri ievieš `Eq`.
///
/// Tas ir kapāt, lai apietu ierobežojumus mūsu tipa sistēmā.
///
/// # Background
///
/// Mēs vēlamies pieprasīt, lai modeļu atbilstībās izmantotajiem konsta veidiem būtu atribūts `#[derive(PartialEq, Eq)]`.
///
/// Ideālākā pasaulē mēs varētu pārbaudīt šo prasību, vienkārši pārbaudot, vai dotais tips īsteno gan `StructuralPartialEq` trait *, gan*`Eq` trait.
/// Tomēr jums var būt ADT, kas *dara*`derive(PartialEq, Eq)`, un tas ir gadījums, kuru mēs vēlamies, lai kompilators pieņem, un tomēr konstantes tips neizdodas ieviest `Eq`.
///
/// Proti, šāds gadījums:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Iepriekšējā kodā problēma ir tā, ka `Wrap<fn(&())>` neievieš ne `PartialEq`, ne `Eq`, jo `for <` a> fn(&'a _)` does not implement those traits.)
///
/// Tāpēc mēs nevaram paļauties uz naivu pārbaudi `StructuralPartialEq` un tikai `Eq`.
///
/// Lai to apietu, mēs izmantojam divus atsevišķus traits, kurus injicē katrs no abiem atvasinājumiem (`#[derive(PartialEq)]` un `#[derive(Eq)]`), un pārbaudām, vai abi ir klāt kā daļa no strukturālās atbilstības pārbaudes.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Veidi, kuru vērtības var dublēt, vienkārši kopējot bitus.
///
/// Pēc noklusējuma mainīgajām saitēm ir `pārvietot semantiku`.Citiem vārdiem sakot:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` ir pārvietots uz `y`, un tāpēc to nevar izmantot
///
/// // println! ("{: ?}", x);//kļūda: pārvietotās vērtības izmantošana
/// ```
///
/// Tomēr, ja tips ievieš `Copy`, tā vietā ir `kopēšanas semantika`:
///
/// ```
/// // Mēs varam iegūt `Copy` ieviešanu.
/// // `Clone` ir arī nepieciešams, jo tas ir `Copy` supertraits.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` ir `x` kopija
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Ir svarīgi atzīmēt, ka šajos divos piemēros vienīgā atšķirība ir tā, vai pēc piešķiršanas jums ir atļauts piekļūt `x`.
/// Zem pārsega gan kopijas, gan pārvietošanas rezultātā biti var tikt kopēti atmiņā, lai gan tas dažreiz tiek optimizēts.
///
/// ## Kā es varu ieviest `Copy`?
///
/// Ir divi veidi, kā `Copy` ieviest jūsu tipā.Vienkāršākais ir izmantot `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// `Copy` un `Clone` var arī ieviest manuāli:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Starp abiem ir neliela atšķirība: `derive` stratēģija arī ievietos `Copy`, kas saistīts ar tipa parametriem, kas ne vienmēr ir vēlams.
///
/// ## Kāda ir atšķirība starp `Copy` un `Clone`?
///
/// Kopijas notiek netieši, piemēram, kā daļu no uzdevuma `y = x`.`Copy` darbība nav pārslogojama;tā vienmēr ir vienkārša, mazliet gudra kopija.
///
/// Klonēšana ir nepārprotama darbība, `x.clone()`.[`Clone`] ieviešana var nodrošināt jebkura veida darbību, kas nepieciešama, lai droši dublētu vērtības.
/// Piemēram, [`Clone`] ieviešanai operētājsistēmai [`String`] ir jākopē kaudzītē norādītais virknes buferis.
/// Vienkārša [`String`] vērtību bitu kopija tikai kopētu rādītāju, kas novestu pie dubultas brīvas līnijas lejup.
/// Šī iemesla dēļ [`String`] ir [`Clone`], bet ne `Copy`.
///
/// [`Clone`] ir `Copy` supertrait, tāpēc visam, kas ir `Copy`, ir jāievieš arī [`Clone`].
/// Ja tips ir `Copy`, tā [`Clone`] ieviešanai jāatdod tikai `*self` (skatiet iepriekš sniegto piemēru).
///
/// ## Kad mans tips var būt `Copy`?
///
/// Tips var ieviest `Copy`, ja visi tā komponenti ievieš `Copy`.Piemēram, šī struktūra var būt `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Struktūra var būt `Copy`, un [`i32`] ir `Copy`, tāpēc `Point` ir piemērots `Copy`.
/// Turpretī apsveriet
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// Struktūra `PointList` nevar ieviest `Copy`, jo [`Vec<T>`] nav `Copy`.Ja mēģināsim iegūt `Copy` ieviešanu, tiks parādīta kļūda:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Koplietotās atsauces (`&T`) ir arī `Copy`, tāpēc tips var būt `Copy`, pat ja tam ir kopīgas `T` tipa atsauces, kas *nav*`Copy`.
/// Apsveriet šādu struktūru, ar kuru var ieviest `Copy`, jo tai ir tikai *kopīga atsauce* uz mūsu, nevis kopiju `PointList` tipu no augšas:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Kad *vai* mans tips nevar būt `Copy`?
///
/// Dažus veidus nevar droši kopēt.Piemēram, kopējot `&mut T`, tiktu izveidota aizstājvārda mainīga atsauce.
/// Kopējot [`String`], tiktu dublēta atbildība par [`String`] bufera pārvaldību, tādējādi radot dubultu bezmaksas.
///
/// Apkopojot pēdējo gadījumu, jebkurš tips, kas ievieš [`Drop`], nevar būt `Copy`, jo tas pārvalda dažus resursus papildus saviem [`size_of::<T>`] baitiem.
///
/// Ja mēģināsit ieviest `Copy` struktūrā vai uzskaitē, kas satur datus, kas nav `Copy`, tiks parādīta kļūda [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Kad * manam tipam vajadzētu būt `Copy`?
///
/// Vispārīgi runājot, ja jūsu _can_ tips ievieš `Copy`, tam vajadzētu būt.
/// Tomēr paturiet prātā, ka `Copy` ieviešana ir daļa no jūsu veida publiskās API.
/// Ja future tipā var kļūt ne-Kopija, varētu būt piesardzīgi tagad izlaist `Copy` ieviešanu, lai izvairītos no API izmaiņām.
///
/// ## Papildu ieviesēji
///
/// Papildus [implementors listed below][impls] `Copy` ievieš arī šādi tipi:
///
/// * Funkciju vienumu veidi (ti, katrai funkcijai noteiktie atšķirīgie veidi)
/// * Funkciju rādītāju veidi (piem., `fn() -> i32`)
/// * Masīvu veidi visiem izmēriem, ja vienuma tips ievieš arī `Copy` (piem., `[i32; 123456]`)
/// * Tuple veidi, ja katrs komponents arī ievieš `Copy` (piemēram, `()`, `(i32, bool)`)
/// * Slēgšanas veidi, ja tie neuzņem nekādu vērtību no vides vai ja visas šādas uzņemtās vērtības pašas ievieš `Copy`.
///   Ņemiet vērā, ka mainīgie, kas uztverti ar kopīgu atsauci, vienmēr ievieš `Copy` (pat ja referents to nedara), bet mainīgie, kurus uztver mainīga atsauce, nekad neievieš `Copy`.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Tas ļauj kopēt tipu, kas neievieš `Copy` neapmierinošu mūža ierobežojumu dēļ (`A<'_>` kopēšana, ja tikai `A<'static>: Copy` un `A<'_>: Clone`).
// Šis atribūts mums tagad ir tikai tāpēc, ka `Copy` ir diezgan daudz specializāciju, kas jau pastāv standarta bibliotēkā, un pašlaik nav iespējas droši rīkoties šādi.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Iegūstiet makro, ģenerējot trait `Copy` impliku.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Veidi, kuriem ir droši kopīgot atsauces starp pavedieniem.
///
/// Šis trait tiek automātiski ieviests, kad kompilators nosaka, ka tas ir piemērots.
///
/// Precīza definīcija ir šāda: `T` tips ir [`Sync`] tikai tad, ja `&T` ir [`Send`].
/// Citiem vārdiem sakot, ja, nododot `&T` atsauces starp pavedieniem, nav iespēju [undefined behavior][ub] (ieskaitot datu sacīkstes).
///
/// Kā varētu sagaidīt, primitīvi tipi, piemēram, [`u8`] un [`f64`], visi ir [`Sync`], un tāpat ir vienkārši tos saturoši agregātu tipi, piemēram, komplekti, uzbūves un enumi.
/// Citi pamata [`Sync`] tipu piemēri ietver "immutable" tipus, piemēram, `&T`, un tipus ar vienkāršu iedzimtu mainīgumu, piemēram, [`Box<T>`][box], [`Vec<T>`][vec] un lielāko daļu citu kolekciju veidu.
///
/// (Vispārējiem parametriem jābūt [`Sync`], lai to konteiners būtu ["Sync"].)
///
/// Nedaudz pārsteidzošas definīcijas sekas ir tādas, ka `&mut T` ir `Sync` (ja `T` ir `Sync`), pat ja šķiet, ka tas varētu nodrošināt nesinhronizētu mutāciju.
/// Triks ir tāds, ka maināmā atsauce aiz koplietotās atsauces (tas ir, `& &mut T`) kļūst tikai lasāma, it kā tā būtu `& &T`.
/// Tādējādi nav datu sacīkšu riska.
///
/// Veidi, kas nav `Sync`, ir tādi, kuriem "interior mutability" ir bezvītnes formā, piemēram, [`Cell`][cell] un [`RefCell`][refcell].
/// Šie veidi ļauj mutēt to saturu pat ar nemaināmu, kopīgu atsauci.
/// Piemēram, `set` metode [`Cell<T>`][cell] aizņem `&self`, tāpēc tai nepieciešama tikai koplietojama atsauce [`&Cell<T>`][cell].
/// Metode neveic sinhronizāciju, tāpēc [`Cell`][cell] nevar būt `Sync`.
///
/// Vēl viens ne-Sync veida piemērs ir atsauces skaitīšanas rādītājs [`Rc`][rc].
/// Ņemot vērā jebkuru atsauci [`&Rc<T>`][rc], jūs varat klonēt jaunu [`Rc<T>`][rc], modificējot atskaites skaitu ar atomu nesaistītā veidā.
///
/// Gadījumos, kad nepieciešama iekšēja maināmība ar vītni, Rust nodrošina [atomic data types], kā arī skaidru bloķēšanu, izmantojot [`sync::Mutex`][mutex] un [`sync::RwLock`][rwlock].
/// Šie veidi nodrošina, ka jebkura mutācija nevar izraisīt datu sacīkstes, tāpēc veidi ir `Sync`.
/// Tāpat [`sync::Arc`][arc] nodrošina [`Rc`][rc] drošu vītņu analogu.
///
/// Visiem tipiem ar salona mainīgumu jāizmanto arī [`cell::UnsafeCell`][unsafecell] aptinums ap value(s), kuru var mutēt, izmantojot kopīgu atsauci.
/// Ja tas neizdodas, ir [undefined behavior][ub].
/// Piemēram, [`transmute`][transmute]-ing no `&T` uz `&mut T` nav derīgs.
///
/// Plašāku informāciju par `Sync` skatiet sadaļā [the Nomicon][nomicon-send-and-sync].
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): Kad atbalsts piezīmju pievienošanai `rustc_on_unimplemented` piezemējas beta versijā, un tas ir paplašināts, lai pārbaudītu, vai prasību ķēdē ir slēgums, pagariniet to kā tādu (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Nulles izmēra tips, ko izmanto, lai atzīmētu lietas, kuras "act like" pieder `T`.
///
/// Pievienojot savam tipam lauku `PhantomData<T>`, kompilatoram tiek teikts, ka jūsu tips darbojas tā, it kā tas saglabātu `T` tipa vērtību, kaut arī tā patiesībā nav.
/// Šī informācija tiek izmantota, aprēķinot noteiktas drošības īpašības.
///
/// Lai iegūtu padziļinātu skaidrojumu par `PhantomData<T>` lietošanu, lūdzu, skatiet [the Nomicon](../../nomicon/phantom-data.html).
///
/// # Šausmīga piezīme 👻👻👻
///
/// Lai gan viņiem abiem ir biedējoši nosaukumi, `PhantomData` un `fantoma tipi` ir saistīti, bet nav identiski.Fantoma tipa parametrs ir vienkārši tipa parametrs, kuru nekad neizmanto.
/// Programmā Rust tas bieži liek kompilatoram sūdzēties, un risinājums ir pievienot "dummy" lietojumu, izmantojot `PhantomData`.
///
/// # Examples
///
/// ## Neizmantotie kalpošanas laika parametri
///
/// Varbūt visizplatītākais `PhantomData` lietošanas gadījums ir struktūra, kurai ir neizmantots kalpošanas laiks, parasti kā daļa no nedroša koda.
/// Piemēram, šeit ir struktūras `Slice`, kurai ir divi `*const T` tipa rādītāji, domājams, kaut kur norādīti masīvā:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Mērķis ir tāds, ka pamatā esošie dati ir derīgi tikai dzīves laikā `'a`, tāpēc `Slice` nevajadzētu pārdzīvot `'a`.
/// Tomēr šis nodoms nav izteikts kodā, jo `'a` kalpošanas laiks netiek izmantots, un tāpēc nav skaidrs, uz kādiem datiem tas attiecas.
/// Mēs to varam izlabot, liekot kompilatoram rīkoties *tā, it kā*`Slice` struktūrā būtu atsauce `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Tam savukārt ir nepieciešama anotācija `T: 'a`, norādot, ka visas atsauces `T` ir derīgas visā `'a` dzīves laikā.
///
/// Inicializējot `Slice`, laukam `phantom` vienkārši jānorāda vērtība `PhantomData`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Nelietoti tipa parametri
///
/// Dažreiz gadās, ka jums ir neizmantoti tipa parametri, kas norāda, kāda veida datiem struktūrai ir "tied", kaut arī šie dati patiesībā nav atrodami pašā struktūrā.
/// Šeit ir piemērs, kur tas rodas ar [FFI].
/// Ārējā saskarne izmanto `*mut ()` tipa rokturus, lai atsauktos uz dažāda veida Rust vērtībām.
/// Mēs izsekojam Rust tipu, izmantojot fantoma tipa parametru struktūrā `ExternalResource`, kas aptin rokturi.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Īpašumtiesības un pārbaude
///
/// `PhantomData<T>` tipa lauka pievienošana norāda, ka jūsu tipam pieder `T` tipa dati.Tas savukārt nozīmē, ka, atmetot tipu, tas var nomest vienu vai vairākus `T` tipa gadījumus.
/// Tas ietekmē Rust kompilatora [drop check] analīzi.
///
/// Ja jūsu struktūrai faktiski nepieder `T` tipa dati, labāk ir izmantot atsauces tipu, piemēram, `PhantomData<&'a T>` (ideally) vai `PhantomData<*const T>` (ja mūža ilgums nav spēkā), lai nenorādītu īpašumtiesības.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Kompilators-iekšējais trait, ko izmanto, lai norādītu enum diskriminantu tipu.
///
/// Šis trait tiek automātiski ieviests katram tipam un nepievieno nekādas garantijas [`mem::Discriminant`].
/// Pārveidot starp `DiscriminantKind::Discriminant` un `mem::Discriminant` ir **nedefinēta rīcība**.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Diskriminanta tips, kuram jāatbilst `mem::Discriminant` prasītajam trait bounds.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Kompilators-iekšējais trait tiek izmantots, lai noteiktu, vai tips satur `UnsafeCell` iekšēji, bet ne caur virzienu.
///
/// Tas, piemēram, ietekmē to, vai šāda veida `static` tiek ievietots tikai lasāmā statiskā atmiņā vai rakstāmā statiskajā atmiņā.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Veidi, kurus pēc piespraušanas var droši pārvietot.
///
/// Pašai Rust nav jēdziena par nekustamajiem veidiem, un tā uzskata, ka pārvietošanās (piemēram, ar piešķiršanu vai [`mem::replace`]) vienmēr ir droša.
///
/// [`Pin`][Pin] tips tiek izmantots, lai novērstu pārvietošanos pa tipa sistēmu.Rādītājus `P<T>`, kas ietīti [`Pin<P<T>>`][Pin] iesaiņojumā, nevar pārvietot.
/// Plašāku informāciju par piespraušanu skatiet [`pin` module] dokumentācijā.
///
/// `Unpin` trait ieviešana operētājsistēmai `T` atceļ tipa noņemšanas ierobežojumus, kas pēc tam ļauj pārvietot `T` no [`Pin<P<T>>`][Pin] ar tādām funkcijām kā [`mem::replace`].
///
///
/// `Unpin` vispār neietekmē nepiespraustos datus.
/// Jo īpaši [`mem::replace`] ar prieku pārvieto `!Unpin` datus (tas darbojas jebkuram `&mut T`, ne tikai tad, kad `T: Unpin`).
/// Tomēr jūs nevarat izmantot [`mem::replace`] datiem, kas iesaiņoti [`Pin<P<T>>`][Pin], jo nevarat iegūt tam nepieciešamo `&mut T`, un *tas* padara šo sistēmu darbojošos.
///
/// Tā, piemēram, to var izdarīt tikai tipiem, kas ievieš `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Lai izsauktu `mem::replace`, mums ir nepieciešama mainīga atsauce.
/// // Šādu atsauci varam iegūt, (implicitly) izsaucot `Pin::deref_mut`, taču tas ir iespējams tikai tāpēc, ka `String` ievieš `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Šis trait tiek automātiski ieviests gandrīz visiem tipiem.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Marķiera tips, kas neievieš `Unpin`.
///
/// Ja tips satur `PhantomPinned`, tas pēc noklusējuma neieviesīs `Unpin`.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// `Copy` ieviešana primitīviem tipiem.
///
/// Īstenojumi, kurus nevar aprakstīt Rust, tiek ieviesti `traits::SelectionContext::copy_clone_conditions()` versijā `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Koplietotās atsauces var nokopēt, bet maināmās atsauces *nevar*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}