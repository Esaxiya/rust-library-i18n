//! Atomu veidi
//!
//! Atomu veidi nodrošina primitīvu koplietotās atmiņas komunikāciju starp pavedieniem un ir citu vienlaicīgu tipu veidojošie bloki.
//!
//! Šis modulis nosaka atsevišķu primitīvu tipu atomu versijas, ieskaitot [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`] utt.
//! Atomic veidi parāda darbības, kuras, pareizi lietojot, sinhronizē atjauninājumus starp pavedieniem.
//!
//! Katra metode ņem [`Ordering`], kas parāda atmiņas barjeras stiprumu šai operācijai.Šie pasūtījumi ir tādi paši kā [C++20 atomic orderings][1].Plašāku informāciju skatiet [nomicon][2].
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! Atomiskos mainīgos var droši koplietot starp pavedieniem (tie ievieš [`Sync`]), taču tie paši nenodrošina koplietošanas mehānismu un seko Rust [threading model](../../../std/thread/index.html#the-threading-model).
//!
//! Visizplatītākais veids, kā kopīgot atomu mainīgo, ir tā ievietošana [`Arc`][arc] (kopīgi ar atomu atsaucēm saskaitīts rādītājs).
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! Atomu tipus var uzglabāt statiskos mainīgos, inicializētus, izmantojot tādus nemainīgus inicializētājus kā [`AtomicBool::new`].Atmos statiku bieži izmanto slinkai globālai inicializēšanai.
//!
//! # Portability
//!
//! Visiem šī moduļa atomu tipiem ir garantija, ka tie būs [lock-free], ja tie ir pieejami.Tas nozīmē, ka viņi iekšēji neiegūst globālu muteksu.Nav garantēts, ka atomu veidi un darbības būs bez gaidīšanas.
//! Tas nozīmē, ka tādas darbības kā `fetch_or` var īstenot ar salīdzināšanas un mainīšanas cilpu.
//!
//! Atomu darbības var veikt instrukciju slānī ar lielāka izmēra atomiem.Piemēram, dažas platformas izmanto 4 baitu atomu instrukcijas, lai ieviestu `AtomicI8`.
//! Ņemiet vērā, ka šim atdarinājumam nevajadzētu ietekmēt koda pareizību, tas ir tikai jāzina.
//!
//! Šī moduļa atomu veidi var nebūt pieejami visās platformās.Šeit visi atomu tipi ir plaši pieejami, un parasti uz tiem var paļauties.Daži ievērojami izņēmumi ir:
//!
//! * PowerPC un MIPS platformām ar 32 bitu rādītājiem nav `AtomicU64` vai `AtomicI64` tipu.
//! * ARM tādas platformas kā `armv5te`, kas nav paredzētas Linux, nodrošina tikai operācijas `load` un `store` un neatbalsta (CAS) salīdzināšanas un mainīšanas operācijas, piemēram, `swap`, `fetch_add` utt.
//! Turklāt operētājsistēmā Linux šīs CAS darbības tiek īstenotas, izmantojot [operating system support], par ko var tikt piemērots izpildes sods.
//! * ARM mērķi ar `thumbv6m` nodrošina tikai operācijas `load` un `store` un neatbalsta (CAS) salīdzināšanas un mainīšanas operācijas, piemēram, `swap`, `fetch_add` utt.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! Ņemiet vērā, ka var tikt pievienotas platformas future, kurām arī nav atbalsta dažām atomu darbībām.Maksimāli pārnēsājamais kods vēlēsies būt uzmanīgs attiecībā uz to, kuri atomu tipi tiek izmantoti.
//! `AtomicUsize` un `AtomicIsize` parasti ir visvairāk pārnēsājamie, taču pat tad tie nav pieejami visur.
//! Lai uzzinātu, `std` bibliotēkai ir nepieciešami rādītāja lieluma atomi, lai gan `core` nav.
//!
//! Pašlaik jums būs jāizmanto `#[cfg(target_arch)]` galvenokārt, lai nosacīti apkopotu kodā ar atomu.Ir arī nestabils `#[cfg(target_has_atomic)]`, ko var stabilizēt future.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! Vienkāršs spinlock:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // Pagaidiet, līdz otra vītne atbrīvo slēdzeni
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! Uzturiet globālo dzīvo pavedienu skaitu:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// Būla tips, kuru var droši koplietot starp pavedieniem.
///
/// Šim tipam atmiņā ir tāds pats attēlojums kā [`bool`].
///
/// **Piezīme**: Šis tips ir pieejams tikai platformās, kas atbalsta atomu slodzes un `u8` krājumus.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// Izveido `AtomicBool`, kas inicializēts `false`.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// Sūtīšana ir netieši ieviesta vietnē AtomicBool.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// Neapstrādāta rādītāja tips, kuru var droši koplietot starp pavedieniem.
///
/// Šim tipam atmiņā ir tāds pats attēlojums kā `*mut T`.
///
/// **Piezīme**: Šis tips ir pieejams tikai platformās, kas atbalsta atomu slodzes un rādītāju krājumus.
/// Tās lielums ir atkarīgs no mērķa rādītāja lieluma.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// Izveido nulles vērtību `AtomicPtr<T>`.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// Atomu atmiņu pasūtījumi
///
/// Atmiņas secība norāda veidu, kā atomu darbības sinhronizē atmiņu.
/// Vājākajā [`Ordering::Relaxed`] tiek sinhronizēta tikai atmiņa, kurai tieši pieskāries darbība.
/// No otras puses, [`Ordering::SeqCst`] darbību veikala un ielādes pārī tiek sinhronizēta cita atmiņa, vienlaikus saglabājot šādu operāciju kopējo secību visos pavedienos.
///
///
/// Rust atmiņas secība ir [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order).
///
/// Plašāku informāciju skatiet [nomicon].
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// Nav pasūtīšanas ierobežojumu, tikai atomu darbības.
    ///
    /// Atbilst [`memory_order_relaxed`] C++ 20.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// Savienojot ar veikalu, visas iepriekšējās darbības tiek pasūtītas pirms jebkādas šīs vērtības ielādes ar [`Acquire`] (vai spēcīgāku) pasūtīšanu.
    ///
    /// Jo īpaši visi iepriekšējie rakstījumi kļūst redzami visiem pavedieniem, kas veic šīs vērtības [`Acquire`] (vai spēcīgāku) slodzi.
    ///
    /// Ievērojiet, ka šī pasūtīšana operācijai, kas apvieno slodzes un uzglabā, noved pie [`Relaxed`] slodzes operācijas!
    ///
    /// Šis pasūtījums attiecas tikai uz darbībām, kuras var veikt veikalā.
    ///
    /// Atbilst [`memory_order_release`] C++ 20.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// Ja ielādētā vērtība ir apvienota ar slodzi, tā tika ierakstīta ar veikala darbību ar [`Release`] (vai spēcīgāku) pasūtīšanu, tad visas turpmākās darbības tiek pasūtītas pēc šī krājuma.
    /// Jo īpaši visās turpmākajās slodzēs dati tiks ierakstīti pirms veikala.
    ///
    /// Ievērojiet, ka šī pasūtīšana operācijai, kas apvieno slodzes un krājumus, noved pie [`Relaxed`] veikala darbības!
    ///
    /// Šis pasūtījums attiecas tikai uz darbībām, kuras var veikt slodzi.
    ///
    /// Atbilst [`memory_order_acquire`] C++ 20.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// Ir gan [`Acquire`], gan [`Release`] ietekme kopā:
    /// Kravām tā izmanto [`Acquire`] pasūtīšanu.Veikaliem tā izmanto [`Release`] pasūtīšanu.
    ///
    /// Ievērojiet, ka `compare_and_swap` gadījumā ir iespējams, ka operācija neveic nevienu veikalu, un tāpēc tā ir tikai pasūtījusi [`Acquire`].
    ///
    /// Tomēr `AcqRel` nekad neveiks [`Relaxed`] piekļuves.
    ///
    /// Šis pasūtījums ir piemērots tikai darbībām, kurās tiek apvienotas gan kravas, gan krājumi.
    ///
    /// Atbilst [`memory_order_acq_rel`] C++ 20.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// Tāpat kā [`Iegūt`]/[`Atbrīvot`]/[`AcqRel`](attiecīgi operācijām ar ielādi, uzglabāšanu un ielādi ar veikalu) ar papildu garantiju, ka visi pavedieni redz visas secīgi konsekventās darbības vienā secībā .
    ///
    ///
    /// Atbilst [`memory_order_seq_cst`] C++ 20.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// [`AtomicBool`] inicializēts `false`.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// Izveido jaunu `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// Atgriež maināmu atsauci uz pamatā esošo [`bool`].
    ///
    /// Tas ir droši, jo maināmā atsauce garantē, ka neviens cits pavediens vienlaikus nepiekļūst atomu datiem.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // DROŠĪBA: mainīgā atsauce garantē unikālas īpašumtiesības.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// Iegūstiet atomu piekļuvi `&mut bool`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // DROŠĪBA: mainīgā atsauce garantē unikālas īpašumtiesības un
        // gan `bool`, gan `Self` izlīdzināšana ir 1.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// Patērē atomu un atgriež ietverto vērtību.
    ///
    /// Tas ir droši, jo `self` nodošana pēc vērtības garantē, ka neviens cits pavediens vienlaikus nepiekļūst atomu datiem.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// Ielādē vērtību no bool.
    ///
    /// `load` ņem argumentu [`Ordering`], kas apraksta šīs operācijas secību atmiņā.
    /// Iespējamās vērtības ir [`SeqCst`], [`Acquire`] un [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics, ja `order` ir [`Release`] vai [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // DROŠĪBA: jebkādas datu sacīkstes novērš atoma būtība un neapstrādāts
        // ievadītais rādītājs ir derīgs, jo mēs to saņēmām no atsauces.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// Saglabā vērtību bool.
    ///
    /// `store` ņem argumentu [`Ordering`], kas apraksta šīs operācijas secību atmiņā.
    /// Iespējamās vērtības ir [`SeqCst`], [`Release`] un [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics, ja `order` ir [`Acquire`] vai [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // DROŠĪBA: jebkādas datu sacīkstes novērš atoma būtība un neapstrādāts
        // ievadītais rādītājs ir derīgs, jo mēs to saņēmām no atsauces.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// Saglabā vērtību bool, atgriežot iepriekšējo vērtību.
    ///
    /// `swap` ņem argumentu [`Ordering`], kas apraksta šīs operācijas secību atmiņā.Ir iespējami visi pasūtīšanas režīmi.
    /// Ņemiet vērā, ka [`Acquire`] izmantošana padara šīs operācijas daļu [`Relaxed`], bet [`Release`] izmantošana padara kravas daļu [`Relaxed`].
    ///
    ///
    /// **Note:** Šī metode ir pieejama tikai platformās, kas atbalsta atomu operācijas ar `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // DROŠĪBA: datu sacīkstes novērš atomu būtība.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// Vērtība tiek saglabāta [`bool`], ja pašreizējā vērtība ir tāda pati kā `current`.
    ///
    /// Atgriešanās vērtība vienmēr ir iepriekšējā vērtība.Ja tas ir vienāds ar `current`, vērtība tika atjaunināta.
    ///
    /// `compare_and_swap` ņem arī argumentu [`Ordering`], kas apraksta šīs operācijas secību atmiņā.
    /// Ievērojiet, ka pat tad, ja izmantojat [`AcqRel`], darbība var neizdoties un tādējādi vienkārši veikt `Acquire` slodzi, bet tai nav `Release` semantikas.
    /// Izmantojot [`Acquire`], veikals šo darbību padara par [`Relaxed`], ja tā notiek, un, izmantojot [`Release`], kravas daļa kļūst par [`Relaxed`].
    ///
    /// **Note:** Šī metode ir pieejama tikai platformās, kas atbalsta atomu operācijas ar `u8`.
    ///
    /// # Migrēšana uz `compare_exchange` un `compare_exchange_weak`
    ///
    /// `compare_and_swap` ir ekvivalents `compare_exchange` ar šādu kartēšanu atmiņas pasūtījumiem:
    ///
    /// Oriģināls |Panākumi |Neveiksme
    /// -------- | ------- | -------
    /// Atslābināts |Atslābināts |Relaxed Acquire |Iegūt |Iegūt izlaidumuAtbrīvot |Atslābināts AcqRel |AcqRel |Iegūt SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` ir atļauts kļūdaini izgāzties pat tad, ja salīdzinājums izdodas, kas ļauj kompilatoram ģenerēt labāku montāžas kodu, kad salīdzināšanas un mijmaiņas process tiek izmantots lokā.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Vērtība tiek saglabāta [`bool`], ja pašreizējā vērtība ir tāda pati kā `current`.
    ///
    /// Atgriešanās vērtība ir rezultāts, kas norāda, vai jaunā vērtība ir uzrakstīta un satur iepriekšējo vērtību.
    /// Gūstot panākumus, šī vērtība tiek garantēta vienāda ar `current`.
    ///
    /// `compare_exchange` Lai aprakstītu šīs darbības atmiņas secību, ir nepieciešami divi [`Ordering`] argumenti.
    /// `success` apraksta nepieciešamo pasūtīšanu lasīšanas, modificēšanas un rakstīšanas operācijai, kas notiek, ja salīdzinājums ar `current` izdodas.
    /// `failure` apraksta nepieciešamo pasūtīšanu slodzes darbībai, kas notiek, kad neizdodas salīdzināt.
    /// Izmantojot veiksmīgu pasūtīšanu [`Acquire`], veikals ir daļa no šīs operācijas [`Relaxed`], un, lietojot [`Release`], veiksmīga slodze tiek veikta [`Relaxed`].
    ///
    /// Kļūmju pasūtīšana var būt tikai [`SeqCst`], [`Acquire`] vai [`Relaxed`], un tai jābūt līdzvērtīgai vai vājākai par veiksmīgu pasūtīšanu.
    ///
    /// **Note:** Šī metode ir pieejama tikai platformās, kas atbalsta atomu operācijas ar `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // DROŠĪBA: datu sacīkstes novērš atomu būtība.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Vērtība tiek saglabāta [`bool`], ja pašreizējā vērtība ir tāda pati kā `current`.
    ///
    /// Atšķirībā no [`AtomicBool::compare_exchange`], šai funkcijai ir atļauts kļūdaini izgāzties pat tad, ja salīdzinājums izdodas, kas dažās platformās var radīt efektīvāku kodu.
    ///
    /// Atgriešanās vērtība ir rezultāts, kas norāda, vai jaunā vērtība ir uzrakstīta un satur iepriekšējo vērtību.
    ///
    /// `compare_exchange_weak` Lai aprakstītu šīs darbības atmiņas secību, ir nepieciešami divi [`Ordering`] argumenti.
    /// `success` apraksta nepieciešamo pasūtīšanu lasīšanas, modificēšanas un rakstīšanas operācijai, kas notiek, ja salīdzinājums ar `current` izdodas.
    /// `failure` apraksta nepieciešamo pasūtīšanu slodzes darbībai, kas notiek, kad neizdodas salīdzināt.
    /// Izmantojot veiksmīgu pasūtīšanu [`Acquire`], veikals ir daļa no šīs operācijas [`Relaxed`], un, lietojot [`Release`], veiksmīga slodze tiek veikta [`Relaxed`].
    /// Kļūmju pasūtīšana var būt tikai [`SeqCst`], [`Acquire`] vai [`Relaxed`], un tai jābūt līdzvērtīgai vai vājākai par veiksmīgu pasūtīšanu.
    ///
    /// **Note:** Šī metode ir pieejama tikai platformās, kas atbalsta atomu operācijas ar `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // DROŠĪBA: datu sacīkstes novērš atomu būtība.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Loģiskais "and" ar būla vērtību.
    ///
    /// Veic loģisku "and" darbību ar pašreizējo vērtību un argumentu `val` un iestata jaunajai vērtībai rezultātu.
    ///
    /// Atgriež iepriekšējo vērtību.
    ///
    /// `fetch_and` ņem argumentu [`Ordering`], kas apraksta šīs operācijas secību atmiņā.Ir iespējami visi pasūtīšanas režīmi.
    /// Ņemiet vērā, ka [`Acquire`] izmantošana padara šīs operācijas daļu [`Relaxed`], bet [`Release`] izmantošana padara kravas daļu [`Relaxed`].
    ///
    ///
    /// **Note:** Šī metode ir pieejama tikai platformās, kas atbalsta atomu operācijas ar `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // DROŠĪBA: datu sacīkstes novērš atomu būtība.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// Loģiskais "nand" ar būla vērtību.
    ///
    /// Veic loģisku "nand" darbību ar pašreizējo vērtību un argumentu `val` un iestata jaunajai vērtībai rezultātu.
    ///
    /// Atgriež iepriekšējo vērtību.
    ///
    /// `fetch_nand` ņem argumentu [`Ordering`], kas apraksta šīs operācijas secību atmiņā.Ir iespējami visi pasūtīšanas režīmi.
    /// Ņemiet vērā, ka [`Acquire`] izmantošana padara šīs operācijas daļu [`Relaxed`], bet [`Release`] izmantošana padara kravas daļu [`Relaxed`].
    ///
    ///
    /// **Note:** Šī metode ir pieejama tikai platformās, kas atbalsta atomu operācijas ar `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // Mēs šeit nevaram izmantot atomic_nand, jo tā rezultātā bool var būt nederīga.
        // Tas notiek tāpēc, ka atomu darbība tiek veikta ar iekšēji 8 bitu veselu skaitli, kas iestatītu augšējos 7 bitus.
        //
        // Tāpēc mēs vienkārši izmantojam fetch_xor vai swap.
        if val {
            // ! (x&true)== !x Mums ir jāapgriež bool.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&false)==true Mums bool ir jāiestata kā true.
            //
            self.swap(true, order)
        }
    }

    /// Loģiskais "or" ar būla vērtību.
    ///
    /// Veic loģisku "or" darbību ar pašreizējo vērtību un argumentu `val` un iestata jaunajai vērtībai rezultātu.
    ///
    /// Atgriež iepriekšējo vērtību.
    ///
    /// `fetch_or` ņem argumentu [`Ordering`], kas apraksta šīs operācijas secību atmiņā.Ir iespējami visi pasūtīšanas režīmi.
    /// Ņemiet vērā, ka [`Acquire`] izmantošana padara šīs operācijas daļu [`Relaxed`], bet [`Release`] izmantošana padara kravas daļu [`Relaxed`].
    ///
    ///
    /// **Note:** Šī metode ir pieejama tikai platformās, kas atbalsta atomu operācijas ar `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // DROŠĪBA: datu sacīkstes novērš atomu būtība.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// Loģiskais "xor" ar būla vērtību.
    ///
    /// Veic loģisku "xor" darbību ar pašreizējo vērtību un argumentu `val` un iestata jaunajai vērtībai rezultātu.
    ///
    /// Atgriež iepriekšējo vērtību.
    ///
    /// `fetch_xor` ņem argumentu [`Ordering`], kas apraksta šīs operācijas secību atmiņā.Ir iespējami visi pasūtīšanas režīmi.
    /// Ņemiet vērā, ka [`Acquire`] izmantošana padara šīs operācijas daļu [`Relaxed`], bet [`Release`] izmantošana padara kravas daļu [`Relaxed`].
    ///
    ///
    /// **Note:** Šī metode ir pieejama tikai platformās, kas atbalsta atomu operācijas ar `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // DROŠĪBA: datu sacīkstes novērš atomu būtība.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// Atgriež maināmo rādītāju pamatā esošajam [`bool`].
    ///
    /// Veicot atomu lasīšanu un rakstīšanu uz iegūto veselu skaitli, tas var būt datu skrējiens.
    /// Šī metode galvenokārt ir noderīga FFI, kur funkcijas parakstā `&AtomicBool` vietā var izmantot `*mut bool`.
    ///
    /// `*mut` rādītāja atgriešana no kopīgas atsauces uz šo atomu ir droša, jo atomu tipi darbojas ar iekšējo mainīgumu.
    /// Visas atoma modifikācijas maina vērtību, izmantojot kopīgu atsauci, un to var izdarīt droši, kamēr tās izmanto atomu darbības.
    /// Lai izmantotu atgriezto neapstrādāto rādītāju, ir nepieciešams `unsafe` bloks, un tam joprojām ir jāievēro tas pats ierobežojums: darbībām ar to jābūt atomu.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// Iegūst vērtību un pielieto tai funkciju, kas atgriež neobligātu jaunu vērtību.Atgriež `Ok(previous_value)` vērtību `Ok(previous_value)`, ja funkcija atgrieza vērtību `Some(_)`, citādi `Err(previous_value)`.
    ///
    /// Note: Tas var izsaukt funkciju vairākas reizes, ja starplaikā vērtība ir mainīta no citiem pavedieniem, ja vien funkcija atgriež `Some(_)`, bet saglabātajai vērtībai funkcija tiks lietota tikai vienu reizi.
    ///
    ///
    /// `fetch_update` Lai aprakstītu šīs darbības atmiņas secību, ir nepieciešami divi [`Ordering`] argumenti.
    /// Pirmajā aprakstīts nepieciešamais pasūtījums, kad darbība beidzot ir veiksmīga, bet otrais-nepieciešamais pasūtījums slodzēm.
    /// Tie atbilst attiecīgi [`AtomicBool::compare_exchange`] veiksmes un neveiksmes pasūtījumiem.
    ///
    /// Lietojot [`Acquire`] kā veiksmīgu pasūtīšanu, veikals ir daļa no šīs operācijas [`Relaxed`], un, lietojot [`Release`], tiek veikta pēdējā veiksmīgā ielāde [`Relaxed`].
    /// (failed) slodzes pasūtīšana var būt tikai [`SeqCst`], [`Acquire`] vai [`Relaxed`], un tai jābūt līdzvērtīgai vai vājākai par veiksmīgu pasūtīšanu.
    ///
    /// **Note:** Šī metode ir pieejama tikai platformās, kas atbalsta atomu operācijas ar `u8`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// Izveido jaunu `AtomicPtr`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// Atgriež maināmu atsauci uz pamatā esošo rādītāju.
    ///
    /// Tas ir droši, jo maināmā atsauce garantē, ka neviens cits pavediens vienlaikus nepiekļūst atomu datiem.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// Iegūstiet atomu piekļuvi rādītājam.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - mainīgā atsauce garantē unikālas īpašumtiesības.
        //  - `*mut T` un `Self` izlīdzinājums ir vienāds visās platformās, kuras atbalsta rust, kā pārbaudīts iepriekš.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// Patērē atomu un atgriež ietverto vērtību.
    ///
    /// Tas ir droši, jo `self` nodošana pēc vērtības garantē, ka neviens cits pavediens vienlaikus nepiekļūst atomu datiem.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// Ielādē vērtību no rādītāja.
    ///
    /// `load` ņem argumentu [`Ordering`], kas apraksta šīs operācijas secību atmiņā.
    /// Iespējamās vērtības ir [`SeqCst`], [`Acquire`] un [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics, ja `order` ir [`Release`] vai [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // DROŠĪBA: datu sacīkstes novērš atomu būtība.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// Saglabā vērtību rādītājā.
    ///
    /// `store` ņem argumentu [`Ordering`], kas apraksta šīs operācijas secību atmiņā.
    /// Iespējamās vērtības ir [`SeqCst`], [`Release`] un [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics, ja `order` ir [`Acquire`] vai [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // DROŠĪBA: datu sacīkstes novērš atomu būtība.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// Vērtību saglabā rādītājā, atgriežot iepriekšējo vērtību.
    ///
    /// `swap` ņem argumentu [`Ordering`], kas apraksta šīs operācijas secību atmiņā.Ir iespējami visi pasūtīšanas režīmi.
    /// Ņemiet vērā, ka [`Acquire`] izmantošana padara šīs operācijas daļu [`Relaxed`], bet [`Release`] izmantošana padara kravas daļu [`Relaxed`].
    ///
    ///
    /// **Note:** Šī metode ir pieejama tikai platformās, kas atbalsta atomu darbības ar rādītājiem.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // DROŠĪBA: datu sacīkstes novērš atomu būtība.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// Vērtība tiek saglabāta rādītājā, ja pašreizējā vērtība ir vienāda ar vērtību `current`.
    ///
    /// Atgriešanās vērtība vienmēr ir iepriekšējā vērtība.Ja tas ir vienāds ar `current`, vērtība tika atjaunināta.
    ///
    /// `compare_and_swap` ņem arī argumentu [`Ordering`], kas apraksta šīs operācijas secību atmiņā.
    /// Ievērojiet, ka pat tad, ja izmantojat [`AcqRel`], darbība var neizdoties un tādējādi vienkārši veikt `Acquire` slodzi, bet tai nav `Release` semantikas.
    /// Izmantojot [`Acquire`], veikals šo darbību padara par [`Relaxed`], ja tā notiek, un, izmantojot [`Release`], kravas daļa kļūst par [`Relaxed`].
    ///
    /// **Note:** Šī metode ir pieejama tikai platformās, kas atbalsta atomu darbības ar rādītājiem.
    ///
    /// # Migrēšana uz `compare_exchange` un `compare_exchange_weak`
    ///
    /// `compare_and_swap` ir ekvivalents `compare_exchange` ar šādu kartēšanu atmiņas pasūtījumiem:
    ///
    /// Oriģināls |Panākumi |Neveiksme
    /// -------- | ------- | -------
    /// Atslābināts |Atslābināts |Relaxed Acquire |Iegūt |Iegūt izlaidumuAtbrīvot |Atslābināts AcqRel |AcqRel |Iegūt SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` ir atļauts kļūdaini izgāzties pat tad, ja salīdzinājums izdodas, kas ļauj kompilatoram ģenerēt labāku montāžas kodu, kad salīdzināšanas un mijmaiņas process tiek izmantots lokā.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Vērtība tiek saglabāta rādītājā, ja pašreizējā vērtība ir vienāda ar vērtību `current`.
    ///
    /// Atgriešanās vērtība ir rezultāts, kas norāda, vai jaunā vērtība ir uzrakstīta un satur iepriekšējo vērtību.
    /// Gūstot panākumus, šī vērtība tiek garantēta vienāda ar `current`.
    ///
    /// `compare_exchange` Lai aprakstītu šīs darbības atmiņas secību, ir nepieciešami divi [`Ordering`] argumenti.
    /// `success` apraksta nepieciešamo pasūtīšanu lasīšanas, modificēšanas un rakstīšanas operācijai, kas notiek, ja salīdzinājums ar `current` izdodas.
    /// `failure` apraksta nepieciešamo pasūtīšanu slodzes darbībai, kas notiek, kad neizdodas salīdzināt.
    /// Izmantojot veiksmīgu pasūtīšanu [`Acquire`], veikals ir daļa no šīs operācijas [`Relaxed`], un, lietojot [`Release`], veiksmīga slodze tiek veikta [`Relaxed`].
    ///
    /// Kļūmju pasūtīšana var būt tikai [`SeqCst`], [`Acquire`] vai [`Relaxed`], un tai jābūt līdzvērtīgai vai vājākai par veiksmīgu pasūtīšanu.
    ///
    /// **Note:** Šī metode ir pieejama tikai platformās, kas atbalsta atomu darbības ar rādītājiem.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // DROŠĪBA: datu sacīkstes novērš atomu būtība.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// Vērtība tiek saglabāta rādītājā, ja pašreizējā vērtība ir vienāda ar vērtību `current`.
    ///
    /// Atšķirībā no [`AtomicPtr::compare_exchange`], šai funkcijai ir atļauts kļūdaini izgāzties pat tad, ja salīdzinājums izdodas, kas dažās platformās var radīt efektīvāku kodu.
    ///
    /// Atgriešanās vērtība ir rezultāts, kas norāda, vai jaunā vērtība ir uzrakstīta un satur iepriekšējo vērtību.
    ///
    /// `compare_exchange_weak` Lai aprakstītu šīs darbības atmiņas secību, ir nepieciešami divi [`Ordering`] argumenti.
    /// `success` apraksta nepieciešamo pasūtīšanu lasīšanas, modificēšanas un rakstīšanas operācijai, kas notiek, ja salīdzinājums ar `current` izdodas.
    /// `failure` apraksta nepieciešamo pasūtīšanu slodzes darbībai, kas notiek, kad neizdodas salīdzināt.
    /// Izmantojot veiksmīgu pasūtīšanu [`Acquire`], veikals ir daļa no šīs operācijas [`Relaxed`], un, lietojot [`Release`], veiksmīga slodze tiek veikta [`Relaxed`].
    /// Kļūmju pasūtīšana var būt tikai [`SeqCst`], [`Acquire`] vai [`Relaxed`], un tai jābūt līdzvērtīgai vai vājākai par veiksmīgu pasūtīšanu.
    ///
    /// **Note:** Šī metode ir pieejama tikai platformās, kas atbalsta atomu darbības ar rādītājiem.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // DROŠĪBA: Šis raksturīgais elements nav drošs, jo tas darbojas ar neapstrādātu rādītāju
        // bet mēs noteikti zinām, ka rādītājs ir derīgs (mēs to tikko ieguvām no `UnsafeCell`, kas mums ir ar atsauci), un pati atoma darbība ļauj mums droši mutēt `UnsafeCell` saturu.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// Iegūst vērtību un pielieto tai funkciju, kas atgriež neobligātu jaunu vērtību.Atgriež `Ok(previous_value)` vērtību `Ok(previous_value)`, ja funkcija atgrieza vērtību `Some(_)`, citādi `Err(previous_value)`.
    ///
    /// Note: Tas var izsaukt funkciju vairākas reizes, ja starplaikā vērtība ir mainīta no citiem pavedieniem, ja vien funkcija atgriež `Some(_)`, bet saglabātajai vērtībai funkcija tiks lietota tikai vienu reizi.
    ///
    ///
    /// `fetch_update` Lai aprakstītu šīs darbības atmiņas secību, ir nepieciešami divi [`Ordering`] argumenti.
    /// Pirmajā aprakstīts nepieciešamais pasūtījums, kad darbība beidzot ir veiksmīga, bet otrais-nepieciešamais pasūtījums slodzēm.
    /// Tie atbilst attiecīgi [`AtomicPtr::compare_exchange`] veiksmes un neveiksmes pasūtījumiem.
    ///
    /// Lietojot [`Acquire`] kā veiksmīgu pasūtīšanu, veikals ir daļa no šīs operācijas [`Relaxed`], un, lietojot [`Release`], tiek veikta pēdējā veiksmīgā ielāde [`Relaxed`].
    /// (failed) slodzes pasūtīšana var būt tikai [`SeqCst`], [`Acquire`] vai [`Relaxed`], un tai jābūt līdzvērtīgai vai vājākai par veiksmīgu pasūtīšanu.
    ///
    /// **Note:** Šī metode ir pieejama tikai platformās, kas atbalsta atomu darbības ar rādītājiem.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// Pārvērš `bool` par `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // Šis makro dažās arhitektūrās tiek neizmantots.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// Vesels skaitlis, kuru var droši koplietot starp pavedieniem.
        ///
        /// Šim tipam ir tāds pats atmiņas attēlojums kā pamatā esošajam veselā skaitļa veidam ["
        ///
        #[doc = $s_int_type]
        /// `].
        /// Lai uzzinātu vairāk par atomu un atomu tipu atšķirībām, kā arī informāciju par šāda veida pārnesamību, lūdzu, skatiet [module-level documentation].
        ///
        ///
        /// **Note:** Šis tips ir pieejams tikai platformās, kas atbalsta atomu slodzes un kravas [
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// Atomu vesels skaitlis, kas inicializēts `0`.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // Sūtīšana ir netieši ieviesta.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// Izveido jaunu atomu veselu skaitli.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// Atgriež maināmu atsauci uz pamatā esošo veselu skaitli.
            ///
            /// Tas ir droši, jo maināmā atsauce garantē, ka neviens cits pavediens vienlaikus nepiekļūst atomu datiem.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// let mut some_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq! (daži_int, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - mainīgā atsauce garantē unikālas īpašumtiesības.
                //  - `$int_type` un `Self` izlīdzināšana ir tāda pati, kā solīja $cfg_align un pārbaudīja iepriekš.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// Patērē atomu un atgriež ietverto vērtību.
            ///
            /// Tas ir droši, jo `self` nodošana pēc vērtības garantē, ka neviens cits pavediens vienlaikus nepiekļūst atomu datiem.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// Ielādē vērtību no atomu veselā skaitļa.
            ///
            /// `load` ņem argumentu [`Ordering`], kas apraksta šīs operācijas secību atmiņā.
            /// Iespējamās vērtības ir [`SeqCst`], [`Acquire`] un [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics, ja `order` ir [`Release`] vai [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // DROŠĪBA: datu sacīkstes novērš atomu būtība.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// Saglabā vērtību atomu veselajā skaitlī.
            ///
            /// `store` ņem argumentu [`Ordering`], kas apraksta šīs operācijas secību atmiņā.
            ///  Iespējamās vērtības ir [`SeqCst`], [`Release`] un [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics, ja `order` ir [`Acquire`] vai [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // DROŠĪBA: datu sacīkstes novērš atomu būtība.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// Saglabā vērtību atomu veselajā skaitlī, atgriežot iepriekšējo vērtību.
            ///
            /// `swap` ņem argumentu [`Ordering`], kas apraksta šīs operācijas secību atmiņā.Ir iespējami visi pasūtīšanas režīmi.
            /// Ņemiet vērā, ka [`Acquire`] izmantošana padara šīs operācijas daļu [`Relaxed`], bet [`Release`] izmantošana padara kravas daļu [`Relaxed`].
            ///
            ///
            /// **Piezīme**: Šī metode ir pieejama tikai platformās, kurās tiek atbalstītas atomu darbības
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // DROŠĪBA: datu sacīkstes novērš atomu būtība.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// Ja pašreizējā vērtība ir vienāda ar vērtību `current`, tā tiek glabāta atomu veselajā skaitlī.
            ///
            /// Atgriešanās vērtība vienmēr ir iepriekšējā vērtība.Ja tas ir vienāds ar `current`, vērtība tika atjaunināta.
            ///
            /// `compare_and_swap` ņem arī argumentu [`Ordering`], kas apraksta šīs operācijas secību atmiņā.
            /// Ievērojiet, ka pat tad, ja izmantojat [`AcqRel`], darbība var neizdoties un tādējādi vienkārši veikt `Acquire` slodzi, bet tai nav `Release` semantikas.
            ///
            /// Izmantojot [`Acquire`], veikals šo darbību padara par [`Relaxed`], ja tā notiek, un, izmantojot [`Release`], kravas daļa kļūst par [`Relaxed`].
            ///
            /// **Piezīme**: Šī metode ir pieejama tikai platformās, kurās tiek atbalstītas atomu darbības
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Migrēšana uz `compare_exchange` un `compare_exchange_weak`
            ///
            /// `compare_and_swap` ir ekvivalents `compare_exchange` ar šādu kartēšanu atmiņas pasūtījumiem:
            ///
            /// Oriģināls |Panākumi |Neveiksme
            /// -------- | ------- | -------
            /// Atslābināts |Atslābināts |Relaxed Acquire |Iegūt |Iegūt izlaidumuAtbrīvot |Atslābināts AcqRel |AcqRel |Iegūt SeqCst |SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` ir atļauts kļūdaini izgāzties pat tad, ja salīdzinājums izdodas, kas ļauj kompilatoram ģenerēt labāku montāžas kodu, kad salīdzināšanas un mijmaiņas process tiek izmantots lokā.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// Ja pašreizējā vērtība ir vienāda ar vērtību `current`, tā tiek glabāta atomu veselajā skaitlī.
            ///
            /// Atgriešanās vērtība ir rezultāts, kas norāda, vai jaunā vērtība ir uzrakstīta un satur iepriekšējo vērtību.
            /// Gūstot panākumus, šī vērtība tiek garantēta vienāda ar `current`.
            ///
            /// `compare_exchange` Lai aprakstītu šīs darbības atmiņas secību, ir nepieciešami divi [`Ordering`] argumenti.
            /// `success` apraksta nepieciešamo pasūtīšanu lasīšanas, modificēšanas un rakstīšanas operācijai, kas notiek, ja salīdzinājums ar `current` izdodas.
            /// `failure` apraksta nepieciešamo pasūtīšanu slodzes darbībai, kas notiek, kad neizdodas salīdzināt.
            /// Izmantojot veiksmīgu pasūtīšanu [`Acquire`], veikals ir daļa no šīs operācijas [`Relaxed`], un, lietojot [`Release`], veiksmīga slodze tiek veikta [`Relaxed`].
            ///
            /// Kļūmju pasūtīšana var būt tikai [`SeqCst`], [`Acquire`] vai [`Relaxed`], un tai jābūt līdzvērtīgai vai vājākai par veiksmīgu pasūtīšanu.
            ///
            /// **Piezīme**: Šī metode ir pieejama tikai platformās, kurās tiek atbalstītas atomu darbības
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // DROŠĪBA: datu sacīkstes novērš atomu būtība.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// Ja pašreizējā vērtība ir vienāda ar vērtību `current`, tā tiek glabāta atomu veselajā skaitlī.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// šai funkcijai ir atļauts kļūdaini izgāzties pat tad, ja salīdzinājums izdodas, kā rezultātā dažās platformās var būt efektīvāks kods.
            /// Atgriešanās vērtība ir rezultāts, kas norāda, vai jaunā vērtība ir uzrakstīta un satur iepriekšējo vērtību.
            ///
            /// `compare_exchange_weak` Lai aprakstītu šīs darbības atmiņas secību, ir nepieciešami divi [`Ordering`] argumenti.
            /// `success` apraksta nepieciešamo pasūtīšanu lasīšanas, modificēšanas un rakstīšanas operācijai, kas notiek, ja salīdzinājums ar `current` izdodas.
            /// `failure` apraksta nepieciešamo pasūtīšanu slodzes darbībai, kas notiek, kad neizdodas salīdzināt.
            /// Izmantojot veiksmīgu pasūtīšanu [`Acquire`], veikals ir daļa no šīs operācijas [`Relaxed`], un, lietojot [`Release`], veiksmīga slodze tiek veikta [`Relaxed`].
            ///
            /// Kļūmju pasūtīšana var būt tikai [`SeqCst`], [`Acquire`] vai [`Relaxed`], un tai jābūt līdzvērtīgai vai vājākai par veiksmīgu pasūtīšanu.
            ///
            /// **Piezīme**: Šī metode ir pieejama tikai platformās, kurās tiek atbalstītas atomu darbības
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// let mut vecs= val.load(Ordering::Relaxed);
            /// cilpa {let new=old * 2;
            ///     spēles val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // DROŠĪBA: datu sacīkstes novērš atomu būtība.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// Pievieno pašreizējai vērtībai, atgriežot iepriekšējo vērtību.
            ///
            /// Šī darbība aptver pārplūdi.
            ///
            /// `fetch_add` ņem argumentu [`Ordering`], kas apraksta šīs operācijas secību atmiņā.Ir iespējami visi pasūtīšanas režīmi.
            /// Ņemiet vērā, ka [`Acquire`] izmantošana padara šīs operācijas daļu [`Relaxed`], bet [`Release`] izmantošana padara kravas daļu [`Relaxed`].
            ///
            ///
            /// **Piezīme**: Šī metode ir pieejama tikai platformās, kurās tiek atbalstītas atomu darbības
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // DROŠĪBA: datu sacīkstes novērš atomu būtība.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// Atņem no pašreizējās vērtības, atgriežot iepriekšējo vērtību.
            ///
            /// Šī darbība aptver pārplūdi.
            ///
            /// `fetch_sub` ņem argumentu [`Ordering`], kas apraksta šīs operācijas secību atmiņā.Ir iespējami visi pasūtīšanas režīmi.
            /// Ņemiet vērā, ka [`Acquire`] izmantošana padara šīs operācijas daļu [`Relaxed`], bet [`Release`] izmantošana padara kravas daļu [`Relaxed`].
            ///
            ///
            /// **Piezīme**: Šī metode ir pieejama tikai platformās, kurās tiek atbalstītas atomu darbības
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // DROŠĪBA: datu sacīkstes novērš atomu būtība.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// Bitu kustībā "and" ar pašreizējo vērtību.
            ///
            /// Veic bitute "and" darbību ar pašreizējo vērtību un argumentu `val` un iestata jaunajai vērtībai rezultātu.
            ///
            /// Atgriež iepriekšējo vērtību.
            ///
            /// `fetch_and` ņem argumentu [`Ordering`], kas apraksta šīs operācijas secību atmiņā.Ir iespējami visi pasūtīšanas režīmi.
            /// Ņemiet vērā, ka [`Acquire`] izmantošana padara šīs operācijas daļu [`Relaxed`], bet [`Release`] izmantošana padara kravas daļu [`Relaxed`].
            ///
            ///
            /// **Piezīme**: Šī metode ir pieejama tikai platformās, kurās tiek atbalstītas atomu darbības
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // DROŠĪBA: datu sacīkstes novērš atomu būtība.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// Bitu kustībā "nand" ar pašreizējo vērtību.
            ///
            /// Veic bitute "nand" darbību ar pašreizējo vērtību un argumentu `val` un iestata jaunajai vērtībai rezultātu.
            ///
            /// Atgriež iepriekšējo vērtību.
            ///
            /// `fetch_nand` ņem argumentu [`Ordering`], kas apraksta šīs operācijas secību atmiņā.Ir iespējami visi pasūtīšanas režīmi.
            /// Ņemiet vērā, ka [`Acquire`] izmantošana padara šīs operācijas daļu [`Relaxed`], bet [`Release`] izmantošana padara kravas daļu [`Relaxed`].
            ///
            ///
            /// **Piezīme**: Šī metode ir pieejama tikai platformās, kurās tiek atbalstītas atomu darbības
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13&0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // DROŠĪBA: datu sacīkstes novērš atomu būtība.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// Bitu kustībā "or" ar pašreizējo vērtību.
            ///
            /// Veic bitute "or" darbību ar pašreizējo vērtību un argumentu `val` un iestata jaunajai vērtībai rezultātu.
            ///
            /// Atgriež iepriekšējo vērtību.
            ///
            /// `fetch_or` ņem argumentu [`Ordering`], kas apraksta šīs operācijas secību atmiņā.Ir iespējami visi pasūtīšanas režīmi.
            /// Ņemiet vērā, ka [`Acquire`] izmantošana padara šīs operācijas daļu [`Relaxed`], bet [`Release`] izmantošana padara kravas daļu [`Relaxed`].
            ///
            ///
            /// **Piezīme**: Šī metode ir pieejama tikai platformās, kurās tiek atbalstītas atomu darbības
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // DROŠĪBA: datu sacīkstes novērš atomu būtība.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// Bitu kustībā "xor" ar pašreizējo vērtību.
            ///
            /// Veic bitute "xor" darbību ar pašreizējo vērtību un argumentu `val` un iestata jaunajai vērtībai rezultātu.
            ///
            /// Atgriež iepriekšējo vērtību.
            ///
            /// `fetch_xor` ņem argumentu [`Ordering`], kas apraksta šīs operācijas secību atmiņā.Ir iespējami visi pasūtīšanas režīmi.
            /// Ņemiet vērā, ka [`Acquire`] izmantošana padara šīs operācijas daļu [`Relaxed`], bet [`Release`] izmantošana padara kravas daļu [`Relaxed`].
            ///
            ///
            /// **Piezīme**: Šī metode ir pieejama tikai platformās, kurās tiek atbalstītas atomu darbības
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // DROŠĪBA: datu sacīkstes novērš atomu būtība.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// Iegūst vērtību un pielieto tai funkciju, kas atgriež neobligātu jaunu vērtību.Atgriež `Ok(previous_value)` vērtību `Ok(previous_value)`, ja funkcija atgrieza vērtību `Some(_)`, citādi `Err(previous_value)`.
            ///
            /// Note: Tas var izsaukt funkciju vairākas reizes, ja starplaikā vērtība ir mainīta no citiem pavedieniem, ja vien funkcija atgriež `Some(_)`, bet saglabātajai vērtībai funkcija tiks lietota tikai vienu reizi.
            ///
            ///
            /// `fetch_update` Lai aprakstītu šīs darbības atmiņas secību, ir nepieciešami divi [`Ordering`] argumenti.
            /// Pirmajā aprakstīts nepieciešamais pasūtījums, kad darbība beidzot ir veiksmīga, bet otrais-nepieciešamais pasūtījums slodzēm.Tie atbilst pasūtījuma panākumiem un neveiksmēm
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// Lietojot [`Acquire`] kā veiksmīgu pasūtīšanu, veikals ir daļa no šīs operācijas [`Relaxed`], un, lietojot [`Release`], tiek veikta pēdējā veiksmīgā ielāde [`Relaxed`].
            /// (failed) slodzes pasūtīšana var būt tikai [`SeqCst`], [`Acquire`] vai [`Relaxed`], un tai jābūt līdzvērtīgai vai vājākai par veiksmīgu pasūtīšanu.
            ///
            /// **Piezīme**: Šī metode ir pieejama tikai platformās, kurās tiek atbalstītas atomu darbības
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (Pasūtīšana: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// assert_eq! (x.fetch_update (Pasūtīšana: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// Maksimums ar pašreizējo vērtību.
            ///
            /// Atrod maksimālo pašreizējo vērtību un argumentu `val` un iestata rezultātam jauno vērtību.
            ///
            /// Atgriež iepriekšējo vērtību.
            ///
            /// `fetch_max` ņem argumentu [`Ordering`], kas apraksta šīs operācijas secību atmiņā.Ir iespējami visi pasūtīšanas režīmi.
            /// Ņemiet vērā, ka [`Acquire`] izmantošana padara šīs operācijas daļu [`Relaxed`], bet [`Release`] izmantošana padara kravas daļu [`Relaxed`].
            ///
            ///
            /// **Piezīme**: Šī metode ir pieejama tikai platformās, kurās tiek atbalstītas atomu darbības
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// let bārs=42;
            /// ļaujiet max_foo=foo.fetch_max (josla, Ordering::SeqCst).max(bar);
            /// apgalvo! (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // DROŠĪBA: datu sacīkstes novērš atomu būtība.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// Minimālais ar pašreizējo vērtību.
            ///
            /// Atrod pašreizējās vērtības minimumu un argumentu `val` un iestata rezultātam jauno vērtību.
            ///
            /// Atgriež iepriekšējo vērtību.
            ///
            /// `fetch_min` ņem argumentu [`Ordering`], kas apraksta šīs operācijas secību atmiņā.Ir iespējami visi pasūtīšanas režīmi.
            /// Ņemiet vērā, ka [`Acquire`] izmantošana padara šīs operācijas daļu [`Relaxed`], bet [`Release`] izmantošana padara kravas daļu [`Relaxed`].
            ///
            ///
            /// **Piezīme**: Šī metode ir pieejama tikai platformās, kurās tiek atbalstītas atomu darbības
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// let bārs=12;
            /// ļaujiet min_foo=foo.fetch_min (josla, Ordering::SeqCst).min(bar);
            /// assert_eq! (min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // DROŠĪBA: datu sacīkstes novērš atomu būtība.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// Atgriež maināmo rādītāju pamatā esošajam skaitlim.
            ///
            /// Veicot atomu lasīšanu un rakstīšanu uz iegūto veselu skaitli, tas var būt datu skrējiens.
            /// Šī metode galvenokārt ir noderīga FFI, kur var izmantot funkcijas parakstu
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// `*mut` rādītāja atgriešana no kopīgas atsauces uz šo atomu ir droša, jo atomu tipi darbojas ar iekšējo mainīgumu.
            /// Visas atoma modifikācijas maina vērtību, izmantojot kopīgu atsauci, un to var izdarīt droši, kamēr tās izmanto atomu darbības.
            /// Lai izmantotu atgriezto neapstrādāto rādītāju, ir nepieciešams `unsafe` bloks, un tam joprojām ir jāievēro tas pats ierobežojums: darbībām ar to jābūt atomu.
            ///
            ///
            /// # Examples
            ///
            /// "ignorēt (extern-declaration)
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// extern "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // DROŠĪBA: Droša, kamēr `my_atomic_op` ir atoms.
            /// nedrošs {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // DROŠĪBA: zvanītājam jāievēro `atomic_store` drošības līgums.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // DROŠĪBA: zvanītājam jāievēro `atomic_load` drošības līgums.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // DROŠĪBA: zvanītājam jāievēro `atomic_swap` drošības līgums.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// Atgriež iepriekšējo vērtību (piemēram, __sync_fetch_and_add).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // DROŠĪBA: zvanītājam jāievēro `atomic_add` drošības līgums.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// Atgriež iepriekšējo vērtību (piemēram, __sync_fetch_and_sub).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // DROŠĪBA: zvanītājam jāievēro `atomic_sub` drošības līgums.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // DROŠĪBA: zvanītājam jāievēro `atomic_compare_exchange` drošības līgums.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // DROŠĪBA: zvanītājam jāievēro `atomic_compare_exchange_weak` drošības līgums.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // DROŠĪBA: zvanītājam jāievēro `atomic_and` drošības līgums
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // DROŠĪBA: zvanītājam jāievēro `atomic_nand` drošības līgums
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // DROŠĪBA: zvanītājam jāievēro `atomic_or` drošības līgums
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // DROŠĪBA: zvanītājam jāievēro `atomic_xor` drošības līgums
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// atgriež maksimālo vērtību (parakstīts salīdzinājums)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // DROŠĪBA: zvanītājam jāievēro `atomic_max` drošības līgums
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// atgriež minimālo vērtību (parakstīts salīdzinājums)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // DROŠĪBA: zvanītājam jāievēro `atomic_min` drošības līgums
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// atgriež maksimālo vērtību (neparakstīts salīdzinājums)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // DROŠĪBA: zvanītājam jāievēro `atomic_umax` drošības līgums
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// atgriež minimālo vērtību (neparakstīts salīdzinājums)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // DROŠĪBA: zvanītājam jāievēro `atomic_umin` drošības līgums
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// Atomu žogs.
///
/// Atkarībā no norādītā pasūtījuma žogs neļauj kompilatoram un CPU pārkārtot noteiktus atmiņas darbību veidus ap to.
/// Tas rada sinhronizāciju ar attiecībām starp to un atomu darbībām vai žogiem citos pavedienos.
///
/// Žogs 'A', kuram ir (vismaz) [`Release`] semantikas secība, sinhronizējas ar žogu 'B' ar (vismaz) [`Acquire`] semantiku, ja un tikai tad, ja pastāv operācijas X un Y, kuras abas darbojas ar kādu atomu objektu 'M' tā, ka A tiek sekvencēta iepriekš X, Y tiek sinhronizēts, pirms B un Y novēro izmaiņas uz M.
/// Tas nodrošina atkarību starp A un B pirms notiek.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// Atomu darbības ar [`Release`] vai [`Acquire`] semantiku var arī sinhronizēt ar žogu.
///
/// Žogs, kuram ir [`SeqCst`] pasūtījums, papildus [`Acquire`] un [`Release`] semantikai, piedalās arī citu [`SeqCst`] darbību un/vai žogu globālajā programmu secībā.
///
/// Pieņem [`Acquire`], [`Release`], [`AcqRel`] un [`SeqCst`] pasūtījumus.
///
/// # Panics
///
/// Panics, ja `order` ir [`Relaxed`].
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // Abpusējas izslēgšanas primitīvs, kura pamatā ir spinlock.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // Pagaidiet, līdz vecā vērtība ir `false`.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // Šis žogs sinhronizējas ar `unlock` veikalu.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // DROŠĪBA: atomu žoga izmantošana ir droša.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// Kompilatora atmiņas žogs.
///
/// `compiler_fence` neizlaiž nevienu mašīnkodu, bet ierobežo tos atmiņas veidus, kurus atļauts veikt kompilatora atkārtotai pasūtīšanai.Konkrēti, atkarībā no norādītās [`Ordering`] semantikas, kompilatoram var tikt liegts pārvietot lasījumus vai rakstus no pirms vai pēc zvana uz `compiler_fence` zvana otru pusi.Ņemiet vērā, ka tas **neliedz** aparatūrai * veikt šādu atkārtotu pasūtīšanu.
///
/// Vienu pavedienu izpildes kontekstā tā nav problēma, taču, ja citi pavedieni var vienlaikus modificēt atmiņu, ir nepieciešami spēcīgāki sinhronizācijas primitīvi, piemēram, [`fence`].
///
/// Pārkārtošana, kuru novērš atšķirīgā pasūtīšanas semantika, ir:
///
///  - izmantojot [`SeqCst`], šajā punktā nav atļauts atkārtoti lasīt un rakstīt.
///  - Izmantojot [`Release`], iepriekšējās lasīšanas un rakstīšanas nevar pārvietot pāri nākamajiem ierakstiem.
///  - Izmantojot [`Acquire`], turpmākās lasīšanas un rakstīšanas reizes nevar pārsniegt iepriekšējās lasīšanas.
///  - ar [`AcqRel`] tiek izpildīti abi iepriekš minētie noteikumi.
///
/// `compiler_fence` parasti ir noderīgs tikai, lai novērstu pavedienu sacīkstes *ar sevi*.Tas ir, ja dotais pavediens izpilda vienu koda daļu un pēc tam tiek pārtraukts un sāk izpildīt kodu citur (kamēr tas joprojām atrodas tajā pašā pavedienā un konceptuāli joprojām atrodas tajā pašā kodolā).Tradicionālajās programmās tas var notikt tikai tad, kad ir reģistrēts signāla apstrādātājs.
/// Zemāka līmeņa kodā šādas situācijas var rasties arī, rīkojoties ar pārtraukumiem, ieviešot zaļos pavedienus ar pirmpirkumu utt.
/// Ziņkārīgie lasītāji tiek aicināti izlasīt Linux kodola diskusiju par [memory barriers].
///
/// # Panics
///
/// Panics, ja `order` ir [`Relaxed`].
///
/// # Examples
///
/// Bez `compiler_fence` `assert_eq!` sekojošajā kodā * netiek garantēts, ka tas izdosies, neskatoties uz to, ka viss notiek vienā pavedienā.
/// Lai saprastu, kāpēc, atcerieties, ka kompilators var brīvi nomainīt veikalus uz `IMPORTANT_VARIABLE` un `IS_READ`, jo tie abi ir `Ordering::Relaxed`.Ja tas tā notiek un signāla apstrādātājs tiek izsaukts uzreiz pēc `IS_READY` atjaunināšanas, signāla apstrādātājs redzēs `IS_READY=1`, bet `IMPORTANT_VARIABLE=0`.
/// Izmantojot `compiler_fence`, šī situācija tiek novērsta.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // novērstu iepriekšējo rakstu pārvietošanos ārpus šī punkta
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // DROŠĪBA: atomu žoga izmantošana ir droša.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// Norāda procesoram, ka tas atrodas aizņemtas gaidīšanas griešanās cilpas iekšpusē ("spin lock").
///
/// Šī funkcija ir novecojusi par labu [`hint::spin_loop`].
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}