//! Sastādītāja būtība.
//!
//! Atbilstošās definīcijas ir `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! Atbilstošās konst realizācijas ir `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # Const būtība
//!
//! Note: jebkuras izmaiņas pastāvības raksturīgumā jāapspriež ar valodas komandu.
//! Tas ietver izmaiņas konstantes stabilitātē.
//!
//! Lai padarītu iekšējo izmantojamu kompilēšanas laikā, ir nepieciešams kopēt ieviešanu no <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> uz `compiler/rustc_mir/src/interpret/intrinsics.rs` un pievienot iekšējo `#[rustc_const_unstable(feature = "foo", issue = "01234")]`.
//!
//!
//! Ja domājams, ka iekšējo līdzekli izmanto no `const fn` ar `rustc_const_stable` atribūtu, iekšējam atribūtam jābūt arī `rustc_const_stable`.
//! Šādas izmaiņas nevajadzētu veikt bez konsultēšanās ar T-lang, jo tā valodā iezīmē funkciju, kuru nevar atkārtot lietotāja kodā bez kompilatora atbalsta.
//!
//! # Volatiles
//!
//! Nepastāvīgie iekšējie elementi nodrošina darbības, kas paredzētas darbībai uz I/O atmiņu, kuras kompilators garantē, ka tās nepārkārtos citos gaistošajos iekšējos elementos.Skatiet LLVM dokumentāciju vietnē [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Atomu būtība nodrošina kopīgas atomu darbības ar mašīnvārdiem, ar vairākiem iespējamiem atmiņas pasūtījumiem.Viņi pakļaujas tādai pašai semantikai kā C++ 11.Skatiet LLVM dokumentāciju vietnē [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! Ātra atmiņas pasūtīšanas atsvaidzināšana:
//!
//! * Iegūstiet šķērsli slēdzenes iegūšanai.Turpmākie lasījumi un rakstīšana notiek pēc barjeras.
//! * Atbrīvošana, barjera slēdzenes atbrīvošanai.Iepriekšējie lasījumi un rakstīšana notiek pirms barjeras.
//! * Tiek garantēts, ka secīgi konsekventas, secīgi konsekventas darbības notiks secīgi.Šis ir standarta režīms darbam ar atomu tipiem un ir līdzvērtīgs Java `volatile`.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Šis imports tiek izmantots, lai vienkāršotu iekšējās dokumenta saites
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // DROŠĪBA: skatiet `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, šie raksturīgie faktori izmanto neapstrādātas norādes, jo tie mutē aizstājvārdu atmiņu, kas nav derīga ne `&`, ne `&mut`.
    //

    /// Saglabā vērtību, ja pašreizējā vērtība ir tāda pati kā `old`.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `compare_exchange` metodi, nododot [`Ordering::SeqCst`] kā parametrus `success` un `failure`.
    ///
    /// Piemēram, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Saglabā vērtību, ja pašreizējā vērtība ir tāda pati kā `old`.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `compare_exchange` metodi, nododot [`Ordering::Acquire`] kā parametrus `success` un `failure`.
    ///
    /// Piemēram, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Saglabā vērtību, ja pašreizējā vērtība ir tāda pati kā `old`.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `compare_exchange` metodi, [`Ordering::Release`] kā `success` un [`Ordering::Relaxed`] kā `failure` parametrus.
    /// Piemēram, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Saglabā vērtību, ja pašreizējā vērtība ir tāda pati kā `old`.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `compare_exchange` metodi, [`Ordering::AcqRel`] kā `success` un [`Ordering::Acquire`] kā `failure` parametrus.
    /// Piemēram, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Saglabā vērtību, ja pašreizējā vērtība ir tāda pati kā `old`.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `compare_exchange` metodi, nododot [`Ordering::Relaxed`] kā parametrus `success` un `failure`.
    ///
    /// Piemēram, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Saglabā vērtību, ja pašreizējā vērtība ir tāda pati kā `old`.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `compare_exchange` metodi, [`Ordering::SeqCst`] kā `success` un [`Ordering::Relaxed`] kā `failure` parametrus.
    /// Piemēram, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Saglabā vērtību, ja pašreizējā vērtība ir tāda pati kā `old`.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `compare_exchange` metodi, [`Ordering::SeqCst`] kā `success` un [`Ordering::Acquire`] kā `failure` parametrus.
    /// Piemēram, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Saglabā vērtību, ja pašreizējā vērtība ir tāda pati kā `old`.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `compare_exchange` metodi, [`Ordering::Acquire`] kā `success` un [`Ordering::Relaxed`] kā `failure` parametrus.
    /// Piemēram, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Saglabā vērtību, ja pašreizējā vērtība ir tāda pati kā `old`.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `compare_exchange` metodi, [`Ordering::AcqRel`] kā `success` un [`Ordering::Relaxed`] kā `failure` parametrus.
    /// Piemēram, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Saglabā vērtību, ja pašreizējā vērtība ir tāda pati kā `old`.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `compare_exchange_weak` metodi, nododot [`Ordering::SeqCst`] kā parametrus `success` un `failure`.
    ///
    /// Piemēram, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Saglabā vērtību, ja pašreizējā vērtība ir tāda pati kā `old`.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `compare_exchange_weak` metodi, nododot [`Ordering::Acquire`] kā parametrus `success` un `failure`.
    ///
    /// Piemēram, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Saglabā vērtību, ja pašreizējā vērtība ir tāda pati kā `old`.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `compare_exchange_weak` metodi, [`Ordering::Release`] kā `success` un [`Ordering::Relaxed`] kā `failure` parametrus.
    /// Piemēram, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Saglabā vērtību, ja pašreizējā vērtība ir tāda pati kā `old`.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `compare_exchange_weak` metodi, [`Ordering::AcqRel`] kā `success` un [`Ordering::Acquire`] kā `failure` parametrus.
    /// Piemēram, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Saglabā vērtību, ja pašreizējā vērtība ir tāda pati kā `old`.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `compare_exchange_weak` metodi, nododot [`Ordering::Relaxed`] kā parametrus `success` un `failure`.
    ///
    /// Piemēram, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Saglabā vērtību, ja pašreizējā vērtība ir tāda pati kā `old`.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `compare_exchange_weak` metodi, [`Ordering::SeqCst`] kā `success` un [`Ordering::Relaxed`] kā `failure` parametrus.
    /// Piemēram, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Saglabā vērtību, ja pašreizējā vērtība ir tāda pati kā `old`.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `compare_exchange_weak` metodi, [`Ordering::SeqCst`] kā `success` un [`Ordering::Acquire`] kā `failure` parametrus.
    /// Piemēram, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Saglabā vērtību, ja pašreizējā vērtība ir tāda pati kā `old`.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `compare_exchange_weak` metodi, [`Ordering::Acquire`] kā `success` un [`Ordering::Relaxed`] kā `failure` parametrus.
    /// Piemēram, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Saglabā vērtību, ja pašreizējā vērtība ir tāda pati kā `old`.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `compare_exchange_weak` metodi, [`Ordering::AcqRel`] kā `success` un [`Ordering::Relaxed`] kā `failure` parametrus.
    /// Piemēram, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Ielādē rādītāja pašreizējo vērtību.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `load` metodi, [`Ordering::SeqCst`] nododot kā `order`.
    /// Piemēram, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Ielādē rādītāja pašreizējo vērtību.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `load` metodi, [`Ordering::Acquire`] nododot kā `order`.
    /// Piemēram, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Ielādē rādītāja pašreizējo vērtību.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `load` metodi, [`Ordering::Relaxed`] nododot kā `order`.
    /// Piemēram, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Saglabā vērtību norādītajā atmiņas vietā.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `store` metodi, [`Ordering::SeqCst`] nododot kā `order`.
    /// Piemēram, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Saglabā vērtību norādītajā atmiņas vietā.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `store` metodi, [`Ordering::Release`] nododot kā `order`.
    /// Piemēram, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Saglabā vērtību norādītajā atmiņas vietā.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `store` metodi, [`Ordering::Relaxed`] nododot kā `order`.
    /// Piemēram, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Saglabā vērtību norādītajā atmiņas vietā, atgriežot veco vērtību.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `swap` metodi, [`Ordering::SeqCst`] nododot kā `order`.
    /// Piemēram, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Saglabā vērtību norādītajā atmiņas vietā, atgriežot veco vērtību.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `swap` metodi, [`Ordering::Acquire`] nododot kā `order`.
    /// Piemēram, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Saglabā vērtību norādītajā atmiņas vietā, atgriežot veco vērtību.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `swap` metodi, [`Ordering::Release`] nododot kā `order`.
    /// Piemēram, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Saglabā vērtību norādītajā atmiņas vietā, atgriežot veco vērtību.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `swap` metodi, [`Ordering::AcqRel`] nododot kā `order`.
    /// Piemēram, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Saglabā vērtību norādītajā atmiņas vietā, atgriežot veco vērtību.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `swap` metodi, [`Ordering::Relaxed`] nododot kā `order`.
    /// Piemēram, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Pievieno pašreizējai vērtībai, atgriežot iepriekšējo vērtību.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `fetch_add` metodi, [`Ordering::SeqCst`] nododot kā `order`.
    /// Piemēram, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pievieno pašreizējai vērtībai, atgriežot iepriekšējo vērtību.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `fetch_add` metodi, [`Ordering::Acquire`] nododot kā `order`.
    /// Piemēram, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pievieno pašreizējai vērtībai, atgriežot iepriekšējo vērtību.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `fetch_add` metodi, [`Ordering::Release`] nododot kā `order`.
    /// Piemēram, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pievieno pašreizējai vērtībai, atgriežot iepriekšējo vērtību.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `fetch_add` metodi, [`Ordering::AcqRel`] nododot kā `order`.
    /// Piemēram, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pievieno pašreizējai vērtībai, atgriežot iepriekšējo vērtību.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `fetch_add` metodi, [`Ordering::Relaxed`] nododot kā `order`.
    /// Piemēram, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Atņemiet no pašreizējās vērtības, atgriežot iepriekšējo vērtību.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `fetch_sub` metodi, [`Ordering::SeqCst`] nododot kā `order`.
    /// Piemēram, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Atņemiet no pašreizējās vērtības, atgriežot iepriekšējo vērtību.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `fetch_sub` metodi, [`Ordering::Acquire`] nododot kā `order`.
    /// Piemēram, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Atņemiet no pašreizējās vērtības, atgriežot iepriekšējo vērtību.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `fetch_sub` metodi, [`Ordering::Release`] nododot kā `order`.
    /// Piemēram, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Atņemiet no pašreizējās vērtības, atgriežot iepriekšējo vērtību.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `fetch_sub` metodi, [`Ordering::AcqRel`] nododot kā `order`.
    /// Piemēram, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Atņemiet no pašreizējās vērtības, atgriežot iepriekšējo vērtību.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `fetch_sub` metodi, [`Ordering::Relaxed`] nododot kā `order`.
    /// Piemēram, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitu un ar pašreizējo vērtību, atgriežot iepriekšējo vērtību.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `fetch_and` metodi, [`Ordering::SeqCst`] nododot kā `order`.
    /// Piemēram, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitu un ar pašreizējo vērtību, atgriežot iepriekšējo vērtību.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `fetch_and` metodi, [`Ordering::Acquire`] nododot kā `order`.
    /// Piemēram, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitu un ar pašreizējo vērtību, atgriežot iepriekšējo vērtību.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `fetch_and` metodi, [`Ordering::Release`] nododot kā `order`.
    /// Piemēram, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitu un ar pašreizējo vērtību, atgriežot iepriekšējo vērtību.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `fetch_and` metodi, [`Ordering::AcqRel`] nododot kā `order`.
    /// Piemēram, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitu un ar pašreizējo vērtību, atgriežot iepriekšējo vērtību.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `fetch_and` metodi, [`Ordering::Relaxed`] nododot kā `order`.
    /// Piemēram, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise nand ar pašreizējo vērtību, atgriežot iepriekšējo vērtību.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`AtomicBool`] tipam, izmantojot `fetch_nand` metodi, [`Ordering::SeqCst`] nododot kā `order`.
    /// Piemēram, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand ar pašreizējo vērtību, atgriežot iepriekšējo vērtību.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`AtomicBool`] tipam, izmantojot `fetch_nand` metodi, [`Ordering::Acquire`] nododot kā `order`.
    /// Piemēram, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand ar pašreizējo vērtību, atgriežot iepriekšējo vērtību.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`AtomicBool`] tipam, izmantojot `fetch_nand` metodi, [`Ordering::Release`] nododot kā `order`.
    /// Piemēram, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand ar pašreizējo vērtību, atgriežot iepriekšējo vērtību.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`AtomicBool`] tipam, izmantojot `fetch_nand` metodi, [`Ordering::AcqRel`] nododot kā `order`.
    /// Piemēram, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand ar pašreizējo vērtību, atgriežot iepriekšējo vērtību.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`AtomicBool`] tipam, izmantojot `fetch_nand` metodi, [`Ordering::Relaxed`] nododot kā `order`.
    /// Piemēram, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitu vai ar pašreizējo vērtību, atgriežot iepriekšējo vērtību.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `fetch_or` metodi, [`Ordering::SeqCst`] nododot kā `order`.
    /// Piemēram, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitu vai ar pašreizējo vērtību, atgriežot iepriekšējo vērtību.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `fetch_or` metodi, [`Ordering::Acquire`] nododot kā `order`.
    /// Piemēram, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitu vai ar pašreizējo vērtību, atgriežot iepriekšējo vērtību.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `fetch_or` metodi, [`Ordering::Release`] nododot kā `order`.
    /// Piemēram, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitu vai ar pašreizējo vērtību, atgriežot iepriekšējo vērtību.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `fetch_or` metodi, [`Ordering::AcqRel`] nododot kā `order`.
    /// Piemēram, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitu vai ar pašreizējo vērtību, atgriežot iepriekšējo vērtību.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `fetch_or` metodi, [`Ordering::Relaxed`] nododot kā `order`.
    /// Piemēram, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitu virzienā xor ar pašreizējo vērtību, atgriežot iepriekšējo vērtību.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `fetch_xor` metodi, [`Ordering::SeqCst`] nododot kā `order`.
    /// Piemēram, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitu virzienā xor ar pašreizējo vērtību, atgriežot iepriekšējo vērtību.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `fetch_xor` metodi, [`Ordering::Acquire`] nododot kā `order`.
    /// Piemēram, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitu virzienā xor ar pašreizējo vērtību, atgriežot iepriekšējo vērtību.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `fetch_xor` metodi, [`Ordering::Release`] nododot kā `order`.
    /// Piemēram, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitu virzienā xor ar pašreizējo vērtību, atgriežot iepriekšējo vērtību.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `fetch_xor` metodi, [`Ordering::AcqRel`] nododot kā `order`.
    /// Piemēram, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitu virzienā xor ar pašreizējo vērtību, atgriežot iepriekšējo vērtību.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] tipiem, izmantojot `fetch_xor` metodi, [`Ordering::Relaxed`] nododot kā `order`.
    /// Piemēram, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maksimums ar pašreizējo vērtību, izmantojot parakstītu salīdzinājumu.
    ///
    /// Stabilizētā šī iekšējā versija ir pieejama [`atomic`] parakstīto veselu skaitļu tipiem, izmantojot `fetch_max` metodi, [`Ordering::SeqCst`] nododot kā `order`.
    /// Piemēram, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimums ar pašreizējo vērtību, izmantojot parakstītu salīdzinājumu.
    ///
    /// Stabilizētā šī iekšējā versija ir pieejama [`atomic`] parakstīto veselu skaitļu tipiem, izmantojot `fetch_max` metodi, [`Ordering::Acquire`] nododot kā `order`.
    /// Piemēram, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimums ar pašreizējo vērtību, izmantojot parakstītu salīdzinājumu.
    ///
    /// Stabilizētā šī iekšējā versija ir pieejama [`atomic`] parakstīto veselu skaitļu tipiem, izmantojot `fetch_max` metodi, [`Ordering::Release`] nododot kā `order`.
    /// Piemēram, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimums ar pašreizējo vērtību, izmantojot parakstītu salīdzinājumu.
    ///
    /// Stabilizētā šī iekšējā versija ir pieejama [`atomic`] parakstīto veselu skaitļu tipiem, izmantojot `fetch_max` metodi, [`Ordering::AcqRel`] nododot kā `order`.
    /// Piemēram, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimums ar pašreizējo vērtību.
    ///
    /// Stabilizētā šī iekšējā versija ir pieejama [`atomic`] parakstīto veselu skaitļu tipiem, izmantojot `fetch_max` metodi, [`Ordering::Relaxed`] nododot kā `order`.
    /// Piemēram, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimālais ar pašreizējo vērtību, izmantojot parakstītu salīdzinājumu.
    ///
    /// Stabilizētā šī iekšējā versija ir pieejama [`atomic`] parakstīto veselu skaitļu tipiem, izmantojot `fetch_min` metodi, [`Ordering::SeqCst`] nododot kā `order`.
    /// Piemēram, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimālais ar pašreizējo vērtību, izmantojot parakstītu salīdzinājumu.
    ///
    /// Stabilizētā šī iekšējā versija ir pieejama [`atomic`] parakstīto veselu skaitļu tipiem, izmantojot `fetch_min` metodi, [`Ordering::Acquire`] nododot kā `order`.
    /// Piemēram, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimālais ar pašreizējo vērtību, izmantojot parakstītu salīdzinājumu.
    ///
    /// Stabilizētā šī iekšējā versija ir pieejama [`atomic`] parakstīto veselu skaitļu tipiem, izmantojot `fetch_min` metodi, [`Ordering::Release`] nododot kā `order`.
    /// Piemēram, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimālais ar pašreizējo vērtību, izmantojot parakstītu salīdzinājumu.
    ///
    /// Stabilizētā šī iekšējā versija ir pieejama [`atomic`] parakstīto veselu skaitļu tipiem, izmantojot `fetch_min` metodi, [`Ordering::AcqRel`] nododot kā `order`.
    /// Piemēram, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimālais ar pašreizējo vērtību, izmantojot parakstītu salīdzinājumu.
    ///
    /// Stabilizētā šī būtiskā versija ir pieejama [`atomic`] parakstīto veselu skaitļu tipiem, izmantojot metodi `fetch_min`, [`Ordering::Relaxed`] nododot kā `order`.
    /// Piemēram, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimālais ar pašreizējo vērtību, izmantojot neparakstītu salīdzinājumu.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] neparakstītu veselu skaitļu tipiem, izmantojot metodi `fetch_min`, [`Ordering::SeqCst`] nododot kā `order`.
    /// Piemēram, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimālais ar pašreizējo vērtību, izmantojot neparakstītu salīdzinājumu.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] neparakstītu veselu skaitļu tipiem, izmantojot metodi `fetch_min`, [`Ordering::Acquire`] nododot kā `order`.
    /// Piemēram, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimālais ar pašreizējo vērtību, izmantojot neparakstītu salīdzinājumu.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] neparakstītu veselu skaitļu tipiem, izmantojot metodi `fetch_min`, [`Ordering::Release`] nododot kā `order`.
    /// Piemēram, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimālais ar pašreizējo vērtību, izmantojot neparakstītu salīdzinājumu.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] neparakstītu veselu skaitļu tipiem, izmantojot metodi `fetch_min`, [`Ordering::AcqRel`] nododot kā `order`.
    /// Piemēram, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimālais ar pašreizējo vērtību, izmantojot neparakstītu salīdzinājumu.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] neparakstītu veselu skaitļu tipiem, izmantojot metodi `fetch_min`, [`Ordering::Relaxed`] nododot kā `order`.
    /// Piemēram, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maksimāli ar pašreizējo vērtību, izmantojot neparakstītu salīdzinājumu.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] neparakstītu veselu skaitļu tipiem, izmantojot metodi `fetch_max`, [`Ordering::SeqCst`] nododot kā `order`.
    /// Piemēram, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimāli ar pašreizējo vērtību, izmantojot neparakstītu salīdzinājumu.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] neparakstītu veselu skaitļu tipiem, izmantojot metodi `fetch_max`, [`Ordering::Acquire`] nododot kā `order`.
    /// Piemēram, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimāli ar pašreizējo vērtību, izmantojot neparakstītu salīdzinājumu.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] neparakstītu veselu skaitļu tipiem, izmantojot metodi `fetch_max`, [`Ordering::Release`] nododot kā `order`.
    /// Piemēram, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimāli ar pašreizējo vērtību, izmantojot neparakstītu salīdzinājumu.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] neparakstītu veselu skaitļu tipiem, izmantojot metodi `fetch_max`, [`Ordering::AcqRel`] nododot kā `order`.
    /// Piemēram, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimāli ar pašreizējo vērtību, izmantojot neparakstītu salīdzinājumu.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama [`atomic`] neparakstītu veselu skaitļu tipiem, izmantojot metodi `fetch_max`, [`Ordering::Relaxed`] nododot kā `order`.
    /// Piemēram, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// `prefetch` iekšējais ir mājienu koda ģeneratoram ievietot prefetch instrukciju, ja tā tiek atbalstīta;pretējā gadījumā tas ir aizliegums.
    /// Prefetches neietekmē programmas darbību, bet var mainīt tās veiktspējas īpašības.
    ///
    /// `locality` argumentam ir jābūt nemainīgam veselam skaitlim, un tas ir laika lokalizācijas specifikators, kas svārstās no (0), bez lokalizācijas, līdz (3), ārkārtīgi lokāls glabāšana kešatmiņā.
    ///
    ///
    /// Šim raksturīgajam nav stabila līdzinieka.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// `prefetch` iekšējais ir mājienu koda ģeneratoram ievietot prefetch instrukciju, ja tā tiek atbalstīta;pretējā gadījumā tas ir aizliegums.
    /// Prefetches neietekmē programmas darbību, bet var mainīt tās veiktspējas īpašības.
    ///
    /// `locality` argumentam ir jābūt nemainīgam veselam skaitlim, un tas ir laika lokalizācijas specifikators, kas svārstās no (0), bez lokalizācijas, līdz (3), ārkārtīgi lokāls glabāšana kešatmiņā.
    ///
    ///
    /// Šim raksturīgajam nav stabila līdzinieka.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// `prefetch` iekšējais ir mājienu koda ģeneratoram ievietot prefetch instrukciju, ja tā tiek atbalstīta;pretējā gadījumā tas ir aizliegums.
    /// Prefetches neietekmē programmas darbību, bet var mainīt tās veiktspējas īpašības.
    ///
    /// `locality` argumentam ir jābūt nemainīgam veselam skaitlim, un tas ir laika lokalizācijas specifikators, kas svārstās no (0), bez lokalizācijas, līdz (3), ārkārtīgi lokāls glabāšana kešatmiņā.
    ///
    ///
    /// Šim raksturīgajam nav stabila līdzinieka.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// `prefetch` iekšējais ir mājienu koda ģeneratoram ievietot prefetch instrukciju, ja tā tiek atbalstīta;pretējā gadījumā tas ir aizliegums.
    /// Prefetches neietekmē programmas darbību, bet var mainīt tās veiktspējas īpašības.
    ///
    /// `locality` argumentam ir jābūt nemainīgam veselam skaitlim, un tas ir laika lokalizācijas specifikators, kas svārstās no (0), bez lokalizācijas, līdz (3), ārkārtīgi lokāls glabāšana kešatmiņā.
    ///
    ///
    /// Šim raksturīgajam nav stabila līdzinieka.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Atomu žogs.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama versijā [`atomic::fence`], izlaižot [`Ordering::SeqCst`] kā `order`.
    ///
    ///
    pub fn atomic_fence();
    /// Atomu žogs.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama versijā [`atomic::fence`], izlaižot [`Ordering::Acquire`] kā `order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Atomu žogs.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama versijā [`atomic::fence`], izlaižot [`Ordering::Release`] kā `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Atomu žogs.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama versijā [`atomic::fence`], izlaižot [`Ordering::AcqRel`] kā `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Tikai kompilatoru atmiņas barjera.
    ///
    /// Atmiņas piekļuves kompilators nekad nepārkārtos pāri šai barjerai, taču tam netiks izdotas nekādas instrukcijas.
    /// Tas ir piemērots operācijām ar to pašu pavedienu, kas var būt nepieļauts, piemēram, mijiedarbojoties ar signālu apstrādātājiem.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama versijā [`atomic::compiler_fence`], izlaižot [`Ordering::SeqCst`] kā `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Tikai kompilatoru atmiņas barjera.
    ///
    /// Atmiņas piekļuves kompilators nekad nepārkārtos pāri šai barjerai, taču tam netiks izdotas nekādas instrukcijas.
    /// Tas ir piemērots operācijām ar to pašu pavedienu, kas var būt nepieļauts, piemēram, mijiedarbojoties ar signālu apstrādātājiem.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama versijā [`atomic::compiler_fence`], [`Ordering::Acquire`] nododot kā `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Tikai kompilatoru atmiņas barjera.
    ///
    /// Atmiņas piekļuves kompilators nekad nepārkārtos pāri šai barjerai, taču tam netiks izdotas nekādas instrukcijas.
    /// Tas ir piemērots operācijām ar to pašu pavedienu, kas var būt nepieļauts, piemēram, mijiedarbojoties ar signālu apstrādātājiem.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama versijā [`atomic::compiler_fence`], izlaižot [`Ordering::Release`] kā `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Tikai kompilatoru atmiņas barjera.
    ///
    /// Atmiņas piekļuves kompilators nekad nepārkārtos pāri šai barjerai, taču tam netiks izdotas nekādas instrukcijas.
    /// Tas ir piemērots operācijām ar to pašu pavedienu, kas var būt nepieļauts, piemēram, mijiedarbojoties ar signālu apstrādātājiem.
    ///
    /// Stabilizētā šī raksturīgā versija ir pieejama versijā [`atomic::compiler_fence`], izlaižot [`Ordering::AcqRel`] kā `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Burvju būtība, kas savu nozīmi iegūst no funkcijai pievienotajiem atribūtiem.
    ///
    /// Piemēram, datu plūsma to izmanto, lai ievadītu statiskus apgalvojumus, lai `rustc_peek(potentially_uninitialized)` faktiski vēlreiz pārbaudītu, vai datu plūsma patiešām aprēķina, ka tā nav inicializēta šajā vadības plūsmas punktā.
    ///
    ///
    /// Šo raksturīgo nevajadzētu izmantot ārpus sastādītāja.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Pārtrauc procesa izpildi.
    ///
    /// Lietotājam draudzīgāka un stabilāka šīs operācijas versija ir [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Informē optimizētāju, ka šis koda punkts nav sasniedzams, ļaujot turpināt optimizāciju.
    ///
    /// NB, tas ļoti atšķiras no `unreachable!()` makro: atšķirībā no makro, kuru izpildot panics, ir *nenoteikta uzvedība*, lai sasniegtu ar šo funkciju apzīmēto kodu.
    ///
    ///
    /// Stabilizētā šī būtiskā versija ir [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Informē optimizētāju, ka nosacījums vienmēr ir patiess.
    /// Ja nosacījums ir nepatiess, uzvedība nav definēta.
    ///
    /// Šim raksturīgajam elementam netiek ģenerēts kods, taču optimizētājs mēģinās to saglabāt (un tā stāvokli) starp caurlaidēm, kas var traucēt apkārtējā koda optimizāciju un samazināt veiktspēju.
    /// To nevajadzētu izmantot, ja optimizētāju var pats atrast invariantu vai ja tas neļauj veikt būtiskas optimizācijas.
    ///
    /// Šim raksturīgajam nav stabila līdzinieka.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Padomi kompilatoram, ka branch nosacījums, iespējams, ir patiess.
    /// Atgriež tai nodoto vērtību.
    ///
    /// Jebkura izmantošana, izņemot ar `if` paziņojumiem, visticamāk, neietekmēs.
    ///
    /// Šim raksturīgajam nav stabila līdzinieka.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Padomi kompilatoram, ka branch nosacījums, visticamāk, ir kļūdains.
    /// Atgriež tai nodoto vērtību.
    ///
    /// Jebkura izmantošana, izņemot ar `if` paziņojumiem, visticamāk, neietekmēs.
    ///
    /// Šim raksturīgajam nav stabila līdzinieka.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Izpilda lūzuma punkta slazdu, lai pārbaudītu atkļūdotājs.
    ///
    /// Šim raksturīgajam nav stabila līdzinieka.
    pub fn breakpoint();

    /// Tipa lielums baitos.
    ///
    /// Konkrētāk, tas ir nobāžu nobīde starp viena un tā paša veida secīgiem priekšmetiem, ieskaitot izlīdzināšanas polsterējumu.
    ///
    ///
    /// Stabilizētā šī būtiskā versija ir [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// Minimālais tipa izlīdzinājums.
    ///
    /// Stabilizētā šī būtiskā versija ir [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// Vēlamā veida izlīdzināšana.
    ///
    /// Šim raksturīgajam nav stabila līdzinieka.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// Atsauces vērtības lielums baitos.
    ///
    /// Stabilizētā šī būtiskā versija ir [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// Obligātā atsauces vērtības izlīdzināšana.
    ///
    /// Stabilizētā šī būtiskā versija ir [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Tiek iegūta statiska virknes šķēle, kurā ir tipa nosaukums.
    ///
    /// Stabilizētā šī būtiskā versija ir [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Tiek iegūts identifikators, kas ir unikāls norādītajam tipam.
    /// Šī funkcija atgriezīs vienādu vērtību tipam neatkarīgi no tā, kurā crate tas tiek izmantots.
    ///
    ///
    /// Stabilizētā šī būtiskā versija ir [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// Aizsargs nedrošām funkcijām, kuras nekad nevar izpildīt, ja `T` nav apdzīvots:
    /// Tas statiski vai nu panic, vai arī nedarīs neko.
    ///
    /// Šim raksturīgajam nav stabila līdzinieka.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// Aizsargs nedrošām funkcijām, kuras nekad nevar izpildīt, ja `T` neļauj nulles inicializēšanu: tas statiski vai nu panic, vai arī neko nedarīs.
    ///
    ///
    /// Šim raksturīgajam nav stabila līdzinieka.
    pub fn assert_zero_valid<T>();

    /// Aizsargs nedrošām funkcijām, kuras nekad nevar izpildīt, ja `T` ir nederīgi bitu modeļi: tas statiski vai nu panic, vai arī nedarīs neko.
    ///
    ///
    /// Šim raksturīgajam nav stabila līdzinieka.
    pub fn assert_uninit_valid<T>();

    /// Saņem atsauci uz statisko `Location`, norādot, kur tas tika izsaukts.
    ///
    /// Apsveriet tā vietā iespēju izmantot [`core::panic::Location::caller`](crate::panic::Location::caller).
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Pārvieto vērtību ārpus darbības jomas, nelietojot pilienu līmi.
    ///
    /// Tas pastāv tikai [`mem::forget_unsized`];normāls `forget` vietā izmanto `ManuallyDrop`.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Viena tipa vērtības bitus pārinterpretē kā cita veida bitus.
    ///
    /// Abiem veidiem jābūt vienādiem.
    /// Ne oriģināls, ne rezultāts nedrīkst būt [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` ir semantiski ekvivalents viena veida bitu pārvietošanai citā.Tas kopē bitus no avota vērtības mērķa vērtībā, pēc tam aizmirst oriģinālu.
    /// Tas ir līdzvērtīgs C `memcpy` zem pārsega, tāpat kā `transmute_copy`.
    ///
    /// Tā kā `transmute` ir blakus vērtības darbība, pašu *pārveidoto vērtību* pielīdzināšana nerada bažas.
    /// Tāpat kā ar jebkuru citu funkciju, kompilators jau nodrošina gan `T`, gan `U` pareizu izlīdzināšanu.
    /// Tomēr, pārveidojot vērtības, kas *norāda citur*(piemēram, rādītāji, atsauces, lodziņi ...), zvanītājam ir jānodrošina pareiza norādīto vērtību izlīdzināšana.
    ///
    /// `transmute` ir **neticami** nedrošs.Ir ļoti daudz veidu, kā ar šo funkciju izraisīt [undefined behavior][ub].`transmute` vajadzētu būt absolūtam pēdējam variantam.
    ///
    /// [nomicon](../../nomicon/transmutes.html) ir papildu dokumentācija.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Ir dažas lietas, kurām `transmute` patiešām noder.
    ///
    /// Rādītāja pārvēršana par funkcijas rādītāju.Tas *nav* pārnēsājams mašīnās, kurās funkciju rādītājiem un datu rādītājiem ir dažādi izmēri.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Mūža pagarināšana vai nemainīga mūža saīsināšana.Tas ir uzlabots, ļoti nedrošs Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Neapmieriniet: daudzus `transmute` lietojumus var panākt, izmantojot citus līdzekļus.
    /// Zemāk ir izplatītas `transmute` lietojumprogrammas, kuras var aizstāt ar drošākām konstrukcijām.
    ///
    /// Neapstrādāta bytes(`&[u8]`) pagriešana uz `u32`, `f64` utt.:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // tā vietā izmantojiet `u32::from_ne_bytes`
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // vai izmantojiet `u32::from_le_bytes` vai `u32::from_be_bytes`, lai norādītu endianitāti
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Rādītāja pārvēršana par `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Tā vietā izmantojiet `as` cast
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// `*mut T` pārvēršana par `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Tā vietā izmantojiet aizņēmumu
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// `&mut T` pārvēršana par `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Tagad, saliekot kopā `as` un aizņemoties atkārtoti, ņemiet vērā, ka `as` savienošana ar ķēdi `as` nav pārejoša
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// `&str` pārvēršana par `&[u8]`:
    ///
    /// ```
    /// // tas nav labs veids, kā to izdarīt.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Jūs varētu izmantot `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Vai arī vienkārši izmantojiet baitu virkni, ja jūs kontrolējat virknes burtisko
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// Pārvēršot `Vec<&T>` par `Vec<Option<&T>>`.
    ///
    /// Lai pārveidotu konteinera satura iekšējo tipu, jums jāpārliecinās, ka tas nepārkāpj nevienu no konteinera invariantiem.
    /// `Vec` tas nozīmē, ka gan iekšējo tipu izmēram *, gan izlīdzinājumam* ir jāsakrīt.
    /// Citi konteineri var paļauties uz veida, izlīdzinājuma vai pat `TypeId` izmēru, un tādā gadījumā pārveidošana nemaz nav iespējama, nepārkāpjot konteineru nemainīgos.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // klonējiet vector, jo mēs tos vēlāk atkārtoti izmantosim
    /// let v_clone = v_orig.clone();
    ///
    /// // Transmute izmantošana: tas balstās uz `Vec` nenoteiktu datu izkārtojumu, kas ir slikta ideja un varētu izraisīt nedefinētu uzvedību.
    /////
    /// // Tomēr tā nav kopija.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Tas ir ieteiktais, drošais veids.
    /// // Tomēr tas visu vector kopē jaunā masīvā.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Tas ir pareizs "transmuting" un `Vec` nedrošs veids, nepaļaujoties uz datu izkārtojumu.
    /// // Tā vietā, lai burtiski izsauktu `transmute`, mēs veicam rādītāju nodošanu, taču sākotnējā iekšējā veida (`&i32`) konvertēšanai uz jauno (`Option<&i32>`) ir visas tās pašas atrunas.
    /////
    /// // Papildus iepriekš sniegtajai informācijai skatiet arī [`from_raw_parts`] dokumentāciju.
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Atjauniniet to, kad vec_into_raw_parts ir stabilizēts.
    ///     // Pārliecinieties, ka sākotnējais vector nav nomests.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// `split_at_mut` ieviešana:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Ir vairāki veidi, kā to izdarīt, un ir vairākas problēmas ar šo (transmute) veidu.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // pirmais: pārveidot nav drošs veids;viss, ko tā pārbauda, ir tas, ka T un
    ///         // U ir vienāda lieluma.
    ///         // Otrkārt, tieši šeit jums ir divas maināmas atsauces, kas norāda uz to pašu atmiņu.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Tas atbrīvojas no tipa drošības problēmām;`&mut *`* tikai *dos jums `&mut T` no `&mut T` vai `* mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // tomēr jums joprojām ir divas maināmas atsauces, kas norāda uz vienu un to pašu atmiņu.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Tā to dara standarta bibliotēka.
    /// // Šī ir labākā metode, ja jums ir jādara kaut kas līdzīgs šim
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Tam tagad ir trīs maināmas atsauces, kas norāda uz to pašu atmiņu.`slice`, vērtība ret.0 un vērtība ret.1.
    ///         // `slice` nekad netiek izmantots pēc `let ptr = ...`, un tāpēc to var uzskatīt par "dead", un tāpēc jums ir tikai divas reālas maināmas šķēles.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Lai gan tas padara iekšējo konst stabilu, mums ir daži pielāgoti kodi const fn
    // pārbaudes, kas neļauj to izmantot `const fn`.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Atgriež vērtību `true`, ja faktiskajam tipam, kas norādīts kā `T`, ir nepieciešama pilienu līme;atgriež vērtību `false`, ja faktiskais tips, kas paredzēts `T`, ievieš `Copy`.
    ///
    ///
    /// Ja faktiskajam tipam nav nepieciešama pilināmā līme, un tas nelieto `Copy`, tad šīs funkcijas atgriešanās vērtība nav norādīta.
    ///
    /// Stabilizētā šī būtiskā versija ir [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Aprēķina nobīdi no rādītāja.
    ///
    /// Tas tiek ieviests kā neatņemama sastāvdaļa, lai izvairītos no konvertēšanas uz veselu skaitli un no tā, jo konvertēšana izmetīs aizstājvārdu informāciju.
    ///
    /// # Safety
    ///
    /// Gan sākuma, gan rezultāta rādītājam jābūt vai nu robežās, vai vienam baitam aiz piešķirtā objekta beigām.
    /// Ja kāds no rādītājiem ir ārpus robežas vai notiek aritmētiska pārpilde, jebkura turpmākā atgriezušās vērtības izmantošana radīs nedefinētu rīcību.
    ///
    ///
    /// Stabilizētā šī būtiskā versija ir [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Aprēķina nobīdi no rādītāja, iespējams, iesaiņojot.
    ///
    /// Tas tiek ieviests kā neatņemama sastāvdaļa, lai izvairītos no konvertēšanas uz veselu skaitli un no tā, jo konversija kavē noteiktas optimizācijas.
    ///
    /// # Safety
    ///
    /// Atšķirībā no iekšējās `offset`, šis raksturīgais elements neierobežo iegūto rādītāju norādīt uz piešķirtu objektu vai par vienu baitu aiz piešķirtā objekta beigām, un tas ietin divu komplementāro aritmētiku.
    /// Iegūtā vērtība nav obligāti derīga, lai to izmantotu, lai faktiski piekļūtu atmiņai.
    ///
    /// Stabilizētā šī būtiskā versija ir [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Ekvivalents atbilstošajam `llvm.memcpy.p0i8.0i8.*` raksturīgajam, ar izmēru `count`*`size_of::<T>()` un izlīdzinājumu
    ///
    /// `min_align_of::<T>()`
    ///
    /// Gaistošais parametrs ir iestatīts uz `true`, tāpēc tas netiks optimizēts, ja vien lielums nebūs vienāds ar nulli.
    ///
    /// Šim raksturīgajam nav stabila līdzinieka.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Ekvivalents atbilstošajam `llvm.memmove.p0i8.0i8.*` raksturīgajam, ar izmēru `count* size_of::<T>()` un izlīdzinājumu
    ///
    /// `min_align_of::<T>()`
    ///
    /// Gaistošais parametrs ir iestatīts uz `true`, tāpēc tas netiks optimizēts, ja vien lielums nebūs vienāds ar nulli.
    ///
    /// Šim raksturīgajam nav stabila līdzinieka.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Ekvivalents atbilstošajam `llvm.memset.p0i8.*` raksturīgajam, ar izmēru `count* size_of::<T>()` un izkārtojumu `min_align_of::<T>()`.
    ///
    ///
    /// Gaistošais parametrs ir iestatīts uz `true`, tāpēc tas netiks optimizēts, ja vien lielums nebūs vienāds ar nulli.
    ///
    /// Šim raksturīgajam nav stabila līdzinieka.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Veic gaistošu slodzi no `src` rādītāja.
    ///
    /// Stabilizētā šī būtiskā versija ir [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Veic nepastāvīgu `dst` rādītāja krātuvi.
    ///
    /// Stabilizētā šī būtiskā versija ir [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Veic nepastāvīgu slodzi no `src` rādītāja. Rādītājs nav jāsaskaņo.
    ///
    ///
    /// Šim raksturīgajam nav stabila līdzinieka.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Veic nepastāvīgu `dst` rādītāja krātuvi.
    /// Rādītājs nav jāsaskaņo.
    ///
    /// Šim raksturīgajam nav stabila līdzinieka.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Atgriež `f32` kvadrātsakni
    ///
    /// Stabilizētā šī būtiskā versija ir
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Atgriež `f64` kvadrātsakni
    ///
    /// Stabilizētā šī būtiskā versija ir
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Paaugstina `f32` līdz veselam skaitlim.
    ///
    /// Stabilizētā šī būtiskā versija ir
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Paaugstina `f64` līdz veselam skaitlim.
    ///
    /// Stabilizētā šī būtiskā versija ir
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Atgriež `f32` sinusu.
    ///
    /// Stabilizētā šī būtiskā versija ir
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Atgriež `f64` sinusu.
    ///
    /// Stabilizētā šī būtiskā versija ir
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Atgriež `f32` kosinusu.
    ///
    /// Stabilizētā šī būtiskā versija ir
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Atgriež `f64` kosinusu.
    ///
    /// Stabilizētā šī būtiskā versija ir
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Paaugstina `f32` līdz `f32` jaudai.
    ///
    /// Stabilizētā šī būtiskā versija ir
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Paaugstina `f64` līdz `f64` jaudai.
    ///
    /// Stabilizētā šī būtiskā versija ir
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Atgriež `f32` eksponenciālo vērtību.
    ///
    /// Stabilizētā šī būtiskā versija ir
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Atgriež `f64` eksponenciālo vērtību.
    ///
    /// Stabilizētā šī būtiskā versija ir
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Atgriež 2 paaugstinātu vērtību `f32`.
    ///
    /// Stabilizētā šī būtiskā versija ir
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Atgriež 2 paaugstinātu vērtību `f64`.
    ///
    /// Stabilizētā šī būtiskā versija ir
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Atgriež `f32` naturālo logaritmu.
    ///
    /// Stabilizētā šī būtiskā versija ir
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Atgriež `f64` naturālo logaritmu.
    ///
    /// Stabilizētā šī būtiskā versija ir
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Atgriež `f32` bāzes logaritmu 10.
    ///
    /// Stabilizētā šī būtiskā versija ir
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Atgriež `f64` bāzes logaritmu 10.
    ///
    /// Stabilizētā šī būtiskā versija ir
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Atgriež `f32` bāzes logaritmu 2.
    ///
    /// Stabilizētā šī būtiskā versija ir
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Atgriež `f64` bāzes logaritmu 2.
    ///
    /// Stabilizētā šī būtiskā versija ir
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Atgriež `a *b + c` vērtībām `a* b + c`.
    ///
    /// Stabilizētā šī būtiskā versija ir
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Atgriež `a *b + c` vērtībām `a* b + c`.
    ///
    /// Stabilizētā šī būtiskā versija ir
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Atgriež `f32` absolūto vērtību.
    ///
    /// Stabilizētā šī būtiskā versija ir
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Atgriež `f64` absolūto vērtību.
    ///
    /// Stabilizētā šī būtiskā versija ir
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Atgriež minimālās divas `f32` vērtības.
    ///
    /// Stabilizētā šī būtiskā versija ir
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Atgriež minimālās divas `f64` vērtības.
    ///
    /// Stabilizētā šī būtiskā versija ir
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Atgriež divu `f32` vērtību maksimālo vērtību.
    ///
    /// Stabilizētā šī būtiskā versija ir
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Atgriež divu `f64` vērtību maksimālo vērtību.
    ///
    /// Stabilizētā šī būtiskā versija ir
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Kopē zīmi no `y` uz `x` vērtībām `f32`.
    ///
    /// Stabilizētā šī būtiskā versija ir
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Kopē zīmi no `y` uz `x` vērtībām `f64`.
    ///
    /// Stabilizētā šī būtiskā versija ir
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Atgriež lielāko skaitli, kas ir mazāks vai vienāds ar `f32`.
    ///
    /// Stabilizētā šī būtiskā versija ir
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Atgriež lielāko skaitli, kas ir mazāks vai vienāds ar `f64`.
    ///
    /// Stabilizētā šī būtiskā versija ir
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Atgriež mazāko veselu skaitli, kas ir lielāks vai vienāds ar `f32`.
    ///
    /// Stabilizētā šī būtiskā versija ir
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Atgriež mazāko veselu skaitli, kas ir lielāks vai vienāds ar `f64`.
    ///
    /// Stabilizētā šī būtiskā versija ir
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Atgriež `f32` veselu skaitļa daļu.
    ///
    /// Stabilizētā šī būtiskā versija ir
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Atgriež `f64` veselu skaitļa daļu.
    ///
    /// Stabilizētā šī būtiskā versija ir
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Atgriež `f32` tuvāko veselu skaitli.
    /// Var izraisīt neprecīzu peldošā komata izņēmumu, ja arguments nav vesels skaitlis.
    pub fn rintf32(x: f32) -> f32;
    /// Atgriež `f64` tuvāko veselu skaitli.
    /// Var izraisīt neprecīzu peldošā komata izņēmumu, ja arguments nav vesels skaitlis.
    pub fn rintf64(x: f64) -> f64;

    /// Atgriež `f32` tuvāko veselu skaitli.
    ///
    /// Šim raksturīgajam nav stabila līdzinieka.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Atgriež `f64` tuvāko veselu skaitli.
    ///
    /// Šim raksturīgajam nav stabila līdzinieka.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Atgriež `f32` tuvāko veselu skaitli.Pusceļa gadījumus noapaļo no nulles.
    ///
    /// Stabilizētā šī būtiskā versija ir
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Atgriež `f64` tuvāko veselu skaitli.Pusceļa gadījumus noapaļo no nulles.
    ///
    /// Stabilizētā šī būtiskā versija ir
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Pludinātais papildinājums, kas ļauj optimizēt, pamatojoties uz algebriskiem noteikumiem.
    /// Var pieņemt, ka ievadi ir ierobežoti.
    ///
    /// Šim raksturīgajam nav stabila līdzinieka.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Peldošā atņemšana, kas ļauj optimizēt, pamatojoties uz algebriskiem noteikumiem.
    /// Var pieņemt, ka ievadi ir ierobežoti.
    ///
    /// Šim raksturīgajam nav stabila līdzinieka.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Pārejošā reizināšana, kas ļauj optimizēt, pamatojoties uz algebriskiem noteikumiem.
    /// Var pieņemt, ka ievadi ir ierobežoti.
    ///
    /// Šim raksturīgajam nav stabila līdzinieka.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Peldošā dalīšana, kas ļauj optimizēt, pamatojoties uz algebriskiem noteikumiem.
    /// Var pieņemt, ka ievadi ir ierobežoti.
    ///
    /// Šim raksturīgajam nav stabila līdzinieka.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Pārejošais atlikums, kas ļauj optimizēt, pamatojoties uz algebriskiem noteikumiem.
    /// Var pieņemt, ka ievadi ir ierobežoti.
    ///
    /// Šim raksturīgajam nav stabila līdzinieka.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Konvertējiet ar LLVM fptoui/fptosi, kas var atgriezt undef vērtībām ārpus diapazona
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Stabilizēts kā [`f32::to_int_unchecked`] un [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Atgriež veselu skaitļu `T` tipā iestatīto bitu skaitu
    ///
    /// Stabilizētās šī iekšējā versijas ir pieejamas vesela skaitļa primitīviem, izmantojot metodi `count_ones`.
    /// Piemēram,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Atgriež vadošo nenoteikto bitu skaitu (zeroes) vesela skaitļa `T` tipā.
    ///
    /// Stabilizētās šī iekšējā versijas ir pieejamas vesela skaitļa primitīviem, izmantojot metodi `leading_zeros`.
    /// Piemēram,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// `x` ar vērtību `0` atgriezīs `T` bitu platumu.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Tāpat kā `ctlz`, bet īpaši nedrošs, jo tas atgriež `undef`, ja tam tiek piešķirta `x` ar vērtību `0`.
    ///
    ///
    /// Šim raksturīgajam nav stabila līdzinieka.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Atgriež beigu nenoteikto bitu skaitu (zeroes) vesela skaitļa `T` tipā.
    ///
    /// Stabilizētās šī iekšējā versijas ir pieejamas vesela skaitļa primitīviem, izmantojot metodi `trailing_zeros`.
    /// Piemēram,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// `x` ar vērtību `0` atgriezīs `T` bitu platumu:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Tāpat kā `cttz`, bet īpaši nedrošs, jo tas atgriež `undef`, ja tam tiek piešķirta `x` ar vērtību `0`.
    ///
    ///
    /// Šim raksturīgajam nav stabila līdzinieka.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Apgriež baitus veselā skaitļa `T` tipā.
    ///
    /// Stabilizētās šī iekšējā versijas ir pieejamas vesela skaitļa primitīviem, izmantojot metodi `swap_bytes`.
    /// Piemēram,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Apgriež bitus veselā skaitļa tipā `T`.
    ///
    /// Stabilizētās šī iekšējā versijas ir pieejamas vesela skaitļa primitīviem, izmantojot metodi `reverse_bits`.
    /// Piemēram,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Veic pārbaudītu vesela skaitļa pievienošanu.
    ///
    /// Stabilizētās šī iekšējā versijas ir pieejamas vesela skaitļa primitīviem, izmantojot metodi `overflowing_add`.
    /// Piemēram,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Veic pārbaudītu veselu skaitļu atņemšanu
    ///
    /// Stabilizētās šī iekšējā versijas ir pieejamas vesela skaitļa primitīviem, izmantojot metodi `overflowing_sub`.
    /// Piemēram,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Veic pārbaudītu veselu skaitļu reizināšanu
    ///
    /// Stabilizētās šī iekšējā versijas ir pieejamas vesela skaitļa primitīviem, izmantojot metodi `overflowing_mul`.
    /// Piemēram,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Veic precīzu sadalījumu, kā rezultātā nedefinēta uzvedība, kur `x % y != 0` vai `y == 0` vai `x == T::MIN && y == -1`
    ///
    ///
    /// Šim raksturīgajam nav stabila līdzinieka.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Veic nepārbaudītu dalīšanu, kā rezultātā tiek definēta nedefinēta `y == 0` vai `x == T::MIN && y == -1` darbība
    ///
    ///
    /// Izmantojot `checked_div` metodi, veseliem skaitļiem primitīviem ir pieejami drošie iesaiņotāji.
    /// Piemēram,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Atgriež nepārbaudītā sadalījuma atlikumu, kā rezultātā `y == 0` vai `x == T::MIN && y == -1` tiek noteikta nedefinēta darbība
    ///
    ///
    /// Izmantojot `checked_rem` metodi, veseliem skaitļiem primitīviem ir pieejami drošie iesaiņotāji.
    /// Piemēram,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Veic nepārbaudītu kreiso nobīdi, kā rezultātā rodas nedefinēta uzvedība, kad `y < 0` vai `y >= N`, kur N ir T platums bitos.
    ///
    ///
    /// Izmantojot `checked_shl` metodi, veseliem skaitļiem primitīviem ir pieejami drošie iesaiņotāji.
    /// Piemēram,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Veic nepārbaudītu labo nobīdi, kā rezultātā rodas nedefinēta uzvedība, kad `y < 0` vai `y >= N`, kur N ir T platums bitos.
    ///
    ///
    /// Izmantojot `checked_shr` metodi, veseliem skaitļiem primitīviem ir pieejami drošie iesaiņotāji.
    /// Piemēram,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Atgriež nepārbaudīta papildinājuma rezultātu, kā rezultātā tiek noteikta nedefinēta darbība, kad `x + y > T::MAX` vai `x + y < T::MIN`.
    ///
    ///
    /// Šim raksturīgajam nav stabila līdzinieka.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Atgriež nepārbaudītas atņemšanas rezultātu, kā rezultātā tiek noteikta nedefinēta darbība, kad `x - y > T::MAX` vai `x - y < T::MIN`.
    ///
    ///
    /// Šim raksturīgajam nav stabila līdzinieka.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Atgriež nepārbaudītas reizināšanas rezultātu, kā rezultātā tiek noteikta nedefinēta darbība, kad `x *y > T::MAX` vai `x* y < T::MIN`.
    ///
    ///
    /// Šim raksturīgajam nav stabila līdzinieka.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Veic pagriešanu pa kreisi.
    ///
    /// Stabilizētās šī iekšējā versijas ir pieejamas vesela skaitļa primitīviem, izmantojot metodi `rotate_left`.
    /// Piemēram,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Veic pagriešanu pa labi.
    ///
    /// Stabilizētās šī iekšējā versijas ir pieejamas vesela skaitļa primitīviem, izmantojot metodi `rotate_right`.
    /// Piemēram,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Atgriež (a + b) mod 2 <sup>N</sup>, kur N ir T platums bitos.
    ///
    /// Stabilizētās šī iekšējā versijas ir pieejamas vesela skaitļa primitīviem, izmantojot metodi `wrapping_add`.
    /// Piemēram,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Atgriež (a, b) mod 2 <sup>N</sup>, kur N ir T platums bitos.
    ///
    /// Stabilizētās šī iekšējā versijas ir pieejamas vesela skaitļa primitīviem, izmantojot metodi `wrapping_sub`.
    /// Piemēram,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Atgriež (a * b) mod 2 <sup>N</sup>, kur N ir T platums bitos.
    ///
    /// Stabilizētās šī iekšējā versijas ir pieejamas vesela skaitļa primitīviem, izmantojot metodi `wrapping_mul`.
    /// Piemēram,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Aprēķina `a + b`, piesātinot skaitliskās robežas.
    ///
    /// Stabilizētās šī iekšējā versijas ir pieejamas vesela skaitļa primitīviem, izmantojot metodi `saturating_add`.
    /// Piemēram,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Aprēķina `a - b`, piesātinot skaitliskās robežas.
    ///
    /// Stabilizētās šī iekšējā versijas ir pieejamas vesela skaitļa primitīviem, izmantojot metodi `saturating_sub`.
    /// Piemēram,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Atgriež varianta diskriminanta vērtību 'v';
    /// ja `T` nav diskriminanta, atgriež `0`.
    ///
    /// Stabilizētā šī būtiskā versija ir [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Atgriež `T` tipa variantu skaitu uz `usize`;
    /// ja `T` nav variantu, atgriež `0`.Neapdzīvotie varianti tiks skaitīti.
    ///
    /// Stabilizējamā šī iekšējā versija ir [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Rust "try catch" konstrukcija, kas izsauc funkciju rādītāju `try_fn` ar datu rādītāju `data`.
    ///
    /// Trešais arguments ir funkcija, ko sauc, ja notiek panic.
    /// Šī funkcija novirza datu rādītāju un rādītāju uz noķerto mērķa izņēmuma objektu.
    ///
    /// Lai iegūtu vairāk informācijas, skatiet kompilatora avotu, kā arī std nozvejas ieviešanu.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Izstaro `!nontemporal` veikalu saskaņā ar LLVM (skat. Viņu dokumentus).
    /// Droši vien nekad nekļūs stabils.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Sīkāku informāciju skatiet `<*const T>::offset_from` dokumentācijā.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Sīkāku informāciju skatiet `<*const T>::guaranteed_eq` dokumentācijā.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Sīkāku informāciju skatiet `<*const T>::guaranteed_ne` dokumentācijā.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Piešķirt kompilēšanas laikā.Nevajadzētu izsaukt izpildlaikā.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Dažas funkcijas ir definētas šeit, jo tās nejauši tika padarītas pieejamas šajā modulī stabilā režīmā.
// Skatiet <https://github.com/rust-lang/rust/issues/15702>.
// (Šajā kategorijā ietilpst arī `transmute`, taču to nevar iesaiņot, jo pārbauda, vai `T` un `U` ir vienāda izmēra.)
//

/// Pārbauda, vai `ptr` ir pareizi izlīdzināts attiecībā pret `align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Kopē `count *size_of::<T>()` baitus no `src` uz `dst`.Avots un galamērķis* nedrīkst * pārklāties.
///
/// Atmiņas reģioniem, kas var pārklāties, tā vietā izmantojiet [`copy`].
///
/// `copy_nonoverlapping` ir semantiski ekvivalents C [`memcpy`], bet ar argumentu secību mainīta.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Uzvedība nav definēta, ja tiek pārkāpts kāds no šiem nosacījumiem:
///
/// * `src` jābūt [valid], lai lasītu `count * size_of::<T>()` baitus.
///
/// * `dst` jābūt [valid], lai ierakstītu `count * size_of::<T>()` baitus.
///
/// * Gan `src`, gan `dst` ir pareizi jāsaskaņo.
///
/// * Atmiņas reģions, kas sākas `src` un kura lielums ir `count *
///   ::<T>() `baiti nedrīkst * pārklāties ar tāda paša izmēra atmiņas reģionu, kas sākas `dst`.
///
/// Tāpat kā [`read`], arī `copy_nonoverlapping` izveido `T` bitu kopiju neatkarīgi no tā, vai `T` ir [`Copy`].
/// Ja `T` nav [`Copy`], [violate memory safety][read-ownership] var izmantot *abas* vērtības reģionā, kas sākas ar `*src`, un reģionā, kas sākas ar `* dst`.
///
///
/// Ņemiet vērā, ka pat tad, ja faktiski nokopētais lielums (`skaits * izmērs: <T>()`) ir `0`, rādītājiem nedrīkst būt NULL un pareizi jāsaskaņo.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Manuāli ieviest [`Vec::append`]:
///
/// ```
/// use std::ptr;
///
/// /// Pārvieto visus `src` elementus uz `dst`, atstājot `src` tukšu.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Pārliecinieties, vai `dst` ir pietiekama ietilpība, lai to varētu turēt visā `src`.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Zvans uz kompensāciju vienmēr ir drošs, jo `Vec` nekad nepiešķirs vairāk par `isize::MAX` baitiem.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Saīsiniet `src`, nenometot tā saturu.
///         // Mēs to darām vispirms, lai izvairītos no problēmām, ja kaut kas atrodas tālāk panics.
///         src.set_len(0);
///
///         // Abi reģioni nevar pārklāties, jo maināmām atsaucēm nav alias, un diviem dažādiem vectors nevar piederēt viena un tā pati atmiņa.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Paziņojiet `dst`, ka tajā tagad atrodas `src` saturs.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Veiciet šīs pārbaudes tikai izpildes laikā
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Nav panikas, lai kodegēna ietekme būtu mazāka.
        abort();
    }*/

    // DROŠĪBA: jābūt noslēgtam `copy_nonoverlapping` drošības līgumam
    // apstiprina zvanītājs.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Kopē `count * size_of::<T>()` baitus no `src` uz `dst`.Avots un galamērķis var pārklāties.
///
/// Ja avots un galamērķis * nekad nepārklāsies, tā vietā var izmantot [`copy_nonoverlapping`].
///
/// `copy` ir semantiski ekvivalents C [`memmove`], bet ar argumentu secību mainīta.
/// Kopēšana notiek tā, it kā baiti tiktu kopēti no `src` uz pagaidu masīvu un pēc tam no masīva kopēti uz `dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Uzvedība nav definēta, ja tiek pārkāpts kāds no šiem nosacījumiem:
///
/// * `src` jābūt [valid], lai lasītu `count * size_of::<T>()` baitus.
///
/// * `dst` jābūt [valid], lai ierakstītu `count * size_of::<T>()` baitus.
///
/// * Gan `src`, gan `dst` ir pareizi jāsaskaņo.
///
/// Tāpat kā [`read`], arī `copy` izveido `T` bitu kopiju neatkarīgi no tā, vai `T` ir [`Copy`].
/// Ja `T` nav [`Copy`], [violate memory safety][read-ownership] var izmantot gan vērtības reģionā, kas sākas ar `*src`, gan reģionā, kas sākas ar `* dst`.
///
///
/// Ņemiet vērā, ka pat tad, ja faktiski nokopētais lielums (`skaits * izmērs: <T>()`) ir `0`, rādītājiem nedrīkst būt NULL un pareizi jāsaskaņo.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Efektīvi izveidojiet Rust vector no nedroša bufera:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` jābūt pareizi izlīdzinātam pēc veida un nulles.
/// /// * `ptr` jābūt derīgai, lasot `elts` blakus esošos `T` tipa elementus.
/// /// * Šos elementus nedrīkst izmantot pēc šīs funkcijas izsaukšanas, ja vien nav `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // DROŠĪBA: mūsu priekšnosacījums nodrošina avota izlīdzināšanu un derīgumu,
///     // un `Vec::with_capacity` nodrošina, ka mums ir izmantojama vieta to ierakstīšanai.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // DROŠĪBA: Mēs to iepriekš izveidojām ar tik lielu ietilpību,
///     // un iepriekšējā `copy` ir inicializējusi šos elementus.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Veiciet šīs pārbaudes tikai izpildes laikā
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Nav panikas, lai kodegēna ietekme būtu mazāka.
        abort();
    }*/

    // DROŠĪBA: zvanītājam jāievēro `copy` drošības līgums.
    unsafe { copy(src, dst, count) }
}

/// Iestata atmiņas `count * size_of::<T>()` baitus, sākot no `dst` līdz `val`.
///
/// `write_bytes` ir līdzīgs C [`memset`], bet `count * size_of::<T>()` baitus iestata `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Uzvedība nav definēta, ja tiek pārkāpts kāds no šiem nosacījumiem:
///
/// * `dst` jābūt [valid], lai ierakstītu `count * size_of::<T>()` baitus.
///
/// * `dst` jābūt pareizi izlīdzinātam.
///
/// Turklāt zvanītājam ir jānodrošina, ka, ierakstot `count * size_of::<T>()` baitus attiecīgajā atmiņas reģionā, tiek iegūta derīga `T` vērtība.
/// Atmiņas reģiona, kas ierakstīts kā `T` un kas satur nederīgu `T` vērtību, izmantošana nav noteikta rīcība.
///
/// Ņemiet vērā, ka pat tad, ja faktiski nokopētais lielums (`skaits * izmērs: <T>()`) ir `0`, rādītājam nav jābūt NULL un pareizi izlīdzinātam.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Pamata lietojums:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Nederīgas vērtības izveidošana:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Nopludina iepriekš turēto vērtību, pārrakstot `Box<T>` ar nulles rādītāju.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // Šajā brīdī `v` izmantošana vai nomešana rada nedefinētu uzvedību.
/// // drop(v); // ERROR
///
/// // Pat `v` "uses" noplūde, un līdz ar to ir nedefinēta rīcība.
/// // mem::forget(v); // ERROR
///
/// // Faktiski `v` nav derīgs atbilstoši pamata tipa izkārtojuma nemainīgajiem, tāpēc *jebkura* darbība, kas tai pieskaras, ir nedefinēta rīcība.
/////
/// // ļaujiet v2 =v;//KĻŪDA
///
/// unsafe {
///     // Ievietosim derīgu vērtību
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Tagad kaste ir kārtībā
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // DROŠĪBA: zvanītājam jāievēro `write_bytes` drošības līgums.
    unsafe { write_bytes(dst, val, count) }
}