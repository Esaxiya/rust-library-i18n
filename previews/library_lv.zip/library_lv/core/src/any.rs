//! Šis modulis ievieš `Any` trait, kas ļauj dinamiski ierakstīt jebkuru `'static` tipu, izmantojot izpildlaika atspoguļojumu.
//!
//! `Any` pati par sevi var izmantot, lai iegūtu `TypeId`, un tam ir vairāk funkciju, ja to izmanto kā objektu trait.
//! Kā `&dyn Any` (aizņemts trait objekts) tam ir `is` un `downcast_ref` metodes, lai pārbaudītu, vai saturošā vērtība ir noteikta veida, un lai iegūtu atsauci uz iekšējo vērtību kā tipu.
//! Kā `&mut dyn Any` ir arī `downcast_mut` metode, lai iegūtu mainīgu atsauci uz iekšējo vērtību.
//! `Box<dyn Any>` pievieno metodi `downcast`, kas mēģina pārveidot par `Box<T>`.
//! Pilnu informāciju skatiet [`Box`] dokumentācijā.
//!
//! Ņemiet vērā, ka `&dyn Any` aprobežojas ar pārbaudi, vai vērtība ir noteikta betona tipa, un to nevar izmantot, lai pārbaudītu, vai tips īsteno trait.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Viedās norādes un `dyn Any`
//!
//! Viens no uzvedības veidiem, kas jāpatur prātā, lietojot `Any` kā objektu trait, it īpaši ar tādiem tipiem kā `Box<dyn Any>` vai `Arc<dyn Any>`, ir tas, ka, vienkārši izsaucot vērtību `.type_id()`, tiks iegūts *konteinera*`TypeId`, nevis pamatā esošā objekta trait.
//!
//! To var izvairīties, viedo rādītāju pārveidojot par `&dyn Any`, kas atgriezīs objekta `TypeId`.
//! Piemēram:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Jūs, visticamāk, vēlaties to:
//! let actual_id = (&*boxed).type_id();
//! // ... nekā šis:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Apsveriet situāciju, kad mēs vēlamies atteikties no funkcijas nodotās vērtības.
//! Mēs zinām vērtību, ar kuru mēs strādājam, ievieš Debug, bet nezinām tā konkrēto tipu.Mēs vēlamies piešķirt īpašu attieksmi pret dažiem veidiem: šajā gadījumā String vērtību garuma izdrukāšana pirms to vērtības.
//! Kompilācijas laikā mēs nezinām konkrētu mūsu vērtības veidu, tāpēc mums tā vietā jāizmanto izpildlaika atspoguļojums.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Logger funkcija jebkuram tipam, kas ievieš atkļūdošanu.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Mēģiniet pārvērst mūsu vērtību par `String`.
//!     // Ja tas izdosies, mēs vēlamies norādīt virknes garumu, kā arī tās vērtību.
//!     // Ja nē, tas ir cits veids: vienkārši izdrukājiet to bez dekorēšanas.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Šī funkcija vēlas reģistrēt savu parametru pirms darba ar to.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... veic kādu citu darbu
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Jebkurš trait
///////////////////////////////////////////////////////////////////////////////

/// trait, lai atdarinātu dinamisko rakstīšanu.
///
/// Lielākā daļa veidu ievieš `Any`.Tomēr jebkura veida, kurā ir atsauce, kas nav "statiska", nav.
/// Plašāku informāciju skatiet [module-level documentation][mod].
///
/// [mod]: crate::any
// Šis trait nav nedrošs, lai gan mēs paļaujamies uz tā vienīgā implanta `type_id` funkcijas specifiku nedrošā kodā (piemēram, `downcast`).Parasti tā būtu problēma, taču, tā kā vienīgais `Any` mērķis ir vispārēja ieviešana, neviens cits kods nevar ieviest `Any`.
//
// Mēs varētu ticami padarīt šo trait nedrošu-tas neradītu lūzumus, jo mēs kontrolējam visus ieviešanas gadījumus-, taču mēs izvēlamies to nedarīt, jo tas gan nav īsti nepieciešams, gan var sajaukt lietotājus par nedrošu traits un nedrošu metožu (ti, `type_id` joprojām būtu droši piezvanīt, taču mēs, iespējams, vēlēsimies to norādīt dokumentācijā).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Iegūst `self` `TypeId`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Paplašināšanas metodes jebkuram trait objektam.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Pārliecinieties, ka, piemēram, pavediena savienošanas rezultātu, var izdrukāt un tādējādi izmantot kopā ar `unwrap`.
// Tas galu galā vairs nebūs vajadzīgs, ja nosūtīšana darbojas ar augšupielādi.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Atgriež vērtību `true`, ja ierakstītais tips ir tāds pats kā `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Iegūstiet šāda veida `TypeId`, ar kuru šī funkcija tiek instantiated.
        let t = TypeId::of::<T>();

        // Iegūstiet šāda veida `TypeId` objektā trait (`self`).
        let concrete = self.type_id();

        // Salīdziniet abus `TypeId` par vienlīdzību.
        t == concrete
    }

    /// Atgriež zināmu atsauci uz lodziņa vērtību, ja tā ir `T` tips, vai `None`, ja tā nav.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // DROŠĪBA: vienkārši pārbaudījām, vai mēs norādām uz pareizo tipu, un mēs varam paļauties
            // kas pārbauda atmiņas drošību, jo visiem veidiem esam ieviesuši Any;citi implekti nevar pastāvēt, jo tie būtu pretrunā ar mūsu implikāciju.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Atgriež kādu maināmu atsauci uz lodziņa vērtību, ja tā ir `T` tips, vai `None`, ja tā nav.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // DROŠĪBA: vienkārši pārbaudījām, vai mēs norādām uz pareizo tipu, un mēs varam paļauties
            // kas pārbauda atmiņas drošību, jo visiem veidiem esam ieviesuši Any;citi implekti nevar pastāvēt, jo tie būtu pretrunā ar mūsu implikāciju.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Pāriet uz metodi, kas noteikta tipam `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Pāriet uz metodi, kas noteikta tipam `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Pāriet uz metodi, kas noteikta tipam `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Pāriet uz metodi, kas noteikta tipam `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Pāriet uz metodi, kas noteikta tipam `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Pāriet uz metodi, kas noteikta tipam `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID un tā metodes
///////////////////////////////////////////////////////////////////////////////

/// `TypeId` apzīmē tipam globāli unikālu identifikatoru.
///
/// Katrs `TypeId` ir necaurspīdīgs objekts, kas neļauj pārbaudīt iekšējo saturu, bet ļauj veikt tādas pamatdarbības kā klonēšana, salīdzināšana, drukāšana un demonstrēšana.
///
///
/// `TypeId` pašlaik ir pieejams tikai tipiem, kas attiecināmi uz `'static`, taču future šo ierobežojumu var noņemt.
///
/// Kamēr `TypeId` ievieš `Hash`, `PartialOrd` un `Ord`, ir vērts atzīmēt, ka jaukšana un pasūtīšana dažādās Rust laidienos būs atšķirīga.
/// Sargieties paļauties uz tiem sava koda iekšienē!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Atgriež `TypeId` tipu, ar kuru šī vispārīgā funkcija ir izveidota.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Atgriež tipa nosaukumu kā virknes šķēli.
///
/// # Note
///
/// Tas ir paredzēts diagnostikai.
/// Precīzs atgrieztās virknes saturs un formāts nav norādīts, izņemot to, ka tas ir tipa labākais apraksts.
/// Piemēram, starp virknēm, kuras var atgriezties `type_name::<Option<String>>()`, ir `"Option<String>"` un `"std::option::Option<std::string::String>"`.
///
///
/// Atgriezto virkni nedrīkst uzskatīt par unikālu tipa identifikatoru, jo vairāki tipi var kartēt uz viena tipa nosaukumu.
/// Tāpat nav garantijas, ka visas tipa daļas tiks parādītas atgrieztajā virknē: piemēram, kalpošanas laika specifikatori pašlaik nav iekļauti.
/// Turklāt izvade var mainīties starp kompilatora versijām.
///
/// Pašreizējā ieviešanā tiek izmantota tā pati infrastruktūra kā kompilatora diagnostikā un atkļūdošanas informācijā, taču tas netiek garantēts.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Atgriež norādītās vērtības veida nosaukumu kā virknes šķēli.
/// Tas ir tas pats, kas `type_name::<T>()`, taču to var izmantot, ja mainīgā tips nav viegli pieejams.
///
/// # Note
///
/// Tas ir paredzēts diagnostikai.Precīzs virknes saturs un formāts nav norādīts, izņemot to, ka tas ir tipa labākais apraksts.
/// Piemēram, `type_name_of_val::<Option<String>>(None)` varētu atgriezt `"Option<String>"` vai `"std::option::Option<std::string::String>"`, bet ne `"foobar"`.
///
/// Turklāt izvade var mainīties starp kompilatora versijām.
///
/// Šī funkcija neatrisina trait objektus, tas nozīmē, ka `type_name_of_val(&7u32 as &dyn Debug)` var atgriezt `"dyn Debug"`, bet ne `"u32"`.
///
/// Tipa nosaukums nav jāuzskata par unikālu tipa identifikatoru;
/// vairākiem tipiem var būt tāds pats nosaukuma nosaukums.
///
/// Pašreizējā ieviešanā tiek izmantota tā pati infrastruktūra kā kompilatora diagnostikā un atkļūdošanas informācijā, taču tas netiek garantēts.
///
/// # Examples
///
/// Izdrukā noklusējuma veselā skaitļa un pludiņa tipus.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}