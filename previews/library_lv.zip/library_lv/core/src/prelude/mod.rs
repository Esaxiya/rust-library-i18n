//! Libcore prelude
//!
//! Šis modulis ir paredzēts libcore lietotājiem, kuri nav saistīti arī ar libstd.
//! Šis modulis pēc noklusējuma tiek importēts, ja `#![no_std]` tiek izmantots tāpat kā standarta bibliotēkas prelude.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// Kodola prelude 2015. gada versija.
///
/// Lai uzzinātu vairāk, skatiet [module-level documentation](self).
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// prelude kodola 2018. gada versija.
///
/// Lai uzzinātu vairāk, skatiet [module-level documentation](self).
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Kodola prelude 2021. gada versija.
///
/// Lai uzzinātu vairāk, skatiet [module-level documentation](self).
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Pievienojiet vairāk lietu.
}