//! Šis ir iekšējais modulis, ko izmanto ifmt!izpildlaiks.Šīs struktūras tiek izstarotas statiskos masīvos, lai pirms laika apkopotu formātu virknes.
//!
//! Šīs definīcijas ir līdzīgas to `ct` ekvivalentiem, taču atšķiras ar to, ka tās var statiski piešķirt un nedaudz optimizēt izpildlaika
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Iespējamie izlīdzinājumi, kurus var pieprasīt kā formatēšanas direktīvas daļu.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Norāde, ka saturam jābūt izlīdzinātam pa kreisi.
    Left,
    /// Norāde, ka saturam jābūt izlīdzinātam pa labi.
    Right,
    /// Norāde, ka saturam jābūt centrētam.
    Center,
    /// Netika pieprasīta pielīdzināšana.
    Unknown,
}

/// Izmanto [width](https://doc.rust-lang.org/std/fmt/#width) un [precision](https://doc.rust-lang.org/std/fmt/#precision) specifikatori.
#[derive(Copy, Clone)]
pub enum Count {
    /// Norādīts ar burtisku skaitli, saglabā vērtību
    Is(usize),
    /// Norādīts, izmantojot sintakses `$` un `*`, indeksu saglabā `args`
    Param(usize),
    /// Nav precizēts
    Implied,
}