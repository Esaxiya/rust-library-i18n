use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// Īpašumā esoša un sevī ieturēta backtrace attēlojums.
///
/// Šo struktūru var izmantot, lai attēlotu aizmugures pēdas dažādos programmas punktos, un vēlāk to var izmantot, lai pārbaudītu to, kas tajā laikā bija aizmugure.
///
///
/// `Backtrace` atbalsta skaistu pēdu izdrukāšanu, izmantojot `Debug` ieviešanu.
///
/// # Nepieciešamās funkcijas
///
/// Lai izmantotu šo funkciju, ir jāiespējo `backtrace` crate funkcija `std`, un pēc noklusējuma ir iespējota funkcija `std`.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // Rāmji šeit ir uzskaitīti no kaudzes augšdaļas uz leju
    frames: Vec<BacktraceFrame>,
    // Mēs uzskatām, ka indekss ir faktiskais aizmugures ceļa sākums, izlaižot tādus rāmjus kā `Backtrace::new` un `backtrace::trace`.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// Uzņemta kadra versija aizmugurē.
///
/// Šis tips tiek atgriezts kā saraksts no `Backtrace::frames` un attēlo vienu kaudzes rāmi notvertajā aizmugurē.
///
/// # Nepieciešamās funkcijas
///
/// Lai izmantotu šo funkciju, ir jāiespējo `backtrace` crate funkcija `std`, un pēc noklusējuma ir iespējota funkcija `std`.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// Uzņemta simbola versija aizmugurē.
///
/// Šis tips tiek atgriezts kā saraksts no `BacktraceFrame::symbols` un apzīmē simbola metadatus aizmugurē.
///
/// # Nepieciešamās funkcijas
///
/// Lai izmantotu šo funkciju, ir jāiespējo `backtrace` crate funkcija `std`, un pēc noklusējuma ir iespējota funkcija `std`.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// Notver šīs funkcijas izsaukuma vietas aizmuguri, atdodot īpašumā esošu pārstāvniecību.
    ///
    /// Šī funkcija ir noderīga, lai attēlotu aizmugures ceļu kā objektu Rust.Šo atgriezto vērtību var nosūtīt pa pavedieniem un izdrukāt citur, un šīs vērtības mērķis ir pilnībā iekļauties.
    ///
    /// Ņemiet vērā, ka dažās platformās pilnīgas aizmugures iegūšana un atrisināšana var būt ārkārtīgi dārga.
    /// Ja jūsu lietojumprogrammai ir pārāk lielas izmaksas, ieteicams tā vietā izmantot `Backtrace::new_unresolved()`, kas ļauj izvairīties no simbolu izšķiršanas soļa (kas parasti aizņem visilgāk) un ļauj to atlikt uz vēlāku datumu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # Nepieciešamās funkcijas
    ///
    /// Lai izmantotu šo funkciju, ir jāiespējo `backtrace` crate funkcija `std`, un pēc noklusējuma ir iespējota funkcija `std`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // vēlaties pārliecināties, vai šeit ir noņemams rāmis
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// Līdzīgi kā `new`, izņemot to, ka tas neatrisina nevienu simbolu, tas vienkārši notver backtrace kā adrešu sarakstu.
    ///
    /// Vēlāk var tikt izsaukta funkcija `resolve`, lai šīs aizmugures zīmes pārvērstu lasāmos nosaukumos.
    /// Šī funkcija pastāv, jo izšķirtspējas process dažreiz var aizņemt ievērojamu laiku, turpretī jebkura aizmugure var tikt izdrukāta tikai reti.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // nav simbolu nosaukumu
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // tagad ir klāt simbolu nosaukumi
    /// ```
    ///
    /// # Nepieciešamās funkcijas
    ///
    /// Lai izmantotu šo funkciju, ir jāiespējo `backtrace` crate funkcija `std`, un pēc noklusējuma ir iespējota funkcija `std`.
    ///
    ///
    ///
    #[inline(never)] // vēlaties pārliecināties, vai šeit ir noņemams rāmis
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// Atgriež rāmjus no brīža, kad tika uzņemta šī aizmugure.
    ///
    /// Pirmais šīs šķēles ieraksts, visticamāk, ir funkcija `Backtrace::new`, un pēdējais rāmis, visticamāk, ir kaut kas par to, kā šī pavediens vai galvenā funkcija sākās.
    ///
    ///
    /// # Nepieciešamās funkcijas
    ///
    /// Lai izmantotu šo funkciju, ir jāiespējo `backtrace` crate funkcija `std`, un pēc noklusējuma ir iespējota funkcija `std`.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// Ja šī backtrace tika izveidota no `new_unresolved`, šī funkcija atrisinās visas backtrace adreses uz to simboliskajiem nosaukumiem.
    ///
    ///
    /// Ja šī aizmugure ir iepriekš atrisināta vai izveidota, izmantojot `new`, šī funkcija neko nedara.
    ///
    /// # Nepieciešamās funkcijas
    ///
    /// Lai izmantotu šo funkciju, ir jāiespējo `backtrace` crate funkcija `std`, un pēc noklusējuma ir iespējota funkcija `std`.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// Tas pats, kas `Frame::ip`
    ///
    /// # Nepieciešamās funkcijas
    ///
    /// Lai izmantotu šo funkciju, ir jāiespējo `backtrace` crate funkcija `std`, un pēc noklusējuma ir iespējota funkcija `std`.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// Tas pats, kas `Frame::symbol_address`
    ///
    /// # Nepieciešamās funkcijas
    ///
    /// Lai izmantotu šo funkciju, ir jāiespējo `backtrace` crate funkcija `std`, un pēc noklusējuma ir iespējota funkcija `std`.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// Tas pats, kas `Frame::module_base_address`
    ///
    /// # Nepieciešamās funkcijas
    ///
    /// Lai izmantotu šo funkciju, ir jāiespējo `backtrace` crate funkcija `std`, un pēc noklusējuma ir iespējota funkcija `std`.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// Atgriež to simbolu sarakstu, kuriem šis rāmis atbilst.
    ///
    /// Parasti vienā rāmī ir tikai viens simbols, bet dažreiz, ja vienā rāmī ir iekļautas vairākas funkcijas, tiks atgriezti vairāki simboli.
    /// Pirmais uzskaitītais simbols ir "innermost function", bet pēdējais simbols ir visattālākais (pēdējais zvanītājs).
    ///
    /// Ņemiet vērā, ka, ja šis rāmis nāca no neatrisinātas aizmugures, tas parādīs tukšu sarakstu.
    ///
    /// # Nepieciešamās funkcijas
    ///
    /// Lai izmantotu šo funkciju, ir jāiespējo `backtrace` crate funkcija `std`, un pēc noklusējuma ir iespējota funkcija `std`.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// Tas pats, kas `Symbol::name`
    ///
    /// # Nepieciešamās funkcijas
    ///
    /// Lai izmantotu šo funkciju, ir jāiespējo `backtrace` crate funkcija `std`, un pēc noklusējuma ir iespējota funkcija `std`.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// Tas pats, kas `Symbol::addr`
    ///
    /// # Nepieciešamās funkcijas
    ///
    /// Lai izmantotu šo funkciju, ir jāiespējo `backtrace` crate funkcija `std`, un pēc noklusējuma ir iespējota funkcija `std`.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// Tas pats, kas `Symbol::filename`
    ///
    /// # Nepieciešamās funkcijas
    ///
    /// Lai izmantotu šo funkciju, ir jāiespējo `backtrace` crate funkcija `std`, un pēc noklusējuma ir iespējota funkcija `std`.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// Tas pats, kas `Symbol::lineno`
    ///
    /// # Nepieciešamās funkcijas
    ///
    /// Lai izmantotu šo funkciju, ir jāiespējo `backtrace` crate funkcija `std`, un pēc noklusējuma ir iespējota funkcija `std`.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// Tas pats, kas `Symbol::colno`
    ///
    /// # Nepieciešamās funkcijas
    ///
    /// Lai izmantotu šo funkciju, ir jāiespējo `backtrace` crate funkcija `std`, un pēc noklusējuma ir iespējota funkcija `std`.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // Drukājot ceļus, mēs mēģinām noņemt cwd, ja tāds pastāv, pretējā gadījumā mēs vienkārši izdrukājam ceļu, kāds tas ir.
        // Ņemiet vērā, ka mēs to darām tikai īsajam formātam, jo, ja tas ir pilns, mēs, iespējams, vēlamies visu izdrukāt.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}