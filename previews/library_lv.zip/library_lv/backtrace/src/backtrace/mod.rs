use core::ffi::c_void;
use core::fmt;

/// Pārbauda pašreizējo zvanu kaudzīti, nododot visus aktīvos rāmjus paredzētajā slēgumā, lai aprēķinātu kaudzes izsekošanu.
///
/// Šī funkcija ir šīs bibliotēkas darbarīks, aprēķinot programmas kaudzes pēdas.Norādītajai slēgšanai `cb` tiek iegūti `Frame` gadījumi, kas atspoguļo informāciju par šo zvana rāmi kaudzē.
/// Aizvēršanai tiek piešķirti rāmji no augšas uz leju (jaunākos vispirms sauc par funkcijām).
///
/// Slēguma atgriešanās vērtība norāda, vai turpinājums ir jāturpina.`false` atgriešanās vērtība pārtrauks atgriešanos un nekavējoties atgriezīsies.
///
/// Kad `Frame` ir iegūts, iespējams, vēlēsities piezvanīt uz `backtrace::resolve`, lai `ip` (instrukciju rādītājs) vai simbola adresi pārveidotu par `Symbol`, caur kuru var uzzināt vārdu un/vai faila nosaukumu/līnijas numuru.
///
///
/// Ņemiet vērā, ka šī ir salīdzinoši zema līmeņa funkcija, un, ja vēlaties, piemēram, uzņemt aizmugures pēdu, kas jāpārbauda vēlāk, `Backtrace` tips var būt piemērotāks.
///
/// # Nepieciešamās funkcijas
///
/// Lai izmantotu šo funkciju, ir jāiespējo `backtrace` crate funkcija `std`, un pēc noklusējuma ir iespējota funkcija `std`.
///
/// # Panics
///
/// Šī funkcija cenšas nekad panic, bet, ja `cb` nodrošināja panics, tad dažas platformas piespiedīs dubultu panic pārtraukt procesu.
/// Dažās platformās tiek izmantota C bibliotēka, kas iekšēji izmanto atzvanīšanu, kuru nevar atcelt, tāpēc panika no `cb` var izraisīt procesa pārtraukšanu.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // turpināt atgriezenisko izsekošanu
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Tas pats, kas `trace`, tikai nedrošs, jo nav sinhronizēts.
///
/// Šai funkcijai nav sinhronizācijas garantiju, taču tā ir pieejama, ja šīs crate funkcija `std` nav apkopota.
/// Plašāku dokumentāciju un piemērus skatiet funkcijā `trace`.
///
/// # Panics
///
/// Skatiet informāciju par `trace` par brīdinājumiem par `cb` paniku.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// trait, kas attēlo vienu aizmugures pēdas kadru, piekāpās šī crate funkcijai `trace`.
///
/// Izsekošanas funkcijas slēgšana nodrošinās rāmjus, un rāmis faktiski tiek nosūtīts, jo pamatā esošā ieviešana ne vienmēr ir zināma līdz izpildlaika beigām.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Atgriež šī rāmja pašreizējo instrukciju rādītāju.
    ///
    /// Parasti šī ir nākamā rāmī izpildāmā instrukcija, taču ne visās realizācijās tas tiek uzskaitīts ar 100% precizitāti (bet tas parasti ir diezgan tuvu).
    ///
    ///
    /// Ieteicams nodot šo vērtību `backtrace::resolve`, lai to pārvērstu par simbolu nosaukumu.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Atgriež šī rāmja pašreizējo kaudzes rādītāju.
    ///
    /// Gadījumā, ja aizmugurējā daļa nevar atgūt šī rāmja kaudzes rādītāju, tiek atgriezts nulles rādītājs.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Atgriež šīs funkcijas rāmja sākuma simbola adresi.
    ///
    /// Tas mēģinās pārtīt instrukcijas rādītāju, ko `ip` atgriezis funkcijas sākumā, atgriežot šo vērtību.
    ///
    /// Dažos gadījumos aizmugurējie parametri tikai atgriezīs `ip` no šīs funkcijas.
    ///
    /// Atgriezto vērtību dažreiz var izmantot, ja `backtrace::resolve` neizdevās iepriekš norādītajā `ip`.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Atgriež moduļa bāzes adresi, kurai pieder rāmis.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Tam jābūt pirmajam, lai nodrošinātu, ka Miri ir prioritāte pār resursdatora platformu
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // simbolizē tikai dbghelp
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}