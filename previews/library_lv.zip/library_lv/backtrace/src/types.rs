//! Platformas atkarīgie veidi.

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::borrow::Cow;
        use std::fmt;
        use std::path::PathBuf;
        use std::prelude::v1::*;
        use std::str;
    }
}

/// Platformas neatkarīga virknes attēlojums.
/// Strādājot ar iespējotu `std`, ieteicams izmantot ērtības, lai nodrošinātu reklāmguvumus `std` tipiem.
///
#[derive(Debug)]
pub enum BytesOrWideString<'a> {
    /// Šķēle, kas parasti tiek nodrošināta uz Unix platformām.
    Bytes(&'a [u8]),
    /// Plašas virknes parasti no Windows.
    Wide(&'a [u16]),
}

#[cfg(feature = "std")]
impl<'a> BytesOrWideString<'a> {
    /// Lossy pārveido par `Cow<str>`, piešķir, ja `Bytes` nav derīgs UTF-8 vai ja `BytesOrWideString` ir `Wide`.
    ///
    /// # Nepieciešamās funkcijas
    ///
    /// Lai izmantotu šo funkciju, ir jāiespējo `backtrace` crate funkcija `std`, un pēc noklusējuma ir iespējota funkcija `std`.
    ///
    ///
    pub fn to_str_lossy(&self) -> Cow<'a, str> {
        use self::BytesOrWideString::*;

        match self {
            &Bytes(slice) => String::from_utf8_lossy(slice),
            &Wide(wide) => Cow::Owned(String::from_utf16_lossy(wide)),
        }
    }

    /// Nodrošina `BytesOrWideString` `Path` attēlojumu.
    ///
    /// # Nepieciešamās funkcijas
    ///
    /// Lai izmantotu šo funkciju, ir jāiespējo `backtrace` crate funkcija `std`, un pēc noklusējuma ir iespējota funkcija `std`.
    ///
    pub fn into_path_buf(self) -> PathBuf {
        #[cfg(unix)]
        {
            use std::ffi::OsStr;
            use std::os::unix::ffi::OsStrExt;

            if let BytesOrWideString::Bytes(slice) = self {
                return PathBuf::from(OsStr::from_bytes(slice));
            }
        }

        #[cfg(windows)]
        {
            use std::ffi::OsString;
            use std::os::windows::ffi::OsStringExt;

            if let BytesOrWideString::Wide(slice) = self {
                return PathBuf::from(OsString::from_wide(slice));
            }
        }

        if let BytesOrWideString::Bytes(b) = self {
            if let Ok(s) = str::from_utf8(b) {
                return PathBuf::from(s);
            }
        }
        unreachable!()
    }
}

#[cfg(feature = "std")]
impl<'a> fmt::Display for BytesOrWideString<'a> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.to_str_lossy().fmt(f)
    }
}