//! Modulis, kas palīdz pārvaldīt dbghelp saistījumus Windows
//!
//! Windows aizmugures pēdas (vismaz MSVC) lielā mērā tiek darbinātas, izmantojot `dbghelp.dll` un dažādas tajā ietvertās funkcijas.
//! Šīs funkcijas pašlaik tiek ielādētas *dinamiski*, nevis tiek saistītas ar statisko `dbghelp.dll`.
//! Šobrīd to veic standarta bibliotēka (un teorētiski tā ir nepieciešama), taču tas ir mēģinājums palīdzēt samazināt bibliotēkas statiskās dll atkarības, jo backtraces parasti ir diezgan neobligātas.
//!
//! Tas nozīmē, ka `dbghelp.dll` gandrīz vienmēr veiksmīgi ielādē Windows.
//!
//! Tomēr ņemiet vērā, ka, tā kā mēs visu šo atbalstu ielādējam dinamiski, mēs faktiski nevaram izmantot neapstrādātas definīcijas `winapi`, bet mums pašiem jādefinē funkciju rādītāju veidi un tas jāizmanto.
//! Mēs īsti nevēlamies nodarboties ar Winapi dublēšanu, tāpēc mums ir Cargo funkcija `verify-winapi`, kas apgalvo, ka visi stiprinājumi atbilst WinAPī esošajiem un šī funkcija ir iespējota CI.
//!
//! Visbeidzot, šeit jūs atzīmēsiet, ka `dbghelp.dll` dll nekad netiek izkrauts, un tas pašlaik ir tīši.
//! Domājam, ka mēs varam to globāli saglabāt kešatmiņā un izmantot starp zvaniem uz API, izvairoties no dārga loads/unloads.
//! Ja tā ir noplūdes detektoru problēma vai kas tamlīdzīgs, mēs tur nokļūstot varam šķērsot tiltu.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Darbs ap `SymGetOptions` un `SymSetOptions` nav atrodams pašā Winapi.
// Pretējā gadījumā to izmanto tikai tad, ja mēs vēlreiz pārbaudām veidus pret winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Winapi vēl nav definēts
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Tas ir definēts WinAPI, bet tas nav pareizi (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Winapi vēl nav definēts
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Šo makro izmanto, lai definētu `Dbghelp` struktūru, kas iekšēji satur visus funkciju rādītājus, kurus mēs varētu ielādēt.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// `dbghelp.dll` ielādētais DLL
            dll: HMODULE,

            // Katrs funkcijas rādītājs katrai funkcijai, kuru mēs varētu izmantot
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Sākotnēji mēs neesam ielādējuši DLL
            dll: 0 as *mut _,
            // Sākotnēji visas funkcijas ir iestatītas uz nulli, lai teiktu, ka tās ir dinamiski jāielādē.
            //
            $($name: 0,)*
        };

        // Ērtības typedef katram funkciju tipam.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Mēģinājumi atvērt `dbghelp.dll`.
            /// Atgriež panākumus, ja tas darbojas, vai kļūdu, ja `LoadLibraryW` neizdodas.
            ///
            /// Panics, ja bibliotēka jau ir ielādēta.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Funkcija katrai metodei, kuru mēs vēlētos izmantot.
            // Kad to izsauks, tas nolasīs kešatmiņā saglabāto funkciju rādītāju vai ielādēs to un atgriezīs ielādēto vērtību.
            // Tiek apgalvots, ka panākumi ir slodzes.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Ērtības starpniekserveris, lai izmantotu tīrīšanas bloķētājus, lai atsauktos uz dbghelp funkcijām.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Inicializējiet visu nepieciešamo atbalstu, lai piekļūtu `dbghelp` API funkcijām no šī crate.
///
///
/// Ņemiet vērā, ka šī funkcija ir **droša**, tai iekšēji ir sava sinhronizācija.
/// Ņemiet vērā arī to, ka šo funkciju var droši izsaukt vairākas reizes rekursīvi.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Pirmā lieta, kas mums jādara, ir sinhronizēt šo funkciju.To var izsaukt vienlaicīgi no citiem pavedieniem vai rekursīvi vienā pavedienā.
        // Ņemiet vērā, ka tas tomēr ir sarežģītāk, jo tas, ko mēs šeit izmantojam, `dbghelp`,*arī* šajā procesā ir jāsinhronizē ar visiem citiem zvanītājiem uz `dbghelp`.
        //
        // Parasti tajā pašā procesā nav tik daudz zvanu uz `dbghelp`, un mēs droši varam droši uzskatīt, ka tikai mēs tam piekļūstam.
        // Tomēr ir viens cits primārais lietotājs, par kuru mums jāuztraucas, ironiski mēs paši, bet standarta bibliotēkā.
        // Rust standarta bibliotēka ir atkarīga no šī crate, lai nodrošinātu backtrace atbalstu, un šī crate pastāv arī uz crates.io.
        // Tas nozīmē, ka, ja standarta bibliotēka drukā panic atpakaļsekošanu, tā var sacensties ar šo crate, kas nāk no crates.io, izraisot defektus.
        //
        // Lai palīdzētu atrisināt šo sinhronizācijas problēmu, mēs šeit izmantojam Windows specifisku triku (galu galā tas ir Windows specifisks sinhronizācijas ierobežojums).
        // Lai aizsargātu šo zvanu, mēs izveidojam *session-local* nosaukumu mutex.
        // Mērķis ir tāds, ka standarta bibliotēkai un šai crate nav jādalās ar Rust līmeņa API, lai šeit sinhronizētos, bet tā vietā viņi var strādāt aizkulisēs, lai pārliecinātos, ka viņi sinhronizē viens ar otru.
        //
        // Tādā veidā, kad šī funkcija tiek izsaukta caur standarta bibliotēku vai caur crates.io, mēs varam būt pārliecināti, ka tiek iegūts tas pats mutekss.
        //
        // Tātad tas viss nozīmē, ka pirmā lieta, ko mēs šeit darām, ir atomu veidā izveidot `HANDLE`, kas ir nosaukts mutex uz Windows.
        // Mēs mazliet sinhronizējamies ar citiem pavedieniem, kas koplieto šo funkciju, un nodrošinām, ka katram šīs funkcijas gadījumam tiek izveidots tikai viens rokturis.
        // Ņemiet vērā, ka rokturis nekad netiek aizvērts, kad tas tiek glabāts globālajā.
        //
        // Pēc tam, kad mēs faktiski esam aizgājuši slēdzeni, mēs to vienkārši iegūstam, un mūsu izlaistais `Init` rokturis būs atbildīgs par tā nomest galu galā.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Labi, phew!Tagad, kad mēs visi esam droši sinhronizēti, sāksim faktiski visu apstrādāt.
        // Vispirms mums jānodrošina, lai `dbghelp.dll` patiešām tiktu ielādēts šajā procesā.
        // Mēs to darām dinamiski, lai izvairītos no statiskas atkarības.
        // Vēsturiski tas tika darīts, lai apietu dīvainus saistīšanas jautājumus, un tas ir paredzēts, lai bināros failus padarītu mazliet pārnēsājamākus, jo tas lielā mērā ir tikai atkļūdošanas lietderība.
        //
        //
        // Kad esam atvēruši `dbghelp.dll`, tajā ir jāizsauc dažas inicializācijas funkcijas, un tas ir sīkāk aprakstīts tālāk.
        // Tomēr mēs to darām tikai vienu reizi, tāpēc mums ir globāls loģiskais skaitlis, kas norāda, vai mēs vēl esam pabeiguši vai nē.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Pārliecinieties, vai ir iestatīts karodziņš `SYMOPT_DEFERRED_LOADS`, jo saskaņā ar pašu MSVC dokumentiem par šo: "This is the fastest, most efficient way to use the symbol handler.", tāpēc darīsim to!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Faktiski inicializējiet simbolus ar MSVC.Ņemiet vērā, ka tas var neizdoties, taču mēs to ignorējam.
        // Šim par sevi nav daudz iepriekšējas mākslas, bet šķiet, ka LLVM iekšēji ignorē atgriešanās vērtību šeit, un viena no LLVM sanitizer bibliotēkām izdrukā biedējošu brīdinājumu, ja tas neizdodas, bet būtībā to ilgtermiņā ignorē.
        //
        //
        // Viens gadījums, kas Rust rodas daudz, ir tas, ka gan standarta bibliotēka, gan šī crate operētājsistēmā crates.io vēlas sacensties par `SymInitializeW`.
        // Standarta bibliotēka vēsturiski lielāko daļu laika vēlējās inicializēt un pēc tam veikt tīrīšanu, taču tagad, kad tā izmanto šo crate, tas nozīmē, ka kāds vispirms nonāks pie inicializācijas, bet otrs uzņems šo inicializāciju.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}