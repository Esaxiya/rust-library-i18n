// pašlaik izmanto tikai Linux, tāpēc atļaujiet beigtu kodu izmantot citur
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Vienkāršs arēnas sadalītājs baitu buferiem.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Piešķir noteikta lieluma buferi un atgriež maināmu atsauci uz to.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // DROŠĪBA: šī ir vienīgā funkcija, kas jebkad izveido maināmu
        // atsauce uz `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // DROŠĪBA: mēs nekad neizņemam elementus no `self.buffers`, tāpēc ir atsauce
        // jebkura bufera iekšienē esošie dati dzīvos tik ilgi, kamēr to darīs `self`.
        &mut buffers[i]
    }
}