//! Simbolizācijas stratēģija, izmantojot DWARF parsēšanas kodu libbacktrace.
//!
//! Libbacktrace C bibliotēka, kas parasti tiek izplatīta ar gcc, atbalsta ne tikai aizmugures izsekošanu (ko mēs faktiski neizmantojam), bet arī simbolizē aizmugurējo pēdu un apstrādā rūķu atkļūdošanas informāciju par tādām lietām kā, piemēram, iespiestie rāmji un kas cits.
//!
//!
//! Tas ir samērā sarežģīti, jo šeit ir daudz dažādu problēmu, taču pamatideja ir šāda:
//!
//! * Vispirms mēs izsaucam `backtrace_syminfo`.Tas, ja mēs varam, iegūst informāciju par simboliem no dinamisko simbolu tabulas.
//! * Tālāk mēs saucam `backtrace_pcinfo`.Tas parsēs atkļūdošanas tabulas, ja tās ir pieejamas, un ļaus mums atgūt informāciju par iekļautajiem rāmjiem, failu nosaukumiem, rindu numuriem utt.
//!
//! Par punduru tabulu iekļaušanu libbacktrace ir daudz viltību, taču, cerams, ka tas vēl nav pasaules gals un ir pietiekami skaidrs, lasot tālāk.
//!
//! Šī ir noklusējuma simbolizācijas stratēģija platformām, kas nav MSVC un OSX.Lai gan libstd, tā ir OSX noklusējuma stratēģija.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Ja iespējams, dodiet priekšroku `function` nosaukumam, kas nāk no debuginfo un parasti var būt precīzāks, piemēram, iekšējiem rāmjiem.
                // Ja tā nav, atgriezieties pie simbolu tabulas nosaukuma, kas norādīts `symname`.
                //
                // Ņemiet vērā, ka dažreiz `function` var justies nedaudz mazāk precīzs, piemēram, tas ir norādīts kā `try<i32,closure>`, nevis `std::panicking::try::do_call`.
                //
                // Nav īsti skaidrs, kāpēc, bet kopumā `function` nosaukums šķiet precīzāks.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // nedari neko tagad
}

/// `data` rādītāja tips, kas pārsūtīts uz `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Kad šis atsaukums ir izsaukts no `backtrace_syminfo`, kad mēs sākam atrisināt, mēs ejam tālāk, lai izsauktu `backtrace_pcinfo`.
    // `backtrace_pcinfo` funkcija izmantos atkļūdošanas informāciju un mēģinās veikt tādas darbības kā file/line informācijas, kā arī ielīmēto rāmju atjaunošana.
    // Tomēr ņemiet vērā, ka `backtrace_pcinfo` var neizdoties vai nedarīt daudz, ja nav atkļūdošanas informācijas, tādēļ, ja tas notiks, mēs noteikti piezvanīsim ar atzīmi vismaz ar vienu simbolu no `syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// `data` rādītāja tips, kas pārsūtīts uz `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// Libbacktrace API atbalsta stāvokļa izveidošanu, taču tas neatbalsta stāvokļa iznīcināšanu.
// Es personīgi to uztveru tā, ka ir paredzēts izveidot valsti un pēc tam dzīvot mūžīgi.
//
// Es labprāt reģistrētu at_exit() apdarinātāju, kas attīra šo stāvokli, taču libbacktrace nenodrošina iespēju to izdarīt.
//
// Ņemot vērā šos ierobežojumus, šai funkcijai ir statiski kešatmiņā saglabāts stāvoklis, kas tiek aprēķināts pirmo reizi, kad tas tiek pieprasīts.
//
// Atcerieties, ka aizmuguriskā izsekošana notiek sērijveidā (viena globālā atslēga).
//
// Ņemiet vērā, ka sinhronizācijas trūkums šeit ir saistīts ar prasību, ka `resolve` ir ārēji sinhronizēts.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Neizmantojiet libbacktrace drošās iespējas, jo mēs to vienmēr saucam sinhronizētā veidā.
        //
        0,
        error_cb,
        ptr::null_mut(), // nav papildu datu
    );

    return STATE;

    // Ņemiet vērā, ka, lai libbacktrace darbotos vispār, ir jāatrod DWARF atkļūdošanas informācija pašreizējam izpildāmajam failam.Parasti to dara, izmantojot vairākus mehānismus, tostarp, bet ne tikai:
    //
    // * /proc/self/exe atbalstītajās platformās
    // * Veidojot stāvokli, faila nosaukums tika nodots nepārprotami
    //
    // Libbacktrace bibliotēka ir liels daudzums C koda.Tas, protams, nozīmē, ka tam ir atmiņas drošības ievainojamības, it īpaši, ja tiek apstrādāti nepareizi veidoti atkļūdošanas dati.
    // Libstd vēsturiski ir saskāries ar daudzām no tām.
    //
    // Ja tiek izmantots /proc/self/exe, mēs parasti tos varam ignorēt, jo mēs pieņemam, ka libbacktrace ir "mostly correct" un citādi nedara dīvainas lietas ar rūķu atkļūdošanas informāciju "attempted to be correct".
    //
    //
    // Ja mēs tomēr nododam faila nosaukumu, tad tas ir iespējams dažās platformās (piemēram, BSD), kur ļaunprātīgs dalībnieks var izraisīt patvaļīgu failu ievietošanu šajā vietā.
    // Tas nozīmē, ka, ja mēs sakām libbacktrace par faila nosaukumu, tas, iespējams, izmanto patvaļīgu failu, kas, iespējams, izraisa segfaults.
    // Ja mēs neko nestāsta libbacktrace, tad tas neko nedarīs platformās, kas neatbalsta tādus ceļus kā /proc/self/exe!
    //
    // Ņemot vērā visu, ko mēs cenšamies pēc iespējas vairāk *nepieļaut* faila nosaukumā, bet tas jādara platformās, kas /proc/self/exe neatbalsta vispār.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Ņemiet vērā, ka ideālā gadījumā mēs izmantotu `std::env::current_exe`, taču šeit nevaram pieprasīt `std`.
            //
            // Izmantojiet `_NSGetExecutablePath`, lai ielādētu pašreizējo izpildāmo ceļu statiskā apgabalā (kas, ja tas ir pārāk mazs, vienkārši atmest).
            //
            //
            // Ņemiet vērā, ka mēs šeit nopietni paļaujamies uz libbacktrace, lai nenomirtu no bojātiem izpildāmajiem failiem, taču tas noteikti to dara
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows ir failu atvēršanas režīms, kur pēc atvēršanas to nevar izdzēst.
            // Tas ir tas, ko mēs šeit vēlamies, jo mēs vēlamies nodrošināt, ka mūsu izpildāmais fails nemainās no mums zem tā, kad mēs to nododam libbacktrace, cerams, ka mazinās spēja patvaļīgus datus nodot libbacktrace (kas var tikt nepareizi apstrādāta).
            //
            //
            // Ņemot vērā to, ka mēs šeit mazliet dejojam, lai mēģinātu iegūt sava veida slēdzeni savam tēlam:
            //
            // * Saņemiet pašreizējā procesa rokturi, ielādējiet tā faila nosaukumu.
            // * Atveriet failu ar šo faila nosaukumu ar labajiem karodziņiem.
            // * Pārlādējiet pašreizējā procesa faila nosaukumu, pārliecinoties, ka tas ir vienāds
            //
            // Ja tas viss izdosies, mēs teorētiski patiešām esam atvēruši mūsu procesa failu un esam garantēti, ka tas nemainīsies.FWIW, ka tas ir vēsturiski nokopēts no libstd, tāpēc šī ir mana labākā notikušā interpretācija.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Tas dzīvo statiskajā atmiņā, lai mēs varētu to atgriezt ..
                static mut BUF: [i8; N] = [0; N];
                // ... un tas dzīvo uz steka, jo tas ir īslaicīgi
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // ar nolūku nopludināt šeit `handle`, jo, ja tas ir atvērts, mums jāsaglabā šī faila nosaukuma bloķēšana.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Mēs vēlamies atgriezt šķēli, kas ir izbeigta ar nul, tādēļ, ja viss tika aizpildīts un tas ir vienāds ar kopējo garumu, pielīdziniet to neveiksmei.
                //
                //
                // Pretējā gadījumā, atgriežot panākumus, pārliecinieties, vai nul baits ir iekļauts šķēlē.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // backtrace kļūdas šobrīd tiek slauktas zem paklāja
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Zvaniet uz `backtrace_syminfo` API, kurai (izlasot kodu) vajadzētu izsaukt `syminfo_cb` tieši vienu reizi (vai arī neizdoties, iespējams, ar kļūdu).
    // Pēc tam mēs rīkojamies vairāk ar `syminfo_cb`.
    //
    // Ņemiet vērā, ka mēs to darām, jo `syminfo` izmantos simbolu tabulu, meklējot simbolu nosaukumus, pat ja binārā nav atkļūdošanas informācijas.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}