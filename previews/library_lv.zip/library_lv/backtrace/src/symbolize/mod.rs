use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Atrisiniet adresi simbolam, nododot simbolu norādītajam slēgumam.
///
/// Šī funkcija meklēs norādīto adresi tādās jomās kā vietējā simbolu tabula, dinamisko simbolu tabula vai DWARF atkļūdošanas informācija (atkarībā no aktivizētās ieviešanas), lai atrastu simbolus, kurus iegūt.
///
///
/// Slēgšanu nevar izsaukt, ja izšķirtspēju nevarēja veikt, un to var arī izsaukt vairāk nekā vienu reizi, ja iestrādātas funkcijas.
///
/// Iegūtie simboli apzīmē izpildi norādītajā `addr`, atgriežot file/line pārus šai adresei (ja pieejami).
///
/// Ņemiet vērā, ka, ja jums ir `Frame`, ieteicams izmantot šo funkciju `resolve_frame`.
///
/// # Nepieciešamās funkcijas
///
/// Lai izmantotu šo funkciju, ir jāiespējo `backtrace` crate funkcija `std`, un pēc noklusējuma ir iespējota funkcija `std`.
///
/// # Panics
///
/// Šī funkcija cenšas nekad panic, bet, ja `cb` nodrošināja panics, tad dažas platformas piespiedīs dubultu panic pārtraukt procesu.
/// Dažās platformās tiek izmantota C bibliotēka, kas iekšēji izmanto atzvanīšanu, kuru nevar atcelt, tāpēc panika no `cb` var izraisīt procesa pārtraukšanu.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // skatieties tikai uz augšējo rāmi
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Atrisiniet iepriekš uzņemto rāmi uz simbolu, nododot simbolu norādītajai aizvēršanai.
///
/// Šis functin veic to pašu funkciju kā `resolve`, izņemot to, ka adreses vietā kā argumentu tas izmanto `Frame`.
/// Tas var ļaut dažām platformām ieviest atpakaļ izsekošanu, lai sniegtu precīzāku informāciju par simboliem vai, piemēram, informāciju par iekšējiem rāmjiem.
///
/// Ieteicams to izmantot, ja varat.
///
/// # Nepieciešamās funkcijas
///
/// Lai izmantotu šo funkciju, ir jāiespējo `backtrace` crate funkcija `std`, un pēc noklusējuma ir iespējota funkcija `std`.
///
/// # Panics
///
/// Šī funkcija cenšas nekad panic, bet, ja `cb` nodrošināja panics, tad dažas platformas piespiedīs dubultu panic pārtraukt procesu.
/// Dažās platformās tiek izmantota C bibliotēka, kas iekšēji izmanto atzvanīšanu, kuru nevar atcelt, tāpēc panika no `cb` var izraisīt procesa pārtraukšanu.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // skatieties tikai uz augšējo rāmi
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// IP vērtības no kaudzes rāmjiem parasti ir (always?) instrukcija *pēc* zvana, kas ir faktiskā kaudzes izsekošana.
// Simbolizējot to, filename/line numurs ir priekšā un, iespējams, tukšumā, ja tas ir tuvu funkcijas beigām.
//
// Šķiet, ka tas vienmēr notiek visās platformās, tāpēc mēs vienmēr atņemam vienu no atrisinātā ip, lai atrisinātu to ar iepriekšējo zvana instrukciju, nevis uz to, ka tiek atgriezta instrukcija.
//
//
// Ideālā gadījumā mēs to nedarītu.
// Ideālā gadījumā mēs pieprasīsim, lai šeit `resolve` API zvanītāji manuāli veiktu -1 un kontu, ka viņi vēlas informāciju par atrašanās vietu *iepriekšējai* instrukcijai, nevis pašreizējai.
// Ideālā gadījumā mēs arī parādītu `Frame`, ja mēs patiešām esam nākamās instrukcijas vai pašreizējās adreses adrese.
//
// Pagaidām gan tas ir diezgan nišas jautājums, tāpēc mēs tikai iekšēji vienmēr to atņemam.
// Patērētājiem jāturpina strādāt un gūt diezgan labus rezultātus, tāpēc mums vajadzētu būt pietiekami labiem.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Tas pats, kas `resolve`, tikai nedrošs, jo nav sinhronizēts.
///
/// Šai funkcijai nav sinhronizācijas garantiju, taču tā ir pieejama, ja šīs crate funkcija `std` nav apkopota.
/// Plašāku dokumentāciju un piemērus skatiet funkcijā `resolve`.
///
/// # Panics
///
/// Skatiet informāciju par `resolve` par brīdinājumiem par `cb` paniku.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Tāds pats kā `resolve_frame`, tikai nedrošs, jo nav sinhronizēts.
///
/// Šai funkcijai nav sinhronizācijas garantiju, taču tā ir pieejama, ja šīs crate funkcija `std` nav apkopota.
/// Plašāku dokumentāciju un piemērus skatiet funkcijā `resolve_frame`.
///
/// # Panics
///
/// Skatiet informāciju par `resolve_frame` par brīdinājumiem par `cb` paniku.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// trait, kas attēlo faila simbola izšķirtspēju.
///
/// Šis trait tiek piešķirts kā trait objekts `backtrace::resolve` funkcijai piešķirtajam slēgumam, un tas tiek faktiski nosūtīts, jo nav zināms, kura ieviešana ir aiz tā.
///
///
/// Simbols var sniegt konteksta informāciju par funkciju, piemēram, nosaukumu, faila nosaukumu, rindas numuru, precīzu adresi utt.
/// Ne visa informācija vienmēr ir pieejama simbolā, tāpēc visas metodes atgriež `Option`.
///
///
pub struct Symbol {
    // TODO: šis mūža garums ir jāpaglabā līdz `Symbol`,
    // bet tas šobrīd ir pārsteidzošas izmaiņas.
    // Pagaidām tas ir droši, jo `Symbol` vienmēr izdod tikai ar atsauci un to nevar klonēt.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Atgriež šīs funkcijas nosaukumu.
    ///
    /// Atgriezto struktūru var izmantot, lai vaicātu dažādas īpašības par simbola nosaukumu:
    ///
    ///
    /// * `Display` ieviešana izdrukās demangled simbolu.
    /// * Var piekļūt neapstrādātai simbola `str` vērtībai (ja tā ir derīga utf-8).
    /// * Var piekļūt neapstrādātiem baitiem simbola nosaukumam.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Atgriež šīs funkcijas sākuma adresi.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Atgriež neapstrādāto faila nosaukumu kā šķēli.
    /// Tas galvenokārt ir noderīgi `no_std` vidēs.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Atgriež kolonnas numuru, kur šis simbols pašlaik tiek izpildīts.
    ///
    /// Pašlaik tikai gimli šeit sniedz vērtību un pat tad, ja `filename` atgriež `Some`, un tāpēc uz to attiecīgi attiecas līdzīgas atrunas.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Atgriež līnijas numuru vietai, kur šis simbols pašlaik tiek izpildīts.
    ///
    /// Šī atgriešanās vērtība parasti ir `Some`, ja `filename` atgriež `Some`, un līdz ar to uz to attiecas līdzīgas atrunas.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Atgriež faila nosaukumu, kur šī funkcija tika definēta.
    ///
    /// Tas pašlaik ir pieejams tikai tad, kad tiek izmantota libbacktrace vai gimli (piem.,
    /// unix platformas citi) un kad binārs tiek apkopots ar debuginfo.
    /// Ja neviens no šiem nosacījumiem nav izpildīts, tas, iespējams, atgriezīs `None`.
    ///
    /// # Nepieciešamās funkcijas
    ///
    /// Lai izmantotu šo funkciju, ir jāiespējo `backtrace` crate funkcija `std`, un pēc noklusējuma ir iespējota funkcija `std`.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Varbūt parsēts C++ simbols, ja neizdevās parsēt sajaukto simbolu kā Rust.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Pārliecinieties, ka saglabājat šo nulles lielumu, lai atspējojot `cpp_demangle` funkciju, nebūtu jāmaksā.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Iesaiņojums ap simbola nosaukumu, lai ergonomiski piekļūtu izjauktajam nosaukumam, neapstrādātajiem baitiem, neapstrādātajai virknei utt.
///
// Atļaut beigtu kodu gadījumos, kad funkcija `cpp_demangle` nav iespējota.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Izveido jaunu simbola nosaukumu no neapstrādātiem pamatā esošajiem baitiem.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Atgriež neapstrādāto (mangled) simbola nosaukumu kā `str`, ja simbols ir derīgs utf-8.
    ///
    /// Izmantojiet `Display` ieviešanu, ja vēlaties izjauktu versiju.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Atgriež neapstrādāta simbola nosaukumu kā baitu sarakstu
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // To var izdrukāt, ja izjauktais simbols patiesībā nav derīgs, tāpēc rīkojieties ar kļūdu šeit graciozi, neizplatot to uz āru.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Mēģiniet atgūt kešatmiņā saglabāto atmiņu, kas izmantota adrešu simbolizēšanai.
///
/// Šī metode mēģinās atbrīvot visas globālās datu struktūras, kas citādi ir glabātas kešatmiņā visā pasaulē vai pavedienā, kas parasti atspoguļo parsētu DWARF informāciju vai tamlīdzīgu.
///
///
/// # Caveats
///
/// Lai gan šī funkcija vienmēr ir pieejama, tā faktiski neko nedara lielākajā daļā ieviešanas gadījumu.
/// Bibliotēkas, piemēram, dbghelp vai libbacktrace, nenodrošina iespējas sadalīt stāvokli un pārvaldīt piešķirto atmiņu.
/// Pagaidām šīs crate iezīme `gimli-symbolize` ir vienīgā funkcija, kurai šai funkcijai ir kāda ietekme.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}