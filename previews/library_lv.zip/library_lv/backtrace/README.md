# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Bibliotēka Rust aizmugures pēdu iegūšanai izpildlaika laikā.
Šīs bibliotēkas mērķis ir uzlabot standarta bibliotēkas atbalstu, nodrošinot programmatisku saskarni darbam, taču tā atbalsta arī vienkāršu pašreizējās aizmugures, piemēram, libstd's panics, drukāšanu.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Lai vienkārši notvertu aizmugures pēdas un atliktu ar to saistīto darbību atlikšanu vēlāk, varat izmantot augstākā līmeņa `Backtrace` tipu.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Tomēr, ja vēlaties vairāk neapstrādātas piekļuves faktiskajai izsekošanas funkcionalitātei, varat tieši izmantot funkcijas `trace` un `resolve`.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Atrisiniet šo norādījumu uz simbola nosaukumu
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // turpiniet iet uz nākamo kadru
    });
}
```

# License

Šis projekts ir licencēts saskaņā ar kādu no

 * Apache licence, versija 2.0, ([LICENSE-APACHE](LICENSE-APACHE) vai http://www.apache.org/licenses/LICENSE-2.0)
 * MIT licence ([LICENSE-MIT](LICENSE-MIT) vai http://opensource.org/licenses/MIT)

pēc jūsu izvēles.

### Contribution

Ja vien nepārprotami nenorādīsiet citādi, jebkurš ieguldījums, ko jūs esat apzināti iesniedzis iekļaušanai backtrace-rs, kā noteikts Apache-2.0 licencē, būs divējāda licence, kā norādīts iepriekš, bez jebkādiem papildu noteikumiem vai nosacījumiem.







