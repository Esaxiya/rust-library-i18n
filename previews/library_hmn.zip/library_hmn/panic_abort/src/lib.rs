//! Yuav ua raws li Rust panics ntawm txheej txheem aborts
//!
//! Thaum muab piv rau qhov kev siv ntawm kev sib tsoo, qhov no crate yog *ntau* yooj yim!Uas qab hais tias, nws yog tsis heev li ntau yam, tiam sis ntawm no mus!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" lub payload thiab shim rau cov ho nyob rau platform nyob rau hauv nqe lus nug.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // hu std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // Ntawm Windows, siv tus txheej txheem tshwj xeeb __fastfail mechanism.Hauv Windows 8 thiab tom qab, qhov no yuav tso tseg txoj kev tam sim ntawd yam tsis muaj kev sib tham nrog txhua tus txheej txheem tshwj xeeb kev xa khoom.
            // Hauv cov qauv ua ntej ntawm Windows, cov kab lus ntawm cov lus qhia no yuav raug kho raws li kev ua txhaum kev nkag mus, rhuav tshem cov txheej txheem tab sis tsis tas yuav hla txhua tus tuav cov zam.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: qhov no yog tib siv raws li nyob rau hauv libstd lub `abort_internal`
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// Qhov no ... yog me ntsis ntawm qhov tsis tseeb.Lub tl; dr;yog tias qhov no yog qhov yuav tsum tau txuas txuas kom raug, qhov piav qhia ntev dua hauv qab no.
//
// Txoj cai tam sim no lub binaries ntawm libcore/libstd tias peb nkoj yog tag nrho cov muab tso ua ke nrog `-C panic=unwind`.Qhov no yog ua los xyuas kom meej tias binaries muaj qhov ua siab tshaj plaws nrog ntau yam xwm txheej li sai tau.
// Lub compiler, txawm li cas los, yuav tsum tau ib tug "personality function" rau tag nrho cov kev khiav dej num tso ua ke nrog `-C panic=unwind`.Tus cwj pwm kev coj ua no yog hardcoded mus rau lub cim `rust_eh_personality` thiab tau txhais los ntawm `eh_personality` lang yam.
//
// So...
// vim li cas tsis tsuas yog txhais cov khoom lang ntawm no?Cov nqe lus nug zoo!Txoj kev uas panic runtimes tau sib txuas nrog yog qhov tseeb me me nyob rau hauv uas lawv nyob "sort of" hauv khw crate lub khw, tab sis tsuas yog ua tau txuas yog tias lwm qhov tsis tau txuas.
//
// Qhov no xaus cov ntsiab lus hais tias ob qho no crate thiab cov panic_unwind crate tuaj yeem tshwm nyob rau hauv lub khw crate lub khw, thiab yog tias ob qho tib si txhais cov khoom `eh_personality` lang ces qhov ntawd mam li tsoo yuam kev.
//
// Txhawm rau lis cov ntaub ntawv no tsuas yog xav kom `eh_personality` txhais yog tias panic runtime raug txuas rau hauv yog lub sijhawm sib tsoo, thiab txwv tsis pub nws tsis tas yuav tsum txhais (yog li ntawd).
// Nyob rau hauv cov ntaub ntawv no, Txawm li cas los, qhov no cov tsev qiv ntawv cia li hais lub cim thiaj li muaj tsawg kawg yog ib co cwm pwm qhov chaw.
//
// Qhov tseem ceeb lub cim no tsuas yog txhais tau kom tau txais kab xov tooj txog libcore/libstd binaries, tab sis nws yuav tsum tsis txhob raug hu ua peb tsis txuas hauv qhov tsis lom zem lub sijhawm.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // Nyob rau x86_64-pc-windows-gnu peb siv peb tus kheej cwm pwm nuj nqi uas xav tau kev pab rov qab mus `ExceptionContinueSearch` raws li peb nyob nraum dua rau tag nrho peb ntas.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // Zoo ib yam li saum toj no, qhov no sib haum rau `eh_catch_typeinfo` lang yam khoom uas tsuas yog siv rau ntawm Emscripten tam sim no.
    //
    // Vim panics tsis tsim kom muaj kev zam thiab txawv teb chaws tsis tau tam sim no UB nrog -C panic=abort (txawm hais tias qhov no yuav raug pauv), txhua qhov kev hu xov tooj tsis paub yuav tsis siv hom typeinfo no.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // Ob qho no tau hu los ntawm peb cov khoom pib ntawm i686-pc-windows-gnu, tab sis lawv tsis tas yuav ua dab tsi yog li lub cev yog nops.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}