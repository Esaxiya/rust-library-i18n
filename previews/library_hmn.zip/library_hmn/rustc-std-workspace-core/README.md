# Lub `rustc-std-workspace-core` crate

crate no yog ib qho shim thiab khoob crate uas tsuas yog nyob ntawm `libcore` thiab xa tag nrho nws cov ntsiab lus.
Lub crate yog lub crux ntawm empowering rau tus txheej txheem tsev qiv ntawv rau nyob ntawm seb crates los ntawm crates.io

Crates rau crates.io hais tias tus txheej txheem tsev qiv ntawv yog nyob ntawm seb yuav tsum tau nyob ntawm seb cov `rustc-std-workspace-core` crate los ntawm crates.io, uas yog tas.

Peb siv `[patch]` kom hla nws mus rau crate hauv qhov chaw cia khoom no.
Raws li qhov tshwm sim, crates ntawm crates.io yuav kos ib tus neeg edge mus rau `libcore`, cov version tau hais tseg hauv lub chaw cia khoom no.
Uas yuav tsum tau kos tag nrho cov quav npoo los xyuas kom meej Cargo ua crates ntse!

Nco ntsoov tias crates rau crates.io yuav tsum nyob ntawm seb qhov no crate nrog lub npe `core` rau txhua yam mus ua hauj lwm kom raug.Yuav kom ua li ntawd lawv tuaj yeem siv:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Los ntawm kev siv ntawm cov `package` tseem ceeb lub crate yog renamed mus rau `core`, qab hau nws mam li saib zoo li

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

thaum Cargo thov lub compiler, satisfying lub implicit `extern crate core` qhia txhaj los ntawm cov compiler.




