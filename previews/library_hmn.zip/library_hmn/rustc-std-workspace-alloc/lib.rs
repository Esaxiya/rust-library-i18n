#![feature(no_core)]
#![no_core]

// Saib rustc-std-ntshoo-core yog vim li cas qhov no crate uas yuav tsum tau.

// Rename lub crate kom tsis txhob tseem nrog cov alloc module nyob rau hauv liballoc.
extern crate alloc as foo;

pub use foo::*;