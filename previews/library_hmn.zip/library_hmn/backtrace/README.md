# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Lub tsev khaws ntaub ntawv rau txais cov backtraces thaum runtime rau Rust.
Lub tsev qiv ntawv no lub hom phiaj yog txhim kho kev txhawb nqa ntawm lub tsev qiv ntawv txheem los ntawm muab ib qho programmatic interface los ua haujlwm nrog, tab sis nws tseem txhawb yooj yim luam tawm cov backtrace tam sim no zoo li libstd's panics.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Txhawm rau ntes tsuas yog thawb rov qab thiab ncua sij hawm nrog nws kom txog rau lub sijhawm tom qab, koj tuaj yeem siv hom sab saum toj-qib `Backtrace`.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Yog tias, txawm li cas los xij, koj xav tau ntau dua kev nkag mus rau qhov tseeb kev ua haujlwm, koj tuaj yeem siv `trace` thiab `resolve` ua haujlwm ncaj qha.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Daws cov kev qhia qhia no rau lub cim lub npe
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // pheej mus rau tom ntej no
    });
}
```

# License

Txoj haujlwm no tau ntawv tso cai raws li ob qho tib si

 * Apache Daim Ntawv Tso Cai, Version 2.0, ([LICENSE-APACHE](LICENSE-APACHE) lossis http://www.apache.org/licenses/LICENSE-2.0)
 * Daim ntawv tso cai MIT ([LICENSE-MIT](LICENSE-MIT) lossis http://opensource.org/licenses/MIT)

nyob ntawm koj xaiv.

### Contribution

Tshwj tsis yog koj hais ntsees txwv tsis pub, lwm yam kev txhawb nqa uas yog txhob txwm xa rau kev nkag rau hauv backtrace-rs los ntawm koj, raws li sau tseg hauv Apache-2.0 daim ntawv tso cai, yuav tsum yog ob daim ntawv tso cai raws li saum toj no, tsis muaj ib qho lus hais ntxiv lossis cov xwm txheej.







