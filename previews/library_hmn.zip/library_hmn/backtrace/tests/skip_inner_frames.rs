use backtrace::Backtrace;

// Qhov kev kuaj no tsuas yog ua haujlwm rau cov platforms uas muaj ua haujlwm `symbol_address` ua haujlwm rau cov ntas uas tshaj tawm qhov chaw nyob pib ntawm lub cim.
// Raws li qhov tshwm sim nws tsuas yog qhib rau ob peb lub platform.
//
const ENABLED: bool = cfg!(all(
    // Windows muaj tsis tiag tiag raug kuaj, thiab OSX tsis txhawb tau nrhiav ib tug muab ncej, li ntawd, lov tes taw no
    //
    target_os = "linux",
    // Nyob rau NPAB nrhiav tus muab nuj nqi yog tsuas rov qab rau hauv lub ip nws tus kheej.
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}