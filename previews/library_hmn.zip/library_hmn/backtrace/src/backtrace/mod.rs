use core::ffi::c_void;
use core::fmt;

/// Tshawb xyuas tam sim no hu-pawg, dhau tag nrho cov thav ntawv mus rau hauv qhov kev kaw tau muab los laij ib pawg ib txoj lw.
///
/// Qhov no muaj nuj nqi yog lub workhorse ntawm no tsev qiv ntawv nyob rau hauv kev xam xyuas cov pawg ib co kua nplaum rau ib qho kev pab.Cov muab kaw `cb` yog muaj txiaj ntsig tam sim ntawm `Frame` uas sawv cev cov ntaub ntawv hais txog qhov ntawd hu tus ncej ntawm pawg.
/// Lub kaw yog yielded ntas nyob rau hauv ib tug saum-down zam (feem ntau tsis ntev los no hu ua zog ua ntej).
///
/// Lub kaw kev xa rov qab tus nqi yog qhov ntsuas seb puas yuav rov qab sab hauv qab.Tus nqi xa rov qab ntawm `false` yuav tso tseg lub backtrace thiab xa rov qab sai.
///
/// Thaum ib tus `Frame` xav koj yuav xav tau hu rau `backtrace::resolve` los hloov `ip` (kev qhia qhia pointer) lossis cim chaw nyob rau `Symbol` los ntawm uas lub npe thiab/lossis filename/kab xov tooj tuaj yeem kawm.
///
///
/// Nco ntsoov tias qhov no yog qhov ua tau zoo-tsawg thiab yog tias koj xav ua, piv txwv li, ntes ib qho backtrace kom tshuaj xyuas tom qab, tom qab ntawv `Backtrace` yuav tsim nyog dua.
///
/// # Cov nta tseev kom muaj
///
/// Muaj nuj nqi no yuav tsum muaj `std` qhov tseem ceeb ntawm `backtrace` crate yuav tsum tau qhib, thiab `std` lub peev xwm raug qhib los ntawm lub neej ntawd.
///
/// # Panics
///
/// Txoj haujlwm no sib zog ua haujlwm ib txwm tsis panic, tab sis yog `cb` muab panics tom qab ntawd qee lub platform yuav yuam ob panic kom rho tawm cov txheej txheem.
/// Qee cov platform siv C lub tsev qiv ntawv uas nyob hauv sab hauv siv cov callbacks uas tsis tuaj yeem raug mob tsis dhau, yog li kev sib kis ntawm `cb` yuav ua rau cov txheej txheem rho menyuam tawm.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // txuas ntxiv lub backtrace
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Tib yam li `trace`, tsuas yog tsis nyab xeeb nws yog unsynchronized.
///
/// Txoj haujlwm no tsis muaj synchronization guarentees tab sis muaj nyob thaum `std` cov yam ntxwv ntawm no crate tsis tau muab tso ua ke.
/// Saib cov `trace` muaj nuj nqi rau ntau cov ntaub ntawv thiab cov piv txwv.
///
/// # Panics
///
/// Saib cov ntaub ntawv ntawm `trace` rau caveats ntawm `cb` panicking.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// Ib trait sawv cev rau ib tus ncej ntawm ib qho thaub qab, lav rau `trace` qhov haujlwm ntawm no crate.
///
/// Lub tracing muaj nuj nqi kaw yuav tau yielded ntas, thiab thav duab yog zoo tso raws li qhov pib siv yog tsis ib txwm paub txog thaum lub sijhawm runtime.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Rov qab txais cov kev qhia tam sim no ntawm tus ncej no.
    ///
    /// Qhov no feem ntau yog cov lus qhia tom ntej kom ua rau hauv tus ncej, tab sis tsis yog txhua qhov kev nqis tes ua qhov no nrog 100% qhov tseeb (tab sis nws feem ntau zoo nkauj ze).
    ///
    ///
    /// Nws raug nquahu kom dhau cov nqi no mus rau `backtrace::resolve` kom tig nws mus rau lub npe cim.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Rov tam sim no pawg pointer ntawm no ncej.
    ///
    /// Nyob rau hauv rooj plaub uas tus thaub qab tsis tuaj yeem rov qab tau cov pawg pointer rau cov ncej no, null pointer rov qab los.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Rov cov pib cim qhov chaw nyob ntawm lub thav duab ntawm no muaj nuj nqi.
    ///
    /// Qhov no yuav sim rewind qhov kev qhia pointer xa rov qab los ntawm `ip` los pib ua haujlwm, rov qab cov nqi ntawd.
    ///
    /// Qee qhov xwm txheej, txawm li cas los xij, backends yuav cia li rov qab `ip` los ntawm txoj haujlwm no.
    ///
    /// Cov rov qab nqi tej zaum kuj yuav siv tau yog tias `backtrace::resolve` ua tsis tau tejyam rau lub `ip` muab saum toj no.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Rov puag chaw nyob ntawm lub module uas tus ncej belongs.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Qhov no yuav tsum tau los ua ntej, los xyuas kom meej tias Miri siv ua ntej dhau ntawm lub party platform
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // tsuas yog siv nyob rau hauv dbghelp symbolize
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}