//! Backtrace txhawb siv libunwind/gcc_s/etc APIs.
//!
//! Cov qauv no muaj qhov muaj peev xwm rub tawm cov tshooj uas siv cov qib libunwind-style APIs.
//! Nco ntsoov tias muaj yog ib tug tag nrho pawg ntawm implementations ntawm lub libunwind zoo li API, thiab qhov no yog cia li ua rau tau tshaj rau feem ntau ntawm lawv tag nrho cov nyob rau hauv ib zaug es tsis txhob ua kus kes.
//!
//!
//! Lub libunwind API yog powered by `_Unwind_Backtrace` thiab yog nyob rau hauv kev xyaum heev txhim khu kev qha ntawm generating ib tug backtrace.
//! Nws tsis meej tag nrho yuav ua li cas nws ua (ncej taw tes? Eh_frame info? Ob leeg?) Tab sis nws zoo li ua haujlwm!
//!
//! Feem ntau ntawm cov nyom ntawm cov qauv no tswj cov kev sib txawv ntawm ntau lub platform thoob plaws kev siv libunwind.
//! Txwv tsis pub qhov no yog qhov ncaj ncaj Rust khi rau libunwind APIs.
//!
//! Qhov no yog lub lim piam tsis taus rau tag nrho cov uas tsis muaj qhov rai tam sim no.
//!
//!
//!

use super::super::Bomb;
use core::ffi::c_void;

pub enum Frame {
    Raw(*mut uw::_Unwind_Context),
    Cloned {
        ip: *mut c_void,
        sp: *mut c_void,
        symbol_address: *mut c_void,
    },
}

// Nrog cov libunwind lub pointer nyoos nws yuav tsum tau tsuas yog nkag mus rau hauv qhov kev nyeem xov threadsafe zam, yog li nws yog `Sync`.
// Thaum xa mus rau lwm cov threads ntawm `Clone` peb yeej ib txwm hloov mus rau ib version uas tsis khaws sab hauv pointers, yog li peb yuav tsum tau `Send` zoo li.
//
//
unsafe impl Send for Frame {}
unsafe impl Sync for Frame {}

impl Frame {
    pub fn ip(&self) -> *mut c_void {
        let ctx = match *self {
            Frame::Raw(ctx) => ctx,
            Frame::Cloned { ip, .. } => return ip,
        };
        unsafe { uw::_Unwind_GetIP(ctx) as *mut c_void }
    }

    pub fn sp(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ctx) => unsafe { uw::get_sp(ctx) as *mut c_void },
            Frame::Cloned { sp, .. } => sp,
        }
    }

    pub fn symbol_address(&self) -> *mut c_void {
        if let Frame::Cloned { symbol_address, .. } = *self {
            return symbol_address;
        }

        // Nws zoo nkaus li nyob rau OSX `_Unwind_FindEnclosingFunction` rov qab pointer rau ... yam uas tsis meej.
        // Nws yog twv yuav raug hu tsis yeej ib txwm lub muab nuj nqi rau txhua yam vim li cas.
        // Nws tsis muaj tseeb kiag rau kuv tias muaj dab tsi ntawm no, yog li pessimize qhov no rau tam sim no thiab tsuas yog rov qab xa tus ip.
        //
        // Nco ntsoov `skip_inner_frames.rs` qhov kev xeem raug hla ntawm OSX vim qhov kab lus no, thiab yog tias qhov no tau kho tas uas ntsuas hauv kev tshawb xav tuaj yeem khiav ntawm OSX!
        //
        //
        //
        if cfg!(target_os = "macos") || cfg!(target_os = "ios") {
            self.ip()
        } else {
            unsafe { uw::_Unwind_FindEnclosingFunction(self.ip()) }
        }
    }

    pub fn module_base_address(&self) -> Option<*mut c_void> {
        None
    }
}

impl Clone for Frame {
    fn clone(&self) -> Frame {
        Frame::Cloned {
            ip: self.ip(),
            sp: self.sp(),
            symbol_address: self.symbol_address(),
        }
    }
}

#[inline(always)]
pub unsafe fn trace(mut cb: &mut dyn FnMut(&super::Frame) -> bool) {
    uw::_Unwind_Backtrace(trace_fn, &mut cb as *mut _ as *mut _);

    extern "C" fn trace_fn(
        ctx: *mut uw::_Unwind_Context,
        arg: *mut c_void,
    ) -> uw::_Unwind_Reason_Code {
        let cb = unsafe { &mut *(arg as *mut &mut dyn FnMut(&super::Frame) -> bool) };
        let cx = super::Frame {
            inner: Frame::Raw(ctx),
        };

        let mut bomb = Bomb { enabled: true };
        let keep_going = cb(&cx);
        bomb.enabled = false;

        if keep_going {
            uw::_URC_NO_REASON
        } else {
            uw::_URC_FAILURE
        }
    }
}

/// Unwind lub tsev qiv ntawv interface siv rau backtraces
///
/// Nco ntsoov tias cov cai tuag tau raug tso cai raws li ntawm no tsuas yog cov hlua khi iOS tsis siv txhua yam ntawm nws tab sis ntxiv ntau cov platform-kev lees paub meej ua kom cov pa ntawm cov cai ntau dhau
///
///
#[allow(non_camel_case_types)]
#[allow(non_snake_case)]
#[allow(dead_code)]
mod uw {
    pub use self::_Unwind_Reason_Code::*;

    use core::ffi::c_void;

    #[repr(C)]
    pub enum _Unwind_Reason_Code {
        _URC_NO_REASON = 0,
        _URC_FOREIGN_EXCEPTION_CAUGHT = 1,
        _URC_FATAL_PHASE2_ERROR = 2,
        _URC_FATAL_PHASE1_ERROR = 3,
        _URC_NORMAL_STOP = 4,
        _URC_END_OF_STACK = 5,
        _URC_HANDLER_FOUND = 6,
        _URC_INSTALL_CONTEXT = 7,
        _URC_CONTINUE_UNWIND = 8,
        _URC_FAILURE = 9, // siv tsuas yog siv ARM EABI
    }

    pub enum _Unwind_Context {}

    pub type _Unwind_Trace_Fn =
        extern "C" fn(ctx: *mut _Unwind_Context, arg: *mut c_void) -> _Unwind_Reason_Code;

    extern "C" {
        // Tsis muaj haiv neeg_Unwind_Backtrace rau iOS
        #[cfg(not(all(target_os = "ios", target_arch = "arm")))]
        pub fn _Unwind_Backtrace(
            trace: _Unwind_Trace_Fn,
            trace_argument: *mut c_void,
        ) -> _Unwind_Reason_Code;

        // muaj txij li GCC 4.2.0, yuav tsum yog qhov zoo rau peb lub hom phiaj
        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "s390x"))
        ))]
        // Qhov no muaj nuj nqi yog ib tug misnomer: es tau txais no ncej lub Canonical Ncej Chaw Nyob (aka tus neeg hu ncej lub SP) nws rov no ncej lub SP.
        //
        //
        // https://github.com/libunwind/libunwind/blob/d32956507cf29d9b1a98a8bce53c78623908f4fe/src/unwind/GetCFA.c#L28-L35
        //
        #[link_name = "_Unwind_GetCFA"]
        pub fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t;
    }

    // s390x siv qhov muaj nuj nqi rau CFA tus nqi, yog li ntawd peb yuav tsum siv_Unwind_GetGR kom tau txais cov pawg pointer sau npe (%r15) es tsis txhob tso siab rau_Unwind_GetCFA.
    //
    //
    #[cfg(all(target_os = "linux", target_arch = "s390x"))]
    pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
        extern "C" {
            pub fn _Unwind_GetGR(ctx: *mut _Unwind_Context, index: libc::c_int) -> libc::uintptr_t;
        }
        _Unwind_GetGR(ctx, 15)
    }

    // Ntawm android thiab caj npab, txoj haujlwm `_Unwind_GetIP` thiab ib pawg ntawm lwm tus yog macros, yog li peb txhais cov haujlwm uas muaj qhov txuas ntawm macros.
    //
    //
    // TODO: txuas mus rau header file uas txhais cov macros, yog tias koj tuaj yeem pom.
    // (KUV, tsis tas li, nrhiav tsis tau cov ntawv sau header uas qee qhov kev nthuav qhia dav dav muaj keebkwm qiv los ntawm.)
    //
    //
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    pub use self::arm::*;
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    mod arm {
        pub use super::*;
        #[repr(C)]
        enum _Unwind_VRS_Result {
            _UVRSR_OK = 0,
            _UVRSR_NOT_IMPLEMENTED = 1,
            _UVRSR_FAILED = 2,
        }
        #[repr(C)]
        enum _Unwind_VRS_RegClass {
            _UVRSC_CORE = 0,
            _UVRSC_VFP = 1,
            _UVRSC_FPA = 2,
            _UVRSC_WMMXD = 3,
            _UVRSC_WMMXC = 4,
        }
        #[repr(C)]
        enum _Unwind_VRS_DataRepresentation {
            _UVRSD_UINT32 = 0,
            _UVRSD_VFPX = 1,
            _UVRSD_FPAX = 2,
            _UVRSD_UINT64 = 3,
            _UVRSD_FLOAT = 4,
            _UVRSD_DOUBLE = 5,
        }

        type _Unwind_Word = libc::c_uint;
        extern "C" {
            fn _Unwind_VRS_Get(
                ctx: *mut _Unwind_Context,
                klass: _Unwind_VRS_RegClass,
                word: _Unwind_Word,
                repr: _Unwind_VRS_DataRepresentation,
                data: *mut c_void,
            ) -> _Unwind_VRS_Result;
        }

        pub unsafe fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                15,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            (val & !1) as libc::uintptr_t
        }

        // R13 yog pawg khij ntawm sab caj npab.
        const SP: _Unwind_Word = 13;

        pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                SP,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            val as libc::uintptr_t
        }

        // Qhov no muaj nuj nqi kuj tsis muaj nyob rau ntawm Android los yog ARM/Linux, li ntawd, ua rau nws ib tug tsis muaj-op.
        //
        pub unsafe fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void {
            pc
        }
    }
}