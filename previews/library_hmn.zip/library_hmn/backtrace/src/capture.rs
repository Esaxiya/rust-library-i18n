use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// Cov sawv cev ntawm nyias tus kheej thiab nyias muaj nyias qhov sab nraud.
///
/// Cov qauv no tuaj yeem siv los txeeb lub backtrace ntawm ntau cov ntsiab lus hauv ib qhov kev zov me nyuam thiab tom qab ntawd siv los kuaj xyuas qhov backtrace nyob rau lub sijhawm ntawd.
///
///
/// `Backtrace` txhawb nqa zoo nkauj-luam tawm ntawm backtraces los ntawm nws `Debug` kev siv.
///
/// # Cov nta tseev kom muaj
///
/// Muaj nuj nqi no yuav tsum muaj `std` qhov tseem ceeb ntawm `backtrace` crate yuav tsum tau qhib, thiab `std` lub peev xwm raug qhib los ntawm lub neej ntawd.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // Cov ntas ntawm no tau teev los ntawm sab saum toj-mus rau hauv qab ntawm pawg
    frames: Vec<BacktraceFrame>,
    // Qhov Performance index peb ntseeg hais tias yog qhov tseeb pib ntawm lub backtrace, twg ntas zoo li `Backtrace::new` thiab `backtrace::trace`.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// Cov ntsiab lus ntes ntawm tus ncej hauv lub nraub qaum.
///
/// Hom no tau xa rov qab raws li daim ntawv teev npe los ntawm `Backtrace::frames` thiab sawv cev rau ib qho kab sib tshooj hauv ib qho kev txheeb rov qab.
///
/// # Cov nta tseev kom muaj
///
/// Muaj nuj nqi no yuav tsum muaj `std` qhov tseem ceeb ntawm `backtrace` crate yuav tsum tau qhib, thiab `std` lub peev xwm raug qhib los ntawm lub neej ntawd.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// Txais tau cov cim ntawm lub cim hauv qab nraub qaum.
///
/// Qhov no hom rov qab raws li ib daim ntawv teev los ntawm `BacktraceFrame::symbols` thiab nruab nrab yog cov metadata rau ib tug cim nyob rau hauv ib tug backtrace.
///
/// # Cov nta tseev kom muaj
///
/// Muaj nuj nqi no yuav tsum muaj `std` qhov tseem ceeb ntawm `backtrace` crate yuav tsum tau qhib, thiab `std` lub peev xwm raug qhib los ntawm lub neej ntawd.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// Txais lub backtrace ntawm qhov hu ntawm txoj haujlwm no, rov ua tus sawv cev uas yog tswv.
    ///
    /// Txoj haujlwm no muaj txiaj ntsig zoo rau sawv cev backtrace yog yam khoom nyob hauv Rust.Tus nqi xa rov qab no tuaj yeem xa hla cov xov thiab luam tawm lwm qhov, thiab lub hom phiaj ntawm tus nqi no yog kom muaj nws tus kheej nkaus.
    ///
    /// Nco ntsoov tias ntawm qee lub vev xaib tau txais kev qhia tom qab thiab daws qhov teeb meem nws tuaj yeem yog qhov tsis tshua muaj nqi.
    /// Yog tias tus nqi ntau dhau rau koj daim ntawv thov nws raug pom zoo kom siv `Backtrace::new_unresolved()` uas zam cov kauj ruam daws teeb meem (uas ib txwm siv sijhawm ntev tshaj plaws) thiab tso cai rau kev daws qhov teebmeem ntawd mus rau ib hnub tom qab.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # Cov nta tseev kom muaj
    ///
    /// Muaj nuj nqi no yuav tsum muaj `std` qhov tseem ceeb ntawm `backtrace` crate yuav tsum tau qhib, thiab `std` lub peev xwm raug qhib los ntawm lub neej ntawd.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // xav kom ntseeg tau tias muaj tus ncej ntawm no kom tshem tawm
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// Zoo ib yam li `new` tshwj tsis yog tias qhov no tsis daws teeb meem cov cim, qhov no tsuas yog rub daim backtrace raws li cov npe chaw nyob.
    ///
    /// Lub sijhawm tom qab lub sijhawm ua haujlwm `resolve` tuaj yeem raug hu los daws qhov backtrace no cov cim rau hauv cov npe yooj yim.
    /// Qhov no muaj nuj nqi no tshwm sim vim hais tias cov kev daws teeb meem tau tej zaum kuj siv sij hawm ib tug tseem ceeb npaum li cas ntawm lub sij hawm whereas ib tug backtrace tsuas yog tsis tshua muaj luam.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // tsis muaj lub npe
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // cim cov npe tam sim no tam sim no
    /// ```
    ///
    /// # Cov nta tseev kom muaj
    ///
    /// Muaj nuj nqi no yuav tsum muaj `std` qhov tseem ceeb ntawm `backtrace` crate yuav tsum tau qhib, thiab `std` lub peev xwm raug qhib los ntawm lub neej ntawd.
    ///
    ///
    ///
    #[inline(never)] // xav kom ntseeg tau tias muaj tus ncej ntawm no kom tshem tawm
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// Rov tus ntas los ntawm thaum no backtrace twb ntes.
    ///
    /// Thawj nkag ntawm cov hlais no tej zaum yuav muaj nuj nqi `Backtrace::new`, thiab cov ncej kawg tej zaum yuav ib yam dab tsi txog li cas cov xov no lossis lub ntsiab haujlwm pib.
    ///
    ///
    /// # Cov nta tseev kom muaj
    ///
    /// Muaj nuj nqi no yuav tsum muaj `std` qhov tseem ceeb ntawm `backtrace` crate yuav tsum tau qhib, thiab `std` lub peev xwm raug qhib los ntawm lub neej ntawd.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// Yog hais tias qhov no backtrace yog tsim los ntawm `new_unresolved` ces qhov no muaj nuj nqi yuav daws tag nrho cov chaw nyob nyob rau hauv lub backtrace rau lawv leb npe.
    ///
    ///
    /// Yog tias qhov backtrace no tau raug daws dua los yog tau tsim los ntawm `new`, qhov haujlwm no tsis muaj dab tsi.
    ///
    /// # Cov nta tseev kom muaj
    ///
    /// Muaj nuj nqi no yuav tsum muaj `std` qhov tseem ceeb ntawm `backtrace` crate yuav tsum tau qhib, thiab `std` lub peev xwm raug qhib los ntawm lub neej ntawd.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// Tib yam li `Frame::ip`
    ///
    /// # Cov nta tseev kom muaj
    ///
    /// Muaj nuj nqi no yuav tsum muaj `std` qhov tseem ceeb ntawm `backtrace` crate yuav tsum tau qhib, thiab `std` lub peev xwm raug qhib los ntawm lub neej ntawd.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// Tib yam li `Frame::symbol_address`
    ///
    /// # Cov nta tseev kom muaj
    ///
    /// Muaj nuj nqi no yuav tsum muaj `std` qhov tseem ceeb ntawm `backtrace` crate yuav tsum tau qhib, thiab `std` lub peev xwm raug qhib los ntawm lub neej ntawd.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// Tib yam li `Frame::module_base_address`
    ///
    /// # Cov nta tseev kom muaj
    ///
    /// Muaj nuj nqi no yuav tsum muaj `std` qhov tseem ceeb ntawm `backtrace` crate yuav tsum tau qhib, thiab `std` lub peev xwm raug qhib los ntawm lub neej ntawd.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// Rov qab cov npe ntawm cov cim uas cov kab no tau raug.
    ///
    /// Feem ntau muaj no tsuas muaj ib lub cim rau ib tus ncej, tab sis tej zaum kuj yog ib tug xov tooj ntawm kev khiav dej num yog inlined rau hauv ib tug ncej ces ntau cim yuav raug xa rov qab.
    /// Tus thawj lub cim uas sau tseg yog lub "innermost function", whereas lub xeem cim yog lub outermost (lub xeem hu).
    ///
    /// Nco ntsoov tias yog tias lub thav duab no los ntawm qhov kev daws tsis tau rov qab zoo ces qhov no yuav xa rov qab tsis muaj npe.
    ///
    /// # Cov nta tseev kom muaj
    ///
    /// Muaj nuj nqi no yuav tsum muaj `std` qhov tseem ceeb ntawm `backtrace` crate yuav tsum tau qhib, thiab `std` lub peev xwm raug qhib los ntawm lub neej ntawd.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// Tib yam li `Symbol::name`
    ///
    /// # Cov nta tseev kom muaj
    ///
    /// Muaj nuj nqi no yuav tsum muaj `std` qhov tseem ceeb ntawm `backtrace` crate yuav tsum tau qhib, thiab `std` lub peev xwm raug qhib los ntawm lub neej ntawd.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// Tib yam li `Symbol::addr`
    ///
    /// # Cov nta tseev kom muaj
    ///
    /// Muaj nuj nqi no yuav tsum muaj `std` qhov tseem ceeb ntawm `backtrace` crate yuav tsum tau qhib, thiab `std` lub peev xwm raug qhib los ntawm lub neej ntawd.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// Tib yam li `Symbol::filename`
    ///
    /// # Cov nta tseev kom muaj
    ///
    /// Muaj nuj nqi no yuav tsum muaj `std` qhov tseem ceeb ntawm `backtrace` crate yuav tsum tau qhib, thiab `std` lub peev xwm raug qhib los ntawm lub neej ntawd.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// Tib yam li `Symbol::lineno`
    ///
    /// # Cov nta tseev kom muaj
    ///
    /// Muaj nuj nqi no yuav tsum muaj `std` qhov tseem ceeb ntawm `backtrace` crate yuav tsum tau qhib, thiab `std` lub peev xwm raug qhib los ntawm lub neej ntawd.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// Tib yam li `Symbol::colno`
    ///
    /// # Cov nta tseev kom muaj
    ///
    /// Muaj nuj nqi no yuav tsum muaj `std` qhov tseem ceeb ntawm `backtrace` crate yuav tsum tau qhib, thiab `std` lub peev xwm raug qhib los ntawm lub neej ntawd.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // Thaum luam ntawv txoj kab peb sim sawb lub cwd yog tias muaj, txwv tsis pub peb tsuas yog luam tawm txoj hauv kev yog.
        // Nco ntsoov tias peb tseem tsuas ua qhov no rau hom ntawv luv, vim tias yog nws puv peb xav tias yuav luam txhua yam.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}