//! Platform nyob hom.

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::borrow::Cow;
        use std::fmt;
        use std::path::PathBuf;
        use std::prelude::v1::*;
        use std::str;
    }
}

/// Lub platform ywj siab sawv cev ntawm txoj hlua.
/// Thaum ua haujlwm nrog `std` qhib kev pom zoo nws raug pom zoo rau cov txheej txheem yooj yim rau kev muab kev sib hloov rau `std` hom.
///
#[derive(Debug)]
pub enum BytesOrWideString<'a> {
    /// Ib qho hlais, ib txwm muab ntawm Unix platform.
    Bytes(&'a [u8]),
    /// Dav hlua feem ntau los ntawm Windows.
    Wide(&'a [u16]),
}

#[cfg(feature = "std")]
impl<'a> BytesOrWideString<'a> {
    /// Lossy hloov mus rau `Cow<str>`, yuav faib yog `Bytes` tsis yog siv tau UTF-8 lossis yog `BytesOrWideString` yog `Wide`.
    ///
    /// # Cov nta tseev kom muaj
    ///
    /// Muaj nuj nqi no yuav tsum muaj `std` qhov tseem ceeb ntawm `backtrace` crate yuav tsum tau qhib, thiab `std` lub peev xwm raug qhib los ntawm lub neej ntawd.
    ///
    ///
    pub fn to_str_lossy(&self) -> Cow<'a, str> {
        use self::BytesOrWideString::*;

        match self {
            &Bytes(slice) => String::from_utf8_lossy(slice),
            &Wide(wide) => Cow::Owned(String::from_utf16_lossy(wide)),
        }
    }

    /// Muab cov `Path` sawv cev ntawm `BytesOrWideString`.
    ///
    /// # Cov nta tseev kom muaj
    ///
    /// Muaj nuj nqi no yuav tsum muaj `std` qhov tseem ceeb ntawm `backtrace` crate yuav tsum tau qhib, thiab `std` lub peev xwm raug qhib los ntawm lub neej ntawd.
    ///
    pub fn into_path_buf(self) -> PathBuf {
        #[cfg(unix)]
        {
            use std::ffi::OsStr;
            use std::os::unix::ffi::OsStrExt;

            if let BytesOrWideString::Bytes(slice) = self {
                return PathBuf::from(OsStr::from_bytes(slice));
            }
        }

        #[cfg(windows)]
        {
            use std::ffi::OsString;
            use std::os::windows::ffi::OsStringExt;

            if let BytesOrWideString::Wide(slice) = self {
                return PathBuf::from(OsString::from_wide(slice));
            }
        }

        if let BytesOrWideString::Bytes(b) = self {
            if let Ok(s) = str::from_utf8(b) {
                return PathBuf::from(s);
            }
        }
        unreachable!()
    }
}

#[cfg(feature = "std")]
impl<'a> fmt::Display for BytesOrWideString<'a> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.to_str_lossy().fmt(f)
    }
}