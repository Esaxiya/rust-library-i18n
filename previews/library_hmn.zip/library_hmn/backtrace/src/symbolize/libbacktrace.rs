//! Cov cim kev qhia siv lub DWARF-parsing code hauv libbacktrace.
//!
//! Lub tsev qiv ntawv libbacktrace C, feem ntau faib nrog gcc, txhawb tsis tau tsuas yog tsim kom muaj lub backtrace (uas peb tsis tau siv) tab sis kuj ua cim txog qhov backtrace thiab tuav cov ntaub ntawv debug txog cov khoom xws li inlines ntas thiab whatnot.
//!
//!
//! Qhov no yog qhov nyuaj vim tias ntau ntau qhov kev txhawj xeeb ntawm no, tab sis cov tswv yim tseem ceeb yog:
//!
//! * Ua ntej peb hu `backtrace_syminfo`.Qhov no tau txais cov ntaub ntawv cim ntawm lub rooj cim cim dynamic yog tias peb tuaj yeem ua tau.
//! * Tom ntej no peb hu `backtrace_pcinfo`.Qhov no yuav parse debuginfo cov rooj yog tias lawv muaj thiab tso cai rau peb rov qab cov ntaub ntawv hais txog cov kab sib chaws, kab ntawv, naj npawb xov tooj, thiab lwm yam.
//!
//! Muaj ntau ntawm cov lus dag txog kev tau txais cov ntxhuav ntsias ua libbacktrace, tab sis vam tias nws tsis yog qhov kawg ntawm lub ntiaj teb thiab muaj tseeb txaus thaum nyeem hauv qab.
//!
//! Qhov no yog lub neej ntawd symbolication zoo rau uas tsis yog-MSVC thiab uas tsis yog-OSX platforms.Nyob rau hauv libstd tab sis qhov no yog lub neej ntawd zoo rau OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Yog tias ua tau xum `function` lub npe uas los ntawm debuginfo thiab tuaj yeem feem ntau yog qhov tseeb rau cov kab sab hauv ua piv txwv.
                // Yog hais tias yog tsis tam sim no tab sis yog lub caij nplooj zeeg rov qab mus rau lub cim rooj lub npe teev nyob rau hauv `symname`.
                //
                // Nco ntsoov tias qee zaum `function` tuaj yeem hnov qee qhov tsis tshua muaj tseeb, piv txwv li tau teev npe ua `try<i32,closure>` isntead of `std::panicking::try::do_call`.
                //
                // Nws tsis tshua meej yog vim li cas, tab sis tag nrho `function` lub npe zoo li ntau dua.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // tsis muaj dab tsi rau tam sim no
}

/// Ntaus ntawm lub `data` pointer dhau mus rau hauv `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Thaum no callback yog invoked los ntawm `backtrace_syminfo` thaum peb pib txawj peb mus ntxiv hu rau `backtrace_pcinfo`.
    // Tus `backtrace_pcinfo` muaj nuj nqi yuav sab laj debug cov ntaub ntawv thiab cev nqaij daim tawv los ua tej yam zoo li rov qab file/line cov ntaub ntawv ntxiv rau cov ntas hauv.
    // Nco ntsoov tias `backtrace_pcinfo` tuaj yeem ua tsis tiav lossis tsis ua ntau yog tias tsis muaj qhov debug info, yog li yog tias qhov tshwm sim peb paub meej kom hu rau rov qab nrog tsawg kawg ib lub cim los ntawm `syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Hom `data` pointer dhau rau `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// Lub libbacktrace API txhawb tsim lub xeev, tab sis nws tsis txhawb kev rhuav tshem lub xeev.
// Kuv tus kheej los coj qhov no txhais tau tias lub xeev yog tsim los tsim thiab tom qab ntawd nyob mus ib txhis.
//
// Kuv yuav nyiam rau npe tus at_exit() handler uas ntxuav tawm hauv lub xeev no, tab sis libbacktrace muab tsis muaj txoj hauv kev los ua nws.
//
// Nrog rau cov kev txwv no, txoj haujlwm no muaj lub xeev cached cov xwm txheej uas tau suav ua thawj zaug qhov no tau thov.
//
// Nco ntsoov tias backtracing txhua yam tshwm sim serial (ib qho khoom siv kaw thoob ntiaj teb).
//
// Nco ntsoov qhov tsis muaj synchronization ntawm no yog vim muaj qhov yuav tsum ua `resolve` X yog sab nraud synchronized.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Tsis txhob siv threadsafe tuition ntawm libbacktrace txij li thaum peb nyob nraum ib txwm hu rau nws nyob rau hauv ib tug synchronized zam.
        //
        0,
        error_cb,
        ptr::null_mut(), // tsis muaj ntaub ntawv ntxiv
    );

    return STATE;

    // Nco ntsoov tias rau libbacktrace rau kev khiav lag luam ntawm txhua qhov nws xav tau los nrhiav DWARF debug cov ntaub ntawv rau qhov ua tam sim no.Nws feem ntau yog tias ntawm ib tug xov tooj ntawm mechanisms xws li, tiam sis tsis tag rau:
    //
    // * /proc/self/exe nyob rau kev txhawb cov platforms
    // * Lub filename dhau hauv kev qhia meej thaum tsim lub xeev
    //
    // Lub tsev qiv ntawv libbacktrace yog loj wad ntawm C code.Qhov no ib txwm txhais tau tias nws tau txais kev nco kev nyab xeeb muaj peev xwm, tshwj xeeb tshaj yog thaum tuav malformed debuginfo.
    // Libstd tau dhau los ua ntau cov keeb kwm no.
    //
    // Yog hais tias /proc/self/exe siv ces peb tuaj yeem tsis quav ntsej cov no raws li peb xav tias libbacktrace yog "mostly correct" thiab lwm yam tsis ua tej yam txawv nrog "attempted to be correct" ntsias debug info.
    //
    //
    // Yog hais tias peb kis tau rau hauv ib tug filename, txawm li cas los, ces nws yuav tau nyob rau hauv ib co platforms (xws li BSDs) qhov twg ib tug siab phem actor yuav ua rau ib tug arbitrary ntaub ntawv yuav tsum tau muab tso rau ntawd qhov chaw nyob.
    // Qhov no txhais tau hais tias yog hais tias peb qhia rau libbacktrace hais txog ib tug filename tej zaum nws yuav siv ib tug arbitrary ntaub ntawv, tejzaum yuav ua tau segfaults.
    // Yog tias peb tsis qhia libbacktrace dab tsi tab sis tom qab ntawd nws yuav tsis ua dab tsi ntawm cov platforms uas tsis txhawb txoj kev zoo li /proc/self/exe!
    //
    // Muab txhua yam uas peb sim ua qhov nyuaj li sai tau rau *tsis* dhau ntawm lub npe, tab sis peb yuav tsum nyob rau cov platforms uas tsis txhawb /proc/self/exe txhua.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Nco ntsoov tias tob peb xav siv `std::env::current_exe`, tab sis peb tsis tuaj yeem xav tau `std` ntawm no.
            //
            // Siv `_NSGetExecutablePath` los thauj cov kab kev coj ua tam sim no mus rau thaj chaw zoo li qub (uas yog tias nws tsawg dhau tsuas yog tso).
            //
            //
            // Nco ntsoov tias peb nyob nraum tiag kev cia siab libbacktrace no mus tsis tuag rau corrupt executables, tab sis nws muaj tseeb tsis ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows muaj hom kev qhib cov ntaub ntawv nyob qhov twg tom qab nws qhib nws tsis tuaj yeem raug tshem tawm.
            // Qhov ntawd yog qhov uas peb xav tau ntawm no vim peb xav kom ntseeg tau tias peb qhov kev ua tiav tsis hloov pauv ntawm hauv qab peb tom qab peb xa tawm mus rau libbacktrace, cia siab tias yuav txo tau kev muaj peev xwm dhau los hauv cov ntaub ntawv tsis txaus siab rau libbacktrace (uas tej zaum yuav raug mishandled).
            //
            //
            // Muab hais tias peb ua txoj kev seev cev me ntsis ntawm no los sim kom tau txais qhov kev txwv ntawm peb tus kheej duab:
            //
            // * Tau txais tus kov rau txoj kev tam sim no, thauj nws lub npe.
            // * Qhib cov ntawv rau qhov filename nrog tus chij sab xis.
            // * Reload lub tam sim no cov txheej txheem lub filename, ua kom paub tseeb tias nws yog tib yam
            //
            // Yog tias txhua qhov hla peb hauv kev tshawb xav tau qhib peb cov txheej txheem cov ntaub ntawv thiab peb tau lees tias nws yuav tsis hloov.FWIW pawg ntawm qhov no yog theej los ntawm libstd keeb kwm, yog li qhov no kuv txhais tau zoo tshaj plaws ntawm qhov xwm txheej.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Qhov no nyob rau hauv zoo li qub nco li ntawd, peb yuav tau rov qab nws ..
                static mut BUF: [i8; N] = [0; N];
                // ... thiab qhov no nyob ntawm pawg tau vim tias nws yog ib ntus
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // txhob txwm paim quav `handle` no vim hais tias muaj uas qhib yuav tsum khaws cia peb xauv rau cov ntaub ntawv no lub npe.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Peb xav rov qab mus ib tug ib nplais uas yog nul-haujlwm, yog li ntawd yog txhua yam sau nyob rau hauv thiab nws sib npaug tag nrho ntev ces equate uas mus tsis ua hauj lwm.
                //
                //
                // Txwv tsis pub thaum rov qab ua tiav nco ntsoov kom cov nul byte tso rau hauv hlais.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // backtrace yuam kev yog tam sim no swept hauv qab ntaub pua plag
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Hu rau `backtrace_syminfo` API uas (los ntawm nyeem cov code) yuav tsum hu `syminfo_cb` raws nraim ib zaug (lossis ua tsis tiav nrog qhov ua yuam kev).
    // Peb mam li lis ntau dua hauv `syminfo_cb`.
    //
    // Nco ntsoov tias peb ua li no vim `syminfo` yuav tham lub cim rooj, nrhiav cim npe txawm yog hais tias muaj tsis muaj debug ntaub ntawv nyob rau hauv lub binary.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}