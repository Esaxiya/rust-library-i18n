//! Txhawb nqa cov cim qhia siv `gimli` crate ntawm crates.io
//!
//! Qhov no yog lub neej ntawd symbolication siv rau Rust.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // 'Zoo li qub neej yog ib cov lus dag rau hack nyob ib ncig ntawm tsis muaj kev pab txhawb nqa rau nws tus kheej-referential structs.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // Hloov mus rau 'kev ua neej zoo li qub vim tias cov cim yuav tsum tsuas qiv `map` thiab `stash` thiab peb tau tshwj tseg cia rau hauv qab no.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Rau kev thauj cov haiv neeg qiv ntawm Windows, saib qee qhov kev sib tham ntawm rust-lang/rust#71060 rau cov tswv yim ntau ntawm no.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // MinGW qiv tam sim no tsis txhawb ASLR (rust-lang/rust#16514), tab sis DLLs tseem tuaj yeem hloov chaw mus nyob hauv thaj chaw nyob.
            // Nws zoo nkaus li qhov chaw nyob hauv debug cov ntaub ntawv yog txhua li-yog tias lub tsev qiv ntawv no tau thauj khoom ntawm nws tus "image base", uas yog daim teb hauv nws daim COFF file headers.
            // Txij li qhov no yog dab tsi debuginfo zoo li sau peb parse lub cim rooj thiab khw chaw nyob yog hais tias lub tsev qiv ntawv tau thauj khoom ntawm "image base" zoo li.
            //
            // Cov tsev qiv ntawv tej zaum yuav tsis tau loaded ntawm "image base", txawm li cas los.
            // (Txawm ib yam dab tsi lwm tus tej zaum yuav tau loaded muaj?) Qhov no yog qhov twg lub `bias` teb los mus ua si, thiab peb yuav tsum tau kom paub tseeb tus nqi ntawm `bias` no.Hmoov tsis zoo txawm tias nws tsis meej yuav ua li cas thiaj kis tau qhov no los ntawm cov txheej txheem loaded.
            // Yuav ua li cas peb tsis muaj, txawm li cas los, yog lub sij load chaw nyob (`modBaseAddr`).
            //
            // Raws li me ntsis ntawm cop-tawm rau tam sim no peb mmap cov ntaub ntawv, nyeem cov ntaub ntawv header cov ntaub ntawv, tom qab ntawd poob lub mmap.Qhov no yog wasteful vim hais tias peb yuav zaum rov qhib lub mmap tom qab, tab sis qhov no yuav tsum ua hauj lwm zoo txaus rau tam sim no.
            //
            // Thaum peb muaj `image_base` (xav tau qhov chaw thau khoom) thiab `base_addr` (qhov chaw thauj khoom) peb tuaj yeem sau `bias` (qhov sib txawv ntawm qhov tseeb thiab xav tau) thiab tom qab ntawd cov chaw nyob ntawm txhua ntu yog `image_base` vim tias yog cov ntaub ntawv hais.
            //
            //
            // Txog rau tam sim no nws zoo nkaus li tsis zoo li ELF/MachO peb tuaj yeem ua nrog ib ntu ntawm ib lub tsev qiv ntawv, siv `modBaseSize` raws li tus lej loj.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS siv lub Mach-O cov hom ntaub ntawv thiab kev siv DYLD kev APIs mus thauj ib daim ntawv teev cov haiv neeg cov tsev qiv ntawv uas yog ib feem ntawm daim ntawv thov.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // Nqa lub npe ntawm no tsev qiv ntawv uas sau raws nkaus Ii rau txoj kev ntawm qhov chaw uas mus thauj nws zoo li.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // Thauj cov duab duab lub taub hau ntawm lub tsev qiv ntawv no thiab xa mus rau `object` txhawm rau txhawm rau txhawm rau txhawm rau txhawm rau txhawm rau txhawm rau txhawm rau txhawm rau txhawm rau txhawm rau txhawm rau txhawm rau paub txhua qhov ntu ntawm no.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // Khov dhau ntu ntu thiab sau npe cheeb tsam paub rau ntu uas peb pom.
            // Txuas ntxiv sau cov ncauj lus txog cov kab ntawv sau rau kev txheeb xyuas tom qab, saib cov lus hauv qab no.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // Txiav txim xyuas "slide" rau lub tsev qiv ntawv no uas xaus rau qhov kev tsis ncaj ncees uas peb siv los xyuas seb qhov twg hauv cov khoom nco hauv lub nra.
            // Qhov no yog me ntsis ntawm kev sib cais sib txawv tab sis yog qhov txiaj ntsig ntawm kev sim ua ob peb yam hauv cov tsiaj qus thiab pom dab tsi sticks.
            //
            // Lub tswv yim dav dav yog tias `bias` ntxiv rau ntu ntu `stated_virtual_memory_address` yuav mus rau qhov twg hauv qhov chaw nyob tiag qhov chaw ntu ntu nyob.
            // Lwm yam uas peb tso siab rau tab sis yog tias qhov chaw nyob tiag yog rho tawm `bias` yog qhov ntsuas xyuas kom pom ntawm lub cim rooj thiab debuginfo.
            //
            // Nws hloov tawm, txawm li cas los xij, tias rau lub kaw lus qiv cov lus qhia no tsis yog.Rau cov neeg ua haujlwm ib txwm ua, txawm li cas los xij, nws pom muaj tseeb.
            // Tsa qee lub cav los ntawm LLDB qhov chaw nws muaj qee qhov tshwj xeeb-thawj rau thawj ntu `__TEXT` thauj khoom los ntawm cov ntaub ntawv offset 0 nrog lub nonzero loj.
            // Rau qhov laj thawj dab tsi thaum qhov no tam sim no nws zoo li txhais tau tias lub cim lub rooj yog qhov sib luag rau tsuas yog vmaddr swb rau lub tsev qiv ntawv.
            // Yog tias nws *tsis* tam sim no cov lus cim sau yog ntu ntawm vmaddr swb ntxiv rau ntu ntu cov chaw nyob.
            //
            // Txog ntawm cov xwm txheej no yog tias peb *tsis* nrhiav cov ntu ntawv ntawm cov ntaub ntawv offset xoom ces peb nce qhov kev tsis ncaj ncees los ntawm thawj cov ntawv sau hais chaw nyob thiab txo tag nrho cov chaw nyob los ntawm tus nqi ntawd ib yam nkaus.
            //
            // Ntawd txoj kev ntawm lub cim rooj yeej ib txwm pom tus txheeb ze rau lub tsev qiv ntawv lub peev xwm.
            // Qhov no zoo nkaus li muaj cov txiaj ntsig raug rau qhov cim sau ntawm cov cim rooj.
            //
            // Honestly kuv tsis tseeb nkaus seb qhov no yog txoj cai los sis yog tias muaj ib yam dab tsi lwm yam uas yuav tsum qhia tias yuav ua li cas ua li no.
            // Txog rau tam sim no txawm tias qhov no zoo rau ua haujlwm txaus txaus (?) thiab peb yuav tsum nco ntsoov tuaj yeem nyem qhov no dhau sijhawm yog tias tsim nyog.
            //
            // Yog xav paub cov ntaub ntawv ntau ntxiv saib #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Lwm yam Unix (e.g.
        // Linux) cov platform siv ELF ua ib hom ntawv tawm qauv thiab feem ntau siv qib API hu ua `dl_iterate_phdr` los thauj cov tsev qiv ntawv haiv ib txwm muaj.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` yuav tsum muaj tus taw tes siv tau.
        // `vec` yuav tsum muaj ib tug siv tau pointer mus rau ib tug `std::Vec`.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 tsis tas ib txwm txhawb kev debug info, tab sis qhov tsim tsim yuav muab cov kev debug info ntawm txoj kev `romfs:/debug_info.elf`.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // Txhua tsav txhua yam yuav tsum siv ELF, tab sis tsis paub yuav ua li cas thauj cov chaw qiv hauv haiv ib txwm.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// Txhua lub tsev khaws ntaub ntawv uas tau muab qhia uas tau muaj thauj.
    libraries: Vec<Library>,

    /// Mappings cache qhov twg peb khaws cia cov ntaub ntawv ntsias kab ntsab.
    ///
    /// Qhov no daim ntawv teev muaj ib tug tsau muaj peev xwm rau nws tag nrho liftime uas yeej tsis tsub kom.
    /// Qhov `usize` lub ntsiab ntawm txhua khub yog ib qho kev ntsuas rau `libraries` saum toj no qhov twg `usize::max_value()` sawv cev tam sim no.
    ///
    /// Lub `Mapping` yog coj parsed ntsias ntaub ntawv.
    ///
    /// Nco ntsoov tias qhov no yog ib qho LRU cache thiab peb yuav tau hloov chaw nyob hauv no raws li peb cim qhov chaw nyob.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// Tej ntu ntawm lub tsev qiv ntawv no tau ntim rau hauv lub cim xeeb, thiab qhov chaw uas lawv thauj khoom.
    segments: Vec<LibrarySegment>,
    /// Lub "bias" ntawm lub tsev qiv ntawv no, feem ntau qhov chaw nws tau thau khoom rau hauv kev nco.
    /// Qhov no tus nqi yog ntxiv rau txhua ya tus hais qhov chaw nyob kom tau qhov tseeb virtual nco chaw nyob uas tus ya yog loaded rau hauv.
    /// Tsis tas li ntawd no tsis ncaj ncees yuav raug txiav los ntawm tiag tiag virtual nco chaw nyob rau index rau hauv debuginfo thiab lub cim rooj.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// Lub chaw nyob uas hais ntawm ntu no hauv cov ntaub ntawv pov thawj.
    /// Qhov no tsis yog qhov twg ntu ntu thauj, tab sis theej chaw nyob no ntxiv rau lub tsev qiv ntawv muaj `bias` yog qhov twg pom.
    ///
    stated_virtual_memory_address: usize,
    /// Qhov loj ntawm ths ntu ntawm qhov nco.
    len: usize,
}

// tsis nyab xeeb vim tias qhov no yuav tsum tau ua kom tau sab nrauv synchronized
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // tsis nyab xeeb vim tias qhov no yuav tsum tau ua kom tau sab nrauv synchronized
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // Ib qho me me, yooj yim heev LRU cache rau debug info mappings.
        //
        // Lub hit tus nqi yuav tsum tau siab heev, txij li thaum raug teeb tsis hla ntawm ntau muab qhia cov tsev qiv ntawv.
        //
        // Lub `addr2line::Context` cov qauv yog kim heev los tsim.
        // Nws tus nqi raug cia siab yuav tsum tau txiav txim siab los ntawm cov lus nug `locate` tom ntej, uas sib zog ua tus qauv tsim thaum tsim lub tuam txhab 'addr2line: : Cov ntsiab lus kom tau txais ceev nrawm.
        //
        // Yog tias peb tsis muaj lub cache no, kev hloov kho kom zoo li no yuav tsis tshwm sim, thiab qhov cim rov qab yuav yog ssssllooooowww.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // Thawj li, kuaj yog tias qhov no `lib` muaj tej yam ya uas muaj lub `addr` (tuav nyaj).Yog tias daim tshev no dhau los ces peb tuaj yeem txuas mus ntxiv hauv qab thiab txhais cov chaw nyob kom raug.
                //
                // Nco ntsoov tias peb nyob nraum siv `wrapping_add` ntawm no kom tsis txhob overflow tshev.Nws tau pom nyob rau hauv cov tsiaj qus uas lub SVMA + kev tsis ncaj ncees qhov hla dhau.
                // Nws nkawd kuj nce mentsis khib uas yuav tshwm sim tab sis muaj tsis yog ib tug lossis loj npaum li peb yuav ua li cas txog nws lwm yam tshaj li tej zaum cia li las mees cov theem txij li thaum lawv nyob nraum yuav taw tawm mus rau hauv qhov chaw.
                //
                // Qhov no yog sawv daws tuaj hauv rust-lang/backtrace-rs#329.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // Tam sim no peb paub `lib` muaj `addr`, peb tuaj yeem tshem tawm nrog kev tsis ncaj ncees kom nrhiav qhov chaw hais lub cim xeeb virutal.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Invariant: tom qab no zwj ceeb sau tsis ntxov rov qab
        // los ntawm kev ua yuam kev, nkag nkag rau cov kab no yog ntawm index 0.

        if let Some(idx) = idx {
            // Thaum lub kuas yog twb nyob rau hauv lub cache, txav mus rau pem hauv ntej.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // Thaum daim phiaj tsis nyob hauv lub cache, tsim daim phiaj qhia chaw tshiab, ntxig nws mus rau sab xub ntiag ntawm lub cache, thiab ntiab tawm cov cache qub tshaj plaws yog tias tsim nyog.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // tsis txhob xaum `'static` lub neej, nco ntsoov tias nws tau scoped rau peb tus kheej nkaus xwb
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // Txuas ntxiv tas sim neej ntawm `sym` rau `'static` txij li peb hmoov tsis tas yuav tsum nyob ntawm no, tab sis nws yog qhov ua tau tawm mus raws li kev siv yog li tsis muaj siv rau nws yuav tsum mob siab dhau tus ncej no lawm.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // Thaum kawg, tau txais daim phiaj cache lossis tsim daim phiaj tshiab rau cov ntaub ntawv no, thiab ntsuas cov ntaub ntawv DWARF kom pom cov file/line/name rau qhov chaw nyob no.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// Peb tau tuaj yeem nrhiav cov ntaub ntawv ncej rau lub cim no, thiab `addr2line` tus ncej sab hauv muaj txhua cov ntsiab lus tsis muaj tseeb.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// Yuav tsis nrhiav debug ntaub ntawv, tab sis peb pom nws nyob rau hauv lub cim rooj ntawm elf executable.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}