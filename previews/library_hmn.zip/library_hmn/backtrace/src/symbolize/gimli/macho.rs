use super::{Box, Context, Mapping, Path, Stash, Vec};
use core::convert::TryInto;
use object::macho;
use object::read::macho::{MachHeader, Nlist, Section, Segment as _};
use object::{Bytes, NativeEndian};

#[cfg(target_pointer_width = "32")]
type Mach = object::macho::MachHeader32<NativeEndian>;
#[cfg(target_pointer_width = "64")]
type Mach = object::macho::MachHeader64<NativeEndian>;
type MachSegment = <Mach as MachHeader>::Segment;
type MachSection = <Mach as MachHeader>::Section;
type MachNlist = <Mach as MachHeader>::Nlist;

impl Mapping {
    // Lub chaw thau khoom txoj kev rau cov OSX yog yog li txawv peb cia li muaj ib tug txawv kiag li kev siv ntawm cov nuj nqi no.
    // Nyob rau OSX peb yuav tsum mus probing lub filesystem rau ib Rev ntawm cov ntaub ntawv.
    //
    pub fn new(path: &Path) -> Option<Mapping> {
        // Ua ntej tshaj peb yuav tsum tau thauj tus cim UUID uas tau muab cia rau hauv macho header ntawm cov ntaub ntawv peb tau nyeem, teev ntawm `path`.
        //
        let map = super::mmap(path)?;
        let (macho, data) = find_header(Bytes(&map))?;
        let endian = macho.endian().ok()?;
        let uuid = macho.uuid(endian, data).ok()??;

        // Tom ntej no peb yuav tsum nrhiav cov ntaub ntawv `*.dSYM`.Txog tam sim no peb tsuas yog sojntsuam nrog cov npe thiab saib ib puag ncig rau qee yam uas phim `*.dSYM`.
        // Thaum nws pom peb lub hauv paus los ntawm cov ntsias peev uas nws muaj thiab sim nrhiav macho cov ntaub ntawv uas muaj qhov sib txuam UUID yog qhov ntawm peb tus kheej cov ntaub ntawv.
        //
        // Yog tias peb pom qhov sib phim uas yog cov ntawv ntsias peb xav rov qab.
        //
        //
        if let Some(parent) = path.parent() {
            if let Some(mapping) = Mapping::load_dsym(parent, uuid) {
                return Some(mapping);
            }
        }

        // Zoo li tsis muaj ib yam dabtsi phim peb UUID, yog li cia tsawg kawg xa peb tus kheej cov ntaub ntawv.
        // Qhov no yuav tsum muaj lub cim rooj rau yam tsawg kawg qee lub cim.
        //
        Mapping::mk(map, |data, stash| {
            let (macho, data) = find_header(Bytes(data))?;
            let endian = macho.endian().ok()?;
            let obj = Object::parse(macho, endian, data)?;
            Context::new(stash, obj)
        })
    }

    fn load_dsym(dir: &Path, uuid: [u8; 16]) -> Option<Mapping> {
        for entry in dir.read_dir().ok()? {
            let entry = entry.ok()?;
            let filename = match entry.file_name().into_string() {
                Ok(name) => name,
                Err(_) => continue,
            };
            if !filename.ends_with(".dSYM") {
                continue;
            }
            let candidates = entry.path().join("Contents/Resources/DWARF");
            if let Some(mapping) = Mapping::try_dsym_candidate(&candidates, uuid) {
                return Some(mapping);
            }
        }
        None
    }

    fn try_dsym_candidate(dir: &Path, uuid: [u8; 16]) -> Option<Mapping> {
        // Saib cov ntaub ntawv nyob rau hauv lub `DWARF` directory uas muaj ib txoj kev UUID mus rau tus thawj yam khoom ua ntaub ntawv thov.
        // Yog tias peb pom ib qho peb pom cov lus debug.
        //
        for entry in dir.read_dir().ok()? {
            let entry = entry.ok()?;
            let map = super::mmap(&entry.path())?;
            let candidate = Mapping::mk(map, |data, stash| {
                let (macho, data) = find_header(Bytes(data))?;
                let endian = macho.endian().ok()?;
                let entry_uuid = macho.uuid(endian, data).ok()??;
                if entry_uuid != uuid {
                    return None;
                }
                let obj = Object::parse(macho, endian, data)?;
                Context::new(stash, obj)
            });
            if let Some(candidate) = candidate {
                return Some(candidate);
            }
        }

        None
    }
}

fn find_header(mut data: Bytes<'_>) -> Option<(&'_ Mach, Bytes<'_>)> {
    use object::endian::BigEndian;

    let desired_cpu = || {
        if cfg!(target_arch = "x86") {
            Some(macho::CPU_TYPE_X86)
        } else if cfg!(target_arch = "x86_64") {
            Some(macho::CPU_TYPE_X86_64)
        } else if cfg!(target_arch = "arm") {
            Some(macho::CPU_TYPE_ARM)
        } else if cfg!(target_arch = "aarch64") {
            Some(macho::CPU_TYPE_ARM64)
        } else {
            None
        }
    };

    match data
        .clone()
        .read::<object::endian::U32<NativeEndian>>()
        .ok()?
        .get(NativeEndian)
    {
        macho::MH_MAGIC_64 | macho::MH_CIGAM_64 | macho::MH_MAGIC | macho::MH_CIGAM => {}

        macho::FAT_MAGIC | macho::FAT_CIGAM => {
            let mut header_data = data;
            let endian = BigEndian;
            let header = header_data.read::<macho::FatHeader>().ok()?;
            let nfat = header.nfat_arch.get(endian);
            let arch = (0..nfat)
                .filter_map(|_| header_data.read::<macho::FatArch32>().ok())
                .find(|arch| desired_cpu() == Some(arch.cputype.get(endian)))?;
            let offset = arch.offset.get(endian);
            let size = arch.size.get(endian);
            data = data
                .read_bytes_at(offset.try_into().ok()?, size.try_into().ok()?)
                .ok()?;
        }

        macho::FAT_MAGIC_64 | macho::FAT_CIGAM_64 => {
            let mut header_data = data;
            let endian = BigEndian;
            let header = header_data.read::<macho::FatHeader>().ok()?;
            let nfat = header.nfat_arch.get(endian);
            let arch = (0..nfat)
                .filter_map(|_| header_data.read::<macho::FatArch64>().ok())
                .find(|arch| desired_cpu() == Some(arch.cputype.get(endian)))?;
            let offset = arch.offset.get(endian);
            let size = arch.size.get(endian);
            data = data
                .read_bytes_at(offset.try_into().ok()?, size.try_into().ok()?)
                .ok()?;
        }

        _ => return None,
    }

    Mach::parse(data).ok().map(|h| (h, data))
}

// Qhov no yog siv ob qho tib si rau executables/libraries thiab cov ntaub ntawv pov thawj cov ntaub ntawv.
pub struct Object<'a> {
    endian: NativeEndian,
    data: Bytes<'a>,
    dwarf: Option<&'a [MachSection]>,
    syms: Vec<(&'a [u8], u64)>,
    syms_sort_by_name: bool,
    // Tsuas yog teem rau executables/libraries, thiab tsis yog hom khoom ntawv.
    object_map: Option<object::ObjectMap<'a>>,
    // Cov txheej Option yog rau tub nkeeg chaw thau khoom, thiab lub puab Option tso cai load uas tsis yuav tsum tau cached.
    object_mappings: Box<[Option<Option<Mapping>>]>,
}

impl<'a> Object<'a> {
    fn parse(mach: &'a Mach, endian: NativeEndian, data: Bytes<'a>) -> Option<Object<'a>> {
        let is_object = mach.filetype(endian) == object::macho::MH_OBJECT;
        let mut dwarf = None;
        let mut syms = Vec::new();
        let mut syms_sort_by_name = false;
        let mut commands = mach.load_commands(endian, data).ok()?;
        let mut object_map = None;
        let mut object_mappings = Vec::new();
        while let Ok(Some(command)) = commands.next() {
            if let Some((segment, section_data)) = MachSegment::from_command(command).ok()? {
                // Cov ntaub ntawv tawm tsam yuav tsum muaj tag nrho cov kab lus hauv ib ntu hais txog lub npe thauj.
                if segment.name() == b"__DWARF" || (is_object && segment.name() == b"") {
                    dwarf = segment.sections(endian, section_data).ok();
                }
            } else if let Some(symtab) = command.symtab().ok()? {
                let symbols = symtab.symbols::<Mach>(endian, data).ok()?;
                syms = symbols
                    .iter()
                    .filter_map(|nlist: &MachNlist| {
                        let name = nlist.name(endian, symbols.strings()).ok()?;
                        if name.len() > 0 && nlist.is_definition() {
                            Some((name, u64::from(nlist.n_value(endian))))
                        } else {
                            None
                        }
                    })
                    .collect();
                if is_object {
                    // Peb tsis nrhiav cov ntaub ntawv qhia cov khoom cim ntawm chaw nyob.
                    // Hloov chaw, peb twb paub lub cim npe los ntawm kev ua tiav, thiab peb yuav tsum tshawb ntawm lub npe kom pom cov cim sib txuam hauv cov khoom siv cov ntaub ntawv.
                    //
                    syms.sort_unstable_by_key(|(name, _)| *name);
                    syms_sort_by_name = true;
                } else {
                    syms.sort_unstable_by_key(|(_, addr)| *addr);
                    let map = symbols.object_map(endian);
                    object_mappings.resize_with(map.objects().len(), || None);
                    object_map = Some(map);
                }
            }
        }

        Some(Object {
            endian,
            data,
            dwarf,
            syms,
            syms_sort_by_name,
            object_map,
            object_mappings: object_mappings.into_boxed_slice(),
        })
    }

    pub fn section(&self, _: &Stash, name: &str) -> Option<&'a [u8]> {
        let name = name.as_bytes();
        let dwarf = self.dwarf?;
        let section = dwarf.into_iter().find(|section| {
            let section_name = section.name();
            section_name == name || {
                section_name.starts_with(b"__")
                    && name.starts_with(b".")
                    && &section_name[2..] == &name[1..]
            }
        })?;
        Some(section.data(self.endian, self.data).ok()?.0)
    }

    pub fn search_symtab<'b>(&'b self, addr: u64) -> Option<&'b [u8]> {
        debug_assert!(!self.syms_sort_by_name);
        let i = match self.syms.binary_search_by_key(&addr, |(_, addr)| *addr) {
            Ok(i) => i,
            Err(i) => i.checked_sub(1)?,
        };
        let (sym, _addr) = self.syms.get(i)?;
        Some(sym)
    }

    /// Sim los ntsaws cov ntsiab lus teb rau cov ntawv kwv.
    ///
    /// Yog hais tias dsymutil twb tsis khiav, ces tus ntsias tej zaum yuav muaj nyob rau hauv lub qhov chaw tus kwv cov ntaub ntawv.
    pub(super) fn search_object_map<'b>(&'b mut self, addr: u64) -> Option<(&Context<'b>, u64)> {
        // `object_map` muaj daim ntawv qhia los ntawm chaw nyob mus rau cov cim thiab cov kab ke.
        // Saib qhov chaw nyob thiab tau txais daim phiaj qhia cov khoom.
        let object_map = self.object_map.as_ref()?;
        let symbol = object_map.get(addr)?;
        let object_index = symbol.object_index();
        let mapping = self.object_mappings.get_mut(object_index)?;
        if mapping.is_none() {
            // Tsis cached kuas, yog li tsim nws.
            *mapping = Some(object_mapping(object_map.objects().get(object_index)?));
        }
        let cx: &'b Context<'static> = &mapping.as_ref()?.as_ref()?.cx;
        // Tsis txhob xog `'static` lub neej, nco ntsoov tias nws tau ntsuas rau peb tus kheej nkaus xwb.
        let cx = unsafe { core::mem::transmute::<&'b Context<'static>, &'b Context<'b>>(cx) };

        // Peb yuav tsum txhais qhov chaw nyob thiaj li tuaj yeem saib nws hauv DWARF hauv cov ntawv kwv yees.
        //
        debug_assert!(cx.object.syms.is_empty() || cx.object.syms_sort_by_name);
        let i = cx
            .object
            .syms
            .binary_search_by_key(&symbol.name(), |(name, _)| *name)
            .ok()?;
        let object_symbol = cx.object.syms.get(i)?;
        let object_addr = addr
            .wrapping_sub(symbol.address())
            .wrapping_add(object_symbol.1);
        Some((cx, object_addr))
    }
}

fn object_mapping(path: &[u8]) -> Option<Mapping> {
    use super::mystd::ffi::OsStr;
    use super::mystd::os::unix::prelude::*;

    let map;

    // `N_OSO` cim npe yuav tsum yog `/path/to/object.o` los yog `/path/to/archive.a(object.o)`.
    let member_name = if let Some((archive_path, member_name)) = split_archive_path(path) {
        map = super::mmap(Path::new(OsStr::from_bytes(archive_path)))?;
        Some(member_name)
    } else {
        map = super::mmap(Path::new(OsStr::from_bytes(path)))?;
        None
    };
    Mapping::mk(map, |data, stash| {
        let data = match member_name {
            Some(member_name) => {
                let archive = object::read::archive::ArchiveFile::parse(data).ok()?;
                let member = archive
                    .members()
                    .filter_map(Result::ok)
                    .find(|m| m.name() == member_name)?;
                Bytes(member.data())
            }
            None => Bytes(data),
        };
        let (macho, data) = find_header(data)?;
        let endian = macho.endian().ok()?;
        let obj = Object::parse(macho, endian, data)?;
        Context::new(stash, obj)
    })
}

fn split_archive_path(path: &[u8]) -> Option<(&[u8], &[u8])> {
    let (last, path) = path.split_last()?;
    if *last != b')' {
        return None;
    }
    let index = path.iter().position(|&x| x == b'(')?;
    let (archive, rest) = path.split_at(index);
    Some((archive, &rest[1..]))
}