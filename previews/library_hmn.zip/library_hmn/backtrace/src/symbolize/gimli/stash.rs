// tsuas yog siv rau ntawm Linux tam sim no, yog li tso cai code tuag rau lwm qhov
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Tej qhov chaw tswj fwm yooj yim rau cov byte buffers.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Allocates tsis ntawm daim kev cai tswjhwm qhov luaj li cas thiab xa rov qab los siv tau rau nws.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // KEV RUAJ NTSEG: qhov no yog tib qho haujlwm uas tsim tsa ib qho hloov tau
        // siv rau `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // KEV RUAJ NTSEG: peb yeej tsis tshem tawm cov ntsiab lus ntawm `self.buffers`, yog li kev siv
        // rau cov ntaub ntawv hauv ib yam tsis yuav nyob ntev li ntev tau raws li `self` li.
        &mut buffers[i]
    }
}