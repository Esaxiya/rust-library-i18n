use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Daws ib qho chaw nyob rau ib lub cim, dua cov cim rau lub qee kaw.
///
/// Lub luag haujlwm no yuav saib cov chaw nyob hauv thaj chaw xws li lub rooj cim cim hauv zos, lub rooj cim cim dynamic, lossis DWARF debug cov ntaub ntawv (nyob ntawm kev siv ua haujlwm) kom pom cov cim los tso tawm.
///
///
/// Qhov kaw yuav tsis hu yog tias daws teeb meem tsis tuaj yeem ua tau, thiab nws tseem yuav raug hu ntau dua ib zaug yog muaj teeb meem hauv lub luag haujlwm.
///
/// Cim yielded sawv cev rau lub tiav ntawm lub teev `addr`, rov qab file/line officers rau qhov chaw nyob (yog tias muaj).
///
/// Nco ntsoov tias yog tias koj muaj lub `Frame` ces nws pom zoo kom siv `resolve_frame` ua haujlwm hloov qhov no.
///
/// # Cov nta tseev kom muaj
///
/// Muaj nuj nqi no yuav tsum muaj `std` qhov tseem ceeb ntawm `backtrace` crate yuav tsum tau qhib, thiab `std` lub peev xwm raug qhib los ntawm lub neej ntawd.
///
/// # Panics
///
/// Txoj haujlwm no sib zog ua haujlwm ib txwm tsis panic, tab sis yog `cb` muab panics tom qab ntawd qee lub platform yuav yuam ob panic kom rho tawm cov txheej txheem.
/// Qee cov platform siv C lub tsev qiv ntawv uas nyob hauv sab hauv siv cov callbacks uas tsis tuaj yeem raug mob tsis dhau, yog li kev sib kis ntawm `cb` yuav ua rau cov txheej txheem rho menyuam tawm.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // tsuas saib rau sab saum toj ncej
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Daws qhov ncej yav dhau los ua cim rau ib lub cim, dhau ntawm lub cim mus rau qhov kev txwv kaw.
///
/// Qhov no functin ua ib tug yam ntxwv raws li `resolve` tsuas hais tias nws yuav siv sij hawm ib tug `Frame` li ib tug sib cav es tsis txhob ntawm ib qho chaw nyob.
/// Qhov no tuaj yeem tso qee lub platform kev ua haujlwm ntawm thim rov qab los muab cov cim cim lus tseeb lossis cov ntaub ntawv hais txog cov kab sib chaws inline piv txwv.
///
/// Nws raug nquahu kom siv qhov no yog tias koj tuaj yeem.
///
/// # Cov nta tseev kom muaj
///
/// Muaj nuj nqi no yuav tsum muaj `std` qhov tseem ceeb ntawm `backtrace` crate yuav tsum tau qhib, thiab `std` lub peev xwm raug qhib los ntawm lub neej ntawd.
///
/// # Panics
///
/// Txoj haujlwm no sib zog ua haujlwm ib txwm tsis panic, tab sis yog `cb` muab panics tom qab ntawd qee lub platform yuav yuam ob panic kom rho tawm cov txheej txheem.
/// Qee cov platform siv C lub tsev qiv ntawv uas nyob hauv sab hauv siv cov callbacks uas tsis tuaj yeem raug mob tsis dhau, yog li kev sib kis ntawm `cb` yuav ua rau cov txheej txheem rho menyuam tawm.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // tsuas saib rau sab saum toj ncej
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// IP qhov tseem ceeb los ntawm cov ntas ntas feem ntau (always?) qhov kev qhia *tom qab* hu xov tooj uas yog qhov tseeb cov kab ntaiv.
// Symbolizing no rau ua lub filename/line tooj yuav tsum tau ib tug tom ntej thiab tej zaum mus rau hauv lub void yog hais tias nws yog nyob ze rau qhov kawg ntawm cov nuj nqi.
//
// Qhov no zoo li qhov pib ib txwm muaj ntawm txhua lub sijhawm, yog li peb ib txwm rho tawm ib qho ntawm ib tus ip daws los daws nws rau qhov kev qhia hu ua dhau los es tsis yog cov kev qhia raug xa rov qab.
//
//
// Qhov tsim nyog peb yuav tsis ua qhov no.
// Qhov tseeb peb xav tau cov neeg hu ntawm `resolve` APIs ntawm no los tswj kev ua tus -1 thiab tus account uas lawv xav tau cov ntaub ntawv qhov chaw nyob rau qhov *yav dhau los* kev qhia, tsis yog qhov tam sim no.
// Qhov tseeb tiag mas peb yuav kuj las rau `Frame` yog hais tias peb yog tseeb qhov chaw nyob ntawm lub tom ntej no qhia ntawv los yog cov tam sim no.
//
// Txog rau tam sim no txawm tias qhov no yog qhov kev txhawj xeeb zoo nkauj li peb tsuas yog sab hauv ib txwm txiav ib qho.
// Tau txais kev pab yuav tsum ua hauj lwm thiab tau txais zoo zoo nkauj tau, yog li peb yuav tsum tau zoo txaus.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Tib yam li `resolve`, tsuas yog tsis nyab xeeb nws yog unsynchronized.
///
/// Txoj haujlwm no tsis muaj synchronization guarentees tab sis muaj nyob thaum `std` cov yam ntxwv ntawm no crate tsis tau muab tso ua ke.
/// Saib tus `resolve` muaj nuj nqi rau cov ntaub ntawv ntau ntxiv thiab cov qauv.
///
/// # Panics
///
/// Saib cov lus qhia txog `resolve` rau caveats rau `cb` panicking.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Tib yam li `resolve_frame`, tsuas tsis zoo raws li nws yog unsynchronized.
///
/// Txoj haujlwm no tsis muaj synchronization guarentees tab sis muaj nyob thaum `std` cov yam ntxwv ntawm no crate tsis tau muab tso ua ke.
/// Saib cov `resolve_frame` muaj nuj nqi rau ntau cov ntaub ntawv thiab cov piv txwv.
///
/// # Panics
///
/// Saib cov lus qhia txog `resolve_frame` rau caveats rau `cb` panicking.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// A trait sawv cev daws teeb meem ntawm lub cim hauv ib cov ntawv.
///
/// Cov trait no yog kom raws li trait tawm tswv yim rau qhov kaw tau muab rau `backtrace::resolve` lub luag haujlwm, thiab nws tau zoo xa raws li nws tsis paub txog qhov kev siv ua twg qab nws.
///
///
/// Ib lub cim tuaj yeem qhia cov ntsiab lus ntsig txog kev ua haujlwm, piv txwv li lub npe, filename, tus lej kab, chaw nyob meej, thiab lwm yam.
/// Tsis yog txhua txhua cov ntaub ntawv yog yeej ib txwm muaj nyob rau hauv ib lub cim, txawm li cas los, li ntawd, tag nrho txoj kev rov qab mus ib `Option`.
///
///
pub struct Symbol {
    // TODO: qhov kev ua neej nyob thoob plaws qhov kev xav tau no yuav tsum muaj kev ywj pheej thaum kawg rau `Symbol`,
    // tab sis tam sim no uas yog qhov kev hloov pauv.
    // Txog rau tam sim no qhov no muaj kev nyab xeeb txij li `Symbol` tsuas yog tau muab coj los ntawm kev siv thiab tsis tuaj yeem raug cloned.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Rov qab lub npe ntawm txoj haujlwm no.
    ///
    /// Cov rov qab qauv yuav siv tau los lus nug ntau yam zog txog lub cim npe:
    ///
    ///
    /// * Lub `Display` siv yuav sau tawm lub demangled cim.
    /// * Lub nyoos `str` nqi ntawm cov cim yuav tsum accessed (yog hais tias nws txoj kev siv tau utf-8).
    /// * Cov nyoos nyoos rau lub cim lub npe tuaj yeem nkag mus.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Rov qab los rau chaw pib ntawm txoj haujlwm no.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Rov qab los lub filename nyoos li hlais.
    /// Qhov no yog tsuas pab tau rau cov `no_std` tej kev kawm.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Rov qab rau kab naj npawb rau qhov twg lub cim no tam sim no ua haujlwm.
    ///
    /// Tsuas yog gimli tam sim no muab tus nqi ntawm no thiab txawm tias tom qab ntawd tsuas yog `filename` rov `Some`, thiab yog li nws yog tom qab ntawd thiaj li yuav muaj qhov zoo sib xws.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Rov qab tus lej kab rau qhov twg lub cim no tam sim no ua haujlwm.
    ///
    /// Qhov no rov qab nqi yog feem ntau `Some` yog `filename` rov `Some`, thiab yog thiaj li yuav raug zoo li caveats.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Rov cov ntaub ntawv npe qhov twg no muaj nuj nqi twb hais tseg.
    ///
    /// Qhov no tam sim no tsuas yog muaj thaum libbacktrace lossis gimli tab tom siv (piv txwv
    /// unix platforms lwm) thiab thaum binary tau tso ua ke nrog debuginfo.
    /// Yog hais tias tej yam uas cov tej yam kev mob yog ntsib ces qhov no yuav yuav rov qab `None`.
    ///
    /// # Cov nta tseev kom muaj
    ///
    /// Muaj nuj nqi no yuav tsum muaj `std` qhov tseem ceeb ntawm `backtrace` crate yuav tsum tau qhib, thiab `std` lub peev xwm raug qhib los ntawm lub neej ntawd.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Tej zaum ib tug parsed C++ cim, yog parsing lub mangled cim raws li Rust ua tsis tau tejyam.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Nco ntsoov khaws cov xoom no, kom qhov `cpp_demangle` lub ntsej muag tsis muaj nqi thaum xiam oob khab.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Cov ntaub qhwv ib ncig ntawm lub cim lub npe los muab ergonomic accessors rau lub npe demangled, cov khoom nyoos bytes, txoj hlua nyoos, thiab lwm yam.
///
// Txheeb xyuas cov cai tuag rau thaum `cpp_demangle` lub ntsej muag tsis ua haujlwm.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Tsim lub cim tshiab lub npe los ntawm cov nqaij nyoos hauv bytes.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Rov qab (mangled) lub cim nyoos lub npe ua `str` yog tias lub cim siv tau utf-8.
    ///
    /// Siv `Display` kev siv yog tias koj xav tau lub demangled version.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Rov cov nqaij nyoos cim npe raws li ib daim ntawv teev bytes
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Qhov no tuaj yeem luam tawm tau yog tias lub cim demangled tsis tau siv tau, yog li siv qhov kev ua yuam kev ntawm no tsis hais tawm los ntawm sab nraud.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Sim reclaim uas cached nco siv los symbolicate chaw nyob.
///
/// Cov qauv no yuav sim tso tawm txhua cov ntaub ntawv thoob ntiaj teb uas tau muab khaws cov ntaub ntawv hauv ntiaj teb lossis hauv cov xov uas feem ntau sawv cev parsed DWARF cov ntaub ntawv lossis zoo sib xws.
///
///
/// # Caveats
///
/// Thaum uas cov nuj nqi no ib txwm muaj nws tsis tau ua dab tsi rau feem ntau cov kev siv.
/// Cov tsev qiv ntawv zoo li dbghelp lossis libbacktrace tsis muab cov vaj tse los cuam tshuam rau lub xeev thiab tswj kev siv lub cim xeeb.
/// Rau tam sim no lub `gimli-symbolize` feature ntawm no crate yog lub tsuas feature nyob qhov twg no muaj nuj nqi muaj tej yam nyhuv.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}