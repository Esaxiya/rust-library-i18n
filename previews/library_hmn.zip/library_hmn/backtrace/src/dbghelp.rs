//! Ib qho qauv siv los pab tswj hwm dbghelp txoj hlua khi ntawm Windows
//!
//! Backtraces ntawm Windows (tsawg kawg rau MSVC) feem ntau tau tsav los ntawm `dbghelp.dll` thiab cov haujlwm ntau uas nws muaj.
//! Cov haujlwm no tau thauj khoom tam sim no *dynamically* ntau dua li txuas rau `dbghelp.dll` zoo li qub.
//! Qhov no yog tam sim no ua los ntawm tus txheej txheem tsev qiv ntawv (thiab yog nyob rau hauv kev tshawb xav yuav tsum tau muaj), tab sis yog ib qho kev rau siab mus pab txo qhov zoo li qub dll dependencies ntawm lub tsev qiv ntawv txij li thaum backtraces yog feem ntau zoo nkauj los tsis ua cas.
//!
//! Ntawd tau hais, `dbghelp.dll` yuav luag txhua lub sijhawm ua tiav ntawm Windows.
//!
//! Nco ntsoov tias vim peb tau thau txhua qhov kev txhawb nqa zoo peb tsis tuaj yeem siv cov lus txhais nyoos hauv `winapi`, tab sis, peb xav kom txhais cov nuj nqi pointer yam peb tus kheej thiab siv qhov ntawd.
//! Peb tsis tshua xav nyob hauv kev lag luam ntawm qhov luam tawm winapi, yog li peb muaj Cargo feature `verify-winapi` uas lees tias txhua txoj hlua khi cov uas nyob hauv winapi thiab cov yam ntxwv no tau qhib rau CI.
//!
//! Thaum kawg, koj yuav nco ntsoov ntawm no tias qhov dll rau `dbghelp.dll` yeej tsis tau thau tawm, thiab tam sim no yog txhob txwm ua.
//! Qhov kev xav yog tias peb tuaj yeem thoob plaws thoob plaws nws thiab siv nws ntawm kev hu rau API, tsis txhob kim loads/unloads.
//! Yog tias qhov no yog qhov teeb meem rau cov xaim ntes los yog tej yam zoo li peb tuaj yeem hla tus choj thaum peb tau los txog.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Ua haujlwm ncig `SymGetOptions` thiab `SymSetOptions` tsis tau nyob hauv winapi nws tus kheej.
// Txwv tsis pub qhov no yog tsuas siv thaum peb nyob nraum ob npaug rau-xyuas hom tiv thaiv winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Tsis txhais tau hais tias nyob rau hauv winapi tsis tau
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Qhov no tau txhais hauv winapi, tab sis nws tsis raug (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Tsis txhais tau hais tias nyob rau hauv winapi tsis tau
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Qhov no macro yog siv los txhais tau ib tug `Dbghelp` qauv uas hauv muaj tag nrho cov nuj nqi pointers hais tias peb yuav thauj khoom.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// Tus nqi DLL rau `dbghelp.dll`
            dll: HMODULE,

            // Txhua muaj nuj nqi pointer rau txhua txoj hauj lwm peb yuav siv
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Thaum pib peb tsis tau thauj khoom DLL
            dll: 0 as *mut _,
            // Initiall txhua qhov kev ua haujlwm tau teeb tsa rau xoom kom hais tias lawv yuav tsum tau thauj khoom zoo.
            //
            $($name: 0,)*
        };

        // Yam yooj yim typedef rau txhua hom ua haujlwm.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Attempts mus qhib `dbghelp.dll`.
            /// Rov qab ua tiav yog tias nws ua haujlwm lossis ua yuam kev yog `LoadLibraryW` poob.
            ///
            /// Panics yog tsev qiv ntawv yog twb loaded.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Muaj nuj nqi rau txhua txoj kev uas peb xav siv.
            // Thaum hu ua nws yuav yog nyeem cached muaj nuj nqi pointer los yog thauj nws thiab rov qab mus rau hauv lub loaded nqi.
            // Loads yog khav rau kawm tau ntawv zoo.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Kev sib nkag siab yooj yim siv los siv lub pob kom huv si mus siv dbghelp haujlwm.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Initialize tag nrho cov kev pab txhawb nqa tsim nyog nkag mus `dbghelp` API zog los ntawm qhov no crate.
///
///
/// Nco ntsoov tias qhov no muaj nuj nqi yog **zoo**, nws internally nws muaj nws tus kheej synchronization.
/// Tseem nco ntsoov tias nws muaj kev nyab xeeb hu rau qhov haujlwm no ntau zaus recursively.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Ua ntej tshaj plaws peb yuav tsum tau ua yog los synchronize txoj haujlwm no.Qhov no yuav tsum tau hu ua tib lub sijhawm los ntawm lwm yam threads los yog recursively tsis pub dhau ib thread.
        // Nco ntsoov tias nws tau dag dua li ntawd txawm tias vim li cas peb nyob nraum siv ntawm no, `dbghelp`,*kuj* xav tau synchronized nrog txhua lwm cov neeg hu rau `dbghelp` hauv tus txheej txheem no.
        //
        // Feem ntau tsis muaj qhov tseeb uas ntau hu rau `dbghelp` nyob rau hauv tib txoj kev thiab peb tuaj yeem muaj kev nyab xeeb xav tias peb tsuas yog tus nkag mus siv nws.
        // Muaj, txawm li cas los xij, ib tus thawj tus neeg siv peb peb yuav tsum txhawj xeeb txog uas yog ironically peb tus kheej, tab sis nyob hauv lub tsev qiv ntawv txheem.
        // Lub Rust txheem tsev qiv ntawv yog nyob ntawm no crate rau backtrace them nyiaj yug, thiab qhov no crate kuj tau tshwm sim rau crates.io.
        // Qhov no txhais tau tias yog tias lub tsev qiv ntawv txheem luam ntawv panic backtrace nws yuav muaj kev sib tw nrog crate los ntawm crates.io, ua rau muaj teeb meem segfaults.
        //
        // Txhawm rau pab daws qhov teeb meem synchronization no peb ntiav Windows-qhia qhov tseeb ntawm no (nws yog, tom qab tag nrho, lub Windows-tshwj xeeb txwv txog kev sib txuas ua ke).
        // Peb tsim * * ntu-hauv zos * npe hu ua mutex los tiv thaiv kev hu no.
        // Lub tswv yim no yog tias tus txheej txheem tsev qiv ntawv thiab no crate tsis tau muab Rust-theem APIs rau synchronize no tab sis muaj peev xwm es tsis txhob ua hauj lwm qab lub scenes kom paub tseeb tias lawv nyob nraum synchronizing nrog ib leeg.
        //
        // Hais tias txoj kev thaum no muaj nuj nqi no yog hu ua los ntawm tus txheej txheem tsev qiv ntawv los yog los ntawm crates.io peb yuav tau nco ntsoov hais tias tus tib mutex yog kis tau.
        //
        // Yog li ntawd tag nrho cov uas yog hais tias yog thawj zaug uas peb ua no yog peb atomically tsim ib tug `HANDLE` uas yog ib tug muaj npe mutex rau Windows.
        // Peb synchronize me ntsis nrog lwm txoj xov sib qhia txoj haujlwm no tshwj xeeb thiab xyuas kom meej tias tsuas yog ib tus kov raug tsim rau piv txwv ntawm txoj haujlwm no.
        // Nco ntsoov tias tus kov yeej tsis kaw ib zaug nws muab cia rau hauv lub ntiaj teb no.
        //
        // Tom qab peb tau mus lub ntsuas phoo peb tsuas tau nws, thiab peb cov `Init` kov peb tes tawm yuav yog lub luag haujlwm rau tso nws thaum kawg.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Ok, phew!Tam sim no tias peb txhua tus muaj kev nyab xeeb synchronized, cia peb pib ua txhua yam.
        // Ua ntej tshaj peb xav tau los xyuas kom meej tias `dbghelp.dll` yog qhov tau thauj khoom hauv txoj kev no.
        // Peb ua li no dynamically kom tsis txhob muaj zoo li qub quav.
        // Qhov no yav dhau los ua tiav los ua haujlwm nyob ib ncig ntawm qhov teeb meem sib txawv ntawm cov sib txawv thiab yog npaj rau ua binaries ntau me ntsis ntxiv txij li qhov no feem ntau tsuas yog kev siv debugging.
        //
        //
        // Thaum peb tau qhib `dbghelp.dll` peb xav tau hu rau qee qhov pib ua haujlwm hauv nws, thiab qhov ntawd tseem ntxiv hauv qab no.
        // Peb tsuas yog ua qhov no ib zaug, txawm hais tias, yog li peb tau txais lub ntiaj teb boolean qhia tias peb tau ua tiav lossis tsis tau.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Nco ntsoov tias `SYMOPT_DEFERRED_LOADS` tus chij tau teeb tsa, vim tias raws li MSVC tus kheej cov ntawv hais txog qhov no: "This is the fastest, most efficient way to use the symbol handler.", yog li cia tus ntawd!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Qhov ua tau pib cim rau MSVC.Nco ntsoov tias qhov no tuaj yeem swb, tab sis peb tsis quav ntsej nws.
        // Tsis muaj ib tuj ntawm kev kos duab ua ntej rau qhov no rau ib qho, tab sis LLVM sab hauv zoo li tsis quav ntsej tus nqi xa rov qab ntawm no thiab ib qho ntawm kev nyiam huv lub tsev qiv ntawv hauv LLVM luam tawm cov lus ceeb toom ntshai yog tias qhov no ua tsis tiav tab sis yeej tsis quav ntsej nws hauv lub sijhawm ntev.
        //
        //
        // Ib qhov teeb meem no los txog ntau Rust yog tias lub tsev qiv ntawv txheem thiab no crate ntawm crates.io ob leeg xav tau los sib tw rau `SymInitializeW`.
        // Lub tsev khaws ntaub ntawv keeb kwm yav dhau los xav pib ua kev ntxuav tu ntau lub sijhawm, tab sis tam sim no nws siv cov crate no txhais tau hais tias ib tug neeg yuav tau txais kev pib ua ntej thiab lwm tus yuav khaws qhov pib ntawd.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}