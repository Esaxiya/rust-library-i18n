#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// Ib daim ntawv foos rau rov qab.
///
/// Hom no tuaj yeem siv los sau lub backtrace tsis hais qhov twg backtrace nws tus kheej los ntawm.
/// Yog hais tias koj muaj ib tug `Backtrace` hom ces nws `Debug` siv twb siv no printing hom.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// Lub yeej ntawm printing hais tias peb yuav sau
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Luam tawm ib ncig sab nraud uas tsuas yog muaj cov ntaub ntawv muaj feem cuam tshuam
    Short,
    /// Luam tawm ib daim ntaiv uas muaj cov ncauj lus qhia tau txhua qhov
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Tsim tus tshiab `BacktraceFmt` uas yuav sau cov tso zis rau `fmt` X muab.
    ///
    /// Qhov kev sib cav `format` yuav tswj cov style uas backtrace tau luam tawm, thiab `print_path` kev sib cav yuav raug siv los luam `BytesOrWideString` piv txwv ntawm filenames.
    /// Qhov no hom nws tus kheej tsis ua tej yam luam filenames, tab sis qhov no callback yog yuav tsum tau ua li ntawd.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Luam tawm ua ntej rau sab nraum qab yuav tsum sau.
    ///
    /// Qhov no yuav tsum muaj ntawm qee lub vev xaib rau backtraces tau tag nrho cov cim tom qab, thiab txwv tsis pub qhov no tsuas yog thawj txoj kev koj hu tom qab tsim `BacktraceFmt`.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Ntxiv ib kablus rau lub backtrace tsim tawm.
    ///
    /// Qhov no ua rov qab ib tug RAII Piv txwv ntawm ib tug `BacktraceFrameFmt` uas yuav siv tau los ua tau sau ib tug ncej, thiab nyob rau kev puas tsuaj nws yuav increment tus ncej counter.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Ua tiav qhov backtrace tso tawm.
    ///
    /// Qhov no yog tam sim no tsis muaj-op tab sis tau ntxiv rau future sib raug zoo nrog kev txhawb nqa sab nraud.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // Tam sim no ib tug tsis muaj-op-- xws li no hook cia rau future ntxiv.
        Ok(())
    }
}

/// Ib daim ntawv rau tsuas yog ib tug ncej ntawm lub backtrace.
///
/// Hom no yog tsim los ntawm `BacktraceFmt::frame` muaj nuj nqi.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Luam tawm `BacktraceFrame` nrog cov qauv no.
    ///
    /// Qhov no yuav txheeb tau txhua qhov `BacktraceSymbol` tam sim no nyob rau hauv `BacktraceFrame`.
    ///
    /// # Cov nta tseev kom muaj
    ///
    /// Muaj nuj nqi no yuav tsum muaj `std` qhov tseem ceeb ntawm `backtrace` crate yuav tsum tau qhib, thiab `std` lub peev xwm raug qhib los ntawm lub neej ntawd.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// Prints ib `BacktraceSymbol` nyob rau hauv ib `BacktraceFrame`.
    ///
    /// # Cov nta tseev kom muaj
    ///
    /// Muaj nuj nqi no yuav tsum muaj `std` qhov tseem ceeb ntawm `backtrace` crate yuav tsum tau qhib, thiab `std` lub peev xwm raug qhib los ntawm lub neej ntawd.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: qhov no tsis zoo uas peb tsis tas luam dab tsi
            // nrog tsis-utf8 filenames.
            // Thankfully yuav luag txhua yam yog utf8 yog li qhov no yuav tsum tsis txhob ua qhov phem dhau.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Luam tawm cov lus nyoos coj los saib xyuas `Frame` thiab `Symbol`, feem ntau los ntawm nyob sab hauv xov tooj ntawm no crate.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Ntxiv cov ntoo nyoos rau sab nraub qaum.
    ///
    /// Cov qauv no, tsis zoo li yav dhau los, yuav siv sij hawm sib cav nyoos nyob rau kis lawv tau los ntawm ntau qhov chaw.
    /// Nco ntsoov hais tias qhov no tej zaum yuav hu ua ntau lub sij hawm rau ib tug ncej.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Ntxiv cov kab nyoos rau sab nraub qaum, nrog rau cov ntawv qhia.
    ///
    /// Qhov no txoj kev, zoo li lub yav dhau los, yuav siv sij hawm lub raw cov lus sib cav nyob rau hauv cov ntaub ntawv lawv nyob nraum ua qhov chaw los ntawm qhov chaw txawv.
    /// Nco ntsoov hais tias qhov no tej zaum yuav hu ua ntau lub sij hawm rau ib tug ncej.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Fuchsia tsis muaj peev xwm los ua tus cim rau hauv tus txheej txheem yog li nws muaj cov qauv tshwj xeeb uas tuaj yeem siv los ua qhov cim tom qab.
        // Luam tawm tias hloov chaw luam ntawv hauv peb tus kheej ntawm no.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Tsis tas yuav tsum luam tawm "null" ntas, nws tsuas yog txhais tau tias qhov system backtrace tau mob siab rau txhawm rau taug qab rov qab super deb.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Yuav kom txo TCB loj hauv Sgx enclave, peb tsis xav ua tus cim daws teeb meem ua haujlwm.
        // Tiamsis, peb yuav muaj peev xwm sau lub offset ntawm qhov chaw nyob ntawm no, uas yuav tsum tau tom qab mapped mus yog muaj nuj nqi.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Sau lub Performance index ntawm tus ncej raws li zoo raws li lub yeem qhia pointer ntawm tus ncej.
        // Yog tias peb tshaj li thawj lub cim ntawm lub thav duab no tab sis peb tsuas yog luam tawm qhov tsim nyog.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Ntxiv mus sau tawm lub npe cim, siv lwm hom ntawv qhia rau cov ntaub ntawv ntxiv yog tias peb nyob nraum qab.
        // Ntawm no peb kuj lis cov cim uas tsis muaj npe,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // Thiab kav mus, luam tawm cov filename/line tooj yog lawv muaj.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line yog sau rau ntawm cov kab nyob rau hauv lub cim npe, ces sau ib co tsim nyog whitespace txheeb ntawm txoj cai-dlhos peb tus kheej.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Rho tawm rau peb sab hauv kev hu rov qab los luam tawm lub npe thiab tom qab ntawd luam tawm tus naj npawb xov tooj.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Ntxiv rau kem naj npawb, yog tias muaj.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Peb tsuas yog txhawj txog thawj lub cim ntawm tus ncej
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}