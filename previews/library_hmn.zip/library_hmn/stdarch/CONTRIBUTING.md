# Pab rau stdarch

Lub `stdarch` crate yog qhov ntau tshaj li txaus siab los lees txais kev koom tes!Ua ntej koj yuav tej zaum xav mus saib lub repository thiab kom paub tseeb tias kev ntsuam xyuas ntawv rau koj:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Qhov twg `<your-target-arch>` yog lub hom phiaj triple li siv los ntawm `rustup`, piv txwv li `x86_x64-unknown-linux-gnu` (tsis muaj ib qho ua ntej `nightly-` lossis zoo sib xws).
Tseem nco ntsoov tias lub chaw cia khoom no yuav tsum muaj cov kab tsaus ntuj ntawm Rust!
Qhov saum toj no kev ntsuam xyuas ua nyob rau hauv qhov tseeb yuav tsum tau nightly rust yuav lub neej ntawd rau koj lub cev, mus teev uas siv `rustup default nightly` (thiab `rustup default stable` rau revert).

Yog hais tias ib yam ntawm cov saum toj no cov kauj ruam tsis txhob ua hauj lwm, [please let us know][new]!

Ntxiv mus koj tuaj yeem [find an issue][issues] los pab tawm, peb tau xaiv ob peb tus nrog [`help wanted`][help] thiab [`impl-period`][impl] cim npe uas tuaj yeem siv qee yam kev pab. 
Tej zaum koj yuav feem ntau xav nyob rau hauv [#40][vendor], siv tag nrho cov vendor intrinsics rau x86.Tias qhov teeb meem tau txais qee tus taw tes zoo txog kev pib qhov twg!

Yog tias koj tau txais cov lus nug dav dav nyob rau [join us on gitter][gitter] thiab nug ib puag ncig!Xav mus rau ping xws li@BurntSushi lossis@alexcrichton nrog cov lus nug.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Yuav sau cov qauv li cas rau stdarch intrinsics

Nws muaj qee qhov nta uas yuav tsum raug ua rau kom muab qhov tseem ceeb rau kev ua haujlwm kom raug thiab qhov piv txwv yuav tsum tsuas yog khiav los ntawm `cargo test --doc` thaum lub zog tau txhawb los ntawm CPU.

Yog li ntawd, lub neej ntawd `fn main` uas tsim los ntawm `rustdoc` yuav tsis ua haujlwm (feem ntau).
Xav txog kev siv cov hauv qab no ua cov lus qhia kom ntseeg tau tias koj qhov piv txwv ua haujlwm raws li xav.

```rust
/// # // Peb xav tau cfg_target_feature kom ntseeg tau tias cov piv txwv tsuas yog
/// # // khiav los ntawm `cargo test --doc` thaum lub CPU txhawb lub feature
/// # #![feature(cfg_target_feature)]
/// # // Peb xav target_feature rau lub intrinsic mus ua hauj lwm
/// # #![feature(target_feature)]
/// #
/// # // rustdoc los ntawm neej ntawd siv `extern crate stdarch`, tab sis peb xav tau qhov
/// # // `#[macro_use]`
/// # # [macro_use] txawv crate stdarch;
/// #
/// # // Qhov tseem ceeb muaj nuj nqi
/// # fn main() {
/// #     // Tsuas yog khiav qhov no yog `<target feature>` txaus siab
/// #     yog cfg_feature_enabled! ("<target feature>"){
/// #         // Tsim ib tug `worker` nuj nqi uas yuav tsuas yuav khiav yog hais tias tus lub hom phiaj feature
/// #         // muaj kev txhawb nqa thiab xyuas kom meej tias `target_feature` tau qhib rau koj tus neeg ua haujlwm
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         tsis nyab xeeb fn worker() {
/// // Sau koj qhov piv txwv ntawm no.Feature kev intrinsics yuav ua hauj lwm nyob ntawm no!Mus qus!
///
/// #         }
///
/// #         tsis zoo { worker(); }
/// #     }
/// # }
```

Yog hais tias ib co ntawm cov saum toj no syntax tsis zoo paub, lub [Documentation as tests] seem ntawm lub [Rust Book] qhia txog cov `rustdoc` syntax zoo heev.
Raws li ib txwm muaj, xav tias dawb rau [join us on gitter][gitter] thiab nug peb yog tias koj ntaus snags, thiab ua tsaug rau koj pab txhim kho cov ntaub ntawv ntawm `stdarch`!

# Lwm Txoj Kev Kuaj Cov Lus Qhia

Feem ntau nws pom zoo kom koj siv `ci/run.sh` los khiav cov ntawv xeem.
Txawm li cas los qhov no tej zaum yuav tsis ua hauj lwm rau koj, xws li yog hais tias koj nyob rau hauv Windows.

Nyob rau hauv cov ntaub ntawv uas koj yuav poob rov qab mus khiav `cargo +nightly test` thiab `cargo +nightly test --release -p core_arch` rau kev soj ntsuam qhov code tiam.
Nco ntsoov tias cov no xav tau cov cuab yeej nruab hnub hmo ntuj kom tau nruab thiab rau `rustc` kom paub txog koj lub phiaj xwm triple thiab nws lub CPU.
Hauv qhov tshwj xeeb koj yuav tsum teeb tsa `TARGET` ib puag ncig hloov pauv raws li koj xav tau rau `ci/run.sh`.
Ntxiv rau koj yuav tsum teeb tsa `RUSTCFLAGS` (xav tau `C`) txhawm rau taw qhia lub hom phiaj phiaj, piv txwv li `RUSTCFLAGS="-C -target-features=+avx2"`.
Koj tseem tuaj yeem tsim `-C -target-cpu=native` yog tias koj yog "just" tsim tawm tsam koj lub CPU tam sim no.

Yuav tau ceeb toom tias thaum koj siv tau cov no lwm cov lus qhia, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], xws li
kev qhia txog kev sim tsim tawm tuaj yeem swb vim tias tus disassembler muaj npe lawv sib txawv, xws li
nws yuav tsim `vaesenc` siv `aesenc` cov lus qhia txawm hais tias lawv coj zoo ib yam.
Tsis tas li ntawd cov lus qhia no ua tsawg kev ntsuam xyuas dua yuav nquag ua li cas, yog li ntawd tsis tsis tau ras hais tias thaum koj nws thiaj li rub-thov ib co uas tsis zaum yuav qhia txog rau cov kev ntsuam xyuas tsis tau kev pab no.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






