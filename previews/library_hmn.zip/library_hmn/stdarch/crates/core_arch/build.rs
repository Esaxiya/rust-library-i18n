use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Siv los qhia peb cov `#[assert_instr]` cov lus tshaj tawm tias txhua tus simd intrinsics yog muaj los kuaj lawv cov codegen, vim qee qhov tau dhau los ua qab qhov ntxiv `-Ctarget-feature=+unimplemented-simd128` uas tsis muaj qhov sib npaug hauv `#[target_feature]` tam sim no.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}