`core::arch` - Rust lub tsev qiv ntawv tseem ceeb architecture tsim tshwj xeeb intrinsics
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

Lub `core::arch` module ua cov qauv tsim kev tiv thaiv kom tsis muaj vaj huam sib luag (piv txwv li SIMD).

# Usage 

`core::arch` yog muaj ua ib feem ntawm `libcore` thiab nws tau rov ua lag luam los ntawm `libstd`.Xav siv nws ntawm `core::arch` los yog `std::arch` tshaj ntawm no lub crate.
Cov yam ntxwv tsis ruaj khov feem ntau muaj nyob hauv nightly Rust ntawm `feature(stdsimd)`.

Siv `core::arch` ntawm no lub crate yuav tsum tau nightly Rust, thiab nws tau (thiab) lov feem ntau.Tib qho xwm txheej uas koj yuav tsum xav txog siv nws ntawm no crate yog:

* yog tias koj xav tau rov ua `core::arch` koj tus kheej, piv txwv li, nrog cov phiaj tshwj xeeb-nta tau tsis tau qhib rau `libcore`/`libstd`.
Note: yog tias koj xav tau rov sau nws rau qhov tsis yog hom phiaj, thov nyiam siv `xargo` thiab rov sau `libcore`/`libstd` raws li tsim nyog es tsis txhob siv cov crate.
  
* siv ib co nta uas tej zaum yuav tsis muaj txawm qab tsis ruaj tsis khov Rust nta.Peb yuav ua tiag kom cov mus rau ib tug tsawg kawg nkaus.
Yog tias koj xav siv qee qhov ntawm no, thov qhib qhov teeb meem kom peb tuaj yeem nthuav tawm lawv nyob rau hmo ntuj Rust thiab koj tuaj yeem siv lawv los ntawm qhov ntawd.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` feem ntau tau faib raws li cov lus cog tseg ntawm ob qho tib si MIT daim ntawv tso cai thiab Apache Daim Ntawv Tso Cai (Version 2.0), nrog cov feem tau them los ntawm ntau yam BSD zoo li daim ntawv tso cai.

Saib LICENSE-APACHE, thiab LICENSE-MIT kom paub meej.

# Contribution

Tshwj tsis yog koj hais ntsees txwv tsis pub lwm yam, kev txhawb nqa tswv yim rau kev koom rau hauv `core_arch` los ntawm koj, raws li sau tseg hauv Apache-2.0 daim ntawv tso cai, yuav tsum yog ob daim ntawv tso cai raws li saum toj no, tsis muaj ib qho lus cog tseg ntxiv lossis cov xwm txheej.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












