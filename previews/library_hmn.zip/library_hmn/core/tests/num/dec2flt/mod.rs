#![allow(overflowing_literals)]

mod parse;
mod rawfp;

// Siv ib tug ntab literal, tig nws mus rau hauv ib txoj hlua nyob rau hauv ntau txoj kev (uas yog tag nrho cov ntseeg yuav tsum tau tseeb) thiab seb cov neeg hlua yog parsed rov qab mus rau tus nqi ntawm cov literal.
//
// Yuav tsum tau ib tug *polymorphic literal*, piv txwv li, ib tug uas yuav pab raws li f64 raws li f32.
macro_rules! test_literal {
    ($x: expr) => {{
        let x32: f32 = $x;
        let x64: f64 = $x;
        let inputs = &[stringify!($x).into(), format!("{:?}", x64), format!("{:e}", x64)];
        for input in inputs {
            assert_eq!(input.parse(), Ok(x64));
            assert_eq!(input.parse(), Ok(x32));
            let neg_input = &format!("-{}", input);
            assert_eq!(neg_input.parse(), Ok(-x64));
            assert_eq!(neg_input.parse(), Ok(-x32));
        }
    }};
}

#[test]
fn ordinary() {
    test_literal!(1.0);
    test_literal!(3e-5);
    test_literal!(0.1);
    test_literal!(12345.);
    test_literal!(0.9999999);

    if cfg!(miri) {
        // Miri tau qeeb heev
        return;
    }

    test_literal!(2.2250738585072014e-308);
}

#[test]
fn special_code_paths() {
    test_literal!(36893488147419103229.0); // 2 ^ 65, 3, txhais tawm ib nrab-rau-txawm nrog txawm tias muaj ntau yam
    test_literal!(101e-33); // Ua lo qhia underflow cov ntaub ntawv nyob rau hauv AlgorithmM (rau f32)
    test_literal!(1e23); // Ua rau AlgorithmR
    test_literal!(2075e23); // Ua lwm txoj kev los ntawm AlgorithmR
    test_literal!(8713e-23); // ... thiab tsis tau lwm.
}

#[test]
fn large() {
    test_literal!(1e300);
    test_literal!(123456789.34567e250);
    test_literal!(943794359898089732078308743689303290943794359843568973207830874368930329.);
}

#[test]
#[cfg_attr(miri, ignore)] // Miri tau qeeb heev
fn subnormals() {
    test_literal!(5e-324);
    test_literal!(91e-324);
    test_literal!(1e-322);
    test_literal!(13245643e-320);
    test_literal!(2.22507385851e-308);
    test_literal!(2.1e-308);
    test_literal!(4.9406564584124654e-324);
}

#[test]
#[cfg_attr(miri, ignore)] // Miri tau qeeb heev
fn infinity() {
    test_literal!(1e400);
    test_literal!(1e309);
    test_literal!(2e308);
    test_literal!(1.7976931348624e308);
}

#[test]
fn zero() {
    test_literal!(0.0);
    test_literal!(1e-325);

    if cfg!(miri) {
        // Miri tau qeeb heev
        return;
    }

    test_literal!(1e-326);
    test_literal!(1e-500);
}

#[test]
fn fast_path_correct() {
    // Tus naj npawb no ua rau txoj kev nrawm dua thiab raug daws tsis raug thaum sau rau ntawm x86 tsis muaj SSE2 (piv txwv li, siv x87 FPU pawg).
    //
    test_literal!(1.448997445238699);
}

#[test]
fn lonely_dot() {
    assert!(".".parse::<f32>().is_err());
    assert!(".".parse::<f64>().is_err());
}

#[test]
fn exponentiated_dot() {
    assert!(".e0".parse::<f32>().is_err());
    assert!(".e0".parse::<f64>().is_err());
}

#[test]
fn lonely_sign() {
    assert!("+".parse::<f32>().is_err());
    assert!("-".parse::<f64>().is_err());
}

#[test]
fn whitespace() {
    assert!(" 1.0".parse::<f32>().is_err());
    assert!("1.0 ".parse::<f64>().is_err());
}

#[test]
fn nan() {
    assert!("NaN".parse::<f32>().unwrap().is_nan());
    assert!("NaN".parse::<f64>().unwrap().is_nan());
}

#[test]
fn inf() {
    assert_eq!("inf".parse(), Ok(f64::INFINITY));
    assert_eq!("-inf".parse(), Ok(f64::NEG_INFINITY));
    assert_eq!("inf".parse(), Ok(f32::INFINITY));
    assert_eq!("-inf".parse(), Ok(f32::NEG_INFINITY));
}

#[test]
fn massive_exponent() {
    let max = i64::MAX;
    assert_eq!(format!("1e{}000", max).parse(), Ok(f64::INFINITY));
    assert_eq!(format!("1e-{}000", max).parse(), Ok(0.0));
    assert_eq!(format!("1e{}000", max).parse(), Ok(f64::INFINITY));
}

#[test]
fn borderline_overflow() {
    let mut s = "0.".to_string();
    for _ in 0..375 {
        s.push('3');
    }
    // Thaum lub sijhawm sau ntawv no, qhov no rov Err(..), tab sis qhov no yog cov kab uas yuav tsum tau kho tas.
    // Nws ua rau tsis muaj kev nkag siab rau enshrine tias nyob rau hauv ib txoj kev kuaj, qhov tseem ceeb yog hais tias nws tsis panic.
    let _ = s.parse::<f64>();
}