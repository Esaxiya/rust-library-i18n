use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Qhov no tsis yog thaj chaw ruaj khov, tab sis pab khaws `?` pheej yig ntawm lawv, txawm tias LLVM tsis tuaj yeem siv sijhawm tam sim no.
    //
    // (Tu siab tshwm sim thiab Kev xaiv yog qhov tsis sib xws, yog li ControlFlow tsis tuaj yeem phim ob leeg.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}