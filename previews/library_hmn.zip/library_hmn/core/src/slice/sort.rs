//! Hlais ntawv xaiv
//!
//! Cov qauv no muaj cov txheej txheem sorting los ntawm Orson Peters 'qauv-swb lub quicksort, luam tawm ntawm: <https://github.com/orlp/pdqsort>
//!
//!
//! Tsis ruaj tsis khov sorting yog sib xws nrog libcore vim hais tias nws tsis faib lub cim xeeb, tsis zoo li peb ruaj khov sorting siv.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Thaum poob, luam tawm los ntawm `src` rau `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // TXUAG NYIAJ: Qhov no yog chav kawm pab cuam.
        //          Thov hu rau nws siv rau kev raug.
        //          Namely, ib tug yuav tsum nco ntsoov hais tias `src` thiab `dst` tsis sib tshooj raws li yuav tsum tau los ntawm `ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Hloov cov thawj lub ntsiab rau sab xis kom txog thaum nws ntsib qhov siab dua lossis sib luag.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // KEV RUAJ NTSEG: Cov haujlwm tsis muaj kev nyab xeeb hauv qab no yuav suav nrog kev suav ntsuas tsis muaj cov cim kos (`get_unchecked` thiab `get_unchecked_mut`)
    // thiab theej luam cim xeeb (`ptr::copy_nonoverlapping`).
    //
    // a.Indexing:
    //  1. Peb soj ntsuam qhov loj ntawm lub array rau>=2.
    //  2. Txhua qhov ntsuas ua peb yuav ua yog ib txwm nyob ntawm {0 <= index < len} thaum feem ntau.
    //
    // b.Cim xeeb luam tawm
    //  1. Peb tau txais cov lus taw qhia rau cov ntawv pov thawj uas tau lees tias siv tau.
    //  2. Lawv yuav tsis sib tshooj vim hais tias peb tau pointers rau txawv indices ntawm lub hlais.
    //     Namely, `i` thiab `i-1`.
    //  3. Yog hais tias lub hlais yog zoo raws li, lub ntsiab yog kom raws.
    //     Nws yog tus neeg hu xov tooj lub luag haujlwm kom paub tseeb tias cov hlais tau raws li tau sau cia.
    //
    // Saib cov lus hauv qab no kom paub meej ntxiv.
    unsafe {
        // Yog tias thawj ob lub ntsiab lus tsis tawm ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Nyeem thawj ntu mus rau hauv pawg ua ntu sib faib.
            // Yog hais tias ib tug nram qab no sib piv lag luam panics, `hole` yuav tau poob thiab yeej sau lub caij rov qab mus rau hauv lub hlais.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Txav mus `i`-th caij ib qho chaw rau sab laug, yog li txav lub qhov ntawm sab xis.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` tau txais poob thiab yog li luam cov `tmp` rau hauv qhov seem ntxiv hauv `v`.
        }
    }
}

/// Hloov lub caij kawg rau sab laug kom txog thaum nws ntsib qhov sib luag me lossis sib npaug.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // KEV RUAJ NTSEG: Cov haujlwm tsis muaj kev nyab xeeb hauv qab no yuav suav nrog kev suav ntsuas tsis muaj cov cim kos (`get_unchecked` thiab `get_unchecked_mut`)
    // thiab theej luam cim xeeb (`ptr::copy_nonoverlapping`).
    //
    // a.Indexing:
    //  1. Peb tau soj ntsuam qhov luaj li cas ntawm cov array rau>=2.
    //  2. Txhua qhov ntsuas ua peb yuav ua yog ib txwm nyob ntawm `0 <= index < len-1` thaum feem ntau.
    //
    // b.Cim xeeb luam tawm
    //  1. Peb tau txais cov lus taw qhia rau cov ntawv pov thawj uas tau lees tias siv tau.
    //  2. Lawv yuav tsis sib tshooj vim hais tias peb tau pointers rau txawv indices ntawm lub hlais.
    //     Namely, `i` thiab `i+1`.
    //  3. Yog hais tias lub hlais yog zoo raws li, lub ntsiab yog kom raws.
    //     Nws yog tus neeg hu xov tooj lub luag haujlwm kom paub tseeb tias cov hlais tau raws li tau sau cia.
    //
    // Saib cov lus hauv qab no kom paub meej ntxiv.
    unsafe {
        // Yog hais tias ob lub ntsiab kawg puas tawm ntawm-xaj ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Nyeem qhov kawg los mus ua pawg sib faib.
            // Yog hais tias ib tug nram qab no sib piv lag luam panics, `hole` yuav tau poob thiab yeej sau lub caij rov qab mus rau hauv lub hlais.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Txav mus rau 'i`-th caij ib qhov chaw mus rau sab xis, yog li hloov lub qhov mus rau sab laug.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` tau txais poob thiab yog li luam cov `tmp` rau hauv qhov seem ntxiv hauv `v`.
        }
    }
}

/// Qee kov ib qho los ntawm kev hloov ntau ntawm cov khoom uas tau hais tseg ib puag ncig.
///
/// Rov qab `true` yog tias cov hlais tau txheeb ntawm qhov kawg.Qhov no muaj nuj nqi yog *O*(*n*) worst-case.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Qhov ntau ntawm cov neeg uas nyob ib sab sab nrauv uas yuav txav mus los.
    const MAX_STEPS: usize = 5;
    // Yog tias cov nplais luv dua li qhov no, tsis txhob hloov tej ntsiab lus.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // KEV RUAJ NTSEG: Peb twb tau hais meej meej puas tau ua qhov khij daim phiaj nrog `i < len`.
        // Txhua peb cov kev ntsuas tom qab tsuas yog ntsuas tus nqi `0 <= index < len`
        unsafe {
            // Nrhiav cov tom ntej no khub ntawm ib sab tawm-ntawm-kev txiav txim hais.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Puas yog peb ua tiav lawm?
        if i == len {
            return true;
        }

        // Tsis txhob ua hauj lwm ceev ntsiab rau luv luv arrays, uas muaj ib tug ua tau zoo nqi.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Sib puav cov khub uas pom.Qhov no txo nws hwj lawv kom raug.
        v.swap(i - 1, i);

        // Hloov chaw me dua rau sab laug.
        shift_tail(&mut v[..i], is_less);
        // Hloov lub ntsiab ntau dua rau sab xis.
        shift_head(&mut v[i..], is_less);
    }

    // Tsis tau tswj los txiav cov hlais qhov tsawg ntawm cov kauj ruam.
    false
}

/// Txheeb ib qho txiav tawm uas siv ntxig rau cov ntxig, uas yog *O*(*n*^ 2) qhov tsis zoo.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Txheeb `v` siv heapsort, uas tuaj yeem lav *O*(*n*\*log(* n*)) qhov tsis zoo-rooj plaub.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // No cov binary heap hwm tus nqi `parent >= child`.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Cov me nyuam ntawm `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Xaiv cov menyuam loj dua.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Nres yog tias qhov tsis muaj cai khaws ntawm `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Sib pauv `node` nrog rau tus menyuam ntau dua, txav ib ruam zuj zus, thiab txuas mus ntxiv.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Tsim lub heap rau hauv linear lub sijhawm.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Pop maximal ntsiab los ntawm qhov heap.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Partitions `v` rau hauv ntsiab me dua `pivot`, ua raws li los ntawm cov ntsiab ntau dua los yog sib npaug rau `pivot`.
///
///
/// Rov qab tus naj npawb ntawm cov khoom me dua `pivot`.
///
/// Partitioning yog ua thaiv-by-thaiv nyob rau hauv thiaj li yuav txo tau tus nqi ntawm branching hauj lwm.
/// Cov tswv yim no nthuav tawm hauv [BlockQuicksort][pdf] daim ntawv.
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Cov naj npawb ntawm cov khoom hauv ib qho raug thaiv.
    const BLOCK: usize = 128;

    // Txoj kev muab faib faib rov qab ua cov theem nram qab no kom txog thaum ua tiav:
    //
    // 1. Ntxig kev thaiv ntawm sab laug los txheeb xyuas cov khoom loj tshaj los yog sib npaug nrog cov pivot.
    // 2. Ntxig txoj hauv kev los ntawm sab xis los txheeb cov khoom me uas tsis muaj piv txwv.
    // 3. Txauv qhov cim qhia tau ntawm tus sab laug thiab sab xis.
    //
    // Peb khaws cov qhob hauv qab no rau qhov thaiv ntawm cov khoom:
    //
    // 1. `block` - Tus naj npawb ntawm cov khoom hauv lub block.
    // 2. `start` - Pib pointer rau hauv `offsets` array.
    // 3. `end` - Xaus pointer rau hauv `offsets` array.
    // 4. 'Offsets, Indices ntawm tawm-ntawm-kev txiav txim hais tsis pub dhau lub block.

    // Qhov tam sim no thaiv nyob rau sab laug (ntawm `l` txog `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Qhov tam sim no thaiv ntawm sab xis (los ntawm `r.sub(block_r)` to `r`).
    // KEV RUAJ NTSEG: Cov ntaub ntawv rau .add() tshwj xeeb hais tias `vec.as_ptr().add(vec.len())` yog ib txwm muaj kev nyab xeeb `
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Thaum peb tau txais VLAs, sim tsim ib qho ntawm qhov ntev `min(v.len(), 2 * THAIV) `theej
    // dua ob qhov ntsuas raws li cov xaj ntev ntawm `BLOCK`.VLAs tej zaum yuav ntau cache-npaum.

    // Rov qab rau cov naj npawb ntawm cov kis ntawm `l` (inclusive) thiab `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Peb tau ua tiav nrog kev faib cov block-by-block thaum `l` thiab `r` ze heev.
        // Tom qab ntawd peb ua tau ib co thaj-up kev ua hauj lwm nyob rau hauv thiaj li yuav muab faib rau seem uas hais nyob rau hauv nruab nrab.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Tus naj npawb ntawm cov khoom seem (tseem tsis tau piv rau pivot).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Kho qhov ntau thiab tsawg ntawm cov block kom cov sab laug thiab txoj cai tsis txhob sib tshooj, tab sis tau txig ua ke los npog tag nrho cov seem.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Looj `block_l` cov ntsiab lus los ntawm sab lauj.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // TXUJ CI: Cov haujlwm tsis muaj kev nyab xeeb hauv qab no suav nrog kev siv `offset`.
                //         Raws li cov tej yam kev mob yuav tsum tau los ntawm cov kev ua, peb los siav lawv vim hais tias:
                //         1. `offsets_l` yog muab faib sib cais, thiab yog li txiav txim siab cais cov khoom sib cais.
                //         2. Txoj haujlwm `is_less` rov xa `bool`.
                //            Casting ib `bool` yuav tsis phwj `isize`.
                //         3. Peb tau lees tias `block_l` yuav `<= BLOCK`.
                //            Ntxiv rau, `end_l` tau pib teeb tsa rau tus pib pointer ntawm `offsets_` uas tau tshaj tawm rau ntawm pawg.
                //            Yog li, peb paub hais tias txawm nyob rau hauv lub phem tshaj cov ntaub ntawv (tag nrho cov invocations ntawm `is_less` rov cuav) peb yuav tsuas yuav nyob rau hauv feem ntau 1 byte dhau thaum kawg.
                //        Lwm unsafety lag luam no yog dereferencing `elem`.
                //        Txawm li cas los, `elem` yog chiv lub pib pointer mus rau lub hlais uas yog ib txwm siv tau.
                unsafe {
                    // Kev sib piv tsis muaj ceg.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Looj `block_r` cov ntsiab lus los ntawm sab xis.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // TXUJ CI: Cov haujlwm tsis muaj kev nyab xeeb hauv qab no suav nrog kev siv `offset`.
                //         Raws li cov tej yam kev mob yuav tsum tau los ntawm cov kev ua, peb los siav lawv vim hais tias:
                //         1. `offsets_r` yog muab faib sib cais, thiab yog li txiav txim siab cais cov khoom sib cais.
                //         2. Txoj haujlwm `is_less` rov xa `bool`.
                //            Casting ib `bool` yuav tsis phwj `isize`.
                //         3. Peb tau guaranteed tias `block_r` yuav `<= BLOCK`.
                //            Ntxiv rau, `end_r` tau pib teeb tsa rau tus pib pointer ntawm `offsets_` uas tau tshaj tawm rau ntawm pawg.
                //            Yog li, peb paub tias txawm tias qhov xwm txheej phem tshaj plaws (txhua qhov kev caw ntawm `is_less` rov qab muaj tseeb) peb yuav tsuas yog nyob rau feem ntau 1 byte dhau qhov kawg.
                //        Lwm unsafety lag luam no yog dereferencing `elem`.
                //        Txawm li cas los xij, `elem` yog pib `1 *sizeof(T)` dhau los kawg thiab peb txo nws los ntawm `1* sizeof(T)` ua ntej nkag mus.
                //        Ntxiv rau, `block_r` tau lees tias yuav tsawg dua `BLOCK` thiab `elem` yuav yog li ntawm feem ntau yuav taw rau qhov pib ntawm hlais.
                unsafe {
                    // Kev sib piv tsis muaj ceg.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Tus naj npawb tawm ntawm cov khoom tau kom pauv ntawm sab laug thiab sab xis.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Hloov chaw ntawm sib pauv ib khub thaum lub sijhawm, nws yog qhov ua tau zoo dua los ua qhov kev tso cai ntawm kev voj voog.
            // Qhov no tsis yog nruj me ntsis rau kev sib pauv, tab sis tsim cov txiaj ntsig zoo sib xws uas siv cov kev nco tsawg dua.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Txhua qhov tawm ntawm cov khoom tau hais hauv seem sab laug tau hloov mus.Txav mus rau tom ntej no block.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Tag nrho tawm-ntawm-kev txiav txim hais rau hauv txoj cai thaiv tau txav mus li.Txav mus rau yav dhau los thaiv.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Txhua qhov uas tseem nyob tam sim no yog nyob rau ntawm ntau qhov kev thaiv (txawm sab laug lossis sab xis) nrog kev tawm ntawm cov khoom uas yuav tsum tau txav.
    // Xws li cov ntsiab lus ntxiv tuaj yeem hloov mus rau qhov kawg hauv lawv qhov block.
    //

    if start_l < end_l {
        // Lub tsev seem tshuav.
        // Txav mus rau nws seem tawm-ntawm-kev txiav txim hais mus rau lub deb txoj cai.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Txoj cai thaiv tseem.
        // Txav mus rau nws cov seem uas tau txiav txim rau sab laug.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Tsis muaj dab tsi ntxiv ua, peb tau ua tiav.
        width(v.as_mut_ptr(), l)
    }
}

/// Partitions `v` rau hauv cov khoom me dua `v[pivot]`, tom qab los ntawm cov khoom ntau dua lossis sib npaug rau `v[pivot]`.
///
///
/// Xa rov qab tuple ntawm:
///
/// 1. Tus naj npawb ntawm cov khoom me dua `v[pivot]`.
/// 2. Muaj tseeb yog tias `v` twb muab faib lawm.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Tso cov pivot thaum pib hlais.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Nyeem pivot rau hauv ib pawg-faib nce mus nce los rau efficiency.
        // Yog tias kev lag luam sib piv nram qab no panics, cov pivot yuav cia li sau rov qab rau hauv cov hlais.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Nrhiav thawj khub ntawm kev tawm ntawm cov khoom.
        let mut l = 0;
        let mut r = v.len();

        // KEV RUAJ NTSEG: Qhov tsis muaj kev nyab xeeb hauv qab no suav nrog kev ntsuas qhov ntsuas.
        // Rau thawj tus: Peb twb tau ua cov kab kos ntawm no nrog `l < r`.
        // Rau qhov thib ob: Peb pib muaj `l == 0` thiab `r == v.len()` thiab peb tau tshawb xyuas tias `l < r` ntawm txhua qhov kev ntsuas.
        //                     Txij ntawm no peb paub tias `r` yuav tsum yog tsawg kawg `r == l` uas tau pom tias siv tau los ntawm thawj tus.
        unsafe {
            // Nrhiav thawj ntu loj dua los yog sib npaug nrog cov pivot.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Nrhiav lub caij kawg me me uas qhov pivot.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` mus tawm ntawm qhov teev thiab sau cov pivot (uas yog pawg sib cais cov sib txawv) rov qab mus rau hauv hlais qhov twg nws yog thaum chiv thawj.
        // Cov kauj ruam no yog qhov tseem ceeb rau kev ua kom muaj kev nyab xeeb!
        //
    };

    // Tso lub pivot ntawm ob ntu.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Muab faib `v` rau hauv cov khoom sib npaug rau `v[pivot]` ua raws cov khoom loj dua `v[pivot]`.
///
/// Rov qab tus naj npawb ntawm cov khoom sib npaug nrog hauv pivot.
/// Nws tau kwv yees tias `v` tsis muaj cov khoom me dua piv rau pivot.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Tso cov pivot thaum pib hlais.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Nyeem pivot rau hauv ib pawg-faib nce mus nce los rau efficiency.
    // Yog tias kev lag luam sib piv nram qab no panics, cov pivot yuav cia li sau rov qab rau hauv cov hlais.
    // KEV RUAJ NTSEG: Tus pointer ntawm no siv tau vim nws tau los ntawm kev siv mus rau ib qho hlais.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Tam sim no muab faib rau cov hlais.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // KEV RUAJ NTSEG: Qhov tsis muaj kev nyab xeeb hauv qab no suav nrog kev ntsuas qhov ntsuas.
        // Rau thawj tus: Peb twb tau ua cov kab kos ntawm no nrog `l < r`.
        // Rau qhov thib ob: Peb pib muaj `l == 0` thiab `r == v.len()` thiab peb tau tshawb xyuas tias `l < r` ntawm txhua qhov kev ntsuas.
        //                     Txij ntawm no peb paub tias `r` yuav tsum yog tsawg kawg `r == l` uas tau pom tias siv tau los ntawm thawj tus.
        unsafe {
            // Nrhiav thawj ntu loj tshaj qhov pivot.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Nrhiav lub caij kawg sib npaug rau qhov pivot.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Puas yog peb ua tiav lawm?
            if l >= r {
                break;
            }

            // Swap lub pom khub tawm-ntawm-kev txiav txim hais.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Peb pom `l` khoom sib npaug rau cov pivot.Ntxiv 1 tus account rau lub pivot nws tus kheej.
    l + 1

    // `_pivot_guard` mus tawm ntawm qhov teev thiab sau cov pivot (uas yog pawg sib cais cov sib txawv) rov qab mus rau hauv hlais qhov twg nws yog thaum chiv thawj.
    // Cov kauj ruam no yog qhov tseem ceeb rau kev ua kom muaj kev nyab xeeb!
}

/// Scatters qee cov ntsiab lus ib puag ncig nyob rau hauv ib qho kev sim mus ua txhaum cov qauv uas yuav ua rau tsis txaus partitions nyob rau hauv quicksort.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Pseudorandom tooj generator los ntawm cov "Xorshift RNGs" daim ntawv los ntawm George Marsaglia.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Nqa cov lej lej lej modulo tus lej no.
        // Tus lej haum rau `usize` vim `len` tsis loj dua `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Qee tus neeg xaiv yuav los nyob ze rau qhov ntsuas no.Cia peb xaiv lawv.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Tsim kom muaj random tooj modulo `len`.
            // Txawm li cas los xij, txhawm rau kom tsis txhob raug nyiaj ntau rau kev ua haujlwm peb yuav xub coj nws hloov lub zog ntawm ob, thiab tom qab ntawd txo los ntawm `len` kom txog thaum nws haum rau ntau yam `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` yog lav kom tsawg dua `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Xaiv ib tug pivot nyob rau hauv `v` thiab rov qab rau hauv lub Performance index thiab `true` yog hais tias tus hlais no tej zaum yuav twb txheeb.
///
/// Hais hauv `v` tej zaum yuav rov ua cov txheej txheem.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Yam tsawg kawg nkaus ntev mus xaiv theem nrab-of-medians txoj kev.
    // Luv luv slices siv tej yam yooj yim theem nrab-of-peb txoj kev.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Qhov tsawg kawg nkaus ntawm cov swaps uas tuaj yeem ua rau hauv txoj haujlwm no.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Peb qhov taw qhia nyob ze uas peb yuav tau xaiv lub pivot.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Suav tag nrho cov xov tooj ntawm cov swaps peb yog hais txog los ua thaum sorting indices.
    let mut swaps = 0;

    if len >= 8 {
        // Swaps indices kom `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Swaps indices kom `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Pom cov khoom nruab nrab ntawm `v[a - 1], v[a], v[a + 1]` thiab khaws cov cim ntsuas rau hauv `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Pom cov medians nyob ze cov `a`, `b`, thiab `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Nrhiav cov khoom nruab nrab ntawm `a`, `b`, thiab `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Qhov ntau tshaj plaws ntawm swaps tau ua.
        // Txoj hauv kev yog cov hlais nqis los yog feem ntau nqis los, yog li thim rov qab tej zaum yuav pab txheeb nws kom nrawm dua.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Txheeb `v` recursively.
///
/// Yog tias cov hlais tau tus neeg xav tau ua ntej hauv cov khoom qub, nws tau hais tseg yog `pred`.
///
/// `limit` yog tus naj npawb ntawm tso cai imbalanced partitions ua ntej switching rau `heapsort`.
/// Yog tias xoom, txoj haujlwm no yuav hloov mus rau heapsort tam sim ntawd.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Slices ntawm li no ntev tau txheeb siv zoo tsi.
    const MAX_INSERTION: usize = 20;

    // Muaj tseeb yog hais tias lub kawg sib faib cuab yeej tsis tsim nyog.
    let mut was_balanced = true;
    // Yeej muaj tseeb yog hais tias tus kawg partitioning tsis shuffle ntsiab (lub hlais twb partitioned).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Luv luv heev tau txheeb siv siv ntxig cov teeb meem.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Yog tias ntau qhov kev xaiv pivot tsis zoo, tsuas yog poob rov qab rau heapsort thiaj li tau lees tias `O(n * log(n))` qhov tsis zoo tshaj plaws.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Yog hais tias lub xeem partitioning twb imbalanced, sim rhuav qauv nyob rau hauv lub hlais los ntawm shuffling ib co ntsiab nyob ib ncig ntawm.
        // Hopefully peb mam li xaiv ib tug zoo dua pivot lub sij hawm no.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Xaiv lub pivot thiab sim twv seb daim hlais twb tau txheeb.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Yog hais tias lub xeem muab faib kawg tau ncaj ncaj thiab tsis shuffle hais, thiab yog pivot xaiv kwv yees hlais yog yuav muaj twb txheeb ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Sim qhia ob peb tawm-ntawm-kev txiav txim hais thiab hloov lawv mus yog txoj haujlwm.
            // Yog tias cov hlais xaus ua qhov kom tiav, peb tau ua tiav.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Yog hais tias tus xaiv pivot yog sib npaug zos rau cov thawj, ces nws yog ib qhov tsawg tshaj plaws caij nyob rau hauv lub hlais.
        // Muab faib rau cov hle rau cov khoom sib npaug thiab cov khoom loj dua lub pivot.
        // Qhov xwm txheej no feem ntau ntaus thaum cov hlais muaj ntau cov ntsiab lus tsis hloov.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Txuas cov khoom mus ntxiv kom loj dua qhov pivot.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Muab faib lub hlais.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Faib cov ntawv txiav rau hauv `left`, `pivot`, thiab `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Kws tu neeg mob mus rau sab luv luv tsuas yog txhawm rau ua kom qhov tsawg ntawm tag nrho cov xov tooj hu rov qab thiab siv chaw tsawg dua.
        // Tom qab ntawd tsuas yog txuas mus ntxiv nrog ntev dua (qhov no yog zoo li tus Tsov tus tw thov rov qab).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Txheeb `v` siv cov qauv-swb lub quicksort, uas yog *O*(*n*\*log(* n*)) qhov tsis zoo tshaj plaws.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Qhov muaj tsis muaj nuj nqis tus cwj pwm nyob rau hauv xoom-sized hom.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Txwv tsawg tus naj npawb ntawm imbalanced partitions rau `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Rau cov hlais ntawm qhov ntev li no tej zaum yuav yooj yim dua rau tsuas yog xaiv lawv.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Xaiv lub pivot
        let (pivot, _) = choose_pivot(v, is_less);

        // Yog hais tias tus xaiv pivot yog sib npaug zos rau cov thawj, ces nws yog ib qhov tsawg tshaj plaws caij nyob rau hauv lub hlais.
        // Muab faib rau cov hle rau cov khoom sib npaug thiab cov khoom loj dua lub pivot.
        // Qhov xwm txheej no feem ntau ntaus thaum cov hlais muaj ntau cov ntsiab lus tsis hloov.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Yog tias peb tau dhau peb qhov ntsuas, ces peb ua tau zoo.
                if mid > index {
                    return;
                }

                // Txwv tsis pub, txuas ntxiv mus txheeb cov khoom loj tshaj qhov pivot.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Faib cov ntawv txiav rau hauv `left`, `pivot`, thiab `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Yog tias nruab nrab==qhov ntsuas, tom qab ntawd peb tau ua tiav, txij li partition() tau lees tias tag nrho cov khoom tom qab nruab nrab muaj ntau dua lossis ntau dua ib nrab.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Txheeb tsis muaj lub cwj pwm tsis tseem ceeb ntawm kev ua hom xoom.Tsis ua dab tsi.
    } else if index == v.len() - 1 {
        // Nrhiav max caij thiab tso nws nyob rau hauv lub xeem txoj hauj lwm ntawm lub array.
        // Peb tau dawb siv `unwrap()` ntawm no vim peb paub v yuav tsum tsis txhob khoob.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Nrhiav min caij thiab tso nws nyob rau hauv thawj txoj hauj lwm ntawm lub array.
        // Peb tau dawb siv `unwrap()` ntawm no vim peb paub v yuav tsum tsis txhob khoob.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}