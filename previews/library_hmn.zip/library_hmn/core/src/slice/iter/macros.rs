//! Macros siv los ntawm iterators ntawm hlais.

// Inlining is_empty thiab len ua ib qhov kev ua tau zoo loj
macro_rules! is_empty {
    // Txoj kev peb encode qhov ntev ntawm ZST tus ntsuas hluav taws xob, qhov no ua haujlwm ob qho tib si rau ZST thiab tsis-ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Txhawm rau kom tshem tawm ntawm qee qhov kev txheeb xyuas pov tseg (saib `position`), peb suav qhov ntev hauv txoj kev npaj txhij.
// (Kuaj los ntawm 'codegen/hlais-txoj haujlwm-ciam teb-kos `.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // peb qee zaum siv nyob rau hauv qhov thaiv tsis zoo

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Qhov _cannot_ no siv `unchecked_sub` vim tias peb vam khom los ntawm kev ntim khoom los sawv cev rau qhov ntev ntawm ZST hlais cov ntsuas kub ntev.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Peb paub tias `start <= end`, yog li tuaj yeem ua tau zoo dua `offset_from`, uas yuav tsum muaj kev sib koom tes hauv kos npe.
            // Los ntawm teeb tsa cov chij tsim nyog ntawm no peb tuaj yeem qhia LLVM qhov no, uas pab nws tshem tawm cov ciam tshev.
            // KEV RUAJ NTSEG: Los ntawm cov hom tsis muaj, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Los ntawm tseem qhia LLVM tias cov taw tes sib nrug los ntawm qhov muaj ntau yam ntawm cov hom loj, nws tuaj yeem ua kom `len() == 0` nqis qis rau `start == end` hloov `(end - start) < size`.
            //
            // KEV RUAJ NTSEG: Los ntawm hom tsis muaj, cov taw tes yog mus raws li qhov
            //         qhov kev ncua deb ntawm lawv yuav tsum yog ntau qhov sib txawv
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// Lub ntsiab lus sib qhia ntawm `Iter` thiab `IterMut` iterators
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Rov qab los ntawm thawj lub hauv paus thiab txav pib ntawm tus ntsuas pa xa mus los ntawm 1.
        // Zoo heev txhim kho kev ua tau zoo piv rau qhov ntxaij.
        // Tus ncej hluav taws xob yuav tsum tsis muaj qhov khoob.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Rov qab rau lub caij kawg thiab txav qhov kawg ntawm tus txhuam rov qab los ntawm 1.
        // Zoo heev txhim kho kev ua tau zoo piv rau qhov ntxaij.
        // Tus ncej hluav taws xob yuav tsum tsis muaj qhov khoob.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Shrinks tus ntsuas hluav taws xob thaum T yog ZST, los ntawm txav qhov kawg ntawm tus txhuam rov qab los ntawm `n`.
        // `n` yuav tsum tsis pub tshaj `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Kev pab ua haujlwm rau kev tsim cov hlais los ntawm tus tsim.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // KEV RUAJ NTSEG: tus tsim iterator tau tsim los ntawm ib qho hlais nrog tus pointer
                // `self.ptr` thiab ntev `len!(self)`.
                // Qhov no tau lees tias txhua qhov tsim nyog ua ntej rau `from_raw_parts` tau ua tiav.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Kev pab ua haujlwm rau kev txav chaw pib ntawm lub thev taws xob forwards los ntawm `offset` cov ntsiab lus, rov qab pib qhov qub.
            //
            // Tsis xyuam xim vim tias txoj kev tiv thaiv yuav tsum tsis txhob siab tshaj `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // KEV RUAJ NTSEG: tus hu tuaj yeem lav tias `offset` tsis tshaj `self.len()`,
                    // yog li no tus pointer tshiab yog sab hauv `self` thiab yog li tau lees tias yuav tsis yog-tsis yog.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Pab muaj nuj nqi rau mus rau thaum xaus ntawm lub iterator rov mus los ntawm `offset` hais, rov qab rau hauv lub tshiab kawg.
            //
            // Tsis xyuam xim vim tias txoj kev tiv thaiv yuav tsum tsis txhob siab tshaj `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // KEV RUAJ NTSEG: tus hu tuaj yeem lav tias `offset` tsis tshaj `self.len()`,
                    // uas tuaj yeem lav rau tsis dhau ib qho `isize`.
                    // Tsis tas li, qhov pointer uas tshwm sim yog nyob rau hauv ciam ntawm `slice`, uas ua tiav lwm cov kev xav tau rau `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // yuav muab siv nrog hlais, tab sis qhov no zam kev ciam ciam

                // KEV RUAJ NTSEG: Kev hu xov tooj `assume` muaj kev nyab xeeb txij thaum pib lub pointer pib
                // yuav tsum yog non-null, thiab hlais dua li cov-ZSTs kuj yuav tsum muaj qhov tsis yog-null kawg pointer.
                // Kev hu mus rau `next_unchecked!` yog qhov muaj kev nyab xeeb vim tias peb kuaj yog tias tus ntsuas pa yog qhov ua ntej.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Tus sawv cev tam sim no khoob.
                    if mem::size_of::<T>() == 0 {
                        // Peb yuav tsum tau ua nws txoj kev no raws li `ptr` yuav tsis yog 0, tab sis `end` yuav yog (vim kev qhwv).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // KEV RUAJ NTSEG: kawg tsis tuaj yeem yog 0 yog T tsis yog ZST vim ptr tsis yog 0 thiab xaus>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // TXUJ CI: Peb nyob hauv ciam.`post_inc_start` ua qhov yog txawm tias ZSTs.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Peb dhau qhov kev pib ua tsis tau, uas siv `try_fold`, vim tias qhov kev siv tau yooj yim no ua rau muaj LLVM IR tsawg dua thiab nrawm dua los sau ua ke.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Peb dhau qhov kev pib ua tsis tau, uas siv `try_fold`, vim tias qhov kev siv tau yooj yim no ua rau muaj LLVM IR tsawg dua thiab nrawm dua los sau ua ke.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Peb dhau qhov kev pib ua tsis tau, uas siv `try_fold`, vim tias qhov kev siv tau yooj yim no ua rau muaj LLVM IR tsawg dua thiab nrawm dua los sau ua ke.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Peb dhau qhov kev pib ua tsis tau, uas siv `try_fold`, vim tias qhov kev siv tau yooj yim no ua rau muaj LLVM IR tsawg dua thiab nrawm dua los sau ua ke.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Peb dhau qhov kev pib ua tsis tau, uas siv `try_fold`, vim tias qhov kev siv tau yooj yim no ua rau muaj LLVM IR tsawg dua thiab nrawm dua los sau ua ke.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Peb dhau qhov kev pib ua tsis tau, uas siv `try_fold`, vim tias qhov kev siv tau yooj yim no ua rau muaj LLVM IR tsawg dua thiab nrawm dua los sau ua ke.
            // Tsis tas li, `assume` zam kev pov hwm tus ciam.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // KEV RUAJ NTSEG: peb tau lees tias yuav nyob rau hauv cov ciam los ntawm kev sib ntxig sib hloov:
                        // thaum `i >= n`, `self.next()` rov `None` thiab lub voj lov.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Peb dhau qhov kev pib ua tsis tau, uas siv `try_fold`, vim tias qhov kev siv tau yooj yim no ua rau muaj LLVM IR tsawg dua thiab nrawm dua los sau ua ke.
            // Tsis tas li, `assume` zam kev pov hwm tus ciam.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // KEV RUAJ NTSEG: `i` yuav tsum qis dua `n` vim nws pib ntawm `n`
                        // thiab tsuas yog zuj zus lawm xwb.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // KEV RUAJ NTSEG: tus neeg hu yuav tsum lav tias `i` nyob rau hauv cov kev txwv
                // lub qhov pib hlais, yog li `i` tsis tuaj yeem dhau ib qho `isize`, thiab cov ntawv xa rov qab tau lees tias xa mus rau ib qho ntawm cov hlais thiab yog li lav tau siv tau.
                //
                // Tseem nco ntsoov tias tus neeg hu xov tooj tseem tuaj yeem lav tias peb tsis tau hu nrog tib lub ntsiab lus rov qab, thiab tias tsis muaj lwm txoj hauv kev uas yuav nkag mus rau cov subslice no yog hu ua, yog li nws siv tau rau cov ntaub ntawv xa rov qab tuaj yeem hloov mus nyob rau kis
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // yuav muab siv nrog hlais, tab sis qhov no zam kev ciam ciam

                // KEV RUAJ NTSEG: `assume` hu yog qhov zoo vim tias ib qho pib pib pointer yuav tsum yog qhov tsis yog-tus,
                // thiab hlais dua cov tsis-ZSTs yuav tsum muaj cov tsis muaj null kawg pointer.
                // Cov kev hu mus rau `next_back_unchecked!` muaj kev ruaj ntseg txij li thaum peb mus saib yog hais tias tus iterator yog empty thawj.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Tus sawv cev tam sim no khoob.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // KEV RUAJ NTSEG: Peb yog nyob rau hauv ciam teb.`pre_dec_end` puas qhov zoo tshaj plaws txawm rau ZSTs.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}