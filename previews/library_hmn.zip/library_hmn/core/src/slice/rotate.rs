// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Rotates cov kab ntau `[mid-left, mid+right)` xws tias lub caij ntawm `mid` dhau los ua thawj lub caij.Qhov sib npaug, tig qhov ntau ntawm `left` lub ntsiab rau sab laug lossis `right` ntsiab rau sab xis.
///
/// # Safety
///
/// Cov kab kev teev tseg yuav tsum siv tau rau kev nyeem thiab sau ntawv.
///
/// # Algorithm
///
/// Algorithm 1 yog siv rau qhov muaj nuj nqis me me ntawm `left + right` lossis rau `T` loj.
/// Cov ntsiab lus tau txav mus rau lawv txoj haujlwm kawg ib tus zuj zus pib ntawm `mid - left` thiab nce qib los ntawm `right` kauj ruam modulo `left + right`, xws li tias tsuas yog ib ntus xwb.
/// Nws thiaj li, peb tuaj txog ntawm `mid - left`.
/// Txawm li cas los xij, yog tias `gcd(left + right, right)` tsis yog 1, cov theem saum toj no hla dhau cov khoom.
/// Piv txwv li:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Qhov zoo ces, tus naj npawb ntawm cov raug hla lawm tshaj hais ntawm finalized ntsiab yog yeej ib txwm sib npaug, li ntawd, peb yuav cia li offset peb pib txoj hauj lwm thiab ua ntau rounds (tag nrho cov ntawm rounds yog lub `gcd(left + right, right)` value).
///
/// Qhov kawg tshwm sim yog tias txhua lub ntsiab lus xaus lus ib zaug thiab tsuas yog ib zaug.
///
/// Algorithm 2 yog siv yog tias `left + right` yog qhov loj tab sis `min(left, right)` yog qhov loj me kom haum rau ib pawg tsis khoom.
/// Cov `min(left, right)` lub ntsiab yog theej rau hauv qhov tsis, `memmove` siv rau lwm tus, thiab cov ntawm cov tsis yog tsiv rov qab mus rau hauv lub qhov taub ntawm qhov sib txawv ntawm qhov chaw lawv tuaj.
///
/// Cov txheej txheem ua lag luam uas tuaj yeem ua vectorized outperform qhov saum toj no ib zaug `left + right` ua loj txaus.
/// Algorithm 1 tuaj yeem ua tau vectorized los ntawm chunking thiab ua ntau ntau cov kab ib zaug, tab sis muaj ntau dhau los ntawm qhov nruab nrab kom txog thaum `left + right` yog qhov loj heev, thiab qhov xwm txheej tsis zoo ntawm ib puag ncig ib txwm muaj.
/// Hloov chaw, algorithm 3 siv ntau dua kev sib hloov ntawm `min(left, right)` cov ntsiab lus kom txog thaum muaj qhov teeb meem me tig.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// thaum `left < right` lub swapping tshwm sim los ntawm sab laug hloov.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. cov ntsiab hauv qab no tuaj yeem ua tsis tiav yog tias cov teeb meem no tsis tau tshawb xyuas
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Algorithm 1 Microbenchmarks qhia tau hais tias qhov nruab nrab ntawm kev ua haujlwm rau kev hloov mus rau qhov kev sib tw ua tau zoo dua txhua txoj hauv kev txog thaum txog `left + right == 32`, tab sis qhov teeb meem tsis zoo ntawm kev ua haujlwm tawg txawm tias ib puag ncig 16.
            // 24 raug xaiv ua nruab nrab hauv av.
            // Yog tias qhov luaj li cas ntawm `T` yog qhov loj dua 4 `usize`s, qhov kev cuam tshuam no tseem tshaj tawm lwm cov txheej txheem.
            //
            //
            let x = unsafe { mid.sub(left) };
            // pib ntawm thawj puag ncig
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` tau muaj nyob ua ntej tes los xam xyuas `gcd(left + right, right)`, tab sis nws yog ib qhov ceev ua ib lub voj uas laij cov GCD raws li ib tug sab nyhuv, ces ua tus so ntawm lub thooj
            //
            //
            let mut gcd = right;
            // cov qauv qhia pom tias nws tau nrawm dua los hloov cov ncauj lus txhua txoj kev los ntawm kev tsis txhob nyeem ib qho ib ntus, luam rov qab, thiab tom qab ntawd sau qhov ntawd ib ntus thaum kawg.
            // Qhov no yog tejzaum vim lub fact tias swapping los yog hloov temporaries siv tsuas yog ib lub cim xeeb chaw nyob nyob rau hauv lub voj es tsis txhob ntawm xav kom tswj ob.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // es tsis txhob nce ntxiv `i` thiab tom qab ntawd kuaj xyuas yog tias nws nyob sab nraud txoj kab, peb kuaj yog tias `i` yuav tawm sab nraud cov ciaj ciam ntawm cov nce ntxiv.
                // Qhov no txwv tsis pub muaj dab tsi qhwv ntawm taw tes lossis `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // xaus ntawm thawj round
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // tus mob no yuav tsum nyob ntawm no yog `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // tas cov thooj nrog ntau dua puag ncig
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` tsis yog xoom hom me me, yog li nws faib tawm los ntawm nws qhov loj.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Algorithm 2 Lub `[T; 0]` no yog los xyuas kom meej qhov no yog tsim nyog raws li rau T
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algorithm 3 Muaj yog ib qho lwm txoj kev txoj kev ntawm swapping uas yuav nrhiav qhov twg kawg sib puav ntawm no algorithm yuav, thiab swapping siv kawg thooj es tsis txhob ntawm swapping uas nyob ib sab chunks zoo li no algorithm ua dab tsi, tab sis qhov no txoj kev yog tseem sai.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Cov Txheej Txheem 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}