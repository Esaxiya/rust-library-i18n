// Kev pib siv los ntawm rust-memchr.
// Copyright 2015 Andrew Gallant, bluss thiab Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Siv kev ncua sijhawm.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Rov qab `true` yog `x` muaj txhua byte xoom.
///
/// Los ntawm *Matters Kev Sib Tham*, J. Arndt:
///
/// "Lub tswv yim yog rho ib qho ntawm txhua qhov ntawm lub bytes thiab tom qab ntawd saib rau bytes qhov twg qiv qiv tawm txhua txoj hauv kev mus rau qhov tseem ceeb tshaj plaws
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Rov thawj index txuam tus byte `x` nyob rau hauv `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Txoj kev sai rau cov hlais me me
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Luam theej duab ib qho byte tus nqi los ntawm kev nyeem ob lub `usize` lus ntawm lub sijhawm.
    //
    // Phim `text` nyob rau peb ntu
    // - unaligned thawj ntu, ua ntej thawj lo lus mus raws li chaw nyob hauv kab ntawv
    // - lub cev, luam theej tawm los ntawm 2 lo lus ntawm ib lub sijhawm
    // - seem kawg ntawm ntu, <2 lus loj

    // tshawb mus rau ib thaj tsam hauv ib cheeb tsam
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // tshawb lub cev ntawm cov ntawv nyeem
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // KEV RUAJ NTSEG: thaum lub sij hawm kwv yees tau lees tias qhov kev ncua deb ntawm tsawg kawg 2 * usize_bytes
        // nruab nrab ntawm qhov ua txhaum thiab qhov kawg ntawm daim.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // so yog tias muaj lub byte piv
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Nrhiav cov byte tom qab taw tes lub cev tas lawm.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Rov qab rau lub vev xaib kawg piv rau byte `x` hauv `text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Luam theej duab ib qho byte tus nqi los ntawm kev nyeem ob lub `usize` lus ntawm lub sijhawm.
    //
    // Phim `text` hauv peb ntu:
    // - unaligned Tail, tom qab lo lus kawg mus raws li qhov chaw nyob hauv cov ntawv nyeem,
    // - lub cev, luam los ntawm 2 lo lus ntawm lub sijhawm,
    // - thawj qhov txwv bytes, <2 lo lus loj.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Peb hu qhov no tsuas yog kom tau qhov ntev ntawm cov ua ntej thiab tom qab.
        // Hauv nruab nrab peb ib txwm ua ob txheej txheem ib zaug.
        // KEV RUAJ NTSEG: transmuting `[u8]` rau `[usize]` nyab xeeb tshwj tsis yog qhov sib txawv me me uas tau tuav los ntawm `align_to`.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Tshawb nrhiav lub cev ntawm cov ntawv nyeem, nco ntsoov tias peb tsis hla min_aligned_offset.
    // offset yeej ib txwm kws dlhos, yog li tsuas yog xeem `>` txaus thiab zam dhau kev txeej.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // KEV RUAJ NTSEG: offset pib ntawm len, suffix.len(), ntev npaum li qhov nws tau ntau dua
        // min_aligned_offset (prefix.len()) qhov kev ncua deb yog tsawg kawg 2 * chunk_bytes.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Txhaum yog tias muaj byte piv.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Nrhiav lub byte ua ntej kis taw tes lub cev nres.
    text[..offset].iter().rposition(|elt| *elt == x)
}