// ignore-tidy-filelength

//! Suam thiab tswj.
//!
//! Rau cov lus qhia ntxiv saib [`std::slice`].
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// Ntshiab rust memchr kev siv, coj los ntawm rust-memchr
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// Txoj haujlwm no yog pej xeem nkaus xwb vim tias tsis muaj lwm txoj hauv kev rau chav kuaj kuaj mob heapsort.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// Rov qab xa cov naj npawb ntawm cov khoom hauv cov hlais.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // KEV RUAJ NTSEG: const suab vim hais tias peb transmute tawm ntev ntev raws li usize (uas nws yuav tsum yog)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // KEV RUAJ NTSEG: qhov no yog kev ruaj ntseg vim hais tias `&[T]` thiab `FatPtr<T>` muaj tib lub layout.
            // Tsuas yog `std` thiaj ua tau qhov kev lav no.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: Hloov nrog `crate::ptr::metadata(self)` thaum uas yog const-ruaj khov.
            // Raws li ntawm qhov kev sau ntawv no ua rau "Const-stable functions can only call other const-stable functions" yuam kev.
            //

            // KEV RUAJ NTSEG: Nkag mus rau tus nqi los ntawm `PtrRepr` lub koomhaum muaj kev nyab xeeb txij li * const T
            // thiab PtrComponents<T>muaj cov cim xeeb txheej txheem tib yam.
            // Tsuas yog std tuaj yeem ua qhov kev lav no.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// Rov qab los `true` yog hais tias tus hlais muaj ib tug ntev ntawm 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Rov qab rau thawj ntu ntawm cov nplais, lossis `None` yog tias nws khoob.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Rov ib mutable pointer mus rau tus thawj lub caij ntawm lub hlais, los yog `None` yog hais tias nws yog tas.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Rov qab rau thawj thiab txhua tus so ntawm cov ntsiab lus ntawm cov hlais, lossis `None` yog tias nws khoob.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Rov qab rau thawj thiab txhua tus so ntawm cov ntsiab lus ntawm cov hlais, lossis `None` yog tias nws khoob.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Rov qab rau tom kawg thiab tag nrho cov khoom ua ntu ntawm cov hlais, lossis `None` yog tias nws khoob.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Rov qab rau tom kawg thiab tag nrho cov khoom ua ntu ntawm cov hlais, lossis `None` yog tias nws khoob.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Rov qab rau lub caij kawg ntawm cov hlais, lossis `None` yog tias nws khoob.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Rov qab los pointerable ua tiav rau cov khoom kawg hauv cov hlais.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Rov qab xa tus kheej mus rau ib qho tseem ceeb lossis subslice nyob ntawm seb hom ntsuas.
    ///
    /// - Yog tias muab rau hauv txoj haujlwm, rov qab xa mus rau lub keeb ntawm txoj haujlwm ntawd lossis `None` yog tias tawm ntawm cov ciaj ciam.
    ///
    /// - Yog tias muab ntau, rov qab subslice sib nug rau qhov ntau, lossis `None` yog tias tawm ntawm cov ciam.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// Rov qab los siv cov lus qhia hloov mus rau ib qho kev qhia lossis subslice nyob ntawm seb hom ntawv ntsuas (saib [`get`]) lossis `None` yog tias qhov ntsuas tawm dhau qhov tsis tseem ceeb.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// Rov qab xa cov ntawv qhia rau ib qho twg lossis subslice, tsis tas ua cov kab pov tseg.
    ///
    /// Txog kev nyab xeeb lwm tus pom [`get`].
    ///
    /// # Safety
    ///
    /// Hu cov hom no nrog qhov ntsuas tawm-ntawm-bounds yog *[tus cwj pwm tsis paub qhov tseeb]* txawm tias qhov siv tau los tsis siv.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // KEV RUAJ NTSEG: tus neeg hu yuav tsum txhawb nqa feem ntau ntawm kev nyab xeeb kev nyab xeeb rau `get_unchecked`;
        // cov hlais yog dereferencable vim `self` yog qhov siv nyab xeeb.
        // Tus pointer rov qab muaj kev nyab xeeb vim tias impls ntawm `SliceIndex` yuav tsum tau lees tias nws yog.
        unsafe { &*index.get_unchecked(self) }
    }

    /// Rov qab los siv cov ntsiab lus hloov mus rau ib qho lossis subslice, tsis tas ua cov kab pov tseg.
    ///
    /// Txog kev nyab xeeb lwm tus pom [`get_mut`].
    ///
    /// # Safety
    ///
    /// Hu cov hom no nrog qhov ntsuas tawm-ntawm-bounds yog *[tus cwj pwm tsis paub qhov tseeb]* txawm tias qhov siv tau los tsis siv.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // KEV RUAJ NTSEG: tus neeg hu yuav tsum khaws qhov yuav tsum muaj kev nyab xeeb rau `get_unchecked_mut`;
        // cov hlais yog dereferencable vim `self` yog qhov siv nyab xeeb.
        // Tus pointer rov qab muaj kev nyab xeeb vim tias impls ntawm `SliceIndex` yuav tsum tau lees tias nws yog.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// Rov ib tug nyoos pointer mus rau lub hlais tus tsis.
    ///
    /// Tus neeg hu yuav tsum xyuas kom meej tias cov hlais outlives lub pointer txoj haujlwm no rov qab los, lossis lwm tus nws yuav xaus rau qhov taw qhia khib nyiab.
    ///
    /// Tus hu yuav tsum kuj ua kom paub meej tias lub cim xeeb lub pointer (non-transitively) cov ntsiab lus rau yog tsis tau sau rau (tshwj tsis yog sab hauv `UnsafeCell`) siv tus pointer no lossis txhua tus pointer muab los ntawm nws.
    /// Yog hais tias koj xav tau rau mutate tus txheem ntawm lub hlais, siv [`as_mut_ptr`].
    ///
    /// Hloov kho cov thawv ntim uas tau hais los ntawm cov nplais no yuav ua rau nws tsis tuaj yeem hloov kho, uas tseem yuav ua rau txhua tus taw tes rau nws siv tsis tau.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// Rov qab tuaj yeem tsis muaj kev hloov pauv tsis zoo rau cov hlais cov ntas yeej.
    ///
    /// Tus neeg hu yuav tsum xyuas kom meej tias cov hlais outlives lub pointer txoj haujlwm no rov qab los, lossis lwm tus nws yuav xaus rau qhov taw qhia khib nyiab.
    ///
    /// Hloov kho cov thawv ntim uas tau hais los ntawm cov nplais no yuav ua rau nws tsis tuaj yeem hloov kho, uas tseem yuav ua rau txhua tus taw tes rau nws siv tsis tau.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// Rov qab los rau ob qho khoom siv raw kis rau kev txiav.
    ///
    /// Cov rov qab ntau yog ib nrab-qhib, uas txhais tau hais tias qhov kawg pointer ntsiab lus *ib qho dhau los* qhov kawg ntawm cov hlais.
    /// Txoj kev no, ib qho khoob yog sawv cev los ntawm ob tus taw qhia sib npaug, thiab qhov sib txawv ntawm ob tus taw tes sawv cev qhov loj ntawm cov hlais.
    ///
    /// Saib [`as_ptr`] rau cov lus ceeb toom ntawm kev siv cov ntsiab lus no.Qhov kawg ntawm tus po taw qhia yuav tsum tau ceev faj ntxiv, raws li nws tsis taw tes rau qhov siv tau hauv cov hlais.
    ///
    /// Txoj haujlwm no muaj txiaj ntsig zoo rau kev sib tham nrog kev cuam tshuam txawv teb chaws uas siv ob tus taw tes rau xa mus rau ntau yam ntawm cov ntsiab lus hauv qhov cim xeeb, zoo ib yam li C++ .
    ///
    ///
    /// Nws tseem tuaj yeem siv tau los tshawb xyuas yog tias tus pointer mus rau ib qho khoom siv hais txog lub hauv paus ntawm daim hlais:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // KEV RUAJ NTSEG: Tus `add` ntawm no yog kev nyab xeeb, vim hais tias:
        //
        //   - Tag nrho ob qho taw tes yog ib feem ntawm tib qho khoom, raws li taw qhia ncaj qha dhau los tus kwv kuj suav.
        //
        //   - Qhov loj ntawm cov hlais yeej tsis loj dua isize::MAX bytes, raws li tau sau tseg ntawm no:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - Tsis muaj qhwv ib puag ncig muab kev koom tes, raws li cov hlais tsis qhwv yav tas los ntawm qhov chaw nyob chaw.
        //
        // Saib cov ntaub ntawv ntawm pointer::add.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Rov qab tso tawm ob qho kev nyab xeeb sib cuam tshuam tus taw tes sib nrug.
    ///
    /// Cov rov qab ntau yog ib nrab-qhib, uas txhais tau hais tias qhov kawg pointer ntsiab lus *ib qho dhau los* qhov kawg ntawm cov hlais.
    /// Txoj kev no, ib qho khoob yog sawv cev los ntawm ob tus taw qhia sib npaug, thiab qhov sib txawv ntawm ob tus taw tes sawv cev qhov loj ntawm cov hlais.
    ///
    /// Saib [`as_mut_ptr`] rau cov lus ceeb toom ntawm kev siv cov ntsiab lus no.
    /// Qhov kawg ntawm tus po taw qhia yuav tsum tau ceev faj ntxiv, raws li nws tsis taw tes rau qhov siv tau hauv cov hlais.
    ///
    /// Txoj haujlwm no muaj txiaj ntsig zoo rau kev sib tham nrog kev cuam tshuam txawv teb chaws uas siv ob tus taw tes rau xa mus rau ntau yam ntawm cov ntsiab lus hauv qhov cim xeeb, zoo ib yam li C++ .
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // KEV RUAJ NTSEG: Saib as_ptr_range() saum toj no rau vim li cas `add` ntawm no yog kev nyab xeeb.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Sib pauv ob qho hauv cov hlais.
    ///
    /// # Arguments
    ///
    /// * a, Qhov ntsuas pib ntawm thawj lub ntsiab
    /// * b, Qhov ntsuas tseem ceeb ntawm cov khoom thib ob
    ///
    /// # Panics
    ///
    /// Panics yog `a` lossis `b` tawm ntawm qhov tsis muaj ciam.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // Yuav tsis noj ob mutable nyiaj txais los ntawm ib tug vector, li ntawd, es tsis txhob siv raw pointers.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // KEV RUAJ NTSEG: `pa` thiab `pb` tau raug tsim los ntawm kev nyab xeeb hloov chaw thiab xa mus
        // rau cov ntsiab lus hauv cov hlais thiab yog li ntawd tau lees tias yuav siv tau thiab mus raws li.
        // Nco ntsoov tias nkag mus rau cov khoom tom qab `a` thiab `b` yog kuaj xyuas thiab yuav panic thaum tsis muaj ciam teb.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// Thim qhov kev txiav txim ntawm cov khoom hauv cov hlais, hauv qhov chaw.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // Rau cov hom me me, txhua tus neeg nyeem hauv txoj kev ib txwm ua tsis zoo.
        // Peb tuaj yeem ua kom tau zoo dua, muab cov txiaj ntsig tsis txaus xaj load/store, los ntawm kev thauj khoom tus nqi dav thiab rov mus rau npe.
        //

        // Tob LLVM yuav ua li no rau peb, raws li nws paub zoo tshaj li peb ua seb unaligned nyeem yog npaum (txij li thaum uas hloov ntawm txawv NPAB versions, piv txwv li) li cas thiab lub zoo tshaj plaws thooj loj yuav ua tau.
        // Hmoov tsis zoo, raws li ntawm LLVM 4.0 (2017-05) nws tsuas yog khij lub voj, yog li peb yuav tsum ua qhov no rau peb tus kheej.
        // (Hypothesis: thim rov qab yog qhov teeb meem vim tias ob tog tuaj yeem mus raws li qhov sib txawv-yuav yog, thaum qhov ntev tsis txawv-yog li tsis muaj txoj kev ntawm kev tso ua ntej-thiab tshaj tawm kom siv cov ntawv sib txuas ntawm SIMD hauv nruab nrab.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // Siv llvm.bswap intrinsic kom thim rov qab u8s hauv usize
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // KEV RUAJ NTSEG: Muaj ntau yam kuaj xyuas ntawm no:
                //
                // - Nco ntsoov tias `chunk` yog li 4 lossis 8 vim yog kev kuaj ntawm cfg sau sab saud.Yog li `chunk - 1` yog qhov zoo.
                // - Qhov ntsuas nrog cov qhab nia `i` tau zoo raws li lub voj voos tshwj xeeb
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - Qhov ntaus nqi nrog kev ntsuas `ln - i - chunk = ln - (i + chunk)` yog qhov zoo:
                //   - `i + chunk > 0` yog tsis muaj tseeb.
                //   - Lub voj voos lav:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, yog li kev rho tsis dhau.
                // - Cov `read_unaligned` thiab `write_unaligned` hu tsis zoo:
                //   - `pa` cov ntsiab lus rau index `i` qhov twg `i < ln / 2 - (chunk - 1)` (saib saum toj no) thiab `pb` cov ntsiab lus rau index `ln - i - chunk`, li ntawd, ob qho tib si muaj tsawg kawg `chunk` ntau bytes deb ntawm lub kawg ntawm `self`.
                //
                //   - Cov pib cim xeeb yog siv tau `usize`.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // Siv tig tig-los-16 kom rov qab u16s hauv u32
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // KEV RUAJ NTSEG: Ib qho tsis txaus kos u32 tuaj yeem nyeem ntawm `i` yog `i + 1 < ln`
                // (thiab pom tseeb `i < ln`), vim tias txhua ntu 2 bytes thiab peb nyeem 4.
                //
                // `i + chunk - 1 < ln / 2` # hos mob
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // Txij li nws tsawg dua qhov ntev tau muab faib los ntawm 2, tom qab ntawd nws yuav tsum nyob hauv qhov tsis muaj ciam
                //
                // Qhov no kuj txhais tau hais tias cov xwm txheej `0 < i + chunk <= ln` ib txwm hwm, ua kom lub `pb` pointer tuaj yeem siv nyab xeeb.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // KEV RUAJ NTSEG: `i` yog qhov qis dua ib nrab ntawm qhov ntev ntawm cov hlais yog li
            // Kev nkag mus rau `i` thiab `ln - i - 1` yog qhov muaj kev ruaj ntseg (`i` pib ntawm 0 thiab yuav tsis mus ntxiv dua `ln / 2 - 1`).
            // Cov txiaj ntsig tshwm sim `pa` thiab `pb` yog li ntawd siv tau thiab ua raws li, thiab tuaj yeem nyeem los ntawm thiab sau rau.
            //
            //
            unsafe {
                // Tsis nyab xeeb lub pob kom tsis txhob muaj ciam nyob rau hauv kev sib pauv kom nyab xeeb.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// Rov qab los tus ntsuas dua li cov nplais.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// Rov qab los tus ntsuas hluav taws xob uas tso cai rau hloov kho txhua tus nqi.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// Rov qab los rau tus ntsuas dua txhua ntu windows ntawm ntev `size`.
    /// Lub windows sib tshooj.
    /// Yog tias cov hlais luv dua li `size`, nws yuav rov qab tsis muaj nuj nqis.
    ///
    /// # Panics
    ///
    /// Panics yog `size` yog 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Yog hais tias lub hlais yog luv dua `size`:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// Rov qab tus ntsuas hluav taws xob tshaj `chunk_size` lub zog ntawm cov hlais ib zaug, pib ntawm qhov pib hlais.
    ///
    /// Lub chunks yog slices thiab ua tsis sib tshooj.Yog tias `chunk_size` tsis faib qhov ntev ntawm cov hlais, tom qab kawg chunk yuav tsis muaj qhov ntev `chunk_size`.
    ///
    /// Saib [`chunks_exact`] rau ib tug variant ntawm no iterator uas rov qab chunks ntawm yeej ib txwm raws nraim `chunk_size` hais, thiab [`rchunks`] rau tib lub iterator tab sis pib ntawm lub kawg ntawm lub hlais.
    ///
    ///
    /// # Panics
    ///
    /// Panics yog `chunk_size` yog 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// Rov qab tus ntsuas hluav taws xob tshaj `chunk_size` lub zog ntawm cov hlais ib zaug, pib ntawm qhov pib hlais.
    ///
    /// Cov chunks yog qhov tuaj yeem hloov pauv, thiab tsis sib tshooj.Yog tias `chunk_size` tsis faib qhov ntev ntawm cov hlais, tom qab kawg chunk yuav tsis muaj qhov ntev `chunk_size`.
    ///
    /// Pom [`chunks_exact_mut`] rau qhov sib txawv ntawm qhov tsim tawm no uas rov qab chunks ntawm ib txwm ua raws `chunk_size` cov khoom, thiab [`rchunks_mut`] rau tib qho kev ntsuas tab sis pib ntawm qhov kawg ntawm hlais.
    ///
    ///
    /// # Panics
    ///
    /// Panics yog `chunk_size` yog 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// Rov qab tus ntsuas hluav taws xob tshaj `chunk_size` lub zog ntawm cov hlais ib zaug, pib ntawm qhov pib hlais.
    ///
    /// Cov chunks yog cov nplais thiab tsis sib tshooj.
    /// Yog hais tias `chunk_size` tsis faib qhov ntev ntawm lub hlais, ces kawg mus txog `chunk_size-1` hais yuav tsum rho thiab yuav retrieved los ntawm cov `remainder` muaj nuj nqi ntawm lub iterator.
    ///
    ///
    /// Vim txhua chunk muaj raws nraim `chunk_size` cov ntsiab lus, lub compiler feem ntau tuaj yeem ua kom qhov txiaj ntsig cov txiaj ntsig zoo dua li ntawm [`chunks`].
    ///
    /// Pom [`chunks`] rau qhov sib txawv ntawm qhov ntsuas no uas tseem rov cov seem uas yog me dua, thiab [`rchunks_exact`] rau tib qho kev ntsuas tab sis pib ntawm qhov kawg ntawm hlais.
    ///
    /// # Panics
    ///
    /// Panics yog `chunk_size` yog 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// Rov qab tus ntsuas hluav taws xob tshaj `chunk_size` lub zog ntawm cov hlais ib zaug, pib ntawm qhov pib hlais.
    ///
    /// Cov chunks yog qhov tuaj yeem hloov pauv, thiab tsis sib tshooj.
    /// Yog hais tias `chunk_size` tsis faib qhov ntev ntawm lub hlais, ces kawg mus txog `chunk_size-1` hais yuav tsum rho thiab yuav retrieved los ntawm cov `into_remainder` muaj nuj nqi ntawm lub iterator.
    ///
    ///
    /// Vim txhua yam muaj raws nraim `chunk_size` hais, lub compiler yuav feem ntau optimize lub resulting code zoo dua nyob rau hauv cov ntaub ntawv ntawm [`chunks_mut`].
    ///
    /// Pom [`chunks_mut`] rau qhov sib txawv ntawm qhov ntsuas no uas tseem rov cov seem uas yog me dua, thiab [`rchunks_exact_mut`] rau tib qho kev ntsuas tab sis pib ntawm qhov kawg ntawm hlais.
    ///
    /// # Panics
    ///
    /// Panics yog `chunk_size` yog 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// Phua cov hlais txia mus ua ib kab ntawm 'N'-caij arrays, kwv yees tias tsis muaj cov seem.
    ///
    ///
    /// # Safety
    ///
    /// Qhov no tsuas yog hu tau thaum twg
    /// - Cov hlais phua tawm ua ke rau hauv `N`-caij cov tshooj (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // KEV RUAJ NTSEG: 1-ntu ntu ib txwm tsis muaj seem
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // TXUJ CI: Cov hlais ntev (6) yog qhov ntau ntawm 3
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // Cov no yuav tsis muaj tseeb:
    /// // cia chunks: &[[_;5]]= slice.as_chunks_unchecked()//Lub hlais ntev no tsis muaj ntau yam ntawm 5 cia chunks:&[[_;0]]= slice.as_chunks_unchecked()//Cov voj txwv ntev ntev tsis pub ib zaug
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // TXUJ CI: Peb qhov tshwj xeeb yog qhov uas yuav tsum tau hu rau qhov no
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // KEV RUAJ NTSEG: Peb nrum cov hlais cov ntawv `new_len * N` nkag rau hauv
        // ib daim ntawm `new_len` ntau `N` ntsiab chunks.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// Muab cov hlais sib faib ua ib thooj ntawm 'N`-lub caij muaj tswv yim, pib ntawm qhov pib ntawm hlais, thiab cov seem uas seem nrog ntev ntev tsawg dua `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics yog `N` yog 0. Qhov kev kuaj xyuas no feem ntau yuav raug hloov pauv mus rau qhov kev suav sau lub sijhawm yuam kev ua ntej cov qauv no ruaj khov.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // KEV RUAJ NTSEG: Peb twb npau taws rau xoom, thiab paub tseeb los ntawm kev tsim kho
        // uas qhov ntev ntawm lub subslice yog ib tug ntau yam ntawm N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// Muab cov hlais sib faib ua ib thooj ntawm 'N`-lub caij muaj tswv yim, pib ntawm qhov kawg ntawm hlais, thiab cov seem uas tseem tshuav nrog ntev ntev tsawg dua `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics yog `N` yog 0. Qhov kev kuaj xyuas no feem ntau yuav raug hloov pauv mus rau qhov kev suav sau lub sijhawm yuam kev ua ntej cov qauv no ruaj khov.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // KEV RUAJ NTSEG: Peb twb npau taws rau xoom, thiab paub tseeb los ntawm kev tsim kho
        // uas qhov ntev ntawm lub subslice yog ib tug ntau yam ntawm N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// Rov qab tus ntsuas hluav taws xob tshaj `N` lub zog ntawm cov hlais ib zaug, pib ntawm qhov pib hlais.
    ///
    /// Cov chunks yog array cov ntawv xa mus thiab tsis sib tshooj.
    /// Yog tias `N` tsis faib qhov ntev ntawm cov hlais, tom qab kawg mus txog `N-1` cov ntsiab lus yuav raug rho tawm thiab tuaj yeem rov tau los ntawm `remainder` kev ua haujlwm ntawm tus ntsuas pa.
    ///
    ///
    /// Txoj kev no yog qhov tseem ceeb tshaj ntawm [`chunks_exact`].
    ///
    /// # Panics
    ///
    /// Panics yog `N` yog 0. Qhov kev kuaj xyuas no feem ntau yuav raug hloov pauv mus rau qhov kev suav sau lub sijhawm yuam kev ua ntej cov qauv no ruaj khov.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// Phua cov hlais txia mus ua ib kab ntawm 'N'-caij arrays, kwv yees tias tsis muaj cov seem.
    ///
    ///
    /// # Safety
    ///
    /// Qhov no tsuas yog hu tau thaum twg
    /// - Cov hlais phua tawm ua ke rau hauv `N`-caij cov tshooj (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // KEV RUAJ NTSEG: 1-ntu ntu ib txwm tsis muaj seem
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // TXUJ CI: Cov hlais ntev (6) yog qhov ntau ntawm 3
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // Cov no yuav tsis muaj tseeb:
    /// // cia chunks: &[[_;5]]= slice.as_chunks_unchecked_mut()//Qhov hlais ntev tsis yog qhov ntau ntawm 5 cia chunks:&[[_;0]]= slice.as_chunks_unchecked_mut()//Cov voj txwv ntev ntev tsis pub ib zaug
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // TXUJ CI: Peb qhov tshwj xeeb yog qhov uas yuav tsum tau hu rau qhov no
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // KEV RUAJ NTSEG: Peb nrum cov hlais cov ntawv `new_len * N` nkag rau hauv
        // ib daim ntawm `new_len` ntau `N` ntsiab chunks.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// Muab cov hlais sib faib ua ib thooj ntawm 'N`-lub caij muaj tswv yim, pib ntawm qhov pib ntawm hlais, thiab cov seem uas seem nrog ntev ntev tsawg dua `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics yog `N` yog 0. Qhov kev kuaj xyuas no feem ntau yuav raug hloov pauv mus rau qhov kev suav sau lub sijhawm yuam kev ua ntej cov qauv no ruaj khov.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // KEV RUAJ NTSEG: Peb twb npau taws rau xoom, thiab paub tseeb los ntawm kev tsim kho
        // uas qhov ntev ntawm lub subslice yog ib tug ntau yam ntawm N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// Muab cov hlais sib faib ua ib thooj ntawm 'N`-lub caij muaj tswv yim, pib ntawm qhov kawg ntawm hlais, thiab cov seem uas tseem tshuav nrog ntev ntev tsawg dua `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics yog `N` yog 0. Qhov kev kuaj xyuas no feem ntau yuav raug hloov pauv mus rau qhov kev suav sau lub sijhawm yuam kev ua ntej cov qauv no ruaj khov.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // KEV RUAJ NTSEG: Peb twb npau taws rau xoom, thiab paub tseeb los ntawm kev tsim kho
        // uas qhov ntev ntawm lub subslice yog ib tug ntau yam ntawm N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// Rov qab tus ntsuas hluav taws xob tshaj `N` lub zog ntawm cov hlais ib zaug, pib ntawm qhov pib hlais.
    ///
    /// Lub chunks yog mutable array ua tim khawv thiab ua tsis sib tshooj.
    /// Yog tias `N` tsis faib qhov ntev ntawm cov hlais, tom qab kawg mus txog `N-1` cov ntsiab lus yuav raug rho tawm thiab tuaj yeem rov tau los ntawm `into_remainder` kev ua haujlwm ntawm tus ntsuas pa.
    ///
    ///
    /// Txoj kev no yog qhov tseem ceeb tshaj ntawm [`chunks_exact_mut`].
    ///
    /// # Panics
    ///
    /// Panics yog `N` yog 0. Qhov kev kuaj xyuas no feem ntau yuav raug hloov pauv mus rau qhov kev suav sau lub sijhawm yuam kev ua ntej cov qauv no ruaj khov.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// Rov qab los rau tus ntsuas pa hla kev windows ntawm `N` cov ntsiab lus ntawm cov hlais, pib thaum pib ntawm cov hlais.
    ///
    ///
    /// Qhov no yog tus nqi hluav taws xob sib npaug ntawm [`windows`].
    ///
    /// Yog `N` ntau dua qhov luaj li cas hlais, nws yuav rov tsis muaj windows.
    ///
    /// # Panics
    ///
    /// Panics yog `N` yog 0.
    /// Daim tshev no feem ntau yuav raug hloov mus rau qhov kev suav sau lub sijhawm yuam kev ua ntej hom no ruaj khov.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// Rov qab tus ntsuas hluav taws xob tshaj `chunk_size` cov ntsiab lus ntawm cov hlais nyob rau ib lub sijhawm, pib ntawm qhov kawg ntawm hlais.
    ///
    /// Lub chunks yog slices thiab ua tsis sib tshooj.Yog tias `chunk_size` tsis faib qhov ntev ntawm cov hlais, tom qab kawg chunk yuav tsis muaj qhov ntev `chunk_size`.
    ///
    /// Saib [`rchunks_exact`] rau ib tug variant ntawm no iterator uas rov qab chunks ntawm yeej ib txwm raws nraim `chunk_size` hais, thiab [`chunks`] rau tib lub iterator tab sis pib thaum pib ntawm lub hlais.
    ///
    ///
    /// # Panics
    ///
    /// Panics yog `chunk_size` yog 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// Rov qab tus ntsuas hluav taws xob tshaj `chunk_size` cov ntsiab lus ntawm cov hlais nyob rau ib lub sijhawm, pib ntawm qhov kawg ntawm hlais.
    ///
    /// Cov chunks yog qhov tuaj yeem hloov pauv, thiab tsis sib tshooj.Yog tias `chunk_size` tsis faib qhov ntev ntawm cov hlais, tom qab kawg chunk yuav tsis muaj qhov ntev `chunk_size`.
    ///
    /// Pom [`rchunks_exact_mut`] rau qhov sib txawv ntawm qhov tsim tawm no uas rov qab chunks ntawm ib txwm ua raws `chunk_size` cov khoom, thiab [`chunks_mut`] rau tib qho kev ntsuas tab sis pib thaum pib hlais.
    ///
    ///
    /// # Panics
    ///
    /// Panics yog `chunk_size` yog 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// Rov qab tus ntsuas hluav taws xob tshaj `chunk_size` cov ntsiab lus ntawm cov hlais nyob rau ib lub sijhawm, pib ntawm qhov kawg ntawm hlais.
    ///
    /// Cov chunks yog cov nplais thiab tsis sib tshooj.
    /// Yog hais tias `chunk_size` tsis faib qhov ntev ntawm lub hlais, ces kawg mus txog `chunk_size-1` hais yuav tsum rho thiab yuav retrieved los ntawm cov `remainder` muaj nuj nqi ntawm lub iterator.
    ///
    /// Vim txhua chunk muaj raws nraim `chunk_size` cov ntsiab lus, lub compiler feem ntau tuaj yeem ua kom qhov txiaj ntsig cov txiaj ntsig zoo dua li ntawm [`chunks`].
    ///
    /// Pom [`rchunks`] rau qhov sib txawv ntawm qhov ntsuas no uas tseem rov cov seem uas yog me dua, thiab [`chunks_exact`] rau tib qho kev ntsuas tab sis pib thaum pib hlais.
    ///
    ///
    /// # Panics
    ///
    /// Panics yog `chunk_size` yog 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// Rov qab tus ntsuas hluav taws xob tshaj `chunk_size` cov ntsiab lus ntawm cov hlais nyob rau ib lub sijhawm, pib ntawm qhov kawg ntawm hlais.
    ///
    /// Cov chunks yog qhov tuaj yeem hloov pauv, thiab tsis sib tshooj.
    /// Yog hais tias `chunk_size` tsis faib qhov ntev ntawm lub hlais, ces kawg mus txog `chunk_size-1` hais yuav tsum rho thiab yuav retrieved los ntawm cov `into_remainder` muaj nuj nqi ntawm lub iterator.
    ///
    /// Vim txhua yam muaj raws nraim `chunk_size` hais, lub compiler yuav feem ntau optimize lub resulting code zoo dua nyob rau hauv cov ntaub ntawv ntawm [`chunks_mut`].
    ///
    /// Saib [`rchunks_mut`] rau ib tug variant ntawm no iterator uas tseem rov tas raws li ib tug me me thooj, thiab [`chunks_exact_mut`] rau tib lub iterator tab sis pib thaum pib ntawm lub hlais.
    ///
    ///
    /// # Panics
    ///
    /// Panics yog `chunk_size` yog 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// Rov qab los ib qho ntsuas dua li cov hlais ua cov khoom sib tshooj khiav ntawm cov khoom siv uas siv cov predicate los cais lawv.
    ///
    /// Lub predicate yog hu rau ob lub hauv qab lawv tus kheej, nws txhais tau tias cov predicate yog hu rau `slice[0]` thiab `slice[1]` tom qab ntawd ntawm `slice[1]` thiab `slice[2]` thiab lwm yam.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Txoj kev no tuaj yeem siv los rho tawm cov subslices tso:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// Rov qab los ib qho ntsuas dua li cov hlais ua cov tsis sib tshooj khiav ntawm cov khoom siv uas siv cov predicate los cais lawv.
    ///
    /// Lub predicate yog hu rau ob lub hauv qab lawv tus kheej, nws txhais tau tias cov predicate yog hu rau `slice[0]` thiab `slice[1]` tom qab ntawd ntawm `slice[1]` thiab `slice[2]` thiab lwm yam.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Txoj kev no tuaj yeem siv los rho tawm cov subslices tso:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// Faib ib qho sib faib ua ob qho ntawm qhov ntsuas.
    ///
    /// Thawj zaug yuav muaj tag nrho cov taw qhia los ntawm `[0, mid)` (tsis suav nrog lub Performance index `mid` nws tus kheej) thiab lub thib ob yuav muaj txhua qhov ntsuas ntawm `[mid, len)` (tsis suav nrog lub npe `len` nws tus kheej).
    ///
    ///
    /// # Panics
    ///
    /// Panics yog `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // KEV RUAJ NTSEG: `[ptr; mid]` thiab `[mid; len]` sab hauv `self`, uas
        // ua tiav cov cai ntawm `from_raw_parts_mut`.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// Muab faib rau ib qho sib hloov tau ua ob qho ntawm qhov ntsuas.
    ///
    /// Thawj zaug yuav muaj tag nrho cov taw qhia los ntawm `[0, mid)` (tsis suav nrog lub Performance index `mid` nws tus kheej) thiab lub thib ob yuav muaj txhua qhov ntsuas ntawm `[mid, len)` (tsis suav nrog lub npe `len` nws tus kheej).
    ///
    ///
    /// # Panics
    ///
    /// Panics yog `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // KEV RUAJ NTSEG: `[ptr; mid]` thiab `[mid; len]` sab hauv `self`, uas
        // ua tiav cov cai ntawm `from_raw_parts_mut`.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// Faib ib qho faib ua ob sab ntawm qhov ntsuas, tsis ua qhov ntsuas xyuas.
    ///
    /// Thawj zaug yuav muaj tag nrho cov taw qhia los ntawm `[0, mid)` (tsis suav nrog lub Performance index `mid` nws tus kheej) thiab lub thib ob yuav muaj txhua qhov ntsuas ntawm `[mid, len)` (tsis suav nrog lub npe `len` nws tus kheej).
    ///
    ///
    /// Txog kev nyab xeeb lwm tus pom [`split_at`].
    ///
    /// # Safety
    ///
    /// Hu cov hom no nrog qhov ntsuas tawm-ntawm-bounds yog *[tus cwj pwm tsis paub qhov tseeb]* txawm tias qhov siv tau los tsis siv.Tus neeg hu tuaj yeem kom paub meej tias `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // KEV RUAJ NTSEG: Tus hu yuav tsum kos tias `0 <= mid <= self.len()`
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// Divides ib mutable hlais mus rau hauv ob ib tug Performance index, tsis tau ua raws kev kuaj.
    ///
    /// Thawj zaug yuav muaj tag nrho cov taw qhia los ntawm `[0, mid)` (tsis suav nrog lub Performance index `mid` nws tus kheej) thiab lub thib ob yuav muaj txhua qhov ntsuas ntawm `[mid, len)` (tsis suav nrog lub npe `len` nws tus kheej).
    ///
    ///
    /// Rau ib kev ruaj ntseg lwm saib [`split_at_mut`].
    ///
    /// # Safety
    ///
    /// Hu cov hom no nrog qhov ntsuas tawm-ntawm-bounds yog *[tus cwj pwm tsis paub qhov tseeb]* txawm tias qhov siv tau los tsis siv.Tus neeg hu tuaj yeem kom paub meej tias `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // KEV RUAJ NTSEG: Tus hu yuav tsum kos tias `0 <= mid <= self.len()`.
        //
        // `[ptr; mid]` thiab `[mid; len]` tsis dhau txheej, yog li rov qab los saib dua tshiab yog qhov zoo.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// Rov qab los rau tus ntsuas pa hla kev subslices sib cais los ntawm cov khoom uas sib phim `pred`.
    /// Lub ntsiab lus sib txuam tsis muaj nyob hauv cov subslices.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Yog hais tias tus thawj lub caij matched, ib qho kev npliag hlais yuav ua tau tus thawj yam khoom rov qab los ntawm lub iterator.
    /// Zoo sib xws, yog tias lub caij kawg hauv cov hlais tau sib phim, ib qho khoob yuav yog cov khoom kawg rov los los ntawm tus kav:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Yog hais tias ob lub ntsiab uas sib txuam tau ncaj qha nyob ib sab, ib npliag yuav tuaj nyob nruab nrab ntawm lawv:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// Rov qab los rau tus ntsuas pa hla cov kev hloov pauv uas sib cais los ntawm cov khoom uas phim `pred`.
    /// Lub ntsiab lus sib txuam tsis muaj nyob hauv cov subslices.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// Rov qab los rau tus ntsuas pa hla kev subslices sib cais los ntawm cov khoom uas sib phim `pred`.
    /// Cov khoom sib txuam tau muaj nyob rau hauv qhov kawg ntawm qhov kawg subslice ua tus ntaus luag.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Yog hais tias lub caij kawg ntawm cov hlais tau sib phim, qhov khoom ntawd yuav raug suav hais tias yog tus txiav txim ntawm cov hlais ua ntej.
    ///
    /// Cov hlais ntawd yuav yog qhov khoom kawg rov los ntawm tus kav.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// Rov qab los rau tus ntsuas pa hla cov kev hloov pauv uas sib cais los ntawm cov khoom uas phim `pred`.
    /// Cov sib txuam tau muaj nyob hauv cov subslice dhau los uas yog tus tsim cov npe.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// Rov qab los rau tus ntsuas pa hla kev subslices sib cais los ntawm cov khoom uas sib phim `pred`, pib ntawm qhov kawg ntawm hlais thiab ua haujlwm rov qab.
    /// Lub ntsiab lus sib txuam tsis muaj nyob hauv cov subslices.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ib yam li `split()`, yog tias thawj zaug lossis theem kawg ua ke sib phim, ib qho khoob yuav yog thawj (lossis kawg) cov khoom xa rov qab los ntawm tus kav.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// Rov qab los rau tus ntsuas pa hla cov kev hloov pauv tau sib cais los ntawm cov khoom uas sib phim `pred`, pib ntawm qhov kawg ntawm cov hlais thiab ua haujlwm rov qab.
    /// Lub ntsiab lus sib txuam tsis muaj nyob hauv cov subslices.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// Rov qab los ib iterator tshaj subslices sib cais los ntawm lub ntsiab uas phim `pred`, tag rau rov qab rau ntawm cov `n` khoom.
    /// Lub ntsiab lus sib txuam tsis muaj nyob hauv cov subslices.
    ///
    /// Lub caij kawg rov qab, yog tias muaj, yuav muaj cov seem ntawm cov hlais.
    ///
    /// # Examples
    ///
    /// Sau lub hlais phua ib zaug los ntawm tus xov tooj divisible los ntawm 3 (ie, `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// Rov qab los ib iterator tshaj subslices sib cais los ntawm lub ntsiab uas phim `pred`, tag rau rov qab rau ntawm cov `n` khoom.
    /// Lub ntsiab lus sib txuam tsis muaj nyob hauv cov subslices.
    ///
    /// Lub caij kawg rov qab, yog tias muaj, yuav muaj cov seem ntawm cov hlais.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// Rov qab los rau tus ntsuas pa hla kev subslices sib cais los ntawm cov khoom uas phim `pred` txwv kom rov qab los ntawm cov khoom feem ntau `n`.
    /// Qhov no pib ntawm qhov kawg ntawm cov hlais thiab ua haujlwm rov qab.
    /// Lub ntsiab lus sib txuam tsis muaj nyob hauv cov subslices.
    ///
    /// Lub caij kawg rov qab, yog tias muaj, yuav muaj cov seem ntawm cov hlais.
    ///
    /// # Examples
    ///
    /// Luam tawm cov hlais faib ib zaug, pib rau tom kawg, los ntawm cov lej pom tau los ntawm 3 (piv txwv li, `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// Rov qab los rau tus ntsuas pa hla kev subslices sib cais los ntawm cov khoom uas phim `pred` txwv kom rov qab los ntawm cov khoom feem ntau `n`.
    /// Qhov no pib ntawm qhov kawg ntawm cov hlais thiab ua haujlwm rov qab.
    /// Lub ntsiab lus sib txuam tsis muaj nyob hauv cov subslices.
    ///
    /// Lub caij kawg rov qab, yog tias muaj, yuav muaj cov seem ntawm cov hlais.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// Rov qab `true` yog tias cov hlais muaj ib qho khoom nrog rau tus nqi muab.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// Yog tias koj tsis muaj `&T`, tab sis tsuas yog ib qho `&U` xws li tias `T: Borrow<U>` (xws li
    /// 'Hlua: qiv<str>`), koj tuaj yeem siv `iter().any`:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // hlais ntawm `String`
    /// assert!(v.iter().any(|e| e == "hello")); // tshawb nrhiav nrog `&str`
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// Rov qab `true` yog `needle` yog lub cim ua ntej ntawm cov hlais.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// Txhua zaus rov `true` yog `needle` yog ib qho khoob:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// Xa rov qab `true` yog `needle` yog cov ntawv seem ntawm cov hlais.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// Txhua zaus rov `true` yog `needle` yog ib qho khoob:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// Rov qab cov nyiaj subslice nrog cov ua ntej tshem tawm.
    ///
    /// Yog tias cov hlais pib nrog `prefix`, rov xa cov subslice tom qab ua ntej sau, qhwv hauv `Some`.
    /// Yog tias `prefix` qhov khoob, tsuas rov qhov qub hlais.
    ///
    /// Yog tias cov hlaws tsis pib nrog `prefix`, rov `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Qhov no muaj nuj nqi yuav tsum tau rewriting yog thiab thaum twg SlicePattern yuav ntau sophisticated.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// Rov qab cov subslice nrog rau cov tsiaj ntawv tshem.
    ///
    /// Yog tias cov hlaws xaus nrog `suffix`, rov xa cov subslice ua ntej cov tsiaj ntawv ua tom qab, qhwv hauv `Some`.
    /// Yog tias `suffix` qhov khoob, tsuas rov qhov qub hlais.
    ///
    /// Yog tias cov hlaws tsis xaus nrog `suffix`, rov `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Qhov no muaj nuj nqi yuav tsum tau rewriting yog thiab thaum twg SlicePattern yuav ntau sophisticated.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// Binary tshawb qhov txheeb cais li no rau ib qho uas tau muab rau.
    ///
    /// Yog tias pom tus nqi ces [`Result::Ok`] xa rov qab, uas muaj cov ntsuas ntawm cov khoom txuam.
    /// Yog tias muaj ntau qhov sib luag, tom qab ntawd ib qho ntawm cov ntais ntawv yuav raug xa rov qab.
    /// Yog hais tias tus nqi tsis tau pom ces [`Result::Err`] xa rov qab, muaj cov khoom ntsuas uas qhov khoom sib piv tau muab tso thaum tswj qhov kev txiav txim txheeb.
    ///
    ///
    /// Xyuas [`binary_search_by`], [`binary_search_by_key`], thiab [`partition_point`].
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Zoo li hauv plaub ntu.
    /// Thawj qhov yog pom, nrog rau qhov kev txiav txim siab tsis xws dua;qhov thib ob thiab peb tsis pom;cov plaub yuav phim txhua txoj hauj lwm nyob rau hauv `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// Yog hais tias koj xav mus tau ntxig ib yam khoom rau ib tug txheeb vector, thaum tswj tsi txiav txim:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// Binary tshawb qhov txheeb cais no nrog tus ntsuas sib piv.
    ///
    /// Lub comparator muaj nuj nqi yuav tsum siv ib tug thiaj li zoo ib yam nrog rau cov tsi kev txiav txim ntawm lub qhov pib hlais, rov qab kev txiav txim code uas qhia seb nws sib cav yog `Less`, `Equal` los yog `Greater` cov yam hom phiaj.
    ///
    ///
    /// Yog tias pom tus nqi ces [`Result::Ok`] xa rov qab, uas muaj cov ntsuas ntawm cov khoom txuam.Yog tias muaj ntau qhov sib luag, tom qab ntawd ib qho ntawm cov ntais ntawv yuav raug xa rov qab.
    /// Yog hais tias tus nqi tsis tau pom ces [`Result::Err`] xa rov qab, muaj cov khoom ntsuas uas qhov khoom sib piv tau muab tso thaum tswj qhov kev txiav txim txheeb.
    ///
    /// Xyuas [`binary_search`], [`binary_search_by_key`], thiab [`partition_point`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Zoo li hauv plaub ntu.Thawj qhov yog pom, nrog rau qhov kev txiav txim siab tsis xws dua;qhov thib ob thiab peb tsis pom;plaub kuj tuaj yeem phim rau txhua txoj hauj lwm hauv `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // KEV RUAJ NTSEG: kev hu yog tsim kom muaj kev nyab xeeb los ntawm cov kab mob hauv qab no:
            // - `mid >= 0`
            // - `mid < size`: `mid` muaj kev txwv los ntawm `[left; right)` ua txhua yam.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // Yog vim li cas vim li cas peb siv if/else tswj kev khiav nrawm dua li qhov sib piv yog vim tias cov kev sib tw ua haujlwm sib piv cov haujlwm, uas yog perf rhiab.
            //
            // Qhov no yog x86 ASM rau u8: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// Binary tshawb cov no txheeb nrog cov tseem ceeb rho tawm haujlwm.
    ///
    /// Txheeb tias cov hlais tau txheeb los ntawm tus yuam sij, piv txwv li nrog [`sort_by_key`] siv tib qho tseem ceeb rho tawm haujlwm.
    ///
    /// Yog tias pom tus nqi ces [`Result::Ok`] xa rov qab, uas muaj cov ntsuas ntawm cov khoom txuam.
    /// Yog tias muaj ntau qhov sib luag, tom qab ntawd ib qho ntawm cov ntais ntawv yuav raug xa rov qab.
    /// Yog hais tias tus nqi tsis tau pom ces [`Result::Err`] xa rov qab, muaj cov khoom ntsuas uas qhov khoom sib piv tau muab tso thaum tswj qhov kev txiav txim txheeb.
    ///
    ///
    /// Saib kuj [`binary_search`], [`binary_search_by`], thiab [`partition_point`].
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Zoo li hauv plaub ntu hauv ib kuav ntawm cov khub txheeb los ntawm lawv cov ntsiab lus thib ob.
    /// Thawj qhov yog pom, nrog rau qhov kev txiav txim siab tsis xws dua;qhov thib ob thiab peb tsis pom;cov plaub yuav phim txhua txoj hauj lwm nyob rau hauv `[1, 4]`.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // Lint rustdoc::broken_intra_doc_links yog tso cai raws li `slice::sort_by_key` yog nyob rau hauv crate `alloc`, thiab raws li xws li tsis tshwm sim tsis tau thaum lub tsev `core`.
    //
    // kev txuas rau downstream crate: #74481.Txij li cov thawj zaug tsuas yog sau tseg hauv libstd (#73423), qhov no yeej tsis ua rau kev sib tsoo tawg hauv kev coj ua.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Qha cov hlais, tab sis tej zaum yuav tsis khaws qhov kev txiav txim ntawm cov khoom sib npaug.
    ///
    /// Qhov kev xaiv no tsis ruaj khov (xws li, yuav rov kho dua tshiab sib npaug), hauv-chaw (ie, tsis faib), thiab *O*(*n*\*log(* n*)) qhov tsis zoo-rooj plaub.
    ///
    /// # Kev siv tam sim no
    ///
    /// Qhov kev daws teeb meem tam sim no yog txiav los ntawm [pattern-defeating quicksort][pdqsort] los ntawm Orson Peters, uas sib xyaw cov ntaub ntawv ceev nrawm ntawm randomized quicksort nrog cov teeb meem sai ntawm heapsort, thaum ua tiav cov kab sij hawm ntawm cov hlais nrog qee cov qauv.
    /// Nws siv qee cov kev tsis suav nrog kom zam dhau cov xwm txheej tsis zoo, tab sis nrog lub chaw ruaj khov seed los ib txwm coj tus cwj pwm txiav txim siab.
    ///
    /// Nws yog sai dua li kev ruaj khov sorting, tshwj tsis yog hauv qee kis tshwj xeeb, piv txwv li, thaum cov hlais muaj ob peb concatenated txheeb cov ntu.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// Teeb cov hlais nrog cov sib piv ua kom zoo, tab sis tej zaum yuav tsis tuaj yeem khaws cov xaj ntawm cov khoom sib npaug.
    ///
    /// Qhov kev xaiv no tsis ruaj khov (xws li, yuav rov kho dua tshiab sib npaug), hauv-chaw (ie, tsis faib), thiab *O*(*n*\*log(* n*)) qhov tsis zoo-rooj plaub.
    ///
    /// Kev ntsuas kev sib piv yuav tsum txhais tag nrho cov khoom xaj rau cov khoom hauv cov hlais.Yog tias qhov kev txiav txim tsis suav tag nrho, qhov kev xaj ntawm cov khoom tsis tau txheeb xyuas.Ib qho kev txiav txim yog qhov kev txiav txim tag nrho yog tias nws yog (rau txhua `a`, `b` thiab `c`):
    ///
    /// * tag nrho thiab antisymmetric: ib qho `a < b`, `a == b` lossis `a > b` yog qhov tseeb, thiab
    /// * hloov pauv, `a < b` thiab `b < c` teeb meem `a < c`.Tib yam yuav tsum tuav rau ob qho `==` thiab `>`.
    ///
    /// Piv txwv li, thaum [`f64`] tsis siv [`Ord`] vim `NaN != NaN`, peb tuaj yeem siv `partial_cmp` raws li peb cov haujlwm ua haujlwm thaum peb paub cov hlais tsis muaj `NaN`.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # Kev siv tam sim no
    ///
    /// Qhov kev daws teeb meem tam sim no yog txiav los ntawm [pattern-defeating quicksort][pdqsort] los ntawm Orson Peters, uas sib xyaw cov ntaub ntawv ceev nrawm ntawm randomized quicksort nrog cov teeb meem sai ntawm heapsort, thaum ua tiav cov kab sij hawm ntawm cov hlais nrog qee cov qauv.
    /// Nws siv qee cov kev tsis suav nrog kom zam dhau cov xwm txheej tsis zoo, tab sis nrog lub chaw ruaj khov seed los ib txwm coj tus cwj pwm txiav txim siab.
    ///
    /// Nws yog sai dua li kev ruaj khov sorting, tshwj tsis yog hauv qee kis tshwj xeeb, piv txwv li, thaum cov hlais muaj ob peb concatenated txheeb cov ntu.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // rov qab sorting
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// Teeb cov hlais nrog cov yuam sij ua kom zoo, tab sis tej zaum yuav tsis khaws cov xaj ntawm cov khoom sib npaug.
    ///
    /// Qhov kev xaiv no tsis ruaj khov (piv txwv li, yuav rov kho dua tshiab sib npaug), hauv-chaw (ie, tsis faib), thiab *O*(m\* * n *\* log(*n*)) qhov tsis zoo-rooj plaub, qhov ua haujlwm tseem ceeb yog *O*(*m*).
    ///
    /// # Kev siv tam sim no
    ///
    /// Qhov kev daws teeb meem tam sim no yog txiav los ntawm [pattern-defeating quicksort][pdqsort] los ntawm Orson Peters, uas sib xyaw cov ntaub ntawv ceev nrawm ntawm randomized quicksort nrog cov teeb meem sai ntawm heapsort, thaum ua tiav cov kab sij hawm ntawm cov hlais nrog qee cov qauv.
    /// Nws siv qee cov kev tsis suav nrog kom zam dhau cov xwm txheej tsis zoo, tab sis nrog lub chaw ruaj khov seed los ib txwm coj tus cwj pwm txiav txim siab.
    ///
    /// Vim nws txoj haujlwm tseem ceeb hu, [`sort_unstable_by_key`](#method.sort_unstable_by_key) yog qhov yuav tau qeeb dua [`sort_by_cached_key`](#method.sort_by_cached_key) hauv cov xwm txheej uas lub luag haujlwm tseem ceeb yuav kim.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Reorder cov hlais xws li tias lub caij ntawm `index` yog ntawm nws txoj haujlwm xaiv kawg.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// Rov kho cov hlais nrog cov kev sib piv ua haujlwm xws li lub ntsiab ntawm `index` yog ntawm nws txoj haujlwm zaum kawg.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// Reorder cov hlais nrog qhov tseem ceeb ua kom zoo li lub ntsiab ntawm `index` yog ntawm nws txoj haujlwm zaum kawg.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// Reorder cov hlais xws li tias lub caij ntawm `index` yog ntawm nws txoj haujlwm xaiv kawg.
    ///
    /// Qhov kev rov ua ntxiv no muaj cov cuab yeej ntxiv uas txhua qhov muaj nuj nqis ntawm txoj haujlwm `i < index` yuav tsawg dua lossis sib luag rau ib qho nqi ntawm ib qho chaw `j > index`.
    /// Ib qho ntxiv, qhov kev thim rov qab tsis ruaj khov (ie
    /// yam tsawg muaj vaj huam sib hais yuav mus nyob txoj hauj lwm `index`), nyob rau hauv-qhov chaw (ie
    /// tsis faib nyiaj), thiab *O*(*n*) qhov tsis zoo-rooj plaub.
    /// Txoj haujlwm no tseem paub/paub ua "kth element" hauv lwm lub tsev nyeem ntawv.
    /// Nws rov muab cov txiaj ntsig ntawm cov nuj nqis nram qab no: txhua lub ntsiab tsawg dua qhov ntawm qhov ntsuas, tus nqi ntawm qhov ntsuas, thiab tag nrho cov ntsiab ntau dua ib qho ntawm qhov ntsuas.
    ///
    ///
    /// # Kev siv tam sim no
    ///
    /// Qhov tam sim no tus lej ua raws li qhov nrawm nrawm ntawm tib lub nrawm nrawm cuam tshuam siv [`sort_unstable`] X.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics thaum `index >= len()`, lub ntsiab lus nws ib txwm panics ntawm ib qho khoob.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Nrhiav cov khoom nruab nrab
    /// v.select_nth_unstable(2);
    ///
    /// // Peb tsuas yog lav cov nplais yuav yog ib qho hauv qab no, raws li qhov peb txheeb xyuas ntawm cov ntsuas ntsuas.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// Rov kho cov hlais nrog cov kev sib piv ua haujlwm xws li lub ntsiab ntawm `index` yog ntawm nws txoj haujlwm zaum kawg.
    ///
    /// Qhov no reordering muaj ntxiv cov khoom uas tej nqi ntawm txoj hauj lwm `i < index` yuav tsum tsawg tshaj los yog sib npaug rau tej nqi ntawm ib txoj hauj lwm `j > index` siv cov comparator muaj nuj nqi.
    /// Ib qho ntxiv, qhov kev thim rov qab tsis ruaj khov (piv txwv li cov xov tooj ntawm cov sib luag tsis txaus siab yuav mus rau ntawm txoj haujlwm `index`), hauv-chaw (piv txwv li tsis faib), thiab *O*(*n*) qhov tsis zoo.
    /// Txoj haujlwm no tseem paub ua "kth element" hauv lwm lub tsev qiv ntawv.
    /// Nws rov muab cov txiaj ntsig ntawm cov nuj nqis nram qab no: txhua lub ntsiab tsawg dua ib qho ntawm qhov ntsuas, tus nqi ntawm qhov ntsuas, thiab tag nrho cov ntsiab ntau dua ntawm ib qho ntawm qhov ntsuas, siv cov piv txwv muaj nuj nqi.
    ///
    ///
    /// # Kev siv tam sim no
    ///
    /// Qhov tam sim no tus lej ua raws li qhov nrawm nrawm ntawm tib lub nrawm nrawm cuam tshuam siv [`sort_unstable`] X.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics thaum `index >= len()`, lub ntsiab lus nws ib txwm panics ntawm ib qho khoob.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Nrhiav cov khoom nruab nrab zoo li yog hais tias cov hlais tau txheeb hauv cov txheej txheem nqis.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // Peb tsuas yog lav cov nplais yuav yog ib qho hauv qab no, raws li qhov peb txheeb xyuas ntawm cov ntsuas ntsuas.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// Reorder cov hlais nrog qhov tseem ceeb ua kom zoo li lub ntsiab ntawm `index` yog ntawm nws txoj haujlwm zaum kawg.
    ///
    /// Qhov kev rov ua haujlwm no muaj cov cuab yeej ntxiv uas txhua qhov muaj nuj nqis ntawm txoj haujlwm `i < index` yuav tsawg dua lossis sib luag rau ib qho nqi ntawm ib qho chaw `j > index` siv qhov tseem ceeb rho tawm haujlwm.
    /// Ib qho ntxiv, qhov kev thim rov qab tsis ruaj khov (piv txwv li cov xov tooj ntawm cov sib luag tsis txaus siab yuav mus rau ntawm txoj haujlwm `index`), hauv-chaw (piv txwv li tsis faib), thiab *O*(*n*) qhov tsis zoo.
    /// Txoj haujlwm no tseem paub ua "kth element" hauv lwm lub tsev qiv ntawv.
    /// Nws rov muab cov txiaj ntsig ntawm cov nuj nqis nram qab no: txhua lub ntsiab tsawg dua ib qho ntawm qhov ntsuas, tus nqi ntawm qhov ntsuas, thiab tag nrho cov ntsiab ntau dua ntawm ib qho ntawm qhov ntsuas, uas siv txoj haujlwm tseem ceeb muab rho tawm.
    ///
    ///
    /// # Kev siv tam sim no
    ///
    /// Qhov tam sim no tus lej ua raws li qhov nrawm nrawm ntawm tib lub nrawm nrawm cuam tshuam siv [`sort_unstable`] X.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics thaum `index >= len()`, lub ntsiab lus nws ib txwm panics ntawm ib qho khoob.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Rov qab mus rau qhov nruab nrab zoo li yog qhov ntsuas tau txheeb raws li tus nqi kiag li.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // Peb tsuas yog lav cov nplais yuav yog ib qho hauv qab no, raws li qhov peb txheeb xyuas ntawm cov ntsuas ntsuas.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// Tsiv tag nrho cov sib law liag rov hais mus rau thaum xaus ntawm lub hlais raws li lub [`PartialEq`] trait siv.
    ///
    ///
    /// Rov qab ob tsab.Tus thawj tsis muaj cov ncauj lus tsis sib haum.
    /// Qhov thib ob muaj tag nrho cov ntawv luam nyob hauv tsis muaj qhov sau tseg.
    ///
    /// Yog tias cov hlais tau txheeb, thawj cov ntawv xa rov qab tsis muaj qhov tsis muaj duplicates.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// Tsiv tag nrho tab sis thawj zaug ntawm cov ntsiab lus sib law liag mus rau qhov kawg ntawm cov hlais uas txaus siab rau qhov muab kev sib txig sib luag.
    ///
    /// Rov qab ob tsab.Tus thawj tsis muaj cov ncauj lus tsis sib haum.
    /// Qhov thib ob muaj tag nrho cov ntawv luam nyob hauv tsis muaj qhov sau tseg.
    ///
    /// Lub `same_bucket` muaj nuj nqi yog dhau kev xa mus rau ob qho los ntawm cov hlais thiab yuav tsum txiav txim siab yog tias cov khoom sib piv sib npaug.
    /// Cov khoom tau dhau los hauv qhov kev rov ua dhau los ntawm lawv cov kev txiav txim hauv cov hlais, yog li `same_bucket(a, b)` rov `true`, `a` tsiv mus rau tom kawg ntawm cov hlais.
    ///
    ///
    /// Yog tias cov hlais tau txheeb, thawj cov ntawv xa rov qab tsis muaj qhov tsis muaj duplicates.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // Txawm hais tias peb muaj kev hloov pauv tau rau `self`, peb tsis tuaj yeem ua *arbitrary* hloov pauv.Cov `same_bucket` hu tuaj yeem panic, yog li peb yuav tsum xyuas kom meej tias cov hlais yog nyob rau hauv lub xeev siv tau txhua lub sijhawm.
        //
        // Txoj kev uas peb coj qhov no yog los ntawm kev siv sib hloov;peb iterate tshaj tag nrho cov ntsiab, swapping raws li peb mus li tias thaum kawg lub ntsiab peb xav kom muaj nyob rau hauv pem hauv ntej, thiab cov neeg uas peb xav yuav tsis tau txais yog nyob rau tom qab.
        // Peb yuav ces phua lub hlais.
        // Txoj haujlwm no tseem yog `O(n)`.
        //
        // Piv Txwv: Peb pib hauv lub xeev no, qhov twg `r` sawv cev "tom ntej
        // nyeem "thiab `w` sawv cev" next_write`.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // Muab piv rau self[r] tiv thaiv tus kheej [w-1], qhov no tsis yog qhov theej tawm, yog li peb hloov self[r] thiab self[w] (tsis muaj qhov cuam tshuam li r==w) thiab tom qab ntawd nce ntxiv ob qho thiab r, tawm hauv peb nrog:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Muab piv rau self[r] tawm tsam tus kheej [w-1], tus nqi no yog qhov tsis zoo, yog li peb nce `r` tab sis tawm txhua yam ntxiv tsis hloov:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Muab piv rau self[r] tawm tsam nws tus kheej [w-1], qhov no tsis yog qhov theej tawm, yog li sib pauv self[r] thiab self[w] thiab ua ntej r thiab w:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // Tsis yog qhov theej tawm, rov ua:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // Theej tawm, advance r. End ntawm daim.Sib faib ntawm w.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // KEV RUAJ NTSEG: tus mob `while` tuaj yeem lav `next_read` thiab `next_write`
        // yog cov tsawg dua `len`, yog li sab hauv `self`.
        // `prev_ptr_write` taw rau ib qho ua ntej `ptr_write`, tab sis `next_write` pib ntawm 1, yog li `prev_ptr_write` yeej tsis tsawg dua 0 thiab nyob hauv daim hlais.
        // Qhov no ua tiav qhov yuav tsum tau ua rau kev txiav tawm `ptr_read`, `prev_ptr_write` thiab `ptr_write`, thiab rau kev siv `ptr.add(next_read)`, `ptr.add(next_write - 1)` thiab `prev_ptr_write.offset(1)`.
        //
        //
        // `next_write` tseem yog nce ntxiv nyob rau hauv feem ntau ib zaug ib lub voj nyob rau ntawm lub ntsiab lus feem ntau tsis muaj lub ntsiab lus hla thaum nws yuav xav tau pauv.
        //
        // `ptr_read` thiab `prev_ptr_write` yeej tsis taw tes rau tib qho chaw.Qhov no yuav tsum muaj rau `&mut *ptr_read`, `&mut* prev_ptr_write` kom muaj kev nyab xeeb.
        // Cov lus piav qhia tsuas yog hais tias `next_read >= next_write` yog ib txwm muaj tseeb, yog li `next_read > next_write - 1` dhau lawm.
        //
        //
        //
        //
        //
        unsafe {
            // Zam txhob thaiv cov ciam teb los ntawm kev siv cov khoom siv raw.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// Tsiv txhua tus tab sis thawj zaug ntawm cov sib law liag mus rau qhov kawg ntawm cov hlais uas daws rau tib tus yuam sij.
    ///
    ///
    /// Rov qab ob tsab.Tus thawj tsis muaj cov ncauj lus tsis sib haum.
    /// Qhov thib ob muaj tag nrho cov ntawv luam nyob hauv tsis muaj qhov sau tseg.
    ///
    /// Yog tias cov hlais tau txheeb, thawj cov ntawv xa rov qab tsis muaj qhov tsis muaj duplicates.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// Rotates cov hlais-nyob rau hauv-qhov chaw xws li tias thawj `mid` cov ntsiab lus ntawm cov hlais txav mus rau qhov kawg thaum kawg `self.len() - mid` cov ntsiab lus txav mus rau pem hauv ntej.
    /// Tom qab hu rau `rotate_left`, lub caij yav tas los ntawm qhov ua lej `mid` yuav dhau los ua thawj qhov hauv kev hlais.
    ///
    /// # Panics
    ///
    /// Qhov no muaj nuj nqi yuav panic yog `mid` yog ntau tshaj qhov ntev ntawm lub hlais.Nco ntsoov tias `mid == self.len()` puas _not_ panic thiab yog qhov tsis muaj op.
    ///
    /// # Complexity
    ///
    /// Siv sijhawm linear (hauv `self.len()`) sijhawm.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// Tig ib qho subslice:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // KEV RUAJ NTSEG: Qhov ntau yam `[p.add(mid) - mid, p.add(mid) + k)` yog tsis tseem ceeb
        // siv tau rau kev nyeem thiab sau ntawv, raws li `ptr_rotate` xav tau.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Rotates cov hlais-nyob rau hauv-qhov chaw xws li tias thawj `self.len() - k` cov ntsiab lus ntawm cov hlais txav mus rau qhov kawg thaum kawg `k` cov ntsiab lus txav mus rau pem hauv ntej.
    /// Tom qab hu rau `rotate_right`, lub caij yav tas los ntawm qhov ua lej `self.len() - k` yuav dhau los ua thawj qhov hauv kev hlais.
    ///
    /// # Panics
    ///
    /// Muaj nuj nqi no yuav panic yog tias `k` ntau dua qhov ntev ntawm cov hlais.Nco ntsoov tias `k == self.len()` puas _not_ panic thiab yog ib tug tsis muaj-op kev sib hloov.
    ///
    /// # Complexity
    ///
    /// Siv sijhawm linear (hauv `self.len()`) sijhawm.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// Tig subslice:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // KEV RUAJ NTSEG: Qhov ntau yam `[p.add(mid) - mid, p.add(mid) + k)` yog tsis tseem ceeb
        // siv tau rau kev nyeem thiab sau ntawv, raws li `ptr_rotate` xav tau.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Ua tiav `self` nrog cov ntsiab lus los ntawm cloning `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// Fills `self` nrog cov khoom xa rov qab los ntawm kev hu xov tooj kaw ib zaug ntxiv.
    ///
    /// Txoj kev no siv kaw los tsim cov txiaj ntsig tshiab.Yog tias koj xav [`Clone`] qhov muab tus nqi, siv [`fill`].
    /// Yog tias koj xav siv [`Default`] trait los tsim cov nqi, koj tuaj yeem dhau [`Default::default`] li kev sib cav.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// Luam tawm cov ntawv los ntawm `src` rau `self`.
    ///
    /// Qhov ntev ntawm `src` yuav tsum yog tib yam li `self`.
    ///
    /// Yog tias `T` ua raws `Copy`, nws tuaj yeem ua tau ntau dua los siv [`copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Txoj haujlwm no yuav panic yog tias ob lub ncuav nyias nyias nyias ntev.
    ///
    /// # Examples
    ///
    /// Cloning ob qho los ntawm cov hlais rau lwm qhov:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Vim tias cov nplais yuav tsum muaj tib qho ntev, peb muab cov nplais los ntawm plaub lub ntsiab rau ob.
    /// // Nws yuav panic yog tias peb tsis ua qhov no.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust tswj hwm tias tsuas muaj ib qho kev hloov pauv tau uas tsis muaj qhov xa mus tsis tau rau ib qho ntawm cov ntaub ntawv hauv ib qho tshwj xeeb.
    /// Vim tias qhov no, sim siv `clone_from_slice` ntawm cov hlais ib qho yuav ua rau kev sib tw tsis ua haujlwm:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Txhawm rau ua haujlwm nyob ib ncig ntawm no, peb tuaj yeem siv [`split_at_mut`] los tsim ob lub ntsej muag me me sib txawv ntawm ib qho:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// Luam tawm txhua qhov ntawm `src` rau `self`, siv memcpy.
    ///
    /// Qhov ntev ntawm `src` yuav tsum yog tib yam li `self`.
    ///
    /// Yog hais tias `T` tsis siv `Copy`, siv [`clone_from_slice`].
    ///
    /// # Panics
    ///
    /// Txoj haujlwm no yuav panic yog tias ob lub ncuav nyias nyias nyias ntev.
    ///
    /// # Examples
    ///
    /// Luam tawm ob qhov los ntawm cov hlais rau lwm qhov:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Vim tias cov nplais yuav tsum muaj tib qho ntev, peb muab cov nplais los ntawm plaub lub ntsiab rau ob.
    /// // Nws yuav panic yog tias peb tsis ua qhov no.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust tswj hwm tias tsuas muaj ib qho kev hloov pauv tau uas tsis muaj qhov xa mus tsis tau rau ib qho ntawm cov ntaub ntawv hauv ib qho tshwj xeeb.
    /// Vim tias qhov no, sim siv `copy_from_slice` ntawm cov hlais ib qho yuav ua rau kev sib tw tsis ua haujlwm:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Txhawm rau ua haujlwm nyob ib ncig ntawm no, peb tuaj yeem siv [`split_at_mut`] los tsim ob lub ntsej muag me me sib txawv ntawm ib qho:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // Txoj kev panic code tau muab tso rau qhov ua haujlwm txias txias kom tsis txhob bloat hu rau qhov chaw.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // KEV RUAJ NTSEG: `self` siv tau rau `self.len()` cov ntsiab lus los ntawm cov lus txhais, thiab `src` tau
        // soj ntsuam kom muaj tib qho ntev.
        // Cov hlais tuaj yeem tsis sib tshooj vim tias qhov ua tim khawv sib pauv tau tshwj xeeb.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// Luam ntsiab los ntawm ib feem ntawm lub hlais mus rau lwm ib feem ntawm nws tus kheej, siv ib tug memmove.
    ///
    /// `src` yog qhov ntau nyob rau hauv `self` los luam tawm ntawm.
    /// `dest` yog lub pib index ntawm lub ntau tsis pub dhau `self` luam rau, uas yuav muaj cov tib ntev li `src`.
    /// Ob ntu yuav nkag mus tau.
    /// Qhov xaus ntawm ob kab yuav tsum tsawg dua lossis tsawg dua `self.len()`.
    ///
    /// # Panics
    ///
    /// Muaj nuj nqi no yuav panic yog tias muaj ntau yam tshaj qhov kawg ntawm cov hlais, lossis yog tias qhov kawg ntawm `src` yog ua ntej pib.
    ///
    ///
    /// # Examples
    ///
    /// Luam plaub tus lej nyob rau hauv ib daim:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // KEV RUAJ NTSEG: lub tej yam kev mob rau `ptr::copy` tau tag nrho cov tau soj ntsuam saum toj no,
        // raws li cov muaj rau `ptr::add`.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// Swaps tag nrho cov ntsiab hauv `self` nrog cov uas nyob hauv `other`.
    ///
    /// Qhov ntev ntawm `other` yuav tsum yog tib yam li `self`.
    ///
    /// # Panics
    ///
    /// Txoj haujlwm no yuav panic yog tias ob lub ncuav nyias nyias nyias ntev.
    ///
    /// # Example
    ///
    /// Kev sib pauv ob qho thoob ib qho:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust yuam uas yuav tsuas yuav muaj ib tug mutable siv rau ib tug daim ntawm cov ntaub ntawv nyob rau hauv ib tug tau.
    ///
    /// Vim tias qhov no, sim siv `swap_with_slice` ntawm cov hlais ib qho yuav ua rau kev sib tw tsis ua haujlwm:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// Txhawm rau ua haujlwm nyob ib ncig ntawm no, peb tuaj yeem siv [`split_at_mut`] los tsim ob qho kev hloov pauv me me los ntawm cov hlais:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // KEV RUAJ NTSEG: `self` siv tau rau `self.len()` cov ntsiab lus los ntawm cov lus txhais, thiab `src` tau
        // soj ntsuam kom muaj tib qho ntev.
        // Cov hlais tuaj yeem tsis sib tshooj vim tias qhov ua tim khawv sib pauv tau tshwj xeeb.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// Muaj nuj nqi rau xam lengths ntawm nruab nrab thiab trailing hlais rau `align_to{,_mut}`.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // Peb yuav ua dab tsi txog `rest` yog xam dab tsi ntau ntawm `U peb tuaj yeem tso rau hauv tus lej qis ntawm` T`s.
        //
        // Thiab muaj pes tsawg tus `T`s peb xav tau rau txhua qhov "multiple".
        //
        // Xav txog piv txwv T=u8 U=u16.Tom qab ntawd peb yuav muab tso rau 1 U nyob rau hauv 2 Ts.Yooj Yim.
        // Tam sim no, xav txog piv txwv ib rooj plaub uas size_of: :<T>=16, size_of::<U>=24.</u>
        // Peb tuaj yeem tso peb 2 Peb qhov chaw ntawm txhua 3 Ts hauv `rest` cov nplais.
        // Ib me ntsis ntau tham.
        //
        // Cov mis los xam qhov no yog:
        //
        // Us= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // Nthuav thiab yooj yim:
        //
        // Us=size_of: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=size_of::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // Luckily txij li thaum tag nrho cov no yog qhov-soj ntsuam ... kev kawm no tseem ceeb tsis tau!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // iterative stein's algorithm Peb yuav tsum tseem ua qhov `const fn` (thiab thim rov qab rau recursive algorithm yog tias peb ua) vim hais tias cia siab rau llvm rau consteval txhua qhov no yog…zoo, nws ua rau kuv tsis xis nyob.
            //
            //

            // KEV RUAJ NTSEG: `a` thiab `b` raug kuaj xyuas qhov tsis yog-xoom qhov tseem ceeb.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // tshem tawm txhua yam ntawm 2 ntawm b
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // KEV RUAJ NTSEG: `b` raug kuaj xyuas qhov tsis yog-xoom.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // Armed nrog txoj kev paub no, peb yuav nrhiav tau ntau npaum li cas 'U`s peb yuav haum!
        let us_len = self.len() / ts * us;
        // Thiab coob npaum li cas `T` yuav nyob rau hauv cov qhov ib sab!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Transmute lub hlais mus rau ib tug hlais cov lwm hom, kom ntseeg tau kawm tuab si lug ntawm lub hom yog khaws cia.
    ///
    /// Txoj kev no cais cov hlais ua peb qho kev sib txawv: sau ua ntej, muab cov ntawv ncaj qha nruab nrab ntawm cov hom tshiab, thiab cov plaub tom qab.
    /// Cov txheej txheem yuav ua rau qhov nruab nrab hlais qhov ntev tshaj plaws ntev tau rau muab hom thiab cov tswv yim hlais, tab sis tsuas yog koj qhov kev ua haujlwm algorithm yuav tsum yog nyob ntawm qhov ntawd, tsis yog nws qhov tseeb.
    ///
    /// Nws yog tso cai rau tag nrho cov ntaub ntawv tawm tswv yim kom xa rov qab raws li qhov pib ua ntej lossis tom qab hlais.
    ///
    /// Qhov no txoj kev muaj tsis muaj hom phiaj thaum twg los lub tswv yim caij `T` los yog tso zis caij `U` yog zero-sized thiab yuav rov qab mus rau thawj daim tsis splitting dab tsi.
    ///
    /// # Safety
    ///
    /// Qhov qauv no yog qhov tseem ceeb `transmute` nrog kev hwm rau cov khoom hauv nruab nrab xa rov qab nruab nrab, yog li txhua tus neeg niaj zaus tham txog `transmute::<T, U>` tseem siv rau ntawm no.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // Nco ntsoov tias feem ntau ntawm txoj haujlwm no yuav raug ntsuas tas li,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // lis cov ZSTs tshwj xeeb, uas yog-tsis tau tuav lawv txhua lub sijhawm.
            return (self, &[], &[]);
        }

        // Ua ntej, nrhiav ntawm qhov twg taw tes peb cais ntawm cov thawj thiab thib thib hlais.
        // Yooj yim nrog ptr.align_offset.
        let ptr = self.as_ptr();
        // KEV RUAJ NTSEG: Saib `align_to_mut` tus qauv rau cov ncauj lus kom ntxaws kev nyab xeeb.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // KEV RUAJ NTSEG: tam sim no `rest` zoo sib xws, yog li `from_raw_parts` hauv qab no tsis ua li cas,
            // txij li tus neeg hu tuaj lees tias peb tuaj yeem thauj `T` rau `U` yam xyuam xim.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Transmute lub hlais mus rau ib tug hlais cov lwm hom, kom ntseeg tau kawm tuab si lug ntawm lub hom yog khaws cia.
    ///
    /// Txoj kev no cais cov hlais ua peb qho kev sib txawv: sau ua ntej, muab cov ntawv ncaj qha nruab nrab ntawm cov hom tshiab, thiab cov plaub tom qab.
    /// Cov txheej txheem yuav ua rau qhov nruab nrab hlais qhov ntev tshaj plaws ntev tau rau muab hom thiab cov tswv yim hlais, tab sis tsuas yog koj qhov kev ua haujlwm algorithm yuav tsum yog nyob ntawm qhov ntawd, tsis yog nws qhov tseeb.
    ///
    /// Nws yog tso cai rau tag nrho cov ntaub ntawv tawm tswv yim kom xa rov qab raws li qhov pib ua ntej lossis tom qab hlais.
    ///
    /// Qhov no txoj kev muaj tsis muaj hom phiaj thaum twg los lub tswv yim caij `T` los yog tso zis caij `U` yog zero-sized thiab yuav rov qab mus rau thawj daim tsis splitting dab tsi.
    ///
    /// # Safety
    ///
    /// Qhov qauv no yog qhov tseem ceeb `transmute` nrog kev hwm rau cov khoom hauv nruab nrab xa rov qab nruab nrab, yog li txhua tus neeg niaj zaus tham txog `transmute::<T, U>` tseem siv rau ntawm no.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // Nco ntsoov tias feem ntau ntawm txoj haujlwm no yuav raug ntsuas tas li,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // lis cov ZSTs tshwj xeeb, uas yog-tsis tau tuav lawv txhua lub sijhawm.
            return (self, &mut [], &mut []);
        }

        // Ua ntej, nrhiav ntawm qhov twg taw tes peb cais ntawm cov thawj thiab thib thib hlais.
        // Yooj yim nrog ptr.align_offset.
        let ptr = self.as_ptr();
        // TXUJ CI: Ntawm no peb ua kom peb yuav siv cov lus taw qhia rau U rau qhov
        // tus so ntawm txoj kev.Qhov no yog ua los ntawm kev kis tus taw tes rau&[T] nrog kev sib ncag sib luag rau U.
        // `crate::ptr::align_offset` yog hu nrog cov ntawv sau kom raug thiab siv tau tus pointer `ptr` (nws los ntawm kev siv rau `self`) thiab nrog qhov loj me uas yog lub zog ntawm ob (vim nws los ntawm kev sib luag rau U), txaus siab nws txoj kev nyab xeeb.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // Peb tsis tuaj yeem siv `rest` ntxiv tom qab qhov no, uas yuav siv tsis tau nws lub npe `mut_ptr`!KEV RUAJ NTSEG: saib cov lus pom rau `align_to`.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// Tshawb xyuas yog tias cov khoom ntawm no hlais tau txheeb.
    ///
    /// Ntawd yog, rau txhua lub caij `a` thiab nws cov khoom hauv qab no `b`, `a <= b` yuav tsum tuav.Yog hais tias cov hlais yields raws nraim xoom lossis ib lub caij, `true` xa rov qab.
    ///
    /// Nco ntsoov tias yog `Self::Item` tsuas yog `PartialOrd`, tab sis tsis yog `Ord`, cov lus txhais saum toj no txhais tau tias txoj haujlwm no xa rov qab `false` yog tias muaj ob qho khoom sib law liag tsis piv.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// Cov tshev mis yog hais tias tus hais ntawm no hlais yog txheeb siv cov muab comparator muaj nuj nqi.
    ///
    /// Hloov chaw siv `PartialOrd::partial_cmp`, txoj haujlwm no siv `compare` muab kev ua haujlwm los txiav txim siab qhov xaj ntawm ob lub.
    /// Sib nrug los ntawm hais tias, nws yog sib npaug rau [`is_sorted`];saib nws cov ntawv pov thawj rau cov lus qhia ntxiv.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// Tshawb xyuas yog tias cov khoom ntawm cov hlais no tau txheeb xyuas siv cov nuj nqi muab los ua kom yuam kev.
    ///
    /// Hloov chaw piv cov hlais cov ntsiab lus ncaj qha, txoj haujlwm no piv cov yuam sij ntawm cov khoom, raws li tau txiav txim los ntawm `f`.
    /// Sib nrug los ntawm hais tias, nws yog sib npaug rau [`is_sorted`];saib nws cov ntawv pov thawj rau cov lus qhia ntxiv.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// Rov qab xa tawm qhov ntsuas ntawm qhov taw qhia muab faib raws li muab qhia ua ntej (qhov ntsuas ntawm thawj lub ntsiab ntawm qhov muab faib thib ob).
    ///
    /// Daim hlais tau kwv yees tau muab faib raws li txoj cai hais ua ntej.
    /// Qhov no txhais tau tias txhua lub ntsiab lus rau qhov kev kwv yees rov qab muaj tseeb yog thaum pib hlais thiab txhua lub ntsiab lus uas lub zeem muag rov dag yog qhov kawg.
    ///
    /// Piv txwv li, [7, 15, 3, 5, 4, 12, 6] yog ib qho kev faib tawm hauv qhov twv x% 2!=0 (txhua tus lej tsis yog thaum pib, txhua qhov txawm tias tom kawg).
    ///
    /// Yog tias cov nplais no tsis tau muab faib, qhov xa rov qab yog qhov tsis pom zoo thiab tsis muaj qab hau, vim tias hom no ua ib hom kev tshawb nrhiav binary.
    ///
    /// Xyuas [`binary_search`], [`binary_search_by`], thiab [`binary_search_by_key`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // KEV RUAJ NTSEG: Thaum `left < right`, `left <= mid < right`.
            // Yog li ntawd `left` ib txwm nce thiab `right` ib txwm tsawg zuj zus, thiab ob qho ntawm lawv yuav raug xaiv.Nyob rau hauv ob leeg `left <= right` yog txaus siab.Yog li ntawd yog tias `left < right` hauv ib kauj ruam, `left <= right` txaus siab rau kauj ruam tom ntej.
            //
            // Yog li ntawd ntev li `left != right`, `0 <= left < right <= len` txaus siab thiab yog tias cov ntaub ntawv no `0 <= mid < len` txaus siab dhau.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: Peb yuav tsum ntsees hlais lawv mus rau lub tib ntev
        // kom nws yooj yim dua rau lub optimizer rau elide ciam teb kuaj.
        // Tab sis vim nws tsis tuaj yeem cia siab rau peb kuj tseem muaj qhov tshwj xeeb tshwj xeeb rau T: Luam Ntawv.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// Tsim ib qho npliag.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// Tsim ib qho kev hlais ib hloov pauv tau.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// Cov qauv hauv cov hlov, tam sim no, tsuas yog siv los ntawm `strip_prefix` thiab `strip_suffix`.
/// Nyob rau ib lub future point, peb cia siab tias yuav generalize `core::str::Pattern` (uas nyob rau lub sij hawm ntawm kev sau ntawv yog tas rau `str`) rau slices, thiab ces qhov no trait yuav tau los hloov los yog poob mus li.
///
pub trait SlicePattern {
    /// Lub caij hom ntawm cov hlais tau sib phim.
    type Item;

    /// Tam sim no, tau txais kev pab ntawm `SlicePattern` xav tau ib tug hlais.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}