//! Cov haujlwm pub dawb los tsim `&[T]` thiab `&mut [T]`.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Ua cov ntawv txiav los ntawm ntxig thiab ntev.
///
/// Lub `len` sib cav yog lub xov tooj ntawm **ntsiab**, tsis yog tus naj npawb ntawm cov bytes.
///
/// # Safety
///
/// Tus cwj pwm yog undefined yog ib yam ntawm cov nram qab no tej yam kev mob yog ua txhaum:
///
/// * `data` yuav tsum yog [valid] rau kev nyeem rau `len * mem::size_of::<T>()` ntau bytes, thiab nws yuav tsum tau ua kom zoo mus ibyam.Qhov no txhais tau rau hauv kev:
///
///     * Tag nrho cov cim xeeb ntau ntawm cov hlais no yuav tsum muaj nyob hauv ib tus kwv yees nkaus xwb!
///       Slices yuav tsis saib ntsoov txog hla ntau faib khoom.Saib [below](#incorrect-usage) rau qhov piv txwv tsis raug tsis coj ua qhov no.
///     * `data` yuav tsum tsis yog-thov thiab raws li txawm rau xoom-ntev slices.
///     Ib qho laj thawj rau qhov no yog hais tias enum layout kev xaiv kom zoo dua yuav cia siab rau cov neeg ua tim khawv (suav nrog hlov ib qho twg ntev) tau sib txig thiab tsis yog-cais rau qhov txawv lawv los ntawm lwm cov ntaub ntawv.
///     Koj tuaj yeem muab cov pointer uas siv tau xws li `data` rau xoom qhov ntev ntev siv [`NonNull::dangling()`].
///
/// * `data` yuav tsum taw rau `len` sib law liag kom pib qhov tseem ceeb ntawm hom `T`.
///
/// * Lub cim xeeb los ntawm daim ntawv xa rov qab yuav tsum tsis txhob sib tham rau lub sijhawm ntawm lub neej `'a`, tshwj tsis yog sab hauv `UnsafeCell`.
///
/// * Tag nrho qhov loj me `len * mem::size_of::<T>()` ntawm cov hlais yuav tsum tsis loj tshaj `isize::MAX`.
///   Saib cov ntaub ntawv kev nyab xeeb ntawm [`pointer::offset`].
///
/// # Caveat
///
/// Lub neej rau kev xa rov qab yog inferred los ntawm nws txoj kev siv.
/// Yuav kom tiv thaiv txhob txwm siv tsis raws cai, nws yog tswv yim mus rau khi lub neej rau qhov twg qhov twg los lub neej muaj kev ruaj ntseg nyob rau hauv cov ntsiab lus teb, xws li los ntawm kev muab ib tug pab muaj nuj nqi noj hauv lub neej ntawm ib tug tswv tsev tus nqi rau cov hlais, los yog los ntawm qhia tau meej heev annotation.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // qhia ib nplais ntawv rau ib qho kev kawm
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Kev siv tsis raug
///
/// Cov haujlwm `join_slices` hauv qab no yog **tsis zoo** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // Lub assertion saum toj no kom `fst` thiab `snd` yog contiguous, tab sis lawv yuav tseem yuav muaj nyob hauv _different allocated objects_, nyob rau hauv uas cov ntaub ntawv tsim no hlais yog undefined tus cwj pwm.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` thiab `b` yog cov khoom siv sib txawv ...
///     let a = 42;
///     let b = 27;
///     // ... uas tej zaum yuav cuaj kaum yuav pw tawm contiguously nyob rau hauv lub cim xeeb: |a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // KEV RUAJ NTSEG: tus neeg hu yuav tsum khaws daim ntawv cog lus muaj kev nyab xeeb rau `from_raw_parts`.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Ua tib lub luag haujlwm ib yam li [`from_raw_parts`], tshwj tsis yog tias ib qho kev sib pauv hloov tau rov qab.
///
/// # Safety
///
/// Tus cwj pwm yog undefined yog ib yam ntawm cov nram qab no tej yam kev mob yog ua txhaum:
///
/// * `data` yuav tsum yog [valid] rau ob qho nyeem thiab sau rau `len * mem::size_of::<T>()` ntau lub bytes, thiab nws yuav tsum raug ua kom zoo mus rau.Qhov no txhais tau rau hauv kev:
///
///     * Tag nrho cov cim xeeb ntau ntawm cov hlais no yuav tsum muaj nyob hauv ib tus kwv yees nkaus xwb!
///       Cov qib qis tsis tuaj yeem hla rau ntau cov khoom sib cais.
///     * `data` yuav tsum tsis yog-thov thiab raws li txawm rau xoom-ntev slices.
///     Ib qho laj thawj rau qhov no yog hais tias enum layout kev xaiv kom zoo dua yuav cia siab rau cov neeg ua tim khawv (suav nrog hlov ib qho twg ntev) tau sib txig thiab tsis yog-cais rau qhov txawv lawv los ntawm lwm cov ntaub ntawv.
///
///     Koj tuaj yeem muab cov pointer uas siv tau xws li `data` rau xoom qhov ntev ntev siv [`NonNull::dangling()`].
///
/// * `data` yuav tsum taw rau `len` sib law liag kom pib qhov tseem ceeb ntawm hom `T`.
///
/// * Lub cim xeeb hais txog los ntawm cov xa rov qab yuav tsum tsis txhob nkag los ntawm lwm lub pointer (tsis yog muab los ntawm tus nqi xa rov qab) rau lub sijhawm ntawm lub neej `'a`.
///   Ob qho tib si nyeem thiab sau ntawv nkag tau raug txwv.
///
/// * Tag nrho qhov loj me `len * mem::size_of::<T>()` ntawm cov hlais yuav tsum tsis loj tshaj `isize::MAX`.
///   Saib cov ntaub ntawv kev nyab xeeb ntawm [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // KEV RUAJ NTSEG: tus neeg hu yuav tsum khaws daim ntawv cog lus muaj kev nyab xeeb rau `from_raw_parts_mut`.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Hloov tus siv rau T rau hauv cov hlais qhov ntev 1 (yam tsis muaj luam).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Hloov tus siv rau T rau hauv cov hlais qhov ntev 1 (yam tsis muaj luam).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}