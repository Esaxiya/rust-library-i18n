//! Kev khiav haujlwm ntawm ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Cov tshev yog tias tag nrho cov bytes hauv daim hlais no nyob hauv ASCII ntau.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Cov tshev mis uas ob slices yog ib tug ASCII cov ntaub ntawv-insensitive match.
    ///
    /// Tib yam li `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, tab sis tsis muaj kev faib tawm thiab cov ntawv sau tseg ntawm lub ntsej muag.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Converts no hlais rau nws ASCII sab sauv cov ntaub ntawv sib npaug nyob rau hauv-qhov chaw.
    ///
    /// ASCII cov ntawv 'a' rau 'z' yog mapped rau 'A' rau 'Z', tab sis cov tsiaj ntawv tsis-ASCII tsis hloov pauv.
    ///
    /// Txhawm rau rov qab tus nqi tshiab uas tsis hloov pauv yam uas twb muaj lawm, siv [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Hloov siab cov nplais no rau nws ASCII cov ntaub ntawv qis dua sib npaug hauv-chaw.
    ///
    /// ASCII cov ntawv 'A' rau 'Z' yog mapped rau 'a' rau 'z', tab sis cov tsiaj ntawv tsis-ASCII tsis hloov pauv.
    ///
    /// Txhawm rau rov qab tus nqi qis qis dua yam tsis muaj kev hloov kho rau ib tus uas twb muaj lawm, siv [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Rov qab `true` yog tias muaj byte hauv lo lus `v` yog nonascii (>=128).
/// Snarfed los ntawm `../str/mod.rs`, uas ua tej yam zoo sib xws rau utf8 kev siv tau.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Optimized ASCII xeem uas yuav siv kev ua haujlwm usize-ntawm-ib-sijhawm ua haujlwm es tsis yog byte-ntawm-lub sijhawm ua haujlwm (thaum ua tau).
///
/// Lub algorithm peb siv ntawm no yog qhov yooj yim zoo nkauj.Yog tias `s` luv heev, peb tsuas yog khij txhua byte thiab ua tiav nrog nws.Txwv tsis pub:
///
/// - Nyeem thawj lo lus nrog xas unaligned.
/// - Dlhos cov pointer, nyeem cov lus txuas txuas ntxiv kom txog rau thaum xaus nrog cov khoom sib dhos.
/// - Nyeem tus `usize` kawg ntawm `s` nrog kev thauj khoom tsis txaus.
///
/// Yog tias ib qho twg ntawm cov nraub qaum ua rau qee yam rau `contains_nonascii` (above) rov qab los muaj tseeb, ces peb paub cov lus teb tsis muaj tseeb.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Yog tias peb yuav tsis tau dab tsi los ntawm kev siv lus-ntawm-ib-lub sijhawm, poob rov qab rau lub voj voos plav.
    //
    // Peb kuj ua qhov no rau architectures qhov twg `size_of::<usize>()` tsis zoo txaus rau `usize`, vim tias nws yog rooj plaub edge txawv.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Peb ib txwm nyeem thawj lo lus unaligned, uas txhais tau tias `align_offset` yog
    // 0, peb yuav nyeem tus nqi qub dua rau cov ntawv uas nyeem ua ntej.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // KEV RUAJ NTSEG: Peb paub tseeb `len < USIZE_SIZE` saum toj no.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Peb tau tshawb xyuas qhov saum toj no, qee qhov cuam tshuam.
    // Nco ntsoov tias `offset_to_aligned` yog `align_offset` lossis `USIZE_SIZE`, ob qho tib si tau tshawb xyuas meej meej saum toj no.
    //
    debug_assert!(offset_to_aligned <= len);

    // KEV RUAJ NTSEG: word_ptr yog qhov (haum raws li) usize ptr peb siv los nyeem cov
    // nruab nrab chunk ntawm hlais.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` yog byte Performance index ntawm `word_ptr`, siv rau lub voj kawg cov tshev.
    let mut byte_pos = offset_to_aligned;

    // Paranoia xyuas txog kev ua haujlwm sib dhos, txij li peb yuav ua ib lub nra ntawm kev thauj khoom tsis sib luag.
    // Hauv kev coj ua qhov no yuav tsis yooj yim sua kev txwv tsis pub muaj qhov tsis txaus nyob hauv `align_offset` txawm tias.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Nyeem cov lus txuas ntxiv mus kom txog rau lo lus txuas kawg, tsis suav nrog lo lus kawg ntawm nws tus kheej los ua kom tus tw tom qab, kom ntseeg tau tias tus Tsov tus tw yeej ib txwm yog `usize` nyob rau feem ntau rau ntxiv branch `byte_pos == len`.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Kev kuaj qhov tseeb tias qhov nyeem ntawv tsis muaj qhov twg
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // Thiab tias peb cov kev xav txog `byte_pos` tuav.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // KEV RUAJ NTSEG: Peb paub `word_ptr` zoo raws li cov ntsiab lus (vim hais tias ntawm
        // `align_offset`), thiab peb paub tias peb muaj bytes txaus ntawm `word_ptr` thiab kawg
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // TXUJ CI: Peb paub tias `byte_pos <= len - USIZE_SIZE`, uas txhais tau tias
        // tom qab no `add`, `word_ptr` yuav yog nyob rau ntau qhov-kawg-kawg-kawg.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Kev kuaj kom pom tseeb tias muaj tiag tsuas muaj ib qho `usize` sab laug.
    // Qhov no yuav tsum tau lav los ntawm peb lub voj voos.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // KEV RUAJ NTSEG: Qhov no tso siab rau `len >= USIZE_SIZE`, uas peb kuaj thaum pib.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}