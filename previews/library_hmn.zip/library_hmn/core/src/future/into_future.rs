use crate::future::Future;

/// Hloov mus ua ib tus `Future`.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// Cov khoom lag luam uas future yuav tsim tawm ntawm qhov kev ua tiav.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// Hom future twg yog peb hloov qhov no mus?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// Tsim ib tug future los ntawm ib tug nqi.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}