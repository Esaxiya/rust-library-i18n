#![stable(feature = "futures_api", since = "1.36.0")]

//! Asynchronous qhov tseem ceeb.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// Qhov no hom uas yuav tsum tau vim hais tias:
///
/// a) Cov tshuab hluav taws xob tsis tuaj yeem siv `for<'a, 'b> Generator<&'a mut Context<'b>>`, yog li peb xav kom dhau cov pointer nyoos (saib <https://github.com/rust-lang/rust/issues/68923>).
///
/// b) Cov taw tes nyoos thiab `NonNull` tsis yog `Send` lossis `Sync`, yog li uas yuav ua rau txhua tus future non-Send/Sync zoo li, thiab peb tsis xav tau ntawd.
///
/// Nws kuj simplifies hir txos ntawm `.await`.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Qhwv lub tshuab hluav taws xob hauv future.
///
/// Qhov no muaj nuj nqi rov ib `GenFuture` qab, tab sis hides nyob rau hauv `impl Trait` muab zoo dua kev ua yuam kev lus (`impl Future` es `GenFuture<[closure.....]>`).
///
// Qhov no yog `const` kom tsis txhob muaj qhov yuam kev ntxiv tom qab peb rov qab los ntawm `const async fn`
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // Peb cia siab rau qhov tseeb hais tias async/await futures yog nyob khov kho nyob rau hauv thiaj li yuav tsim nws tus kheej-referential borrows nyob rau hauv lub qhov pib generator.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // KEV RUAJ NTSEG: Kev nyab xeeb vim tias peb nyob nraum !Unpin + !Drop, thiab qhov no tsuas yog ua kom pom daim teb.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // Rov qab siv lub tshuab hluav taws xob, tig lub `&mut Context` mus rau `NonNull` lub pointer nyoos.
            // `.await` txo qis yuav nyab nrum ntawd rov mus rau `&mut Context`.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // KEV RUAJ NTSEG: tus hu yuav tsum lav tias `cx.0` yog lub pointer siv tau
    // uas fulfills tag nrho cov uas yuav tsum tau rau ib tug mutable siv.
    unsafe { &mut *cx.0.as_ptr().cast() }
}