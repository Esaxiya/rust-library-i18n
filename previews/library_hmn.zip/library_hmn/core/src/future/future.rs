#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// A future sawv cev rau kev suav ua lej.
///
/// A future yog ib qhov muaj nuj nqis uas tej zaum tsis tau ua tiav kev suav tseem.
/// Qhov no zoo ntawm "asynchronous value" ua rau nws ua tau rau ib tug xov mus ntxiv ua pab ua hauj lwm thaum nws waits rau cov nqi los kuj muaj.
///
///
/// # `poll` txujci
///
/// Cov qauv tseem ceeb ntawm future, `poll`,*sim* los daws cov future rau tus nqi kawg.
/// Qhov no txoj kev tsis thaiv hais tias tus nqi yog tsis npaj txhij.
/// Hloov chaw, lub luag haujlwm tam sim no tau teem tseg los tsim lub siab thaum nws muaj peev xwm ua kom muaj kev vam meej ntxiv los ntawm 'kev xaiv tsa' dua.
/// Lub `context` kis mus rau cov `poll` txoj kev yuav muab tau ib tug [`Waker`], uas yog ib tug kov rau waking tam sim no ua hauj lwm.
///
/// Thaum siv ib future, koj feem ntau yuav tsis hu `poll` ncaj qha, tab sis es tsis txhob `.await` tus nqi.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Lub hom ntawm tus nqi ua rau tiav.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Sim daws qhov future mus rau ib tug thaum kawg tus nqi, sau npe tam sim no ua hauj lwm rau wakeup hais tias tus nqi yog tsis tau muaj.
    ///
    /// # Rov qab tus nqi
    ///
    /// Muaj nuj nqi no rov:
    ///
    /// - [`Poll::Pending`] yog hais tias tus future yog tsis npaj txhij tsis tau
    /// - [`Poll::Ready(val)`] nrog rau cov txiaj ntsig `val` ntawm no future yog tias nws ua tiav zoo.
    ///
    /// Thaum future tiav lawm, cov neeg yuav tsum tsis txhob `poll` nws dua.
    ///
    /// Thaum future tseem tsis tau npaj txhij, `poll` rov `Poll::Pending` thiab khaws cov clone ntawm [`Waker`] theej los ntawm [`Context`] tam sim no.
    /// Qhov [`Waker`] no ces woken ib zaug future tuaj yeem ua kev txhim kho.
    /// Piv txwv li, future tos lub ntsaws qhov muag kom nyeem tau tuaj yeem hu `.clone()` ntawm [`Waker`] thiab khaws nws.
    /// Thaum ib lub teeb liab tuaj txog rau lwm qhov chaw qhia tias lub nplos yog tshwmsim, [`Waker::wake`] yog hu ua thiab lub nplos future txoj hauj lwm yog awoken.
    /// Thaum ib txoj hauj lwm tau sawv, nws yuav tsum sim `poll` lub future dua, uas yuav yog lossis tsis tsim lub txiaj ntsig zaum kawg.
    ///
    /// Nco ntsoov tias nyob rau hauv ntau yam hu xov tooj rau `poll`, tsuas yog tus [`Waker`] los ntawm cov [`Context`] dhau mus rau feem ntau tsis ntev los no hu yuav tsum tau teem kom tau txais ib wakeup.
    ///
    /// # Runtime cov yam ntxwv
    ///
    /// Futures ib leeg yog *inert*;lawv yuav tsum tau *nquag*'poll`ed ua tau zoo, lub ntsiab lus uas txhua lub sij hawm tam sim no ua hauj lwm yog woken, nws yuav tsum muaj kev koom re-`poll` tos futures hais tias nws tseem muaj ib qho kev txaus nyob rau hauv.
    ///
    /// Lub `poll` muaj nuj nqi yog tsis hu ua dua nyob rau hauv ib tug ceev voj-es tsis txhob, nws yuav tsum tsuas yog hu ua thaum lub future ntawd hais tias nws yog npaj txhij mus ua kev kawm (los ntawm kev hu mus rau `wake()`).
    /// Yog tias koj paub nrog `poll(2)` lossis `select(2)` syscalls ntawm Unix nws tsim nyog pom tias futures feem ntau ua *tsis* raug teeb meem tib yam ntawm "all wakeups must poll all events";lawv yog cov zoo li `epoll(4)`.
    ///
    /// Ib tug siv ntawm `poll` yuav tsum siv zog kom rov qab mus sai sai, thiab yuav tsum tsis txhob thaiv.Rov qab los sai sai tiv thaiv qhov tsis tsim nyog txhaws ntawm xov lossis cov loops.
    /// Yog hais tias nws yog lub npe hu ua ntej ntawm lub sij hawm uas ib tug hu rau `poll` tej zaum yuav mus noj ib chim, lub chaw ua hauj lwm yuav tsum tau offloaded mus rau ib tug xov pas dej ua ke (los yog ib yam dab tsi uas zoo sib xws) kom paub meej tias `poll` yuav tau rov qab sai sai.
    ///
    /// # Panics
    ///
    /// Thaum ib tug future tau ua kom tiav (xa rov qab `Ready` los ntawm `poll`), hu nws `poll` txoj kev dua yuav panic, thaiv mus ib txhis, los yog ua lwm yam teeb meem;lub `Future` trait muab tsis yuav tsum tau ntawm cov teebmeem ntawm xws li ib tug hu.
    /// Txawm li cas los xij, raws li `poll` txoj kev tsis cim `unsafe`, Rust cov kev cai ib txwm siv: kev hu yuav tsum tsis txhob ua qhov tsis muaj kev coj cwj pwm (kev nco tsis ncaj, kev siv tsis tau `unsafe` lub zog, lossis cov zoo li), tsis hais future lub xeev.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}