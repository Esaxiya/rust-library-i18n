//! Ximxoo pauv hloov.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// Converts ib `u32` mus rau ib tug `char`.
///
/// Nco ntsoov tias txhua [`char`] yog siv tau [`u32`], thiab tuaj yeem pov rau ib tus
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Txawm li cas los, qhov rov qab yog tsis muaj tseeb: tsis yog txhua txhua siv tau ['u32`] s yog siv tau [' char`] s.
/// `from_u32()` yuav rov qab `None` yog lub tswv yim tsis yog ib tug siv tau muaj nuj nqis rau ib tug [`char`].
///
/// Txog qhov tsis nyab xeeb ntawm lub luag haujlwm no uas tsis quav ntsej cov tshev no, saib [`from_u32_unchecked`].
///
///
/// # Examples
///
/// Kev siv theem pib:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// Rov qab `None` thaum lub tswv yim tsis yog ib tug siv tau [`char`]:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// Hloov tus `u32` rau `char` X, tsis quav ntsej txog kev siv tau.
///
/// Nco ntsoov tias txhua [`char`] yog siv tau [`u32`], thiab tuaj yeem pov rau ib tus
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Txawm li cas los, qhov rov qab yog tsis muaj tseeb: tsis yog txhua txhua siv tau ['u32`] s yog siv tau [' char`] s.
/// `from_u32_unchecked()` yuav las mees no, thiab blindly nrum [`char`], tejzaum nws tsim ib tug tsis tseeb ib.
///
///
/// # Safety
///
/// Txoj haujlwm no tsis zoo, raws li nws yuav tsim `char` X tsis muaj nuj nqis.
///
/// Rau ib kev ruaj ntseg version ntawm no muaj nuj nqi, saib [`from_u32`] muaj nuj nqi.
///
/// # Examples
///
/// Kev siv theem pib:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // KEV RUAJ NTSEG: tus neeg hu yuav tsum lees tias `i` yog ib tug siv tau char nqi.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// Converts ib [`char`] rau hauv ib lub [`u32`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// Converts ib [`char`] rau hauv ib lub [`u64`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Lub char yog pov rau tus nqi ntawm txoj cai taw tes, tom qab ntawd xoom-txuas ntxiv mus rau 64 ntsis.
        // Saib [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// Converts ib [`char`] rau hauv ib lub [`u128`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Lub char yog casted rau tus nqi ntawm cov code taw tes, ces zero-ncua rau 128 ntsis.
        // Saib [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u128
    }
}

/// Cov pev ib daim byte hauv 0x00 ..=0xFF mus rau `char` nws qhov code taw qhia muaj tib tus nqi, hauv U + 0000 ..=U + 00FF.
///
/// Unicode yog tsim los ntawm qhov no zoo txiav suab ntawm tus lej cim nrog IAA hu rau ISO-8859-1.
/// Qhov encoding no tau tshaj ASCII.
///
/// Nco ntsoov tias qhov no txawv ntawm ISO/IEC 8859-1 aka
/// ISO 8859-1 (nrog rau ib qho hyphen tsawg dua), uas tawm qee "blanks", byte qhov tseem ceeb uas tsis tau muab rau ib qho cim.
/// ISO-8859-1 (IANA ib) muab lawv rau C0 thiab C1 tswj cov cai.
///
/// Nco ntsoov tias qhov no yog *kuj* sib txawv los ntawm lub qhov rais-1252 aka
/// code page 1252, uas yog ib tug superset ISO/IEC 8859-1 uas assigns ib co (tsis yog txhua txhua!) teb rau cov cim thiab ntau yam Latin cim.
///
/// Txhawm rau kom tsis meej lwm yam ntxiv, [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1`, thiab `windows-1252` yog txhua lub npe rau cov neeg siv ntawm Windows-1252 uas sau cov seem tsis tseem tshuav nrog cov C0 thiab C1 tswj cov lis dej num.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// Converts ib [`u8`] rau hauv ib lub [`char`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// Kev ua yuam kev uas tuaj yeem xa rov qab thaum faib ib qho char.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // KEV RUAJ NTSEG: kuaj xyuas tias nws raug nqi unicode raws cai
            Ok(unsafe { transmute(i) })
        }
    }
}

/// Qhov yuam kev hom rov qab thaum qhov kev hloov dua siab tshiab ntawm u32 los hloov tsis tau.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// Hloov tus lej nyob rau hauv xov tooj muab rau ib tug `char`.
///
/// Ib tug 'radix' ntawm no qee zaum kuj hu ua 'base'.
/// Ib lub voj voos ntawm ob qhia txog tus naj npawb binary, ib lub voos kaum ntawm kaum, kaum, thiab ib feem kaum ntawm kaum rau, hexadecimal, muab qee qhov tseem ceeb.
///
/// Arbitrary radices yog txaus siab.
///
/// `from_digit()` yuav rov `None` yog hais tias lub tswv yim tsis yog tus lej hauv cov kab rov tav.
///
/// # Panics
///
/// Panics yog tias muab cov duab hluav taws xob loj dua 36.
///
/// # Examples
///
/// Kev siv theem pib:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // Zauv 11 yog ib tug hluas tug lej nyob rau hauv lub hauv paus 16
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// Rov qab `None` thaum lub tswv yim tsis yog ib tug lej:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// Dhau lub vojvoog loj, ua rau panic:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}