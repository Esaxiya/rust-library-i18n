//! impl char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// Cov cai siv tau ntau tshaj yog ib tus `char` tuaj yeem muaj.
    ///
    /// Ib tug `char` yog ib tug [Unicode Scalar Value], uas txhais tau hais tias nws yog ib tug [Code Point], tiam sis tsuas yog sawv daws yuav nyob rau hauv ib yam ntau.
    /// `MAX` yog lub siab tshaj plaws uas siv tau code point uas yog ib tug siv tau [Unicode Scalar Value].
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () yog siv nyob rau hauv Unicode los sawv cev rau ib tug seev suab yuam kev.
    ///
    /// Nws yuav tshwm sim, piv txwv li, thaum muab mob-tsim UTF-8 bytes rau [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy).
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// Cov version ntawm [Unicode](http://www.unicode.org/) hais tias cov Unicode qhov chaw ntawm `char` thiab `str` txoj kev yog raws li nyob rau hauv.
    ///
    /// Cov khoos phib tawj tshiab ntawm Unicode raug tso tawm tsis tu ncua thiab tom qab txhua txoj hauv phau ntawv qiv nyob ntawm tus qauv siv Unicode yuav hloov kho.
    /// Yog li no tus cwj pwm ntawm qee tus txheej txheem `char` thiab `str` thiab tus nqi ntawm qhov hloov pauv tsis tu ncua thaum lub sijhawm.
    /// Qhov no *tsis* raug suav tias yog kev hloov pauv.
    ///
    /// Cov version numbering tswvyim yog piav nyob rau hauv [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// Tsim cov ntsuas hluav taws xob tshaj UTF-16 qhov chaws cim cov ntsiab lus hauv `iter`, rov qab cov neeg tsis ua haujlwm surrogates li `Err`s.
    ///
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// Ib tug lossy decoder yuav tau ua los ntawm hloov `Err` tau nrog cov kev hloov tus cwj pwm:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// Converts ib `u32` mus rau ib tug `char`.
    ///
    /// Nco ntsoov tias txhua tus 'char`s siv tau [`u32`] s, thiab tuaj yeem muab pov rau ib tus
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Txawm li cas los xij, qhov rov qab tsis yog qhov tseeb: tsis yog txhua txoj siv tau [`u32`] yog qhov siv tau 'char'.
    /// `from_u32()` yuav rov qab `None` yog lub tswv yim tsis yog ib tug siv tau muaj nuj nqis rau ib tug `char`.
    ///
    /// Txog qhov tsis nyab xeeb ntawm lub luag haujlwm no uas tsis quav ntsej cov tshev no, saib [`from_u32_unchecked`].
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// Rov qab `None` thaum lub tswv yim tsis yog ib tug siv tau `char`:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// Hloov tus `u32` rau `char` X, tsis quav ntsej txog kev siv tau.
    ///
    /// Nco ntsoov tias txhua tus 'char`s siv tau [`u32`] s, thiab tuaj yeem muab pov rau ib tus
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Txawm li cas los xij, qhov rov qab tsis yog qhov tseeb: tsis yog txhua txoj siv tau [`u32`] yog qhov siv tau 'char'.
    /// `from_u32_unchecked()` yuav tsis quav ntsej qhov no, thiab dig muag mus rau `char`, tejzaum nws tsim qhov tsis raug.
    ///
    ///
    /// # Safety
    ///
    /// Txoj haujlwm no tsis zoo, raws li nws yuav tsim `char` X tsis muaj nuj nqis.
    ///
    /// Rau ib kev ruaj ntseg version ntawm no muaj nuj nqi, saib [`from_u32`] muaj nuj nqi.
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // KEV RUAJ NTSEG: kev ruaj ntseg daim ntawv cog lus yuav tsum tau upheld los ntawm ib tus neeg hu.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Hloov tus lej nyob rau hauv xov tooj muab rau ib tug `char`.
    ///
    /// Ib tug 'radix' ntawm no qee zaum kuj hu ua 'base'.
    /// Ib lub voj voos ntawm ob qhia txog tus naj npawb binary, ib lub voos kaum ntawm kaum, kaum, thiab ib feem kaum ntawm kaum rau, hexadecimal, muab qee qhov tseem ceeb.
    ///
    /// Arbitrary radices yog txaus siab.
    ///
    /// `from_digit()` yuav rov `None` yog hais tias lub tswv yim tsis yog tus lej hauv cov kab rov tav.
    ///
    /// # Panics
    ///
    /// Panics yog tias muab cov duab hluav taws xob loj dua 36.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // Zauv 11 yog ib tug hluas tug lej nyob rau hauv lub hauv paus 16
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// Rov qab `None` thaum lub tswv yim tsis yog ib tug lej:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// Dhau lub vojvoog loj, ua rau panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// Tshawb xyuas yog tias `char` yog tus lej hauv lub vojvoog muab rau.
    ///
    /// Ib tug 'radix' ntawm no qee zaum kuj hu ua 'base'.
    /// Ib lub voj voos ntawm ob qhia txog tus naj npawb binary, ib lub voos kaum ntawm kaum, kaum, thiab ib feem kaum ntawm kaum rau, hexadecimal, muab qee qhov tseem ceeb.
    ///
    /// Arbitrary radices yog txaus siab.
    ///
    /// Piv rau [`is_numeric()`], qhov no muaj nuj nqi tsuas paub lub cim `0-9`, `a-z` thiab `A-Z`.
    ///
    /// 'Digit' yog txhais tau tias tsuas yog cov cim hauv qab no:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// Txhawm rau kev nkag siab ntau ntxiv ntawm 'digit', saib [`is_numeric()`].
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics yog tias muab cov duab hluav taws xob loj dua 36.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// Dhau lub vojvoog loj, ua rau panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// Converts ib `char` mus rau ib tug lej nyob rau hauv qhov muab Radix.
    ///
    /// Ib tug 'radix' ntawm no qee zaum kuj hu ua 'base'.
    /// Ib lub voj voos ntawm ob qhia txog tus naj npawb binary, ib lub voos kaum ntawm kaum, kaum, thiab ib feem kaum ntawm kaum rau, hexadecimal, muab qee qhov tseem ceeb.
    ///
    /// Arbitrary radices yog txaus siab.
    ///
    /// 'Digit' yog txhais tau tias tsuas yog cov cim hauv qab no:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Rov `None` yog hais tias tus `char` tsis xa mus rau ib tug lej nyob rau hauv qhov muab Radix.
    ///
    /// # Panics
    ///
    /// Panics yog tias muab cov duab hluav taws xob loj dua 36.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Dhau qhov uas tsis yog tus lej nyob rau qhov tsis ua haujlwm:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// Dhau lub vojvoog loj, ua rau panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // lub code yog phua li no mus txhim kho tiav ceev rau mob qhov twg `radix` yog qhov thiab 10 los yog me me
        //
        let val = if likely(radix <= 10) {
            // Yog tias tsis yog tus lej, yuav muaj tus lej ntau dua radix yuav raug tsim.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Rov qab los ib iterator uas yields cov hexadecimal Unicode khiav ntawm cov ua cim raws li 'char`s.
    ///
    /// Qhov no yuav khiav cov cim nrog Rust syntax ntawm daim ntawv `\u{NNNNNN}` qhov twg `NNNNNN` yog cov sawv cev hexadecimal.
    ///
    ///
    /// # Examples
    ///
    /// Raws li ib tug iterator:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Siv `println!` ncaj qha:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Ob qho tib si sib npaug rau:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// Siv `to_string`:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // los yog-ing 1 Saib kuas meej kuas uas rau c==0 cov code computes hais tias ib tug lej yuav tsum tau sau thiab (uas yog tib yam) txhob (31, 32) underflow
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // qhov ntsuas ntawm cov lej tseem ceeb hex
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// Ib qho txuas ntawm `escape_debug` uas xaiv tau tso cai kom khiav Dhau ntawm Grapheme codepoints.
    /// Qhov no tso cai rau peb format cim zoo li nonspacing tias zoo dua thaum lawv nyob nraum thaum pib ntawm ib txoj hlua.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Xa rov qab ib qho iterator uas yields txoj kev khiav dim txoj cai ntawm lub cim zoo li `char`s.
    ///
    /// Qhov no yuav khiav lub cim zoo ib yam li lub `Debug` implementations ntawm `str` los yog `char`.
    ///
    ///
    /// # Examples
    ///
    /// Raws li ib tug iterator:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Siv `println!` ncaj qha:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Ob qho tib si sib npaug rau:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// Siv `to_string`:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Xa rov qab ib qho iterator uas yields txoj kev khiav dim txoj cai ntawm lub cim zoo li `char`s.
    ///
    /// Lub neej ntawd yog xaiv nrog kev tsis ncaj ncees rau kev tsim cov ntawv nyeem uas raug cai ntawm ntau hom lus, suav nrog C++ 11 thiab C-tsev neeg cov lus zoo sib xws.
    /// Lub caij nyoog kev cai yog:
    ///
    /// * Tab yog dim li `\t`.
    /// * Carriage rov qab yog dim li `\r`.
    /// * Kab noj yog dim li `\n`.
    /// * Tib quote yog dim li `\'`.
    /// * Ob chav quote yog dim li `\"`.
    /// * Backslash yog dim li `\\`.
    /// * Tej cim nyob rau hauv lub 'xav luam ASCII' ntau `0x20` .. `0x7e` inclusive yog tsis dim.
    /// * Tag nrho lwm cov cim yog muab hexadecimal Unicode escapes;saib [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Raws li ib tug iterator:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Siv `println!` ncaj qha:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Ob qho tib si sib npaug rau:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// Siv `to_string`:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// Rov tus xov tooj ntawm bytes no `char` yuav tsum yog kho nyob rau hauv UTF-8.
    ///
    /// Tus xov tooj ntawm bytes yog yeej ib txwm nyob nruab nrab ntawm 1 thiab 4, inclusive.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// Lub `&str` hom guarantees tias nws txheem yog UTF-8, thiab kom peb thiaj li los sib piv qhov ntev nws yuav siv sij hawm yog txhua tus code point twb tuaj raws li ib tug `char` vs nyob rau hauv lub `&str` nws tus kheej:
    ///
    ///
    /// ```
    /// // raws li chars
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // ob qho tib si tuaj yeem sawv cev raws li peb bytes
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // raws li &str, ob qhov no tau tshaj rau hauv UTF-8
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // peb tuaj yeem pom tias lawv siv rau (6) bytes tag nrho ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... cia li zoo li cov &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// Rov tus xov tooj ntawm 16-ntsis code units no `char` yuav tsum yog kho nyob rau hauv UTF-16.
    ///
    ///
    /// Saib cov ntaub ntawv rau [`len_utf8()`] rau ntau piav qhia txog cov tswvyim no.
    /// Txoj haujlwm no yog tsom iav, tab sis rau UTF-16 hloov UTF-8.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Encodes no cim raws li UTF-8 mus rau hauv lub muab byte tsis, thiab ces rov subslice ntawm tus tsis hais tias muaj cov kho tus cwj pwm.
    ///
    ///
    /// # Panics
    ///
    /// Panics yog tias tsis zoo txaus.
    /// Tsis tiv thaiv ntawm qhov ntev plaub yog qhov loj txaus kom encode ib qho `char`.
    ///
    /// # Examples
    ///
    /// Nyob rau hauv ob qho tib si ntawm cov piv txwv, 'ß' yuav siv sij hawm ob bytes rau encode.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Qhov tsis zoo uas yog qhov tsawg heev:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // KEV RUAJ NTSEG: `char` tsis yog ib tug surrogate, yog li no yog siv tau UTF-8.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Encodes no cim raws li UTF-16 mus rau hauv lub muab `u16` tsis, thiab ces rov subslice ntawm tus tsis hais tias muaj cov kho tus cwj pwm.
    ///
    ///
    /// # Panics
    ///
    /// Panics yog tias tsis zoo txaus.
    /// Ib tug tsis ntev 2 yog loj txaus rau encode tej `char`.
    ///
    /// # Examples
    ///
    /// Nyob rau hauv ob qho tib si ntawm cov piv txwv, '𝕊' yuav siv sij hawm ob 'u16`s rau encode.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Qhov tsis zoo uas yog qhov tsawg heev:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Rov qab los `true` yog hais tias qhov `char` muaj `Alphabetic` cov cuab yeej.
    ///
    /// `Alphabetic` yog tau piav nyob rau hauv Tshooj 4 (Cov Cwj Pwm Khoom) ntawm [Unicode Standard] thiab teev hauv [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // kev hlub yog muaj ntau yam, tab sis nws tsis yog alphabetic
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Rov qab `true` yog qhov no `char` muaj cov cuab yeej `Lowercase`.
    ///
    /// `Lowercase` yog tau piav nyob rau hauv Tshooj 4 (Cov Cwj Pwm Khoom) ntawm [Unicode Standard] thiab teev hauv [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // Cov ntawv sau Suav ntau thiab cov cim sau ntawv tsis muaj rooj plaub, thiab lwm yam:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Rov qab `true` yog qhov no `char` muaj cov cuab yeej `Uppercase`.
    ///
    /// `Uppercase` yog tau piav nyob rau hauv Tshooj 4 (Cov Cwj Pwm Khoom) ntawm [Unicode Standard] thiab teev hauv [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // Cov ntawv sau Suav ntau thiab cov cim sau ntawv tsis muaj rooj plaub, thiab lwm yam:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Rov qab `true` yog qhov no `char` muaj cov cuab yeej `White_Space`.
    ///
    /// `White_Space` yog teev hauv [Unicode Character Database][ucd] [`PropList.txt`].
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // qhov chaw tsis-tawg
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Rov qab `true` yog tias `char` txaus siab [`is_alphabetic()`] lossis [`is_numeric()`].
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Rov qab los `true` yog hais tias qhov `char` muaj cov kev qeb kev tswj cov lis dej num.
    ///
    /// Cov lej tswj (cov cim lej nrog cov qeb dav dav ntawm `Cc`) tau piav qhia nyob hauv Tshooj 4 (Cov Cwj Pwm) ntawm [Unicode Standard] thiab teev hauv [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// // U + 009C, txoj hlua Terminator
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Rov qab los `true` yog hais tias qhov `char` muaj `Grapheme_Extend` cov cuab yeej.
    ///
    /// `Grapheme_Extend` yog tau piav qhia hauv [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] thiab teev hauv [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Rov qab `true` yog tias `char` no muaj ib qho ntawm cov khoom siv dav dav rau tus lej.
    ///
    /// Cov qeb dav dav rau cov naj npawb (`Nd` rau cov lej lej, `Nl` rau cov ntawv zoo li cov cim, thiab `No` rau lwm cov cim loj) tau teev nyob hauv [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Rov qab los ib iterator uas yields cov lowercase kuas ntawm no `char` raws li ib tug los yog ntau tshaj
    /// `char`s.
    ///
    /// Yog tias `char` no tsis muaj qhov ntsuas qis kab, tus ntsuas pa yields tib `char`.
    ///
    /// Yog hais tias qhov no `char` muaj ib tug ib tug-rau-ib tug lowercase kuas muab los ntawm cov [Unicode Character Database][ucd] [`UnicodeData.txt`], lub iterator loo uas `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Yog tias `char` no yuav tsum muaj kev xav tshwj xeeb (piv txwv li ntau tus 'char`s) tus ntsuas khoom pub cov' char '(s) muab los ntawm [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Txoj haujlwm no ua tiav daim phiaj tsis ua haujlwm yam tsis muaj kev ntsuas txiav.Hais tias yog, tus hloov dua siab tshiab yog ywj siab ntawm lub ntsiab lus teb thiab cov lus.
    ///
    /// Hauv [Unicode Standard], Tshooj 4 (Cov Cwj Pwm Sib Zog) sib tham txog daim phiaj qhia chaw dav dav thiab Tshooj 3 (Conformance) sib tham txog qhov ua tsis suav cov teeb meem rau kev hloov pauv ntawm rooj plaub.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Raws li ib tug iterator:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Siv `println!` ncaj qha:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Ob qho tib si sib npaug rau:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// Siv `to_string`:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // Qee zaum cov txiaj ntsig ntau dua ib lub cim:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Cov cim tsis muaj ob qho uas loj thiab cov tsiaj ntawv me hloov mus rau lawv tus kheej.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Rov qab tawm tus ntsuas uas yields qhov uppercase daim phiaj qhia ntawm no `char` ua ib lossis ntau dua
    /// `char`s.
    ///
    /// Yog hais tias qhov no `char` tsis muaj ib tug ntawv loj kuas, lub iterator yields cov tib `char`.
    ///
    /// Yog hais tias qhov no `char` muaj ib tug ib tug-rau-ib tug loj kuas muab los ntawm cov [Unicode Character Database][ucd] [`UnicodeData.txt`], lub iterator loo uas `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Yog tias `char` no yuav tsum muaj kev xav tshwj xeeb (piv txwv li ntau tus 'char`s) tus ntsuas khoom pub cov' char '(s) muab los ntawm [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Txoj haujlwm no ua tiav daim phiaj tsis ua haujlwm yam tsis muaj kev ntsuas txiav.Hais tias yog, tus hloov dua siab tshiab yog ywj siab ntawm lub ntsiab lus teb thiab cov lus.
    ///
    /// Hauv [Unicode Standard], Tshooj 4 (Cov Cwj Pwm Sib Zog) sib tham txog daim phiaj qhia chaw dav dav thiab Tshooj 3 (Conformance) sib tham txog qhov ua tsis suav cov teeb meem rau kev hloov pauv ntawm rooj plaub.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Raws li ib tug iterator:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Siv `println!` ncaj qha:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Ob qho tib si sib npaug rau:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// Siv `to_string`:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // Qee zaum cov txiaj ntsig ntau dua ib lub cim:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Cov cim tsis muaj ob qho uas loj thiab cov tsiaj ntawv me hloov mus rau lawv tus kheej.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Sau tseg hauv zos
    ///
    /// Nyob rau hauv Turkish, qhov sib npaug ntawm 'i' nyob rau hauv Latin muaj tsib ntaub ntawv es tsis txhob ntawm ob:
    ///
    /// * 'Dotless': Kuv/ı, qee zaum sau ntawv ï
    /// * 'Dotted': /I
    ///
    /// Nco ntsoov tias lub lowercase dotted 'i' yog tib yam li cov Latin.Yog li ntawd:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// Tus nqi ntawm `upper_i` no cia siab rau cov lus ntawm cov ntawv nyeem: yog hais tias peb nyob rau hauv `en-US`, nws yuav tsum tau `"I"`, tab sis yog hais tias peb nyob rau hauv `tr_TR`, nws yuav tsum tau `"İ"`.
    /// `to_uppercase()` tsis txhob noj mus rau hauv tus account, thiab thiaj li:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// tuas thoob plaws hom lus.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Cov tshev mis yog hais tias tus nqi yog nyob rau hauv lub ASCII ntau yam.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Ua ib daim qauv ntawm cov nqi nyob rau hauv nws cov ASCII sab sauv cov ntaub ntawv sib npaug.
    ///
    /// ASCII cov ntawv 'a' rau 'z' yog mapped rau 'A' rau 'Z', tab sis cov tsiaj ntawv tsis-ASCII tsis hloov pauv.
    ///
    /// Txhawm rau ua kom tus nqi nyob rau hauv-qhov chaw, siv [`make_ascii_uppercase()`].
    ///
    /// Txhawm rau uppercase ASCII cov cim ntxiv rau tsis yog-ASCII cov cim, siv [`to_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Ua ib daim qauv ntawm cov nqi nyob rau hauv nws cov ASCII qis cov ntaub ntawv sib npaug.
    ///
    /// ASCII cov ntawv 'A' rau 'Z' yog mapped rau 'a' rau 'z', tab sis cov tsiaj ntawv tsis-ASCII tsis hloov pauv.
    ///
    /// Yuav kom lowercase tus nqi nyob rau hauv-qhov chaw, siv [`make_ascii_lowercase()`].
    ///
    /// Txo qis ASCII cov cim ntxiv rau cov tsis yog-ASCII cov cim, siv [`to_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Tshuaj xyuas tias ob qhov tseem ceeb yog ASCII rooj plaub-pom qhov tsis zoo.
    ///
    /// Sib npaug rau `to_ascii_lowercase(a) == to_ascii_lowercase(b)`.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Hloov siab hom no rau nws ASCII qaum rooj plaub sib npaug hauv-chaw.
    ///
    /// ASCII cov ntawv 'a' rau 'z' yog mapped rau 'A' rau 'Z', tab sis cov tsiaj ntawv tsis-ASCII tsis hloov pauv.
    ///
    /// Rov qab mus rau ib tug tshiab uppercased nqi tsis modifying uas twb muaj lawm ib tug, siv [`to_ascii_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Hloov siab los ntseeg no hom rau nws ASCII qis cov ntaub ntawv sib npaug nyob rau hauv-qhov chaw.
    ///
    /// ASCII cov ntawv 'A' rau 'Z' yog mapped rau 'a' rau 'z', tab sis cov tsiaj ntawv tsis-ASCII tsis hloov pauv.
    ///
    /// Txhawm rau rov qab tus nqi qis qis dua yam tsis muaj kev hloov kho rau ib tus uas twb muaj lawm, siv [`to_ascii_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Cov tshev yog tias tus nqi yog ASCII tus tsiaj ntawv:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', los yog
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Cov tshev mis yog hais tias tus nqi yog ib qho ASCII loj cim:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Cov tshev yog tias tus nqi yog ASCII tus ntawv qis:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Cov tshev yog tias tus nqi yog ASCII alphanumeric cov cim:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', los yog
    /// - U + 0061 'a' ..=U + 007A 'z', los yog
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Cov tshev yog tias tus nqi yog ASCII tus lej:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Cov tshev mis yog hais tias tus nqi yog ib qho ASCII hexadecimal lej:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', los yog
    /// - U + 0041 'A' ..=U + 0046 'F', los yog
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Cov tshev yog tias tus nqi yog ASCII cim ntu:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, or
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, or
    /// - U + 005B ..=U + 0060 '' [\] ^ _ ``, los yog
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Cov tshev yog tias tus nqi yog ASCII nraaj cim:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Cov tshev mis yog hais tias tus nqi yog ib qho ASCII whitespace cim:
    /// U + 0020 CHAW UA KE, U + 0009 KAB ROV QAB TUG TAB, U + 000A KAB NOJ, U + 000C DAIM DAG, los yog U + 000D KEV NCAJ NCEES.
    ///
    /// Rust siv WhatWG Infra Standard tus [definition of ASCII whitespace][infra-aw].Muaj ntau ntau lwm yam lus txhais rau hauv dav siv.
    /// Piv txwv li, [the POSIX locale][pct] muaj xws li U + 000B NTSUG TAB raws li tag nrho cov saum toj no cim, tab sis ntawm tus qub heev specification-[lub neej ntawd txoj cai rau "field splitting" nyob rau hauv lub Bourne shell][bfs] considers *xwb* qhov chaw, KAB ROV TAV TAB, thiab LINE FEED li whitespace.
    ///
    ///
    /// Yog tias koj tab tom sau qhov program uas yuav ua cov hom file uas twb muaj lawm, xyuas seb hom ntawv twg txhais ntawm qhov chaw tsis tau yog ua ntej siv txoj haujlwm no.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Cov tshev yog tias tus nqi yog ASCII tswj lub cim:
    /// U + 0000 NUL ..=U + 001F UNIT SEPARATOR, los yog U + 007F RHO TAWM.
    /// Nco ntsoov tias feem ntau ASCII whitespace cim yog tswj cim, tab sis qhov chaw no tsis yog.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Encodes ib tug nyoos u32 nqi raws li UTF-8 mus rau hauv lub muab byte tsis, thiab ces rov subslice ntawm tus tsis hais tias muaj cov kho tus cwj pwm.
///
///
/// Tsis zoo li `char::encode_utf8`, qhov no txoj kev tseem tuam haujlwm txais cov codepoints nyob rau hauv lub surrogate ntau yam.
/// (Tsim ib `char` nyob rau hauv lub surrogate ntau yog UB.) Cov no siv tau [generalized UTF-8] tab sis siv tsis tau UTF-8.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics yog tias tsis zoo txaus.
/// Tsis tiv thaiv ntawm qhov ntev plaub yog qhov loj txaus kom encode ib qho `char`.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// Encodes ib tug nyoos u32 nqi raws li UTF-16 mus rau hauv lub muab `u16` tsis, thiab ces rov subslice ntawm tus tsis hais tias muaj cov kho tus cwj pwm.
///
///
/// Tsis zoo li `char::encode_utf16`, cov qauv no kuj daws cov codepoints hauv qhov ntau ntawm surrogate.
/// (Tsim ib `char` nyob rau hauv lub surrogate ntau yog UB.)
///
/// # Panics
///
/// Panics yog tias tsis zoo txaus.
/// Ib tug tsis ntev 2 yog loj txaus rau encode tej `char`.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // KEV RUAJ NTSEG: txhua txhais caj npab xyuas seb puas muaj cov ntawv sau kom txaus rau hauv
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // Tus BMP poob los ntawm
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Cov dav hlau ntxiv tawg rau surrogates.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}