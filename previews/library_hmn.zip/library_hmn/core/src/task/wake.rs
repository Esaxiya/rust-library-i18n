#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// Ib tus `RawWaker` tso cai rau tus neeg coj ua haujlwm ua haujlwm los tsim ib tus [`Waker`] uas muab kev coj ua lub neej sawv.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// Nws muaj ib cov ntaub ntawv pointer thiab ib tug [virtual function pointer table (vtable)][vtable] uas customizes tus cwj pwm ntawm cov `RawWaker`.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// Ib tug cov ntaub ntawv pointer, uas yuav siv tau los cia arbitrary cov ntaub ntawv raws li yuav tsum tau los ntawm lub executor.
    /// Qhov no yuav yog yam ntxwv
    /// ib hom-eisted pointer rau ib qho `Arc` uas cuam tshuam nrog txoj haujlwm.
    /// Tus nqi ntawm daim teb no tau dhau mus rau tag nrho cov haujlwm uas yog ib feem ntawm vtable ua thawj tus ntsuas.
    ///
    data: *const (),
    /// Virtual function pointer table uas yog kho tus cwj pwm ntawm cov neeg hnav khaub ncaws no.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Tsim ib tug tshiab `RawWaker` los ntawm cov muab `data` pointer thiab `vtable`.
    ///
    /// Lub `data` pointer yuav siv tau los cia arbitrary cov ntaub ntawv raws li yuav tsum tau los ntawm lub executor.Qhov no yuav yog yam ntxwv
    /// ib hom-eisted pointer rau ib qho `Arc` uas cuam tshuam nrog txoj haujlwm.
    /// Tus nqi ntawm no pointer yuav tau kis mus rau tag nrho cov zog uas yog ib feem ntawm lub `vtable` raws li cov thawj parameter.
    ///
    /// Lub `vtable` customizes tus cwj pwm ntawm ib tug `Waker` uas tau tsim los ntawm ib tug `RawWaker`.
    /// Rau txhua qhov haujlwm ntawm `Waker`, txoj haujlwm ua haujlwm hauv `vtable` ntawm qhov pib `RawWaker` yuav raug hu.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// Ib tug virtual muaj nuj nqi pointer rooj (vtable) uas qhia txog tus cwj pwm ntawm ib tug [`RawWaker`].
///
/// Tus pointer dhau mus rau tag nrho cov haujlwm hauv vtable yog `data` pointer los ntawm kev xa nrog [`RawWaker`] lub hom phiaj.
///
/// Cov haujlwm hauv cov qauv no tsuas yog npaj siab yuav raug hu rau `data` tus pointer ntawm cov khoom tsim nyog [`RawWaker`] tawm ntawm sab hauv [`RawWaker`] kev siv.
/// Hu ib tug ntawm cov muaj zog siv lwm yam `data` pointer yuav ua rau undefined tus cwj pwm.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// Muaj nuj nqi no yuav raug hu thaum lub [`RawWaker`] tau txais cloned, piv txwv li thaum [`Waker`] nyob rau hauv uas [`RawWaker`] yog khaws tau cloned.
    ///
    /// Cov kev siv ntawm no muaj nuj nqi yuav tsum khaws tag nrho cov kev pab uas yuav tsum tau rau li no ntxiv piv txwv ntawm ib tug [`RawWaker`] thiab kab hauj lwm.
    /// Hu `wake` rau lub resulting [`RawWaker`] yuav tsum ua nyob rau hauv ib tug wakeup ntawm tib neeg ua hauj lwm uas yuav tau awoken los ntawm tus thawj [`RawWaker`].
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Qhov no muaj nuj nqi yuav tsum tau hu ua thaum `wake` yog hu ua nyob rau hauv lub [`Waker`].
    /// Nws yuav tsum sawv ua hauj lwm uas txuam nrog no [`RawWaker`].
    ///
    /// Cov kev siv ntawm no muaj nuj nqi yuav tsum nco ntsoov tso tej kev pab uas txuam nrog no lom ntawm ib tug [`RawWaker`] thiab kab hauj lwm.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Txoj haujlwm no yuav raug hu thaum `wake_by_ref` hu rau [`Waker`].
    /// Nws yuav tsum sawv ua hauj lwm uas txuam nrog no [`RawWaker`].
    ///
    /// Qhov no muaj nuj nqi yog zoo li `wake`, tab sis yuav tsum tsis txhob haus cov muab cov ntaub ntawv pointer.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Muaj nuj nqi no tau hu thaum tus [`RawWaker`] poob.
    ///
    /// Cov kev siv ntawm no muaj nuj nqi yuav tsum nco ntsoov tso tej kev pab uas txuam nrog no lom ntawm ib tug [`RawWaker`] thiab kab hauj lwm.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Tsim cov `RawWakerVTable` tshiab los ntawm cov muab `clone`, `wake`, `wake_by_ref`, thiab `drop` haujlwm.
    ///
    /// # `clone`
    ///
    /// Muaj nuj nqi no yuav raug hu thaum lub [`RawWaker`] tau txais cloned, piv txwv li thaum [`Waker`] nyob rau hauv uas [`RawWaker`] yog khaws tau cloned.
    ///
    /// Cov kev siv ntawm no muaj nuj nqi yuav tsum khaws tag nrho cov kev pab uas yuav tsum tau rau li no ntxiv piv txwv ntawm ib tug [`RawWaker`] thiab kab hauj lwm.
    /// Hu `wake` rau lub resulting [`RawWaker`] yuav tsum ua nyob rau hauv ib tug wakeup ntawm tib neeg ua hauj lwm uas yuav tau awoken los ntawm tus thawj [`RawWaker`].
    ///
    /// # `wake`
    ///
    /// Qhov no muaj nuj nqi yuav tsum tau hu ua thaum `wake` yog hu ua nyob rau hauv lub [`Waker`].
    /// Nws yuav tsum sawv ua hauj lwm uas txuam nrog no [`RawWaker`].
    ///
    /// Cov kev siv ntawm no muaj nuj nqi yuav tsum nco ntsoov tso tej kev pab uas txuam nrog no lom ntawm ib tug [`RawWaker`] thiab kab hauj lwm.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Txoj haujlwm no yuav raug hu thaum `wake_by_ref` hu rau [`Waker`].
    /// Nws yuav tsum sawv ua hauj lwm uas txuam nrog no [`RawWaker`].
    ///
    /// Qhov no muaj nuj nqi yog zoo li `wake`, tab sis yuav tsum tsis txhob haus cov muab cov ntaub ntawv pointer.
    ///
    /// # `drop`
    ///
    /// Muaj nuj nqi no tau hu thaum tus [`RawWaker`] poob.
    ///
    /// Cov kev siv ntawm no muaj nuj nqi yuav tsum nco ntsoov tso tej kev pab uas txuam nrog no lom ntawm ib tug [`RawWaker`] thiab kab hauj lwm.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// Tus `Context` ntawm kev ua haujlwm asynchronous.
///
/// Tam sim no, `Context` tsuas yog pabcuam los muab kev nkag mus rau `&Waker` uas tuaj yeem siv los tsim txoj haujlwm tam sim no.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Xyuas kom peb future-ntawv pov thawj tiv thaiv kev hloov pauv sib txawv los ntawm kev yuam kom lub neej muaj qhov tsis xws luag (kev sib cav-txoj hauj lwm lub neej yog contravariant thaum rov qab-txoj hauj lwm lub neej yog covariant).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Tsim tshiab `Context` los ntawm `&Waker`.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Rov ib tug siv mus rau lub `Waker` rau tam sim no ua hauj lwm.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// Ib tug `Waker` yog ib tug kov rau waking ib tug neeg ua hauj lwm los ntawm qhia nws executor hais tias nws yog npaj txhij yuav khiav.
///
/// Qhov kev kov no encapsulates ib qho piv txwv [`RawWaker`], uas txhais cov kev coj ua ntawm kev coj tus cwj pwm.
///
///
/// Kev xyaum [`Clone`], [`Send`], thiab [`Sync`].
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Sawv kev ua haujlwm muaj feem xyuam nrog no `Waker`.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // Qhov tseeb tiag sawv kev hu yog muab los ntawm qhov ua haujlwm hu rau qhov kev nqis tes uas tau txhais los ntawm tus neeg ua haujlwm.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // Tsis txhob hu `drop`-tus waker yuav noj ntawm `wake`.
        crate::mem::forget(self);

        // KEV RUAJ NTSEG: Qhov no yog muaj kev ruaj ntseg vim hais tias `Waker::from_raw` yog tib txoj kev
        // yuav pib `wake` thiab `data` xav kom tus neeg siv tau lees paub tias daim ntawv cog lus ntawm `RawWaker` tau raug saib xyuas.
        //
        unsafe { (wake)(data) };
    }

    /// Sawv neeg ua hauj lwm uas txuam nrog no `Waker` tsis siv cov `Waker`.
    ///
    /// Qhov no zoo ib yam li `wake`, tab sis tej zaum yuav siv zog me ntsis hauv rooj plaub uas muaj tus `Waker` muaj.
    /// Qhov no txoj kev yuav tsum tau najnpawb hu `waker.clone().wake()`.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // Qhov tseeb tiag sawv kev hu yog muab los ntawm qhov ua haujlwm hu rau qhov kev nqis tes uas tau txhais los ntawm tus neeg ua haujlwm.
        //

        // KEV RUAJ NTSEG: saib `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Rov qab los `true` yog hais tias qhov `Waker` thiab lwm `Waker` tau awoken tib neeg ua hauj lwm.
    ///
    /// Qhov haujlwm no ua haujlwm zoo rau kev siv zog, thiab tej zaum yuav rov dag cuav txawm tias thaum tus "Waker" yuav paub txog tib txoj haujlwm.
    /// Txawm li cas los, Yog hais tias qhov no muaj nuj nqi rov `true`, nws yog guaranteed hais tias cov 'Waker`s yuav nyuaj tib yam hauj lwm.
    ///
    /// Qhov no muaj nuj nqi yog feem ntau siv rau optimization hom phiaj.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// Tsim ib tug tshiab `Waker` los ntawm [`RawWaker`].
    ///
    /// Cov cwj pwm ntawm cov rov qab `Waker` yog undefined yog daim ntawv cog lus hais tseg nyob rau hauv ['RawWaker`]' s thiab ['RawWakerVTable`]' s ntaub ntawv yog tsis upheld.
    ///
    /// Yog li hom kab ke no tsis nyab xeeb.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // KEV RUAJ NTSEG: Qhov no yog muaj kev ruaj ntseg vim hais tias `Waker::from_raw` yog tib txoj kev
            // yuav pib `clone` thiab `data` xav kom tus neeg siv tau lees paub tias daim ntawv cog lus ntawm [`RawWaker`] tau raug saib xyuas.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // KEV RUAJ NTSEG: Qhov no yog muaj kev ruaj ntseg vim hais tias `Waker::from_raw` yog tib txoj kev
        // initialize `drop` thiab `data` tau tus neeg siv yuav lees paub hais tias daim ntawv cog lus ntawm `RawWaker` yog upheld.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}