//! Lub `Clone` trait rau hom hais tias yuav ua tsis tau 'implicitly theej'.
//!
//! Hauv Rust, qee hom yooj yim yog "implicitly copyable" thiab thaum koj cob lawv lossis dhau lawv ua kev sib cav, tus txais yuav tau txais ib daim ntawv, tawm tus nqi qub hauv qhov chaw.
//! Cov tsis yuav tsum tau qee rau daim ntawv thiab tsis muaj finalizers (ie, lawv tsis muaj muaj thawv los yog siv [`Drop`]), li ntawd, lub compiler considers lawv pheej yig thiab muaj kev nyab xeeb rau luam.
//!
//! Txog lwm hom ntawv yuav tsum tau ua kom meej meej, los ntawm kev pom zoo siv [`Clone`] trait thiab hu [`clone`] tus qauv.
//!
//! [`clone`]: Clone::clone
//!
//! Basic pab Piv txwv li:
//!
//! ```
//! let s = String::new(); // Hlua hom implements Clone
//! let copy = s.clone(); // yog li peb tuaj yeem ua nws
//! ```
//!
//! Txhawm rau siv Clone trait kom yooj yim, koj kuj siv tau `#[derive(Clone)]`.Piv txwv:
//!
//! ```
//! #[derive(Clone)] // peb ntxiv Clone trait rau Morpheus qauv
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // thiab tam sim no peb tuaj yeem clone nws!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// Ib qho trait dav dav rau qhov muaj peev xwm ua kom meej meej theej tawm ib yam khoom.
///
/// Cov neeg sib txawv ntawm [`Copy`] hauv [`Copy`] yog qhov tsis txaus ntseeg thiab tsis tshua muaj nqi, thaum `Clone` ib txwm paub meej thiab tej zaum yuav yog lossis tsis kim.
/// Nyob rau hauv thiaj li yuav tswj cov kev yam ntxwv, Rust tsis pub koj mus reimplement [`Copy`], tab sis tej zaum koj yuav reimplement `Clone` thiab khiav arbitrary code.
///
/// Txij li thaum `Clone` yog ntau general tshaj [`Copy`], koj muaj peev xwm txiav ua dab tsi [`Copy`] yuav `Clone` zoo li.
///
/// ## Derivable
///
/// Cov trait no tuaj yeem siv nrog `#[derive]` yog tias txhua daim teb yog `Clone`.Qhov kev piav qhia ua [`Clone`] hu [`clone`] ntawm txhua daim teb.
///
/// [`clone`]: Clone::clone
///
/// Rau ib generic struct, `#[derive]` siv `Clone` conditionally los ntawm kev ntxiv txhua yam `Clone` rau generic tsis.
///
/// ```
/// // `derive` implements Clone rau kev nyeem ntawv<T>thaum T yog Clone.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Kuv tuaj yeem siv `Clone` li cas?
///
/// Cov hom yog [`Copy`] yuav tsum muaj kev coj ua ntawm `Clone`.Ntau daim ntawv sau:
/// yog `T: Copy`, `x: T`, thiab `y: &T`, ces `let x = y.clone();` yog qhov sib npaug rau `let x = *y;`.
/// Kev siv phau ntawv yuav tsum tau ceev faj los txhawb qhov kev tsis tuaj no;Txawm li cas los, tsis zoo code yuav tsum tsis txhob cia siab rau nws los xyuas kom meej nco kev ruaj ntseg.
///
/// Ib qho piv txwv yog ib tug generic struct tuav ib tug muaj nuj nqi pointer.Hauv qhov no, qhov kev siv ntawm `Clone` tsis tuaj yeem yog 'neeg coj los tau' tab sis tuaj yeem ua raws li:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Cov neeg siv ntxiv
///
/// Ntxiv nrog rau [implementors listed below][impls], cov hom hauv qab no tseem siv `Clone`:
///
/// * Muaj nuj nqi yam khoom (piv txwv li, cov sib txawv txhais tau rau txhua qhov haujlwm)
/// * Muaj nuj nqi pointer hom (piv txwv li, `fn() -> i32`)
/// * Array hom, rau tag nrho cov ntau thiab tsawg pab, yog hais tias tus khoom hom kuj siv `Clone` (eg, `[i32; 123456]`)
/// * Tu hom, yog tias txhua ntu tivthaiv `Clone` (xws li `()`, `(i32, bool)`)
/// * Kaw hom, yog hais tias lawv ntes tsis muaj nqi los ntawm cov ib puag ncig los yog hais tias tag nrho xws li yog tej qhov tseem ceeb kev `Clone` lawv tus kheej.
///   Nco ntsoov tias qhob yuav los ntawm kev sib qhia siv ib txwm siv `Clone` (txawm tias qhov siv tsis tau), thaum lub zog hloov los ntawm mutable siv yeej tsis siv `Clone`.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Rov qab daim ntawv tus nqi.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str implements Clone
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Ua cov ntawv luam-muab los ntawm `source`.
    ///
    /// `a.clone_from(&b)` yog sib npaug rau `a = b.clone()` hauv kev ua haujlwm, tab sis tuaj yeem overridden rov qab siv cov peev txheej ntawm `a` kom tsis txhob muaj kev faib nyiaj tsis tsim nyog.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Neeg macro generating ib tug impl ntawm lub trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): cov structs yog siv ib hom los ntawm#[neeg] paub tias txhua txhua feem ntawm ib hom implements Clone los yog Copy.
//
//
// Cov structs yuav tsum tsis txhob tshwm sim nyob rau hauv tus neeg siv code.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Kev siv `Clone` rau txheej thaum ub.
///
/// Kev coj ua uas tsis tuaj yeem piav qhia hauv Rust yog nqis tes hauv `traits::SelectionContext::copy_clone_conditions()` hauv `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Sib neeg ua tim khawv yuav tsum cloned, tab sis mutable ua tim khawv *yuav tsis*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Sib neeg ua tim khawv yuav tsum cloned, tab sis mutable ua tim khawv *yuav tsis*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}