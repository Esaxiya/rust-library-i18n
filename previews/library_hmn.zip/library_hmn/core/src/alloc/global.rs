use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// Ib lub cim xeeb siv uas tuaj yeem tso npe raws li tus qauv qiv hauv lub qub vim los ntawm `#[global_allocator]` tus cwj pwm.
///
/// Ib txhia ntawm cov kev yuav tsum tau hais tias ib tug nco thaiv yuav *tam sim no faib* ntawm ib tug allocator.Qhov no txhais tau tias:
///
/// * lub pib qhov chaw nyob rau cov uas nco thaiv tau yav tas los rov qab los ntawm ib tug yav dhau los hu rau ib tug faib txoj kev xws li `alloc`, thiab
///
/// * lub cim xeeb thaiv tsis tau txuas ntxiv tom qab, qhov twg thaiv tau sib cog lus los ntawm xa mus rau txoj hauv kev cog lus xws li `dealloc` lossis los ntawm dhau mus rau hom kev faib tawm rov qab uas tsis yog tus tsis muaj pointer.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// Lub `GlobalAlloc` trait yog `unsafe` trait rau ntau qhov laj thawj, thiab cov kws tsim khoom yuav tsum ua kom ntseeg tau tias lawv ua raws li cov ntawv cog lus no:
///
/// * Nws tus cwj pwm tsis paub qhov tseeb yog tias cov neeg siv khoom hauv ntiaj teb rub tawm.Qhov kev txwv no yuav raug tshem tawm hauv future, tab sis tam sim no panic los ntawm ib qho ntawm cov haujlwm no yuav ua rau lub cim xeeb tsis muaj teeb meem.
///
/// * `Layout` cov lus nug thiab suav nyob rau hauv dav dav yuav tsum yog.Cov neeg hu xov tooj ntawm trait no raug tso cai kom cia siab rau cov ntawv cog lus sau tseg hauv txhua txoj kev, thiab cov kws tsim khoom yuav tsum ua kom paub tseeb tias cov ntawv cog lus no tseem muaj tseeb.
///
/// * Koj yuav tsis cia siab rau kev faib nyiaj uas muaj tshwm sim tiag tiag, txawm tias muaj cov kev txwv tsis pub muaj nyob hauv qhov chaw zoo.
/// Lub optimizer yuav ntes tsis siv nyiaj hais tias nws yuav yog tshem tawm tag nrho los yog tsiv mus nyob rau cov tshooj thiab tsis yog li ntawd ua tau rau tus tus allocator.
/// Tus optimizer tuaj yeem hais ntxiv tias qhov kev faib tawm tsis tiav, yog li cov lej uas siv los ua tsis tiav vim kev faib cov haujlwm tsis tuaj yeem tam sim no ua haujlwm sai vim tias lub optimizer tau ua haujlwm nyob ib ncig ntawm qhov xav tau rau kev faib tawm.
/// Ntau qhov tseeb, qhov piv txwv cov cai hauv qab no tsis muaj txiaj ntsig, tsis hais txog seb koj cov neeg faib kev cai tso cai suav qhov ntau npaum li cas kev faib nyiaj tau tshwm sim.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Nco ntsoov tias cov kev hloov kho tau hais los saum toj no tsis yog qhov tsuas kho kom zoo dua uas tuaj yeem thov.Koj feem ntau yuav tsis cia siab rau kev faib cov kab heap yog tias lawv tuaj yeem raug tshem tawm yam tsis muaj kev hloov ntawm qhov kev pab cuam.
///   Seb nyiaj tshwm sim los yog tsis yog tsis yog ib feem ntawm qhov kev pab cuam tus cwj pwm, txawm yog hais tias nws yuav yuav ntes tau ntawm ib qho kev allocator uas lem nyiaj los ntawm luam los yog lwm yam muaj kev phiv.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Faib cov cim xeeb raws li piav qhia los ntawm `layout` muab.
    ///
    /// Rov qab los pointer los cim lub cim xeeb tshiab, lossis thov tsis qhia qhov faib ua tsis ua hauj lwm.
    ///
    /// # Safety
    ///
    /// Qhov no muaj nuj nqi tsis zoo vim hais tias undefined tus cwj pwm muaj yog hais tias tus neeg hu tsis xyuas kom meej tias `layout` muaj uas tsis yog-xoom loj.
    ///
    /// (Kev rho tawm mus ntxiv yuav qhia tau ntau yam ntxiv rau ntawm tus cwjpwm, piv txwv li, lav qhov chaw nyob xa ntawv lossis tus taw qhia tsis siv los teb rau tus thov kev xoom me.)
    ///
    /// Coob tus lub cim xeeb yuav los yog tsis tau pib.
    ///
    /// # Errors
    ///
    /// Rov qab mus thov tsis muaj cim qhia tau hais tias lub cim xeeb puas tas lawm lossis `layout` tsis tau raws li tus tsub ntawm no qhov loj me lossis kev teeb tsa tsis haum.
    ///
    /// Implementations yog xav kom rov qab thov rau nco qaug es aborting, tab sis qhov no yog tsis yog ib tug nruj yuav tsum tau.
    /// (Tshwj xeeb: nws yog *kev cai lij choj* kom ua raws li no trait atop ib lub chaw qiv cov haiv neeg ib txwm txiav tawm ntawm lub cim xeeb sab nrauv.)
    ///
    /// Neeg xav ho xam nyob rau hauv teb rau ib tug faib kev ua yuam kev yog xav kom hu mus rau lub [`handle_alloc_error`] muaj nuj nqi, es ncaj qha invoking `panic!` los yog zoo sib xws.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Cuam tshuam kev thaiv ntawm lub cim xeeb ntawm lub `ptr` pointer nrog muab `layout`.
    ///
    /// # Safety
    ///
    /// Lub luag haujlwm no tsis zoo vim tias tus cwj pwm tsis paub qhov tseeb tuaj yeem yog tus neeg hu tsis tuaj yeem ntseeg tag nrho cov hauv qab no:
    ///
    ///
    /// * `ptr` yuav tsum txhais ib ntu ntawm lub cim xeeb tam sim no faib ntawm no lub allocator,
    ///
    /// * `layout` yuav tsum yog tib layout uas siv los mus faib uas thaiv kev nco.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// Cwj pwm zoo ib yam li `alloc`, tab sis kuj xyuas kom meej tias cov ntsiab lus tau teem rau xoom ua ntej xa rov qab.
    ///
    /// # Safety
    ///
    /// Qhov no muaj nuj nqi tsis zoo rau tib yog vim li cas hais tias `alloc` yog.
    /// Txawm li cas los lub faib thaiv ntawm lub cim xeeb yog guaranteed yuav tsum tau initialized.
    ///
    /// # Errors
    ///
    /// Rov qab mus thov tsis muaj cim qhia tau hais tias qhov cim xeeb yog sab nrauv lossis `layout` tsis tau raws li tus neeg faib khoom qhov loj lossis kev txwv, zoo ib yam li hauv `alloc`.
    ///
    /// Neeg xav ho xam nyob rau hauv teb rau ib tug faib kev ua yuam kev yog xav kom hu mus rau lub [`handle_alloc_error`] muaj nuj nqi, es ncaj qha invoking `panic!` los yog zoo sib xws.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // KEV RUAJ NTSEG: daim ntawv cog lus muaj kev nyab xeeb rau `alloc` yuav tsum tau nqa los ntawm tus neeg hu.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // KEV RUAJ NTSEG: raws li kev faib nyiaj ua tiav, cheeb tsam los ntawm `ptr`
            // ntawm loj `size` yuav lav yuav tsum siv tau rau sau.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Ntsws los yog loj hlob ib ntu ntawm lub cim xeeb mus rau lub muab `new_size`.
    /// Qhov block tau piav qhia los ntawm kev muab `ptr` pointer thiab `layout`.
    ///
    /// Yog tias qhov no rov qab ua qhov tsis yog tus pointer, ces cov tswv cuab ntawm lub cim xeeb thaiv tau hais los ntawm `ptr` tau hloov mus rau tus neeg faib khoom no.
    /// Lub cim xeeb yuav yog los kuj tsis tau raug deallocated, thiab yuav tsum raug xam tias yog cov tsis zoo (tshwj tsis yog tias tau kawg nws twb pauv mus rov qab mus rau tus neeg hu dua ntawm rov qab los tus nqi ntawm cov qauv no).
    /// Lub cim xeeb tshiab yog faib nrog `layout`, tab sis nrog `size` hloov kho rau `new_size`.
    /// Qhov no tshiab layout yuav tsum tau siv thaum deallocating tus tshiab nco block nrog `dealloc`.
    /// Qhov thaj tsam `0..min(layout.size(), new_size) `ntawm lub cim xeeb tshiab tau lees tias muaj tib lub txiaj ntsig zoo ib yam li cov khoom qub.
    ///
    /// Yog hais tias qhov no txoj kev rov qab thov, ces cov tswv cuab ntawm lub cim xeeb thaiv tsis tau pauv mus rau qhov no allocator, thiab tus txheem ntawm lub cim xeeb thaiv yog unaltered.
    ///
    /// # Safety
    ///
    /// Lub luag haujlwm no tsis zoo vim tias tus cwj pwm tsis paub qhov tseeb tuaj yeem yog tus neeg hu tsis tuaj yeem ntseeg tag nrho cov hauv qab no:
    ///
    /// * `ptr` yuav tsum tau tam sim no tseg ntawm no lub allocator,
    ///
    /// * `layout` yuav tsum yog tib qhov qauv uas tau siv los faib qhov block ntawd ntawm lub cim xeeb,
    ///
    /// * `new_size` yuav tsum ntau tshaj xoom.
    ///
    /// * `new_size`, thaum npawv mus rau qhov ze ntau yam ntawm `layout.align()`, yuav tsum tsis txhob phwj (ie, lub sib npaug tus nqi yuav tsum muaj tsawg tshaj li `usize::MAX`).
    ///
    /// (Kev rho tawm mus ntxiv yuav qhia tau ntau yam ntxiv rau ntawm tus cwjpwm, piv txwv li, lav qhov chaw nyob xa ntawv lossis tus taw qhia tsis siv los teb rau tus thov kev xoom me.)
    ///
    /// # Errors
    ///
    /// Rov thov yog hais tias tus tshiab layout tsis tau raws li qhov luaj li cas thiab kawm tuab si lug xyuas ntawm lub allocator, los yog hais tias reallocation tsis tsis.
    ///
    /// Implementations yog xav kom rov qab thov rau nco qaug es panicking los yog aborting, tab sis qhov no yog tsis yog ib tug nruj yuav tsum tau.
    /// (Tshwj xeeb: nws yog *kev cai lij choj* kom ua raws li no trait atop ib lub chaw qiv cov haiv neeg ib txwm txiav tawm ntawm lub cim xeeb sab nrauv.)
    ///
    /// Neeg xav ho xam nyob rau hauv teb mus rau ib tug reallocation kev ua yuam kev yog xav kom hu mus rau lub [`handle_alloc_error`] muaj nuj nqi, es ncaj qha invoking `panic!` los yog zoo sib xws.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // KEV RUAJ NTSEG: tus neeg hu yuav tsum xyuas kom meej tias lub `new_size` tsis phwj.
        // `layout.align()` los ntawm `Layout` thiab yog li tau lees tias yuav siv tau.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // KEV RUAJ NTSEG: tus neeg hu yuav tsum xyuas kom meej tias `new_layout` yog ntau dua li xoom.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // KEV RUAJ NTSEG: lub yav tas los faib thaiv yuav tsis sib tshooj tshiab khiv faib block.
            // Daim ntawv cog lus kev nyab xeeb rau `dealloc` yuav tsum muaj kev cia siab los ntawm tus neeg hu tuaj.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}