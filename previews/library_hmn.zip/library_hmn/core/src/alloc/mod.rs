//! Nco rau cov qib APIs

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// Lub `AllocError` yuam kev qhia ib tug faib tsis ua hauj lwm uas tej zaum yuav vim kev pab qaug los yog mus rau ib yam dab tsi tsis ncaj ncees lawm thaum combining muab tswv yim cov lus sib cav nrog rau qhov no allocator.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (peb xav tau qhov no rau downstream impl ntawm trait Yuam Kev)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// Qhov kev siv ntawm `Allocator` tuaj yeem faib, loj hlob, me me, thiab tsim kev cais rau cov laj thawj tsis zoo ntawm cov ntaub ntawv tau piav qhia ntawm [`Layout`][].
///
/// `Allocator` yog tsim los siv rau ZSTs, ua tim khawv, los yog ntse pointers vim hais tias muaj ib tug allocator li `MyAlloc([u8; N])` tsis tau tsiv, tsis muaj muab kho dua rau pointers rau cov faib lub cim xeeb.
///
/// Tsis zoo li [`GlobalAlloc`][], xoom xaim cov nyiaj tau los tso cai hauv `Allocator`.
/// Yog tias cov nyiaj faib hauv qab tsis txhawb nqa qhov no (zoo li jemalloc) lossis xa rov qab tsis muaj dab tsi (xws li `libc::malloc`), qhov no yuav tsum raug ntes los ntawm kev siv.
///
/// ### Tam sim no faib cim xeeb
///
/// Ib txhia ntawm cov kev yuav tsum tau hais tias ib tug nco thaiv yuav *tam sim no faib* ntawm ib tug allocator.Qhov no txhais tau tias:
///
/// * lub pib qhov chaw nyob rau cov uas nco thaiv tau yav tas los rov qab los ntawm [`allocate`], [`grow`], los yog [`shrink`], thiab
///
/// * lub cim xeeb thaiv tsis tau tom qab deallocated, qhov twg blocks yog yog deallocated ncaj qha los yog kis mus rau [`deallocate`] los yog tau hloov los yog kis mus rau [`grow`] los yog [`shrink`] uas rov `Ok`.
///
/// Yog tias `grow` lossis `shrink` tau xa rov qab `Err`, lub pointer dhau los tseem siv tau.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Cim xeeb haum
///
/// Qee txoj kev xav tau qhov txheej txheem *haum* ib qho cim xeeb.
/// Nws txhais li cas rau ib tug layout rau "fit" ib tug nco block txhais tau tias (los yog equivalently, rau ib tug nco thaiv kom "fit" ib tug layout) yog hais tias lub nram qab no tej yam kev mob yuav tsum tuav:
///
/// * Lub thaiv yuav tsum tau muab faib nrog tib lub vaj huam sib luag li [`layout.align()`], thiab
///
/// * Qhov muab [`layout.size()`] yuav tsum poob rau hauv chav kawm `min ..= max`, qhov twg:
///   - `min` yog qhov loj me ntawm cov ntawv feem ntau tsis ntev los no siv los faib cov thaiv, thiab
///   - `max` yog qhov tseeb tiag tiag qhov loj me rov qab los ntawm [`allocate`], [`grow`], lossis [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Cov cim xeeb rov qab los ntawm tus neeg siv nyiaj yuav tsum tau taw rau lub cim xeeb siv tau thiab khaws lawv cov kev siv tau kom txog rau thaum piv txwv thiab tag nrho nws cov clones tau nqis,
///
/// * cloning los yog tsiv lub allocator yuav tsum tsis txhob invalidate nco blocks rov qab los ntawm no allocator.Ib tus neeg faib nyiaj yuav tsum coj zoo ib yam li kev faib nyiaj, thiab
///
/// * ib lub pointer rau lub cim xeeb uas yog [*currently allocated*] dhau mus rau lwm qhov kev ntawm cov neeg faib khoom.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Attempts mus faib ib ntu ntawm lub cim xeeb.
    ///
    /// Nyob rau kev vam meej, rov ib [`NonNull<[u8]>`][NonNull] lub rooj sib tham qhov luaj li cas thiab kawm tuab si lug guarantees ntawm `layout`.
    ///
    /// Lub block rov qab tuaj yeem muaj qhov loj me dua li tau teev tseg los ntawm `layout.size()`, thiab kuj yuav lossis tsis muaj nws cov ntawv sau.
    ///
    /// # Errors
    ///
    /// Rov qab `Err` qhia tau hais tias qhov cim xeeb yog sab sab tag nrho lossis `layout` tsis tau raws li qhov kev faib tawm qhov loj lossis kev txwv.
    ///
    /// Qhov kev ua raws yog xav kom rov `Err` ntawm lub cim xeeb qaug zog es tsis yog yias lossis tsim txom, tab sis qhov no tsis yog qhov yuav tsum nruj.
    /// (Tshwj xeeb: nws yog *kev cai lij choj* kom ua raws li no trait atop ib lub chaw qiv cov haiv neeg ib txwm txiav tawm ntawm lub cim xeeb sab nrauv.)
    ///
    /// Neeg xav ho xam nyob rau hauv teb rau ib tug faib kev ua yuam kev yog xav kom hu mus rau lub [`handle_alloc_error`] muaj nuj nqi, es ncaj qha invoking `panic!` los yog zoo sib xws.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Behaves li `allocate`, tab sis yuav pab kom lub rov qab nco yog zero-initialized.
    ///
    /// # Errors
    ///
    /// Rov qab `Err` qhia tau hais tias qhov cim xeeb yog sab sab tag nrho lossis `layout` tsis tau raws li qhov kev faib tawm qhov loj lossis kev txwv.
    ///
    /// Qhov kev ua raws yog xav kom rov `Err` ntawm lub cim xeeb qaug zog es tsis yog yias lossis tsim txom, tab sis qhov no tsis yog qhov yuav tsum nruj.
    /// (Tshwj xeeb: nws yog *kev cai lij choj* kom ua raws li no trait atop ib lub chaw qiv cov haiv neeg ib txwm txiav tawm ntawm lub cim xeeb sab nrauv.)
    ///
    /// Neeg xav ho xam nyob rau hauv teb rau ib tug faib kev ua yuam kev yog xav kom hu mus rau lub [`handle_alloc_error`] muaj nuj nqi, es ncaj qha invoking `panic!` los yog zoo sib xws.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // KEV RUAJ NTSEG: `alloc` rov siv lub cim xeeb zoo
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Cuam tshuam lub cim xeeb tau hais los ntawm `ptr`.
    ///
    /// # Safety
    ///
    /// * `ptr` yuav tsum tau hais tawm lub block ntawm lub cim xeeb [*currently allocated*] los ntawm tus neeg faib khoom no, thiab
    /// * `layout` yuav tsum [*fit*] uas thaiv kev nco.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Sim txuas ntxiv qhov cim xeeb thaiv.
    ///
    /// Rov qab [`NonNull<[u8]>`][NonNull] tshiab uas muaj lub pointer thiab qhov loj me ntawm cov cim xeeb tseg.Tus taw tes yog haum rau tuav cov ntaub ntawv piav qhia los ntawm `new_layout`.
    /// Yuav kom ua tiav, tus neeg faib khoom tuaj yeem txuas ntxiv cov kev faib los ntawm `ptr` kom haum rau cov qauv tshiab.
    ///
    /// Yog tias qhov no rov `Ok`, ces cov tswv cuab ntawm lub cim xeeb thaiv tau hais los ntawm `ptr` tau hloov mus rau tus neeg faib khoom no.
    /// Lub cim xeeb yuav los yog tsis tau tso rau, thiab yuav tsum tau txiav txim siab siv tsis tau tshwj tsis yog tias nws tau pauv rov qab rau tus neeg hu xov tooj ntxiv ntawm kev xa rov qab tus nqi ntawm hom no.
    ///
    /// Yog tias cov qauv no rov `Err`, ces cov tswv cuab ntawm lub cim xeeb thaiv tsis tau hloov mus rau tus neeg faib khoom no, thiab cov ntsiab lus ntawm lub cim xeeb thaiv tsis tau.
    ///
    /// # Safety
    ///
    /// * `ptr` yuav tsum tau hais tawm lub block ntawm lub cim xeeb [*currently allocated*] los ntawm tus neeg faib cov nyiaj no.
    /// * `old_layout` yuav tsum [*fit*] uas thaiv qhov cim xeeb (Qhov `new_layout` kev sib cav tsis xav tau nws haum.).
    /// * `new_layout.size()` yuav tsum ntau dua los yog sib npaug zos rau `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Rov `Err` yog hais tias tus tshiab layout tsis tau raws li lub allocator tus loj thiab kawm tuab si lug xyuas ntawm lub allocator, los yog hais tias loj hlob tsis tsis.
    ///
    /// Qhov kev ua raws yog xav kom rov `Err` ntawm lub cim xeeb qaug zog es tsis yog yias lossis tsim txom, tab sis qhov no tsis yog qhov yuav tsum nruj.
    /// (Tshwj xeeb: nws yog *kev cai lij choj* kom ua raws li no trait atop ib lub chaw qiv cov haiv neeg ib txwm txiav tawm ntawm lub cim xeeb sab nrauv.)
    ///
    /// Neeg xav ho xam nyob rau hauv teb rau ib tug faib kev ua yuam kev yog xav kom hu mus rau lub [`handle_alloc_error`] muaj nuj nqi, es ncaj qha invoking `panic!` los yog zoo sib xws.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // KEV RUAJ NTSEG: vim `new_layout.size()` yuav tsum ntau dua los yog sib npaug zos rau
        // `old_layout.size()`, ob lub qub thiab tshiab nco qee yog siv tau rau nyeem thiab sau rau `old_layout.size()` bytes.
        // Tsis tas li, vim tias cov nyiaj faib qub tsis tau cuam tshuam, nws tsis tuaj yeem sib tshooj `new_ptr`.
        // Yog li, kev hu mus rau `copy_nonoverlapping` muaj kev ruaj ntseg.
        // Daim ntawv cog lus kev nyab xeeb rau `dealloc` yuav tsum muaj kev cia siab los ntawm tus neeg hu tuaj.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Behaves li `grow`, tab sis yuav pab kom tus tshiab txheem no teem rau xoom ua ntej xa rov qab.
    ///
    /// Lub cim xeeb thaiv yuav muaj cov ntsiab lus hauv qab no tom qab hu ua tiav
    /// `grow_zeroed`:
    ///   * Bytes `0..old_layout.size()` yog khaws cia los ntawm thawj kev faib.
    ///   * Bytes `old_layout.size()..old_size` yuav yog khaws cia lossis xoom, nyob ntawm saib kev siv nyiaj.
    ///   `old_size` hais txog qhov loj me ntawm lub cim xeeb thaiv ua ntej `grow_zeroed` hu, uas yuav loj dua li qhov loj me uas tau thov kom tau thaum nws tau faib.
    ///   * Bytes `old_size..new_size` yog zeroed.`new_size` hais txog qhov loj me ntawm lub cim xeeb thaiv rov qab los ntawm `grow_zeroed` hu.
    ///
    /// # Safety
    ///
    /// * `ptr` yuav tsum tau hais tawm lub block ntawm lub cim xeeb [*currently allocated*] los ntawm tus neeg faib cov nyiaj no.
    /// * `old_layout` yuav tsum [*fit*] uas thaiv qhov cim xeeb (Qhov `new_layout` kev sib cav tsis xav tau nws haum.).
    /// * `new_layout.size()` yuav tsum ntau dua los yog sib npaug zos rau `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Rov `Err` yog hais tias tus tshiab layout tsis tau raws li lub allocator tus loj thiab kawm tuab si lug xyuas ntawm lub allocator, los yog hais tias loj hlob tsis tsis.
    ///
    /// Qhov kev ua raws yog xav kom rov `Err` ntawm lub cim xeeb qaug zog es tsis yog yias lossis tsim txom, tab sis qhov no tsis yog qhov yuav tsum nruj.
    /// (Tshwj xeeb: nws yog *kev cai lij choj* kom ua raws li no trait atop ib lub chaw qiv cov haiv neeg ib txwm txiav tawm ntawm lub cim xeeb sab nrauv.)
    ///
    /// Neeg xav ho xam nyob rau hauv teb rau ib tug faib kev ua yuam kev yog xav kom hu mus rau lub [`handle_alloc_error`] muaj nuj nqi, es ncaj qha invoking `panic!` los yog zoo sib xws.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // KEV RUAJ NTSEG: vim `new_layout.size()` yuav tsum ntau dua los yog sib npaug zos rau
        // `old_layout.size()`, ob lub qub thiab tshiab nco qee yog siv tau rau nyeem thiab sau rau `old_layout.size()` bytes.
        // Tsis tas li, vim tias cov nyiaj faib qub tsis tau cuam tshuam, nws tsis tuaj yeem sib tshooj `new_ptr`.
        // Yog li, kev hu mus rau `copy_nonoverlapping` muaj kev ruaj ntseg.
        // Daim ntawv cog lus kev nyab xeeb rau `dealloc` yuav tsum muaj kev cia siab los ntawm tus neeg hu tuaj.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Kev npaj siab rau qhov yuav thaiv lub cim xeeb.
    ///
    /// Rov qab [`NonNull<[u8]>`][NonNull] tshiab uas muaj lub pointer thiab qhov loj me ntawm cov cim xeeb tseg.Tus taw tes yog haum rau tuav cov ntaub ntawv piav qhia los ntawm `new_layout`.
    /// Yuav kom ua tiav qhov no, tus neeg faib tawm yuav txo cov kev faib los ntawm `ptr` kom haum rau cov qauv tshiab.
    ///
    /// Yog tias qhov no rov `Ok`, ces cov tswv cuab ntawm lub cim xeeb thaiv tau hais los ntawm `ptr` tau hloov mus rau tus neeg faib khoom no.
    /// Lub cim xeeb yuav los yog tsis tau tso rau, thiab yuav tsum tau txiav txim siab siv tsis tau tshwj tsis yog tias nws tau pauv rov qab rau tus neeg hu xov tooj ntxiv ntawm kev xa rov qab tus nqi ntawm hom no.
    ///
    /// Yog tias cov qauv no rov `Err`, ces cov tswv cuab ntawm lub cim xeeb thaiv tsis tau hloov mus rau tus neeg faib khoom no, thiab cov ntsiab lus ntawm lub cim xeeb thaiv tsis tau.
    ///
    /// # Safety
    ///
    /// * `ptr` yuav tsum tau hais tawm lub block ntawm lub cim xeeb [*currently allocated*] los ntawm tus neeg faib cov nyiaj no.
    /// * `old_layout` yuav tsum [*fit*] uas thaiv qhov cim xeeb (Qhov `new_layout` kev sib cav tsis xav tau nws haum.).
    /// * `new_layout.size()` yuav tsum yuav me dua los sis sib npaug rau `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Rov qab `Err` yog tias qhov kev teeb tsa tshiab tsis tau raws li tus neeg faib khoom qhov loj thiab cov kev txwv ntawm tus neeg lav, lossis yog tias ntsws tsis ua hauj lwm.
    ///
    /// Qhov kev ua raws yog xav kom rov `Err` ntawm lub cim xeeb qaug zog es tsis yog yias lossis tsim txom, tab sis qhov no tsis yog qhov yuav tsum nruj.
    /// (Tshwj xeeb: nws yog *kev cai lij choj* kom ua raws li no trait atop ib lub chaw qiv cov haiv neeg ib txwm txiav tawm ntawm lub cim xeeb sab nrauv.)
    ///
    /// Neeg xav ho xam nyob rau hauv teb rau ib tug faib kev ua yuam kev yog xav kom hu mus rau lub [`handle_alloc_error`] muaj nuj nqi, es ncaj qha invoking `panic!` los yog zoo sib xws.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // KEV RUAJ NTSEG: vim `new_layout.size()` yuav tsum qis dua los yog sib npaug rau
        // `old_layout.size()`, ob qho tib si qub thiab lub cim xeeb tshiab tseem siv tau rau kev nyeem thiab sau rau `new_layout.size()` bytes.
        // Tsis tas li, vim tias cov nyiaj faib qub tsis tau cuam tshuam, nws tsis tuaj yeem sib tshooj `new_ptr`.
        // Yog li, kev hu mus rau `copy_nonoverlapping` muaj kev ruaj ntseg.
        // Daim ntawv cog lus kev nyab xeeb rau `dealloc` yuav tsum muaj kev cia siab los ntawm tus neeg hu tuaj.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Tsim cov "by reference" adapter rau qhov piv txwv ntawm `Allocator`.
    ///
    /// Lub hloov xa rov qab kuj tseem siv `Allocator` thiab yuav tsuas yog qev qhov no.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // KEV RUAJ NTSEG: daim ntawv cog lus muaj kev ruaj ntseg yuav tsum tau nqa los ntawm tus neeg hu tuaj
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // KEV RUAJ NTSEG: daim ntawv cog lus muaj kev ruaj ntseg yuav tsum tau nqa los ntawm tus neeg hu tuaj
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // KEV RUAJ NTSEG: daim ntawv cog lus muaj kev ruaj ntseg yuav tsum tau nqa los ntawm tus neeg hu tuaj
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // KEV RUAJ NTSEG: daim ntawv cog lus muaj kev ruaj ntseg yuav tsum tau nqa los ntawm tus neeg hu tuaj
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}