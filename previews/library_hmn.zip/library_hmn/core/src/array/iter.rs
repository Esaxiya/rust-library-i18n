//! Lub sij lub `IntoIter` muaj iterator rau arrays.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// A ntawm-nqi [array] iterator.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Qhov no yog qhov array peb tab tom ua ntau dua.
    ///
    /// Cov ntsiab lus nrog qhov ua piv txwv `i` qhov twg `alive.start <= i < alive.end` tsis tau muaj txiaj ntsig tsis tau thiab siv tau cov khoom nkag uas siv tau.
    /// Hais nrog indices `i < alive.start` los yog `i >= alive.end` tau yielded lawm thiab yuav tsum tsis txhob yuav nkag lawm!Cov ua tuag ntawd los tseem yuav mus rau hauv ib qho kev txhaum kiag li!
    ///
    ///
    /// Yog li ntawd cov invariants yog:
    /// - `data[alive]` ciaj sia (piv txwv li muaj cov khoom uas siv tau)
    /// - `data[..alive.start]` thiab `data[alive.end..]` tau tuag lawm (piv txwv li cov ntsiab lus tau nyeem tas lawm thiab yuav tsum tsis txhob kov ntxiv lawm!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Lub ntsiab nyob rau hauv `data` uas tsis tau yielded tsis tau.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Tsim cov khoom siv cav tshiab hla lub `array` muab.
    ///
    /// *Ceeb toom*: cov qauv no tej zaum yuav deprecated nyob rau hauv lub future, tom qab [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // Lub hom `value` yog ib tug `i32` no, es tsis txhob ntawm `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // TXUJ CI: Cov transmute ntawm no yog ua kom nyab xeeb.Cov docs ntawm `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` yog lav kom muaj tib qho loj thiab kev sib thooj
        // > raws li `T`.
        //
        // Tus docs txawm qhia transmute los ntawm ib qho array ntawm `MaybeUninit<T>` mus rau kev ntsuas ntawm `T`.
        //
        //
        // Nrog hais tias, qhov no initialization satisfies cov invariants.

        // FIXME(LukasKalbertodt): yeej siv `mem::transmute` ntawm no, thaum nws ua haujlwm nrog const generics:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Txog thaum ntawd, peb yuav siv `mem::transmute_copy` los ua ib tug Bitwise daim ntawv raws li ib tug txawv hom, ces tsis nco qab `array` li hais tias nws yog tsis poob.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Rov ib immutable hlais ntawm tag nrho cov ntsiab uas tsis tau yielded tsis tau.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // KEV RUAJ NTSEG: Peb paub tias txhua yam hauv `alive` yog pib ua ntej.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Rov ib mutable hlais ntawm tag nrho cov ntsiab uas tsis tau yielded tsis tau.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // KEV RUAJ NTSEG: Peb paub tias txhua yam hauv `alive` yog pib ua ntej.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Tau txais qhov ntsuas tom ntej los ntawm sab xub ntiag.
        //
        // Nce `alive.start` los ntawm 1 tswj qhov tsis tseeb txog `alive`.
        // Txawm li cas los, vim rau qhov kev hloov no, rau ib tug luv luv lub sij hawm, lub ciaj sia tsam yog tsis `data[alive]` lawm, tiam sis `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Nyeem lub caij ntawm lub array.
            // KEV RUAJ NTSEG: `idx` yog ib qho ntsuas mus rau yav dhau los "alive" thaj av ntawm lub
            // array.Nyeem no txhais tau hais tias `data[idx]` yog ntshai li tuag tam sim no (ie tsis txhob kov).
            // Raws li `idx` yog pib ntawm ciaj sia-thaj chaw, thaj chaw ciaj sia yog tam sim no `data[alive]` dua, rov kho txhua tus neeg muaj mob.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Tau txais qhov ntsuas tom ntej los tom qab.
        //
        // Txo Cov `alive.end` los ntawm 1 tswj qhov tsis tseem ceeb txog `alive`.
        // Txawm li cas los xij, vim qhov kev hloov pauv no, rau ib lub sijhawm luv luv, thaj chaw muaj sia tsis yog `data[alive]` ntxiv lawm, tab sis `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Nyeem lub caij ntawm lub array.
            // KEV RUAJ NTSEG: `idx` yog ib qho ntsuas mus rau yav dhau los "alive" thaj av ntawm lub
            // array.Nyeem no txhais tau hais tias `data[idx]` yog ntshai li tuag tam sim no (ie tsis txhob kov).
            // Raws li `idx` yog qhov kawg ntawm cov chaw muaj sia-thaj chaw, thaj chaw ciaj sia yog tam sim no `data[alive]` dua, rov kho txhua tus neeg muaj mob.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // KEV RUAJ NTSEG: Qhov no yog muaj kev ruaj ntseg: `as_mut_slice` rov raws nraim sub-hlais
        // ntawm cov ntsiab lus uas tsis tau txav mus ntxiv thiab uas nyob twj ywm kom tau tso tawm.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Yuav tsis underflow vim lub invariant 'alive.start <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Lub iterator tseeb ceeb toom txog cov tseeb ntev.
// Tus nab npawb ntawm "alive" ntsiab (uas yuav tseem yuav yielded) yog qhov ntev ntawm lub ntau yam `alive`.
// Cov kab ntawv no tau txo qis hauv ntev hauv `next` lossis `next_back`.
// Nws yog ib txwm decremented los ntawm 1 nyob rau hauv cov kev, tab sis tsuas yog `Some(_)` yog xa rov qab.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Ceeb toom, peb tsis tshua xav tau kom phim lub caij nyoog tib ciaj sia ntau yam, yog li peb yuav tau cia li clone rau hauv offset 0 hais txog ntawm qhov chaw uas `self` yog.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Clone tag nrho ciaj sia ntsiab.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Sau ib tug clone rau hauv lub tshiab array, ces hloov nws ciaj sia ntau yam.
            // Yog hais tias cloning panics, peb mam li raug poob rau hauv lub yav dhau los cov khoom.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Tsuas yog luam tawm cov ntsiab lus uas tsis tau yauv tau: peb tsis tuaj yeem nkag mus rau cov khoom muaj txiaj ntsig ntxiv lawm.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}