//! Kev ua raws li cov khoom xws li `Eq` rau qhov ntev ntev txog rau ntev li ntev.
//! Nws thiaj li, peb yuav tsum muaj peev xwm dav dav rau txhua qhov ntev.
//!
//! *[See also the array primitive type](array).*
//!

#![stable(feature = "core_array", since = "1.36.0")]

use crate::borrow::{Borrow, BorrowMut};
use crate::cmp::Ordering;
use crate::convert::{Infallible, TryFrom};
use crate::fmt;
use crate::hash::{self, Hash};
use crate::iter::TrustedLen;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{Index, IndexMut};
use crate::slice::{Iter, IterMut};

mod iter;

#[stable(feature = "array_value_iter", since = "1.51.0")]
pub use iter::IntoIter;

/// Hloov tus siv rau `T` rau hauv kev siv mus rau ib qho array ntawm ntev 1 (yam tsis muaj luam tawm).
#[unstable(feature = "array_from_ref", issue = "77101")]
pub fn from_ref<T>(s: &T) -> &[T; 1] {
    // KEV RUAJ NTSEG: Hloov `&T` rau `&[T; 1]` yog suab.
    unsafe { &*(s as *const T).cast::<[T; 1]>() }
}

/// Hloov tus kab ke hloov mus rau `T` mus rau cov ntawv siv tau hloov mus rau ib qho ntawm qhov ntev 1 (tsis tas theej).
#[unstable(feature = "array_from_ref", issue = "77101")]
pub fn from_mut<T>(s: &mut T) -> &mut [T; 1] {
    // KEV RUAJ NTSEG: Converting `&mut T` rau `&mut [T; 1]` yog suab.
    unsafe { &mut *(s as *mut T).cast::<[T; 1]>() }
}

/// Utility trait siv tsuas yog nyob rau arrays ntawm tsau loj
///
/// Cov trait no tuaj yeem siv los siv ua lwm traits ntawm cov ntsuas qhov chaw loj me me uas tsis tas yuav ua rau ntau tus metadata bloat.
///
/// Lub trait cim tias tsis nyab xeeb kom txwv tsis pub siv rau cov khoom txwv uas tsis tsim nyog tuav.
/// Ib tus neeg siv ntawm no trait tuaj yeem xav tias cov neeg ua haujlwm ua haujlwm muaj cov qauv qhia tshwj xeeb hauv lub cim xeeb ntawm qhov ntsuas qhov loj me (piv txwv li, rau qhov pib tsis nyab xeeb).
///
///
/// Nco ntsoov tias lub traits [`AsRef`] thiab [`AsMut`] muab zoo xws li cov hau kev rau kev hom uas yuav kho tsis tau-loj arrays.
/// Cov ua yuav tsum nyiam qhov traits hloov chaw.
///
///
///
#[unstable(feature = "fixed_size_array", issue = "27778")]
pub unsafe trait FixedSizeArray<T> {
    /// Hloov pauv cov array rau immutable hlais
    #[unstable(feature = "fixed_size_array", issue = "27778")]
    fn as_slice(&self) -> &[T];
    /// Converts lub array rau mutable hlais
    #[unstable(feature = "fixed_size_array", issue = "27778")]
    fn as_mut_slice(&mut self) -> &mut [T];
}

#[unstable(feature = "fixed_size_array", issue = "27778")]
unsafe impl<T, A: Unsize<[T]>> FixedSizeArray<T> for A {
    #[inline]
    fn as_slice(&self) -> &[T] {
        self
    }
    #[inline]
    fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }
}

/// Cov kev ua yuam kev hom rov qab thaum ib tug hloov dua siab tshiab los ntawm ib tug ib nplais rau ib tug array tsis.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone)]
pub struct TryFromSliceError(());

#[stable(feature = "core_array", since = "1.36.0")]
impl fmt::Display for TryFromSliceError {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(self.__description(), f)
    }
}

impl TryFromSliceError {
    #[unstable(
        feature = "array_error_internals",
        reason = "available through Error trait and this method should not \
                     be exposed publicly",
        issue = "none"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "could not convert slice to array"
    }
}

#[stable(feature = "try_from_slice_error", since = "1.36.0")]
impl From<Infallible> for TryFromSliceError {
    fn from(x: Infallible) -> TryFromSliceError {
        match x {}
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, const N: usize> AsRef<[T]> for [T; N] {
    #[inline]
    fn as_ref(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, const N: usize> AsMut<[T]> for [T; N] {
    #[inline]
    fn as_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "array_borrow", since = "1.4.0")]
impl<T, const N: usize> Borrow<[T]> for [T; N] {
    fn borrow(&self) -> &[T] {
        self
    }
}

#[stable(feature = "array_borrow", since = "1.4.0")]
impl<T, const N: usize> BorrowMut<[T]> for [T; N] {
    fn borrow_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<T, const N: usize> TryFrom<&[T]> for [T; N]
where
    T: Copy,
{
    type Error = TryFromSliceError;

    fn try_from(slice: &[T]) -> Result<[T; N], TryFromSliceError> {
        <&Self>::try_from(slice).map(|r| *r)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<'a, T, const N: usize> TryFrom<&'a [T]> for &'a [T; N] {
    type Error = TryFromSliceError;

    fn try_from(slice: &[T]) -> Result<&[T; N], TryFromSliceError> {
        if slice.len() == N {
            let ptr = slice.as_ptr() as *const [T; N];
            // KEV RUAJ NTSEG: ok vim hais tias peb cia li mus soj ntsuam hais tias qhov ntev fits
            unsafe { Ok(&*ptr) }
        } else {
            Err(TryFromSliceError(()))
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<'a, T, const N: usize> TryFrom<&'a mut [T]> for &'a mut [T; N] {
    type Error = TryFromSliceError;

    fn try_from(slice: &mut [T]) -> Result<&mut [T; N], TryFromSliceError> {
        if slice.len() == N {
            let ptr = slice.as_mut_ptr() as *mut [T; N];
            // KEV RUAJ NTSEG: ok vim hais tias peb cia li mus soj ntsuam hais tias qhov ntev fits
            unsafe { Ok(&mut *ptr) }
        } else {
            Err(TryFromSliceError(()))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, const N: usize> Hash for [T; N] {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        Hash::hash(&self[..], state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for [T; N] {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&&self[..], f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, const N: usize> IntoIterator for &'a [T; N] {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, const N: usize> IntoIterator for &'a mut [T; N] {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "index_trait_on_arrays", since = "1.50.0")]
impl<T, I, const N: usize> Index<I> for [T; N]
where
    [T]: Index<I>,
{
    type Output = <[T] as Index<I>>::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(self as &[T], index)
    }
}

#[stable(feature = "index_trait_on_arrays", since = "1.50.0")]
impl<T, I, const N: usize> IndexMut<I> for [T; N]
where
    [T]: IndexMut<I>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(self as &mut [T], index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[B; N]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &[B; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[B; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &[B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for [B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<&[B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &&[B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &&[B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for &[B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<&mut [B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &&mut [B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &&mut [B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for &mut [B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

// NOTE: ib co tsis tseem ceeb impls yog rho los txo code bloat
// __impl_slice_eq2!{ [A; $N], &'b [B; $N] } __impl_slice_eq2! { [A; $N], &'b mut [B; $N] }
//

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, const N: usize> Eq for [T; N] {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, const N: usize> PartialOrd for [T; N] {
    #[inline]
    fn partial_cmp(&self, other: &[T; N]) -> Option<Ordering> {
        PartialOrd::partial_cmp(&&self[..], &&other[..])
    }
    #[inline]
    fn lt(&self, other: &[T; N]) -> bool {
        PartialOrd::lt(&&self[..], &&other[..])
    }
    #[inline]
    fn le(&self, other: &[T; N]) -> bool {
        PartialOrd::le(&&self[..], &&other[..])
    }
    #[inline]
    fn ge(&self, other: &[T; N]) -> bool {
        PartialOrd::ge(&&self[..], &&other[..])
    }
    #[inline]
    fn gt(&self, other: &[T; N]) -> bool {
        PartialOrd::gt(&&self[..], &&other[..])
    }
}

/// Kev sib piv kev sib piv ntawm arrays [lexicographically](Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, const N: usize> Ord for [T; N] {
    #[inline]
    fn cmp(&self, other: &[T; N]) -> Ordering {
        Ord::cmp(&&self[..], &&other[..])
    }
}

// Lub Default impls yuav tsis tau ua nrog const Generics vim hais tias `[T; 0]` tsis tau Default yuav tsum tau siv, thiab muaj ntau impl blocks rau txawv tus xov tooj yog tsis txaus siab tsis tau.
//
//

macro_rules! array_impl_default {
    {$n:expr, $t:ident $($ts:ident)*} => {
        #[stable(since = "1.4.0", feature = "array_default")]
        impl<T> Default for [T; $n] where T: Default {
            fn default() -> [T; $n] {
                [$t::default(), $($ts::default()),*]
            }
        }
        array_impl_default!{($n - 1), $($ts)*}
    };
    {$n:expr,} => {
        #[stable(since = "1.4.0", feature = "array_default")]
        impl<T> Default for [T; $n] {
            fn default() -> [T; $n] { [] }
        }
    };
}

array_impl_default! {32, T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T}

#[lang = "array"]
impl<T, const N: usize> [T; N] {
    /// Rov qab los ntawm ib qho loj ntawm tib qho me me li `self`, nrog kev ua haujlwm `f` siv rau txhua yam hauv kev txiav txim.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_map)]
    /// let x = [1, 2, 3];
    /// let y = x.map(|v| v + 1);
    /// assert_eq!(y, [2, 3, 4]);
    ///
    /// let x = [1, 2, 3];
    /// let mut temp = 0;
    /// let y = x.map(|v| { temp += 1; v * temp });
    /// assert_eq!(y, [1, 4, 9]);
    ///
    /// let x = ["Ferris", "Bueller's", "Day", "Off"];
    /// let y = x.map(|v| v.len());
    /// assert_eq!(y, [6, 9, 3, 3]);
    /// ```
    #[unstable(feature = "array_map", issue = "75243")]
    pub fn map<F, U>(self, f: F) -> [U; N]
    where
        F: FnMut(T) -> U,
    {
        // KEV RUAJ NTSEG: peb paub rau qee yam uas qhov tsim nyog no yuav tawm los tseeb `N`
        // items.
        unsafe { collect_into_array_unchecked(&mut IntoIter::new(self).map(f)) }
    }

    /// 'Zips up' ob qho arrays rau hauv ib qho kev sib txig ntawm cov khub.
    ///
    /// `zip()` rov muab qhov tshiab tso rau qhov twg txhua qhov khoom yog tuple qhov thawj lub hauv paus los ntawm tus thawj array, thiab lub caij thib ob los ntawm tus lej thib ob.
    ///
    /// Hauv lwm lo lus, nws zaws ob daim phiaj sib dhos ua ke, mus ua ib qho.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_zip)]
    /// let x = [1, 2, 3];
    /// let y = [4, 5, 6];
    /// let z = x.zip(y);
    /// assert_eq!(z, [(1, 4), (2, 5), (3, 6)]);
    /// ```
    ///
    #[unstable(feature = "array_zip", issue = "80094")]
    pub fn zip<U>(self, rhs: [U; N]) -> [(T, U); N] {
        let mut iter = IntoIter::new(self).zip(IntoIter::new(rhs));

        // KEV RUAJ NTSEG: peb paub rau qee yam uas qhov tsim nyog no yuav tawm los tseeb `N`
        // items.
        unsafe { collect_into_array_unchecked(&mut iter) }
    }

    /// Rov qab ib daig uas muaj tag nrho cov array.Sib npaug rau `&s[..]`.
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Rov qab ib rab koob uas sib hloov uas muaj tag nrho cov khoom.
    /// Sib npaug rau `&mut s[..]`.
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Borrows txhua lub caij thiab rov ua array ntawm ua tim khawv nrog cov loj tib yam li `self`.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(array_methods)]
    ///
    /// let floats = [3.1, 2.7, -1.0];
    /// let float_refs: [&f64; 3] = floats.each_ref();
    /// assert_eq!(float_refs, [&3.1, &2.7, &-1.0]);
    /// ```
    ///
    /// Txoj hau kev no muaj txiaj ntsig tshwj xeeb yog muab sib xyaw nrog lwm txoj hauv kev, zoo li [`map`](#method.map).
    /// Txoj kev no, koj tuaj yeem zam dhau qhov hloov lub qub yog tias nws cov ntsiab lus tsis yog `Copy`.
    ///
    /// ```
    /// #![feature(array_methods, array_map)]
    ///
    /// let strings = ["Ferris".to_string(), "♥".to_string(), "Rust".to_string()];
    /// let is_ascii = strings.each_ref().map(|s| s.is_ascii());
    /// assert_eq!(is_ascii, [true, false, true]);
    ///
    /// // Peb tseem tuaj yeem nkag mus rau thawj qhov array: nws tsis tau txav mus.
    /// assert_eq!(strings.len(), 3);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn each_ref(&self) -> [&T; N] {
        // KEV RUAJ NTSEG: peb paub rau qee yam uas qhov tsim nyog no yuav tawm los tseeb `N`
        // items.
        unsafe { collect_into_array_unchecked(&mut self.iter()) }
    }

    /// Borrows txhua lub ntsiab lus sib hloov thiab xa rov qab ib qho kev hloov cov lus qhia uas muaj qhov loj me ib yam li `self`.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(array_methods)]
    ///
    /// let mut floats = [3.1, 2.7, -1.0];
    /// let float_refs: [&mut f64; 3] = floats.each_mut();
    /// *float_refs[0] = 0.0;
    /// assert_eq!(float_refs, [&mut 0.0, &mut 2.7, &mut -1.0]);
    /// assert_eq!(floats, [0.0, 2.7, -1.0]);
    /// ```
    ///
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn each_mut(&mut self) -> [&mut T; N] {
        // KEV RUAJ NTSEG: peb paub rau qee yam uas qhov tsim nyog no yuav tawm los tseeb `N`
        // items.
        unsafe { collect_into_array_unchecked(&mut self.iter_mut()) }
    }
}

/// Cia li nkaum kiag `N` cov khoom los ntawm `iter` thiab rov qab rau lawv raws li ib tug array.
/// Yog hais tias lub iterator loo tsawg tshaj li `N` khoom, qhov no muaj nuj nqi teev undefined tus cwj pwm.
///
///
/// Saib [`collect_into_array`] rau cov lus qhia ntxiv.
///
/// # Safety
///
/// Nws yog nyob ntawm tus neeg hu tuaj kom lav tias `iter` yields tsawg kawg `N` khoom.
/// Kev ua txhaum txoj kev mob no ua rau tus cwj pwm tsis tau xaiv.
unsafe fn collect_into_array_unchecked<I, const N: usize>(iter: &mut I) -> [I::Item; N]
where
    // Note: `TrustedLen` no yog dog dig ntawm ib tug xyaum ua tej yam.Qhov no yog cia li ib tug
    // kev ua haujlwm sab hauv, yog li muaj kev ywj pheej los tshem tawm yog qhov khi no hloov tawm mus ua qhov tsis zoo.
    // Nyob rau hauv cov ntaub ntawv uas, nco ntsoov kuj tshem tawm cov qis ua txhua yam `debug_assert!` hauv qab no!
    //
    I: Iterator + TrustedLen,
{
    debug_assert!(N <= iter.size_hint().1.unwrap_or(usize::MAX));
    debug_assert!(N <= iter.size_hint().0);

    match collect_into_array(iter) {
        Some(array) => array,
        // KEV RUAJ NTSEG: kev pab los ntawm kev ua daim ntawv cog lus.
        None => unsafe { crate::hint::unreachable_unchecked() },
    }
}

/// Rub cov khoom `N` los ntawm `iter` thiab rov lawv li kev ua array.Yog tias tus ntsuas hluav taws xob yields tsawg dua `N` khoom, `None` xa rov qab thiab txhua qhov twb tau muab tso tawm lawm.
///
/// Vim tias tus ntsuas pa tau dhau los ua ib qho kev hloov pauv thiab qhov haujlwm no hu `next` ntawm feem ntau `N` lub sijhawm, tus kav kuj tseem tuaj yeem siv tom qab txhawm rau rov qab cov khoom seem.
///
///
/// Yog hais tias `iter.next()` panicks, tag nrho cov khoom twb yielded los ntawm lub iterator yog poob.
///
///
///
///
fn collect_into_array<I, const N: usize>(iter: &mut I) -> Option<[I::Item; N]>
where
    I: Iterator,
{
    if N == 0 {
        // KEV RUAJ NTSEG: Ib npliag array yog yeej ib txwm nyob hauv Npanpiloo thiab twb tsis muaj validity invariants.
        return unsafe { Some(mem::zeroed()) };
    }

    struct Guard<T, const N: usize> {
        ptr: *mut T,
        initialized: usize,
    }

    impl<T, const N: usize> Drop for Guard<T, N> {
        fn drop(&mut self) {
            debug_assert!(self.initialized <= N);

            let initialized_part = crate::ptr::slice_from_raw_parts_mut(self.ptr, self.initialized);

            // KEV RUAJ NTSEG: daim hlais zoo li no tsuas yog cov khoom pib xwb.
            unsafe {
                crate::ptr::drop_in_place(initialized_part);
            }
        }
    }

    let mut array = MaybeUninit::uninit_array::<N>();
    let mut guard: Guard<_, N> =
        Guard { ptr: MaybeUninit::slice_as_mut_ptr(&mut array), initialized: 0 };

    while let Some(item) = iter.next() {
        // KEV RUAJ NTSEG: `guard.initialized` pib ntawm 0, yog tau nce los ntawm ib qho hauv qhov
        // lub voj thiab lub voj raug rho tawm thaum nws nce mus txog N (uas yog `array.len()`).
        //
        unsafe {
            array.get_unchecked_mut(guard.initialized).write(item);
        }
        guard.initialized += 1;

        // Kuaj xyuas yog tias tag nrho cov qauv tau pib ua ntej.
        if guard.initialized == N {
            mem::forget(guard);

            // KEV RUAJ NTSEG: qhov xwm txheej saum toj saud tau hais tias txhua yam yog
            // initialized.
            let out = unsafe { MaybeUninit::array_assume_init(array) };
            return Some(out);
        }
    }

    // Qhov no tsuas yog ncav cuag yog tias tus ntsuas hluav taws xob ua kom nruj ua ntej `guard.initialized` txog `N`.
    //
    // Tsis tas li ntawd nco ntsoov tias `guard` yog poob ntawm no, xa me nyuam rov tag nrho cov twb initialized ntsiab.
    None
}