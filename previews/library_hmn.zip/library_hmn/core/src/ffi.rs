#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! Cov hluav taws xob muaj feem xyuam nrog kev ua haujlwm txawv teb chaws cuam tshuam (FFI) khi.

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// Sib npaug rau C cov `void` hom thaum siv raws li ib tug [pointer].
///
/// Hauv cov ntsiab lus, `*const c_void` yog sib npaug rau C's `const void*` thiab `*mut c_void` yog sib npaug rau C's `void*`.
/// Uas hais tias, qhov no yog *tsis* tib yam li C lub `void` rov qab yam, uas yog Rust lub `()` hom.
///
/// Qauv pointers rau opaque hom nyob rau hauv FFI, kom txog thaum `extern type` stabilized, nws yog pom zoo kom siv ib tug newtype wrapper nyob ib ncig ntawm ib qho kev npliag byte array.
///
/// Saib rau [Nomicon] kom paub meej.
///
/// Ib tug yuav siv `std::os::raw::c_void` yog hais tias lawv xav tau los pab txhawb cov laus Rust compiler down rau 1.1.0.
/// Tom qab Rust 1.30.0, nws twb rov exported los ntawm lub ntsiab txhais no.
/// Yog xav paub ntxiv, thov nyeem [RFC 2521].
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// NB, rau LLVM kom paub txog qhov khoob khoob pointer yam thiab los ntawm kev txuas ntxiv cov haujlwm zoo ib yam li malloc(), peb xav kom muaj nws sawv cev raws li i8 * hauv LLVM bitcode.
// Lub enum siv no kom qhov no thiab tiv thaiv siv tsis ntawm lub "raw" hom los tsuas muaj private variants.
// Peb yuav tsum tau ob variants, vim hais tias cov compiler yws txog cov repr attribute tsis thiab peb yuav tsum tau yam tsawg ib variant li txwv tsis pub tus enum yuav tsis muaj neeg nyob thiab tsawg kawg yog dereferencing xws pointers yuav UB.
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// Basic kev siv ntawm ib tug `va_list`.
// Lub npe yog WIP, siv `VaListImpl` rau tam sim no.
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // Tsis pom dhau `'f`, yog li txhua qhov `VaListImpl<'f>` khoom siv tau khi rau thaj tsam ntawm txoj haujlwm nws tau hais tseg hauv
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 ABI kev siv ib qho `va_list`.
/// Saib rau [AArch64 Procedure Call Standard] kom paub meej ntxiv.
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC ABI kev siv ib qho `va_list`.
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 ABI kev siv ib qho `va_list`.
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// Ib tug wrapper rau ib tug `va_list`
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Hloov tus `VaListImpl` rau `VaList` uas yog binary-tau tshaj nrog C's `va_list`.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Hloov tus `VaListImpl` rau `VaList` uas yog binary-tau tshaj nrog C's `va_list`.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// Lub VaArgSafe trait xav tau los siv rau hauv kev cuam tshuam hauv tsoomfwv, txawm li cas los xij, trait nws tus kheej yuav tsum tsis raug tso cai siv nyob sab nraud ntawm tus qauv no.
// Yog tias peb cia rau cov neeg mus siv lub trait rau ib tug tshiab hom (li uas lub va_arg intrinsic yuav tsum tau siv nyob rau hauv ib tug tshiab hom) yog yuav ua rau undefined tus cwj pwm.
//
// FIXME(dlrobertson): Txhawm rau siv VaArgSafe trait nyob rau hauv kev sib txuas lus rau pej xeem tab sis kuj paub tseeb tias nws tsis tuaj yeem siv lwm qhov, trait xav tau rau pej xeem nyob hauv tus kheej ntiag tug.
// Thaum RFC 2145 tau raug siv saib mus rau hauv kev txhim kho no.
//
//
//
//
mod sealed_trait {
    /// Trait uas tso cai rau cov hom uas raug tso cai siv nrog [super::VaListImpl::arg].
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Ua ntej rau qhov sib ceg tom ntej.
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // KEV RUAJ NTSEG: tus neeg hu yuav tsum khaws daim ntawv cog lus muaj kev nyab xeeb rau `va_arg`.
        unsafe { va_arg(self) }
    }

    /// Luam cov `va_list` nyob rau tam sim no qhov chaw.
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // KEV RUAJ NTSEG: tus neeg hu yuav tsum khaws daim ntawv cog lus muaj kev nyab xeeb rau `va_end`.
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // KEV RUAJ NTSEG: peb sau rau `MaybeUninit`, yog li nws pib thiab `assume_init` yog kev cai
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: qhov no yuav tsum hu rau `va_end`, tab sis tsis muaj txoj kev huv rau
        // lav tsis tau tias `drop` yeej ib txwm twg thiaj li raug inlined rau hauv nws cov kev hem, yog li lub `va_end` yuav tau ncaj qha hu ua los ntawm lub tib lub muaj nuj nqi raws li lub sib nug xov `va_copy`.
        // `man va_end` hais tias C yuav tsum muaj qhov no, thiab LLVM cia li ua raws li C semantics, yog li peb yuav tsum paub tseeb tias `va_end` ib txwm hu los ntawm cov haujlwm ib yam li `va_copy`.
        //
        // Yog xav paub ntxiv cov ntsiab lus, see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // Qhov no ua hauj lwm rau tam sim no, txij li thaum `va_end` yog ib tug tsis muaj-op rau tag nrho cov tam sim no LLVM lub hom phaj.
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// Txov cov kev sib cav `ap` tom qab pib nrog `va_start` lossis `va_copy`.
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// Luam tawm qhov chaw nyob tam sim no ntawm kev sib cav `src` mus rau kev sib ceg `dst`.
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// Loads ib tug sib cav yam `T` los ntawm cov `va_list` `ap` thiab increment lub cav `ap` cov ntsiab lus rau.
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}