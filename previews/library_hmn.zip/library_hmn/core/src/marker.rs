//! Txheej thaum ub traits thiab hom uas sawv cev rau yooj yim thaj chaw ntawm ntau hom.
//!
//! Rust hom yuav txwv kom muab zais nyob rau hauv ntau yam pab tau txoj kev raws li lawv intrinsic zog.
//! Cov classifications yog muaj tuaj raws li traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Hom uas yuav pab tau thoob plaws xov ib thaj tsam.
///
/// Qhov no trait yog txiav los siv thaum lub compiler txiav txim nws yog tsim nyog.
///
/// Ib qho piv txwv ntawm ib tug uas tsis yog-`Send` hom yog cov siv-suav pointer [`rc::Rc`][`Rc`].
/// Yog hais tias ob threads sim clone ['Rc`] s uas taw tes rau cov tib reference-suav nqi, tej zaum lawv yuav sim los mus hloov cov phau ntawv count nyob rau tib lub sij hawm, uas yog [undefined behavior][ub] vim hais tias [`Rc`] tsis siv atomic operations.
///
/// Nws tus viv ncaus [`sync::Arc`][arc] puas siv atomic ua hauj lwm (incurring ib co nyiaj siv ua haujlwm) thiab yog li yog `Send`.
///
/// Saib [the Nomicon](../../nomicon/send-and-sync.html) kom paub meej ntxiv.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Hom nrog ib tug qhov luaj li cas paub nyob compile lub sij hawm.
///
/// Txhua hom tsis tau muaj kev cuam tshuam txog `Sized`.Qhov tshwj xeeb syntax `?Sized` yuav siv tau los tshem tawm no ua txhua yam yog hais tias nws tsis tsim nyog.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//kev ua yuam kev: tsuas yog tsis muab siv rau [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Lub ib tug kos yog lub implicit `Self` hom ntawm ib tug trait.
/// A trait tsis muaj qhov cuam tshuam nrog `Sized` ua txhua qhov vim qhov no tsis sib xws nrog [trait khoom] s qhov twg, los ntawm kev txhais, trait xav tau kev ua haujlwm nrog txhua tus ua tau raws, thiab li no tuaj yeem yog qhov loj me.
///
///
/// Txawm tias Rust yuav qhia rau koj khi `Sized` mus rau ib tug trait, koj yuav tsis muaj peev xwm siv nws los tsim ib tug trait khoom tom qab:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // cia y: &dyn Bar= &Impl;//kev ua yuam kev: cov trait `Bar` yuav tsis tau mus rau hauv ib tug kwv
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // rau Default, piv txwv, uas yuav tsum kom `[T]: !Default` tuaj yeem ntsuas tau
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Hom uas yuav ua tau "unsized" mus rau ib tug dynamically-sized hom.
///
/// Piv txwv li, lub me array hom `[i8; 2]` siv `Unsize<[i8]>` thiab `Unsize<dyn fmt::Debug>`.
///
/// Tag nrho cov kev coj ua ntawm `Unsize` tau muab los ntawm cov compiler.
///
/// `Unsize` tau muab los siv rau:
///
/// - `[T; N]` yog `Unsize<[T]>`
/// - `T` yog `Unsize<dyn Trait>` thaum `T: Trait`
/// - `Foo<..., T, ...>` yog `Unsize<Foo<..., U, ...>>` yog hais tias:
///   - `T: Unsize<U>`
///   - Foo yog kev teeb tsa
///   - Tsuas yog tus kawg teb ntawm `Foo` muaj ib yam uas `T`
///   - `T` tsis yog ib feem ntawm cov hom ntawm lwm daim teb
///   - `Bar<T>: Unsize<Bar<U>>`, yog hais tias tus kawg teb ntawm `Foo` muaj hom `Bar<T>`
///
/// `Unsize` yog siv nrog rau [`ops::CoerceUnsized`] tso cai rau "user-defined" xws li [`Rc`] kom muaj dynamically-sized hom.
/// Saib cov [DST coercion RFC][RFC982] thiab [the nomicon entry on coercion][nomicon-coerce] kom paub meej ntxiv.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Yuav tsum tau trait rau constants siv nyob rau hauv tus qauv qhov yuam kev.
///
/// Txhua yam uas neeg nyiam `PartialEq` siv qhov no trait,*tsis hais* ntawm seb nws yam-tsis siv `Eq`.
///
/// Yog hais tias ib tug `const` yam khoom muaj ib co hom uas tsis siv no trait, ces hais tias hom twg los (1.) tsis siv `PartialEq` (uas txhais tau tias qhov yuav tsis muab hais tias kev sib piv txoj kev, uas code tiam assumes yog muaj), los yog (2.) nws implements *nws tus kheej* version ntawm `PartialEq` (uas peb xav tias tsis ua raws li cov qauv sib luag-kev sib txig sib luag).
///
///
/// Nyob rau hauv tog twg los ntawm lub ob scenarios saum toj no, peb tsis kam ua pab ntawm xws li ib tug tsis tu ncua nyob rau hauv ib tug qauv match.
///
/// Saib kuj lub [structural match RFC][RFC1445], thiab [issue 63438] uas mob siab migrating los ntawm attribute-raws li tsim los no trait.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Yuav tsum tau trait rau constants siv nyob rau hauv tus qauv qhov yuam kev.
///
/// Txhua yam uas ua rau `Eq` tau siv qhov no trait,*tsis hais* ntawm seb nws hom tsis siv `Eq`.
///
/// Qhov no yog ib tug hack mus ua hauj lwm nyob ib ncig ntawm ib tug txwv nyob rau hauv peb hom system.
///
/// # Background
///
/// Peb xav kom yuav tsum tau hais tias hom consts siv nyob rau hauv tus qauv ntais ntawv muaj cov attribute `#[derive(PartialEq, Eq)]`.
///
/// Nyob rau hauv ib tug ntau zoo tagnrho lub ntiaj teb no, peb yuav xyuas tias yuav tsum tau los cia li xyuas hais tias cov muab hom implements ob lub `StructuralPartialEq` trait *thiab* cov `Eq` trait.
/// Txawm li cas los, koj yuav muaj ADTs uas *ua*`derive(PartialEq, Eq)`, thiab yuav yog ib tug cov ntaub ntawv uas peb xav kom cov compiler mus txais, thiab tsis tau lub qhov lub hom tsis siv `Eq`.
///
/// Namely, ib rooj plaub zoo li no:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Qhov teeb meem nyob rau hauv lub saum toj no code yog tias `Wrap<fn(&())>` tsis siv `PartialEq`, tsis `Eq`, vim hais tias 'rau <' ib tug> fn(&'a _)` does not implement those traits.)
///
/// Yog li ntawd, peb yuav tsis cia siab rau naïve daim tshev rau cov `StructuralPartialEq` thiab mere `Eq`.
///
/// Raws li ib tug hack mus ua hauj lwm nyob ib ncig ntawm no, peb siv nyias traits txhaj los ntawm txhua tus ntawm cov ob derives (`#[derive(PartialEq)]` thiab `#[derive(Eq)]`) thiab check hais tias ob ntawm lawv yog cov tam sim no raws li ib feem ntawm cov yam ntxwv-match checking.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Hom uas nws qhov tseem ceeb yuav tsum duplicated tsuas yog luam khoom.
///
/// Yog lub neej ntawd, nce mus nce los nabkaus muaj 'txav semantics.'Hauv lwm lo lus:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` tau tsiv mus rau hauv `y`, thiab thiaj li yuav siv tsis tau
///
/// // println! ("{: ?}", x);//kev ua yuam kev: siv ntawm Khiav nqi
/// ```
///
/// Txawm li cas los, Yog hais tias ib yam implements `Copy`, nws es tsis txhob muaj 'luam semantics':
///
/// ```
/// // Peb tuaj yeem txais lub `Copy` siv.
/// // `Clone` yog tseem yuav tsum tau, raws li nws yog ib tug supertrait ntawm `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` yog ib daim qauv ntawm `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Nws yog ib qho tseem ceeb kom nco ntsoov tias nyob rau hauv no ob piv txwv, qhov txawv tsuas yog seb koj puas tso cai rau kev nkag `x` tom qab lub ntus.
/// Nyob rau hauv lub hood, ob leeg ib daim ntawv thiab ib tug txav yuav ua nyob rau hauv cov khoom raug theej nyob rau hauv lub cim xeeb, txawm hais tias qhov no yog tej zaum qhov zoo tam sim ntawd.
///
/// ## Yuav ua li cas Kuv yuav siv `Copy`?
///
/// Muaj ob txoj hauv kev los siv `Copy` ntawm koj hom.Qhov yooj yim yog siv `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Koj yuav tau siv `Copy` thiab `Clone` manually:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Muaj qhov sib txawv me me ntawm ob: `derive` lub tswv yim kuj tseem yuav tso `Copy` ua txhua yam ntawm cov hom tsis, uas tsis yog ib txwm xav tau.
///
/// ## Yuav ua li cas yog qhov txawv ntawm `Copy` thiab `Clone`?
///
/// Luam tshwm sim implicitly, piv txwv li raws li ib feem ntawm ib txoj hauj lwm `y = x`.Cov cwj pwm ntawm cov `Copy` yog tsis overloadable;nws yog ib txwm ib tug yooj yim me ntsis-paub qab hau daim ntawv.
///
/// Cloning yog ib qho qhia tau meej heev txiav txim, `x.clone()`.Qhov kev siv ntawm [`Clone`] tuaj yeem muab txhua yam kev coj cwj pwm uas tsim nyog los theej tawm cov txiaj ntsig kev nyab xeeb.
/// Piv txwv li, qhov kev siv ntawm [`Clone`] rau [`String`] xav luam cov taw-rau txoj hlua tsis nyob hauv qhov heap.
/// Ib tug yooj yim Bitwise daim qauv ntawm [`String`] qhov tseem ceeb yuav pawg luam cov pointer, ua rau ib tug muab ob npaug rau dawb los ntawm kab.
/// Vim li no, [`String`] yog [`Clone`] tab sis tsis yog `Copy`.
///
/// [`Clone`] yog ib tug supertrait ntawm `Copy`, li ntawd, txhua yam uas yog `Copy` yuav tsum tau siv [`Clone`].
/// Yog hais tias ib yam yog `Copy` ces nws [`Clone`] siv xwb yuav tsum tau rov qab mus `*self` (tus piv txwv saum toj no).
///
/// ## Thaum twg kuv hom tuaj yeem yog `Copy`?
///
/// Ib tug hom yuav siv `Copy` hais tias tag nrho ntawm nws lub Cheebtsam siv `Copy`.Piv txwv, tus qauv no tuaj yeem yog `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Ib tug struct yuav ua tau `Copy`, thiab [`i32`] yog `Copy`, yog li ntawd `Point` yog tsim nyog yuav tsum tau `Copy`.
/// Los ntawm qhov tsis sib xws, xav txog
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// Lub struct `PointList` yuav tsis siv `Copy`, vim hais tias [`Vec<T>`] yog tsis `Copy`.Yog hais tias peb sim rau neeg ib `Copy` siv, peb yuav tau ib qho yuam kev:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Sib chiv keeb (`&T`) kuj `Copy`, li ntawd, ib hom yuav ua tau `Copy`, txawm tias thaum nws tuas muab qhia ua tim khawv ntawm hom `T` uas yog *tsis*`Copy`.
/// Xav txog cov nram qab no struct, uas yuav siv `Copy`, vim hais tias nws tsuas tuav ib tug *qhia siv* rau peb uas tsis yog-`Copy` hom `PointList` los ntawm saum toj no:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Thaum *tsis tau* Kuv hom yog `Copy`?
///
/// Ib txhia hom tsis tau theej yam xyuam xim.Piv txwv li, theej theej `&mut T` yuav tsim kev cai siv kev hloov pauv uas siv tau.
/// Luam [`String`] yuav theej tawm lub luag hauj lwm rau kev tswj cov ['String`]' s tsis, ua rau ib tug muab ob npaug rau free.
///
/// Generalizing rau tom kawg cov ntaub ntawv, txhua yam kev siv [`Drop`] tsis tau `Copy`, vim hais tias nws yog tswj ib co kev pab dua li nws tus kheej [`size_of::<T>`] bytes.
///
/// Yog hais tias koj sim siv `Copy` rau ib tug struct los yog enum muaj uas tsis yog-`Copy` cov ntaub ntawv, koj yuav tau txais cov kev ua yuam kev [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Thaum *yuav tsum* kuv hom yuav `Copy`?
///
/// Feem ntau hais lus, Yog hais tias koj hom _can_ siv `Copy`, nws yuav tsum.
/// Khaws nyob rau hauv lub siab, tab sis yog, uas siv `Copy` yog ib feem ntawm cov pej xeem API ntawm koj hom.
/// Yog hais tias hom yuav dhau los ua tsis-`Copy`nyob rau hauv future, nws tuaj yeem ua qhov tsis zoo rau kev tso tseg `Copy` tam sim no, kom tsis txhob muaj qhov hloov API tawg.
///
/// ## Cov neeg siv ntxiv
///
/// Ntxiv nrog rau [implementors listed below][impls], cov hom hauv qab no tseem siv `Copy`:
///
/// * Muaj nuj nqi yam khoom (piv txwv li, cov sib txawv txhais tau rau txhua qhov haujlwm)
/// * Muaj nuj nqi pointer hom (piv txwv li, `fn() -> i32`)
/// * Cov qauv Array, rau txhua qhov ntau thiab tsawg, yog tias yam khoom ntawd kuj siv `Copy` (piv txwv li, `[i32; 123456]`)
/// * Tuple hom, Yog hais tias txhua tivthaiv kuj siv `Copy` (eg, `()`, `(i32, bool)`)
/// * Kaw hom, yog hais tias lawv ntes tsis muaj nqi los ntawm cov ib puag ncig los yog hais tias tag nrho xws li yog tej qhov tseem ceeb kev `Copy` lawv tus kheej.
///   Nco ntsoov tias cov tsiaj ntawv yuav los ntawm sib koom siv ib txwm siv `Copy` (txawm yog hais tias tus referent tsis), thaum ntau yam yuav los ntawm mutable siv tsis siv `Copy`.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Qhov no pub rau luam ib hom uas tsis siv `Copy` vim hais tias ntawm tsis txaus siab lub neej bounds (luam `A<'_>` thaum tsuas `A<'static>: Copy` thiab `A<'_>: Clone`).
// Peb muaj cov cwj pwm ntawm no rau tam sim no tsuas yog vim tias muaj qee qhov tshwj xeeb uas twb muaj lawm hauv `Copy` uas twb muaj nyob hauv cov tsev qiv ntawv tus qauv, thiab tsis muaj txoj hauv kev nyab xeeb rau qhov kev coj cwj pwm tam sim no.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Neeg macro generating ib tug impl ntawm lub trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Hom rau cov uas nws muaj kev ruaj ntseg rau qhia ua tim khawv ntawm threads.
///
/// Qhov no trait yog txiav los siv thaum lub compiler txiav txim nws yog tsim nyog.
///
/// Cov leej txhais yog: ib hom `T` yog [`Sync`] yog tias thiab tsuas yog tias `&T` yog [`Send`].
/// Nyob rau hauv lwm yam lus, yog hais tias muaj yog tsis muaj tau ntawm [undefined behavior][ub] (xws li cov ntaub ntawv haiv neeg) thaum dua `&T` ua tim khawv ntawm threads.
///
/// Raws li ib tug yuav txais, txheej thaum ub hom zoo li [`u8`] thiab [`f64`] yog tag nrho cov [`Sync`], thiab thiaj li yog yooj yim sau ua ib pawg hom uas muaj lawv, zoo li tuples, structs thiab enums.
/// Ntau cov piv txwv ntawm cov theem pib [`Sync`] suav nrog "immutable" hom zoo li `&T`, thiab cov uas muaj kev hloov pauv yooj yim, xws li [`Box<T>`][box], [`Vec<T>`][vec] thiab feem ntau lwm yam kev sib sau.
///
/// (Kev ntsuas dav dav yuav tsum yog [`Sync`] rau lawv lub thawv kom yog [`Sync`].)
///
/// Ib qho kev xav tsis txaus ntseeg ntawm lub ntsiab txhais yog `&mut T` yog `Sync` (yog `T` yog `Sync`) txawm tias nws zoo li uas yuav muab kev hloov tsis ua haujlwm.
/// Qhov ua kom yuam yog hais tias ib tug mutable siv qab ib tug sib reference (uas yog, `& &mut T`) yuav nyeem nkaus xwb, raws li yog hais tias nws yog ib tug `& &T`.
/// Li no muaj yog tsis muaj hmoo ntawm ib tug cov ntaub ntawv haiv neeg.
///
/// Hom uas tsis `Sync` yog cov uas muaj "interior mutability" nyob rau hauv ib tug uas tsis yog-xov-kev nyab xeeb daim ntawv no, xws li [`Cell`][cell] thiab [`RefCell`][refcell].
/// Cov pub rau hloov ntawm lawv txheem txawm los ntawm ib tug immutable, qhia siv.
/// Piv txwv li cov `set` txoj kev rau [`Cell<T>`][cell] yuav siv sij hawm `&self`, ces nws yuav tsum tsuas yog ib tug sib reference [`&Cell<T>`][cell].
/// Cov qauv ua tsis muaj synchronization, yog li [`Cell`][cell] tsis tuaj yeem yog `Sync`.
///
/// Lwm cov piv txwv ntawm ib tug uas tsis yog-`Sync` hom yog cov siv-suav pointer [`Rc`][rc].
/// Muab kev siv [`&Rc<T>`][rc], koj yuav clone ib tug tshiab [`Rc<T>`][rc], modifying siv suav nyob rau hauv ib tug uas tsis yog-atomic txoj kev.
///
/// Rau tus neeg mob thaum muaj ib tug tsis xav tau xov-kev nyab xeeb sab hauv mutability, Rust muab [atomic data types], raws li zoo raws li qhia tau meej heev locking ntawm [`sync::Mutex`][mutex] thiab [`sync::RwLock`][rwlock].
/// Cov xyuas kom meej tias txhua yam kev hloov yuav tsis ua cov ntaub ntawv haiv neeg, li no tus yam yog `Sync`.
/// Ib yam li ntawd, [`sync::Arc`][arc] muab xov-zoo kab ntawm [`Rc`][rc].
///
/// Tej yam uas sab hauv mutability yuav tsum tau siv cov [`cell::UnsafeCell`][unsafecell] wrapper nyob ib ncig ntawm lub value(s) uas yuav mutated los ntawm ib tug muab qhia siv.
/// Tsis ua li no yog [undefined behavior][ub].
/// Piv txwv li, ['transmute`][transmute]-ing los ntawm `&T` rau `&mut T` yog invalid.
///
/// Saib [the Nomicon][nomicon-send-and-sync] rau cov lus qhia ntxaws ntxiv txog `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): ib zaug kev pab txhawb nqa ntxiv sau ntawv nyob rau hauv `rustc_on_unimplemented` av nyob rau hauv beta, thiab nws twb tau ncua mus xyuas seb ib tug kaw yog nyob qhov twg nyob rau hauv lub qhov yuav tsum tau saw, cuag nws xws li (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Cov xoom xaim hom siv los kos cim khoom uas "act like" lawv muaj `T` X.
///
/// Ntxiv `PhantomData<T>` teb rau koj hom qhia lub compiler tias koj hom ua zoo li nws khaws tus nqi ntawm hom `T`, txawm tias nws tsis tshua.
/// Cov ntaub ntawv no yog siv thaum laij tej kev nyab xeeb zog.
///
/// Rau ib tug ntau nyob rau hauv-tob qhia txog yuav ua li cas siv `PhantomData<T>`, thov mus saib [the Nomicon](../../nomicon/phantom-data.html).
///
/// # Ib tug ghastly ntawv 👻👻👻
///
/// Txawm hais tias lawv ob leeg muaj npe txaus ntshai, `PhantomData` thiab 'phantom yam' muaj feem xyuam, tab sis tsis zoo tib yam.Ib tug phantom hom parameter tsuas yog ib hom parameter uas yog yeej tsis siv.
/// Nyob rau hauv Rust, qhov no feem ntau ua rau cov compiler kev tsis txaus siab, thiab cov tshuaj no rau ntxiv ib "dummy" siv los ntawm txoj kev ntawm `PhantomData`.
///
/// # Examples
///
/// ## Tsis Siv lub neej tsis
///
/// Tej zaum cov feem ntau ntau siv cov ntaub ntawv rau `PhantomData` yog ib tug struct uas muaj ib tug tsis siv lub neej parameter, feem ntau raws li ib feem ntawm ib co tsis zoo code.
/// Piv txwv li, ntawm no yog ib tug struct `Slice` uas muaj ob pointers yam `*const T`, txawm taw mus rau hauv ib qho array qhov chaw:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Lub tswv yim yog hais tias lub qhov pib cov ntaub ntawv no tsuas yog siv tau rau lub neej `'a`, yog li `Slice` yuav tsum tsis txhob outlive `'a`.
/// Txawm li cas los, qhov no yog txhob txwm tsis yog qhia nyob rau hauv cov kev cai, vim muaj cov tsis muaj kev siv ntawm lub neej `'a` thiab li no nws tsis yog luaj li cas cov ntaub ntawv nws siv tau.
/// Peb yuav kho no los ntawm kev qhia cov compiler ua *raws li yog hais* lub `Slice` struct muaj ib tug siv `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Qhov no kuj nyob rau hauv lem yuav tsum muaj tus lej `T: 'a`, qhia tias txhua nqe lus hauv `T` siv tau dhau ntawm lub neej `'a`.
///
/// Thaum pib `Slice` koj tsuas muab tus nqi `PhantomData` rau daim teb `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Tsis Siv hom tsis
///
/// Nws zaum kuj tshwm sim hais tias koj muaj tsis siv hom tsis uas qhia seb hom ntawm cov ntaub ntawv ib tug struct yog "tied" rau, txawm tias cov ntaub ntawv ntawd yog tsis tau pom nyob rau hauv lub struct nws tus kheej.
/// Ntawm no yog ib qho piv txwv uas qhov no tshwm sim nrog [FFI].
/// Lub txawv teb chaws interface siv saib xyuas ntawm hom `*mut ()` rau xa mus rau Rust qhov tseem ceeb ntawm ntau hom.
/// Peb taug qab Rust hom siv phantom hom ntsuas ntawm tus qauv `ExternalResource` uas qhwv ib tus kov.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Tswv cuab thiab txoj kev nco check
///
/// Ntxiv ib daim teb ntawm hom `PhantomData<T>` ntawd hais tias koj hom tswv cov ntaub ntawv ntawm hom `T`.Qhov no nyob rau hauv lem implies hais tias thaum koj hom yog poob, tej zaum nws yuav poob ib los yog ntau tshaj piv txwv ntawm cov hom `T`.
/// Qhov no muaj cov kabmob ntawm Rust compile tus [drop check] tsom.
///
/// Yog hais tias koj struct tsis nyob rau hauv qhov tseeb *tus kheej* cov ntaub ntawv ntawm hom `T`, nws yog zoo dua rau siv ib tug siv hom, xws li `PhantomData<&'a T>` (ideally) los yog `PhantomData<*const T>` (yog tias tsis muaj lub neej siv), thiaj li tsis mus qhia cov tswv cuab.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Compiler-nrog trait siv los qhia tias lub hom enum discriminants.
///
/// Qhov no trait yog txiav los siv rau txhua txhua hom thiab tsis ntxiv tej guarantees rau [`mem::Discriminant`].
/// Nws yog **undefined tus cwj pwm** rau transmute ntawm `DiscriminantKind::Discriminant` thiab `mem::Discriminant`.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Lub hom ntawm cov discriminant, uas yuav tsum los siav trait bounds yuav tsum tau los ntawm `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Compiler-internal trait siv los txiav txim siab seb ib hom puas muaj `UnsafeCell` sab hauv, tab sis tsis dhau los ntawm kev txiav txim siab.
///
/// Qhov no muaj feem xyuam rau, piv txwv li, seb ib tug `static` ntawm hom yog muab tso rau hauv nyeem nkaus xwb zoo li qub cim xeeb los yog writable zoo li qub nco.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Hom uas yuav xyuam xim tsiv tom qab paib.
///
/// Rust nws tus kheej tsis muaj kev paub txog hom kev txav tsis tau, thiab txiav txim siab tsiv (piv txwv li, los ntawm kev muab haujlwm lossis [`mem::replace`]) kom muaj kev nyab xeeb tas mus li.
///
/// Qhov [`Pin`][Pin] hom yog siv los tiv thaiv kev tsiv los ntawm hom system.Pointers `P<T>` qhwv nyob rau hauv lub [`Pin<P<T>>`][Pin] wrapper tsis tau tsiv tawm ntawm.
/// Saib cov [`pin` module] cov ntaub ntawv rau cov lus qhia ntxiv nyob rau hauv pinning.
///
/// Siv lub `Unpin` trait rau `T` lawd cov kev txwv ntawm pinning tawm hom, uas ces tso cai tsiv `T` tawm ntawm [`Pin<P<T>>`][Pin] nrog zog xws li [`mem::replace`].
///
///
/// `Unpin` muaj tsis muaj qhov tsim nyog tau rau tag nrho cov uas tsis yog-pinned cov ntaub ntawv.
/// Hauv tshwj xeeb, [`mem::replace`] zoo siab txav `!Unpin` cov ntaub ntawv (nws ua haujlwm rau ib qho `&mut T`, tsis yog thaum `T: Unpin`).
/// Txawm li cas los, koj siv tsis tau [`mem::replace`] ntawm cov ntaub ntawv qhwv hauv ib [`Pin<P<T>>`][Pin] vim hais tias koj tsis tau txais lub `&mut T` koj xav tau rau cov uas, thiab *uas* yog dab tsi ua rau qhov no system ua hauj lwm.
///
/// Yog li no, piv txwv li, tsuas yuav ua li cas rau hom kev siv `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Peb yuav tsum tau ib tug mutable siv hu mus rau `mem::replace`.
/// // Peb tuaj yeem tau txais cov lus qhia los ntawm (implicitly) ua rau `Pin::deref_mut`, tab sis qhov ntawd tsuas yog ua tau vim `String` siv `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Qhov no trait yog txiav los siv rau yuav luag txhua yam.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Ib tug marker hom uas tsis siv `Unpin`.
///
/// Yog tias ib hom muaj tus `PhantomPinned`, nws yuav tsis siv `Unpin` los ntawm lub neej ntawd.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Implementations ntawm `Copy` rau txheej thaum ub hom.
///
/// Kev coj ua uas tsis tuaj yeem piav qhia hauv Rust yog nqis tes hauv `traits::SelectionContext::copy_clone_conditions()` hauv `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Sib neeg ua tim khawv yuav tsum tau theej, tab sis mutable ua tim khawv *yuav tsis*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}