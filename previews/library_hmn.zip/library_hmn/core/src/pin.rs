//! Lub hom uas pin cov ntaub ntawv rau nws qhov chaw nyob nco.
//!
//! Nws yog qee zaum muaj txiaj ntsig kom muaj cov khoom uas tau lees tias tsis txav chaw, hauv kev nkag siab tias lawv qhov kev tso kawm hauv lub cim xeeb tsis hloov, thiab yog li tuaj yeem tso siab tau.
//! Ib qho piv txwv zoo tshaj plaws ntawm qhov kev tshwm sim yuav yog kev txhim kho tus kheej kev teeb tsa tus kheej, raws li kev txav khoom nrog cov taw tes rau nws tus kheej yuav ua rau lawv tsis muaj peev xwm, uas tuaj yeem ua rau tus cwj pwm tsis paub tseeb.
//!
//! Thaum theem siab, [`Pin<P>`] ua kom qhov chaw ntawm txhua lub pointer hom `P` muaj qhov chaw ruaj khov hauv lub cim xeeb, txhais tau tias nws tsis tuaj yeem txav mus rau lwm qhov thiab nws lub cim xeeb tsis tuaj yeem siv tau kom txog thaum nws poob.Peb hais tias lub pointee yog "pinned".Yam tau txais ntau qhov kev paub tsis meej thaum sib tham txog hom uas sib txuas cov pin nrog cov ntaub ntawv tsis-pinned;[see below](#projections-and-structural-pinning) rau cov lus qhia ntxiv.
//!
//! Yog lub neej ntawd, tag nrho cov hom nyob rau hauv Rust yog rooj noj.
//! Rust tso cai rau dhau txhua yam los ntawm-tus nqi, thiab cov hom ntse-pointer xws li [`Box<T>`] thiab `&mut T` tso cai hloov thiab hloov cov nqi uas lawv muaj: koj tuaj yeem txav tawm ntawm [`Box<T>`], lossis koj tuaj yeem siv [`mem::swap`].
//! [`Pin<P>`] qhwv lub pointer hom `P`, yog li [`Pin`] `<` [`Lub thawv]`<T>> `haujlwm ntau npaum li ib txwm ua
//!
//! [`Box<T>`]: when a [`Pin`] Aa <`[` Box`]`<T>> `tau poob, yog li ua nws cov ntsiab lus, thiab lub cim xeeb tau txais
//!
//! sib ceg.Zoo sib xws, [`Pin`] `<&mut T>` yog ntau yam xws li `&mut T`.Txawm li cas los, [`Pin<P>`] tsis cia cov neeg ua tau tau ib tug [`Box<T>`] los yog `&mut T` rau pinned cov ntaub ntawv, uas implies hais tias koj muaj peev xwm siv tsis tau ua hauj lwm xws li [`mem::swap`]:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` xav tau `&mut T`, tab sis peb tsis tuaj yeem tau txais nws.
//!     // Peb tau daig, peb tsis tuaj yeem hloov lub ntsiab lus ntawm cov ntawv pov thawj.
//!     // Peb tuaj yeem siv `Pin::get_unchecked_mut`, tab sis qhov tsis zoo rau qhov laj thawj:
//!     // peb tsis raug tso cai siv nws rau kev txav khoom tsiv tawm ntawm `Pin`.
//! }
//! ```
//!
//! Nws tsim nyog rov qab hais tias [`Pin<P>`] tsis *tsis* hloov qhov tseeb tias Rust suav sau tag nrho txhua yam kev txav tau.[`mem::swap`] tseem tuaj yeem hu tau rau txhua `T`.Es tsis txhob, [`Pin<P>`] tiv thaiv tej yam *qhov tseem ceeb*(taw tes rau los ntawm pointers qhwv nyob rau hauv [`Pin<P>`]) los yog tsiv los ua rau nws tsis yooj yim sua kom koj hu rau txoj kev uas yuav tsum tau `&mut T` rau lawv (xws li [`mem::swap`]).
//!
//! [`Pin<P>`] tuaj yeem siv los qhwv txhua tus pointer hom `P`, thiab xws li nws cuam tshuam nrog [`Deref`] thiab [`DerefMut`].Ib tug [`Pin<P>`] qhov twg `P: Deref` yuav tsum raug xam tias yog raws li ib tug "`P`-style pointer" mus rau ib tug paib `P::Target`-li ntawd, ib tug ['Pin`]' <'[' Box`] '<T>> `yog tus tswv taw rau tus xaum `T`, thiab tus [` Pin `]` <Luv [Rc `]<T>>`yog cov neeg suav sau suav mus rau ib tus pinned `T`.
//! Txog qhov tseeb, [`Pin<P>`] cia siab rau qhov kev ua raws ntawm [`Deref`] thiab [`DerefMut`] kom tsis txhob txav tawm ntawm lawv qhov `self` parameter, thiab tsuas yog ib txwm rov qab xa tus pointer mus rau cov ntaub ntawv pinned thaum lawv hu rau ntawm tus pin pointer.
//!
//! # `Unpin`
//!
//! Ntau hom yeej ib txwm muaj kev ywj pheej txav tau, txawm tias yog li tus pin, vim tias lawv tsis cia siab rau muaj qhov chaw nyob ruaj khov.Qhov no suav nrog txhua hom pib (zoo li [`bool`], [`i32`], thiab cov ntawv xa mus) nrog rau cov hom uas tsuas yog cov hom no.Cov hom tsis quav ntsej txog kev txhim kho pinning siv [`Unpin`] pib-trait, uas tshem cov nyhuv ntawm [`Pin<P>`].
//! Rau `T: Unpin`, ['Pin`]' <'[' Box`] '<T>> `thiab [`Box<T>`] kev ua haujlwm ntawm tus kheej, xws li ua [` Pin `]` <&mut T> `thiab `&mut T`.
//!
//! Nco ntsoov tias pinning thiab [`Unpin`] tsuas yog cuam tshuam cov taw-rau hom `P::Target`, tsis yog tus pointer hom `P` nws tus kheej uas tau qhwv hauv [`Pin<P>`].Piv txwv, txawm tias [`Box<T>`] yog [`Unpin`] tsis muaj kev cuam tshuam rau kev coj cwj pwm ntawm [`Pin`] `<` [`Lub thawv ']<T>>`(ntawm no, `T` yog qhov taw qhia-rau hom).
//!
//! # Piv txwv li: kev txiav txim siab rau tus kheej
//!
//! Ua ntej peb nkag mus rau ntau cov ntsiab lus los piav qhia txog qhov lav thiab cov kev xaiv cuam tshuam nrog `Pin<T>`, peb tham txog qee qhov qauv rau yuav siv nws li cas.
//! Xav tias dawb rau [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Nov yog kev txiav txim siab rau tus kheej vim hais tias cov nplais ntu taw mus rau cov ntaub ntawv.
//! // Peb tsis tuaj yeem qhia tus sau tawm txog qhov ntawd nrog qhov ib txwm siv, vim cov qauv no tsis tuaj yeem piav qhia nrog cov cai qiv ib txwm.
//! //
//! // Hloov chaw peb siv lub pointer nyoos, txawm tias ib qho uas paub tias tsis yog null, raws li peb paub tias nws tau taw ntawm txoj hlua.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Yuav kom ntseeg tau tias cov ntaub ntawv tsis txav thaum lub haujlwm rov qab, peb muab tso rau hauv qhov chaw nws yuav nyob rau hauv lub neej ntawm qhov khoom, thiab tib txoj kev nkag mus rau nws yuav yog los ntawm tus pointer rau nws.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // peb tsuas ua tau ib lub pointer ib zaug cov ntaub ntawv yog nyob rau hauv qhov chaw txwv tsis pub nws yuav tau twb tsiv ua ntej peb txawm pib
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // peb paub qhov no muaj kev nyab xeeb vim hloov daim teb tsis txav tag nrho cov qauv
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // Tus taw qhia yuav tsum taw tes rau qhov chaw muaj tseeb, tsuav yog tus qauv tsis tau txav mus los.
//! //
//! // Lub caij no, peb muaj kev ywj pheej rhais tus pointer puag ncig.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Vim peb hom tsis siv Unpin, qhov no yuav swb rau compile:
//! // cia mut tshiab_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Piv txwv: daim ntawv txuas ob lub npe txuas
//!
//! Nyob rau hauv ib tug sab doubly-txuas daim ntawv teev, tus sau tsis tau faib lub cim xeeb rau lub ntsiab ntawm nws tus kheej.
//! Kev tshem tawm yog tswj hwm los ntawm cov neeg siv khoom, thiab cov khoom tuaj yeem tuaj yeem nyob ntawm tus ncej uas muaj lub neej luv dua li kev sau.
//!
//! Los ua qhov haujlwm no, txhua lub caij muaj taw tes rau nws tus neeg ua ntej thiab kev ua tiav hauv cov npe.Cov ntsiab lus tsuas muab tau ntxiv thaum lawv pinned, vim hais tias tsiv cov khoom nyob ib ncig ntawm yuav ua tsis pom kev ntawm cov kis.Ntxiv mus, [`Drop`] kev siv ntawm cov kab txuas txuas ua ke yuav ua rau cov ntsiab lus ntawm nws tus thawj ntawm thiab tus thawj coj tom qab tshem nws tus kheej tawm ntawm cov npe.
//!
//! Qhov tseem ceeb, peb yuav tsum tau cia siab rau [`drop`] raug hu ua.Yog tias ib qho khoom siv tuaj yeem ua tau lossis hloov chaw yam tsis tau hu xov tooj [`drop`], tus taw tes rau hauv nws los ntawm nws cov neeg nyob sib ze yuav dhau los ua tsis raug, uas yuav ua txhaum cov qauv ntaub ntawv.
//!
//! Yog li ntawd, pinning kuj los nrog [`poob ']-txheeb kev lav paub.
//!
//! # `Drop` guarantee
//!
//! Lub hom phiaj ntawm qhov pinning yog qhov ua tau kom vam khom qhov kev tso kawm ntawm qee cov ntaub ntawv hauv cim xeeb.
//! Los ua qhov haujlwm no, tsis yog txav cov ntaub ntawv yog txwv;kev sib cais, rov hais dua, lossis lwm yam tsis siv los siv lub cim xeeb siv los khaws cov ntaub ntawv raug txwv, ib yam nkaus.
//! Concretely, rau cov ntaub ntawv pinned koj yuav tsum tswj hwm tus tsis sib xws uas *nws lub cim xeeb yuav tsis tau txais kev siv tsis raug lossis rov qab los ntawm lub sijhawm nws tau pinned mus txog thaum thaum [`drop`] hu ua*.Tsuas yog ib zaug [`drop`] rov los lossis panics, lub cim xeeb yuav rov qab siv dua.
//!
//! Lub cim xeeb tuaj yeem yog "invalidated" los ntawm kev daws teeb meem, tab sis kuj los hloov [`Some(v)`] los ntawm [`None`], lossis hu [`Vec::set_len`] rau "kill" qee cov ntsiab lus tawm ntawm vector.Nws tuaj yeem siv rov qab los ntawm kev siv [`ptr::write`] kom tshaj nws nws yam tsis tas hu lub destructor ua ntej.Tsis muaj ib qho no yog tso cai rau cov ntaub ntawv pinned tsis hu rau [`drop`].
//!
//! Qhov no yog raws li hom tau lees tias cov ntawv txuas sib txuas los ntawm seem ntu dhau los yuav tsum ua haujlwm kom raug.
//!
//! Daim ntawv ceeb toom tias qhov kev lees paub no ua *tsis* txhais tau hais tias lub cim xeeb tsis xau!Nws yog tseem tsis tau zoo kiag li tsis tau hu rau [`drop`] ntawm lub plav (piv txwv li, koj tseem tuaj yeem hu [`mem::forget`] ntawm tus [`Pin`] `<<[Lub thawv`]<T>> `).Nyob rau hauv qhov piv txwv ntawm cov doubly-txuas daim ntawv teev, uas caij yuav cia li nyob twj ywm nyob rau hauv daim ntawv teev.Txawm li cas los xij koj yuav tsis pub dawb lossis rov siv lub ntim *tsis tas hu [`poob`]*.
//!
//! # `Drop` implementation
//!
//! Yog hais tias koj hom kev siv pinning (xws li cov ob tug piv txwv saum toj no), koj yuav tsum tau ceev faj thaum siv [`Drop`].Qhov [`drop`] kev ua haujlwm yuav siv `&mut self`, tab sis qhov no hu ua *txawm tias koj hom tau yog ua ntej pinned*!Nws zoo li yog tias tus compiler cia li hu ua [`Pin::get_unchecked_mut`].
//!
//! Qhov no tsis tuaj yeem tsim teeb meem nyob rau hauv kev nyab xeeb txoj cai vim hais tias siv hom uas tso siab rau pinning yuav tsum tsis muaj kev nyab xeeb code, tab sis nco ntsoov txiav txim siab los txiav txim siab siv pinning hauv koj hom (piv txwv los ntawm kev siv qee txoj haujlwm ntawm [`Pin ']` <&Self> `lossis [` Pin`]`<&mut tswj tus kheej>`) muaj lub txim rau koj kev siv [`Drop`] ib yam nkaus: yog tias ib qho ntawm koj hom yuav tau raug pinned, koj yuav tsum kho [`Drop`] raws li implicitly noj [`Pin`]`<&mut Tus kheej> `.
//!
//!
//! Piv txwv li, koj tuaj yeem siv `Drop` raws li hauv qab no:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` tsis ua li cas vim peb paub tias tus nqi no yeej tsis rov siv dua tom qab tau nqis.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Qhov tseeb nco code mus ntawm no.
//!         }
//!     }
//! }
//! ```
//!
//! Kev ua haujlwm `inner_drop` muaj hom uas [`drop`]*yuav tsum* muaj, yog li qhov no ua kom paub tseeb tias koj tsis txhob siv lub `self`/`this` yam tsis zoo uas yog qhov teeb meem nrog pinning.
//!
//! Ntxiv mus, yog tias koj hom yog `#[repr(packed)]`, lub compiler yuav cia li txav tawm thaj tsam ib puag ncig kom tuaj yeem ua poob rau lawv.Nws yuav txawm ua li ntawd rau teb uas tshwm sim rau yuav txaus raws li.Raws li qhov xwm txheej, koj tsis tuaj yeem siv pinning nrog `#[repr(packed)]` hom.
//!
//! # Projections thiab ntxwv pinning
//!
//! Thaum ua haujlwm nrog pinned structs, cov lus nug tshwm sim li cas ib tus neeg tuaj yeem nkag mus rau thaj teb ntawm qhov qauv ntawd hauv txoj kev uas yuav siv tau [`Pin`] `<&mut Qauv>`.
//! Lub ib txwm mus kom ze yog sau pab txoj kev (yog li ntawd hu ua *projections*) uas tig ['Pin`]' <&Mut struct> 'mus rau hauv ib tug siv rau hauv lub teb, tab sis yog dab tsi hom yuav tsum hais tias siv tau?Puas yog [`Pin`]` <&mut teb> `lossis `&mut Field`?
//! Tib lo lus nug tshwm sim nrog cov teb ntawm `enum`, thiab tseem yog thaum xav container/wrapper hom xws li [`Vec<T>`], [`Box<T>`], lossis [`RefCell<T>`].
//! (Lo lus nug no siv tau rau ob qho lus sib hloov thiab sib qhia, peb tsuas yog siv ntau qhov xwm txheej ntawm kev hais qhia hloov nyob ntawm no rau kev piv txwv.)
//!
//! Nws hloov tawm tias nws yog qhov tseeb txog ntawm tus neeg sau ntawm cov qauv ntaub ntawv los txiav txim siab seb qhov kev ntsuas pinned rau ib qho kev teb tshwj xeeb tig [`Pin`]`<&mut Qauv>`mus rau [`Pin`]`<&mut teb>`lossis `&mut Field`.Muaj qee qhov kev pom zoo txawm tias, thiab qhov tseem ceeb tshaj plaws yog *sib xws*:
//! txhua daim teb tuaj yeem ua tau *yog* npaj rau kev siv pinned,*lossis* muaj pinning tshem tawm ua ib feem ntawm kev ua tiav.
//! Yog tias ob qho tag rau cov khoom ua ke zoo ib yam, uas yuav zoo li yuav tsis zoo!
//!
//! Raws li tus sau ntawm cov qauv ntaub ntawv koj tau txais los txiav txim rau txhua daim teb seb pinning "propagates" rau daim teb no lossis tsis tau.
//! Pinning uas kev nthuav tawm tseem hu ua "structural", vim nws ua raws cov qauv ntawm hom.
//! Hauv cov nqe lus hauv qab no, peb piav qhia txog cov kev txiav txim siab uas yuav tsum tau ua rau ob qho kev xaiv.
//!
//! ## Pinning *tsis yog* cov txheej txheem rau `field`
//!
//! Nws tuaj yeem zoo li qhov tsis pom kev uas hais tias daim teb ntawm tus pinned yuav tsis raug pinned, tab sis qhov ntawd yog qhov kev xaiv yooj yim tshaj plaws: yog tias tus [`Pin ']` <&mut teb> `tsis tau tsim, tsis muaj dab tsi tuaj yeem mus tsis raug!Yog li, yog tias koj txiav txim siab tias qee thaj teb tsis muaj txheej txheem pinning, txhua yam koj yuav tsum xyuas kom meej yog tias koj yeej tsis tsim qhov cim tseg rau daim teb ntawd.
//!
//! Cov teb uas tsis muaj qauv pinning yuav muaj cov qauv pov thawj uas hloov [`Pin`] `<&mut Tus Qauv>` mus rau `&mut Field`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Qhov no tsis ua lag luam vim `field` yeej tsis xav tias yog pinned.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Koj kuj tseem tuaj yeem `impl Unpin for Struct`*txawm tias* hom `field` tsis yog [`Unpin`].Hom dab tsi xav hais txog kev ntaus pin yog tsis cuam tshuam thaum tsis muaj [`Pin`] `<&mut teb>` puas tau tsim.
//!
//! ## Pinning *yog* qauv rau `field`
//!
//! Lwm qhov kev xaiv yog txiav txim siab tias pinning yog "structural" rau `field`, txhais tau tias yog tias tus qauv yog pinned ces yog li daim teb.
//!
//! Qhov no pub rau sau ib projection uas tsim ib tug ['Pin`]' <&Mut Teb> ', li no pom tias cov teb paib:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Qhov no tsis ua li cas vim `field` yog pinned thaum `self` yog.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Txawm li cas los xij, tus txheej txheem pinning los nrog ob peb ntxiv uas yuav tsum tau ua:
//!
//! 1. Tus qauv tsuas yuav tsum yog [`Unpin`] yog tias txhua qhov kev teeb tsa cov qauv yog [`Unpin`].Qhov no yog lub neej ntawd, tab sis [`Unpin`] yog qhov muaj kev ruaj ntseg trait, yog li raws li tus kws sau tus qauv nws yog koj lub luag haujlwm *tsis* ntxiv qee yam zoo li `impl<T> Unpin for Struct<T>`.
//! (Daim ntawv ceeb toom uas muab ib tug projection lag luam yuav tsum tau tsis zoo code, li ntawd, qhov tseeb hais tias [`Unpin`] yog ib tug muaj kev ruaj ntseg trait tsis ua txhaum lub hauv paus ntsiab lus hais tias koj tsuas muaj mus worry txog tej yam no yog hais tias koj siv 'unsafe`.)
//! 2. Lub destructor ntawm lub struct yuav tsum tsis txhob txav ntxwv teb tawm ntawm nws sib cav.Qhov no yog qhov taw tes npliag uas tau tsa hauv [previous section][drop-impl]: `drop` siv `&mut self`, tab sis tus qauv (thiab vim li nws cov liaj teb) tej zaum yuav tau pinned ua ntej.
//!     Koj yuav tsum lav tias koj tsis tsiv ib daim teb sab hauv koj qhov kev siv [`Drop`].
//!     Hauv qee qhov, raws li tau piav qhia yav dhau los, qhov no txhais tau tias koj tus qauv yuav tsum *tsis* yog `#[repr(packed)]`.
//!     Saib uas seem rau yuav ua li cas sau ntawv [`drop`] nyob rau hauv ib txoj kev uas lub compiler yuav pab tau koj tsis ntawd lov pinning.
//! 3. Koj yuav tsum paub tseeb tias koj txhawb nqa [`Drop` guarantee][drop-guarantee]:
//!     ib zaug koj tus qauv yog pinned, lub cim xeeb uas muaj cov ntsiab lus tsis tau muab sau dua lossis tshem tawm yam tsis tas yuav hu cov ntsiab lus cuam tshuam.
//!     Qhov no tuaj yeem yog lo qhia, raws li pom los ntawm [`VecDeque<T>`]: lub destructor ntawm [`VecDeque<T>`] tuaj yeem hu tsis tau [`drop`] ntawm txhua lub ntsiab lus yog tias ib qho kev rhuav tshem panics.Qhov no yog yuam tus [`Drop`] guarantee, vim hais tias nws yuav ua tau kom lub ntsiab raug deallocated tsis muaj lawv cov destructor yog hu ua.([`VecDeque<T>`] twb tsis muaj pinning projections, yog li no tsis ua rau unsoundness.)
//! 4. Koj yuav tsum tsis txhob muab lwm txoj haujlwm uas tau tuaj yeem ua rau cov ntaub ntawv raug txav tawm ntawm cov chaw sib txuas thaum koj hom hle.Piv txwv li, yog hais tias tus qauv muaj ib qho [`Option<T>`] thiab muaj kev ua haujlwm zoo li "coj" nrog hom `fn(Pin<&mut Struct<T>>) -> Option<T>`, qhov haujlwm ntawd yuav siv tau los txav ib qho `T` tawm ntawm tus lej `Struct<T>`-uas txhais tau tias pinning tsis tuaj yeem yog tus qauv rau daim teb tuav qhov no cov ntaub ntawv.
//!
//!     Rau qhov piv txwv ntxiv ntawm kev txav cov ntaub ntawv tawm ntawm ib tus pinned yam, xav txog yog tias [`RefCell<T>`] muaj tus qauv `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>`.
//!     Tom qab ntawd peb tuaj yeem ua cov hauv qab no:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Qhov no yog kev puas tsuaj, nws txhais tau tias peb tuaj yeem xub thawj cov ntsiab lus ntawm [`RefCell<T>`] (siv `RefCell::get_pin_mut`) thiab tom qab ntawd txav cov ntsiab lus ntawd siv cov kev hloov pauv uas peb tau txais tom qab.
//!
//! ## Examples
//!
//! Rau ib hom zoo li [`Vec<T>`], ob leeg muaj peev xwm (cov qauv pinning lossis tsis) zoo siab.
//! Ib qho [`Vec<T>`] nrog cov txheej txheem pinning yuav muaj `get_pin`/`get_pin_mut` kev kom tau txais cov ntaub ntawv pinned rau cov khoom.Txawm li cas los, nws yuav *tsis* cia hu [`pop`][Vec::pop] rau ib tug paib [`Vec<T>`] vim tias yuav tsiv mus nyob rau (structurally paib) txheem!Tsis yog nws tuaj yeem tso cai [`push`][Vec::push], uas tej zaum yuav hloov chaw thiab yog li tseem tsiv cov ntsiab lus.
//!
//! Ib qho [`Vec<T>`] yam tsis muaj qauv pinning yuav `impl<T> Unpin for Vec<T>`, vim hais tias cov ntsiab lus tsis yog ib txwm pinned thiab [`Vec<T>`] nws tus kheej tau zoo nrog tau tsiv mus nyob rau qhov zoo.
//! Thaum lub sijhawm ntawd pinning tsuas yog tsis muaj kev cuam tshuam ntawm vector txhua.
//!
//! Hauv cov tsev qiv ntawv txheem, cov kab pointer feem ntau tsis muaj qauv pinning, thiab yog li lawv tsis muab pinning projections.Qhov no yog vim li cas `Box<T>: Unpin` tuav rau txhua `T`.
//! Nws ua rau kev txiav txim zoo kom ua li no rau pointer hom, vim hais tias mus rau `Box<T>` tsis tau tsiv mus nyob rau `T`: lub [`Box<T>`] yuav ua tau dawb do rooj noj (aka `Unpin`) txawm yog hais tias tus `T` tsis yog.Qhov tseeb, txawm tias [`Pin`] tau <<[Lub thawv `]`<T>> `thiab [` Pin`]`<&mut T>` yeej ib txwm [`Unpin`] lawv tus kheej, rau tib qho laj thawj: lawv cov ntsiab lus (`T`) yog pinned, tab sis tus taw tes lawv tus kheej tuaj yeem txav mus los tsis txav cov ntaub ntawv pinned.
//! Rau ob qho tag nrho [`Box<T>`] thiab [`Pin`] `<` [`Lub thawv`) `<T>>`, Txawm hais tias cov ntsiab lus los tau pinned nkaus kev ywj siab seb tus pointer puas pinned, lub ntsiab lus pinning yog *tsis* qauv.
//!
//! Thaum siv [`Future`] combinator, koj feem ntau yuav xav tau kev txhim kho pinning rau cov zed z0futures0Z, raws li koj xav tau txais cov ntaub ntawv pinned rau lawv kom hu [`poll`].
//! Tiam sis yog tias koj combinator muaj lwm yam ntaub ntawv uas tsis yuav tsum tau pinned, koj yuav ua tau cov neeg teb tsis structural thiab chaw pib dawb do saib tau lawv nrog ib tug mutable siv txawm tias koj nyuam qhuav muaj ['Pin`]' <&Mut Self> '(xws raws li nyob rau hauv koj tus kheej [`poll`] kev siv).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// Ib rab koob ntaus nrig.
///
/// Qhov no yog ib tug wrapper nyob ib ncig ntawm ib yam ntawm cov pointer uas ua rau muaj qhov pointer "pin" cov nqi nyob rau hauv qhov chaw, kev tiv thaiv tus nqi hais los ntawm uas pointer los yog tsiv tshwj tsis yog tias nws siv [`Unpin`].
///
///
/// *Saib cov ntaub ntawv [`pin` module] rau kev piav qhia ntawm pinning.*
///
/// [`pin` module]: self
///
// Note: lub `Clone` neeg hauv qab no ua rau unsoundness raws li nws yog tau siv
// `Clone` rau kev hais lus hloov tau.
// Saib <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> kom paub meej ntxiv.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Cov kev siv hauv qab no tsis yog muab los kom tsis txhob muaj teeb meem rau lub suab.
// `&self.pointer` yuav tsum tsis txhob nkag siv tau rau qhov kev tsis txaus ntseeg trait kev nqis tes ua.
//
// Saib <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> kom paub meej ntxiv.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Tsim tus tshiab `Pin<P>` ncig lub pointer rau qee cov ntaub ntawv ntawm ib hom uas yoog [`Unpin`].
    ///
    /// Tsis zoo li `Pin::new_unchecked`, cov qauv no muaj kev nyab xeeb vim tias tus pointer `P` dereferences mus rau [`Unpin`] hom, uas tshem tawm cov pinning tau lav.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // KEV RUAJ NTSEG: tus nqi taw rau yog `Unpin`, thiab yog li tsis muaj qhov yuav tsum muaj
        // ncig pinning.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Unwraps no `Pin<P>` rov qab rau lwm pointer.
    ///
    /// Qhov no yuav tsum tau hais tias cov ntaub ntawv hauv no `Pin` yog [`Unpin`] kom peb tuaj yeem tsis quav ntsej pinning invariants thaum tsis muab nws.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Tsim tus tshiab `Pin<P>` ncig xa mus rau qee cov ntaub ntawv ntawm ib hom uas yuav yog lossis tsis siv `Unpin`.
    ///
    /// Yog tias `pointer` dereferences rau hom `Unpin`, `Pin::new` yuav tsum siv dua.
    ///
    /// # Safety
    ///
    /// Tus tsim qauv no tsis nyab xeeb vim tias peb tsis tuaj yeem lav tias cov ntaub ntawv taw qhia los ntawm `pointer` yog pinned, txhais tau tias cov ntaub ntawv yuav tsis txav lossis nws lub chaw cia siv tsis tau txog thaum nws poob.
    /// Yog tias `Pin<P>` tsim kho tsis tuaj yeem lav tias cov ntaub ntawv `P` cov ntsiab lus mus rau pinned, uas yog kev ua txhaum daim ntawv cog lus API thiab yuav ua rau kev coj cwj pwm tsis txaus ntseeg tom qab (safe) kev khiav haujlwm.
    ///
    /// Los ntawm kev siv hom no, koj ua promise txog `P::Deref` thiab `P::DerefMut` kev nqis tes ua haujlwm, yog tias muaj nyob.
    /// Qhov tseem ceeb tshaj plaws, lawv yuav tsum tsis txhob txav tawm ntawm lawv cov `self` kev sib cav: `Pin::as_mut` thiab `Pin::as_ref` yuav hu `DerefMut::deref_mut` thiab `Deref::deref`*ntawm tus pin pointer* thiab cia siab tias cov hau kev no yuav txhawb tus pinning invariants.
    /// Ntxiv mus, los ntawm kev hu xov tooj rau txoj kev no koj promise tias qhov siv `P` dereferences mus yuav tsis tsiv tawm ntawm ntxiv;nyob rau hauv particular, nws yuav tsum tsis txhob yuav tau kom tau ib tug `&mut P::Target` thiab ces txav tawm ntawm uas siv (siv, piv txwv li [`mem::swap`]).
    ///
    ///
    /// Piv txwv li, hu rau `Pin::new_unchecked` ntawm `&'a mut T` yog qhov tsis zoo vim tias thaum koj tseem tuaj yeem kos nws rau lub neej `'a`, koj tsis muaj kev tswj hwm seb nws yuav khaws ib zaug thaum `'a` xaus:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Qhov no txhais tau tias tus pointee `a` tsis tuaj yeem txav mus ntxiv.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // Qhov chaw nyob ntawm `a` hloov mus rau `b` cov pawg pawg, yog li `a` tau tsiv mus txawm tias peb tau dhau los muab nws!Peb tau ua txhaum qhov pinning API ntawv cog lus.
    /////
    /// }
    /// ```
    ///
    /// Tus nqi, ib zaug pinned, yuav tsum nyob twj ywm pinned mus ib txhis (tshwj tsis yog nws hom siv `Unpin`).
    ///
    /// Ib yam li ntawd, hu `Pin::new_unchecked` rau ib tug `Rc<T>` yog tsis zoo vim hais tias yuav muaj Aliases rau tib cov ntaub ntawv uas yog tsis raug mus rau lub pinning txwv:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Qhov no txhais tau tias tus neeg taw tes tsis tuaj yeem txav mus ntxiv.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Tam sim no, yog tias `x` tsuas yog tib qho kev siv, peb muaj kev hloov pauv ntawm cov ntaub ntawv peb tus pinned saum toj no, uas peb tuaj yeem siv txav nws li peb tau pom hauv qhov piv txwv dhau los.
    ///     // Peb tau ua txhaum qhov pinning API ntawv cog lus.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Tau txais qhov siv los ua tus pinned siv los ntawm rab koob poov xab no.
    ///
    /// Nov yog txoj hauv kev rau siab los ntawm `&Pin<Pointer<T>>` rau `Pin<&T>`.
    /// Nws muaj kev nyab xeeb vim tias, yog ib feem ntawm kev cog lus ntawm `Pin::new_unchecked`, tus kis tsis tuaj yeem txav tom qab `Pin<Pointer<T>>` tau tsim.
    ///
    /// "Malicious" kev siv ntawm `Pointer::Deref` zoo li kev txiav txim siab los ntawm kev cog lus ntawm `Pin::new_unchecked`.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // KEV RUAJ NTSEG: saib cov ntaub ntawv rau ntawm txoj haujlwm no
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Unwraps no `Pin<P>` rov qab rau lwm pointer.
    ///
    /// # Safety
    ///
    /// Txoj haujlwm no tsis zoo.Koj yuav tsum lav tias koj yuav txuas ntxiv kho cov pointer `P` li pinned tom qab koj hu rau txoj haujlwm no, yog li ntawd cov chaw nkag ntawm `Pin` hom tuaj yeem ntsia tau.
    /// Yog tias tus lej siv cov txiaj ntsig `P` tsis txuas ntxiv tswj kev saib xyuas pinning uas tau ua txhaum ntawm API daim ntawv cog lus thiab yuav ua rau kev coj tus cwj pwm tsis txaus ntseeg tom qab (safe) kev khiav haujlwm.
    ///
    ///
    /// Yog tias cov ntaub ntawv hauv qab yog [`Unpin`], [`Pin::into_inner`] yuav tsum raug siv.
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Tau txais qhov siv cov pinned mutable los ntawm no tus po ntxaib.
    ///
    /// Nov yog txoj hauv kev rau siab los ntawm `&mut Pin<Pointer<T>>` rau `Pin<&mut T>`.
    /// Nws muaj kev nyab xeeb vim tias, yog ib feem ntawm kev cog lus ntawm `Pin::new_unchecked`, tus kis tsis tuaj yeem txav tom qab `Pin<Pointer<T>>` tau tsim.
    ///
    /// "Malicious" kev siv ntawm `Pointer::DerefMut` zoo li kev txiav txim siab los ntawm kev cog lus ntawm `Pin::new_unchecked`.
    ///
    /// Hom no muaj txiaj ntsig thaum ua ntau yam hu rau cov haujlwm uas haus cov hom pinned.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // ua dab tsi
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` noj `self`, thiaj li nyiaj rov qab rau `Pin<&mut Self>` ntawm `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // KEV RUAJ NTSEG: saib cov ntaub ntawv rau ntawm txoj haujlwm no
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Txheeb muab tus nqi tshiab rau lub cim xeeb tom qab ntawm tus pinned siv.
    ///
    /// Cov ntaub ntawv sau no pinned cov ntaub ntawv, tab sis qhov ntawd tsis zoo: nws lub neej puas tsuaj ua ntej tau muab sau, yog li tsis muaj qhov pinning lav yog ua txhaum.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Tsim tus lej tshiab los ntawm kev teeb tsa sab hauv tus nqi.
    ///
    /// Piv txwv li, yog tias koj xav tau txais `Pin` ntawm daim teb ntawm ib yam dab tsi, koj tuaj yeem siv qhov no kom nkag mus rau daim teb ntawd hauv kab ib kab.
    /// Txawm li cas los xij, muaj ob peb gotchas nrog cov "pinning projections";
    /// saib cov ntaub ntawv [`pin` module] rau cov lus qhia ntxiv ntawm cov ncauj lus no.
    ///
    /// # Safety
    ///
    /// Txoj haujlwm no tsis zoo.
    /// Koj yuav tsum lav tias cov ntaub ntawv koj xa rov qab yuav tsis txav mus ntev npaum li qhov kev sib cav tus nqi tsis txav mus (piv txwv li, vim nws yog ib daim teb ntawm cov nqi ntawd), thiab tseem tias koj tsis tsiv tawm ntawm kev sib cav koj tau txais muaj nuj nqi sab hauv.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // KEV RUAJ NTSEG: daim ntawv cog lus muaj kev nyab xeeb rau `new_unchecked` yuav tsum yog
        // upheld los ntawm ib tus neeg hu.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Tau txais kev qhia tawm ntawm tus pin.
    ///
    /// Qhov no muaj kev nyab xeeb vim tias nws tsis tuaj yeem txav tawm ntawm daim ntawv qhia siv.
    /// Nws yuav zoo li zoo li muaj yog ib qhov teeb meem no nrog sab hauv mutability: nyob rau hauv qhov tseeb, nws *yog* tau txav ib `T` tawm ntawm ib tug `&RefCell<T>`.
    /// Txawm li cas los xij, qhov no tsis yog teeb meem ntev li ntev tau tias tsis muaj qhov tseem muaj `Pin<&T>` taw rau tib cov ntaub ntawv, thiab `RefCell<T>` tsis cia koj tsim cov kev siv pinned rau nws cov ntsiab lus.
    ///
    /// Saib kev sib tham ntawm ["pinning projections"] rau cov lus qhia ntxaws ntxiv.
    ///
    /// Note: `Pin` tseem coj `Deref` mus rau lub hom phiaj, tuaj yeem siv kom nkag mus rau sab hauv tus nqi.
    /// Txawm li cas los xij, `Deref` tsuas yog muab cov lus qhia uas nyob rau ntev li ntev tau qiv ntawm `Pin`, tsis tas lub neej ntawm `Pin` nws tus kheej.
    /// Txoj kev no tso cai rau tig `Pin` rau hauv kev siv nrog tib lub neej zoo li tus thawj `Pin`.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Hloov siab cov kab ntawv `Pin<&mut T>` no rau `Pin<&T>` nrog cov tib lub neej.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Tau txais kev hloov pauv rau cov ntaub ntawv sab hauv ntawm `Pin` no.
    ///
    /// Qhov no yuav tsum tau tias cov ntaub ntawv hauv no `Pin` yog `Unpin`.
    ///
    /// Note: `Pin` tseem coj `DerefMut` rau cov ntaub ntawv, uas tuaj yeem siv kom nkag mus rau sab hauv tus nqi.
    /// Txawm li cas los xij, `DerefMut` tsuas yog muab cov lus qhia uas nyob rau ntev li ntev tau qiv ntawm `Pin`, tsis tas lub neej ntawm `Pin` nws tus kheej.
    ///
    /// Txoj kev no tso cai rau tig `Pin` rau hauv kev siv nrog tib lub neej zoo li tus thawj `Pin`.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Tau txais kev hloov pauv rau cov ntaub ntawv sab hauv ntawm `Pin` no.
    ///
    /// # Safety
    ///
    /// Txoj haujlwm no tsis zoo.
    /// Koj yuav tsum lav tias koj yuav tsum tsis txhob tshem tawm cov ntaub ntawv tawm ntawm qhov kev hloov pauv uas koj tau txais thaum koj hu rau txoj haujlwm no, yog li ntawd cov chaw nkag ntawm `Pin` hom tuaj yeem ntsia tau.
    ///
    ///
    /// Yog tias cov ntaub ntawv hauv qab yog `Unpin`, `Pin::get_mut` yuav tsum raug siv.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Tsim tus pin tshiab los ntawm kev teeb tsa sab hauv tus nqi.
    ///
    /// Piv txwv li, yog tias koj xav tau txais `Pin` ntawm daim teb ntawm ib yam dab tsi, koj tuaj yeem siv qhov no kom nkag mus rau daim teb ntawd hauv kab ib kab.
    /// Txawm li cas los xij, muaj ob peb gotchas nrog cov "pinning projections";
    /// saib cov ntaub ntawv [`pin` module] rau cov lus qhia ntxiv ntawm cov ncauj lus no.
    ///
    /// # Safety
    ///
    /// Txoj haujlwm no tsis zoo.
    /// Koj yuav tsum lav tias cov ntaub ntawv koj xa rov qab yuav tsis txav mus ntev npaum li qhov kev sib cav tus nqi tsis txav mus (piv txwv li, vim nws yog ib daim teb ntawm cov nqi ntawd), thiab tseem tias koj tsis tsiv tawm ntawm kev sib cav koj tau txais muaj nuj nqi sab hauv.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // KEV RUAJ NTSEG: tus hu yog lub luag hauj lwm rau qhov tsis txav qhov
        // muaj nqis tawm ntawm qhov siv.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // KEV RUAJ NTSEG: raws li tus nqi ntawm `this` yog qhov lees tias tsis muaj
        // tau tsiv tawm lawm, qhov kev hu no mus rau `new_unchecked` yog kev nyab xeeb.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Tau txais ib tus pinned siv los ntawm kev siv tau zoo li qub.
    ///
    /// Qhov no muaj kev nyab xeeb, vim `T` qiv rau `'static` lub neej, uas tsis muaj qhov kawg.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // KEV RUAJ NTSEG: Tus qiv qiv zoo li qub tuaj yeem lav cov ntaub ntawv yuav tsis ua
        // moved/invalidated kom txog thaum nws tau poob (uas tsis muaj).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Tau txais ib tus pinned mutable siv los ntawm kev siv hluav taws xob hloov pauv.
    ///
    /// Qhov no muaj kev nyab xeeb, vim `T` qiv rau `'static` lub neej, uas tsis muaj qhov kawg.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // KEV RUAJ NTSEG: Tus qiv qiv zoo li qub tuaj yeem lav cov ntaub ntawv yuav tsis ua
        // moved/invalidated kom txog thaum nws tau poob (uas tsis muaj).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: qhov no txhais tau tias txhua yam ntawm `CoerceUnsized` uas tso cai yuam los ntawm
// ib yam uas implies `Deref<Target=impl !Unpin>` rau ib yam uas impls `Deref<Target=Unpin>` yog unsound.
// Tej impl li no tej zaum yuav unsound rau lwm yam, tab sis yog li, yog li peb tsuas yog xav tau saib xyuas kom tsis txhob cia tej impls mus tsaws hauv std.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}