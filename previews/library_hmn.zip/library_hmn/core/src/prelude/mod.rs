//! Lub libcore preclus
//!
//! Qhov qauv no yog npaj rau cov neeg siv ntawm libcore uas tsis txuas rau libstd ib yam nkaus.
//! Qhov qauv no tau muab coj los ua lub neej thaum `#![no_std]` siv rau kev siv tib yam li lub tsev qiv ntawv txheem preclus.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// Lub xyoo 2015 ntawm cov tub ntxhais tseem ceeb prelude.
///
/// Saib cov [module-level documentation](self) rau ntau.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Lub 2018 version ntawm cov tub ntxhais prelude.
///
/// Saib cov [module-level documentation](self) rau ntau.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Lub 2021 version ntawm cov tub ntxhais prelude.
///
/// Saib cov [module-level documentation](self) rau ntau.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Ntxiv ntau yam ntxiv.
}