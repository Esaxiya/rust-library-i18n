//! Panic kev txhawb nqa rau libcore
//!
//! Lub tsev qiv ntawv tseem ceeb tsis tuaj yeem txhais tau qhov mob ua rau yias, tab sis nws ua *tshaj tawm* kev yias
//! Qhov no txhais tau hais tias lub luag haujlwm sab hauv ntawm libcore raug tso cai rau panic, tab sis yuav tsum pab tau ib qho tseem ceeb ntawm crate yuav tsum txhais qhov kev ua haujlwm rau kev siv libcore los siv.
//! Cov interface tam sim no rau panicking yog:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Lub ntsiab lus no tso cai rau panicking nrog txhua cov lus dav dav, tab sis nws tsis tso cai rau ua tsis tiav nrog `Box<Any>` X tus nqi.
//! (`PanicInfo` tsuas yog muaj `&(dyn Any + Send)`, rau qhov peb sau rau dummy tus nqi hauv `PanicInfo: : internal_constructor`.) Qhov laj thawj rau qhov no yog tias libcore tsis raug tso cai faib.
//!
//!
//! Cov qauv no muaj ob peb lwm txoj haujlwm panicking, tab sis cov no tsuas yog cov khoom tsim nyog lang rau lub compiler.Txhua panics yog kev lom zem los ntawm txoj haujlwm no.
//! Lub cim tiag tiag tau tshaj tawm dhau los ntawm `#[panic_handler]` tus cwj pwm.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Qhov pib siv ntawm libcore `panic!` macro thaum tsis muaj qauv siv.
#[cold]
// tsis txhob inline tshwj tsis yog panic_immediate_abort kom tsis txhob muaj kev txhaum cai nyob ntawm qhov chaw hu ntau li ntau tau
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // xav tau los ntawm codegen rau panic ntawm txeej thiab lwm yam `Assert` MIR terminators
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Siv Arguments::new_v1 hloov ntawm format_args! ("{}", Expr) kom txo qhov loj me uas tsis xwm yeem.
    // Format_args!macro siv str's Display trait los sau expr, uas hu rau Formatter::pad, uas yuav tsum tau muab cov hlua txiav thiab ntsuas phoo (txawm tias tsis tau siv nyob ntawm no).
    //
    // Siv Arguments::new_v1 tuaj yeem tso cai rau cov compiler kom rho tawm Formatter::pad los ntawm cov binary tso zis, txuag ob peb kilobytes.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // xav tau rau const-soj ntsuam panics
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // xav tau los ntawm codegen rau panic ntawm OOB array/slice nkag
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Qhov pib siv ntawm libcore's `panic!` macro thaum tsim qauv.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // NCO TSEG Lub luag haujlwm no ib txwm tsis hla ciam FFI;nws yog Rust-rau-Rust hu uas tau daws rau `#[panic_handler]` muaj nuj nqi.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // KEV RUAJ NTSEG: `panic_impl` tau txhais nyob rau hauv kev nyab xeeb Rust code thiab yog li muaj kev nyab xeeb hu.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Muaj nuj nqi sab hauv rau `assert_eq!` thiab `assert_ne!` macros
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}