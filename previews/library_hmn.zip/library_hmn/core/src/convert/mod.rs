//! Traits rau hloov ntawm hom.
//!
//! Lub traits hauv qhov qauv no muab txoj hauv kev hloov ntawm ib hom mus rau lwm hom.
//! Txhua trait ua hauj lwm pab ib tug txawv hom phiaj:
//!
//! - Ua raws li [`AsRef`] trait rau qhov pheej yig siv-rau-siv
//! - Ua raws li [`AsMut`] trait rau cov khoom pheej yig hloov pauv-rau-hloov tau
//! - Siv lub [`From`] trait rau haus tus nqi-rau-tus nqi hloov
//! - Ua raws li [`Into`] trait rau kev sib pauv tus nqi-rau-tus nqi sib pauv rau cov hom sab nraum crate tam sim no
//! - Lub [`TryFrom`] thiab [`TryInto`] traits coj zoo li [`From`] thiab [`Into`], tiam sis yuav tsum muab los siv thaum tus hloov dua siab tshiab yuav tsis.
//!
//! traits hauv qhov qauv no feem ntau siv ua trait bounds rau cov haujlwm tsis tseem ceeb xws li kom muaj kev sib cav ntawm ntau hom tau txais kev txhawb nqa.Saib cov ntaub ntawv ntawm txhua tus trait rau cov piv txwv.
//!
//! Raws li lub tsev qiv ntawv sau, koj yuav tsum nco ntsoov xav siv [`From<T>`][`From`] los yog [`TryFrom<T>`][`TryFrom`] es [`Into<U>`][`Into`] los yog [`TryInto<U>`][`TryInto`], raws li [`From`] thiab [`TryFrom`] muab ntau dua thiab muaj kev sib npaug [`Into`] los yog [`TryInto`] implementations dawb, ua tsaug rau ib daim pam siv nyob rau hauv tus txheej txheem tsev qiv ntawv.
//! Thaum hom phiaj ib tug version ua ntej Rust 1.41, tej zaum nws yuav tsim nyog rau siv [`Into`] los yog [`TryInto`] ncaj qha thaum hloov mus rau ib hom sab nraum lub tam sim no crate.
//!
//! # Generic implementations
//!
//! - [`AsRef`] thiab [`AsMut`] auto-dereference yog tias sab hauv hom yog siv
//! - ['From`]' <U>rau T` implies ['Into`]'</u><T><U>rau U`</u>
//! - ['TryFrom`]' <U>rau T` tiag ['TryInto`]'</u><T><U>rau U`</u>
//! - [`From`] thiab [`Into`] yog reflexive, uas txhais tau hais tias tag nrho cov hom yuav `into` lawv tus kheej thiab `from` lawv tus kheej
//!
//! Saib txhua trait rau cov qauv siv.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Cov qhia tias yog leejtwg muaj nuj nqi.
///
/// Ob tug tej yam uas yog ib qho tseem ceeb rau kev ceeb toom txog qhov no muaj nuj nqi:
///
/// - Nws tsis yog ib txwm sib npaug mus rau ib tug kaw zoo li `|x| x`, txij li thaum lub kaw tej zaum yuav yuam `x` rau hauv ib tug txawv hom.
///
/// - Nws txav ntawm cov tswv yim `x` dhau mus rau qhov haujlwm.
///
/// Thaum nws yuav zoo li coj txawv txawv rau muaj ib tug muaj nuj nqi uas cia li rov qab rov qab lub tswv yim, muaj ib co nthuav kev siv.
///
///
/// # Examples
///
/// Siv `identity` ua ib yam dabtsi nyob rau hauv ib tug sib lawv liag ntawm lwm yam, interesting, zog:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Cia peb ua txuj hais tias muab ib tug yog ib qho kev nthuav muaj nuj nqi.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Siv `identity` raws li ib tug "do nothing" puag cov ntaub ntawv nyob rau hauv ib tug nyob ntawm:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Ua cov yam ntxim siab dua ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Siv `identity` kom lub `Some` variants ntawm ib tug iterator ntawm `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Siv ua ib tug pheej yig siv-rau-siv hloov dua siab tshiab.
///
/// Cov trait no zoo ib yam li [`AsMut`] uas yog siv rau kev hloov ntawm cov ntawv xa mus hloov.
/// Yog hais tias koj yuav tau ua ib tug kim hloov dua siab tshiab nws yog zoo dua rau siv [`From`] nrog hom `&T` los yog sau ntawv ib tug kev cai muaj nuj nqi.
///
/// `AsRef` muaj tib qho kev kos npe raws li [`Borrow`], tab sis [`Borrow`] yog qhov sib txawv hauv ob peb yam:
///
/// - Tsis zoo li `AsRef`, [`Borrow`] muaj daim pam pam rau ib qho `T`, thiab tuaj yeem siv los lees siv tus nqi lossis tus nqi.
/// - [`Borrow`] kuj yuav tsum tau hais tias [`Hash`], [`Eq`] thiab [`Ord`] rau borrowed nqi yog sib npaug rau cov neeg ntawm lub muaj nqi.
/// Vim li no, yog tias koj xav qiv tsuas yog ib daim teb ntawm ib tus txheej txheem koj tuaj yeem siv `AsRef`, tab sis tsis yog [`Borrow`].
///
/// **Note: Qhov no trait yuav tsum tsis txhob tsis **.Yog tias qhov kev hloov pauv tuaj yeem ua tsis tiav, siv txoj hauv kev xa rov qab uas [`Option<T>`] lossis [`Result<T, E>`].
///
/// # Generic implementations
///
/// - `AsRef` nws pib dereferences yog hom sab hauv yog kev siv lossis ib qho siv tau hloov tau (piv txwv: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Los ntawm kev siv trait bounds peb yuav txais cov nqe lus ntawm ntau hom raws li ntev raws li lawv muaj peev xwm yuav hloov dua siab tshiab rau lub teev hom `T`.
///
/// Piv txwv li: Los ntawm txoj kev kom muaj cov generic muaj nuj nqi uas yuav siv sij hawm ib tug `AsRef<str>` peb qhia hais tias peb xav mus txais tag nrho cov neeg ua tim khawv hais tias yuav hloov dua siab tshiab rau [`&str`] li ib tug sib cav.
/// Txij li thaum ob leeg [`String`] thiab [`&str`] siv `AsRef<str>` peb yuav txais tag nrho ob qho li cov tswv yim sib cav.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Ua lub hloov siab tshiab.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Siv los ua qhov pheej yig hloov-rau-hloov tau siv.
///
/// Qhov no trait yog zoo li [`AsRef`] tab sis siv rau converting ntawm mutable ua tim khawv.
/// Yog hais tias koj yuav tau ua ib tug kim hloov dua siab tshiab nws yog zoo dua rau siv [`From`] nrog hom `&mut T` los yog sau ntawv ib tug kev cai muaj nuj nqi.
///
/// **Note: Qhov no trait yuav tsum tsis txhob tsis **.Yog tias qhov kev hloov pauv tuaj yeem ua tsis tiav, siv txoj hauv kev xa rov qab uas [`Option<T>`] lossis [`Result<T, E>`].
///
/// # Generic implementations
///
/// - `AsMut` nws pib dereferences yog hom sab hauv yog siv tau hloov tau (piv txwv li: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Siv `AsMut` li trait bound rau ib tug generic muaj nuj nqi peb yuav txais tag nrho cov mutable ua tim khawv hais tias yuav hloov dua siab tshiab rau ntaus `&mut T`.
/// Vim tias [`Box<T>`] ua raws `AsMut<T>` peb tuaj yeem sau ua haujlwm `add_one` uas yuav siv txhua cov lus sib cav uas tuaj yeem hloov mus rau `&mut u64`.
/// Vim hais tias [`Box<T>`] siv `AsMut<T>`, `add_one` lees txais cov lus sib cav ntawm hom `&mut Box<u64>` zoo li:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Ua lub hloov siab tshiab.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Ib qho txiaj ntsig-rau-nqi hloov dua siab tshiab uas siv ntau lub txiaj ntsig.Tus txheem ntawm [`From`].
///
/// Ib qho yuav tsum zam kev siv [`Into`] thiab siv [`From`] hloov.
/// Siv [`From`] txiav muab ib tug nrog ib kev siv ntawm [`Into`] ua tsaug rau daim pam siv nyob rau hauv tus txheej txheem tsev qiv ntawv.
///
/// Xav siv [`Into`] tshaj [`From`] thaum specifying trait bounds rau ib tug generic muaj nuj nqi kom paub meej tias hom uas tsuas siv [`Into`] yuav siv tau raws li zoo.
///
/// **Note: Qhov no trait yuav tsum tsis txhob tsis **.Yog hais tias lub hloov dua siab tshiab yuav tsis, siv [`TryInto`].
///
/// # Generic implementations
///
/// - ['From`]'<T>rau U` implies `Into<U> for T`
/// - [`Into`] yog reflexive, uas txhais tau tias `Into<T> for T` yog DVR
///
/// # Siv [`Into`] rau hloov mus rau sab nraud hom rau cov laus versions ntawm Rust
///
/// Ua ntej yuav Rust 1.41, yog hais tias tus lo lus uas peb hom yog tsis ib feem ntawm cov tam sim no crate ces koj yuav tsis siv [`From`] ncaj qha.
/// Piv txwv li, muab cov cai no:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Qhov no yuav tsis compile nyob rau hauv cov laus versions ntawm cov lus vim hais tias Rust lub orphaning cai siv los ua ib tug me ntsis ntau nruj.
/// Txhawm rau dhau qhov no, koj tuaj yeem siv [`Into`] ncaj qha:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Nws yog ib qho tseem ceeb kom nkag siab tias [`Into`] tsis muab kev siv [`From`] (raws li [`From`] ua nrog [`Into`]).
/// Yog li, koj yuav tsum ib txwm sim siv [`From`] thiab tom qab ntawd poob rov qab rau [`Into`] yog tias [`From`] tsis tuaj yeem siv.
///
/// # Examples
///
/// [`String`] siv [`Nkag Mus Rau Hauv]` <Qhov `[Vec`] `<` [`u8`] `>:
///
/// Txhawm rau tshaj tawm tias peb xav tau txoj haujlwm zoo los coj tag nrho cov kev sib cav uas tuaj yeem hloov mus rau hom kev cai `T`, peb tuaj yeem siv trait bound ntawm [`Rau Hauv`] `<T>`.
///
/// Piv txwv li: Cov kev ua `is_hello` yuav siv sij hawm tag nrho cov nqe lus uas yuav tsum hloov dua siab tshiab rau hauv ib tug ['Vec`]' <'[' u8`] '>'.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Ua lub hloov siab tshiab.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Siv los ua tus nqi-rau-tus nqi sib pauv thaum noj cov khoom siv tus nqi.Nws yog tus txais ntawm [`Into`].
///
/// Ib qho yuav tsum nco ntsoov nyiam siv `From` tshaj [`Into`] vim tias siv `From` cia li muab ib qho nrog kev siv [`Into`] ua tsaug rau daim pam vov hauv lub tsev qiv ntawv tus qauv.
///
///
/// Tsuas yog siv [`Into`] thaum targeting ib tug version ua ntej Rust 1.41 thiab hloov mus rau ib hom sab nraum lub tam sim no crate.
/// `From` tsis muaj peev xwm ua tau cov kev hloov pauv no hauv cov ntawv ua ntej vim Rust's txoj cai txwv ntsuag.
/// Saib [`Into`] kom paub meej ntxiv.
///
/// Txheeb xyuas [`Into`] dhau los siv `From` thaum qhia meej trait bounds ntawm txoj haujlwm zoo.
/// Txoj kev no, cov hom uas siv [`Into`] ncaj qha tuaj yeem siv cov lus sib cav ib yam.
///
/// Lub `From` tseem muaj txiaj ntsig zoo thaum ua haujlwm yuam kev.Thaum constructing muaj nuj nqi uas muaj peev xwm poob, rov qab yam yuav feem ntau yuav ntawm daim ntawv `Result<T, E>`.
/// Lub `From` trait simplifies kev ua yuam kev tuav los ntawm qhov uas ib tug muaj nuj nqi rov qab muaj ib zaug xwb kev ua yuam kev yam uas encapsulate ntau yuam kev hom.Saib ntu "Examples" thiab [the book][book] kom paub meej ntxiv.
///
/// **Note: Qhov trait yuav tsum tsis swb **.Yog hais tias lub hloov dua siab tshiab yuav tsis, siv [`TryFrom`].
///
/// # Generic implementations
///
/// - `From<T> for U` implies [`Rau Hauv`] `<U>rau T`</u>
/// - `From` yog qhov thim rov qab, uas txhais tau tias `From<T> for T` tau nqis tes ua
///
/// # Examples
///
/// [`String`] siv piv `From<&str>`:
///
/// Ib tug qhia tau meej heev hloov dua siab tshiab los ntawm ib tug `&str` rau ib txoj hlua yog ua li cas raws li nram no:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Thaum ua tau zoo kev ua yuam kev tuav feem ntau nws yog pab tau mus siv `From` rau koj tus kheej yuam kev hom.
/// By hloov lwm yuam kev hom rau peb tus kheej kev cai yuam kev hom uas encapsulates lwm yuam kev hom, peb muaj peev xwm rov qab mus ib zaug xwb kev ua yuam kev yam tsis tau poob cov lus qhia txog lwm ua.
/// Tus neeg teb xov tooj '?' hloov qhov pib qhov pib yuam kev rau peb cov hom kev ua yuam kev los ntawm kev hu `Into<CliError>::into` uas tau muab rau thaum ua raws `From`.
/// Lub compiler ces infers uas ua raws li cov `Into` yuav tsum tau siv.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Ua lub hloov siab tshiab.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Ib sim hloov dua siab tshiab hais tias kov `self`, uas yuav yog los kuj tsis kim.
///
/// Library sau phau ntawv yuav tsum tsis ncaj qha siv no trait, tab sis yuav tsum xav siv cov [`TryFrom`] trait, uas muaj ntau dua thiab muab ib npaug `TryInto` siv rau dawb, ua tsaug rau ib daim pam siv nyob rau hauv tus txheej txheem tsev qiv ntawv.
/// Xav paub ntau ntxiv txog qhov no, saib cov ntaub ntawv rau [`Into`].
///
/// # siv `TryInto`
///
/// Qhov no suffers tib txwv thiab kev xav raws li kev siv [`Into`], pom muaj rau cov ntsiab lus.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Lub hom rov qab nyob rau hauv cov kev tshwm sim ntawm ib tug hloov dua siab tshiab kev ua yuam kev.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Ua lub hloov siab tshiab.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Tej yam yooj yim thiab muaj kev nyab xeeb hom pauv hloov uas tej zaum yuav tsis nyob rau hauv ib tug tswj txoj kev nyob rau hauv tej yam.Nws yog ib lub reciprocal ntawm [`TryInto`].
///
/// Qhov no yog pab tau thaum uas koj ua ib yam hloov dua siab tshiab hais tias tej zaum yuav trivially kawm tau ntawv zoo tab sis tej zaum yuav kuj xav tau kev tuav.
/// Piv txwv li, yog tsis muaj txoj kev uas yuav hloov ib [`i64`] rau hauv ib qho [`i32`] siv cov [`From`] trait, vim hais tias ib tug [`i64`] tej zaum yuav muaj ib tug nqi uas ib tug [`i32`] yuav tsis sawv cev rau thiab ces tus hloov dua siab tshiab yuav poob cov ntaub ntawv.
///
/// Qhov no yuav daws tau los ntawm kev txiav txim siab [`i64`] rau [`i32`] (qhov tseem ceeb muab lub [`i64`] tus nqi modulo [`i32::MAX`]) lossis los ntawm rov qab tsuas yog [`i32::MAX`], lossis los ntawm lwm txoj hauv kev.
/// Lub [`From`] trait yog npaj rau qhov kev hloov pauv zoo meej, yog li `TryFrom` trait qhia rau tus programmer thaum ib hom kev hloov dua siab tshiab tuaj yeem mus tsis zoo thiab cia lawv txiav txim siab yuav ua li cas.
///
/// # Generic implementations
///
/// - `TryFrom<T> for U` implies [`TryInto`] `<U>rau T`</u>
/// - [`try_from`] yog reflexive, uas txhais tau tias `TryFrom<T> for T` yog DVR thiab yuav tsis tsis-cov kab `Error` hom hu `T::try_from()` rau ib tug nqi ntawm hom `T` yog [`Infallible`].
/// Thaum lub [`!`] hom stabilized [`Infallible`] thiab [`!`] yuav sib npaug.
///
/// `TryFrom<T>` tau muab los siv raws li nram no:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Raws li tau piav qhia, [`i32`] coj los sim `TryFrom <` [`i64`] `>:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Twj ywm truncates `big_number`, yuav tsum tau tebchaws thiab tuav lub truncation tom qab lub fact.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Rov qab yuam kev vim `big_number` loj dhau los ua kom haum rau hauv `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Rov `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Lub hom rov qab nyob rau hauv cov kev tshwm sim ntawm ib tug hloov dua siab tshiab kev ua yuam kev.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Ua lub hloov siab tshiab.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// COV TSWV YIM ZOO
////////////////////////////////////////////////////////////////////////////////

// Raws li nqa tshaj&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Raws li cov nqa tshaj &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): hloov cov saum toj no impls rau&/&Mut cov nram qab no ntau general ib:
// // Raws li nqa dhau Deref
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Sized> AsRef <U>rau D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut nqa dua &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): hloov rau saum toj no impl rau &mut nrog rau cov hauv qab no ntau dua ib qho:
// // AsMut nqa tshaj DerefMut
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Tsuas> AsMut <U>rau D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Los ntawm implies Rau Hauv
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// Los ntawm (thiab yog li Into) yog qhov hloov pauv
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Daim Ntawv Ruaj Ntseg:** Qhov kev cog lus no tseem tsis tau muaj, tab sis peb yog "reserving space" ntxiv rau hauv future.
/// Saib [rust-lang/rust#64715][#64715] kom paub meej.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): ua kev kho tshwjxeeb es tsis txhob hloov kho.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom implies TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Infallible hloov dua siab tshiab yog semantically sib npaug rau kev hloov pauv hloov nrog ib tus tsis muaj qhov yuam kev.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// QHOB IMPLS
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// LUB NO-YUAM KEV YUAM KEV YAM
////////////////////////////////////////////////////////////////////////////////

/// Qhov kev ua yuam kev tsis zoo uas tsis tuaj yeem tshwm sim.
///
/// Txij li thaum lub enum no tsis muaj qhov txawv txav, qhov txiaj ntsig ntawm hom no tuaj yeem tsis muaj tiag.
/// Qhov no yuav pab tau kom generic APIs uas siv [`Result`] thiab parameterize qhov yuam kev yam, yuav qhia tau tias cov kev tshwm sim yog ib txwm [`Ok`].
///
/// Piv txwv li, lub [`TryFrom`] trait (hloov dua siab tshiab hais tias rov qab ib tug [`Result`]) muaj ib daim pam siv rau tag nrho cov hom twg ib tug rov qab [`Into`] siv tshwm sim.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Future compatibility
///
/// Cov kabmob no muaj lub luag haujlwm zoo ib yam li [the `!`“never”type][never], uas tsis khov kho nyob rau hauv no version ntawm Rust.
/// Thaum `!` stabilized, peb npaj yuav ua `Infallible` ib hom cai rau nws:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …Thiab nws thiaj li tsis nyiam `Infallible`.
///
/// Txawm li cas los xij muaj ib rooj plaub uas `!` syntax yuav siv tau ua ntej `!` ruaj khov los ua qhov muaj qhov txhij txhua: nyob rau hauv txoj haujlwm ntawm txoj haujlwm rov qab hom.
/// Tshwj xeeb, nws yog tau implementations rau ob tug sib txawv muaj nuj nqi pointer hom:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Nrog `Infallible` yog qhov enum, tus lej no siv tau.
/// Txawm li cas los xij thaum `Infallible` dhau los ua kev cai rau never type, ob lub ntsiab lus yuav pib sib tshooj thiab vim li ntawd yuav tsis pom zoo los ntawm cov lus ntawm trait kev sib koom ua ke cov cai.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}