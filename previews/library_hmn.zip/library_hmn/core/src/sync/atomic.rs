//! Cov qauv atomic
//!
//! Atomic hom muab txheej thaum ub qhia-nco kev sib txuas lus ntawm threads, thiab yog lub tsev blocks ntawm lwm txhawb hom.
//!
//! Qhov no module sij atomic versions ntawm ib qho naj npawb ntawm cov txheej thaum ub hom, xws li [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`], etc.
//! Cov hom ib qho me me ib qho haujlwm tam sim no, thaum siv kom raug, synchronize hloov tshiab ntawm cov xov.
//!
//! Txhua txoj kev yuav siv sij hawm ib tug [`Ordering`] uas nruab nrab yog lub zog ntawm lub cim xeeb teeb meem rau tias ua hauj lwm.Cov kev xaj no yog tib yam li [C++20 atomic orderings][1].Xav paub ntau ntxiv saib hauv [nomicon][2].
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! Atomic qhob muaj kev nyab xeeb sib faib ntawm cov xov (lawv siv [`Sync`]) tab sis lawv tsis lawv tus kheej muab cov txheej txheem rau kev sib faib thiab ua raws li [threading model](../../../std/thread/index.html#the-threading-model) ntawm Rust.
//!
//! Txoj kev sib koom siab tshaj plaws los faib cov atomic variable yog muab tso rau hauv ib qho [`Arc`][arc] (ib qho sib txig sib luag atomically-siv-suav qhia qhov sib pauv).
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! Cov hom Atomic yuav khaws cia zoo li qub hloov pauv, pib siv tus pib tas li zoo li [`AtomicBool::new`].Cov atomic statics feem ntau siv rau cov kev tub nkeeg thoob ntiaj teb.
//!
//! # Portability
//!
//! Txhua cov atomic hom hauv qhov qauv no tau lees tias yuav tsum yog [lock-free] yog tias lawv muaj.Qhov no txhais tau tias lawv tsis xav tau lub ntiaj teb mutex.Atomic hom hauj lwm thiab cov tsis guaranteed yuav tos-free.
//! Qhov no txhais tau hais tias kev khiav haujlwm zoo li `fetch_or` yuav raug coj los siv nrog lub sib piv-thiab-sib hloov.
//!
//! Atomic hauj lwm tej zaum yuav muab los siv nyob rau hauv qhov kev qhia ntawv txheej nrog loj-loj atomics.Piv txwv li ib co platforms siv 4-byte atomic cov lus qhia rau kev `AtomicI8`.
//! Nco ntsoov tias qhov kev tshaj tawm no yuav tsum tsis txhob cuam tshuam txog qhov tseeb ntawm cov cai, nws tsuas yog qee yam yuav tsum paub txog.
//!
//! Cov atomic hom hauv qhov qauv no tej zaum yuav tsis muaj rau txhua lub platform.Cov atomic hom ntawm no yog tag nrho cov muaj dav, txawm li cas los xij, thiab feem ntau tuaj yeem cia siab rau qhov uas twb muaj lawm.Muaj qee qhov tsis suav tshwj xeeb yog:
//!
//! * PowerPC thiab MIPS platforms nrog 32-ntsis pointers tsis muaj `AtomicU64` los yog `AtomicI64` hom.
//! * ARM platforms xws li `armv5te` uas tsis yog ua rau Linux tsuas yog muab cov `load` thiab `store` ua hauj lwm, thiab tsis txhob pab txhawb sib piv thiab sib puav (CAS) ua hauj lwm, xws li `swap`, `fetch_add`, etc.
//! Txuas ntxiv ntawm Linux, cov haujlwm CAS tau ua raws [operating system support], uas tuaj yeem nrog lub txim txhaum.
//! * ARM cov hom phiaj nrog `thumbv6m` tsuas yog muab `load` thiab `store` kev khiav haujlwm, thiab tsis txhawb kev sib piv thiab Swap (CAS) kev khiav haujlwm, xws li `swap`, `fetch_add`, thiab lwm yam.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! Nco ntsoov tias future cov chaw txuas ntxiv tuaj yeem txuas ntxiv uas tseem tsis muaj kev txhawb nqa rau qee qhov ua haujlwm atomic.Maximally portable code yuav xav kom ceev faj txog tias hom twg ib qho me me ais siv.
//! `AtomicUsize` thiab `AtomicIsize` feem ntau thauj khoom feem ntau, tab sis txawm tias tom qab ntawd lawv tsis muaj nyob txhua qhov chaw.
//! Rau siv, cov `std` tsev qiv ntawv yuav tsum tau pointer-qhov loj qhov me atomics, txawm hais tias `core` tsis.
//!
//! Tam sim no koj yuav tsum tau siv `#[cfg(target_arch)]` feem rau conditionally compile nyob rau hauv code nrog atomics.Muaj qhov tsis ruaj khov `#[cfg(target_has_atomic)]` zoo li uas yuav muaj kev ruaj khov hauv future.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! A spinlock yooj yim:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // Tos rau lwm yam xov los tso lub xauv
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! Khaws lub ntiaj teb suav ntawm cov xov nyob:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// Ib hom boolean uas tuaj yeem sib koom ua ke ntawm kev ua xov.
///
/// Hom no muaj tib yam hauv-sawv cev cim ua ib tus [`bool`].
///
/// **Thov Cim**: Hom no tsuas yog muaj nyob rau ntawm platforms uas txhawb atomic loads thiab khw muag khoom ntawm `u8`.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// Tsim ib tug `AtomicBool` initialized rau `false`.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// Xa yog implicitly siv rau AtomicBool.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// Ib qho nyoos pointer hom uas tuaj yeem sib koom ua ke ntawm cov xov.
///
/// Qhov no hom muaj tib lub nyob rau hauv-nco sawv cev raws li ib tug `*mut T`.
///
/// **Nco Ntsoov**: Hom no tsuas yog muaj nyob rau ntawm lub platform uas txhawb cov atomic loads thiab cov khw muag khoom ntawm cov taw tes.
/// Nws loj nyob rau hauv lub hom phiaj pointer tus loj.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// Tsim cov thov `AtomicPtr<T>`.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// Atomic nco txiav txim
///
/// Cim kev txiav txim qhia kom meej txoj kev atomic haujlwm synchronize nco.
/// Hauv nws cov [`Ordering::Relaxed`] uas tsis muaj zog tshaj plaws, tsuas yog lub cim xeeb ncaj qha tau kov los ntawm lub lag luam yog synchronized.
/// Nyob rau lwm cov tes, ib lub khw-load khub ntawm [`Ordering::SeqCst`] haujlwm synchronize lwm nco thaum ntxiv khaws cia ib tug tag nrho kev txiav txim ntawm xws hauj lwm thoob plaws tag nrho cov threads.
///
///
/// Rust lub cim xaj yog [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order).
///
/// Xav paub ntau ntxiv saib hauv [nomicon].
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// Tsis muaj kev txwv kev txwv, tsuas yog kev ua haujlwm atomic.
    ///
    /// Hnov rau [`memory_order_relaxed`] nyob rau hauv C++ 20.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// Thaum muaj kev sib txuas nrog lub khw, txhua txoj haujlwm dhau los ua tus txiav txim ua ntej txhua qhov thauj khoom ntawm tus nqi no nrog [`Acquire`] (lossis cov khoom muaj zog) xaj.
    ///
    /// Hauv tshwj xeeb, tag nrho cov ntawv sau dhau los ua rau pom tag nrho cov xov uas ua ib qho [`Acquire`] (lossis muaj zog) thauj khoom ntawm tus nqi no.
    ///
    /// Daim ntawv ceeb toom tias siv qhov kev txiav txim no rau kev ua haujlwm uas sib xyaw ua ke cov khoom thauj khoom thiab khw muag khoom coj mus rau [`Relaxed`] thauj khoom!
    ///
    /// Qhov kev txiav txim no tsuas yog siv rau cov haujlwm uas tuaj yeem ua tau tom khw.
    ///
    /// Hnov rau [`memory_order_release`] nyob rau hauv C++ 20.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// Thaum ua ke nrog ib tug load, yog hais tias tus loaded nqi tau sau los ntawm ib lub khw lag luam nrog [`Release`] (los yog muaj zog) ordering, ces tag nrho cov tom ntej hauj lwm ua kom tom qab uas lub khw.
    /// Tshwj xeeb, txhua qhov thauj khoom ntxiv yuav pom cov ntaub ntawv sau ua ntej lub khw.
    ///
    /// Daim ntawv ceeb toom tias siv qhov kev txiav txim no rau kev ua haujlwm uas sib xyaw nrog cov khoom thauj khoom thiab khw muag khoom ua rau [`Relaxed`] lub lag luam!
    ///
    /// Qhov kev xaj no tsuas yog siv tau rau cov haujlwm uas tuaj yeem ua lub nra.
    ///
    /// Sib haum rau [`memory_order_acquire`] hauv C++ 20.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// Muaj cov teebmeem ntawm ob [`Acquire`] thiab [`Release`] ua ke:
    /// Rau cov ntim khoom nws siv [`Acquire`] xaj.Rau cov khw muag khoom nws siv [`Release`] xaj.
    ///
    /// Daim ntawv ceeb toom tias nyob rau hauv rooj plaub ntawm `compare_and_swap`, nws yog qhov ua tau tias kev khiav hauj lwm tas tsis ua ib lub khw muag khoom thiab yog li nws tsuas yog [`Acquire`] xaj.
    ///
    /// Txawm li cas los xij, `AcqRel` yuav tsis ua [`Relaxed`] nkag.
    ///
    /// Qhov kev xaj no tsuas yog siv tau rau kev ua haujlwm uas sib xyaw tag nrho cov thau khoom thau khoom thiab khw muag khoom.
    ///
    /// Hnov rau [`memory_order_acq_rel`] nyob rau hauv C++ 20.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// Zoo li ['Acquire`]/[' Release`]/['AcqRel`](rau load, khw, thiab load-nrog-khw ua hauj lwm, feem) nrog lub ntxiv guarantee tias tag nrho cov threads saib tag nrho cov sequentially raws hauj lwm nyob rau hauv qhov kev txiav txim Cov.
    ///
    ///
    /// Sib haum rau [`memory_order_seq_cst`] hauv C++ 20.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// Ib qho [`AtomicBool`] pib rau `false`.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// Tsim dua tshiab `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// Rov ib mutable siv rau qhov pib [`bool`].
    ///
    /// Qhov no muaj kev nyab xeeb vim hais tias cov kev sib pauv hloov tau lees tias tsis muaj lwm txoj xov tau tib lub sijhawm nkag mus hauv cov ntaub ntawv atomic.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // KEV RUAJ NTSEG: lub mutable siv guarantees cim cov tswv cuab.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// Tau atomic nkag tau mus rau ib tug `&mut bool`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // KEV RUAJ NTSEG: lub mutable siv guarantees cim cov tswv cuab, thiab
        // cov kawm tuab si lug ntawm ob `bool` thiab `Self` yog 1.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// Khaws cov atom thiab rov rau cov muaj nqi.
    ///
    /// Qhov no yog muaj kev ruaj ntseg vim hais tias dua `self` los ntawm tus nqi guarantees uas tsis muaj lwm yam threads yog tib tus txheejtxheem lub atomic cov ntaub ntawv.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// Loads ib tug nqi los ntawm lub bool.
    ///
    /// `load` siv sijhawm [`Ordering`] sib cav uas piav txog lub cim xeeb xaj ntawm kev ua haujlwm no.
    /// Cov nqi tsim nyog yog [`SeqCst`], [`Acquire`] thiab [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics yog `order` yog [`Release`] los yog [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // KEV RUAJ NTSEG: txhua cov ntaub ntawv sib tw yog tiv thaiv los ntawm atomic intrinsics thiab cov nyoos
        // pointer dhau nyob rau hauv no siv tau vim hais tias peb tau txais los ntawm ib tug reference.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// Khw tus nqi rau hauv bool.
    ///
    /// `store` siv sijhawm [`Ordering`] sib cav uas piav txog lub cim xeeb xaj ntawm kev ua haujlwm no.
    /// Cov nqi tsim nyog yog [`SeqCst`], [`Release`] thiab [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics yog `order` yog [`Acquire`] los yog [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // KEV RUAJ NTSEG: txhua cov ntaub ntawv sib tw yog tiv thaiv los ntawm atomic intrinsics thiab cov nyoos
        // pointer dhau nyob rau hauv no siv tau vim hais tias peb tau txais los ntawm ib tug reference.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// Stores ib tug nqi rau cov bool, rov qab rau hauv lub yav dhau los tus nqi.
    ///
    /// `swap` siv sijhawm [`Ordering`] sib cav uas piav txog lub cim xeeb xaj ntawm kev ua haujlwm no.Txhua qhov kev xa khoom tuaj yeem yog tau.
    /// Nco ntsoov tias kev siv [`Acquire`] ua rau lub khw muag khoom yog ib feem ntawm txoj haujlwm no [`Relaxed`], thiab siv [`Release`] ua rau cov khoom thauj khoom ib qho [`Relaxed`].
    ///
    ///
    /// **Note:** Qhov no txoj kev no tsuas muaj nyob platforms uas txhawb atomic operations on `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // KEV RUAJ NTSEG: cov ntawv sib tw yog tiv thaiv los ntawm atomic intrinsics.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// Khw tus nqi rau hauv [`bool`] yog tias tus nqi tam sim no yog tib yam li tus nqi `current`.
    ///
    /// Tus nqi xa rov qab yog ib txwm yav dhau los tus nqi.Yog hais tias nws yog sib npaug zos rau `current`, ces tus nqi twb tshiab.
    ///
    /// `compare_and_swap` kuj yuav siv sij hawm ib tug [`Ordering`] sib cav uas qhia txog lub cim xeeb ordering ntawm lub lag luam no.
    /// Daim ntawv ceeb toom tias txawm tias thaum siv [`AcqRel`], kev ua haujlwm yuav poob thiab yog li tsuas yog ua `Acquire` thauj khoom, tab sis tsis muaj `Release` cov lus qhia.
    /// Siv [`Acquire`] ua lub khw ib feem ntawm lub lag luam no [`Relaxed`] yog hais tias nws tshwm sim, thiab siv [`Release`] ua rau cov load ib feem [`Relaxed`].
    ///
    /// **Note:** Qhov no txoj kev no tsuas muaj nyob platforms uas txhawb atomic operations on `u8`.
    ///
    /// # Tebchaws rau `compare_exchange` thiab `compare_exchange_weak`
    ///
    /// `compare_and_swap` yog sib npaug rau `compare_exchange` cov nram qab no kuas kev nco orderings:
    ///
    /// Original |Kev vam meej |Ua tsis tiav
    /// -------- | ------- | -------
    /// So |So |So Rau Tau Txais |Txais |Cia Li Tso Tawm |Tso |So AcqRel |AcqRel |Txais SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` raug tso cai kom ua tsis tiav spuriously txawm tias qhov sib piv ua tiav, uas tso cai rau cov compiler kom tsim tau cov kev sib dhos zoo dua thaum cov sib piv thiab sib pauv yog siv nyob rau hauv lub voj.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Khw tus nqi rau hauv [`bool`] yog tias tus nqi tam sim no yog tib yam li tus nqi `current`.
    ///
    /// Tus nqi rov qab yog qhov tshwm sim qhia seb tus nqi tshiab tau sau tseg thiab muaj tus nqi dhau los.
    /// Ntawm kev vam meej cov nqi no tau lees tias ua ncaj rau `current`.
    ///
    /// `compare_exchange` yuav siv ob lub [`Ordering`] sib cav los piav txog lub cim xeeb xaj ntawm kev ua haujlwm no.
    /// `success` qhia txog cov kev yuav tsum tau ordering rau lub nyeem-hloov-sau lag luam uas yuav siv sij hawm qhov chaw, yog hais tias cov kev sib piv nrog `current` nca muab tsis tau.
    /// `failure` piav qhia qhov yuav tsum tau xaj ua haujlwm rau txoj haujlwm load uas tshwm sim thaum kev sib piv tsis tiav.
    /// Siv [`Acquire`] li kev vam meej ordering ua lub khw ib feem ntawm lub lag luam no [`Relaxed`], thiab siv [`Release`] ua rau cov muaj kev vam meej load [`Relaxed`].
    ///
    /// Cov tsis ua hauj lwm ordering yuav tsuas yuav [`SeqCst`], [`Acquire`] los yog [`Relaxed`] thiab yuav tsum yog sib npaug rau los yog weaker dua txoj kev vam meej ordering.
    ///
    /// **Note:** Qhov no txoj kev no tsuas muaj nyob platforms uas txhawb atomic operations on `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // KEV RUAJ NTSEG: cov ntawv sib tw yog tiv thaiv los ntawm atomic intrinsics.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Khw tus nqi rau hauv [`bool`] yog tias tus nqi tam sim no yog tib yam li tus nqi `current`.
    ///
    /// Tsis zoo li [`AtomicBool::compare_exchange`], txoj haujlwm no tau tso cai rau qhov ua tsis tiav txawm tias qhov sib piv ua tiav, uas tuaj yeem ua rau muaj kev cai ntau dua rau qee cov platform.
    ///
    /// Tus nqi rov qab yog qhov tshwm sim qhia seb tus nqi tshiab tau sau tseg thiab muaj tus nqi dhau los.
    ///
    /// `compare_exchange_weak` yuav siv ob lub [`Ordering`] sib cav los piav txog lub cim xeeb xaj ntawm kev ua haujlwm no.
    /// `success` qhia txog cov kev yuav tsum tau ordering rau lub nyeem-hloov-sau lag luam uas yuav siv sij hawm qhov chaw, yog hais tias cov kev sib piv nrog `current` nca muab tsis tau.
    /// `failure` piav qhia qhov yuav tsum tau xaj ua haujlwm rau txoj haujlwm load uas tshwm sim thaum kev sib piv tsis tiav.
    /// Siv [`Acquire`] li kev vam meej ordering ua lub khw ib feem ntawm lub lag luam no [`Relaxed`], thiab siv [`Release`] ua rau cov muaj kev vam meej load [`Relaxed`].
    /// Cov tsis ua hauj lwm ordering yuav tsuas yuav [`SeqCst`], [`Acquire`] los yog [`Relaxed`] thiab yuav tsum yog sib npaug rau los yog weaker dua txoj kev vam meej ordering.
    ///
    /// **Note:** Qhov no txoj kev no tsuas muaj nyob platforms uas txhawb atomic operations on `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // KEV RUAJ NTSEG: cov ntawv sib tw yog tiv thaiv los ntawm atomic intrinsics.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Logical "and" nrog qhov muaj nuj nqi boolean.
    ///
    /// Ua ib zajlus kom "and" lag luam nyob rau hauv qhov tam sim no tus nqi thiab qhov sib cav `val`, thiab poob lawm tus tshiab tus nqi rau cov kev tshwm sim.
    ///
    /// Rov qab cov nqi dhau los.
    ///
    /// `fetch_and` siv sijhawm [`Ordering`] sib cav uas piav txog lub cim xeeb xaj ntawm kev ua haujlwm no.Txhua qhov kev xa khoom tuaj yeem yog tau.
    /// Nco ntsoov tias kev siv [`Acquire`] ua rau lub khw muag khoom yog ib feem ntawm txoj haujlwm no [`Relaxed`], thiab siv [`Release`] ua rau cov khoom thauj khoom ib qho [`Relaxed`].
    ///
    ///
    /// **Note:** Qhov no txoj kev no tsuas muaj nyob platforms uas txhawb atomic operations on `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // KEV RUAJ NTSEG: cov ntawv sib tw yog tiv thaiv los ntawm atomic intrinsics.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// Logical "nand" nrog qhov muaj nuj nqi boolean.
    ///
    /// Ua ib zajlus kom "nand" lag luam nyob rau hauv qhov tam sim no tus nqi thiab qhov sib cav `val`, thiab poob lawm tus tshiab tus nqi rau cov kev tshwm sim.
    ///
    /// Rov qab cov nqi dhau los.
    ///
    /// `fetch_nand` siv sijhawm [`Ordering`] sib cav uas piav txog lub cim xeeb xaj ntawm kev ua haujlwm no.Txhua qhov kev xa khoom tuaj yeem yog tau.
    /// Nco ntsoov tias kev siv [`Acquire`] ua rau lub khw muag khoom yog ib feem ntawm txoj haujlwm no [`Relaxed`], thiab siv [`Release`] ua rau cov khoom thauj khoom ib qho [`Relaxed`].
    ///
    ///
    /// **Note:** Qhov no txoj kev no tsuas muaj nyob platforms uas txhawb atomic operations on `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // Peb yuav tsis siv atomic_nand no vim hais tias nws yuav ua tau nyob rau hauv ib tug bool nrog ib tug tsis tseeb nqi.
        // Qhov no tshwm sim vim hais tias cov atomic lag luam yuav ua li cas nrog rau ib qho 8-ntsis integer hauv lawv, uas yuav teem cov sab sauv 7 khoom.
        //
        // Yog li peb tsuas yog siv fetch_xor los yog sib pauv xwb.
        if val {
            // (X&tseeb)== !x Peb yuav tsum invert lub bool.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&tsis tseeb)==tseeb Peb yuav tsum teeb tsa bool rau qhov tseeb.
            //
            self.swap(true, order)
        }
    }

    /// Logical "or" nrog qhov muaj nuj nqi boolean.
    ///
    /// Ua cov haujlwm "or" cov txiaj ntsig ntawm tus nqi tam sim no thiab kev sib cav `val`, thiab teeb tsa tus nqi tshiab rau qhov tshwm sim.
    ///
    /// Rov qab cov nqi dhau los.
    ///
    /// `fetch_or` siv sijhawm [`Ordering`] sib cav uas piav txog lub cim xeeb xaj ntawm kev ua haujlwm no.Txhua qhov kev xa khoom tuaj yeem yog tau.
    /// Nco ntsoov tias kev siv [`Acquire`] ua rau lub khw muag khoom yog ib feem ntawm txoj haujlwm no [`Relaxed`], thiab siv [`Release`] ua rau cov khoom thauj khoom ib qho [`Relaxed`].
    ///
    ///
    /// **Note:** Qhov no txoj kev no tsuas muaj nyob platforms uas txhawb atomic operations on `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // KEV RUAJ NTSEG: cov ntawv sib tw yog tiv thaiv los ntawm atomic intrinsics.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// Logical "xor" nrog qhov muaj nuj nqi boolean.
    ///
    /// Ua cov haujlwm "xor" cov txiaj ntsig ntawm tus nqi tam sim no thiab kev sib cav `val`, thiab teeb tsa tus nqi tshiab rau qhov tshwm sim.
    ///
    /// Rov qab cov nqi dhau los.
    ///
    /// `fetch_xor` siv sijhawm [`Ordering`] sib cav uas piav txog lub cim xeeb xaj ntawm kev ua haujlwm no.Txhua qhov kev xa khoom tuaj yeem yog tau.
    /// Nco ntsoov tias kev siv [`Acquire`] ua rau lub khw muag khoom yog ib feem ntawm txoj haujlwm no [`Relaxed`], thiab siv [`Release`] ua rau cov khoom thauj khoom ib qho [`Relaxed`].
    ///
    ///
    /// **Note:** Qhov no txoj kev no tsuas muaj nyob platforms uas txhawb atomic operations on `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // KEV RUAJ NTSEG: cov ntawv sib tw yog tiv thaiv los ntawm atomic intrinsics.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// Rov ib mutable pointer rau qhov pib [`bool`].
    ///
    /// Ua tsis-atomic nyeem thiab sau rau lub resulting integer yuav ua tau ib cov ntaub ntawv haiv neeg.
    /// Txoj kev no feem ntau yog siv rau FFI, qhov twg kos npe ua haujlwm yuav siv `*mut bool` hloov `&AtomicBool`.
    ///
    /// Rov qab `*mut` X tus po taw qhia los ntawm kev sib qhia siv rau lub atomic no muaj kev nyab xeeb vim hais tias cov qauv atomic ua haujlwm nrog sab hauv nruab nrab.
    /// Tag nrho cov kev hloov kho ntawm ib tug atomic hloov tus nqi los ntawm ib tug muab qhia siv, thiab muaj peev xwm ua tau li ntawd yam xyuam xim raws li ntev raws li lawv siv atomic operations.
    /// Ib qho kev siv ntawm tus pointer rov qab ua tiav yuav tsum muaj `unsafe` thaiv thiab tseem yuav tsum tau tuav tib txoj kev txwv: kev ua haujlwm ntawm nws yuav tsum yog atomic.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// Fetches tus nqi, thiab siv ib tug muaj nuj nqi rau nws hais tias rov qab ib tug yeem nqi tshiab.Rov qab `Result` ntawm `Ok(previous_value)` yog tias txoj haujlwm xa rov `Some(_)`, lwm yam `Err(previous_value)`.
    ///
    /// Note: Qhov no tej zaum yuav hu rau cov kev ua ntau lub sij hawm yog hais tias tus nqi tau raug hloov los ntawm lwm cov threads nyob rau hauv lub meantime, raws li ntev raws li cov nuj nqi rov `Some(_)`, tab sis cov nuj nqi yuav tau ua ntawv thov ib zaug xwb rau cov muab tus nqi.
    ///
    ///
    /// `fetch_update` yuav siv ob lub [`Ordering`] sib cav los piav txog lub cim xeeb xaj ntawm kev ua haujlwm no.
    /// Thawj piav qhia qhov yuav tsum tau xaj rau thaum lub sijhawm ua haujlwm thaum kawg kev ua tiav thaum lub thib ob qhia txog qhov yuav tsum tau xaj kev thauj khoom.
    /// Cov sib haum mus rau txoj kev vam meej thiab tsis ua hauj lwm orderings ntawm [`AtomicBool::compare_exchange`] feem.
    ///
    /// Siv [`Acquire`] li kev vam meej ordering ua lub khw ib feem ntawm lub lag luam no [`Relaxed`], thiab siv [`Release`] ua zaum kawg kev vam meej load [`Relaxed`].
    /// Lub (failed) load ordering yuav tsuas yuav [`SeqCst`], [`Acquire`] los yog [`Relaxed`] thiab yuav tsum yog sib npaug rau los yog weaker dua txoj kev vam meej ordering.
    ///
    /// **Note:** Qhov no txoj kev no tsuas muaj nyob platforms uas txhawb atomic operations on `u8`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// Tsim ib tug tshiab `AtomicPtr`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// Rov ib mutable siv rau lwm pointer.
    ///
    /// Qhov no muaj kev nyab xeeb vim hais tias cov kev sib pauv hloov tau lees tias tsis muaj lwm txoj xov tau tib lub sijhawm nkag mus hauv cov ntaub ntawv atomic.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// Tau txais atomic nkag mus rau lub pointer.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - qhov siv tau hloov tau lees tias cov tswv cuab tshwj xeeb.
        //  - lub kawm tuab si lug ntawm `*mut T` thiab `Self` yog tib yam rau tag nrho cov platforms kev txhawb los ntawm rust, raws li pov thawj saum toj no.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// Khaws cov atom thiab rov rau cov muaj nqi.
    ///
    /// Qhov no yog muaj kev ruaj ntseg vim hais tias dua `self` los ntawm tus nqi guarantees uas tsis muaj lwm yam threads yog tib tus txheejtxheem lub atomic cov ntaub ntawv.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// Thauj khoom tus nqi ntawm lub qhov taw.
    ///
    /// `load` siv sijhawm [`Ordering`] sib cav uas piav txog lub cim xeeb xaj ntawm kev ua haujlwm no.
    /// Cov nqi tsim nyog yog [`SeqCst`], [`Acquire`] thiab [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics yog `order` yog [`Release`] los yog [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // KEV RUAJ NTSEG: cov ntawv sib tw yog tiv thaiv los ntawm atomic intrinsics.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// Khw tus nqi rau ntawm tus taw.
    ///
    /// `store` siv sijhawm [`Ordering`] sib cav uas piav txog lub cim xeeb xaj ntawm kev ua haujlwm no.
    /// Cov nqi tsim nyog yog [`SeqCst`], [`Release`] thiab [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics yog `order` yog [`Acquire`] los yog [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // KEV RUAJ NTSEG: cov ntawv sib tw yog tiv thaiv los ntawm atomic intrinsics.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// Stores ib tug nqi rau cov pointer, rov qab rau hauv lub yav dhau los tus nqi.
    ///
    /// `swap` siv sijhawm [`Ordering`] sib cav uas piav txog lub cim xeeb xaj ntawm kev ua haujlwm no.Txhua qhov kev xa khoom tuaj yeem yog tau.
    /// Nco ntsoov tias kev siv [`Acquire`] ua rau lub khw muag khoom yog ib feem ntawm txoj haujlwm no [`Relaxed`], thiab siv [`Release`] ua rau cov khoom thauj khoom ib qho [`Relaxed`].
    ///
    ///
    /// **Note:** Qhov qauv no tsuas yog muaj nyob rau hauv cov platforms uas txhawb kev atomic haujlwm ntawm cov taw tes.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // KEV RUAJ NTSEG: cov ntawv sib tw yog tiv thaiv los ntawm atomic intrinsics.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// Khw tus nqi rau hauv lub pointer yog tias tus nqi tam sim no yog tib yam li tus nqi `current`.
    ///
    /// Tus nqi xa rov qab yog ib txwm yav dhau los tus nqi.Yog hais tias nws yog sib npaug zos rau `current`, ces tus nqi twb tshiab.
    ///
    /// `compare_and_swap` kuj yuav siv sij hawm ib tug [`Ordering`] sib cav uas qhia txog lub cim xeeb ordering ntawm lub lag luam no.
    /// Daim ntawv ceeb toom tias txawm tias thaum siv [`AcqRel`], kev ua haujlwm yuav poob thiab yog li tsuas yog ua `Acquire` thauj khoom, tab sis tsis muaj `Release` cov lus qhia.
    /// Siv [`Acquire`] ua lub khw ib feem ntawm lub lag luam no [`Relaxed`] yog hais tias nws tshwm sim, thiab siv [`Release`] ua rau cov load ib feem [`Relaxed`].
    ///
    /// **Note:** Qhov qauv no tsuas yog muaj nyob rau hauv cov platforms uas txhawb kev atomic haujlwm ntawm cov taw tes.
    ///
    /// # Tebchaws rau `compare_exchange` thiab `compare_exchange_weak`
    ///
    /// `compare_and_swap` yog sib npaug rau `compare_exchange` cov nram qab no kuas kev nco orderings:
    ///
    /// Original |Kev vam meej |Ua tsis tiav
    /// -------- | ------- | -------
    /// So |So |So Rau Tau Txais |Txais |Cia Li Tso Tawm |Tso |So AcqRel |AcqRel |Txais SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` raug tso cai kom ua tsis tiav spuriously txawm tias qhov sib piv ua tiav, uas tso cai rau cov compiler kom tsim tau cov kev sib dhos zoo dua thaum cov sib piv thiab sib pauv yog siv nyob rau hauv lub voj.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Khw tus nqi rau hauv lub pointer yog tias tus nqi tam sim no yog tib yam li tus nqi `current`.
    ///
    /// Tus nqi rov qab yog qhov tshwm sim qhia seb tus nqi tshiab tau sau tseg thiab muaj tus nqi dhau los.
    /// Ntawm kev vam meej cov nqi no tau lees tias ua ncaj rau `current`.
    ///
    /// `compare_exchange` yuav siv ob lub [`Ordering`] sib cav los piav txog lub cim xeeb xaj ntawm kev ua haujlwm no.
    /// `success` qhia txog cov kev yuav tsum tau ordering rau lub nyeem-hloov-sau lag luam uas yuav siv sij hawm qhov chaw, yog hais tias cov kev sib piv nrog `current` nca muab tsis tau.
    /// `failure` piav qhia qhov yuav tsum tau xaj ua haujlwm rau txoj haujlwm load uas tshwm sim thaum kev sib piv tsis tiav.
    /// Siv [`Acquire`] li kev vam meej ordering ua lub khw ib feem ntawm lub lag luam no [`Relaxed`], thiab siv [`Release`] ua rau cov muaj kev vam meej load [`Relaxed`].
    ///
    /// Cov tsis ua hauj lwm ordering yuav tsuas yuav [`SeqCst`], [`Acquire`] los yog [`Relaxed`] thiab yuav tsum yog sib npaug rau los yog weaker dua txoj kev vam meej ordering.
    ///
    /// **Note:** Qhov qauv no tsuas yog muaj nyob rau hauv cov platforms uas txhawb kev atomic haujlwm ntawm cov taw tes.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // KEV RUAJ NTSEG: cov ntawv sib tw yog tiv thaiv los ntawm atomic intrinsics.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// Khw tus nqi rau hauv lub pointer yog tias tus nqi tam sim no yog tib yam li tus nqi `current`.
    ///
    /// Tsis zoo li [`AtomicPtr::compare_exchange`], txoj haujlwm no tau tso cai rau qhov ua tsis tiav txawm tias qhov sib piv ua tiav, uas tuaj yeem ua rau muaj kev cai ntau dua rau qee cov platform.
    ///
    /// Tus nqi rov qab yog qhov tshwm sim qhia seb tus nqi tshiab tau sau tseg thiab muaj tus nqi dhau los.
    ///
    /// `compare_exchange_weak` yuav siv ob lub [`Ordering`] sib cav los piav txog lub cim xeeb xaj ntawm kev ua haujlwm no.
    /// `success` qhia txog cov kev yuav tsum tau ordering rau lub nyeem-hloov-sau lag luam uas yuav siv sij hawm qhov chaw, yog hais tias cov kev sib piv nrog `current` nca muab tsis tau.
    /// `failure` piav qhia qhov yuav tsum tau xaj ua haujlwm rau txoj haujlwm load uas tshwm sim thaum kev sib piv tsis tiav.
    /// Siv [`Acquire`] li kev vam meej ordering ua lub khw ib feem ntawm lub lag luam no [`Relaxed`], thiab siv [`Release`] ua rau cov muaj kev vam meej load [`Relaxed`].
    /// Cov tsis ua hauj lwm ordering yuav tsuas yuav [`SeqCst`], [`Acquire`] los yog [`Relaxed`] thiab yuav tsum yog sib npaug rau los yog weaker dua txoj kev vam meej ordering.
    ///
    /// **Note:** Qhov qauv no tsuas yog muaj nyob rau hauv cov platforms uas txhawb kev atomic haujlwm ntawm cov taw tes.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // KEV RUAJ NTSEG: Qhov no tseem ceeb yog tsis zoo vim hais tias nws ua hauj lwm nyob rau hauv ib tug nqaij nyoos pointer
        // tab sis peb paub tseeb tias tus pointer siv tau (peb nyuam qhuav tau txais los ntawm `UnsafeCell` uas peb muaj los ntawm kev siv) thiab kev ua haujlwm atomic nws tus kheej tso cai rau peb kom muaj kev nyab xeeb hloov cov ntsiab lus ntawm `UnsafeCell`.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// Fetches tus nqi, thiab siv ib tug muaj nuj nqi rau nws hais tias rov qab ib tug yeem nqi tshiab.Rov qab `Result` ntawm `Ok(previous_value)` yog tias txoj haujlwm xa rov `Some(_)`, lwm yam `Err(previous_value)`.
    ///
    /// Note: Qhov no tej zaum yuav hu rau cov kev ua ntau lub sij hawm yog hais tias tus nqi tau raug hloov los ntawm lwm cov threads nyob rau hauv lub meantime, raws li ntev raws li cov nuj nqi rov `Some(_)`, tab sis cov nuj nqi yuav tau ua ntawv thov ib zaug xwb rau cov muab tus nqi.
    ///
    ///
    /// `fetch_update` yuav siv ob lub [`Ordering`] sib cav los piav txog lub cim xeeb xaj ntawm kev ua haujlwm no.
    /// Thawj piav qhia qhov yuav tsum tau xaj rau thaum lub sijhawm ua haujlwm thaum kawg kev ua tiav thaum lub thib ob qhia txog qhov yuav tsum tau xaj kev thauj khoom.
    /// Cov ntawv sau rau qhov ua tiav thiab ua tiav ntawm [`AtomicPtr::compare_exchange`] feem.
    ///
    /// Siv [`Acquire`] li kev vam meej ordering ua lub khw ib feem ntawm lub lag luam no [`Relaxed`], thiab siv [`Release`] ua zaum kawg kev vam meej load [`Relaxed`].
    /// Lub (failed) load ordering yuav tsuas yuav [`SeqCst`], [`Acquire`] los yog [`Relaxed`] thiab yuav tsum yog sib npaug rau los yog weaker dua txoj kev vam meej ordering.
    ///
    /// **Note:** Qhov qauv no tsuas yog muaj nyob rau hauv cov platforms uas txhawb kev atomic haujlwm ntawm cov taw tes.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// Hloov tus `bool` rau hauv `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // Qhov no macro xaus mus rau tsis siv rau ib co architectures.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// Tus lej zauv uas tuaj yeem sib xyaw ntawm cov xov.
        ///
        /// Qhov no hom muaj tib lub nyob rau hauv-nco sawv cev raws li qhov pib integer hom, ['
        ///
        #[doc = $s_int_type]
        /// `].
        /// Yog xav paub ntxiv txog qhov sib txawv ntawm atomic hom thiab uas tsis yog-atomic hom raws li cov lus qhia txog lub tsiv ntawm no hom, thov mus saib cov [module-level documentation].
        ///
        ///
        /// **Note:** Hom no tsuas yog muaj nyob rau ntawm lub platform uas pab txhawb cov atomic loads thiab cov khw ntawm [`
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// Ib qho piv txwv atomic pib rau `0`.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // Xa yog implicitly siv.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// Tsim lub zog tshiab atomic integer.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// Rov qab ib qho kev hloov pauv tau mus rau lwm tus suav.
            ///
            /// Qhov no muaj kev nyab xeeb vim hais tias cov kev sib pauv hloov tau lees tias tsis muaj lwm txoj xov tau tib lub sijhawm nkag mus hauv cov ntaub ntawv atomic.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// cia mut qee qhov_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq! (some_int, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - qhov siv tau hloov tau lees tias cov tswv cuab tshwj xeeb.
                //  - cov kab ke ntawm `$int_type` thiab `Self` yog qhov qub, raws li tau cog lus los ntawm $cfg_align thiab kev txheeb xyuas qhov tseeb saum toj no.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// Khaws cov atom thiab rov rau cov muaj nqi.
            ///
            /// Qhov no yog muaj kev ruaj ntseg vim hais tias dua `self` los ntawm tus nqi guarantees uas tsis muaj lwm yam threads yog tib tus txheejtxheem lub atomic cov ntaub ntawv.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// Thaub tawm tus nqi ntawm lub atomic integer.
            ///
            /// `load` siv sijhawm [`Ordering`] sib cav uas piav txog lub cim xeeb xaj ntawm kev ua haujlwm no.
            /// Cov nqi tsim nyog yog [`SeqCst`], [`Acquire`] thiab [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics yog `order` yog [`Release`] los yog [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // KEV RUAJ NTSEG: cov ntawv sib tw yog tiv thaiv los ntawm atomic intrinsics.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// Stores ib tug nqi rau cov atomic integer.
            ///
            /// `store` siv sijhawm [`Ordering`] sib cav uas piav txog lub cim xeeb xaj ntawm kev ua haujlwm no.
            ///  Cov nqi tsim nyog yog [`SeqCst`], [`Release`] thiab [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics yog `order` yog [`Acquire`] los yog [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // KEV RUAJ NTSEG: cov ntawv sib tw yog tiv thaiv los ntawm atomic intrinsics.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// Khw tus nqi ua ke rau cov khoom lag luam atomic integer, rov qab tus nqi dhau los.
            ///
            /// `swap` siv sijhawm [`Ordering`] sib cav uas piav txog lub cim xeeb xaj ntawm kev ua haujlwm no.Txhua qhov kev xa khoom tuaj yeem yog tau.
            /// Nco ntsoov tias kev siv [`Acquire`] ua rau lub khw muag khoom yog ib feem ntawm txoj haujlwm no [`Relaxed`], thiab siv [`Release`] ua rau cov khoom thauj khoom ib qho [`Relaxed`].
            ///
            ///
            /// **Ceeb toom**: Txoj kev no tsuas yog muaj nyob ntawm cov platform uas txhawb cov haujlwm atomic
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // KEV RUAJ NTSEG: cov ntawv sib tw yog tiv thaiv los ntawm atomic intrinsics.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// Khw tus nqi rau hauv cov khoom lag luam atomic integer yog tias tus nqi tam sim no yog tib yam li tus nqi `current`.
            ///
            /// Tus nqi xa rov qab yog ib txwm yav dhau los tus nqi.Yog hais tias nws yog sib npaug zos rau `current`, ces tus nqi twb tshiab.
            ///
            /// `compare_and_swap` kuj yuav siv sij hawm ib tug [`Ordering`] sib cav uas qhia txog lub cim xeeb ordering ntawm lub lag luam no.
            /// Daim ntawv ceeb toom tias txawm tias thaum siv [`AcqRel`], kev ua haujlwm yuav poob thiab yog li tsuas yog ua `Acquire` thauj khoom, tab sis tsis muaj `Release` cov lus qhia.
            ///
            /// Siv [`Acquire`] ua lub khw ib feem ntawm lub lag luam no [`Relaxed`] yog hais tias nws tshwm sim, thiab siv [`Release`] ua rau cov load ib feem [`Relaxed`].
            ///
            /// **Ceeb toom**: Txoj kev no tsuas yog muaj nyob ntawm cov platform uas txhawb cov haujlwm atomic
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Tebchaws rau `compare_exchange` thiab `compare_exchange_weak`
            ///
            /// `compare_and_swap` yog sib npaug rau `compare_exchange` cov nram qab no kuas kev nco orderings:
            ///
            /// Original |Kev vam meej |Ua tsis tiav
            /// -------- | ------- | -------
            /// So |So |So Rau Tau Txais |Txais |Cia Li Tso Tawm |Tso |So AcqRel |AcqRel |Txais SeqCst |SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` raug tso cai kom ua tsis tiav spuriously txawm tias qhov sib piv ua tiav, uas tso cai rau cov compiler kom tsim tau cov kev sib dhos zoo dua thaum cov sib piv thiab sib pauv yog siv nyob rau hauv lub voj.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// Khw tus nqi rau hauv cov khoom lag luam atomic integer yog tias tus nqi tam sim no yog tib yam li tus nqi `current`.
            ///
            /// Tus nqi rov qab yog qhov tshwm sim qhia seb tus nqi tshiab tau sau tseg thiab muaj tus nqi dhau los.
            /// Ntawm kev vam meej cov nqi no tau lees tias ua ncaj rau `current`.
            ///
            /// `compare_exchange` yuav siv ob lub [`Ordering`] sib cav los piav txog lub cim xeeb xaj ntawm kev ua haujlwm no.
            /// `success` qhia txog cov kev yuav tsum tau ordering rau lub nyeem-hloov-sau lag luam uas yuav siv sij hawm qhov chaw, yog hais tias cov kev sib piv nrog `current` nca muab tsis tau.
            /// `failure` piav qhia qhov yuav tsum tau xaj ua haujlwm rau txoj haujlwm load uas tshwm sim thaum kev sib piv tsis tiav.
            /// Siv [`Acquire`] li kev vam meej ordering ua lub khw ib feem ntawm lub lag luam no [`Relaxed`], thiab siv [`Release`] ua rau cov muaj kev vam meej load [`Relaxed`].
            ///
            /// Cov tsis ua hauj lwm ordering yuav tsuas yuav [`SeqCst`], [`Acquire`] los yog [`Relaxed`] thiab yuav tsum yog sib npaug rau los yog weaker dua txoj kev vam meej ordering.
            ///
            /// **Ceeb toom**: Txoj kev no tsuas yog muaj nyob ntawm cov platform uas txhawb cov haujlwm atomic
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // KEV RUAJ NTSEG: cov ntawv sib tw yog tiv thaiv los ntawm atomic intrinsics.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// Khw tus nqi rau hauv cov khoom lag luam atomic integer yog tias tus nqi tam sim no yog tib yam li tus nqi `current`.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// lub luag haujlwm no raug tso cai rau kom ua tiav sai sai txawm tias qhov kev sib piv ua tiav, uas tuaj yeem ua rau muaj kev cai ntau dua rau qee lub vev xaib.
            /// Tus nqi rov qab yog qhov tshwm sim qhia seb tus nqi tshiab tau sau tseg thiab muaj tus nqi dhau los.
            ///
            /// `compare_exchange_weak` yuav siv ob lub [`Ordering`] sib cav los piav txog lub cim xeeb xaj ntawm kev ua haujlwm no.
            /// `success` qhia txog cov kev yuav tsum tau ordering rau lub nyeem-hloov-sau lag luam uas yuav siv sij hawm qhov chaw, yog hais tias cov kev sib piv nrog `current` nca muab tsis tau.
            /// `failure` piav qhia qhov yuav tsum tau xaj ua haujlwm rau txoj haujlwm load uas tshwm sim thaum kev sib piv tsis tiav.
            /// Siv [`Acquire`] li kev vam meej ordering ua lub khw ib feem ntawm lub lag luam no [`Relaxed`], thiab siv [`Release`] ua rau cov muaj kev vam meej load [`Relaxed`].
            ///
            /// Cov tsis ua hauj lwm ordering yuav tsuas yuav [`SeqCst`], [`Acquire`] los yog [`Relaxed`] thiab yuav tsum yog sib npaug rau los yog weaker dua txoj kev vam meej ordering.
            ///
            /// **Ceeb toom**: Txoj kev no tsuas yog muaj nyob ntawm cov platform uas txhawb cov haujlwm atomic
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// cia mut qub= val.load(Ordering::Relaxed);
            /// voj {cia tshiab=qub * 2;
            ///     phim val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // KEV RUAJ NTSEG: cov ntawv sib tw yog tiv thaiv los ntawm atomic intrinsics.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// Ntxiv rau qhov tam sim no tus nqi, rov qab rau hauv lub yav dhau los tus nqi.
            ///
            /// Cov sijhawm haujlwm no qhwv nyob sib tshooj.
            ///
            /// `fetch_add` siv sijhawm [`Ordering`] sib cav uas piav txog lub cim xeeb xaj ntawm kev ua haujlwm no.Txhua qhov kev xa khoom tuaj yeem yog tau.
            /// Nco ntsoov tias kev siv [`Acquire`] ua rau lub khw muag khoom yog ib feem ntawm txoj haujlwm no [`Relaxed`], thiab siv [`Release`] ua rau cov khoom thauj khoom ib qho [`Relaxed`].
            ///
            ///
            /// **Ceeb toom**: Txoj kev no tsuas yog muaj nyob ntawm cov platform uas txhawb cov haujlwm atomic
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // KEV RUAJ NTSEG: cov ntawv sib tw yog tiv thaiv los ntawm atomic intrinsics.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// Muab rho tawm los ntawm tus nqi tam sim no, rov qab cov nqi yav dhau los.
            ///
            /// Cov sijhawm haujlwm no qhwv nyob sib tshooj.
            ///
            /// `fetch_sub` siv sijhawm [`Ordering`] sib cav uas piav txog lub cim xeeb xaj ntawm kev ua haujlwm no.Txhua qhov kev xa khoom tuaj yeem yog tau.
            /// Nco ntsoov tias kev siv [`Acquire`] ua rau lub khw muag khoom yog ib feem ntawm txoj haujlwm no [`Relaxed`], thiab siv [`Release`] ua rau cov khoom thauj khoom ib qho [`Relaxed`].
            ///
            ///
            /// **Ceeb toom**: Txoj kev no tsuas yog muaj nyob ntawm cov platform uas txhawb cov haujlwm atomic
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // KEV RUAJ NTSEG: cov ntawv sib tw yog tiv thaiv los ntawm atomic intrinsics.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// Bitwise "and" nrog tus nqi tam sim no.
            ///
            /// Ua ib tug Bitwise "and" lag luam nyob rau hauv qhov tam sim no tus nqi thiab qhov sib cav `val`, thiab poob lawm tus tshiab tus nqi rau cov kev tshwm sim.
            ///
            /// Rov qab cov nqi dhau los.
            ///
            /// `fetch_and` siv sijhawm [`Ordering`] sib cav uas piav txog lub cim xeeb xaj ntawm kev ua haujlwm no.Txhua qhov kev xa khoom tuaj yeem yog tau.
            /// Nco ntsoov tias kev siv [`Acquire`] ua rau lub khw muag khoom yog ib feem ntawm txoj haujlwm no [`Relaxed`], thiab siv [`Release`] ua rau cov khoom thauj khoom ib qho [`Relaxed`].
            ///
            ///
            /// **Ceeb toom**: Txoj kev no tsuas yog muaj nyob ntawm cov platform uas txhawb cov haujlwm atomic
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // KEV RUAJ NTSEG: cov ntawv sib tw yog tiv thaiv los ntawm atomic intrinsics.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// Bitwise "nand" nrog tus nqi tam sim no.
            ///
            /// Ua ib tug Bitwise "nand" lag luam nyob rau hauv qhov tam sim no tus nqi thiab qhov sib cav `val`, thiab poob lawm tus tshiab tus nqi rau cov kev tshwm sim.
            ///
            /// Rov qab cov nqi dhau los.
            ///
            /// `fetch_nand` siv sijhawm [`Ordering`] sib cav uas piav txog lub cim xeeb xaj ntawm kev ua haujlwm no.Txhua qhov kev xa khoom tuaj yeem yog tau.
            /// Nco ntsoov tias kev siv [`Acquire`] ua rau lub khw muag khoom yog ib feem ntawm txoj haujlwm no [`Relaxed`], thiab siv [`Release`] ua rau cov khoom thauj khoom ib qho [`Relaxed`].
            ///
            ///
            /// **Ceeb toom**: Txoj kev no tsuas yog muaj nyob ntawm cov platform uas txhawb cov haujlwm atomic
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13&0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // KEV RUAJ NTSEG: cov ntawv sib tw yog tiv thaiv los ntawm atomic intrinsics.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// Bitwise "or" nrog tus nqi tam sim no.
            ///
            /// Ua haujlwm me ntsis "or" kev khiav haujlwm ntawm tus nqi tam sim no thiab kev sib cav `val`, thiab teeb tsa tus nqi tshiab rau qhov tshwm sim.
            ///
            /// Rov qab cov nqi dhau los.
            ///
            /// `fetch_or` siv sijhawm [`Ordering`] sib cav uas piav txog lub cim xeeb xaj ntawm kev ua haujlwm no.Txhua qhov kev xa khoom tuaj yeem yog tau.
            /// Nco ntsoov tias kev siv [`Acquire`] ua rau lub khw muag khoom yog ib feem ntawm txoj haujlwm no [`Relaxed`], thiab siv [`Release`] ua rau cov khoom thauj khoom ib qho [`Relaxed`].
            ///
            ///
            /// **Ceeb toom**: Txoj kev no tsuas yog muaj nyob ntawm cov platform uas txhawb cov haujlwm atomic
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // KEV RUAJ NTSEG: cov ntawv sib tw yog tiv thaiv los ntawm atomic intrinsics.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// Bitwise "xor" nrog tus nqi tam sim no.
            ///
            /// Ua haujlwm me ntsis "xor" kev khiav haujlwm ntawm tus nqi tam sim no thiab kev sib cav `val`, thiab teeb tsa tus nqi tshiab rau qhov tshwm sim.
            ///
            /// Rov qab cov nqi dhau los.
            ///
            /// `fetch_xor` siv sijhawm [`Ordering`] sib cav uas piav txog lub cim xeeb xaj ntawm kev ua haujlwm no.Txhua qhov kev xa khoom tuaj yeem yog tau.
            /// Nco ntsoov tias kev siv [`Acquire`] ua rau lub khw muag khoom yog ib feem ntawm txoj haujlwm no [`Relaxed`], thiab siv [`Release`] ua rau cov khoom thauj khoom ib qho [`Relaxed`].
            ///
            ///
            /// **Ceeb toom**: Txoj kev no tsuas yog muaj nyob ntawm cov platform uas txhawb cov haujlwm atomic
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // KEV RUAJ NTSEG: cov ntawv sib tw yog tiv thaiv los ntawm atomic intrinsics.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// Fetches tus nqi, thiab siv ib tug muaj nuj nqi rau nws hais tias rov qab ib tug yeem nqi tshiab.Rov qab `Result` ntawm `Ok(previous_value)` yog tias txoj haujlwm xa rov `Some(_)`, lwm yam `Err(previous_value)`.
            ///
            /// Note: Qhov no tej zaum yuav hu rau cov kev ua ntau lub sij hawm yog hais tias tus nqi tau raug hloov los ntawm lwm cov threads nyob rau hauv lub meantime, raws li ntev raws li cov nuj nqi rov `Some(_)`, tab sis cov nuj nqi yuav tau ua ntawv thov ib zaug xwb rau cov muab tus nqi.
            ///
            ///
            /// `fetch_update` yuav siv ob lub [`Ordering`] sib cav los piav txog lub cim xeeb xaj ntawm kev ua haujlwm no.
            /// Thawj piav qhia qhov yuav tsum tau xaj rau thaum lub sijhawm ua haujlwm thaum kawg kev ua tiav thaum lub thib ob qhia txog qhov yuav tsum tau xaj kev thauj khoom.Cov no sib haum mus rau qhov ua tiav thiab tsis ua tiav kev txiav txim ntawm
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// Siv [`Acquire`] li kev vam meej ordering ua lub khw ib feem ntawm lub lag luam no [`Relaxed`], thiab siv [`Release`] ua zaum kawg kev vam meej load [`Relaxed`].
            /// Lub (failed) load ordering yuav tsuas yuav [`SeqCst`], [`Acquire`] los yog [`Relaxed`] thiab yuav tsum yog sib npaug rau los yog weaker dua txoj kev vam meej ordering.
            ///
            /// **Ceeb toom**: Txoj kev no tsuas yog muaj nyob ntawm cov platform uas txhawb cov haujlwm atomic
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (Txiaj xaj: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// assert_eq! (x.fetch_update (Txiaj xaj: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// Qhov siab tshaj nrog tus nqi tam sim no.
            ///
            /// Pom lub siab tshaj plaws ntawm qhov tam sim no tus nqi thiab qhov sib cav `val`, thiab teev cov nqi tshiab rau cov kev tshwm sim.
            ///
            /// Rov qab cov nqi dhau los.
            ///
            /// `fetch_max` siv sijhawm [`Ordering`] sib cav uas piav txog lub cim xeeb xaj ntawm kev ua haujlwm no.Txhua qhov kev xa khoom tuaj yeem yog tau.
            /// Nco ntsoov tias kev siv [`Acquire`] ua rau lub khw muag khoom yog ib feem ntawm txoj haujlwm no [`Relaxed`], thiab siv [`Release`] ua rau cov khoom thauj khoom ib qho [`Relaxed`].
            ///
            ///
            /// **Ceeb toom**: Txoj kev no tsuas yog muaj nyob ntawm cov platform uas txhawb cov haujlwm atomic
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// cia bar=42;
            /// cia max_foo=foo.fetch_max (bar, Ordering::SeqCst).max(bar);
            /// vajhuam! (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // KEV RUAJ NTSEG: cov ntawv sib tw yog tiv thaiv los ntawm atomic intrinsics.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// Yam tsawg kawg nkaus nrog tus nqi tam sim no.
            ///
            /// Pom yam tsawg kawg nkaus ntawm tus nqi tam sim no thiab kev sib cav `val`, thiab teeb tus nqi tshiab rau qhov txiaj ntsig.
            ///
            /// Rov qab cov nqi dhau los.
            ///
            /// `fetch_min` siv sijhawm [`Ordering`] sib cav uas piav txog lub cim xeeb xaj ntawm kev ua haujlwm no.Txhua qhov kev xa khoom tuaj yeem yog tau.
            /// Nco ntsoov tias kev siv [`Acquire`] ua rau lub khw muag khoom yog ib feem ntawm txoj haujlwm no [`Relaxed`], thiab siv [`Release`] ua rau cov khoom thauj khoom ib qho [`Relaxed`].
            ///
            ///
            /// **Ceeb toom**: Txoj kev no tsuas yog muaj nyob ntawm cov platform uas txhawb cov haujlwm atomic
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// cia bar=12;
            /// cia min_foo=foo.fetch_min (bar, Ordering::SeqCst).min(bar);
            /// vajhuam_eq! (min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // KEV RUAJ NTSEG: cov ntawv sib tw yog tiv thaiv los ntawm atomic intrinsics.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// Rov qab los pointerable mus rau lwm tus lej.
            ///
            /// Ua tsis-atomic nyeem thiab sau rau lub resulting integer yuav ua tau ib cov ntaub ntawv haiv neeg.
            /// Txoj kev no feem ntau yog siv rau FFI, qhov twg kos npe ua haujlwm yuav siv
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// Rov qab `*mut` X tus po taw qhia los ntawm kev sib qhia siv rau lub atomic no muaj kev nyab xeeb vim hais tias cov qauv atomic ua haujlwm nrog sab hauv nruab nrab.
            /// Tag nrho cov kev hloov kho ntawm ib tug atomic hloov tus nqi los ntawm ib tug muab qhia siv, thiab muaj peev xwm ua tau li ntawd yam xyuam xim raws li ntev raws li lawv siv atomic operations.
            /// Ib qho kev siv ntawm tus pointer rov qab ua tiav yuav tsum muaj `unsafe` thaiv thiab tseem yuav tsum tau tuav tib txoj kev txwv: kev ua haujlwm ntawm nws yuav tsum yog atomic.
            ///
            ///
            /// # Examples
            ///
            /// `` `nqos (extern-declaration)
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// extern "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // KEV RUAJ NTSEG: Safe li ntev raws li `my_atomic_op` yog atomic.
            /// tsis nyab xeeb {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // KEV RUAJ NTSEG: tus neeg hu yuav tsum khaws daim ntawv cog lus muaj kev nyab xeeb rau `atomic_store`.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // KEV RUAJ NTSEG: tus neeg hu yuav tsum khaws daim ntawv cog lus muaj kev nyab xeeb rau `atomic_load`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // KEV RUAJ NTSEG: tus neeg hu yuav tsum khaws daim ntawv cog lus muaj kev nyab xeeb rau `atomic_swap`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// Rov yav dhau los tus nqi (xws li __sync_fetch_and_add).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // KEV RUAJ NTSEG: tus neeg hu yuav tsum khaws daim ntawv cog lus muaj kev nyab xeeb rau `atomic_add`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// Xa rov qab cov nqi dhau los (xws li __sync_fetch_and_sub).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // KEV RUAJ NTSEG: tus neeg hu yuav tsum khaws daim ntawv cog lus muaj kev nyab xeeb rau `atomic_sub`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // KEV RUAJ NTSEG: tus neeg hu yuav tsum khaws daim ntawv cog lus muaj kev nyab xeeb rau `atomic_compare_exchange`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // KEV RUAJ NTSEG: tus neeg hu yuav tsum khaws daim ntawv cog lus muaj kev nyab xeeb rau `atomic_compare_exchange_weak`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // KEV RUAJ NTSEG: tus neeg hu yuav tsum khaws daim ntawv cog lus muaj kev nyab xeeb rau `atomic_and`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // KEV RUAJ NTSEG: tus neeg hu yuav tsum khaws daim ntawv cog lus muaj kev nyab xeeb rau `atomic_nand`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // KEV RUAJ NTSEG: tus neeg hu yuav tsum khaws daim ntawv cog lus muaj kev nyab xeeb rau `atomic_or`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // KEV RUAJ NTSEG: tus neeg hu yuav tsum tau uphold kev ruaj ntseg daim ntawv cog lus rau `atomic_xor`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// rov tus nqi max (kos npe sib piv)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // KEV RUAJ NTSEG: tus neeg hu yuav tsum tau uphold kev ruaj ntseg daim ntawv cog lus rau `atomic_max`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// xa rov qab cov min nqi (kos npe sib piv)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // KEV RUAJ NTSEG: tus neeg hu yuav tsum tau uphold kev ruaj ntseg daim ntawv cog lus rau `atomic_min`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// rov tus nqi max (tsis suav qhov sib piv)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // KEV RUAJ NTSEG: tus neeg hu yuav tsum tau uphold kev ruaj ntseg daim ntawv cog lus rau `atomic_umax`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// rov los rau cov nqi min (kev sib piv uas tsis tau kos npe)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // KEV RUAJ NTSEG: tus neeg hu yuav tsum khaws daim ntawv cog lus muaj kev nyab xeeb rau `atomic_umin`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// Ib qho kev atomic laj kab.
///
/// Nyob ntawm qhov kev txiav txim tshwj xeeb, ib lub laj kab txwv tsis pub lub compiler thiab CPU los ntawm reordering qee hom kev nco ua haujlwm nyob ib puag ncig nws.
/// Uas tsim synchronizes-nrog kev sib raug zoo ntawm nws thiab atomic ua hauj lwm los yog laj kab nyob rau hauv lwm yam threads.
///
/// Ib qho laj kab 'A' uas muaj (tsawg kawg) [`Release`] xaj cov ntsiab lus, synchronizes nrog lub laj kab 'B' nrog (tsawg kawg) [`Acquire`] semantics, yog thiab tsuas yog muaj kev ua haujlwm X thiab Y, ob qho kev khiav haujlwm ntawm qee cov khoom atomic 'M' xws li tias A yog ntu ua ntej X, Y yog synchronized ua ntej B thiab Y pom qhov hloov mus rau M.
/// Qhov no muab qhov tshwm sim-ua ntej tso siab ntawm A thiab B.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// Kev ua haujlwm atomic nrog [`Release`] lossis [`Acquire`] semantics tseem tuaj yeem sib dhos nrog lub laj kab.
///
/// Ib qho laj kab uas muaj [`SeqCst`] xaj, ntxiv rau muaj ob qho tib si [`Acquire`] thiab [`Release`] semantics, koom nrog qhov kev pab cuam thoob ntiaj teb kev txiav txim ntawm lwm [`SeqCst`] cov haujlwm thiab/lossis laj kab.
///
/// Lees [`Acquire`], [`Release`], [`AcqRel`] thiab [`SeqCst`] orderings.
///
/// # Panics
///
/// Panics yog `order` yog [`Relaxed`].
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // Ib tug kev sib nrig sib cais txheej thaum ub raws li spinlock.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // Tos kom txog thaum tus nqi qub yog `false`.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // Lub laj kab no ua tiav-nrog lub khw hauv `unlock`.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // KEV RUAJ NTSEG: siv lub laj kab atomic yog kev nyab xeeb.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// Lub compiler nco laj kab.
///
/// `compiler_fence` tsis emit tej tshuab code, tab sis txwv tsis pub lub hom nco re-ordering lub compiler yog tso cai rau ua.Tshwj xeeb, nyob ntawm qhov muab [`Ordering`] semantics, tus sau yuav raug tsis pom zoo los ntawm kev txav chaw nyeem lossis sau los ntawm ua ntej lossis tom qab kev hu xov tooj rau sab tod los ntawm kev hu mus rau `compiler_fence`.Nco ntsoov tias nws ua **tsis** tiv thaiv tus *kho vajtse* txhob ua qhov kev rov txiav txim siab ntawd.
///
/// Qhov no tsis yog teeb meem nyob rau hauv ib qho-xov, kev ua cov ntsiab lus teb, tab sis thaum lwm txoj xov tuaj yeem hloov kho kev nco tau tib lub sijhawm, muaj zog synchronization primitives xws li [`fence`] yog qhov yuav tsum tau ua.
///
/// Cov rov txiav txim siab tiv thaiv los ntawm qhov sib txawv raws qib ntsiab lus yog:
///
///  - nrog [`SeqCst`], tsis muaj qhov rov txiav txim siab ntawm kev nyeem ntawv thiab sau thoob plaws cov ntsiab lus no raug tso cai.
///  - nrog [`Release`], kev nyeem ua ntej nyeem thiab sau tsis tuaj yeem txav dhau los dhau los sau cia.
///  - nrog [`Acquire`], tom ntej nyeem thiab sau tsis tau tsiv ua ntej ntawm ua ntej nyeem.
///  - nrog [`AcqRel`], ob qho tib si ntawm cov saum toj no kev cai yog tswj.
///
/// `compiler_fence` yog feem ntau tsuas pab tau rau kev tiv thaiv ib tug xov los ntawm kev sib xeem khiav *nrog nws tus kheej*.Uas yog, yog tias ib tug muab xov yog executing ib daim kev cai, thiab yog ces tu ncua, thiab pib executing code lwm qhov (thaum tseem nyob rau hauv tib xov, thiab conceptually tseem nyob rau tib lub ntxhais).Hauv cov khoos kas ib txwm muaj, qhov no tsuas yog tshwm sim thaum muaj teeb meem siv tes sau npe.
/// Hauv kev cai ntau dua, qhov xwm txheej zoo li no tuaj yeem tshwm sim thaum tswj kev cuam tshuam, thaum siv cov xov ntsuab nrog kev zam ua ntej, thiab lwm yam.
/// Cov neeg nyiam nyeem tau raug txhawb kom nyeem Linux lub pob ntawm kev sib tham ntawm [memory barriers].
///
/// # Panics
///
/// Panics yog `order` yog [`Relaxed`].
///
/// # Examples
///
/// Tsis muaj `compiler_fence`, lub `assert_eq!` nyob rau hauv cov nram qab no code yog *tsis* guaranteed kawm tau ntawv zoo, txawm txhua yam tshwm sim nyob rau hauv ib thread.
/// Mus saib yog vim li cas, nco ntsoov tias lub compiler yog free swap lub khw muag khoom noj rau `IMPORTANT_VARIABLE` thiab `IS_READ` txij thaum lawv yog ob qho tib si `Ordering::Relaxed`.Yog hais tias nws ua li, thiab lub teeb liab handler yog invoked txoj cai tom qab `IS_READY` tshiab, ces lub teeb liab handler yuav pom `IS_READY=1`, tab sis `IMPORTANT_VARIABLE=0`.
/// Siv cov tshuaj kho `compiler_fence` cov teeb meem no.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // tiv thaiv ua ntej sau los ntawm tsiv mus dhau dhau qhov no
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // KEV RUAJ NTSEG: siv lub laj kab atomic yog kev nyab xeeb.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// Pib ntsais koj teeb lub processor hais tias nws yog nyob rau hauv ib tug tibneeg hu tauj coob-tos spin-voj ("tig xauv").
///
/// Lub luag haujlwm no yog qhov tsis txaus ntseeg ntawm [`hint::spin_loop`].
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}