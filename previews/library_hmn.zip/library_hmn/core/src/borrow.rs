//! Tus qauv rau kev ua haujlwm nrog cov ntaub ntawv qiv.

#![stable(feature = "rust1", since = "1.0.0")]

/// Ib tug trait rau txais cov ntaub ntawv.
///
/// Hauv Rust, nws yog ib qho muaj los muab cov sawv cev sib txawv ntawm ib hom rau kev siv sib txawv.
/// Piv txwv li, qhov chaw khaws cia thiab kev tswj hwm rau tus nqi tuaj yeem raug xaiv tshwj xeeb uas tsim nyog rau kev siv tshwj xeeb ntawm cov pointer xws li [`Box<T>`] lossis [`Rc<T>`].
/// Tshaj ntawd cov generic wrappers uas yuav siv tau nrog rau tej yam, tej yam muab los tsis ua cas kev seevcev muab uas kim functionality.
/// Ib qho piv txwv rau xws li ib tug yam yog [`String`] uas ntxiv cov peev xwm mus cuag ib txoj hlua rau lub yooj yim [`str`].
/// Qhov no yuav tsum khaws cov ntaub ntawv ntxiv tsis tsim nyog rau txoj hlua yooj yim thiab tsis hloov pauv.
///
/// Cov hom tau muab kev nkag mus rau cov ntaub ntawv hauv qab los ntawm kev xa mus rau hom ntawm cov ntaub ntawv ntawd.Lawv hais tias yuav tsum 'borrowed li' hom.
/// Piv txwv li, [`Box<T>`] tuaj yeem qiv raws li `T` thaum [`String`] tuaj yeem qiv yog `str`.
///
/// Hom qhia hais tias lawv muaj peev xwm yuav borrowed raws li ib co hom `T` los ntawm kev siv `Borrow<T>`, muab ib tug siv rau ib tug `T` nyob rau hauv lub trait lub [`borrow`] txoj kev.Ib hom yog free rau qiv raws li ob peb ntau hom.
/// Yog tias nws xav tau ob leeg qiv qev ua hom-cia cov ntaub ntawv hauv qab yuav raug hloov kho, nws tuaj yeem txuas ntxiv [`BorrowMut<T>`].
///
/// Ntxiv mus, thaum muab implementations ntxiv traits, nws yuav tsum tau raug xam tias yog seb lawv yuav tsum coj zoo tib yam rau cov neeg ntawm lwm yam raws li ib tug rau txim ntawm lub ua yeeb yam raws li ib tug sawv cev ntawm uas lwm hom.
/// Cov lej xaj feem ntau siv `Borrow<T>` thaum nws tso siab rau qhov coj tus cwj pwm zoo ntawm cov kev cai ntxiv trait.
/// Cov traits yuav tshwm sim raws li ntxiv trait bounds.
///
/// Nyob rau hauv kev `Eq`, `Ord` thiab `Hash` yuav tsum sib npaug rau borrowed thiab muaj qhov tseem ceeb: `x.borrow() == y.borrow()` yuav tsum tau muab tus raug tib yam li `x == y`.
///
/// Yog hais tias generic code pawg yuav tsum tau mus ua hauj lwm rau tag nrho cov hom uas yuav muab tau ib tug siv rau lwm yam kev hom `T`, nws yog feem ntau zoo dua siv [`AsRef<T>`] raws li ntau yam yuav xyuam xim siv nws.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Raws li ib tug cov ntaub ntawv sau, [`HashMap<K, V>`] tswv ob lub lag luam thiab qhov tseem ceeb.Yog tias tus yuam sij cov ntaub ntawv tiag tiag muab qhwv rau hauv kev tswj hwm ntawm qee yam, nws yuav tsum, txawm li cas los xij, tseem muaj peev xwm tshawb nrhiav tus nqi uas yog siv tus nqi xa mus rau tus yuam sij cov ntaub ntawv.
/// Piv txwv li, yog tias tus yuam sij yog txoj hlua, ces nws zoo li yuav khaws cia nrog daim ntawv qhia hash raws li [`String`], thaum nws yuav tsum tuaj yeem tshawb nrhiav siv [`&str`][`str`].
/// Yog li, `insert` xav tau kev ua haujlwm ntawm `String` thaum `get` xav kom siv cov `&str`.
///
/// Me ntsis yooj yim zog, hauv cov qhov chaw ntawm `HashMap<K, V>` zoo li no:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // liaj teb raug zam
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// Tag nrho hash daim ntawv qhia yog hom ntau tshaj ib hom tseem ceeb `K`.Vim hais tias cov yuam sij no yog muab nrog cov hash daim ntawv qhia, li no muaj los nyias muaj nyias tus yuam sij cov ntaub ntawv.
/// Thaum inserting ib tug tseem ceeb-nqi khub, hauv daim ntawv qhia yog muab xws li ib tug `K` thiab xav tau kev pab mus nrhiav qhov tseeb hash thoob thiab saib yog hais tias tus yuam sij yog twb tam sim no raws li nyob rau hauv uas `K`.Nws yog li ntawd yuav tsum tau `K: Hash + Eq`.
///
/// Thaum searching rau ib tug nqi nyob rau hauv daim ntawv qhia, li cas los xij, muaj los muab ib tug siv rau ib tug `K` raws li lub ntsiab mus nrhiav puas yuav tsum tau mus yeej ib txwm tsim xws li ib tug muaj nqi.
/// Rau cov hlua yuam, qhov no yuav txhais tau hais tias tus nqi `String` xav tau tsim yog nrhiav rau qhov mob uas tsuas muaj `str` xwb.
///
/// Hloov chaw, `get` tus qauv yog hom ntau tshaj ntawm hom xov tooj tseem ceeb, hu ua `Q` hauv hom kos npe saum toj no.Nws hais tias `K` borrows raws li ib tug `Q` los ntawm yuav tsum hais tias `K: Borrow<Q>`.
/// By ntxiv tau `Q: Hash + Eq`, nws pib ntsais koj teeb lub yuav tsum tau hais tias `K` thiab `Q` muaj implementations ntawm lub `Hash` thiab `Eq` traits uas tsim tib yam tau.
///
/// Qhov kev siv ntawm `get` cuam tshuam tshwj xeeb rau kev coj ua zoo ib yam ntawm `Hash` los ntawm kev txiav txim siab qhov tseem ceeb ntawm hash thoob los ntawm kev hu `Hash::hash` ntawm tus nqi `Q` txawm hais tias nws tso tus yuam sij raws li tus nqi hash xam los ntawm tus nqi `K`.
///
///
/// Raws li ib tug yuav tau txais, tus hash daim ntawv qhia so yog ib tug `K` wrapping ib `Q` nqi ua ib tug txawv hash tshaj `Q`.Piv txwv li, xav txog tej yam koj muaj ib yam uas wraps ib txoj hlua tab sis muab piv ASCII cov tsiaj ntawv uas raug nqi ntau lawv cov ntaub ntawv:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Vim tias ob qhov sib npaug sib npaug xav tau los ua kom muaj nuj nqis zoo ib yam, qhov kev siv ntawm `Hash` yuav tsum tsis quav ntsej ASCII rooj plaub, ib yam nkaus:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// Tau `CaseInsensitiveString` siv `Borrow<str>`?Nws yeej tuaj yeem muab qhov siv rau txoj hlua hlais ntawm nws txoj hlua muaj.
/// Tab sis vim hais tias nws `Hash` siv raws, nws behaves txawv los ntawm `str` thiab yog li ntawd yuav tsum tsis txhob, nyob rau hauv qhov tseeb, siv `Borrow<str>`.
/// Yog hais tias nws xav kom cia rau lwm tus nkag mus rau qhov pib `str`, nws muaj peev xwm ua li ntawd ntawm `AsRef<str>` uas tsis muaj yam ntxiv uas yuav tsum tau.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Kev ywj pheej qiv los ntawm tus nqi muaj.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// Ib tug trait rau mutably txais cov ntaub ntawv.
///
/// Ua ib tus khub rau [`Borrow<T>`] no trait tso cai rau hom qiv raws li hom lwm tus neeg los ntawm muab cov lus pom zoo hloov tau.
/// Saib [`Borrow<T>`] rau cov lus qhia ntxiv ntawm kev qiv raws li lwm hom.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Mutably borrows los ntawm ib tug muaj nqi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}