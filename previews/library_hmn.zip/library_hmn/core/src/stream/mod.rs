//! Muaj pes tsawg leeg asynchronous iteration.
//!
//! Yog tias futures yog cov txiaj ntsig tsis muaj zog, tom qab ntawd cov kwj txuas yog cov asynchronous cov khoom siv.
//! Yog tias koj tau pom koj tus kheej nrog kev khaws cov asynchronous ntawm qee yam, thiab xav tau los ua ib qho kev ua haujlwm ntawm cov ntsiab lus ntawm kev hais sau, koj yuav khiav nrawm mus rau 'streams'.
//! Cov dej ntws yog siv ntau hauv idiomatic asynchronous Rust code, yog li nws tsim nyog los ua kom paub nrog lawv.
//!
//! Ua ntej piav ntau, wb tham txog yuav ua li cas no module structured:
//!
//! # Organization
//!
//! Qhov qauv no lom zem ntau yam raws li hom:
//!
//! * [Traits] yog cov tub ntxhais feem: cov traits txhais li cas ntawm ntws ua ib ke thiab li cas koj yuav ua li cas nrog lawv.Cov hau kev ntawm traits no tsim nyog muab qee lub sijhawm kawm ntxiv rau.
//! * Tso cai muab ib co yuav pab tau txoj kev los mus tsim ib co yooj yim ntws.
//! * Structs yog feem ntau xa rov qab los hom ntawm tus ntau txoj kev rau qhov no module lub traits.Koj yuav feem ntau yog xav mus saib nyob rau txoj kev uas tsim lub `struct`, es lub `struct` nws tus kheej.
//! Yog xav paub ntxiv kom meej txog vim li cas, saib '[siv kwj](#siv-kwj)'.
//!
//! [Traits]: #traits
//!
//! Tus ntawd yog nws!Mus khawb av rau hauv kwj deg.
//!
//! # Stream
//!
//! Lub siab thiab lub siab ntawm tus qauv no yog [`Stream`] trait.Lub ntsiab ntawm [`Stream`] zoo li no:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! Tsis zoo li `Iterator`, `Stream` ua qhov sib txawv ntawm [`poll_next`] tus qauv uas yog siv thaum siv `Stream`, thiab (to-be-implemented) `next` txoj kev uas siv thaum haus ib qho dej.
//!
//! Tau txais kev pab ntawm `Stream` xwb yuav tsum xav txog `next`, uas thaum hu ua, rov ib future uas yields `Option<Stream::Item>`.
//!
//! Lub future rov qab los ntawm `next` yuav paib `Some(Item)` li ntev raws li muaj hais, thiab rau thaum lawv twb tag nrho cov tau sab sab, yuav paib `None` yuav qhia tau tias iteration lawm.
//! Yog tias peb nyob tos qee yam dab tsi asynchronous los daws, future yuav tos kom txog thaum tus kwj npaj rov muab tawm dua.
//!
//! Cov kwj ntawm ib tus neeg yuav xaiv rov pib dua iteration, thiab thiaj li hu xov tooj `next` dua yuav lossis tsis tau kawg nws xa `Some(Item)` dua ntawm qee kis.
//!
//! ['Stream`]' s full txhais muaj xws li ib tug xov tooj ntawm lwm yam kev ua zoo, tab sis lawv yog neej ntawd hais txoj kev, ua rau sab saum toj ntawm [`poll_next`], thiab kom koj tau txais lawv dawb.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Kev Siv Ua Kwj
//!
//! Tsim tus kwj ntawm koj tus kheej koom nrog ob kauj ruam: tsim `struct` los tuav tus kwj ntawm lub xeev, thiab tom qab ntawd siv [`Stream`] rau ntawd `struct`.
//!
//! Cia peb ua ib qho dej npe `Counter` uas suav los ntawm `1` rau `5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Ua ntej, lub struct:
//!
//! /// Ib lub kwj uas suav txij ib txog tsib
//! struct Counter {
//!     count: usize,
//! }
//!
//! // peb xav kom peb suav pib ntawm ib tug, thiaj li cia tus ntxiv ib tug new() txoj kev los pab.
//! // Qhov no yog tsis nruj me ntsis tsim nyog, tab sis yog yooj yim.
//! // Nco ntsoov tias peb pib `count` ntawm xoom, peb mam li pom vim li cas nyob rau hauv `poll_next()`'s siv hauv qab no.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Tom qab ntawd, peb siv `Stream` rau peb `Counter`:
//!
//! impl Stream for Counter {
//!     // peb yuav tsum tau suav nrog usize
//!     type Item = usize;
//!
//!     // poll_next() yog ib lub xwb yuav tsum tau txoj kev
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Increment peb suav.Qhov no yog vim li cas peb pib ntawm xoom.
//!         self.count += 1;
//!
//!         // Xyuas saib yog hais tias peb twb tiav lawm suav los yog tsis.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Cov tsig muaj peev xwm *tub nkeeg*.Qhov no txhais tau hais tias cia li tsim ib tug kwj tsis _do_ ib tug tag nrho ntau.Tsis muaj dab tsi tshwm sim txog thaum koj hu rau `next`.
//! Qhov no qee zaum qee qhov ua haujlwm tsis meej pem thaum tsim kom muaj kwj txhawm rau qhov tshwm sim.
//! Tus neeg sau yuav ceeb toom rau peb txog kev coj cwj pwm zoo no:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;