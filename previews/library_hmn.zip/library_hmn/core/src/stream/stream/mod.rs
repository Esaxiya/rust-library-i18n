use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Lub interface rau kev cuam tshuam nrog asynchronous tus tiv thaiv.
///
/// Qhov no yog tus thawj dej loj trait.
/// Yog xav paub ntxiv txog lub tswvyim ntawm ntws feem ntau, thov mus saib cov [module-level documentation].
/// Hauv kev tshwj xeeb, koj yuav xav paub yuav ua li cas [implement `Stream`][impl].
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// Hom ntawm cov khoom tso tawm los ntawm cov kwj deg.
    type Item;

    /// Txav mus rub tawm tus nqi tom ntej ntawm tus kwj deg no, sau npe ua haujlwm tam sim no rau sawv kev yog tias tus nqi tseem tsis tau muaj, thiab xa rov qab `None` yog tias dej ntws tawm.
    ///
    /// # Rov qab tus nqi
    ///
    /// Muaj ntau qhov kev rov qab ua tau rau kom muaj nuj nqis, txhua tus taw qhia cov kwj txawv ntawm xeev:
    ///
    /// - `Poll::Pending` txhais tau hais tias tus kwj ntawm cov nqi txuas ntxiv no tseem tsis tau npaj tiav.Kev siv yuav ua kom paub tseeb tias txoj haujlwm tam sim no yuav ceeb toom thaum tom ntej yuav muaj txiaj ntsig.
    ///
    /// - `Poll::Ready(Some(val))` txhais tau hais tias lub kwj tau ntse tsim ib tug nqi, `val`, thiab tej zaum yuav tsim ntxiv qhov tseem ceeb rau tom ntej `poll_next` hu.
    ///
    /// - `Poll::Ready(None)` txhais tau hais tias tus kwj deg kaw lawm, thiab `poll_next` yuav tsum tsis txhob rov siv ntxiv.
    ///
    /// # Panics
    ///
    /// Thaum ib tug kwj tau tiav (xa rov qab `Ready(None)` from `poll_next`), hu nws `poll_next` txoj kev dua yuav panic, thaiv mus ib txhis, los yog ua lwm yam teeb meem; lub `Stream` trait muab tsis yuav tsum tau ntawm cov teebmeem ntawm xws li ib tug hu.
    ///
    /// Txawm li cas los, raws li cov `poll_next` txoj kev yog tsis cim `unsafe`, Rust tus li ib txwm cov kev cai no: hu yuav tsum tsis txhob ua rau undefined tus cwj pwm (nco kev noj nyiaj txiag, tsis yog siv cov `unsafe` zog, los yog cov zoo li no), tsis hais txog ntawm tus kwj lub xeev.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Rov qab cov ciam dej ntawm cov seem ntev ntawm ntws.
    ///
    /// Tshwj xeeb, `size_hint()` rov tuple qhov twg rau thawj lub caij yog qhov tsawg dua ua txhua yam, thiab lub thib ob lub caij no yog lub sab sauv ua txhua yam.
    ///
    /// Qhov thib ob ib nrab ntawm cov tuple uas yog xa rov qab yog ib qho ['Option`]' <'[' usize`] '>'.
    /// Ib tug [`None`] ntawm no txhais tau tias tog twg los tsis muaj dua lwm cov paub, thiab cov ciaj ciam loj dua [`usize`].
    ///
    /// # Kev sau ntawv siv
    ///
    /// Nws tsis yog tswj cia tias ib qho kev txhim kho dej yields qhov tshaj tawm tus xov tooj ntawm cov ntsiab lus.A tsheb nees kwj yuav paib tsawg tshaj li tus sab ua txhua yam los yog ntau tshaj cov qaum txhua yam ntawm lub ntsiab.
    ///
    /// `size_hint()` yog feem ntau npaj yuav siv rau kev optimizations xws li tseg chaw rau lub ntsiab ntawm lub kwj, tab sis yuav tsum tsis txhob cia siab rau rau xws li, tso tawm bounds tshev nyob rau hauv tsis zoo code.
    /// Kev siv tsis raug ntawm `size_hint()` yuav tsum tsis txhob ua rau lub cim xeeb kev ua txhaum kev nyab xeeb.
    ///
    /// Uas hais tias, qhov kev siv yuav tsum tau muab ib tug muaj tseeb xwm, vim hais tias txwv tsis pub nws yuav ib tug ua txhaum ntawm lub trait tus raws tu qauv.
    ///
    /// Lub neej ntawd yuav ua raws li rov qab '(0,' ['None`]') 'uas yog muaj tseeb rau tej kwj.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}