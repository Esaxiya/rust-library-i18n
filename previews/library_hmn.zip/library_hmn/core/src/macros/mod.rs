#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Nthuav Dav los yog `$crate::panic::panic_2015` los yog `$crate::panic::panic_2021` nyob rau hauv lub tsab ntawm tus neeg hu.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Asserts tias ob tug kab zauv uas sib npaug zos rau txhua lwm yam (siv [`PartialEq`]).
///
/// Nyob rau panic, qhov no macro yuav sau qhov tseem ceeb ntawm cov kab zauv nrog lawv debug duab kos tau tshwm.
///
///
/// Zoo li [`assert!`], qhov macro no muaj daim ntawv thib ob, qhov kev cai panic tuaj yeem muab tau.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Lub reborrows hauv qab no yog txhob txwm ua.
                    // Yog tsis muaj lawv, lub teeb qhov rau lub qiv yog initialized txawm ua ntej lub qhov tseem ceeb yog muab piv, ua rau ib tug hnov li qeeb.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Lub reborrows hauv qab no yog txhob txwm ua.
                    // Yog tsis muaj lawv, lub teeb qhov rau lub qiv yog initialized txawm ua ntej lub qhov tseem ceeb yog muab piv, ua rau ib tug hnov li qeeb.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Qhia tias ob qho kev hais tawm tsis yog sib npaug rau ib leeg (siv [`PartialEq`]).
///
/// Nyob rau panic, qhov no macro yuav sau qhov tseem ceeb ntawm cov kab zauv nrog lawv debug duab kos tau tshwm.
///
///
/// Zoo li [`assert!`], qhov macro no muaj daim ntawv thib ob, qhov kev cai panic tuaj yeem muab tau.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Lub reborrows hauv qab no yog txhob txwm ua.
                    // Yog tsis muaj lawv, lub teeb qhov rau lub qiv yog initialized txawm ua ntej lub qhov tseem ceeb yog muab piv, ua rau ib tug hnov li qeeb.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Lub reborrows hauv qab no yog txhob txwm ua.
                    // Yog tsis muaj lawv, lub teeb qhov rau lub qiv yog initialized txawm ua ntej lub qhov tseem ceeb yog muab piv, ua rau ib tug hnov li qeeb.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Lus hauv no teb Hais tias qhov kev nthuav dav boolean yog `true` thaum lub sij hawm runtime.
///
/// Qhov no yuav ua tau rau tus tus [`panic!`] macro yog hais tias tus muab qhia tsis tau soj ntsuam los `true` ntawm runtime.
///
/// Zoo li [`assert!`], qhov no macro kuj muaj ib tug thib ob version, qhov twg ib tug kev cai panic lus yuav muab.
///
/// # Uses
///
/// Tsis zoo li [`assert!`], `debug_assert!` nqe lus no xwb enabled nyob rau hauv cov optimized ua los lub neej ntawd.
/// Ib qhov zoo muaj yuav tsis ua `debug_assert!` nqe lus tshwj tsis yog tias `-C debug-assertions` yog kis mus rau cov compiler.
/// Qhov no ua rau `debug_assert!` pab tau rau cov tshev mis uas yog ib yam nkaus thiab kim kim thiaj muaj tam sim no nyob rau hauv ib tug tso tawm muaj tab sis tej zaum yuav pab tau thaum lub sij hawm txoj kev loj hlob.
/// Qhov tshwm sim ntawm kev nthuav dav `debug_assert!` yog ib txwm ntaus cim.
///
/// Ib tug tsi kuaj xyuas assertion tso cai ib qho kev pab nyob rau hauv ib tug inconsistent lub xeev kom khiav, uas tej zaum yuav muaj kev npaj txhij txog txim tab sis tsis paub unsafety li ntev raws li qhov no tsuas yog tshwm sim nyob rau hauv kev ruaj ntseg code.
///
/// Cov kev ua tau tus nqi ntawm assertions, txawm li cas los, yog tsis cuam nyob rau hauv feem ntau.
/// Hloov [`assert!`] nrog `debug_assert!` yog li tsuas xav kom tom qab txhij txhua profiling, thiab tseem ceeb tshaj mas, tsuas yog nyob rau hauv kev ruaj ntseg code!
///
/// # Examples
///
/// ```
/// // lub panic lus rau cov assertions yog lub stringified nqi ntawm cov kev qhia muab.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // ib tug yooj yim heev muaj nuj nqi
/// debug_assert!(some_expensive_computation());
///
/// // hais tawm nrog cov lus cai
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Asserts tias ob tug kab zauv uas sib npaug zos rau txhua lwm yam.
///
/// Nyob rau panic, qhov no macro yuav sau qhov tseem ceeb ntawm cov kab zauv nrog lawv debug duab kos tau tshwm.
///
/// Tsis zoo li [`assert_eq!`], `debug_assert_eq!` nqe lus no xwb enabled nyob rau hauv cov optimized ua los lub neej ntawd.
/// Ib qhov zoo muaj yuav tsis ua `debug_assert_eq!` nqe lus tshwj tsis yog tias `-C debug-assertions` yog kis mus rau cov compiler.
/// Qhov no ua rau `debug_assert_eq!` pab tau rau cov tshev mis uas yog ib yam nkaus thiab kim kim thiaj muaj tam sim no nyob rau hauv ib tug tso tawm muaj tab sis tej zaum yuav pab tau thaum lub sij hawm txoj kev loj hlob.
///
/// Cov tshwm sim ntawm expanding `debug_assert_eq!` yog yeej ib txwm hom soj ntsuam.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Asserts tias ob tug kab zauv uas tsis sib npaug zos rau txhua lwm yam.
///
/// Nyob rau panic, qhov no macro yuav sau qhov tseem ceeb ntawm cov kab zauv nrog lawv debug duab kos tau tshwm.
///
/// Tsis zoo li [`assert_ne!`], `debug_assert_ne!` nqe lus no xwb enabled nyob rau hauv cov optimized ua los lub neej ntawd.
/// Kev tsim kho tsim yuav tsis ua tiav `debug_assert_ne!` cov lus tshwj tsis yog `-C debug-assertions` dhau mus rau lub compiler.
/// Qhov no ua rau `debug_assert_ne!` pab tau rau cov tshev uas yuav kim heev yuav tsum tau muaj nyob rau hauv kev tsim tawm tiam sis tej zaum yuav pab tau thaum tsim kho.
///
/// Qhov tshwm sim ntawm kev nthuav dav `debug_assert_ne!` yog ib txwm ntaus cim.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Rov qab los seb puas muab kev qhia ntais ntawv ib yam ntawm cov muab cov qauv.
///
/// Zoo li nyob rau hauv ib tug `match` qhia, tus qauv yuav tsum optionally ua raws li los ntawm `if` thiab ib lub khwb qhia tias muaj kev nkag tau mus rau npe ua txhua yam los ntawm cov qauv.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Unwraps ib tug tshwm sim los yog propagates nws kev ua yuam kev.
///
/// Tus neeg teb xov tooj `?` tau ntxiv los hloov `try!` thiab yuav tsum siv txoj kev hloov tshiab.
/// Tsis tas li ntawd, `try` yog ib tug reserved lo lus nyob rau hauv Rust 2018, yog li ntawd yog koj yuav tsum tau siv nws, koj yuav tsum tau siv cov [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` ntais ntawv muab [`Result`].Nyob rau hauv cov ntaub ntawv ntawm lub `Ok` variant, cov kev qhia muaj tus nqi ntawm cov qhwv tus nqi.
///
/// Nyob rau hauv cov ntaub ntawv ntawm lub `Err` variant, nws retrieves lub puab yuam kev.`try!` ces ua hloov dua siab tshiab siv `From`.
/// Qhov no yog qhia tsis siv neeg hloov dua siab tshiab ntawm tshwj xeeb kom raug thiab ntau general sawv daws yuav.
/// Qhov tshwm sim yuam kev yog tom qab ntawd xa rov qab.
///
/// Vim hais tias ntawm thaum ntxov rov qab, `try!` yuav tsuas yuav siv nyob rau hauv kev khiav dej num uas rov qab [`Result`].
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Qhov zoo tshaj ntawm txoj kev rov qab ua yuam kev kom sai
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Cov yav tas los txoj kev ceev rov qab uas tsis
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Qhov no yog sib npaug rau:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Sau cov ntaub ntawv uas sau rau hauv cov tsis xwm yeem.
///
/// Tus macro no lees txais 'writer', ib hom kab ntawv, thiab muaj cov lus sib cav.
/// Cov lus sib cav yuav tsum formatted raws li cov kev cai tswjhwm hom hlua thiab cov yuav kis mus rau cov kws ntawv.
/// Tus kws sau ntawv tej zaum yuav tej nqi nrog ib tug `write_fmt` txoj kev;feem ntau qhov no los ntawm ib qho kev siv ntawm tus [`fmt::Write`] los yog lub [`io::Write`] trait.
/// ມະ ຫາ ພາກ rov ua txhua yam `write_fmt` rov qab los;feem ntau ib tug [`fmt::Result`], los yog ib tug [`io::Result`].
///
/// Saib [`std::fmt`] kom paub cov ntaub ntawv ntau ntxiv ntawm cov qauv xov kab.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Ib tug module yuav import ob `std::fmt::Write` thiab `std::io::Write` thiab hu `write!` rau cov khoom siv tog twg los, raws li cov khoom tsis feem ntau siv ob qho tib si.
///
/// Txawm li cas los, lub module yuav tsum import traits tsim nyog li lawv cov npe ua tsis muaj teeb meem:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // siv fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // siv io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Qhov no macro yuav siv tau nyob rau hauv `no_std` setups zoo li.
/// Nyob rau hauv ib tug `no_std` teeb koj yog lub luag hauj lwm rau qhov kev siv cov ntsiab lus ntawm lub Cheebtsam.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Sau cov ntaub ntawv uas sau rau hauv ntawv tsis xwm yeem, ib kab tshiab ntxiv.
///
/// Ntawm txhua lub vev xaib, txoj kab tshiab yog cov LINE FEED tus cim (`\n`/`U+000A`) ib leeg (tsis muaj TSHOOJ YEEM Rov qab (`\r`/`U+000D`).
///
/// Yog xav paub ntxiv, saib [`write!`].Rau cov lus qhia nyob rau hauv cov hom ntawv txoj hlua syntax, saib [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Ib tug module yuav import ob `std::fmt::Write` thiab `std::io::Write` thiab hu `write!` rau cov khoom siv tog twg los, raws li cov khoom tsis feem ntau siv ob qho tib si.
/// Txawm li cas los, lub module yuav tsum import traits tsim nyog li lawv cov npe ua tsis muaj teeb meem:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // siv fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // siv io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Qhia unreachable code.
///
/// Qhov no yog qhov siv tau txhua lub sijhawm uas cov kwv yees tsis tuaj yeem txiav txim siab tias qee qhov cai tsis txog.Piv txwv li:
///
/// * Phim npab nrog tus neeg zov nyas.
/// * Loops uas muaj zog ua haujlwm.
/// * Cov kws txawj txiav uas ruaj khov.
///
/// Yog hais tias qhov kev txiav txim hais tias tus code yog unreachable proves tsis muaj tseeb, qhov kev pab cuam tam sim ntawd terminates nrog ib tug [`panic!`].
///
/// Cov tsis zoo counterpart ntawm no macro yog lub [`unreachable_unchecked`] muaj nuj nqi, uas yuav ua rau undefined tus cwj pwm yog hais tias tus code yog mus txog.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Qhov no yuav yeej ib txwm [`panic!`].
///
/// # Examples
///
/// Phim npab:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // xam qhov yuam kev yog hais tias tawm
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // ib tug ntawm lub poorest implementations ntawm x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Qhia unimplemented code los ntawm panicking nrog ib tug cov lus ntawm "not implemented".
///
/// Qhov no tso cai rau koj cov cai kom ntaus-tshawb xyuas, uas muaj txiaj ntsig yog tias koj ua qauv lossis siv trait uas yuav tsum muaj ntau txoj kev uas koj tsis npaj siv txhua yam.
///
/// Qhov txawv ntawm `unimplemented!` thiab [`todo!`] yog tias thaum `todo!` qhia ib qho hom phiaj ntawm kev siv lub functionality tom qab thiab cov lus yog "not yet implemented", `unimplemented!` ua rau tsis muaj neeg pab leg ntaubntawv.
/// Nws cov lus yog "not implemented".
/// Tsis tas li ntawd ib co IDEs yuav kos tus cim 'todo!' S.
///
/// # Panics
///
/// Qhov no yuav nco ntsoov [`panic!`] vim `unimplemented!` tsuas yog qhia luv luv rau `panic!` nrog cov ntawv ruaj ruaj, hais tshwj xeeb.
///
/// Zoo li `panic!`, qhov no macro muaj ib tug thib ob daim ntawv rau displaying kev cai qhov tseem ceeb.
///
/// # Examples
///
/// Hais tias peb muaj ib tug trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Peb xav kom muaj kev `Foo` rau 'MyStruct', tab sis rau ib txhia yog vim li cas nws tsuas ua rau kev nkag siab rau kev lub `bar()` muaj nuj nqi.
/// `baz()` thiab `qux()` tseem yuav tau muab txhais rau hauv peb kev siv ntawm `Foo`, tiam sis peb yuav siv `unimplemented!` nyob rau hauv lawv txhais cov ntsiab lus kom tso cai rau peb code rau compile.
///
/// Peb tseem xav kom peb txoj haujlwm tso tseg tsis ua haujlwm yog tias tsis tau siv txoj hauv kev.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // Nws ua rau tsis muaj kev nkag siab rau `baz` ib `MyStruct`, li ntawd, peb tsis muaj logic ntawm no nyob rau tag nrho cov.
/////
///         // Qhov no yuav tso saib "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Peb muaj ib co logic no, Peb yuav tau ntxiv ib cov lus rau unimplemented!los qhia peb kev faib tawm.
///         // Qhov no yuav tso saib: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Qhia tsis tas code.
///
/// Qhov no yuav pab tau yog hais tias koj qauv thiab yog cia li nrhiav kom muaj koj code typecheck.
///
/// Qhov txawv ntawm [`unimplemented!`] thiab `todo!` yog tias thaum `todo!` qhia ib qho hom phiaj ntawm kev siv lub functionality tom qab thiab cov lus yog "not yet implemented", `unimplemented!` ua rau tsis muaj neeg pab leg ntaubntawv.
/// Nws cov lus yog "not implemented".
/// Tsis tas li ntawd ib co IDEs yuav kos tus cim 'todo!' S.
///
/// # Panics
///
/// Qhov no yuav yeej ib txwm [`panic!`].
///
/// # Examples
///
/// Ntawm no yog ib qho piv txwv txog qee qhov ua tau ntawm tus lej.Peb muaj trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Peb xav kom muaj kev `Foo` rau ib qho ntawm peb hom, tab sis peb kuj xav mus ua hauj lwm nyob rau hauv cia li `bar()` thawj.Nyob rau hauv kev txiav txim rau peb code rau compile, peb yuav tsum tau siv `baz()`, li ntawd, peb yuav siv `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // kev siv mus no
///     }
///
///     fn baz(&self) {
///         // wb tsis txhawj txog kev siv baz() rau tam sim no
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // peb yuav tsis txawm siv baz(), yog li no yog ib qho zoo.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Txhais cov ntsiab lus ntawm ua-nyob rau hauv macros.
///
/// Feem ntau ntawm cov macro zog (stability, visibility, etc.) yog npaum li cas los ntawm qhov code no, nrog kev zam ntawm expansion zog transforming macro inputs rau hauv outputs, cov neeg khiav dej num yog muab los ntawm lub compiler.
///
///
pub(crate) mod builtin {

    /// Ua muab tso ua ke kom tsis nrog qhov muab yuam kev cov lus thaum ces yuav tsum.
    ///
    /// Qhov no macro yuav tsum tau siv thaum muaj ib tug crate siv ib tug nyob ntawm muab tso ua ke zoo los muab zoo dua kev ua yuam kev lus rau erroneous tej yam kev mob.
    ///
    /// Nws yog ib qhov compiler-theem hauv daim ntawv ntawm [`panic!`], tab sis emits ib qho yuam kev thaum lub sij hawm *muab tso ua ke* es thaum *runtime*.
    ///
    /// # Examples
    ///
    /// Ob tug xws piv txwv yog macros thiab `#[cfg]` tej kev kawm.
    ///
    /// Emit zoo dua compiler yuam kev yog tias macro dhau qhov tsis raug.
    /// Yog tsis muaj branch zaum kawg, tus sau yuav tseem tso tawm ib qho kev ua yuam kev, tab sis cov lus yuam kev yuav tsis hais txog ob qho tseem ceeb siv tau.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Emit compiler kev ua yuam kev, yog hais tias ib tug ntawm ib tug xov tooj ntawm cov nta yog tsis muaj.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Constructs tsis rau lwm txoj hlua-formatting macros.
    ///
    /// Qhov no macro zog los ntawm kev noj ib formatting txoj hlua literal muaj `{}` rau txhua ntxiv sib cav dhau lawm.
    /// `format_args!` npaj cov kev txwv ntxiv kom ntseeg tau tias qhov tawm tuaj yeem raug txhais raws li txoj hlua thiab canonicalizes cov kev sib cav rau hauv ib hom.
    /// Tej nqi uas implements lub [`Display`] trait yuav kis mus rau `format_args!`, raws li yuav ua tej [`Debug`] siv yuav dhau mus rau ib tug `{:?}` nyob rau hauv lub formatting txoj hlua.
    ///
    ///
    /// Qhov no macro ua ib tug nqi ntawm hom [`fmt::Arguments`].Qhov no tus nqi yuav kis tau mus rau lub macros hauv [`std::fmt`] rau kev ua tau zoo pab tau mus.
    /// Tag nrho lwm yam kev sau ntawv macros ([`hom ntawv!`], [`write!`], [`println!`], thiab lwm yam) tau tawm los ntawm qhov no.
    /// `format_args!`, tsis zoo li nws muab macros, txhob heap nyiaj.
    ///
    /// Koj siv tau cov [`fmt::Arguments`] nqi uas `format_args!` rov nyob rau hauv `Debug` thiab `Display` ntsiab lus raws li pom hauv qab no.
    /// Cov piv txwv kuj qhia tau hais tias `Debug` thiab `Display` hom mus rau qhov qub: lub interpolated hom hlua nyob rau hauv `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Yog xav paub ntxiv, mus saib cov ntaub ntawv nyob rau hauv [`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Tib yam li `format_args`, tab sis ntxiv ib newline nyob rau hauv lub kawg.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Inspects ib qho chaw nce mus nce los ntawm compile lub sij hawm.
    ///
    /// Qhov no macro yuav nthuav mus rau tus nqi ntawm lub npe chaw nce mus nce los ntawm compile lub sij hawm, yielding ib qho kev qhia ntawm hom `&'static str`.
    ///
    ///
    /// Yog hais tias cov ib puag ncig kuj sib txawv thiab tsis txhais, ces ib tug muab tso ua ke yuam kev no yuav tsum tawm txim liab.
    /// Yuav kom tsis emit ib tug compile kev ua yuam kev, siv lub [`option_env!`] macro xwb.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Koj yuav customize cov kev ua yuam kev cov lus los ntawm xeem dhau ib txoj hlua li lub thib ob parameter:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Yog hais tias lub `documentation` chaw nce mus nce los yog tsis txhais, koj mam li tau txais lub nram qab no yuam kev:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Xaiv yeem tshawb xyuas qhov kev hloov pauv ib puag ncig ntawm kev suav sau lub sijhawm.
    ///
    /// Yog hais tias lub npe hu puag ncig nce mus nce los yog tam sim no nyob rau ntawm lub compile lub sij hawm, qhov no yuav nthuav mus rau hauv ib qho kev qhia ntawm hom `Option<&'static str>` uas nws muaj nqis yog `Some` ntawm tus nqi ntawm qhov chaw nce mus nce los.
    /// Yog hais tias cov ib puag ncig kuj sib txawv thiab yog tsis tam sim no, ces qhov no yuav nthuav rau `None`.
    /// Saib [`Option<T>`][Option] rau cov lus qhia ntxiv nyob rau hauv no hom.
    ///
    /// Ib tug compile lub sij hawm yuam kev yog yeej tsis tawm txim liab thaum uas siv cov macro hais txog ntawm seb cov ib puag ncig kuj sib txawv thiab yog tam sim no los yog tsis.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Concatenates identifiers mus rau hauv ib tug qhia tau.
    ///
    /// Qhov no macro yuav siv sij hawm yam tsawg comma-cais identifiers, thiab concatenates lawv tag nrho mus rau hauv ib tug, yielding ib qho kev qhia uas yog ib tug tshiab ua qhia tau.
    /// Nco ntsoov tias kev tu cev yuav ua rau nws xws li tias qhov no macro yuav tsis ntes zos zog.
    /// Ntxiv thiab, raws li txoj cai dav dav, macros tsuas yog raug tso cai hauv khoom, nqe lus lossis qhia chaw.
    /// Nws txhais tau tias thaum koj tuaj yeem siv cov ntawv loj heev no rau kev xa mus rau cov hloov pauv tam sim no, haujlwm lossis cov qauv thiab lwm yam, koj tsis tuaj yeem txhais qhov tshiab nrog nws.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (tshiab, lom zem, lub npe) { }//tsis siv tau nyob hauv txoj kev no!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Concatenates literals rau hauv ib tug zoo li qub hlua hlais.
    ///
    /// Cov ntawv loj no yuav siv cov lej ntawm kev sib cais, sib txawv, uas qhia txog hom `&'static str` uas sawv cev rau txhua yam ntawm cov ntawv nyeem xaus sab laug rau sab xis.
    ///
    ///
    /// Integer thiab floating taw tes literals yog stringified nyob rau hauv thiaj li yuav concatenated.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Nthuav rau tus lej kab uas nws tau hu.
    ///
    /// Nrog [`column!`] thiab [`file!`], cov macros muab debugging cov ntaub ntawv rau developers txog qhov chaw nyob rau hauv lub qhov chaw.
    ///
    /// Cov txhab qhia muaj hom `u32` thiab yog 1-raws li, ces tus thawj kab nyob rau hauv txhua cov ntaub ntawv ntsuas kom 1, tus thib ob mus rau 2, etc.
    /// Qhov no yog raws li kev ua yuam kev lus los ntawm ntau compilers los yog nrov editors.
    /// Cov rov qab kab yog *tsis tas* txoj kab ntawm lub `line!` invocation nws tus kheej, tab sis, theej thawj macro invocation ua mus txog rau lub invocation ntawm tus `line!` macro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Nthuav rau kem kab uas nws tau hu.
    ///
    /// Nrog [`line!`] thiab [`file!`], cov macros muab debugging cov ntaub ntawv rau developers txog qhov chaw nyob rau hauv lub qhov chaw.
    ///
    /// Cov txhab qhia muaj hom `u32` thiab yog 1-raws li, ces tus thawj kem nyob rau hauv txhua txoj kab ntsuas kom 1, tus thib ob mus rau 2, etc.
    /// Qhov no yog raws li kev ua yuam kev lus los ntawm ntau compilers los yog nrov editors.
    /// Cov rov qab kem yog *tsis tas* txoj kab ntawm lub `column!` invocation nws tus kheej, tab sis, theej thawj macro invocation ua mus txog rau lub invocation ntawm tus `column!` macro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Nthuav Dav los cov ntaub ntawv npe nyob rau hauv uas nws tau invoked.
    ///
    /// Nrog [`line!`] thiab [`column!`], cov macros no muab kev debugging cov ntaub ntawv rau cov neeg tsim khoom txog qhov chaw nyob hauv qhov chaw.
    ///
    /// Cov lus nthuav dav tau muaj hom `&'static str`, thiab cov ntaub ntawv xa rov qab tsis yog qhov kev xa xov ntawm `file!` macro nws tus kheej, tab sis, theej thawj macro invocation ua rau txoj kev tau txais ntawm `file!` macro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Stringifies nws cov lus.
    ///
    /// Qhov no macro yuav paib ib qho kev qhia ntawm hom `&'static str` uas yog lub stringification ntawm tag nrho cov tokens kis mus rau cov macro.
    /// Tsis muaj kev txwv yog muab tso rau hauv syntax ntawm lub macro invocation nws tus kheej.
    ///
    /// Nco ntsoov tias lub txhab kev soj ntsuam ntawm lub tswv yim tokens tej zaum yuav hloov nyob rau hauv lub future.Koj yuav tsum tau ceev faj, yog hais tias koj cia siab rau cov qhov tso zis.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Xws li ib tug UTF-8 encoded ntaub ntawv raws li ib txoj hlua.
    ///
    /// Cov ntaub ntawv yog nyob ntu ntawm cov ntaub ntawv tam sim no (zoo ib yam li cov ntsuas tau pom li cas).
    /// Cov kab ntawv tau muab txhais nyob rau hauv lub platform kev tshwj xeeb ntawm kev suav lub sijhawm.
    /// Yog li, piv txwv li, ib qho kev tso cai nrog Windows txoj kab uas muaj cov backslashes `\` yuav tsis suav qhov tseeb ntawm Unix.
    ///
    ///
    /// Daim ntawv loj no yuav yauv qhia txog hom `&'static str` uas yog cov ntsiab lus ntawm cov ntaub ntawv.
    ///
    /// # Examples
    ///
    /// Xav hais tias muaj ob cov ntaub ntawv nyob rau hauv tib lub directory nrog rau cov nram qab no txheem:
    ///
    /// Ntaub ntawv 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Ntaub ntawv 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// Compiling 'main.rs' thiab khiav lub resulting binary yuav sau "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Xws li ib cov ntaub ntawv raws li ib tug siv rau ib tug byte array.
    ///
    /// Cov ntaub ntawv yog nyob ntu ntawm cov ntaub ntawv tam sim no (zoo ib yam li cov ntsuas tau pom li cas).
    /// Cov kab ntawv tau muab txhais nyob rau hauv lub platform kev tshwj xeeb ntawm kev suav lub sijhawm.
    /// Yog li, piv txwv li, ib qho kev tso cai nrog Windows txoj kab uas muaj cov backslashes `\` yuav tsis suav qhov tseeb ntawm Unix.
    ///
    ///
    /// Daim ntawv loj no yuav yauv qhia txog hom `&'static [u8; N]` uas yog cov ntsiab lus ntawm cov ntaub ntawv.
    ///
    /// # Examples
    ///
    /// Xav hais tias muaj ob cov ntaub ntawv nyob rau hauv tib lub directory nrog rau cov nram qab no txheem:
    ///
    /// Ntaub ntawv 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Ntaub ntawv 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// Compiling 'main.rs' thiab khiav lub resulting binary yuav sau "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Nthuav tawm mus rau txoj hlua uas sawv cev rau tam sim no qhov kev siv module.
    ///
    /// Tus tam sim no module txoj kev muaj peev xwm yuav xav txog li lub hierarchy ntawm modules ua rov qab mus txog rau lub crate root.
    /// Tus thawj feem ntawm txoj kev rov qab yog ib lub npe ntawm lub crate tam sim no yog tso ua ke.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Ntsuas boolean ob peb ua ke ntawm configuration chij ntawm compile-lub sij hawm.
    ///
    /// Nyob rau hauv tas li ntawd mus rau lub `#[cfg]` attribute, qhov no macro yog muab rau cia boolean qhia kev luj xyuas ntawm configuration chij.
    /// Qhov no feem ntau ua rau tsawg duplicated code.
    ///
    /// Cov lus muab rau macro no yog tib qho ntawm cov cwj pwm [`cfg`].
    ///
    /// `cfg!`, tsis zoo li `#[cfg]`, tsis tshem tawm tej code thiab tsuas yog ntsuas kom muaj tseeb los yog cuav.
    /// Piv txwv li, tag nrho cov blocks nyob rau hauv ib tug if/else qhia yuav tsum tau yuav siv tau thaum `cfg!` yog siv rau cov mob, tsis hais dab tsi `cfg!` yog ntsuam.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Parses ib cov ntaub ntawv raws li ib qho kev qhia los yog ib yam khoom raws li lub ntsiab lus teb.
    ///
    /// Cov ntaub ntawv yog nyob ntu ntawm cov ntaub ntawv tam sim no (zoo ib yam li cov ntsuas tau pom li cas).Cov muab kev yog txhais nyob rau hauv ib tug platform kev txoj kev thaum compile lub sij hawm.
    /// Yog li, piv txwv li, ib qho kev tso cai nrog Windows txoj kab uas muaj cov backslashes `\` yuav tsis suav qhov tseeb ntawm Unix.
    ///
    /// Siv cov macro yog feem ntau ib tug lub tswv yim phem, vim hais tias yog cov ntaub ntawv yog parsed li ib qho kev qhia, nws yuav tsum muab tso rau hauv lub surrounding code unhygienically.
    /// Qhov no tuaj yeem ua rau cov lej sib txawv lossis cov haujlwm ua txawv ntawm cov ntawv xav kom ua li cas yog muaj ntau lub zog lossis cov haujlwm uas muaj tib lub npe hauv cov ntawv tam sim no.
    ///
    ///
    /// # Examples
    ///
    /// Xav hais tias muaj ob cov ntaub ntawv nyob rau hauv tib lub directory nrog rau cov nram qab no txheem:
    ///
    /// Cov Ntaub Ntawv 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Ntaub ntawv 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// Compiling 'main.rs' thiab khiav lub resulting binary yuav sau "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Lus hauv no teb Hais tias qhov kev nthuav dav boolean yog `true` thaum lub sij hawm runtime.
    ///
    /// Qhov no yuav ua tau rau tus tus [`panic!`] macro yog hais tias tus muab qhia tsis tau soj ntsuam los `true` ntawm runtime.
    ///
    /// # Uses
    ///
    /// Cov cuab yeej ua haujlwm yeej ib txwm kuaj nyob rau hauv ob qho kev debug thiab cov chaw tsim tawm, thiab tsis tuaj yeem ua neeg xiam.
    /// Saib [`debug_assert!`] rau cov lus pom uas tsis tau qhib hauv kev tsim tawm los ntawm lub neej ntawd.
    ///
    /// Qhov tsis nyab xeeb cov lej yuav tso siab rau `assert!` los tswj cov kev nkag mus rau thaum lub sijhawm ua txhaum cai, yog tias ua txhaum yuav tuaj yeem ua rau tsis muaj qhov tsis txaus ntseeg.
    ///
    /// Lwm yam kev siv-tus neeg mob ntawm `assert!` muaj xws li soj ntsuam thiab tswj run-lub sij hawm invariants nyob rau hauv kev ruaj ntseg code (uas nws ua txhaum tsis raug nyob rau hauv unsafety).
    ///
    ///
    /// # Kev cai cov lus
    ///
    /// Cov macro no muaj daim ntawv thib ob, qhov kev cai panic xov tuaj yeem muab nrog lossis tsis muaj kev sib cav rau kev tawm tswv yim.
    /// Saib [`std::fmt`] rau syntax rau daim foos no.
    /// Zaj lus siv raws li hom lus sib cav yuav tsuas tsum tau soj ntsuam yog hais tias tus assertion tsis.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // lub panic lus rau cov assertions yog lub stringified nqi ntawm cov kev qhia muab.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // ib tug yooj yim heev muaj nuj nqi
    ///
    /// assert!(some_computation());
    ///
    /// // hais tawm nrog cov lus cai
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Inline los ua ke.
    ///
    /// Nyeem [unstable book] rau cov pab.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// LLVM-style inline los ua ke.
    ///
    /// Nyeem [unstable book] rau cov pab.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Module-theem inline los ua ke.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Prints dhau tokens rau hauv tus txheej txheem tso zis.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Enables los yog disables tracing functionality siv rau debugging lwm macros.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Txheeb xwm loj heev los siv thov kev pab loj heev.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Tus Cwj Pwm macro thov kom muaj ib nuj nqi tig nws mus rau hauv ib chav tsev kuaj.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Tus Cwj Pwm macro thov kom muaj ib nuj nqi tig nws mus rau hauv ib tug benchmark kuaj.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// Ib tug siv kev nthuav dav ntawm lub `#[test]` thiab `#[bench]` macros.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Tus Cwj Pwm macro thov kom muaj ib zoo li qub mus sau npe nws raws li ib tug ntiaj teb no allocator.
    ///
    /// Saib kuj [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Khaws cov khoom uas nws tau thov rau yog tias txoj hauv kev dhau los siv tau, thiab tshem tawm lwm yam.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Nthuav txhua `#[cfg]` thiab `#[cfg_attr]` muab tso rau hauv cov lej fragment nws tau thov rau.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Tsis ruaj tsis khov kev nthuav dav ntawm `rustc` tus sau, tsis txhob siv.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Tsis ruaj tsis khov kev nthuav dav ntawm `rustc` tus sau, tsis txhob siv.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}