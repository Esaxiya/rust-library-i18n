Panics tam sim no xov.

Qhov no tso cai ib qhov program kom tas ib ntus thiab muab cov lus teb rov rau tus hu lub program.
`panic!` yuav tsum siv thaum muaj ib tug kev pab cuam nce mus txog ib tug unrecoverable lub xeev.

Lub macro no yog txoj kev zoo tshaj plaws los lees cov kev mob hauv qhov piv txwv tus lej thiab hauv cov kev ntsuas.
`panic!` yog khi zoo nrog `unwrap` tus txheej txheem ntawm ob qho tib si [`Option`][ounwrap] thiab [`Result`][runwrap] enums.
Ob implementations hu `panic!` thaum lawv muab rau [`None`] los yog [`Err`] variants.

Thaum siv `panic!()` koj tuaj yeem qhia ib txoj hlua payload, uas tau tsim los siv [`format!`] syntax.
Hais tias payload yog siv thaum txhaj cov panic mus rau hauv lub hu Rust xov, ua rau cov xov rau panic nkaus.

Cov cwj pwm ntawm lub neej ntawd `std` hook, piv txwv li
lub code uas sau ncaj qha tom qab lub panic yog invoked, yog mus sau cov lus payload rau `stderr` nrog rau cov file/line/column cov ntaub ntawv ntawm lub `panic!()` hu.

Koj muaj peev xwm override tus panic hook siv [`std::panic::set_hook()`].
Hauv lub hook ib panic yuav tsum accessed raws li ib tug `&dyn Any + Send`, uas muaj xws li ib tug `&str` los yog `String` rau li niaj zaus `panic!()` invocations.
Yuav kom panic nrog ib tug nqi ntawm lwm lwm hom, [`panic_any`] yuav siv tau.

[`Result`] enum yog feem ntau ib tug zoo dua cov tshuaj rau cov recovering los ntawm uas tsis tshaj siv cov `panic!` macro.
Daim ntawv loj loj no yuav tsum raug siv kom tsis txhob mus tom ntej siv cov txiaj ntsig tsis yog, xws li los ntawm lwm qhov sab nraud.
Ncauj lus kom ntxaws txog kev ua yuam kev tuav yog nyob rau hauv lub [book].

Saib kuj lub macro [`compile_error!`], rau raising uas tsis thaum lub sij hawm muab tso ua ke.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Kev siv tam sim no

Yog hais tias lub ntsiab xov panics nws yuav txiav tawm tag nrho koj cov xov thiab xaus koj qhov kev pab cuam nrog code `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





