/// Siv rau kev rho tawm tsis ua haujlwm, xws li `*v`.
///
/// Ntxiv rau qhov raug siv rau kev ua haujlwm tsis meej pem nrog (unary) `*` tus neeg teb xov tooj nyob rau hauv cov ntsiab lus tsis txaus ntseeg, `Deref` kuj tseem siv ncaj qha los ntawm cov compiler hauv ntau yam.
/// Tus txheej txheem no yog hu ua ['`Deref` coercion'][more].
/// Hauv cov ntsiab lus hloov tau, [`DerefMut`] siv.
///
/// Kev siv `Deref` rau cov neeg taw tes ntse ua rau nkag mus rau cov ntaub ntawv tom qab lawv yooj yim, uas yog vim li cas lawv thiaj siv `Deref`.
/// Ntawm qhov tod tes, cov cai hais txog `Deref` thiab [`DerefMut`] tau tsim tshwj xeeb kom haum cov ntse taw qhia.
/// Vim tias qhov no,**`Deref` yuav tsum tsuas yog ua rau cov ntse taw tes** kom tsis txhob muaj kev kub ntxhov.
///
/// Rau qhov laj thawj zoo sib xws,**no trait yuav tsum tsis txhob swb**.Ua tsis tiav thaum lub sij hawm dereferencing tuaj yeem yog qhov muaj peev xwm to taub tsis meej thaum `Deref` raug hu tawm implicitly.
///
/// # Ntau ntawm `Deref` kev yuam
///
/// Yog `T` siv piv `Deref<Target = U>`, thiab `x` yog tus nqi ntawm `T`, ces:
///
/// * Hauv cov ntsiab lus tsis txaus ntseeg, `*x` (qhov twg `T` yog qhov tsis yog qhov siv los yog lub pointer nyoos) yog sib npaug rau `* Deref::deref(&x)`.
/// * Qhov tseem ceeb ntawm hom `&T` yog yuam kom muaj nuj nqis ntawm hom `&U`
/// * `T` implicitly siv tag nrho cov (immutable) txoj kev ntawm hom `U`.
///
/// Yog xav paub cov ntsiab lus ntxiv, txuas mus xyuas [the chapter in *The Rust Programming Language*][book] nrog rau ntu kev qhia ntawm [the dereference operator][ref-deref-op], [method resolution] thiab [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Tus txheej txheem nrog ib daim teb uas yog nkag tau los ntawm dereferencing tus qauv.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Hom tau tom qab dereferencing.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Kev hais txog tus nqi.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Siv rau kev rho tawm kev ua haujlwm tsis zoo, zoo li hauv `*v = 1;`.
///
/// Ntxiv rau qhov raug siv rau kev ua haujlwm tsis meej pem nrog (unary) `*` tus neeg teb xov tooj hauv kev sib hloov, `DerefMut` tseem siv tau ncaj qha los ntawm cov compiler hauv ntau yam.
/// Tus txheej txheem no yog hu ua ['`Deref` coercion'][more].
/// Hauv kev siv tsis tau nyob hauv cov ntsiab lus, [`Deref`] siv.
///
/// Kev siv `DerefMut` rau cov lus taw qhia ntse ua rau hloov cov ntaub ntawv tom qab lawv yooj yim, uas yog vim li cas lawv thiaj li siv `DerefMut`.
/// Ntawm qhov tod tes, cov cai hais txog [`Deref`] thiab `DerefMut` tau tsim tshwj xeeb kom haum cov ntse taw qhia.
/// Vim tias qhov no,**`DerefMut` yuav tsum tsuas yog siv rau cov taw tes ntse** kom tsis txhob muaj kev kub ntxhov.
///
/// Rau qhov laj thawj zoo sib xws,**no trait yuav tsum tsis txhob swb**.Ua tsis tiav thaum lub sij hawm dereferencing tuaj yeem yog qhov muaj peev xwm to taub tsis meej thaum `DerefMut` raug hu tawm implicitly.
///
/// # Ntau ntawm `Deref` kev yuam
///
/// Yog `T` siv piv `DerefMut<Target = U>`, thiab `x` yog tus nqi ntawm `T`, ces:
///
/// * Nyob rau hauv mutable cov ntsiab lus, `*x` (nyob qhov twg `T` yog tej nuj nqis ib tug siv los yog ib tug nyoos pointer) yog sib npaug rau `* DerefMut::deref_mut(&mut x)`.
/// * Qhov tseem ceeb ntawm hom `&mut T` yog yuam kom muaj nuj nqis ntawm hom `&mut U`
/// * `T` implicitly siv tag nrho cov (mutable) txoj kev ntawm hom `U`.
///
/// Yog xav paub cov ntsiab lus ntxiv, txuas mus xyuas [the chapter in *The Rust Programming Language*][book] nrog rau ntu kev qhia ntawm [the dereference operator][ref-deref-op], [method resolution] thiab [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Tus qauv nrog ib daim teb uas yog hloov kho los ntawm dereferencing tus qauv.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Kev sib koom tes ua tus nqi.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Qhia tias tus qauv yuav siv los ua tus qauv txais, yam tsis muaj `arbitrary_self_types` yam ntxwv.
///
/// Qhov no yog ua los ntawm stdlib pointer hom zoo li `Box<T>`, `Rc<T>`, `&T`, thiab `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}