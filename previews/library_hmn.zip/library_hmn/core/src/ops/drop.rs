/// Kev cai kev cai tsis pub dhau lub destructor.
///
/// Thaum tus nqi tsis xav tau, Rust yuav khiav "destructor" ntawm tus nqi ntawd.
/// Txoj kev siv ntau tshaj plaws uas ib qho nuj nqis yog tsis xav tau ntxiv yog thaum nws tawm ntawm cov nqi.Destructors tej zaum tseem khiav nyob rau hauv lwm yam, tab sis peb yuav mus ua kom pom tseeb rau tau rau cov piv txwv ntawm no.
/// Txhawm rau paub txog qee qhov ntawm lwm kis, thov saib [the reference] ntu ntawm kev rhuav tshem.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Tus neeg rhuav tshem no muaj ob qho:
/// - Hu rau `Drop::drop` rau tus nqi ntawd, yog tias qhov tshwj xeeb `Drop` trait siv rau nws hom.
/// - Lub tshuab txais nyiaj "drop glue" uas cia li hu tas lub txav ntawm txhua daim teb ntawm tus nqi no.
///
/// Raws li Rust cia li hu tus rhuav tshem ntawm txhua daim teb, koj tsis tas yuav ua raws `Drop` feem ntau.
/// Tab sis muaj qee kis muaj qee zaum uas nws yuav pab tau, piv txwv rau cov hom uas tswj ncaj qha cov peev txheej.
/// Cov peev txheej ntawd yuav yog qhov nco, nws yuav yog cov ntawv sau cia, nws yuav yog lub network socket.
/// Thaum ib tug nqi ntawm hom yog tsis mus yuav los siv, nws yuav tsum "clean up" nws pab los ntawm freeing lub cim xeeb los yog kaw cov ntaub ntawv los ntsawb.
/// Nov yog txoj haujlwm ntawm destructor, thiab yog li ntawd txoj haujlwm ntawm `Drop::drop`.
///
/// ## Examples
///
/// Txhawm rau pom cov khoom piam sij hauv kev nqis tes ua, cia wb saib ntawm cov haujlwm hauv qab no:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust yuav xub hu `Drop::drop` rau `_x` thiab tom qab ntawd rau ob qho tib si `_x.one` thiab `_x.two`, lub ntsiab lus tias khiav qhov no yuav luam tawm
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// Txawm hais tias peb tshem tawm qhov kev siv ntawm `Drop` rau `HasTwoDrop`, tus rhuav tshem ntawm nws cov liaj tseem raug hu.
/// Qhov no yuav ua rau
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## Koj tsis tuaj yeem hu `Drop::drop` koj tus kheej
///
/// Vim tias `Drop::drop` siv los ntxuav tus nqi, nws yuav muaj kev phom sij los siv tus nqi no tom qab tus qauv tau hu.
/// Raws li `Drop::drop` tsis coj tus tswv cuab ntawm nws cov tswv yim, Rust tiv thaiv kev ua tsis raug cai los ntawm kev tsis tso cai koj hu rau `Drop::drop` ncaj qha.
///
/// Hauv lwm lo lus, yog tias koj sim ntsees hu `Drop::drop` hauv qhov piv txwv saum toj no, koj yuav tau txais qhov yuam kev tsis suav.
///
/// Yog tias koj xav tau ntsees hu lub destructor ntawm tus nqi, [`mem::drop`] tuaj yeem siv dua.
///
/// [`mem::drop`]: drop
///
/// ## Tee xaj
///
/// Qhov twg ntawm peb ob qho `HasDrop` poob ua ntej, ho?Rau cov qauv, nws yog tib qho kev txiav txim uas lawv tau tshaj tawm: thawj `one`, tom qab ntawd `two`.
/// Yog tias koj xav sim qhov no koj tus kheej, koj tuaj yeem hloov kho `HasDrop` saum toj no kom muaj qee cov ntaub ntawv, zoo li ib tus lej, thiab tom qab ntawd siv nws nyob hauv `println!` sab hauv ntawm `Drop`.
/// Tus cwj pwm no tau lees paub los ntawm hom lus.
///
/// Tsis zoo li rau cov qauv, cov qhob hauv zos tau nqis hauv kev rov qab txiav txim:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// Qhov no yuav luam tawm
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Thov saib [the reference] rau cov kev cai tag nrho.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` thiab `Drop` tshwj rau
///
/// Koj tsis tuaj yeem siv ob qho [`Copy`] thiab `Drop` ntawm tib hom.Cov hom uas yog `Copy` tau txais qhov cuam tshuam los ntawm cov compiler, ua rau nws nyuaj nyuaj rau kev twv thaum twg, thiab ntau npaum li cas cuam tshuam yuav tua.
///
/// Xws li, cov hom no tsis tuaj yeem muaj kev puas tsuaj.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Ua rau lub destructor rau hom no.
    ///
    /// Hom no yog hu ua implicitly thaum tus nqi mus tsis tau, thiab tsis tuaj yeem hu meej meej (qhov no yog compiler yuam kev [E0040]).
    /// Txawm li cas los xij, [`mem::drop`] txoj haujlwm hauv prelude tuaj yeem siv los hu cov kev sib cav ntawm `Drop` kev siv.
    ///
    /// Thaum twg tus qauv no tau hu, `self` tseem tsis tau muaj kev cuam tshuam ntau.
    /// Qhov ntawd tsuas yog tshwm sim tom qab cov qauv tiav dhau mus.
    /// Yog tias qhov no tsis yog qhov teeb meem no, `self` yuav yog qhov siv cov neeg txiav txim siab zoo.
    ///
    /// # Panics
    ///
    /// Muab tias ib qho [`panic!`] yuav hu `drop` raws li nws unwinds, muaj [`panic!`] hauv `drop` kev siv yuav yuav rho.
    ///
    /// Nco ntsoov tias txawm tias panics no, tus nqi raug txiav txim siab poob;
    /// koj yuav tsum tsis txhob ua kom `drop` raug hu dua.
    /// Qhov no ib txwm tau txais los ntawm tus sau, tab sis thaum siv txoj cai tsis raug cai, muaj peev xwm qee zaum tshwm sim tsis paub, tshwj xeeb tshaj yog thaum siv [`ptr::drop_in_place`].
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}