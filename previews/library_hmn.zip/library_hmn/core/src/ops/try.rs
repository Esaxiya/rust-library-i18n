/// A trait rau kev coj cwj pwm ntawm tus neeg teb xov tooj `?`.
///
/// Ib hom kev siv `Try` yog ib qho uas muaj txoj kev canonical los saib nws ntawd success/failure dichotomy.
/// trait no tso cai rau ob qho los ua cov txiaj ntsig zoo lossis tsis ua tiav los ntawm cov piv txwv uas twb muaj lawm thiab tsim tshiab tshiab los ntawm cov txiaj ntsig zoo lossis tsis tiav.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Qhov hom ntawm tus nqi no thaum pom tias muaj kev vam meej.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Qhov hom ntawm tus nqi no thaum pom tias ua tsis tau tiav.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Siv lub "?" neeg teb xov tooj.Qhov rov qab ntawm `Ok(t)` txhais tau hais tias kev ua tiav yuav tsum txuas ntxiv txhua zaus, thiab qhov tshwm sim ntawm `?` yog tus nqi `t`.
    /// Ib qho kev xa rov qab ntawm `Err(e)` txhais tau tias kev ua tiav yuav tsum branch mus rau sab hauv inclerm `catch`, lossis rov qab los ntawm kev ua haujlwm.
    ///
    /// Yog tias cov txiaj ntsig `Err(e)` xa rov qab, tus nqi `e` yuav yog "wrapped" hauv kev xa rov qab hom kev lees paub (uas yuav tsum tau nws tus kheej siv `Try`).
    ///
    /// Tshwj xeeb, tus nqi `X::from_error(From::from(e))` xa rov qab, qhov twg `X` yog qhov rov qab hom ntawm kev ua haujlwm enclosing.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Qhwv tus nqi yuam kev los tsim qhov tsim coj los ua ke.
    /// Piv txwv li, `Result::Err(x)` thiab `Result::from_error(x)` yog qhov sib npaug.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Qhwv qhov lawv xav tau los tsim qhov ua tiav ntawm cov txiaj ntsig.
    /// Piv txwv li, `Result::Ok(x)` thiab `Result::from_ok(x)` yog qhov sib npaug.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}