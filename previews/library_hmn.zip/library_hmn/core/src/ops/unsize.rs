use crate::marker::Unsize;

/// Trait uas qhia tias qhov no yog tus taw qhia los yog ib daim ntawv qhwv rau ib qho, qhov twg tsis tuaj yeem ua rau ntawm qhov chaw.
///
/// Saib ntawm [DST coercion RFC][dst-coerce] thiab [the nomicon entry on coercion][nomicon-coerce] rau cov lus qhia ntxiv.
///
/// Rau builtin pointer yam, taw tes rau `T` yuav sib zog taw rau taw rau `U` yog `T: Unsize<U>` los ntawm kev hloov los ntawm cov pointer nyias rau cov roj pointer.
///
/// Rau cov hom kev cai, cov quab yuam ntawm no ua haujlwm los ntawm coercing `Foo<T>` rau `Foo<U>` muab qhov impl ntawm `CoerceUnsized<Foo<U>> for Foo<T>` tshwm sim.
/// Xws li impl tsuas sau tau yog tias `Foo<T>` tsuas muaj ib qho tsis yog-phantomdata teb uas muaj `T`.
/// Yog hais tias hom ntawm daim teb yog `Bar<T>`, kev siv `CoerceUnsized<Bar<U>> for Bar<T>` yuav tsum muaj nyob.
/// Qhov kev yuam yuav ua haujlwm los ntawm kev sib zog `Bar<T>` teb rau `Bar<U>` thiab sau cov seem hauv daim teb los ntawm `Foo<T>` los tsim `Foo<U>`.
/// Qhov no yuav zoo laum nqes mus rau ib lub pointer teb thiab sib zog ntawd.
///
/// Feem ntau, rau cov neeg taw qhia ntse koj yuav siv `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`, nrog kev xaiv `?Sized` khi rau `T` nws tus kheej.
/// Rau cov ntawv qhwv hom uas txuas ncaj qha `T` zoo li `Cell<T>` thiab `RefCell<T>`, koj tuaj yeem ncaj qha rau `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>`.
///
/// Qhov no yuav cia quab yuam ntawm hom zoo li `Cell<Box<T>>` ua haujlwm.
///
/// [`Unsize`][unsize] yog siv los cim hom uas tuaj yeem yuam rau DSTs yog tias tom qab cov taw tes.Nws yog nqes los ntawm cov compiler.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Qhov no siv rau kev nyab xeeb rau khoom, kom kuaj xyuas tias ib txoj kev tau txais hom tuaj yeem txuas rau.
///
/// Qhov piv txwv siv ntawm trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}