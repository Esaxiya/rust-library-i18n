//! Tshaj dhau cov tswj hwm.
//!
//! Ua cov traits tso cai rau koj tshaj txoj haujlwm.
//!
//! Ib co ntawm traits tau ntshuam los ntawm prelude, yog li lawv muaj nyob rau hauv txhua txhua qhov kev pabcuam Rust.Tsuas yog cov neeg ua hauj lwm thim rov qab los ntawm traits tuaj yeem dhau lawm.
//! Piv txwv li, tus neeg tsav tsheb sib ntxiv (`+`) tuaj yeem dhau qhov dhau [`Add`] trait, tab sis txij li tus neeg ua haujlwm muab khoom ua haujlwm (`=`) tsis muaj thaub qab trait, tsis muaj txoj hauv kev dhau ntawm nws cov semantics.
//! Ib qho ntxiv, tus qauv no tsis muab cov txheej txheem los tsim tus neeg ua haujlwm tshiab.
//! Yog hais tias traitless overloading lossis cov neeg siv kev cai yuav tsum, koj yuav tsum saib mus rau macros lossis compiler plugins kom txuas ntxiv Rust lub syntax.
//!
//! Kev siv ntawm tus neeg teb xov tooj traits yuav tsum tsis muaj txiaj ntsig nyob rau hauv lawv cov ntsiab lus sib txawv, nco ntsoov lawv cov ntsiab lus ib txwm siv thiab [operator precedence].
//! Piv txwv li, thaum siv [`Mul`], kev khiav haujlwm yuav tsum muaj qee qhov zoo ib yam rau qhov sib npaug (thiab qhia cov kev cia siab ntawm cov khoom zoo li kev sib txuam).
//!
//! Nco ntsoov tias cov neeg ua haujlwm `&&` thiab `||` luv luv Circuit Court, piv txwv li, lawv tsuas ntsuas lawv cov haujlwm thib ob yog tias nws pab txhawb qhov tshwm sim.Vim tias qhov kev coj ua no tsis raug tswj los ntawm traits, `&&` thiab `||` tsis tau txhawb raws li kev ua haujlwm dhau.
//!
//! Ntau tus neeg ua haujlwm nqa lawv txoj haujlwm ntawm cov nqi.Hauv cov ntsiab lus tsis muaj kev sib txuam nrog cov ua hauv hom, qhov no feem ntau tsis muaj teeb meem.
//! Txawm li cas los, siv cov tswv nyob rau hauv generic code, yuav tsum tau ib co xim yog qhov tseem ceeb yuav tsum tau reused raws li txwv mus cia lub tswv haus lawv.Ib qho kev xaiv yog qee zaum siv [`clone`].
//! Lwm qhov kev xaiv yog tso siab rau cov hom koom nrog muab cov neeg ua haujlwm ntxiv rau kev xa mus.
//! Piv txwv li, rau tus neeg siv txhais hom `T` uas xav tias yuav txhawb nqa ntxiv, nws yog qhov zoo uas yuav muaj ob qho `T` thiab `&T` siv traits [`Add<T>`][`Add`] thiab [`Add<&T>`][`Add`] kom cov lej cim cov ntawv sau tuaj yeem tsis muaj qhov cuam tshuam.
//!
//!
//! # Examples
//!
//! Qhov piv txwv no tsim `Point` tus qauv uas siv [`Add`] thiab [`Sub`], thiab tom qab ntawd ua rau pom kev ntxiv thiab rho ob qhov "Point".
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Saib cov ntaub ntawv rau txhua trait rau kev ua piv txwv.
//!
//! [`Fn`], [`FnMut`], thiab [`FnOnce`] traits raug siv los ntawm hom uas tuaj yeem hu ua haujlwm.Nco ntsoov tias [`Fn`] siv sijhawm `&self`, [`FnMut`] siv sijhawm `&mut self` thiab [`FnOnce`] siv sijhawm `self`.
//! Cov xov mus rau peb cov hom ntawm cov kev uas yuav tau invoked rau ib tug piv txwv: hu-by-reference, hu-by-mutable-reference, thiab hu-by-nqi.
//! Kev siv ntau tshaj plaws ntawm cov traits no yog ua raws li cov ciaj ciam rau cov qib siab uas ua haujlwm los yog kaw zoo li kev sib cav.
//!
//! Noj ib lub [`Fn`] raws li kev ntsuas:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Noj ib lub [`FnMut`] raws li kev ntsuas:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Noj ib lub [`FnOnce`] raws li kev ntsuas:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` noj nws cov khoom noj uas ntes, yog li nws tsis tuaj yeem khiav ntau dua ib zaug
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Kev sim mus rau ua kom `func()` dua yuav pov `use of moved value` yuam kev rau `func`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` tsis tuaj yeem hu ua tam sim no
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;