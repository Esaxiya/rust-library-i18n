use crate::marker::Unpin;
use crate::pin::Pin;

/// Qhov txiaj ntsig ntawm lub tshuab hluav taws xob rov pib dua.
///
/// Cov pa hluav taws xob no tau rov qab los ntawm `Generator::resume` tus qauv thiab qhia tau qhov tseem ceeb rau kev rov qab los ntawm lub tshuab hluav taws xob.
/// Tam sim no qhov no sib haum rau ib qho kev ncua ntawv (`Yielded`) lossis ib qho ntsiab lus xaus (`Complete`).
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// Lub tshuab hluav taws xob tshem tawm nrog tus nqi.
    ///
    /// Lub xeev no qhia tau hais tias lub tshuab hluav taws xob tau raug ncua, thiab feem ntau sib haum rau `yield` cov lus.
    /// Tus nqi muab hauv cov kev hloov pauv no sib raug mus rau qhov kev qhia xa mus rau `yield` thiab pub cov tshuab hluav taws xob muab tus nqi txhua lub sijhawm lawv tso.
    ///
    ///
    Yielded(Y),

    /// Lub tshuab hluav taws xob tiav nrog tus nqi xa rov qab.
    ///
    /// Lub xeev no qhia tau hais tias lub tshuab hluav taws xob tau ua tiav tiav nrog cov muab cov nqi.
    /// Thaum lub tshuab hluav taws xob rov qab `Complete` nws suav tias yog qhov programmer yuam kev hu `resume` dua.
    ///
    Complete(R),
}

/// Lub trait siv los ntawm builtin cov hom tshuab hluav taws xob.
///
/// Lub tshuab tsim hluav taws xob, kuj tseem hu ua coroutines, tam sim no yog ib hom lus sim hauv Rust.
/// Ntxiv rau hauv [RFC 2033] lub tshuab hluav taws xob tau npaj tam sim no feem ntau muab lub tsev thaiv rau async/await syntax tab sis yuav txuas ntxiv mus rau muab cov ntsiab lus ergonomic rau cov khoom thiab lwm cov qauv.
///
///
/// Cov syntax thiab semantics rau cov tshuab hluav taws xob tsis ruaj khov thiab yuav xav tau RFC ntxiv rau kev ua kom ruaj khov.Lub sijhawm no, txawm tias, qhov syntax yog kaw-zoo li:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Cov ntaub ntawv ntxiv ntawm cov tshuab hluav taws xob tuaj yeem pom hauv phau ntawv tsis ruaj khov.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// Qhov hom ntawm tus nqi no lub tshuab hluav taws xob yields.
    ///
    /// Hom kab mob no cuam tshuam nrog `yield` qhov kev hais tawm thiab qhov muaj nuj nqis uas tau tso cai xa rov qab txhua lub sijhawm ib lub tshuab hluav taws xob.
    ///
    /// Piv txwv li iterator-as-a-generator yuav zoo li muaj hom no `T`, hom tau ua iterated dua.
    ///
    type Yield;

    /// Cov hom ntawm cov nqi no lub tshuab hluav taws xob rov los.
    ///
    /// Qhov no sib raug rau hom rov qab los ntawm lub tshuab hluav taws xob los nrog `return` nqe lus lossis cuam tshuam raws li qhov hais tawm kawg ntawm lub tshuab hluav taws xob tiag tiag.
    /// Piv txwv li futures yuav siv no li `Result<T, E>` raws li nws sawv cev ua tiav future.
    ///
    ///
    type Return;

    /// Rov qab ua kom tiav ntawm lub tshuab hluav taws xob no.
    ///
    /// Qhov no muaj nuj nqi yuav rov pib dua tua ntawm cov generator los yog pib tua yog hais tias nws muaj tsis tau.
    /// Qhov kev hu no yuav rov qab mus rau lub tshuab hluav taws xob kawg qhov kev txwv, txuas ntxiv rov qab los ntawm `yield` qhov tseeb kawg.
    /// Lub tshuab hluav taws xob yuav txuas mus ntxiv kom txog thaum nws yields lossis rov qab los, thaum twg lub zog no rov qab.
    ///
    /// # Rov qab tus nqi
    ///
    /// Lub `GeneratorState` enum rov qab los ntawm txoj haujlwm no qhia dab tsi lub xeev lub tshuab hluav taws xob yog nyob rau hauv thaum rov qab los.
    /// Yog hais tias lub `Yielded` variant yog xa rov qab ces cov generator tau mus txog ib ncua kev kawm taw tes thiab ib tus nqi tau yielded tawm.
    /// Cov tshuab hluav taws xob hauv lub xeev no muaj rau kev rov pib dua tom qab.
    ///
    /// Yog tias `Complete` xa rov qab ces lub tshuab hluav taws xob tau ua tiav nrog tus nqi muab.Nws tsis tsim nyog rau lub tshuab hluav taws xob kom rov ua dua.
    ///
    /// # Panics
    ///
    /// Txoj haujlwm no yuav panic yog tias nws hu ua tom qab `Complete` variant tau rov qab dhau los.
    /// Thaum lub tshuab hluav taws xob cov ntawv sau nyob rau hauv cov lus tau lav rau panic ntawm kev rov pib dua tom qab `Complete`, qhov no tsis tuaj yeem lav rau txhua qhov kev coj ua ntawm `Generator` trait.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}