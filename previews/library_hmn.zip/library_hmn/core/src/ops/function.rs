/// Tus version ntawm tus neeg hu xov tooj uas yuav siv ib qho kev pauv tsis tau.
///
/// Feem ntau ntawm `Fn` tuaj yeem raug hu rov qab ua dua yam tsis muaj lub xeev hloov.
///
/// *Qhov trait (`Fn`) tsis yog yuav tsum tso siab rau [function pointers] (`fn`).*
///
/// `Fn` yog tau siv los ntawm kev kaw uas tsuas yog siv cov ntawv pauv hloov uas tsis tau hloov mus rau lwm tus los yog tsis txhom txhua yam, nrog rau (safe) [function pointers] (nrog qee qhov tsis txaus ntseeg, saib lawv cov ntaub ntawv rau cov lus qhia ntxiv).
///
/// Tsis tas li ntawd, rau txhua hom `F` uas siv `Fn`, `&F` coj `Fn`, ib yam nkaus.
///
/// Txij li thaum ob leeg [`FnMut`] thiab [`FnOnce`] yog supertraits ntawm `Fn`, tej lom ntawm `Fn` yuav siv tau raws li ib tug parameter qhov twg ib tug [`FnMut`] los yog [`FnOnce`] yuav tsum.
///
/// Siv `Fn` ua qhov khi thaum koj xav lees txais qhov ntsuas ntawm kev ua haujlwm zoo li hom thiab xav tau hu nws dua thiab tsis hloov lub xeev (piv txwv li, thaum hu nws tib lub sijhawm).
/// Yog tias koj tsis xav tau cov kev cai nruj heev, siv [`FnMut`] lossis [`FnOnce`] raws li cov ciaj ciam.
///
/// Saib rau [chapter on closures in *The Rust Programming Language*][book] rau qee cov ntaub ntawv ntxiv ntawm cov ncauj lus no.
///
/// Kuj tseem ceeb toom yog qhov tshwj xeeb syntax rau `Fn` traits (xws li
/// `Fn(usize, bool) -> usize`).Cov neeg txaus siab nyob rau hauv kev paub meej ntawm qhov no tuaj yeem xa mus rau [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Hu tau kawg
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Siv `Fn` ntsuas
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // kom regex tuaj yeem ntseeg tias `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Hu rau lub lag luam.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Cov version ntawm kev hu xov tooj uas siv tau ib tus txais tau.
///
/// Qee zaus ntawm `FnMut` tuaj yeem raug hu ua ntau zaus thiab tej zaum yuav hloov ua lub xeev.
///
/// `FnMut` yog tau siv los ntawm kev kaw uas siv tau kev hloov pauv mus rau kev hloov tau, nrog rau txhua hom uas siv [`Fn`], xws li, (safe) [function pointers] (vim `FnMut` yog supertrait ntawm [`Fn`]).
/// Tsis tas li ntawd, rau txhua hom `F` uas siv `FnMut`, `&mut F` coj `FnMut`, ib yam nkaus.
///
/// Txij li [`FnOnce`] yog supertrait ntawm `FnMut`, tej yam piv txwv ntawm `FnMut` tuaj yeem siv qhov twg xav tau [`FnOnce`], thiab vim [`Fn`] yog qhov tseem ceeb ntawm `FnMut`, tej yam piv txwv ntawm [`Fn`] tuaj yeem siv qhov twg `FnMut` xav tau.
///
/// Siv `FnMut` raws li qhov kev cog lus thaum koj xav lees txais qhov ntsuas ntawm kev ua haujlwm zoo li hom thiab xav tau hu nws dua, thaum tso cai rau nws hloov mus rau lub xeev.
/// Yog tias koj tsis xav tau qhov parameter los hloov ua xeev, siv [`Fn`] ua qhov khi;yog tias koj tsis tas yuav hu nws ntau zaus, siv [`FnOnce`].
///
/// Saib rau [chapter on closures in *The Rust Programming Language*][book] rau qee cov ntaub ntawv ntxiv ntawm cov ncauj lus no.
///
/// Kuj tseem ceeb toom yog qhov tshwj xeeb syntax rau `Fn` traits (xws li
/// `Fn(usize, bool) -> usize`).Cov neeg txaus siab nyob rau hauv kev paub meej ntawm qhov no tuaj yeem xa mus rau [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Hu tau zoo kaw kaw suab
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Siv `FnMut` ntsuas
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // kom regex tuaj yeem ntseeg tias `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Hu rau lub lag luam.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Cov version ntawm cov neeg hu xov tooj uas siv los ntawm tus nqi ntsuas.
///
/// Qee zaus ntawm `FnOnce` tuaj yeem hu ua, tab sis tej zaum yuav tsis hu ntau zaus.Vim tias qhov no, yog tias tsuas yog ib qho paub txog ib hom yog tias nws coj `FnOnce`, nws tuaj yeem tsuas yog hu ua ib zaug.
///
/// `FnOnce` yog tau txais los ntawm kev kaw uas yuav siv tau kev hloov tau, nrog rau txhua hom uas siv [`FnMut`], xws li, (safe) [function pointers] (vim `FnOnce` yog supertrait ntawm [`FnMut`]).
///
///
/// Txij li ob qho [`Fn`] thiab [`FnMut`] yog qhov tseem ceeb ntawm `FnOnce`, txhua qhov piv txwv ntawm [`Fn`] lossis [`FnMut`] tuaj yeem siv qhov twg xav tau `FnOnce`.
///
/// Siv `FnOnce` ua qhov khi thaum koj xav lees txais qhov ntsuas ntawm kev ua haujlwm zoo li hom thiab tsuas yog xav kom hu nws ib zaug.
/// Yog tias koj xav hu xov tooj mus rau parameter dua, siv [`FnMut`] ua qhov khi;yog tias koj tseem xav tau nws kom tsis txhob hloov pauv lub xeev, siv [`Fn`].
///
/// Saib rau [chapter on closures in *The Rust Programming Language*][book] rau qee cov ntaub ntawv ntxiv ntawm cov ncauj lus no.
///
/// Kuj tseem ceeb toom yog qhov tshwj xeeb syntax rau `Fn` traits (xws li
/// `Fn(usize, bool) -> usize`).Cov neeg txaus siab nyob rau hauv kev paub meej ntawm qhov no tuaj yeem xa mus rau [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Siv `FnOnce` ntsuas
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` noj nws cov khoom noj uas ntes, yog li nws tsis tuaj yeem khiav ntau dua ib zaug.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Sim ua tau rau tus `func()` dua yuav muab pov rau ib tug `use of moved value` kev ua yuam kev rau `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` tsis tuaj yeem hu ua tam sim no
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // kom regex tuaj yeem ntseeg tias `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Hom rov qab tom qab tus neeg hu xov tooj siv.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Hu rau lub lag luam.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}