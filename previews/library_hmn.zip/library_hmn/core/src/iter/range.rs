use crate::char;
use crate::convert::TryFrom;
use crate::mem;
use crate::ops::{self, Try};

use super::{FusedIterator, TrustedLen};

/// Yam khoom uas muaj ib tug notion ntawm *successor* thiab *cov thawj* haujlwm.
///
/// *Tus tswj kev ua haujlwm* ua haujlwm tsiv mus rau cov txiaj ntsig uas sib piv ntau dua.
/// Tus *thawj* lag luam tsiv ntawm qhov tseem ceeb uas piv lesser.
///
/// # Safety
///
/// Qhov trait yog `unsafe` vim tias nws qhov kev siv yuav tsum yog qhov tseeb rau kev nyab xeeb ntawm `unsafe trait TrustedLen` kev ua haujlwm, thiab cov txiaj ntsig ntawm kev siv trait no tuaj yeem ntseeg tau los ntawm `unsafe` tus lej kom raug thiab ua tiav cov luag haujlwm uas tau teev tseg.
///
///
///
#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
pub unsafe trait Step: Clone + PartialOrd + Sized {
    /// Rov qab los rau tus xov tooj ntawm *successor* kauj ruam yuav tsum tau txais los ntawm `start` rau `end`.
    ///
    /// Rov qab `None` yog tias cov naj npawb ntawm cov kauj ruam yuav dhau `usize` (lossis yog tsis kawg, lossis yog `end` yuav tsis tau ib txwm).
    ///
    ///
    /// # Invariants
    ///
    /// Rau tej `a`, `b`, thiab `n`:
    ///
    /// * `steps_between(&a, &b) == Some(n)` yog tias thiab tsuas yog tias `Step::forward_checked(&a, n) == Some(b)`
    /// * `steps_between(&a, &b) == Some(n)` yog tias thiab tsuas yog tias `Step::backward_checked(&a, n) == Some(a)`
    /// * `steps_between(&a, &b) == Some(n)` tsuas yog `a <= b`
    ///   * Corollary: `steps_between(&a, &b) == Some(0)` yog tias thiab tsuas yog tias `a == b`
    ///   * Nco ntsoov tias `a <= b` puas _not_ qhov cuam tshuam `steps_between(&a, &b) != None`;
    ///     no yog cov ntaub ntawv thaum nws yuav yuav tsum tau ntau tshaj li `usize::MAX` kauj ruam mus rau `b`
    /// * `steps_between(&a, &b) == None` yog `a > b`
    fn steps_between(start: &Self, end: &Self) -> Option<usize>;

    /// Rov qab los tus nqi uas yuav tsum tau los ntawm kev noj cov *successor* ntawm `self` `count` lub sij hawm.
    ///
    /// Yog hais tias qhov no yuav phwj hauv lub chav tseem ceeb kev txhawb los ntawm `Self`, rov `None`.
    ///
    /// # Invariants
    ///
    /// Rau ib qho `a`, `n`, thiab `m`:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, m).and_then(|x| Step::forward_checked(x, n))`
    ///
    ///
    /// Rau tej `a`, `n`, thiab `m` qhov twg `n + m` tsis phwj:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, n + m)`
    ///
    /// Rau tej `a` thiab `n`:
    ///
    /// * `Step::forward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::forward_checked(&x, 1))`
    ///   * Corollary: `Step::forward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward_checked(start: Self, count: usize) -> Option<Self>;

    /// Rov qab los tus nqi uas yuav tsum tau los ntawm kev noj cov *successor* ntawm `self` `count` lub sij hawm.
    ///
    /// Yog tias qhov no yuav dhau dhau ntawm cov txiaj ntsig tau txhawb los ntawm `Self`, txoj haujlwm no tau tso cai rau panic, qhwv, lossis saturate.
    ///
    /// Tus cwj pwm uas tau hais tawm yog rau panic thaum qhov debug tau lees paub, thiab muab qhwv lossis saturate lwm yam.
    ///
    /// Tsis zoo code yuav tsum tsis txhob cia siab rau lub correctness ntawm tus cwj pwm tom qab phwj.
    ///
    /// # Invariants
    ///
    /// Rau tej `a`, `n`, thiab `m`, qhov twg tsis phwj tshwm sim:
    ///
    /// * `Step::forward(Step::forward(a, n), m) == Step::forward(a, n + m)`
    ///
    /// Rau tej `a` thiab `n`, qhov twg tsis phwj tshwm sim:
    ///
    /// * `Step::forward_checked(a, n) == Some(Step::forward(a, n))`
    /// * `Step::forward(a, n) == (0..n).fold(a, |x, _| Step::forward(x, 1))`
    ///   * Corollary: `Step::forward(a, 0) == a`
    /// * `Step::forward(a, n) >= a`
    /// * `Step::backward(Step::forward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward(start: Self, count: usize) -> Self {
        Step::forward_checked(start, count).expect("overflow in `Step::forward`")
    }

    /// Rov qab los tus nqi uas yuav tsum tau los ntawm kev noj cov *successor* ntawm `self` `count` lub sij hawm.
    ///
    /// # Safety
    ///
    /// Nws yog tus cwj pwm tsis txaus ntseeg rau txoj haujlwm no dhau los dhau ntawm cov txiaj ntsig tau txhawb los ntawm `Self`.
    /// Yog hais tias koj yuav tsis lav hais tias qhov no yuav tsis phwj, siv `forward` los yog `forward_checked` xwb.
    ///
    /// # Invariants
    ///
    /// Rau tej `a`:
    ///
    /// * yog tias muaj tshwm sim `b` xws li hais tias `b > a`, nws muaj kev ruaj ntseg yuav tau hu rau `Step::forward_unchecked(a, 1)`
    /// * yog tias muaj tshwm sim `b`, `n` xws li hais tias `steps_between(&a, &b) == Some(n)`, nws muaj kev ruaj ntseg yuav tau hu rau `Step::forward_unchecked(a, m)` rau tej `m <= n`.
    ///
    ///
    /// Rau tej `a` thiab `n`, qhov twg tsis phwj tshwm sim:
    ///
    /// * `Step::forward_unchecked(a, n)` yog sib npaug rau `Step::forward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn forward_unchecked(start: Self, count: usize) -> Self {
        Step::forward(start, count)
    }

    /// Rov qab los tus nqi uas yuav tsum tau los ntawm kev noj cov *thawj* ntawm `self` `count` lub sij hawm.
    ///
    /// Yog hais tias qhov no yuav phwj hauv lub chav tseem ceeb kev txhawb los ntawm `Self`, rov `None`.
    ///
    /// # Invariants
    ///
    /// Rau ib qho `a`, `n`, thiab `m`:
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == n.checked_add(m).and_then(|x| Step::backward_checked(a, x))`
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == try { Step::backward_checked(a, n.checked_add(m)?) }`
    ///
    /// Rau tej `a` thiab `n`:
    ///
    /// * `Step::backward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::backward_checked(&x, 1))`
    ///   * Corollary: `Step::backward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward_checked(start: Self, count: usize) -> Option<Self>;

    /// Rov qab los tus nqi uas yuav tsum tau los ntawm kev noj cov *thawj* ntawm `self` `count` lub sij hawm.
    ///
    /// Yog tias qhov no yuav dhau dhau ntawm cov txiaj ntsig tau txhawb los ntawm `Self`, txoj haujlwm no tau tso cai rau panic, qhwv, lossis saturate.
    ///
    /// Tus cwj pwm uas tau hais tawm yog rau panic thaum qhov debug tau lees paub, thiab muab qhwv lossis saturate lwm yam.
    ///
    /// Tsis zoo code yuav tsum tsis txhob cia siab rau lub correctness ntawm tus cwj pwm tom qab phwj.
    ///
    /// # Invariants
    ///
    /// Rau tej `a`, `n`, thiab `m`, qhov twg tsis phwj tshwm sim:
    ///
    /// * `Step::backward(Step::backward(a, n), m) == Step::backward(a, n + m)`
    ///
    /// Rau tej `a` thiab `n`, qhov twg tsis phwj tshwm sim:
    ///
    /// * `Step::backward_checked(a, n) == Some(Step::backward(a, n))`
    /// * `Step::backward(a, n) == (0..n).fold(a, |x, _| Step::backward(x, 1))`
    ///   * Corollary: `Step::backward(a, 0) == a`
    /// * `Step::backward(a, n) <= a`
    /// * `Step::forward(Step::backward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward(start: Self, count: usize) -> Self {
        Step::backward_checked(start, count).expect("overflow in `Step::backward`")
    }

    /// Rov qab los tus nqi uas yuav tsum tau los ntawm kev noj cov *thawj* ntawm `self` `count` lub sij hawm.
    ///
    /// # Safety
    ///
    /// Nws yog tus cwj pwm tsis txaus ntseeg rau txoj haujlwm no dhau los dhau ntawm cov txiaj ntsig tau txhawb los ntawm `Self`.
    /// Yog hais tias koj yuav tsis lav hais tias qhov no yuav tsis phwj, siv `backward` los yog `backward_checked` xwb.
    ///
    /// # Invariants
    ///
    /// Rau tej `a`:
    ///
    /// * yog tias muaj tshwm sim `b` xws li hais tias `b < a`, nws muaj kev ruaj ntseg yuav tau hu rau `Step::backward_unchecked(a, 1)`
    /// * yog tias muaj tshwm sim `b`, `n` xws li hais tias `steps_between(&b, &a) == Some(n)`, nws muaj kev ruaj ntseg yuav tau hu rau `Step::backward_unchecked(a, m)` rau tej `m <= n`.
    ///
    ///
    /// Rau tej `a` thiab `n`, qhov twg tsis phwj tshwm sim:
    ///
    /// * `Step::backward_unchecked(a, n)` yog sib npaug rau `Step::backward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn backward_unchecked(start: Self, count: usize) -> Self {
        Step::backward(start, count)
    }
}

// Cov no tseem yog macro-tsim vim tias tus lej sib ntxiv daws teeb meem rau ntau hom.
macro_rules! step_identical_methods {
    () => {
        #[inline]
        unsafe fn forward_unchecked(start: Self, n: usize) -> Self {
            // KEV RUAJ NTSEG: tus hu yuav tsum lav tias `start + n` tsis dhau.
            unsafe { start.unchecked_add(n as Self) }
        }

        #[inline]
        unsafe fn backward_unchecked(start: Self, n: usize) -> Self {
            // KEV RUAJ NTSEG: tus neeg hu tau mus guarantee hais tias `start - n` tsis phwj.
            unsafe { start.unchecked_sub(n as Self) }
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn forward(start: Self, n: usize) -> Self {
            // Nyob rau hauv debug ua, ua ib tug panic rau phwj.
            // Qhov no yuav tsum tau ua kom zoo tshaj plaws hauv kev tsim tawm tso tawm.
            if Self::forward_checked(start, n).is_none() {
                let _ = Self::MAX + 1;
            }
            // Koj wrapping lej kom tso cai rau xws li `Step::forward(-128i8, 255)`.
            start.wrapping_add(n as Self)
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn backward(start: Self, n: usize) -> Self {
            // Nyob rau hauv debug ua, ua ib tug panic rau phwj.
            // Qhov no yuav tsum tau ua kom zoo tshaj plaws hauv kev tsim tawm tso tawm.
            if Self::backward_checked(start, n).is_none() {
                let _ = Self::MIN - 1;
            }
            // Koj wrapping lej kom tso cai rau xws li `Step::backward(127i8, 255)`.
            start.wrapping_sub(n as Self)
        }
    };
}

macro_rules! step_integer_impls {
    {
        narrower than or same width as usize:
            $( [ $u_narrower:ident $i_narrower:ident ] ),+;
        wider than usize:
            $( [ $u_wider:ident $i_wider:ident ] ),+;
    } => {
        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Qhov no cia siab rau $u_narrower <=usize
                        Some((*end - *start) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_add(n),
                        Err(_) => None, // Yog hais tias n yog tawm ntawm ntau yam, `unsigned_start + n` yog ib yam nkaus thiab
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_sub(n),
                        Err(_) => None, // Yog hais tias n yog tawm ntawm ntau yam, `unsigned_start - n` yog ib yam nkaus thiab
                    }
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Qhov no tso siab rau $i_narrower <=usize
                        //
                        // Casting rau isize ncua lub dav tab sis preserves tus kos npe rau.
                        // Siv wrapping_sub nyob rau hauv isize qhov chaw thiab cam khwb cia rau usize rau laij tau qhov sib txawv uas tej zaum yuav tsis haum rau hauv lub chav isize.
                        //
                        Some((*end as isize).wrapping_sub(*start as isize) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Kev tuav cov tes tuav zoo li `Step::forward(-120_i8, 200) == Some(80_i8)`, txawm tias 200 tawm ntawm qhov ntau rau i8.
                            //
                            //
                            let wrapped = start.wrapping_add(n as Self);
                            if wrapped >= start {
                                Some(wrapped)
                            } else {
                                None // Tsis tas li ntawd puastsuaj tas
                            }
                        }
                        // Yog tias n tawm ntawm ntau yam ua piv txwv
                        // u8, tom qab ntawd nws yog qhov loj dua rau txhua qhov ntau rau i8 yog qhov dav yog `any_i8 + n` tsim nyog dhau i8.
                        //
                        Err(_) => None,
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Kev tuav cov tes tuav zoo li `Step::forward(-120_i8, 200) == Some(80_i8)`, txawm tias 200 tawm ntawm qhov ntau rau i8.
                            //
                            //
                            let wrapped = start.wrapping_sub(n as Self);
                            if wrapped <= start {
                                Some(wrapped)
                            } else {
                                None // Kev rho tawm puv heev
                            }
                        }
                        // Yog tias n tawm ntawm ntau yam ua piv txwv
                        // u8, ces nws yog loj tshaj tag nrho ntau yam rau i8 yog dav li `any_i8 - n` tas overflows i8.
                        //
                        Err(_) => None,
                    }
                }
            }
        )+

        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        usize::try_from(*end - *start).ok()
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        match end.checked_sub(*start) {
                            Some(result) => usize::try_from(result).ok(),
                            // Yog hais tias qhov txawv yog ib yam nkaus thiab loj rau xws li
                            // i128, nws kuj yuav ua rau tau ib yam nkaus thiab loj rau usize muaj tsawg me me.
                            None => None,
                        }
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }
        )+
    };
}

#[cfg(target_pointer_width = "64")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [u64 i64], [usize isize];
    wider than usize: [u128 i128];
}

#[cfg(target_pointer_width = "32")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [usize isize];
    wider than usize: [u64 i64], [u128 i128];
}

#[cfg(target_pointer_width = "16")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [usize isize];
    wider than usize: [u32 i32], [u64 i64], [u128 i128];
}

#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
unsafe impl Step for char {
    #[inline]
    fn steps_between(&start: &char, &end: &char) -> Option<usize> {
        let start = start as u32;
        let end = end as u32;
        if start <= end {
            let count = end - start;
            if start < 0xD800 && 0xE000 <= end {
                usize::try_from(count - 0x800).ok()
            } else {
                usize::try_from(count).ok()
            }
        } else {
            None
        }
    }

    #[inline]
    fn forward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::forward_checked(start, count)?;
        if start < 0xD800 && 0xD800 <= res {
            res = Step::forward_checked(res, 0x800)?;
        }
        if res <= char::MAX as u32 {
            // KEV RUAJ NTSEG: res yog ib tug siv tau unicode scalar
            // (Hauv qab no 0x110000 thiab tsis nyob rau hauv 0xD800..0xE000)
            Some(unsafe { char::from_u32_unchecked(res) })
        } else {
            None
        }
    }

    #[inline]
    fn backward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::backward_checked(start, count)?;
        if start >= 0xE000 && 0xE000 > res {
            res = Step::backward_checked(res, 0x800)?;
        }
        // KEV RUAJ NTSEG: res yog ib tug siv tau unicode scalar
        // (Hauv qab no 0x110000 thiab tsis nyob rau hauv 0xD800..0xE000)
        Some(unsafe { char::from_u32_unchecked(res) })
    }

    #[inline]
    unsafe fn forward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // KEV RUAJ NTSEG: tus neeg hu yuav tsum lav tsis tau tias qhov no tsis nchuav
        // qhov ntau ntawm cov nuj nqis rau ib qho.
        let mut res = unsafe { Step::forward_unchecked(start, count) };
        if start < 0xD800 && 0xD800 <= res {
            // KEV RUAJ NTSEG: tus neeg hu yuav tsum lav tsis tau tias qhov no tsis nchuav
            // qhov ntau ntawm cov nuj nqis rau ib qho.
            res = unsafe { Step::forward_unchecked(res, 0x800) };
        }
        // TXUAG NYIAJ: vim tias tau cog lus dhau los, qhov no yog qhov tau lees tias
        // los ntawm tus hu kom yog ib tug siv tau char.
        unsafe { char::from_u32_unchecked(res) }
    }

    #[inline]
    unsafe fn backward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // KEV RUAJ NTSEG: tus neeg hu yuav tsum lav tsis tau tias qhov no tsis nchuav
        // qhov ntau ntawm cov nuj nqis rau ib qho.
        let mut res = unsafe { Step::backward_unchecked(start, count) };
        if start >= 0xE000 && 0xE000 > res {
            // KEV RUAJ NTSEG: tus neeg hu yuav tsum lav tsis tau tias qhov no tsis nchuav
            // qhov ntau ntawm cov nuj nqis rau ib qho.
            res = unsafe { Step::backward_unchecked(res, 0x800) };
        }
        // TXUAG NYIAJ: vim tias tau cog lus dhau los, qhov no yog qhov tau lees tias
        // los ntawm tus hu kom yog ib tug siv tau char.
        unsafe { char::from_u32_unchecked(res) }
    }
}

macro_rules! range_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl ExactSizeIterator for ops::Range<$t> { }
    )*)
}

macro_rules! range_incl_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "inclusive_range", since = "1.26.0")]
        impl ExactSizeIterator for ops::RangeInclusive<$t> { }
    )*)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::Range<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.start < self.end {
            // KEV RUAJ NTSEG: cia li mus soj ntsuam precondition
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            Some(mem::replace(&mut self.start, n))
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.start < self.end {
            let hint = Step::steps_between(&self.start, &self.end);
            (hint.unwrap_or(usize::MAX), hint)
        } else {
            (0, Some(0))
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            if plus_n < self.end {
                // KEV RUAJ NTSEG: cia li mus soj ntsuam precondition
                self.start = unsafe { Step::forward_unchecked(plus_n.clone(), 1) };
                return Some(plus_n);
            }
        }

        self.start = self.end.clone();
        None
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

// Cov macros tsim `ExactSizeIterator` impls rau ntau yam ntau hom.
//
// * `ExactSizeIterator::len` yog yuav tsum tau mus yeej ib txwm rov qab lub caij nyoog `usize`, thiaj li tsis muaj ntau yam yuav ua tau ntev tshaj li `usize::MAX`.
//
// * Rau cov zauv hom hauv `Range<_>` qhov no yog rooj plaub rau hom kev sib cais tsawg dua los yog dav li `usize`.
//   Rau integer hom nyob rau hauv `RangeInclusive<_>` qhov no yog cov ntaub ntawv rau hom *nruj me ntsis nqaim* tshaj `usize` txij li thaum xws li
//   `(0..=u64::MAX).len()` yuav `u64::MAX + 1`.
//
range_exact_iter_impl! {
    usize u8 u16
    isize i8 i16

    // Cov no yog cov incorect ib txoj kev xav saum toj no, tab sis tshem lawv yuav ua tau ib tug tawg hloov raws li lawv tau nyob ruaj hauv Rust 1.0.0.
    // Yog li ntawd xws li
    // `(0..66_000_u32).len()` piv txwv li yuav suav sau tsis muaj qhov yuam kev lossis ceeb toom ntawm 16-ntsis platform, tab sis txuas ntxiv muab cov txiaj ntsig tsis raug.
    //
    u32
    i32
}
range_incl_exact_iter_impl! {
    u8
    i8

    // Cov no yog cov incorect ib txoj kev xav saum toj no, tab sis tshem lawv yuav ua tau ib tug tawg hloov raws li lawv tau nyob ruaj hauv Rust 1.26.0.
    // Yog li ntawd xws li
    // `(0..=u16::MAX).len()` piv txwv li yuav suav sau tsis muaj qhov yuam kev lossis ceeb toom ntawm 16-ntsis platform, tab sis txuas ntxiv muab cov txiaj ntsig tsis raug.
    //
    u16
    i16
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> DoubleEndedIterator for ops::Range<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.start < self.end {
            // KEV RUAJ NTSEG: cia li mus soj ntsuam precondition
            self.end = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            Some(self.end.clone())
        } else {
            None
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            if minus_n > self.start {
                // KEV RUAJ NTSEG: cia li mus soj ntsuam precondition
                self.end = unsafe { Step::backward_unchecked(minus_n, 1) };
                return Some(self.end.clone());
            }
        }

        self.end = self.start.clone();
        None
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::Range<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::Range<A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::RangeFrom<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let n = Step::forward(self.start.clone(), 1);
        Some(mem::replace(&mut self.start, n))
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        let plus_n = Step::forward(self.start.clone(), n);
        self.start = Step::forward(plus_n.clone(), 1);
        Some(plus_n)
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeFrom<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeFrom<A> {}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> Iterator for ops::RangeInclusive<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // KEV RUAJ NTSEG: cia li mus soj ntsuam precondition
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            mem::replace(&mut self.start, n)
        } else {
            self.exhausted = true;
            self.start.clone()
        })
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.is_empty() {
            return (0, Some(0));
        }

        match Step::steps_between(&self.start, &self.end) {
            Some(hint) => (hint.saturating_add(1), hint.checked_add(1)),
            None => (usize::MAX, None),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            use crate::cmp::Ordering::*;

            match plus_n.partial_cmp(&self.end) {
                Some(Less) => {
                    self.start = Step::forward(plus_n.clone(), 1);
                    return Some(plus_n);
                }
                Some(Equal) => {
                    self.start = plus_n.clone();
                    self.exhausted = true;
                    return Some(plus_n);
                }
                _ => {}
            }
        }

        self.start = self.end.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // KEV RUAJ NTSEG: cia li mus soj ntsuam precondition
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            let n = mem::replace(&mut self.start, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn fold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(f)).unwrap()
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> DoubleEndedIterator for ops::RangeInclusive<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // KEV RUAJ NTSEG: cia li mus soj ntsuam precondition
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            mem::replace(&mut self.end, n)
        } else {
            self.exhausted = true;
            self.end.clone()
        })
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            use crate::cmp::Ordering::*;

            match minus_n.partial_cmp(&self.start) {
                Some(Greater) => {
                    self.end = Step::backward(minus_n.clone(), 1);
                    return Some(minus_n);
                }
                Some(Equal) => {
                    self.end = minus_n.clone();
                    self.exhausted = true;
                    return Some(minus_n);
                }
                _ => {}
            }
        }

        self.end = self.start.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // KEV RUAJ NTSEG: cia li mus soj ntsuam precondition
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            let n = mem::replace(&mut self.end, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn rfold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_rfold(init, ok(f)).unwrap()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeInclusive<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeInclusive<A> {}