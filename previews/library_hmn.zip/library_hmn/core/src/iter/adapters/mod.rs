use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// Qhov no trait muab transitive nkag tau mus rau qhov chaw-theem nyob rau hauv ib tug interator-adapter pipeline nyob rau hauv lub tej yam kev mob uas
/// * Qhov taw qhia qhov `S` nws tus kheej siv `SourceIter<Source = S>`
/// * muaj ib tug delegating siv ntawm no trait rau txhua adapter nyob rau hauv lub raj dej ntawm lub hauv paus thiab lub raj dej neeg.
///
/// Thaum qhov peev txheej yog tus tswv tsim txheej (feem ntau hu ua `IntoIter`) tom qab no qhov no tuaj yeem muaj txiaj ntsig rau kev ua haujlwm tshwj xeeb [`FromIterator`] lossis rov hais dua cov khoom ntxiv tom qab tus txhuam hluav taws xob tau tawm qee.
///
///
/// Nco ntsoov tias implementations tsis tas yuav muab kev nkag tau mus rau lub puab-feem ntau qhov chaw ntawm ib raj dej.Lub xeev muaj peev xwm hloov tau nruab rau ib qho me me ntawm cov kav xa dej thiab yuav ua rau nws lub chaw tso khoom sab hauv yog qhov chaw.
///
/// Lub trait yog tsis zoo vim hais tias implementers yuav tsum tau uphold ntxiv kev nyab xeeb zog.
/// Saib [`as_inner`] kom paub meej.
///
/// # Examples
///
/// Muab ib tug cov noj qhov twg los:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// Ib qhov theem nyob rau hauv ib tug iterator pipeline.
    type Source: Iterator;

    /// Rov xyuas dua qhov ntawm tus kav dej hla dej.
    ///
    /// # Safety
    ///
    /// Implementations ntawm yuav tsum rov qab mus rau tib mutable siv rau lawv lub neej, tshwj tsis yog tias hloov los ntawm ib tug neeg hu.
    /// Hu tuaj tej zaum yuav tsuas hloov cov kev siv thaum lawv nres iteration thiab poob rau hauv lub iterator pipeline tom qab extracting lub hauv paus.
    ///
    /// Qhov no txhais tau tias iterator adapters yuav tau cia siab rau qhov tsis hloov thaum lub sij hawm iteration tab sis lawv yuav tsis cia rau nws nyob rau hauv lawv nco implementations.
    ///
    /// Ua raws li cov qauv no txhais tau tias cov yoog hloov mus rau lwm qhov chaw nkaus xwb thiab tuaj yeem tso siab tau rau kev tuaj yeem ua raws li hom kev txais hom kev qhia.
    /// Qhov uas tsis muaj kev txwv kev nkag kuj yuav tsum tau hais tias adapters yuav tsum tau uphold qhov tus pej xeem API txawm tias thaum lawv muaj kev nkag tau rau nws cov internals.
    ///
    /// Hu nyob rau hauv lem yuav tsum paub qhov chaw yuav tsum tau nyob rau hauv tej lub xeev uas yog muaj raws li nws cov pej xeem API vim adapters zaum nruab nrab ntawm nws thiab qhov chaw muaj tib lub saib.
    /// Hauv tshwj xeeb ib qho adapter yuav tau haus cov ntsiab ntau dua li tsim nyog.
    ///
    /// Lub hom phiaj tag nrho ntawm cov kev xav tau yog kom cov neeg siv khoom siv ntawm kev siv raj xa dej
    /// * txawm seem nyob rau hauv lub qhov chaw tom qab iteration lawm
    /// * lub cim xeeb uas tau ua tsis siv los ntawm kev nce siab tus siv hluav taws xob tau siv
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// Ib iterator adapter uas ua tso zis ntev li ntev raws qhov pib iterator ua `Result::Ok` qhov tseem ceeb.
///
///
/// Yog tias qhov ua yuam kev pom, tus ntsuas hluav taws xob nres thiab qhov yuam kev yog khaws cia.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// Cov txheej txheem rau muab iterator li yog hais tias nws yielded ib tug `T` es tsis txhob ntawm ib tug `Result<T, _>`.
/// Ib qho kev ua yuam kev yuav nres rau sab hauv thiab cov txiaj ntsig tag nrho yuav yog ib qho yuam kev.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}