//! Composable lwm iteration.
//!
//! Yog hais tias koj twb pom koj tus kheej nrog ib tug sau ntawm ib co zoo, thiab yuav tsum tau mus ua ib lub lag luam nyob rau hauv lub ntsiab ntawm hais tias sau, koj mam li sai khiav mus rau hauv 'iterators'.
//! Iterators hnyav ncawv siv nyob rau hauv idiomatic Rust code, li ntawd, nws tsim paub txog cov lawv.
//!
//! Ua ntej piav ntau, wb tham txog yuav ua li cas no module structured:
//!
//! # Organization
//!
//! Qhov qauv no lom zem ntau yam raws li hom:
//!
//! * [Traits] yog cov tub ntxhais feem: cov traits txhais li cas ntawm iterators ua ib ke thiab li cas koj yuav ua li cas nrog lawv.Cov hau kev ntawm traits no tsim nyog muab qee lub sijhawm kawm ntxiv rau.
//! * [Functions] muab ib co yuav pab tau txoj kev los mus tsim ib co yooj yim iterators.
//! * [Structs] yog feem ntau xa rov qab los hom ntawm tus ntau txoj kev rau qhov no module lub traits.Koj yuav feem ntau yog xav mus saib nyob rau txoj kev uas tsim lub `struct`, es lub `struct` nws tus kheej.
//! Yog xav paub ntxiv kom meej txog vim li cas, saib '[siv iterator](#siv-iterator)'.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Tus ntawd yog nws!Wb khawb rau hauv iterators.
//!
//! # Iterator
//!
//! Lub plawv thiab ntsuj plig ntawm no module yog lub [`Iterator`] trait.Cov tub ntxhais ntawm [`Iterator`] zoo li no:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Ib iterator muaj ib txoj kev, [`next`], uas thaum hu ua, rov ib tug ['Option`]'<Item>`.
//! [`next`] yuav rov qab [`Some(Item)`] li ntev raws li muaj hais, thiab rau thaum lawv twb tag nrho cov tau sab sab, yuav rov qab mus `None` yuav qhia tau tias iteration lawm.
//! Cov iterators tej zaum yuav xaiv rov pib dua iteration, thiab thiaj li hu [`next`] dua tej zaum yuav yog los kuj tsis nws thiaj li pib rov qab [`Some(Item)`] dua tom tej taw tes (piv txwv li, saib [`TryIter`]).
//!
//!
//! [`Iterator`] cov lus txhais tag nrho suav nrog ntau txoj hauv kev ib yam, tab sis lawv lub neej yav tom ntej txoj kev, ua rau saum [`next`], thiab yog li koj tau txais lawv dawb.
//!
//! Cov ua haujlwm sib xws kuj yog qhov sib txuam, thiab nws yog ib qho uas muab saw hlau rau lawv ua ke los ua ntau cov txheej txheem ntawm kev ua.Saib cov [Adapters](#adapters) seem hauv qab no kom paub meej ntxiv.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Qhov peb hom ntawm iteration
//!
//! Muaj peb qho txoj kev uas muaj peev xwm tsim iterators los ntawm tus sau:
//!
//! * `iter()`, uas iterates tshaj `&T`.
//! * `iter_mut()`, uas iterates tshaj `&mut T`.
//! * `into_iter()`, uas iterates dhau `T`.
//!
//! Ntau yam nyob rau hauv tus txheej txheem tsev qiv ntawv tej zaum yuav siv ib los yog ntau tshaj ntawm cov peb, qhov twg tsim nyog.
//!
//! # siv iterator
//!
//! Tsim ib tug iterator ntawm koj tus kheej yuav ob kauj ruam: tsim ib tug `struct` los tuav lub iterator lub xeev, thiab ces siv [`Iterator`] rau cov uas `struct`.
//! Qhov no yog vim li cas muaj ntau li ntau 'struct`s nyob rau hauv no module: muaj yog ib qho rau ib iterator thiab iterator adapter.
//!
//! Cia ua ib qho iterator npe `Counter` uas suav los ntawm `1` rau `5`:
//!
//! ```
//! // Ua ntej, lub struct:
//!
//! /// Ib iterator uas suav los ntawm ib tug mus rau tsib
//! struct Counter {
//!     count: usize,
//! }
//!
//! // peb xav kom peb suav pib ntawm ib tug, thiaj li cia tus ntxiv ib tug new() txoj kev los pab.
//! // Qhov no yog tsis nruj me ntsis tsim nyog, tab sis yog yooj yim.
//! // Nco ntsoov tias peb pib `count` ntawm xoom, peb mam li pom vim li cas nyob rau hauv `next()`'s siv hauv qab no.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Ces, peb siv `Iterator` rau peb `Counter`:
//!
//! impl Iterator for Counter {
//!     // peb yuav tsum tau suav nrog usize
//!     type Item = usize;
//!
//!     // next() yog ib lub xwb yuav tsum tau txoj kev
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Increment peb suav.Qhov no yog vim li cas peb pib ntawm xoom.
//!         self.count += 1;
//!
//!         // Xyuas saib yog hais tias peb twb tiav lawm suav los yog tsis.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // Thiab tam sim no peb muaj peev xwm siv nws!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Hu [`next`] no txoj kev tau txais repetitive.Rust muaj ib tug dlaim uas yuav hu rau [`next`] rau koj iterator, kom txog rau thaum nws nce mus txog `None`.Cia peb mus tshaj tias tom ntej no.
//!
//! Tseem nco ntsoov tias `Iterator` muab kev pib siv ntawm cov hauv kev xws li `nth` thiab `fold` uas hu `next` sab hauv.
//! Txawm li cas los xij, nws tseem muaj peev xwm los sau qhov kev coj ua kev siv ntawm cov qauv zoo li `nth` thiab `fold` yog tias tus ntsuas khoom tuaj yeem laij lawv ntau yam tsis tau hu rau `next`.
//!
//! # `for` loops thiab `IntoIterator`
//!
//! Rust lub `for` voj syntax yog ua tau qab zib rau iterators.Ntawm no yog qhov piv txwv yooj yim ntawm `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Qhov no yuav sau cov zauv ib txog tsib, txhua rau lawv tus kheej txoj kab.Tab sis koj yuav pom ib yam dab tsi ntawm no: peb tsis tau hu ib yam dab tsi ntawm peb vector los tsim ib qho tawm.Yuav ua li cas muab?
//!
//! Muaj ib tug trait nyob rau hauv tus txheej txheem tsev qiv ntawv rau converting ib yam dab tsi mus rau hauv ib qho iterator: [`IntoIterator`].
//! trait no muaj ib txoj kev, [`into_iter`], uas hloov qhov tshaj plaws siv [`IntoIterator`] rau hauv tus ntsuas hluav taws xob.
//! Cia wb mus saib nyob rau ntawm `for` voj dua, li cas thiab lub compiler hloov siab los ntseeg nws mus rau hauv:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust de-suab thaj no rau hauv:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Ua ntej, peb hu `into_iter()` rau ntawm tus nqi.Ces, peb phim rau lub iterator uas rov qab, hu xov tooj [`next`] dua kom txog rau thaum peb pom ib tug `None`.
//! Nyob rau ntawm lub taw tes, peb `break` tawm hauv lub voj, thiab peb nyob nraum ua li cas iterating.
//!
//! Muaj ib tug ntau hloov maj mam me ntsis nyob ntawm no: tus txheej txheem tsev qiv ntawv muaj ib qho kev nthuav kev siv ntawm [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Nyob rau hauv lwm yam lus, tag nrho cov ['Iterator`] s siv [`IntoIterator`], los cia li rov qab los rau lawv tus kheej.Qhov no txhais tau tias ob yam:
//!
//! 1. Yog hais tias koj nyob nraum sau ib [`Iterator`], koj muaj peev xwm siv nws nrog ib tug `for` voj.
//! 2. Yog tias koj tab tom tsim cov khoom sau, siv [`IntoIterator`] rau nws yuav cia koj sau los siv nrog `for` lub voj.
//!
//! # Sib cais los ntawm kev siv
//!
//! Txij li thaum [`into_iter()`] yuav siv sij hawm `self` los ntawm tus nqi, siv ib tug `for` voj mus iterate tshaj ib tug sau noj uas sau.Feem ntau, tej zaum koj yuav xav iterate tshaj ib tug sau los tsis siv nws.
//! Muaj ntau collections muaj txoj kev uas muab iterators tshaj ua tim khawv, conventionally hu ua `iter()` thiab `iter_mut()` feem:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` yog tseem muaj los ntawm txoj haujlwm no.
//! ```
//!
//! Yog hais tias ib tug sau hom `C` muab `iter()`, nws feem ntau kuj siv `IntoIterator` rau `&C`, nrog ib tug ua raws li uas cia li hu `iter()`.
//! Ib yam li ntawd, ib tug sau `C` uas muab `iter_mut()` feem ntau siv `IntoIterator` rau `&mut C` los ntawm delegating rau `iter_mut()`.Qhov no yuav pab tau yooj yim luv:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // tib yam li `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // tib yam li `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Txawm hais tias ntau cov ntawv suav muaj `iter()`, tsis yog txhua tus muaj `iter_mut()`.
//! Piv txwv li, mutating cov yuam sij ntawm ib tug [`HashSet<T>`] los yog [`HashMap<K, V>`] yuav muab tus sau rau hauv ib qho inconsistent lub xeev yog hais tias tus yuam sij hashes hloov, yog li no collections tsuas muab `iter()`.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Tso cai uas muab ib tug [`Iterator`] thiab xa rov qab rau lwm tus [`Iterator`] yog feem ntau hu ua 'iterator adapters', raws li lawv yog ib tug hauv daim ntawv ntawm lub 'adapter
//! pattern'.
//!
//! Cov ntsuas pa uas siv tau xws li [`map`], [`take`], thiab [`filter`].
//! Yog xav paub ntxiv, saib lawv cov ntaub ntawv teev cia.
//!
//! Yog hais tias tus ntsuas hluav taws xob panics, tus tiv thaiv yuav nyob hauv qhov chaw uas tsis muaj tseeb (tab sis cim xeeb zoo).
//! Lub xeev no kuj tsis lav kom nyob twj ywm rau hauv tib lub thoob plaws versions ntawm Rust, yog li ntawd koj yuav tsum tsis txhob cia siab rau lub caij nyoog tseem ceeb rov qab los ntawm ib tug iterator uas txhawj heev.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Iterators (thiab iterator [adapters](#adapters)) yog *tub nkeeg*. Qhov no txhais tau hais tias cia li tsim ib tug iterator tsis _do_ ib tug tag nrho ntau. Tsis muaj dab tsi tiag tiag tshwm sim kom txog thaum koj hu [`next`].
//! Qhov no yog tej zaum ib tug qhov chaw ntawm tsis meej pem thaum tsim muaj ib qho iterator thiaj tau tuaj rau nws sab los.
//! Piv txwv li, lub [`map`] txoj kev hu ib tug kaw rau txhua lub caij nws iterates tshaj:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Qhov no yuav tsis luam tawm qhov muaj txiaj ntsig, zoo li peb tsuas tsim tus tsim, es tsis siv nws.Tus neeg sau yuav ceeb toom rau peb txog kev coj cwj pwm zoo no:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Lub idiomatic txoj kev uas yuav sau ib [`map`] rau nws sab los yog siv ib tug `for` voj los yog hu rau [`for_each`] hom:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Lwm ntau txoj kev uas yuav ntsuam xyuas ib tug iterator yog siv cov [`collect`] txoj kev los tsim ib phau tshiab.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Iterators tsis yuav tsum tau finite.Raws li ib qho piv txwv, ib tug lug ntau yog ib tug infinite iterator:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Nws yog ib qho siv cov [`take`] iterator adapter tig ib txhis iterator rau hauv ib tug finite ib:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Qhov no yuav sau cov lej `0` txog `4`, txhua tus ntawm lawv tus kheej kab.
//!
//! Xyooj nyob rau hauv lub siab hais tias txoj kev nyob rau hauv infinite iterators, txawm tias cov neeg uas ib tug tshwm sim muaj peev xwm yuav txiav txim lej nyob rau hauv finite lub sij hawm, tej zaum yuav tsis muaj cai ncaws.
//! Tshwj xeeb, txoj kev xws li [`min`], uas nyob rau hauv cov kev cov ntaub ntawv yuav tsum tau traversing txhua txhua lub caij nyob rau hauv lub iterator, yog tej zaum yuav tsis rov qab mus kawm rau tej infinite iterators.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Oh tsis yog!Ib tug infinite voj!
//! // `ones.min()` ua ib cov voj infinite, ces peb yuav tsis tau mus no taw tes!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;