/// Ib iterator uas paub nws caij nyoog ntev.
///
/// Muaj ntau ['Iterator`] s tsis paub yuav ua li cas muaj ntau zaus lawv yuav iterate, tab sis ib txhia li cas.
/// Yog hais tias ib tug iterator paub yuav ua li cas muaj ntau zaus nws yuav iterate, muab siv tau los hais tias cov ntaub yuav pab tau.
/// Piv txwv li, yog tias koj xav iterate rov mus, ib tug zoo pib yog paub tias qhov twg kawg yog.
///
/// Thaum siv `ExactSizeIterator`, koj yuav tsum ua raws [`Iterator`].
/// Thaum koj ua li ntawd, qhov kev siv ntawm [`Iterator::size_hint`]*yuav tsum* rov qab lub caij nyoog loj ntawm lub iterator.
///
/// [`len`] tus qauv muaj qhov pib siv, yog li koj feem ntau tsis siv nws.
/// Txawm li cas los, tej zaum koj yuav tau muab ib tug ntau performant siv tshaj lub neej ntawd, li ntawd, overriding nws nyob rau hauv cov ntaub ntawv no ua rau kev txiav txim zoo.
///
///
/// Nco ntsoov tias qhov no trait yog ib tug muaj kev ruaj ntseg trait thiab raws li xws li tsis *tsis* thiab *tsis tau* guarantee hais tias tus xa rov qab ntev yog muaj tseeb.
/// Qhov no txhais tau hais tias `unsafe` code **yuav tsum tsis txhob** cia siab rau lub correctness ntawm [`Iterator::size_hint`].
/// Qhov tsis ruaj khov thiab tsis zoo [`TrustedLen`](super::marker::TrustedLen) trait muab qhov kev lav ntxiv no.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Kev siv theem pib:
///
/// ```
/// // qhov ntsuas qhov tseeb paub tseeb pes tsawg zaus nws yuav iterate
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// Hauv [module-level docs], peb tau siv [`Iterator`], `Counter`.
/// Wb siv `ExactSizeIterator` rau nws zoo li:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Peb yuav tau yooj yim xam cov seem tooj ntawm iterations.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // Thiab tam sim no peb muaj peev xwm siv nws!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Rov qab xa qhov ntev ntawm tus txhuam.
    ///
    /// Cov kev siv kom lub iterator yuav rov qab raws nraim `len()` ntau lub sij hawm ib tug [`Some(T)`] nqi, ua ntej yuav rov [`None`].
    ///
    /// Hom no muaj qhov pib siv, yog li koj feem ntau yuav tsum tsis txhob siv nws ncaj qha.
    /// Txawm li cas los xij, yog tias koj tuaj yeem muab qhov kev ua tau zoo dua qub, koj tuaj yeem ua li ntawd.
    /// Saib cov [trait-level] docs rau ib qho piv txwv.
    ///
    /// Lub luag haujlwm no muaj kev lav zoo tib yam li [`Iterator::size_hint`] lub luag haujlwm.
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// // qhov ntsuas qhov tseeb paub tseeb pes tsawg zaus nws yuav iterate
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Assertion no yog overly defensive, tab sis nws cov tshev mis lub invariant
        // guaranteed los ntawm lub trait.
        // Yog hais tias qhov no trait twb rust-nrog, peb yuav siv debug_assert !;assert_eq!yuav tshuaj xyuas txhua qhov kev siv Rust neeg siv dhau.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Rov qab los `true` yog hais tias tus iterator yog empty.
    ///
    /// Qhov no txoj kev muaj ib tug neej ntawd hais siv siv [`ExactSizeIterator::len()`], yog li ntawd koj yuav tsis tau siv nws tus kheej.
    ///
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}