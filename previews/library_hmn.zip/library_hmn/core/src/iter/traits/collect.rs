/// Conversion los ntawm ib tug [`Iterator`].
///
/// Los ntawm kev siv cov `FromIterator` rau ib hom, koj txhais tau li cas nws yuav tsum tau tsim los ntawm ib tug iterator.
/// Qhov no muaj ntau rau cov hom uas piav qhia tus sau ntawm qee yam.
///
/// [`FromIterator::from_iter()`] yog tsis tshua muaj hu ua ntsees, thiab yog es tsis txhob siv los ntawm [`Iterator::collect()`] txoj kev.
///
/// Saib [`Iterator::collect()`]'s cov ntaub ntawv rau ntau cov piv txwv.
///
/// Saib ntxiv: [`IntoIterator`].
///
/// # Examples
///
/// Kev siv theem pib:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Siv [`Iterator::collect()`] rau implicitly siv `FromIterator`:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Siv `FromIterator` rau koj hom:
///
/// ```
/// use std::iter::FromIterator;
///
/// // Ib cov qauv sau, uas tsuas yog ib qho qhwv dhau ntawm Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Wb muab nws ib co kev li ntawd, peb muaj peev xwm tsim ib tug thiab ntxiv tej yam rau nws.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // thiab peb mam li ua los FromIterator
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Tam sim no peb muaj peev xwm ua ib tug tshiab iterator ...
/// let iter = (0..5).into_iter();
///
/// // ... thiab ua ib tug MyCollection tawm ntawm nws
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // collect tej hauj lwm thiab!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Tsim ib tug nqi los ntawm ib tug iterator.
    ///
    /// Saib rau [module-level documentation] ntxiv.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Conversion rau hauv ib qho [`Iterator`].
///
/// Los ntawm kev siv `IntoIterator` rau ib hom, koj txhais tau li cas nws yuav hloov mus rau tus ntsuas hluav taws xob.
/// Qhov no muaj ntau rau cov hom uas piav qhia tus sau ntawm qee yam.
///
/// Ib qho txiaj ntsig ntawm kev coj ua `IntoIterator` yog tias koj hom yuav [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator).
///
///
/// Saib ntxiv: [`FromIterator`].
///
/// # Examples
///
/// Kev siv theem pib:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Siv `IntoIterator` rau koj hom:
///
/// ```
/// // Ib cov qauv sau, uas tsuas yog ib qho qhwv dhau ntawm Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Wb muab nws ib co kev li ntawd, peb muaj peev xwm tsim ib tug thiab ntxiv tej yam rau nws.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // thiab peb mam li siv IntoIterator
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Tam sim no peb muaj peev xwm ua ib phau tshiab ...
/// let mut c = MyCollection::new();
///
/// // ... ntxiv qee yam rau nws ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... thiab ces tig nws mus rau hauv ib qho Iterator:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// Nws yog ib qho muaj los siv `IntoIterator` ua trait bound.Qhov no tso cai rau lub tswv yim sau hom hloov, yog li ntev raws li nws tseem yog ib qho iterator.
/// Ntxiv ciam teb yuav tsum teev tseg los ntawm restricting rau
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// Lub hom ntawm lub ntsiab yog iterated tshaj.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Uas zoo ntawm iterator yog peb tig qhov no mus rau?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Tsim ib tug iterator los ntawm ib tug nqi.
    ///
    /// Saib rau [module-level documentation] ntxiv.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Ntev ib tug sau nrog tus txheem ntawm ib tug iterator.
///
/// Iterators tsim ib tug series ntawm qhov tseem ceeb, thiab collections kuj yuav xav li cas txog raws li ib tug series ntawm qhov tseem ceeb.
/// Lub `Extend` trait bridges no kis, uas koj mus cuag ib tug sau los ntawm xws li tus txheem ntawm uas iterator.
/// Thaum extending ib tug sau nrog ib tug twb uas twb muaj lawm tseem ceeb, uas nkag tshiab los yog, nyob rau hauv cov ntaub ntawv ntawm collections uas tso cai tau ntau yam nkag sib npaug zos lub lag luam, uas nkag tso.
///
///
/// # Examples
///
/// Kev siv theem pib:
///
/// ```
/// // Koj muaj peev xwm cuag ib txoj hlua nrog ib co chars:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// Kev siv `Extend`:
///
/// ```
/// // Ib cov qauv sau, uas tsuas yog ib qho qhwv dhau ntawm Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Wb muab nws ib co kev li ntawd, peb muaj peev xwm tsim ib tug thiab ntxiv tej yam rau nws.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // txij li thaum MyCollection muaj ib daim ntawv teev i32s, peb siv Ntev rau i32
/// impl Extend<i32> for MyCollection {
///
///     // Qhov no yog ib tug me ntsis yooj yim nrog lub pob zeb hom kos npe: peb hu tau cuag rau tej yam uas yuav tsum muab mus rau hauv ib qho iterator uas muab peb i32s.
///     // Vim tias peb xav tau i32s los tso rau hauv MyCollection.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // Qhov kev coj ua yog qhov ncaj ncaj: kev voj los ntawm tus kav, thiab add() txhua qhov chaw rau peb tus kheej.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // wb cuag peb sau nrog peb ntau tus xov tooj
/// c.extend(vec![1, 2, 3]);
///
/// // peb tau ntxiv cov khoom no rau sab kawg
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Ntev nrog cov ntawv sau nrog cov ntsiab lus ntawm tus tsim.
    ///
    /// Raws li qhov no yog qhov tsuas yuav tsum tau txoj kev no trait, lub [trait-level] docs muaj ntau cov ntsiab lus.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// // Koj muaj peev xwm cuag ib txoj hlua nrog ib co chars:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Extends ib tug sau nrog raws nraim ib lub caij.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Cov peev txheej ruaj hauv cov ntawv sau cia rau cov naj npawb ntawm cov khoom ntxiv.
    ///
    /// Lub neej ntawd siv tsis muaj dab tsi.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}