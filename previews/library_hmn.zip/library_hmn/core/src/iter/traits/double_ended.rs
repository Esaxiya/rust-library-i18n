use crate::ops::{ControlFlow, Try};

/// Ib iterator tau tawm los hais los ntawm ob hnub.
///
/// Qee yam ua piv txwv `DoubleEndedIterator` muaj ib lub peev xwm ntxiv dua ib yam dab tsi coj los [`Iterator`]: muaj peev xwm kuj nqa tau 'Yam' ntawm sab nraub qaum, ntxiv rau pem hauv ntej.
///
///
/// Nws yog ib qho tseem ceeb rau daim ntawv uas ob yuj yees ua hauj lwm nyob rau hauv tib ntau yam, thiab ua tsis tau tus ntoo khaub lig: iteration yog thaum lawv tau raws li nyob rau hauv nruab nrab.
///
/// Nyob rau hauv ib tug zoo li zam rau cov [`Iterator`] raws tu qauv, ib zaug ib tug `DoubleEndedIterator` rov [`None`] los ntawm ib tug [`next_back()`], hu rau nws dua yuav yog los kuj tsis puas tau rov qab [`Some`] dua.
/// [`next()`] thiab [`next_back()`] yog sib hloov pauv tau rau lub hom phiaj no.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Kev siv theem pib:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Tshem tawm thiab xa rov qab ib qho khoom ua ntej los ntawm qhov kawg ntawm tus kav.
    ///
    /// Rov `None` thaum tsis muaj ntau yam hais.
    ///
    /// [trait-level] cov ntawv xaum muaj cov ntsiab lus ntxiv.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// Lub ntsiab yielded los ntawm 'DoubleEndedIterator`tus txoj kev tej zaum yuav txawv ntawm qhov sawv daws yuav yielded los ntawm [' Iterator`] 's txoj kev:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Nce qib lub iterator los ntawm cov rov qab los ntawm `n` ntsiab.
    ///
    /// `advance_back_by` yog qhov rov qab version ntawm [`advance_by`].Txoj kev no yuav maj mam hla `n` cov khoom pib tom qab los ntawm kev hu rau [`next_back`] txog `n` lub sijhawm kom txog rau thaum [`None`] ntsib.
    ///
    /// `advance_back_by(n)` yuav rov qab [`Ok(())`] yog hais tias tus iterator ntse nce qib los ntawm `n` hais, los yog [`Err(k)`] yog [`None`] yog ces yuav tsum, nyob qhov twg `k` yog tus naj npawb ntawm cov ntsiab lub iterator yog advanced los ntawm ua ntej yuav khiav tawm ntawm lub ntsiab (ie
    /// qhov ntev ntawm lub iterator).
    /// Nco ntsoov tias `k` yog yeej ib txwm tsawg tshaj li `n`.
    ///
    /// Hu `advance_back_by(0)` tsis haus tej ntsiab thiab yeej ib txwm rov [`Ok(())`].
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // tsuas `&3` twb raug hla lawm
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Rov qab los rau hauv lub 'n`th caij los ntawm lub kawg ntawm lub iterator.
    ///
    /// Qhov no yog lub hauv ntxeev version ntawm [`Iterator::nth()`].
    /// Txawm hais tias zoo li feem ntau ua haujlwm kev ua haujlwm, suav tau pib los ntawm xoom, yog li `nth_back(0)` rov qab los thawj tus nqi ntawm qhov kawg, `nth_back(1)` qhov thib ob, thiab lwm yam.
    ///
    ///
    /// Nco ntsoov tias tag nrho cov ntsiab ntawm qhov kawg thiab lub xa rov qab lub caij yuav tau noj, nrog rau cov rov qab lub caij.
    /// Qhov no kuj txhais tau hais tias kev hu mus rau `nth_back(0)` ntau lub sij hawm nyob rau hauv tib iterator yuav rov qab txawv hais.
    ///
    /// `nth_back()` yuav rov qab [`None`] yog `n` yog ntau dua los yog sib npaug zos rau qhov ntev ntawm lub iterator.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// Hu `nth_back()` ntau lub sij hawm tsis rewind lub iterator:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// Rov qab `None` yog hais tias muaj yog tsawg tshaj li `n + 1` hais:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Qhov no yog qhov rov qab version ntawm [`Iterator::try_fold()`]: nws yuav siv sij hawm hais pib los ntawm lub qab ntawm lub iterator.
    ///
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Vim hais tias nws luv luv-circuited, cov seem ntsiab yog tseem nyob rau ntawm lub iterator.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Ib iterator txoj kev uas thiaj li muaj qhov iterator lub ntsiab rau ib zaug xwb, thaum kawg tus nqi, pib los ntawm lub rov qab.
    ///
    /// Qhov no yog tus qauv thim rov qab ntawm [`Iterator::fold()`]: nws yuav siv cov khoom pib los ntawm sab nraum qab ntawm tus kav.
    ///
    /// `rfold()` yuav siv sij hawm ob nqe lus: ib tug thawj zaug nqi, thiab ib tug kaw nrog ob nqe lus: ib tug 'accumulator', thiab ib tug keeb.
    /// Lub kaw rov tus nqi uas lub accumulator yuav tsum tau muaj rau tom ntej no iteration.
    ///
    /// Tus nqi yog tus nqi lub accumulator yuav muaj nyob rau hauv tus thawj hu.
    ///
    /// Tom qab ua ntawv thov no kaw mus rau txhua txhua lub caij ntawm lub iterator, `rfold()` rov accumulator.
    ///
    /// Txoj haujlwm no qee zaum hu ua 'reduce' lossis 'inject'.
    ///
    /// Folding yog pab tau thaum twg koj muaj ib tug sau ntawm ib yam dab tsi, thiab xav kom ua ib zaug xwb tus nqi los ntawm nws.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // Qhov tawm ntawm tag nrho cov ntsiab lus ntawm a
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Qhov kev piv txwv ua ib txoj hlua, pib nrog ib tug thawj zaug nqi thiab ntxiv nrog txhua lub caij ntawm lub rov qab kom txog thaum lub hauv pem hauv ntej:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Searches rau ib tug keeb ntawm ib tug iterator los ntawm sab nraum qab uas satisfies ib predicate.
    ///
    /// `rfind()` siv kaw qhov uas rov `true` lossis `false`.
    /// Nws siv no kaw mus rau txhua lub caij ntawm lub iterator, pib ntawm lub kawg, thiab yog hais tias ib yam ntawm lawv rov qab `true`, ces `rfind()` rov [`Some(element)`].
    /// Yog hais tias tag nrho lawv rov qab `false`, nws rov [`None`].
    ///
    /// `rfind()` yog luv luv-circuiting;nyob rau hauv lwm yam lus, nws yuav tsis ua raws li sai li lub kaw rov `true`.
    ///
    /// Vim hais tias `rfind()` yuav siv sij hawm ib tug siv, thiab muaj ntau yam iterators iterate tshaj ua tim khawv, qhov no ua rau ib tug tejzaum ruam teeb meem nyob qhov twg lub sib cav yog ib tug muab ob npaug rau siv.
    ///
    /// Koj yuav saib tau no cov nyhuv nyob rau cov qauv hauv qab no, nrog `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Nres ntawm thawj `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // peb yeej tseem siv `iter`, raws li muaj ntau yam hais.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}