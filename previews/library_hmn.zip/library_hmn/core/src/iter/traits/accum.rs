use crate::iter;
use crate::num::Wrapping;

/// Trait los sawv cev rau hom uas yuav tsim los ntawm summing up ib iterator.
///
/// Qhov no trait yog siv los mus siv lub [`sum()`] txoj kev rau iterators.
/// Hom uas siv cov trait yuav tsum generated los ntawm cov [`sum()`] txoj kev.
/// Zoo li [`FromIterator`] no trait yuav tsum tsis tshua muaj yuav hu ua ncaj qha thiab es tsis txhob tham nrog los ntawm [`Iterator::sum()`].
///
///
/// [`sum()`]: Sum::sum
/// [`FromIterator`]: iter::FromIterator
#[stable(feature = "iter_arith_traits", since = "1.12.0")]
pub trait Sum<A = Self>: Sized {
    /// Txoj kev uas yuav siv sij hawm ib tug iterator thiab generates `Self` los ntawm lub ntsiab los ntawm "summing up" cov khoom.
    ///
    #[stable(feature = "iter_arith_traits", since = "1.12.0")]
    fn sum<I: Iterator<Item = A>>(iter: I) -> Self;
}

/// Trait los sawv cev rau hom uas yuav tsim los ntawm txawj hais ntawm ib tug iterator.
///
/// Qhov no trait yog siv los mus siv lub [`product()`] txoj kev rau iterators.
/// Hom uas siv cov trait yuav tsum generated los ntawm cov [`product()`] txoj kev.
/// Zoo li [`FromIterator`] no trait yuav tsum tsis tshua muaj yuav hu ua ncaj qha thiab es tsis txhob tham nrog los ntawm [`Iterator::product()`].
///
///
/// [`product()`]: Product::product
/// [`FromIterator`]: iter::FromIterator
///
#[stable(feature = "iter_arith_traits", since = "1.12.0")]
pub trait Product<A = Self>: Sized {
    /// Txoj kev uas yuav siv sij hawm ib tug iterator thiab generates `Self` los ntawm lub ntsiab los ntawm txawj cov khoom.
    ///
    #[stable(feature = "iter_arith_traits", since = "1.12.0")]
    fn product<I: Iterator<Item = A>>(iter: I) -> Self;
}

macro_rules! integer_sum_product {
    (@impls $zero:expr, $one:expr, #[$attr:meta], $($a:ty)*) => ($(
        #[$attr]
        impl Sum for $a {
            fn sum<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    $zero,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[$attr]
        impl Product for $a {
            fn product<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    $one,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }

        #[$attr]
        impl<'a> Sum<&'a $a> for $a {
            fn sum<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    $zero,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[$attr]
        impl<'a> Product<&'a $a> for $a {
            fn product<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    $one,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }
    )*);
    ($($a:ty)*) => (
        integer_sum_product!(@impls 0, 1,
                #[stable(feature = "iter_arith_traits", since = "1.12.0")],
                $($a)*);
        integer_sum_product!(@impls Wrapping(0), Wrapping(1),
                #[stable(feature = "wrapping_iter_arith", since = "1.14.0")],
                $(Wrapping<$a>)*);
    );
}

macro_rules! float_sum_product {
    ($($a:ident)*) => ($(
        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl Sum for $a {
            fn sum<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    0.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl Product for $a {
            fn product<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    1.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }

        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl<'a> Sum<&'a $a> for $a {
            fn sum<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    0.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl<'a> Product<&'a $a> for $a {
            fn product<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    1.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }
    )*)
}

integer_sum_product! { i8 i16 i32 i64 i128 isize u8 u16 u32 u64 u128 usize }
float_sum_product! { f32 f64 }

#[stable(feature = "iter_arith_traits_result", since = "1.16.0")]
impl<T, U, E> Sum<Result<U, E>> for Result<T, E>
where
    T: Sum<U>,
{
    /// Yuav siv sij hawm txhua lub caij nyob rau hauv lub [`Iterator`]: yog hais tias nws yog ib qho [`Err`], tsis muaj ntxiv ntsiab yog npaum li cas, thiab lub [`Err`] yog xa rov qab.
    /// Yuav tsum tsis muaj [`Err`] tshwm sim, qhov tawm ntawm txhua lub ntsiab lus rov qab.
    ///
    /// # Examples
    ///
    /// Qhov no qhaub txhua integer nyob rau hauv ib tug vector, tsis tau zaum yog ib tug tsis zoo caij ces yuav tsum:
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let res: Result<i32, &'static str> = v.iter().map(|&x: &i32|
    ///     if x < 0 { Err("Negative element found") }
    ///     else { Ok(x) }
    /// ).sum();
    /// assert_eq!(res, Ok(3));
    /// ```
    ///
    ///
    fn sum<I>(iter: I) -> Result<T, E>
    where
        I: Iterator<Item = Result<U, E>>,
    {
        iter::process_results(iter, |i| i.sum())
    }
}

#[stable(feature = "iter_arith_traits_result", since = "1.16.0")]
impl<T, U, E> Product<Result<U, E>> for Result<T, E>
where
    T: Product<U>,
{
    /// Yuav siv sij hawm txhua lub caij nyob rau hauv lub [`Iterator`]: yog hais tias nws yog ib qho [`Err`], tsis muaj ntxiv ntsiab yog npaum li cas, thiab lub [`Err`] yog xa rov qab.
    /// Yuav tsum tsis muaj [`Err`] tshwm sim, cov khoom ntawm tag nrho cov ntsiab yog xa rov qab.
    ///
    fn product<I>(iter: I) -> Result<T, E>
    where
        I: Iterator<Item = Result<U, E>>,
    {
        iter::process_results(iter, |i| i.product())
    }
}

#[stable(feature = "iter_arith_traits_option", since = "1.37.0")]
impl<T, U> Sum<Option<U>> for Option<T>
where
    T: Sum<U>,
{
    /// Yuav siv sij hawm txhua lub caij nyob rau hauv lub [`Iterator`]: yog hais tias nws yog ib tug [`None`], tsis muaj ntxiv ntsiab yog npaum li cas, thiab lub [`None`] yog xa rov qab.
    /// Yuav tsum tsis muaj [`None`] tshwm sim, qhov tawm ntawm txhua lub ntsiab lus rov qab.
    ///
    /// # Examples
    ///
    /// Qhov no suav txog txoj hauj lwm ntawm tus ua cim 'a' hauv vector ntawm cov hlua, yog tias ib lo lus tsis muaj tus cim 'a' kev khiav haujlwm rov `None`:
    ///
    ///
    /// ```
    /// let words = vec!["have", "a", "great", "day"];
    /// let total: Option<usize> = words.iter().map(|w| w.find('a')).sum();
    /// assert_eq!(total, Some(5));
    /// ```
    ///
    fn sum<I>(iter: I) -> Option<T>
    where
        I: Iterator<Item = Option<U>>,
    {
        iter.map(|x| x.ok_or(())).sum::<Result<_, _>>().ok()
    }
}

#[stable(feature = "iter_arith_traits_option", since = "1.37.0")]
impl<T, U> Product<Option<U>> for Option<T>
where
    T: Product<U>,
{
    /// Yuav siv sij hawm txhua lub caij nyob rau hauv lub [`Iterator`]: yog hais tias nws yog ib tug [`None`], tsis muaj ntxiv ntsiab yog npaum li cas, thiab lub [`None`] yog xa rov qab.
    /// Yuav tsum tsis muaj [`None`] tshwm sim, cov khoom ntawm tag nrho cov ntsiab yog xa rov qab.
    ///
    fn product<I>(iter: I) -> Option<T>
    where
        I: Iterator<Item = Option<U>>,
    {
        iter.map(|x| x.ok_or(())).product::<Result<_, _>>().ok()
    }
}