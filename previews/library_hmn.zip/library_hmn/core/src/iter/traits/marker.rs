/// Tus ntsuas pa uas ib txwm txuas ntxiv rau `None` thaum qaug zog.
///
/// Hu tom ntej no nyob rau hauv ib tug fused iterator uas tau xa rov qab `None` ib zaug yog guaranteed rov qab mus [`None`] dua.
/// Qhov no trait yuav tsum tau siv los ntawm tag nrho cov iterators uas coj li no vim hais tias nws tso cai rau optimizing [`Iterator::fuse()`].
///
///
/// Note: Feem ntau, koj yuav tsum tsis txhob siv `FusedIterator` hauv cov npoo tsis tseem ceeb yog tias koj xav tau lub pob hluav taws xob.
/// Xwb, koj yuav tsum cia li hu [`Iterator::fuse()`] rau lub iterator.
/// Yog hais tias lub iterator yog twb fused, ntxiv [`Fuse`] wrapper yuav ua tau ib tug tsis muaj-op uas tsis muaj kev kawm yuav raug nplua.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// Ib iterator uas qhia ib qho tseeb ntev siv size_hint.
///
/// Tus xov tooj ceeb toom qhia qhov loj me qhov nws yog qhov twg yog qhov kawg (qis dua txoj hlua khi sib npaug rau sab saud), lossis cov hlua khi sab saud yog [`None`].
///
/// Lub sab sauv bound yuav tsum tsuas yog [`None`] yog hais tias tus tiag tiag iterator ntev yog loj tshaj [`usize::MAX`].
/// Ua li ntawd, txoj kev khi qis yuav tsum yog [`usize::MAX`], uas ua rau [`Iterator::size_hint()`] ntawm `(usize::MAX, None)`.
///
/// Tus tsim tawm yuav tsum tau ua raws nraim cov naj npawb nws tau tshaj tawm lossis diverge ua ntej mus txog qhov kawg.
///
/// # Safety
///
/// Qhov no trait yuav tsum tsuas yog siv thaum daim ntawv cog lus yog upheld.
/// Tau txais kev pab ntawm no trait yuav tsum tshawb xyuas [`Iterator::size_hint()`]’s sab sauv ua txhua yam.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// Ib iterator tias thaum yielding ib yam khoom yuav muaj npaum li cas tsawg kawg yog ib lub caij los ntawm nws cov lwm [`SourceIter`].
///
/// Hu xov tooj rau txhua txoj kev uas txhawb cov txheej txheem, piv txwv li
/// [`next()`] los yog [`try_fold()`], lav tias rau txhua kauj ruam tsawg kawg ib tus nqi ntawm tus tiv thaiv qhov hluav taws xob tau hloov tawm thiab cov txiaj ntsig ntawm cov kav hlau txuas tuaj yeem muab tso rau hauv nws qhov chaw, kev kwv yees tus yam ntxwv tsis tsim nyog ntawm qhov chaw tso cai xws li kev nkag mus.
///
/// Nyob rau hauv lwm yam lus no trait ntawd hais tias ib tug iterator pipeline yuav sau nyob rau hauv qhov chaw.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}