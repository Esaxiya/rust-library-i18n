// las mees-huv si-filelength ntaub ntawv no yuav luag heev dua lwm yam muaj lub ntsiab txhais ntawm `Iterator`.
// Peb yuav tsis phua uas mus rau hauv ntau yam ntaub ntawv.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// Ib tug interface rau kev soj ntsuam txog nrog iterators.
///
/// Qhov no yog lub ntsiab iterator trait.
/// Yog xav paub ntxiv txog lub tswvyim ntawm cov neeg ua haujlwm feem ntau, thov saib [module-level documentation].
/// Nyob rau hauv kev, tej zaum koj yuav xav kom koj paub yuav ua li cas [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// Lub hom ntawm lub ntsiab yog iterated tshaj.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Ua ntej cov iterator thiab xa rov qab rau tus nqi tom ntej.
    ///
    /// Rov [`None`] thaum iteration lawm.
    /// Cov kev siv tus kheej yuav xaiv los rov ua dua kev pib dua, thiab yog li hu rau `next()` dua kuj yuav lossis tsis yog thaum kawg pib rov [`Some(Item)`] dua ntawm qee kis.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // Hu rau next() rov qab rau tus nqi tom ntej ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... thiab ces tsis muaj ib zaug nws yog lawm.
    /// assert_eq!(None, iter.next());
    ///
    /// // Ntau tshaj hu tau los yog tsis rov `None`.Ntawm no, lawv ib txwm yuav.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Rov cov ciam teb nyob rau hauv seem ntev ntawm lub iterator.
    ///
    /// Tshwj xeeb, `size_hint()` rov tuple qhov twg rau thawj lub caij yog qhov tsawg dua ua txhua yam, thiab lub thib ob lub caij no yog lub sab sauv ua txhua yam.
    ///
    /// Qhov thib ob ib nrab ntawm cov tuple uas yog xa rov qab yog ib qho ['Option`]' <'[' usize`] '>'.
    /// Ib tug [`None`] ntawm no txhais tau tias tog twg los tsis muaj dua lwm cov paub, thiab cov ciaj ciam loj dua [`usize`].
    ///
    /// # Kev sau ntawv siv
    ///
    /// Nws tsis raug yuam hais tias ib qho kev siv tus coj yields qhov tshaj tawm cov xov tooj ntawm cov khoom.A tsheb nees iterator yuav paib tsawg tshaj li tus sab ua txhua yam los yog ntau tshaj cov qaum txhua yam ntawm lub ntsiab.
    ///
    /// `size_hint()` yog feem ntau npaj yuav siv rau kev optimizations xws li tseg chaw rau lub ntsiab ntawm lub iterator, tab sis yuav tsum tsis txhob cia siab rau rau xws li, tso tawm bounds tshev nyob rau hauv tsis zoo code.
    /// Kev siv tsis raug ntawm `size_hint()` yuav tsum tsis txhob ua rau lub cim xeeb kev ua txhaum kev nyab xeeb.
    ///
    /// Uas hais tias, qhov kev siv yuav tsum tau muab ib tug muaj tseeb xwm, vim hais tias txwv tsis pub nws yuav ib tug ua txhaum ntawm lub trait tus raws tu qauv.
    ///
    /// Lub neej ntawd yuav ua raws li rov qab '(0,' ['None`]') 'uas yog muaj tseeb rau tej iterator.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// Ib qhov piv txwv ntau ntxiv:
    ///
    /// ```
    /// // Lub txooj ntawm xoom mus rau kaum.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Tej zaum peb yuav iterate los ntawm xoom mus rau kaum lub sij hawm.
    /// // Paub tias nws yog tsib raws nraim yuav tsis tau yog tsis muaj kev tua filter().
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Wb ntxiv tsib ntau tus xov tooj nrog chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // tam sim no ob leeg puav leej tau nce los ntawm tsib
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Rov `None` rau qaum kev khi:
    ///
    /// ```
    /// // ib txhis iterator muaj tsis muaj sab sauv ua txhua yam thiab lub siab tshaj plaws tau qis bound
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Txais cov ntiv taw, suav tus naj npawb ntawm cov iterations thiab xa rov qab nws.
    ///
    /// Qhov no txoj kev yuav hu [`next`] pheej kom txog rau thaum [`None`] yog ces yuav tsum, rov qab tus xov tooj ntawm lub sij hawm nws pom [`Some`].
    /// Nco ntsoov tias [`next`] tau yuav tsum tau hu ua tsawg kawg ib zaug txawm yog hais tias tus iterator tsis muaj ntsiab.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # puv Cwj Pwm
    ///
    /// Cov kev puas tsis muaj rawv tiv thaiv overflows, yog li suav cov ntsiab ntawm ib tug iterator uas muaj ntau tshaj [`usize::MAX`] ntsiab yog ua tsis ncaj ncees lawm tshwm sim los yog panics.
    ///
    /// Yog tias qhov debug kev lees paub tau ua tiav, lub panic yog qhov lav.
    ///
    /// # Panics
    ///
    /// Qhov no muaj nuj nqi koj lub dag zog panic yog hais tias tus iterator muaj ntau tshaj li [`usize::MAX`] ntsiab.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Kov lub iterator, rov qab qhov kawg lub caij.
    ///
    /// Qhov no txoj kev yuav soj ntsuam qhov iterator kom txog thaum nws rov [`None`].
    /// Thaum koj ua li ntawd, nws yuav taug qab ntawm qhov tam sim no lub caij.
    /// Tom qab [`None`] xa rov qab, `last()` yuav rov qab muab lub caij kawg uas nws tau pom.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Nce qib lub iterator los ntawm `n` ntsiab.
    ///
    /// Txoj kev no yuav maj mam hla `n` cov ntsiab lus los ntawm kev hu [`next`] txog `n` lub sijhawm kom txog rau thaum [`None`] raug.
    ///
    /// `advance_by(n)` yuav rov [`Ok(())`][Ok] yog tias tus theerator vam meej los ntawm `n` cov ntsiab lus, lossis [`Err(k)`][Err] yog tias ntsib [`None`], qhov twg `k` yog tus naj npawb ntawm cov khoom uas tus thev naus laus zuj zus los ntawm ua ntej khiav tawm ntawm cov khoom (piv txwv li
    /// qhov ntev ntawm lub iterator).
    /// Nco ntsoov tias `k` yog yeej ib txwm tsawg tshaj li `n`.
    ///
    /// Hu rau `advance_by(0)` tsis haus cov khoom thiab ib txwm rov los [`Ok(())`][Ok].
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // tsuas `&4` twb raug hla lawm
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Rov qab los rau hauv lub 'n`th caij ntawm lub iterator.
    ///
    /// Zoo li feem ntau indexing ua hauj lwm, lub count pib ntawm xoom, yog li `nth(0)` rov thawj tus nqi, `nth(1)` lub thib ob, thiab thiaj li nyob.
    ///
    /// Nco ntsoov tias tag nrho cov ua ntej hais, raws li tau zoo raws li lub rov qab lub caij, yuav tau noj los ntawm lub iterator.
    /// Qhov ntawd txhais tau hais tias ua ntej hais yuav tau muab pov tseg, thiab kuj tau hais tias kev hu mus rau `nth(0)` ntau lub sij hawm nyob rau hauv tib iterator yuav rov qab txawv hais.
    ///
    ///
    /// `nth()` yuav rov qab [`None`] yog `n` yog ntau dua los yog sib npaug zos rau qhov ntev ntawm lub iterator.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Hu `nth()` ntau zaus tsis rov ua dua:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Rov qab `None` yog hais tias muaj yog tsawg tshaj li `n + 1` hais:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Tsim ib qho ntsuas pib pib ntawm tib lub ntsiab lus, tab sis nqis los ntawm tus nqi muab rau ntawm txhua lub iteration.
    ///
    /// Ceeb toom 1: Thawj lub caij ntawm lub iterator yuav yeej ib txwm raug xa rov qab, hais txog ntawm cov kauj ruam muab.
    ///
    /// Ceeb Toom 2: Lub sijhawm uas tiv thaiv cov ntsiab lus raug rub tawm tsis yog tas.
    /// `StepBy` behaves li ib theem zuj zus `next(), nth(step-1), nth(step-1),…`, tab sis tseem yog free rau coj zoo li ib theem zuj zus
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Txoj kev no yog siv tej zaum yuav hloov rau ib co iterators rau kev kawm ntawv vim li cas.
    /// Qhov thib ob txoj hauv kev yuav ua kom dhau tus theerator ua ntej lawm thiab tuaj yeem siv ntau cov khoom.
    ///
    /// `advance_n_and_return_first` yog qhov sib npaug ntawm:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// Txoj kev yuav panic yog tias qib muab yog `0`.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Siv ob tus ntsuas thiab tsim ib qho tshiab tawm dua ob qho hauv kev ua ntu zus.
    ///
    /// `chain()` yuav rov qab tawm tus tshiab iterator uas yuav xub iterate tshaj qhov tseem ceeb los ntawm tus thawj ua ntej thiab tom qab ntawd dhau qhov tseem ceeb los ntawm tus thib ob tus tsim.
    ///
    /// Nyob rau hauv lwm yam lus, nws mus ob iterators ua ke, nyob rau hauv ib cov saw.🔗
    ///
    /// [`once`] yog kheev siv los hloov ib zaug xwb tus nqi mus rau hauv ib cov saw ntawm lwm yam iteration.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Txij li thaum lub sib cav mus `chain()` siv [`IntoIterator`], peb yuav kis tau tej yam uas muaj peev xwm yuav hloov dua siab tshiab rau hauv ib qho [`Iterator`], tsis yog ib tug [`Iterator`] nws tus kheej.
    /// Piv txwv li, slices (`&[T]`) siv [`IntoIterator`], thiab thiaj li muaj peev xwm kis mus rau `chain()` ncaj qha:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Yog hais tias koj ua hauj lwm nrog Windows API, tej zaum koj yuav xav hloov [`OsStr`] rau `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// 'Zips li' ob iterators rau hauv ib iterator ntawm officers.
    ///
    /// `zip()` rov qab ib tug tshiab iterator uas yuav iterate tshaj ob tug lwm iterators, rov qab ib tug tuple qhov twg rau thawj lub caij los los ntawm tus thawj iterator, thiab lub thib ob lub caij los los ntawm tus thib ob iterator.
    ///
    ///
    /// Hauv lwm lo lus, nws zaws ob tus ua ke, mus rau hauv ib qho.
    ///
    /// Yog hais tias yog iterator rov [`None`], [`next`] los ntawm lub zipped iterator yuav rov qab [`None`].
    /// Yog hais tias tus thawj iterator rov [`None`], `zip` yuav luv luv-Circuit Court thiab `next` yuav tsis tau hu ua rau lub thib ob iterator.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Txij li thaum lub sib cav mus `zip()` siv [`IntoIterator`], peb yuav kis tau tej yam uas muaj peev xwm yuav hloov dua siab tshiab rau hauv ib qho [`Iterator`], tsis yog ib tug [`Iterator`] nws tus kheej.
    /// Piv txwv li, slices (`&[T]`) siv [`IntoIterator`], thiab thiaj li muaj peev xwm kis mus rau `zip()` ncaj qha:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` yog feem ntau siv rau zauv zip ib txhis iterator mus rau ib tug finite ib.
    /// Qhov no ua haujlwm vim tias qhov ntsuas hluav taws xob kawg yuav rov qab [`None`], xaus rau zipper.Zipping nrog `(0..)` tuaj yeem saib zoo li [`enumerate`]:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Tsim tus tsim hluav taws xob tshiab uas muab daim ntawv `separator` nruab nrab ntawm cov khoom nyob ib sab ntawm tus thawj coj.
    ///
    /// Nyob rau hauv cov ntaub ntawv `separator` tsis siv [`Clone`] los yog xav tau kev pab yuav tsum tau xam txhua txhua lub sij hawm, siv [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // Tus thawj lub caij ntawm `a`.
    /// assert_eq!(a.next(), Some(&100)); // Lub sib cais.
    /// assert_eq!(a.next(), Some(&1));   // Lub ntsiab lus tom ntej los ntawm `a`.
    /// assert_eq!(a.next(), Some(&100)); // Lub sib cais.
    /// assert_eq!(a.next(), Some(&2));   // Lub caij kawg ntawm `a`.
    /// assert_eq!(a.next(), None);       // Lub iterator yog tiav lawm.
    /// ```
    ///
    /// `intersperse` yuav pab tau heev mus koom ib qho iterator lub khoom siv ib qho lub caij:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Tsim ib tug tshiab iterator uas muaj ib yam khoom generated los ntawm `separator` ntawm nyob ib sab yam khoom ntawm tus thawj iterator.
    ///
    /// Lub kaw yuav tsum tau hu ua raws nraim ib zaug ib lub sij hawm ib yam khoom yog muab tso rau ntawm ob sab yam khoom los ntawm qhov pib iterator;
    /// tshwj xeeb, kev kaw tsis tau hu yog tias tus ntsuas hluav taws xob hauv qab yields tsawg dua ob yam khoom thiab tom qab khoom kawg tau txais.
    ///
    ///
    /// Yog tias tus ntsuas pa cov khoom ua raws [`Clone`], nws yuav yooj yim rau siv [`intersperse`].
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // Tus thawj lub caij ntawm `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Lub sib cais.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // Cov tom ntej no lub caij ntawm `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Lub sib cais.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // Lub caij kawg tau los ntawm `v`.
    /// assert_eq!(it.next(), None);               // Lub iterator yog tiav lawm.
    /// ```
    ///
    /// `intersperse_with` yuav siv tau nyob rau hauv lub sij hawm uas lub separator yuav tsum tau xoo:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // Qhov kaw tau sib sib qiv nws lub ntsiab lus los tsim cov khoom.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Nqa qhov kaw thiab tsim ib qho iterator uas hu qhov kaw ntawm txhua lub keeb.
    ///
    /// `map()` transforms ib iterator mus rau lwm lub, los ntawm txoj kev nws sib cav:
    /// qee yam uas siv [`FnMut`].Nws ua ib tug tshiab iterator uas hu no kaw rau txhua lub caij ntawm cov thawj iterator.
    ///
    /// Yog hais tias koj yog neeg zoo ntawm xav nyob rau hauv hom, koj yuav tau xav seb `map()` zoo li no:
    /// Yog hais tias koj muaj ib qho iterator uas muab koj cov ntsiab ntawm tej hom `A`, thiab koj xav tau ib qho iterator ntawm ib co lwm hom `B`, koj muaj peev xwm siv `map()`, dua ib tug kaw uas yuav siv sij hawm ib tug `A` thiab rov `B`.
    ///
    ///
    /// `map()` yog conceptually xws li ib tug [`for`] voj.Txawm li cas los, raws li `map()` yog tub nkeeg, nws yog zoo tshaj plaws siv tau thaum koj nyob nraum twb ua hauj lwm nrog rau lwm cov iterators.
    /// Yog hais tias koj nyob nraum ua ib co tsi khoos kas uas rau ib sab nyhuv, nws xam tau tias yog ntau idiomatic siv [`for`] tshaj `map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Yog tias koj ua qee yam tshwm sim, xaj [`for`] rau `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // tsis txhob ua qhov no:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // nws yuav tsis txawm tua, uas nws yog tub nkees.Rust yuav ceeb toom koj txog qhov no.
    ///
    /// // Es tsis txhob, siv rau:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Hu xov tooj kaw rau txhua ntu ntawm tus tuav.
    ///
    /// Qhov no yog sib npaug rau siv ib tug [`for`] voj rau lub iterator, txawm hais tias `break` thiab `continue` yog tsis tau los ntawm ib tug kaw.
    /// Nws yog feem ntau idiomatic siv ib tug `for` voj, tab sis `for_each` tej zaum yuav ntau kom sau zoo thaum khiav cov khoom nyob rau thaum xaus ntawm lawm iterator chains.
    ///
    /// Nyob rau hauv tej rooj plaub `for_each` kuj yuav sai dua lub voj, vim hais tias nws yuav siv nrog iteration rau adapters li `Chain`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// Rau xws li ib tug me me piv txwv li, ib tug `for` voj tej zaum yuav nqus tsev vacuum, tab sis `for_each` tej zaum yuav preferable kom haumxeeb style nrog ntev iterators:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Tsim tus ntsuas hluav taws xob uas siv kaw kom txiav txim siab seb puas muaj cov khoom ua kom zoo.
    ///
    /// Muab cov khoom kaw yuav tsum xa `true` lossis `false`.Tus xa rov qab tuaj yeem tsim tawm tsuas yog cov ntsiab lus uas qhov kev kaw haujlwm rov qab tuaj tseeb.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Vim hais tias lub kaw kis mus rau `filter()` yuav siv sij hawm ib tug siv, thiab muaj ntau yam iterators iterate tshaj ua tim khawv, qhov no ua rau ib tug tejzaum ruam tag qhov teeb meem no, qhov twg lub hom lub kaw yog ib tug muab ob npaug rau siv:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // xav tau ob * s!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Nws yog lub heev rau es tsis txhob siv destructuring rau lub sib cav mus tshem ib tug:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // ob qho tib si&thiab *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// los yog ob qho tib si:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // ob &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ntawm cov khaubncaws sab nraud povtseg.
    ///
    /// Nco ntsoov tias `iter.filter(f).next()` yog sib npaug rau `iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Tsim ib tug iterator hais tias ob cov ntxaij lim dej thiab maps.
    ///
    /// Cov rov qab iterator yields tsuas yog tus 'value`s uas tus nkag kaw rov `Some(value)`.
    ///
    /// `filter_map` yuav siv tau los ua chains ntawm [`filter`] thiab [`map`] ntau cos.
    /// Cov piv txwv hauv qab no qhia tau hais tias yuav ua li cas ib tug `map().filter().map()` yuav zog mus rau ib tug tib hu rau `filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ntawm no yog tib yam piv txwv, tab sis, nrog [`filter`] thiab [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Tsim ib tug iterator uas muab qhov tam sim no iteration suav li zoo raws li lub tom ntej no muaj nqis.
    ///
    /// Lub iterator rov qab loo officers `(i, val)`, qhov twg `i` yog tam sim no Performance index ntawm iteration thiab `val` yog tus nqi rov qab los ntawm lub iterator.
    ///
    ///
    /// `enumerate()` yuav nws count raws li ib tug [`usize`].
    /// Yog hais tias koj xav kom suav los ntawm ib tug txawv tsuas integer, lub [`zip`] muaj nuj nqi muaj zoo xws li cov functionality.
    ///
    /// # puv Cwj Pwm
    ///
    /// Cov kev puas tsis muaj rawv tiv thaiv overflows, yog li enumerating ntau tshaj [`usize::MAX`] ntsiab yog ua tsis ncaj ncees lawm tshwm sim los yog panics.
    /// Yog tias qhov debug kev lees paub tau ua tiav, lub panic yog qhov lav.
    ///
    /// # Panics
    ///
    /// Cov rov qab iterator yuav panic yog hais tias tus uas yuav-rov qab index yuav phwj ib [`usize`].
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Tsim ib tug iterator uas yuav siv [`peek`] rau saib tom ntej no lub caij ntawm lub iterator tsis siv nws.
    ///
    /// Ntxiv ib tug [`peek`] txoj kev mus rau ib qho iterator.Saib nws cov ntaub ntawv rau cov lus qhia ntxiv.
    ///
    /// Nco ntsoov tias qhov ntsuas hluav taws xob hauv qab yog tseem nce siab thaum [`peek`] hu rau thawj lub sijhawm: Txhawm rau muab cov khoom pov thawj tom ntej, [`next`] hu rau ntawm tus tuav hluav taws xob, yog li muaj cov kev mob tshwm sim (piv txwv li
    ///
    /// lwm yam uas tsis yog nqa cov nqi tom ntej) ntawm [`next`] tus qauv yuav tshwm sim.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() cia rau peb saib mus rau hauv lub future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // peb yuav peek() ntau lub sij hawm, lub iterator yuav tsis ua ntej
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // tom qab lub iterator lawm, li ntawd, yog peek()
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Tsim tus ntsuas pa uas [`hla '] lub hauv paus raws li txheej txheem ua ntej.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` yuav siv sij hawm ib tug kaw raws li ib tug sib cav.Nws yuav hu no kaw rau txhua lub caij ntawm lub iterator, thiab las mees hais kom txog rau thaum nws rov `false`.
    ///
    /// Tom qab `false` yog xa rov qab, `skip_while()`'s txoj hauj lwm yog tshaj, thiab tus so ntawm lub ntsiab yog yielded.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Vim tias qhov kaw tau dhau los rau `skip_while()` siv qhov siv, thiab ntau tus neeg xa xov loog dhau cov ntawv xa mus, qhov no ua rau muaj qhov xwm txheej tsis sib haum xeeb, qhov twg hom kev sib cav kaw yog siv ob:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // xav tau ob * s!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Siv ceev xwmphem tom qab qhov pib `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // thaum no yuav tau cuav, txij li thaum peb twb tau txais ib tug tsis muaj tseeb, skip_while() yog tsis tau siv ntau
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Tsim tus tsim hluav taws xob uas yields cov khoom raws li kev twv xyuas.
    ///
    /// `take_while()` yuav siv sijhawm kaw li kev sib cav.Nws yuav hu no kaw rau txhua lub caij ntawm lub iterator, thiab cov paib hais thaum nws rov `true`.
    ///
    /// Tom qab `false` yog xa rov qab, `take_while()`'s txoj hauj lwm yog tshaj, thiab tus so ntawm lub ntsiab yog tsis quav ntsej li.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Vim tias qhov kaw tau dhau los rau `take_while()` siv qhov siv, thiab ntau tus neeg xa xov loog dhau cov ntawv xa mus, qhov no ua rau muaj qhov xwm txheej tsis sib haum xeeb, qhov twg hom kev kaw tau siv ob:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // xav tau ob * s!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Siv ceev xwmphem tom qab qhov pib `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Peb muaj ntau yam uas tseem tsawg tshaj li pes tsawg, tab sis txij li thaum peb twb tau txais ib tug tsis muaj tseeb, take_while() yog tsis tau siv ntau
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Vim hais tias `take_while()` xav tau kev pab mus saib nyob rau ntawm tus nqi nyob rau hauv thiaj li yuav pom tau tias nws yuav tsum muaj los yog tsis, siv iterators yuav pom tias nws yog muab tshem tawm:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// Lub `3` tsis nyob lawm, vim tias nws tau noj txhawm rau txhawm rau saib seb qhov kev ntsuas siab yuav tsum tso tseg, tab sis tsis tau tso rov qab rau hauv tus ntsuas hluav taws xob.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Tsim tus ntsuas pa uas ob qho tib si yields cov khoom raws li kev twv ua ntej thiab cov duab qhia.
    ///
    /// `map_while()` yuav siv sij hawm ib tug kaw raws li ib tug sib cav.
    /// Nws yuav hu qhov no kaw rau txhua ntu ntawm tus kav, thiab tawm los khoom thaum nws rov [`Some(_)`][`Some`].
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ntawm no yog tib yam piv txwv, tab sis, nrog [`take_while`] thiab [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Siv ceev xwmphem tom qab qhov pib [`None`]:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Peb muaj ntau cov ntsiab lus uas yuav haum hauv u32 (4, 5), tab sis `map_while` rov qab `None` rau `-3` (raws li `predicate` xa rov `None`) thiab `collect` nres ntawm thawj `None` ntsib.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Vim hais tias `map_while()` xav tau kev pab mus saib nyob rau ntawm tus nqi nyob rau hauv thiaj li yuav pom tau tias nws yuav tsum muaj los yog tsis, siv iterators yuav pom tias nws yog muab tshem tawm:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// Lub `-3` yog tsis muaj, vim hais tias nws twb consumed nyob rau hauv thiaj li yuav saib yog hais tias tus iteration yuav tsum nres, tab sis twb tsis muab tso rau rov qab mus rau hauv lub iterator.
    ///
    /// Nco ntsoov tias tsis zoo li [`take_while`] no iterator yog **tsis** fused.
    /// Nws kuj tseem tsis tau teev dab tsi no tus ntsuas xa rov qab tom qab thawj [`None`] xa rov qab.
    /// Yog tias koj xav tau fused iterator, siv [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Tsim ib tug iterator uas skips thawj `n` ntsiab.
    ///
    /// Tom qab lawv tau noj, tas cov khoom tseem ceeb.
    /// Ntau dua li overriding cov qauv no ncaj qha, es tsis txhob override `nth` txoj kev.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Tsim tus txhuam xov kab uas yields nws thawj `n` khoom.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` yog feem ntau siv nrog ib tug infinite iterator, kom nws finite:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Yog hais tias tsawg tshaj li `n` ntsiab yog muaj, `take` yuav txwv nws tus kheej mus rau lub luaj li cas ntawm lwm iterator:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// Tus ntsuas pa hluav taws xob zoo ib yam li [`fold`] uas tuav lub xeev sab hauv thiab tsim tawm tus tsim tshiab.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` yuav siv sij hawm ob nqe lus: ib tug thawj zaug nqi uas noob sab hauv lub xeev, thiab ib tug kaw nrog ob nqe lus, cov thawj ua ib tug mutable kev siv rau tus sab hauv lub xeev thiab lub thib ob ib iterator caij.
    ///
    /// Lub kaw yuav muab mus rau lub hauv xeev mus qhia lub xeev ntawm iterations.
    ///
    /// Nyob rau iteration, lub kaw yuav tsum muaj ntaub ntawv rau txhua lub caij ntawm lub iterator thiab rov qab los tus nqi ntawm lub kaw, ib tug [`Option`], yog yielded los ntawm lub iterator.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // txhua iteration, peb mam li muab lub xeev los ntawm lub caij
    ///     *state = *state * x;
    ///
    ///     // ces, peb mam li zam negation ntawm lub xeev
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Tsim ib tug iterator uas ua hauj lwm zoo li daim ntawv qhia, tab sis flattens nested qauv.
    ///
    /// [`map`] adapter tau txais txiaj ntsig zoo heev, tab sis tsuas yog thaum kaw kev txiav txim siab tsim cov txiaj ntsig.
    /// Yog hais tias nws ua ib tug iterator xwb, muaj yog ib qho ntxiv txheej ntawm indirection.
    /// `flat_map()` yuav tshem tawm no txheej ntxiv rau nws tus kheej.
    ///
    /// Koj yuav tau xav seb `flat_map(f)` li cov semantic sib npaug ntawm ['map`] ping, thiab luag [' flatten`] txog li nyob rau hauv `map(f).flatten()`.
    ///
    /// Lwm txoj kev xav txog `flat_map()`: ['map`]' s kaw rov qab ib yam khoom rau txhua lub caij, thiab `flat_map()`'s kaw rov qab ib iterator rau txhua lub caij.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() rov ib iterator
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Tsim ib tug iterator uas flattens nested qauv.
    ///
    /// Qhov no yog pab tau thaum koj muaj ib qho iterator ntawm iterators los yog ib tug iterator ntawm tej yam uas yuav tsum muab mus rau hauv iterators thiab koj xav kom tshem tau ib theem ntawm indirection.
    ///
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Kuas thiab ces flattening:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() rov ib iterator
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Koj yuav tau sau dua tshiab no nyob rau hauv cov nqe lus ntawm [`flat_map()`], uas yog preferable nyob rau hauv cov ntaub ntawv no txij li thaum nws qhia tib si ntau kom meej meej:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() rov ib iterator
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Flattening tsuas tuskheej ib theem ntawm zes ntawm ib lub sij hawm:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Ntawm no peb pom tias `flatten()` tsis ua "deep" flatten.
    /// Es tsis txhob, tsuas yog ib theem ntawm zes yog muab tshem tawm.Uas yog, yog tias koj `flatten()` ib tug peb-dimensional array, qhov tshwm sim yuav tsum muaj ob tug-dimensional thiab tsis yog ib-seem.
    /// Yuav kom tau txais cov qauv ib-seem, koj yuav tsum `flatten()` dua.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Tsim ib tug iterator uas xaus tom qab thawj zaug [`None`].
    ///
    /// Tom qab ib qho iterator rov [`None`], future hu yuav yog los kuj tsis tawm los [`Some(T)`] dua.
    /// `fuse()` adapts ib iterator, kom ntseeg tau hais tias tom qab ib tug [`None`] yog muab, nws yuav nco ntsoov rov qab [`None`] mus ib txhis.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// // ib iterator uas alternates ntawm ib txhia thiab Tsis muaj
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // yog tias nws txawm, Some(i32), lwm tus Tsis Yog
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // peb yuav saib peb iterator mus yuj yees
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // txawm li cas los, ib zaug peb fuse nws ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // nws yuav ib txwm rov qab `None` tom qab thawj lub sij hawm.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Puas muaj qee yam nrog txhua ntu ntawm tus ntsuas pa, kis tus nqi rau.
    ///
    /// Thaum uas siv cov iterators, koj mam li feem ntau saw ob peb ntawm lawv ua ke.
    /// Thaum lub sijhawm ua haujlwm ntawm cov cai, koj yuav xav txheeb xyuas seb muaj dab tsi tshwm sim ntawm ntau qhov chaw hauv raj xa dej.Yuav kom ua li ntawd, ntxig rau ib tug hu rau `inspect()`.
    ///
    /// Nws tau tshwm sim ntau rau `inspect()` siv los ua qhov cuab yeej debugging dua li muaj nyob hauv koj cov cai kawg, tab sis cov ntawv thov yuav pom nws muaj txiaj ntsig nyob rau qee qhov xwm txheej thaum muaj qhov yuam kev xav kom siv ua ntej muab pov tseg.
    ///
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // no iterator ib theem zuj zus yog complex.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // wb ntxiv ib co inspect() hu mus soj ntsuam yog dab tsi mas
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Qhov no yuav sau:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Txiav uas tsis ua ntej muab pov tseg rau lawv:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Qhov no yuav sau:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Borrows ib iterator, es siv nws.
    ///
    /// Qhov no pab tau kom tso cai rau thov iterator adapters thaum tseem ceev cov tswv cuab ntawm cov thawj iterator.
    ///
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // yog hais tias peb sim siv Taug dua, nws yuav tsis ua hauj lwm.
    /// // Cov nram qab no kab muab "kev ua yuam kev: siv ntawm tsiv nqi: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // peb sim ua dua
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // hloov, peb ntxiv hauv .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // tam sim no qhov no yog cia li zoo:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Hloov cov khoom tawm hauv cov khoom sau cia.
    ///
    /// `collect()` yuav noj dab tsi iterable, thiab tig nws mus rau hauv ib cov sau.
    /// Qhov no yog ib tug ntawm cov haib tshaj txoj kev nyob rau hauv tus txheej txheem tsev qiv ntawv, siv nyob rau hauv ib tug ntau yam ntawm cov ntsiab lus.
    ///
    /// Cov yooj yim tshaj plaws qauv nyob rau hauv uas `collect()` yog siv yog tig ib sau mus rau lwm lub.
    /// Koj coj ib tug sau, hu [`iter`] rau nws, ua ib Rev ntawm transformations, thiab ces `collect()` kawg.
    ///
    /// `collect()` kuj yuav tsim piv txwv ntawm hom uas tsis raug collections.
    /// Piv txwv li, ib tug [`String`] peev xwm yuav ua los ntawm ['char`] s, thiab ib tug iterator ntawm [`Result<T, E>`][`Result`] cov khoom yuav tsum sau mus rau hauv `Result<Collection<T>, E>`.
    ///
    /// Saib cov piv txwv hauv qab no yog xav paub ntau.
    ///
    /// Vim tias `collect()` yog qhov dav dav, nws tuaj yeem tsim teeb meem nrog hom kev nkag siab.
    /// Raws li xws li, `collect()` yog ib tug ntawm ob peb lub sij hawm koj yuav pom cov syntax affectionately hu ua tus 'turbofish': `::<>`.
    /// Qhov no pab lub inference algorithm to taub tshwj xeeb uas sau koj sim mus sau rau hauv.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Nco ntsoov tias peb xav tau `: Vec<i32>` ntawm sab laug sab laug.Qhov no yog vim hais tias peb yuav sau mus rau hauv, piv txwv li, ib tug [`VecDeque<T>`] xwb:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// Siv 'turbofish' hloov kev suav `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Vim tias `collect()` tsuas yog mob siab txog yam koj khaws cia rau hauv, koj tseem tuaj yeem siv ib hom hint me me, `_`, nrog lub turbofish:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Siv `collect()` mus ua ib tug [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Yog tias koj muaj cov npe ntawm [`Tshawb Fawb<T, E>'][' Result`] s, koj yuav siv tau `collect()` saib yog hais tias ib yam ntawm lawv tsis tau tejyam:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // muab rau peb thawj qhov yuam kev
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // muab peb daim ntawv teev cov lus teb
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Kov ib tug iterator, tsim ob collections los ntawm nws.
    ///
    /// Lub predicate kis mus rau `partition()` yuav tau rov qab `true`, los yog `false`.
    /// `partition()` rov ua khub, tag nrho cov ntsiab lus rau uas nws tau xa rov qab `true`, thiab tag nrho cov ntsiab rau nws rov qab `false`.
    ///
    ///
    /// Xyuas [`is_partitioned()`] thiab [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Reorders lub ntsiab ntawm no iterator *nyob rau hauv-qhov chaw* raws li qhov muab predicate, xws li hais tias tag nrho cov neeg uas rov qab `true` ua ntej tag nrho cov neeg uas rov qab `false`.
    ///
    /// Rov qab los rau tus xov tooj ntawm `true` ntsiab pom.
    ///
    /// Tus txheeb ze kev txiav txim ntawm partitioned khoom yog tsis khaws cia.
    ///
    /// Saib kuj [`is_partitioned()`] thiab [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Muab faib rau hauv-qhov chaw ntawm evens thiab txawv
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: peb yuav tsum txhawj txog qhov count overflowing?Tib txoj kev kom muaj ntau tshaj li
        // `usize::MAX` mutable ua tim khawv nrog ZSTs, uas yog tsis pab rau muab faib ...

        // Cov kev kaw "factory" no muaj nyob rau kom tsis txhob muaj lub siab nqig rau hauv `Self`.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Pheej nrhiav tau cov thawj `false` thiab swap nws nrog rau lub xeem `true`.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Tshawb xyuas yog tias cov ntsiab lus ntawm tus ntsuas hluav taws xob no tau faib raws li kev xav tau, xws li tias txhua tus uas rov `true` ua ntej tag nrho cov uas rov qab `false`.
    ///
    ///
    /// Xyuas [`partition()`] thiab [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Txawm hais tias tag nrho cov khoom kuaj `true`, lossis thawj kab lus tso tseg nres ntawm `false` thiab peb xyuas tias tsis muaj `true` cov khoom ntxiv tom qab ntawd.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// Ib iterator txoj kev uas siv ib tug muaj nuj nqi raws li ntev raws li nws rov ntse, ua ib zaug xwb, zaum kawg tus nqi.
    ///
    /// `try_fold()` yuav siv sij hawm ob nqe lus: ib tug thawj zaug nqi, thiab ib tug kaw nrog ob nqe lus: ib tug 'accumulator', thiab ib tug keeb.
    /// Lub kaw yog rov qab ntse, nrog rau cov nqi uas lub accumulator yuav tsum tau muaj rau tom ntej no iteration, los yog nws rov ua hauj lwm, nrog rau ib qho kev ua yuam kev muaj nuj nqis uas yog propagated rov qab mus rau tus neeg hu tam sim ntawd (short-circuiting).
    ///
    ///
    /// Thawj tus nqi yog cov nqi uas cov accumulator yuav muaj ntawm thawj hu.Yog tias ua ntawv thov kaw qhov kev ua tiav tiav rau txhua yam ntawm tus kav, `try_fold()` rov qab ua kev pom zoo kawg li kev ua tiav.
    ///
    /// Folding yog pab tau thaum twg koj muaj ib tug sau ntawm ib yam dab tsi, thiab xav kom ua ib zaug xwb tus nqi los ntawm nws.
    ///
    /// # Ceeb toom rau Implementors
    ///
    /// Ob peb ntawm lwm cov txheej txheem (forward) muaj qhov pib ua haujlwm raws li qhov ntawm no, yog li sim siv qhov no kom meej meej yog tias nws tuaj yeem ua qee yam zoo dua li qhov ua tsis tau pib lub sijhawm `for` voj kev siv.
    ///
    /// Hauv tshwj xeeb, sim kom muaj qhov hu no `try_fold()` ntawm cov khoom sab hauv los ntawm qhov no tus tsim tawm yog.
    /// Yog hais tias ntau hu uas yuav tsum tau, lub `?` neeg teb xov tooj tej zaum yuav yooj yim rau chaining lub accumulator nqi raws, tab sis ua zoo dev tom tej invariants uas yuav tsum tau yuav tsum tau upheld ua ntej cov neeg thaum ntxov rov qab.
    /// Qhov no yog ib `&mut self` txoj kev, li ntawd, iteration yuav tsum ua kom resumable tom qab tsoo ib qho yuam kev ntawm no.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // cov cim kos sum ntawm tag nrho cov ntsiab ntawm cov array
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Cov lej no hla dhau thaum ntxiv rau 100 qho
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Vim hais tias nws luv luv-circuited, cov seem ntsiab yog tseem nyob rau ntawm lub iterator.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Ib iterator txoj kev uas siv ib tug fallible muaj nuj nqi rau txhua yam khoom nyob rau hauv lub iterator, siv ceev xwmphem ntawm thawj kev ua yuam kev thiab rov qab los hais tias kev ua yuam kev.
    ///
    ///
    /// Qhov no kuj yuav xav txog li lub fallible daim ntawv ntawm [`for_each()`] los yog raws li cov stateless version ntawm [`try_fold()`].
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Nws luv-circuited, yog li cov khoom seem yog tseem nyob hauv tus kav:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Folds txhua txhua lub caij mus rau hauv ib qho accumulator los ntawm thov ib lub lag luam, rov qab zaum kawg tshwm sim.
    ///
    /// `fold()` yuav siv sij hawm ob nqe lus: ib tug thawj zaug nqi, thiab ib tug kaw nrog ob nqe lus: ib tug 'accumulator', thiab ib tug keeb.
    /// Lub kaw rov tus nqi uas lub accumulator yuav tsum tau muaj rau tom ntej no iteration.
    ///
    /// Tus nqi yog tus nqi lub accumulator yuav muaj nyob rau hauv tus thawj hu.
    ///
    /// Tom qab ua ntawv thov no kaw mus rau txhua txhua lub caij ntawm lub iterator, `fold()` rov accumulator.
    ///
    /// Txoj haujlwm no qee zaum hu ua 'reduce' lossis 'inject'.
    ///
    /// Folding yog pab tau thaum twg koj muaj ib tug sau ntawm ib yam dab tsi, thiab xav kom ua ib zaug xwb tus nqi los ntawm nws.
    ///
    /// Note: `fold()`, thiab cov hau kev zoo sib xws uas cuam tshuam tag nrho tus ntsuas hluav taws xob, tej zaum yuav tsis muaj peev xwm txiav tawm mus rau qhov tsis txawj kawg tsis tas li, txawm tias traits uas qhov txiaj ntsig tau txiav txim siab nyob rau lub sijhawm muaj peev xwm.
    ///
    /// Note: [`reduce()`] tuaj yeem siv los siv thawj lub khoom ua thawj tus nqi, yog tias cov khoom siv ntxiv thiab cov khoom tso tawm yog tib yam.
    ///
    /// # Ceeb toom rau Implementors
    ///
    /// Ob peb ntawm lwm cov txheej txheem (forward) muaj qhov pib ua haujlwm raws li qhov ntawm no, yog li sim siv qhov no kom meej meej yog tias nws tuaj yeem ua qee yam zoo dua li qhov ua tsis tau pib lub sijhawm `for` voj kev siv.
    ///
    ///
    /// Nyob rau hauv kev, sim kom muaj no hu `fold()` nyob rau hauv qhov chaw uas qhov no iterator yog muaj li.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // lub sum ntawm tag nrho cov ntsiab ntawm cov array
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Wb taug kev los ntawm txhua kauj ruam ntawm iteration ntawm no:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// Thiab yog li ntawd, peb tshwm sim zaum kawg, `6`.
    ///
    /// Nws yog ib qho muaj rau cov neeg uas tsis tau siv cov ntsuas ntau siv `for` lub voj voos nrog cov npe yam ua kom muaj txiaj ntsig.Cov yuav tsum muab mus rau hauv `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // rau lub voj:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // lawv nyob zoo ib yam
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Reduces lub ntsiab mus rau ib tug ib zaug xwb, los ntawm pheej thov ib tug txo lub lag luam.
    ///
    /// Yog tias tus ntsuas pa khoob, rov qab [`None`];txwv tsis pub, rov tshwm sim ntawm cov txo.
    ///
    /// Rau cov ntsuas hluav taws xob nrog tsawg kawg ib qho, qhov no yog tib yam li [`fold()`] nrog thawj lub ntsiab ntawm cov khoom siv raws li thawj tus nqi, folding txhua lub caij txuas ntxiv mus rau hauv nws.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Nrhiav tus nqi siab tshaj plaws:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Tests yog txhua txhua lub caij ntawm lub iterator ntais ntawv ib predicate.
    ///
    /// `all()` yuav siv sij hawm ib tug kaw uas rov `true` los yog `false`.Nws siv no kaw mus rau txhua lub caij ntawm lub iterator, thiab yog hais tias tag nrho lawv rov qab `true`, ces thiaj tsis `all()`.
    /// Yog hais tias ib yam ntawm lawv rov qab `false`, nws rov `false`.
    ///
    /// `all()` yog luv-circuiting;nyob rau hauv lwm yam lus, nws yuav tsis ua raws li sai raws li nws pom ib tug `false`, muab hais tias tsis muaj teeb meem dab tsi ntxiv tshwm sim, cov kev tshwm sim kuj yuav `false`.
    ///
    ///
    /// Ib qho kev npliag iterator rov `true`.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Nres ntawm thawj `false`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // peb yeej tseem siv `iter`, raws li muaj ntau yam hais.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Tests yog tias muaj caij ntawm lub iterator ntais ntawv ib predicate.
    ///
    /// `any()` noj ib qho kaw uas rov `true` lossis `false`.Nws siv no kaw mus rau txhua lub caij ntawm lub iterator, thiab yog hais tias ib yam ntawm lawv rov qab `true`, ces thiaj tsis `any()`.
    /// Yog hais tias tag nrho lawv rov qab `false`, nws rov `false`.
    ///
    /// `any()` yog luv luv-circuiting;hauv lwm lo lus, nws yuav nres ua kom sai li sai tau thaum nws pom `true`, muab tias tsis muaj teeb meem dab tsi ntxiv, qhov tshwm sim kuj tseem yuav `true`.
    ///
    ///
    /// Ib qho kev npliag iterator rov `false`.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Nres ntawm thawj `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // peb yeej tseem siv `iter`, raws li muaj ntau yam hais.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Searches rau ib tug keeb ntawm ib tug iterator uas satisfies ib predicate.
    ///
    /// `find()` siv kaw qhov uas rov `true` lossis `false`.
    /// Nws siv no kaw mus rau txhua lub caij ntawm lub iterator, thiab yog hais tias ib yam ntawm lawv rov qab `true`, ces `find()` rov [`Some(element)`].
    /// Yog hais tias tag nrho lawv rov qab `false`, nws rov [`None`].
    ///
    /// `find()` yog luv luv-circuiting;nyob rau hauv lwm yam lus, nws yuav tsis ua raws li sai li lub kaw rov `true`.
    ///
    /// Vim hais tias `find()` yuav siv sij hawm ib tug siv, thiab muaj ntau yam iterators iterate tshaj ua tim khawv, qhov no ua rau ib tug tejzaum ruam teeb meem nyob qhov twg lub sib cav yog ib tug muab ob npaug rau siv.
    ///
    /// Koj yuav saib tau no cov nyhuv nyob rau cov qauv hauv qab no, nrog `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Nres ntawm thawj `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // peb yeej tseem siv `iter`, raws li muaj ntau yam hais.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Nco ntsoov tias `iter.find(f)` yog sib npaug rau `iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Siv cov nuj nqi rau cov ntsiab ntawm cov iterator thiab xa rov qab thawj qhov tsis muaj qhov tshwm sim.
    ///
    ///
    /// `iter.find_map(f)` yog sib npaug rau `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Siv cov kev ua haujlwm rau lub ntsiab ntawm cov iterator thiab rov ua qhov txiaj ntsig thawj zaug lossis thawj qhov yuam kev.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Searches rau lub caij nyob rau hauv ib tug iterator, rov qab nws cov Performance index.
    ///
    /// `position()` siv kaw qhov uas rov `true` lossis `false`.
    /// Nws siv no kaw mus rau txhua lub caij ntawm lub iterator, thiab yog hais tias ib tug ntawm lawv rov `true`, ces `position()` rov [`Some(index)`].
    /// Yog tias tag nrho lawv rov `false`, nws rov [`None`].
    ///
    /// `position()` yog luv-circuiting;nyob rau hauv lwm yam lus, nws yuav tsis ua raws li sai raws li nws pom ib tug `true`.
    ///
    /// # puv Cwj Pwm
    ///
    /// Cov kev puas tsis muaj rawv tiv thaiv overflows, li ntawd, yog hais tias muaj ntau tshaj [`usize::MAX`] tsis txuam hais, nws yog ua tsis ncaj ncees lawm tshwm sim los yog panics.
    ///
    /// Yog tias qhov debug kev lees paub tau ua tiav, lub panic yog qhov lav.
    ///
    /// # Panics
    ///
    /// Qhov no muaj nuj nqi yuav panic yog hais tias tus iterator muaj ntau tshaj li `usize::MAX` tsis txuam ntsiab.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Nres ntawm thawj `true`:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // peb yeej tseem siv `iter`, raws li muaj ntau yam hais.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Cov rov qab index nyob rau iterator lub xeev
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Tshawb nrhiav ib qho khoom rau hauv ib qho chaw tawm ntawm sab xis, rov qab ua nws cov ntsuas.
    ///
    /// `rposition()` siv kaw qhov uas rov `true` lossis `false`.
    /// Nws siv no kaw mus rau txhua lub caij ntawm lub iterator, pib los ntawm lub kawg, thiab yog hais tias ib tug ntawm lawv rov `true`, ces `rposition()` rov [`Some(index)`].
    ///
    /// Yog tias tag nrho lawv rov `false`, nws rov [`None`].
    ///
    /// `rposition()` yog luv-circuiting;nyob rau hauv lwm yam lus, nws yuav tsis ua raws li sai raws li nws pom ib tug `true`.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Nres ntawm thawj `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // peb yeej tseem siv `iter`, raws li muaj ntau yam hais.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Tsis xav tau ib tug phwj kos ntawm no, vim hais tias `ExactSizeIterator` implies hais tias cov xov tooj ntawm cov ntsiab fits rau hauv ib lub `usize`.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Rov qab los ntawm cov siab tshaj plaws ntawm tus tsim.
    ///
    /// Yog tias muaj ntau cov ntsiab lus sib luag, qhov kawg ntawm kev xa rov qab.
    /// Yog hais tias lub iterator yog npliag, [`None`] yog xa rov qab.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Rov qab los yam tsawg kawg nkaus ntawm tus ntsuas hluav taws xob.
    ///
    /// Yog tias muaj ntau lub ntsiab yog muaj sib npaug yam tsawg, thawj lub khoom xa rov qab.
    /// Yog hais tias lub iterator yog npliag, [`None`] yog xa rov qab.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Rov qab los lub caij uas muab tus nqi siab tshaj plaws ntawm lub teev muaj nuj nqi.
    ///
    ///
    /// Yog tias muaj ntau cov ntsiab lus sib luag, qhov kawg ntawm kev xa rov qab.
    /// Yog hais tias lub iterator yog npliag, [`None`] yog xa rov qab.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Rov qab los lub caij uas muab tus nqi siab tshaj plaws nrog hwm rau qee sib piv muaj nuj nqi.
    ///
    ///
    /// Yog tias muaj ntau cov ntsiab lus sib luag, qhov kawg ntawm kev xa rov qab.
    /// Yog hais tias lub iterator yog npliag, [`None`] yog xa rov qab.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Rov qab los lub caij uas muab cov nqi yam tsawg kawg nkaus los ntawm txoj haujlwm ua haujlwm.
    ///
    ///
    /// Yog tias muaj ntau lub ntsiab yog muaj sib npaug yam tsawg, thawj lub khoom xa rov qab.
    /// Yog hais tias lub iterator yog npliag, [`None`] yog xa rov qab.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Rov qab los lub caij uas muab qhov tsawg kawg nkaus tus nqi nrog hwm rau qee sib piv muaj nuj nqi.
    ///
    ///
    /// Yog tias muaj ntau lub ntsiab yog muaj sib npaug yam tsawg, thawj lub khoom xa rov qab.
    /// Yog hais tias lub iterator yog npliag, [`None`] yog xa rov qab.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Reverses ib iterator txoj kev qhia.
    ///
    /// Feem ntau, iterators iterate ntawm sab laug mus rau sab xis.
    /// Tom qab siv `rev()`, tus ntsuas pa yuav hloov nws los ntawm sab xis mus rau sab laug.
    ///
    /// Qhov no ua tau yog tias tus ntsuas hluav taws xob muaj qhov kawg, yog li `rev()` tsuas yog ua haujlwm ntawm [`DoubleEndedIterator`] s.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Hloov pauv chaw tawm cov khoom sib xyaw ua ke ua khub ntim.
    ///
    /// `unzip()` kov ib tug tag nrho iterator ntawm officers, ua ob collections: ib tug los ntawm sab laug ntsiab ntawm cov officers, thiab ib tug los ntawm txoj cai hais.
    ///
    ///
    /// Txoj haujlwm no yog, hauv qee qhov kev nkag siab, sib thooj ntawm [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Tsim ib qho tawm tsam uas luam tawm ntawm tag nrho nws cov ntsiab lus.
    ///
    /// Qhov no yog pab tau thaum koj muaj ib qho iterator tshaj `&T`, tab sis koj xav tau ib tug iterator tshaj `T`.
    ///
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // theej yog tib yam li .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Tsim ib tug iterator uas ['clone`] s tag nrho nws cov ntsiab.
    ///
    /// Qhov no yog pab tau thaum koj muaj ib qho iterator tshaj `&T`, tab sis koj xav tau ib tug iterator tshaj `T`.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // cloned yog tib yam li .map(|&x| x), rau cov zauv
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Repeats ib iterator endlessly.
    ///
    /// Es tsis txhob siv ceev xwmphem ntawm [`None`], lub iterator yuav es tsis txhob rov qab pib dua, los ntawm thaum pib.Tom qab nws rov ntsuas dua, nws yuav pib thaum pib dua.Thiab dua.
    /// Thiab dua.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Qhaub lub ntsiab ntawm ib tug iterator.
    ///
    /// Yuav siv sij hawm txhua lub caij, ntxiv rau lawv ua ke, thiab rov tshwm sim.
    ///
    /// Ib qho kev npliag iterator rov pes tsawg tus nqi ntawm lub hom.
    ///
    /// # Panics
    ///
    /// Thaum hu xov tooj `sum()` thiab thawj hom lej suav tshiab tau muab xa rov qab, hom no yuav panic yog tias kev sib suav nrog xau thiab debug kev lees paub tau ua.
    ///
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Iterates tshaj rau tag nrho cov iterator, txawj tag nrho cov ntsiab
    ///
    /// Ib qho kev npliag iterator rov rau ib tug nqi ntawm lub hom.
    ///
    /// # Panics
    ///
    /// Thaum hu xov tooj `product()` thiab thawj txheej txheem hom lej raug xa rov qab, txoj kev yuav panic yog tias qhov ntsuas xau xaj thiab debug kev lees paub tau ua.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) piv lub ntsiab ntawm no [`Iterator`] nrog cov neeg ntawm lwm.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) muab cov ntsiab lus ntawm cov [`Iterator`] no coj los piv nrog rau lwm qhov txog kev sib piv lub muaj nuj nqi.
    ///
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) piv lub ntsiab ntawm no [`Iterator`] nrog cov neeg ntawm lwm.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) muab cov ntsiab lus ntawm cov [`Iterator`] no coj los piv nrog rau lwm qhov txog kev sib piv lub muaj nuj nqi.
    ///
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Txiav txim siab yog tias cov khoom ntawm [`Iterator`] no yog sib npaug nrog lwm tus.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Txiav txim seb lub ntsiab ntawm no [`Iterator`] yog sib npaug zos rau cov neeg ntawm lwm nrog hwm rau qee koob pheej ntawm lawv muaj nuj nqi.
    ///
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Txiav txim siab yog tias cov khoom ntawm [`Iterator`] no tsis sib xws rau cov ntawm lwm.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Txiav txim seb lub ntsiab ntawm no [`Iterator`] yog [lexicographically](Ord#lexicographical-comparison) tsawg tshaj li cov neeg hauv lwm.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Txiav txim seb lub ntsiab ntawm no [`Iterator`] yog [lexicographically](Ord#lexicographical-comparison) tsawg los yog sib npaug rau cov neeg lwm tus neeg.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Txiav txim siab tias cov hauv no ntawm [`Iterator`] yog [lexicographically](Ord#lexicographical-comparison) ntau dua cov ntawm lwm tus.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Txiav txim seb lub ntsiab ntawm no [`Iterator`] yog [lexicographically](Ord#lexicographical-comparison) ntau dua los yog sib npaug rau cov neeg lwm tus neeg.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Cov tshev mis yog hais tias tus hais ntawm no iterator yog txheeb.
    ///
    /// Hais tias yog, txhua lub caij `a` thiab nws cov nram qab no caij `b`, `a <= b` yuav tsum tuav.Yog hais tias lub iterator yields raws nraim pes tsawg los yog ib tug lub caij, `true` yog xa rov qab.
    ///
    /// Nco ntsoov tias yog `Self::Item` tsuas yog `PartialOrd`, tab sis tsis yog `Ord`, cov lus txhais saum toj no txhais tau tias txoj haujlwm no xa rov qab `false` yog tias muaj ob qho khoom sib law liag tsis piv.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Cov tshev mis yog hais tias tus hais ntawm no iterator yog txheeb siv cov muab comparator muaj nuj nqi.
    ///
    /// Hloov chaw siv `PartialOrd::partial_cmp`, txoj haujlwm no siv `compare` muab kev ua haujlwm los txiav txim siab qhov xaj ntawm ob lub.
    /// Sib nrug los ntawm hais tias, nws yog sib npaug rau [`is_sorted`];saib nws cov ntawv pov thawj rau cov lus qhia ntxiv.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Tshawb xyuas yog tias cov khoom siv ntawm tus ntsuas hluav taws xob no raug txheeb xyuas uas siv cov nuj nqi muab los ua kom tseem ceeb.
    ///
    /// Es tsis txhob muab piv rau cov iterator lub ntsiab ncaj qha, qhov no muaj nuj nqi sib piv hauv lub lag luam ntawm lub ntsiab, raws li txiav txim los ntawm `f`.
    /// Sib nrug los ntawm hais tias, nws yog sib npaug rau [`is_sorted`];saib nws cov ntawv pov thawj rau cov lus qhia ntxiv.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// Saib [TrustedRandomAccess]
    // Lub txawv txawv lub npe yog kom tsis txhob npe collisions nyob rau hauv txoj kev daws teeb meem saib #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}