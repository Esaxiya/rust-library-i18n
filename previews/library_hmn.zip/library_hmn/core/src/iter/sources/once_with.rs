use crate::iter::{FusedIterator, TrustedLen};

/// Tsim ib tug iterator uas lazily generates ib tug nqi raws nraim ib zaug los invoking lub muab kaw.
///
/// Qhov no feem ntau siv los hloov kho cov nqi tsim hluav taws xob rau ib tus [`chain()`] ntawm lwm yam ntawm iteration.
/// Tej zaum koj muaj ib tug iterator uas npog yuav luag txhua yam, tab sis koj xav tau ib tug ntxiv tshwj xeeb cov ntaub ntawv.
/// Tej zaum koj muaj ib tug muaj nuj nqi uas ua haujlwm nyob rau iterators, tab sis koj tsuas yuav tau mus ua ib tug nqi.
///
/// Tsis zoo li [`once()`], qhov no muaj nuj nqi yuav lazily tsim kom muaj qhov nqi rau kev thov.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Kev siv theem pib:
///
/// ```
/// use std::iter;
///
/// // ib tus yog tus lej tshaj plaws
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // yog ib tug, uas yog tag nrho peb tau txais
/// assert_eq!(None, one.next());
/// ```
///
/// Chaining ua ke nrog lwm tus iterator.
/// Cia hais tias peb xav kom iterate tshaj txhua cov ntaub ntawv ntawm lub `.foo` directory, tab sis kuj yog ib tug configuration cov ntaub ntawv,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // peb yuav tsum tau hloov los ntawm ib tug iterator ntawm DirEntry-s mus rau ib qho iterator ntawm PathBufs, yog li peb siv daim ntawv qhia
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // tam sim no, peb tus tsim rau peb cov ntaub ntawv config
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // Saw lub ob iterators ua ke rau hauv ib tug loj iterator
/// let files = dirs.chain(config);
///
/// // qhov no yuav muab peb txhua cov ntaub ntawv hauv .foo zoo li .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// Ib iterator uas yields ib zaug xwb lub caij ntawm hom `A` los ntawm ua ntawv thov cov muab kaw `F: FnOnce() -> A`.
///
///
/// Qhov no `struct` yog tsim los ntawm lub [`once_with()`] muaj nuj nqi.
/// Saib nws cov ntawv pov thawj ntxiv.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}