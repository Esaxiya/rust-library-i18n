use crate::fmt;

/// Tsim ib qho tawm tshiab uas txhua qhov qhia tawm hu rau qhov muab kaw `F: FnMut() -> Option<T>`.
///
/// Qhov no tso cai tsim ib qho kev cai lij choj nrog cov kev coj ua yam tsis siv ntau verbose syntax ntawm kev tsim hom mob siab thiab ua raws li [`Iterator`] trait rau nws.
///
/// Nco ntsoov tias `FromFn` tus ntsuas tsis ua cov kev xav txog tus cwj pwm ntawm kev kaw, thiab yog li kev txuag tsis siv [`FusedIterator`], lossis kev hla dhau [`Iterator::size_hint()`] los ntawm nws lub neej ntawd `(0, None)`.
///
///
/// Lub kaw yuav siv captures thiab nws cov chaw mus taug lub xeev thoob plaws iterations.Nyob ntawm seb yuav ua li cas lub iterator yog siv, qhov no yuav tsum tau specifying lub [`move`] lo lus tseem ceeb nyob rau hauv lub kaw.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Cia peb rov siv lub txee ntsuas los ntawm [module-level documentation]:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Increment peb suav.Qhov no yog vim li cas peb pib ntawm xoom.
///     count += 1;
///
///     // Xyuas saib yog hais tias peb twb tiav lawm suav los yog tsis.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// Tus ntsuas pa qhov twg txhua iteration hu tus muab kaw `F: FnMut() -> Option<T>`.
///
/// Qhov no `struct` yog tsim los ntawm lub [`iter::from_fn()`] muaj nuj nqi.
/// Saib nws cov ntawv pov thawj ntxiv.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}