use crate::{fmt, iter::FusedIterator};

/// Tsim ib tug tshiab iterator nyob qhov twg txhua successive yam khoom yog xoo raws li nyob rau hauv lub ntej ib.
///
/// Lub iterator pib nrog lub xub khoom (yog tias muaj) thiab txhua tus muab `FnMut(&T) -> Option<T>` kaw los laij txhua yam lub successor.
///
///
/// ```
/// use std::iter::successors;
///
/// let powers_of_10 = successors(Some(1_u16), |n| n.checked_mul(10));
/// assert_eq!(powers_of_10.collect::<Vec<_>>(), &[1, 10, 100, 1_000, 10_000]);
/// ```
#[stable(feature = "iter_successors", since = "1.34.0")]
pub fn successors<T, F>(first: Option<T>, succ: F) -> Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    // Yog hais tias qhov no muaj nuj nqi rov qab `impl Iterator<Item=T>` nws yuav yuav raws li nyob rau hauv `unfold` thiab tsis xav tau ib tug siab hom.
    //
    // Txawm li cas los muaj ib tug npe hu `Successors<T, F>` hom tso cai rau nws mus yuav `Clone` thaum `T` thiab `F` yog.
    Successors { next: first, succ }
}

/// Ib tug tshiab iterator nyob qhov twg txhua successive yam khoom yog xoo raws li nyob rau hauv lub ntej ib.
///
/// Qhov no `struct` yog tsim los ntawm lub [`iter::successors()`] muaj nuj nqi.
/// Saib nws cov ntawv pov thawj ntxiv.
///
/// [`iter::successors()`]: successors
#[derive(Clone)]
#[stable(feature = "iter_successors", since = "1.34.0")]
pub struct Successors<T, F> {
    next: Option<T>,
    succ: F,
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> Iterator for Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        let item = self.next.take()?;
        self.next = (self.succ)(&item);
        Some(item)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.next.is_some() { (1, None) } else { (0, Some(0)) }
    }
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> FusedIterator for Successors<T, F> where F: FnMut(&T) -> Option<T> {}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T: fmt::Debug, F> fmt::Debug for Successors<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Successors").field("next", &self.next).finish()
    }
}