use crate::iter::{FusedIterator, TrustedLen};

/// Tsim ib qho tawm tshiab uas tsis tas yuav rov ua ib qho tsis txaus.
///
/// Tus `repeat()` muaj nuj nqi rov ua dua tus nqi dhau ib zaug.
///
/// Infinite iterators zoo li `repeat()` feem ntau siv nrog cov hloov khoom siv zoo ib yam li [`Iterator::take()`], txhawm rau ua kom lawv muaj meej.
///
/// Yog tias lub caij hom ntawm cov kav taws koj xav tau tsis siv `Clone`, lossis yog tias koj tsis xav ua kom lub ntsiab lus rov nco hauv lub cim xeeb, koj tuaj yeem siv [`repeat_with()`] txoj haujlwm.
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Kev siv theem pib:
///
/// ```
/// use std::iter;
///
/// // tus xov tooj plaub 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // yup, tseem plaub
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Mus finite nrog [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // tias lub Piv txwv li yog ntau dhau lawm fours.Cia tsuas yog plaub muaj plaub.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... thiab tam sim no peb nyob nraum ua
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Ib iterator uas repeats lub caij endlessly.
///
/// Cov `struct` no yog tsim los ntawm [`repeat()`] muaj nuj nqi.Saib nws cov ntaub ntawv rau ntau tshaj.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}