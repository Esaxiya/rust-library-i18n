use crate::iter::{FusedIterator, TrustedLen};

/// Tsim ib tug tshiab iterator uas repeats ntsiab ntawm hom `A` endlessly los ntawm ua ntawv thov cov muab kaw, cov repeater, `F: FnMut() -> A`.
///
/// Lub `repeat_with()` nuj nqi hu lub repeater tshaj thiab tshaj dua.
///
/// Infinite iterators li `repeat_with()` yog feem ntau siv nrog adapters li [`Iterator::take()`], nyob rau hauv thiaj li yuav ua rau lawv thaiv.
///
/// Yog hais tias lub caij hom ntawm cov iterator koj xav tau implements [`Clone`], thiab nws yog lawv xav tshuaj kom qhov lub caij nyob rau hauv lub cim xeeb, koj yuav tsum tsis txhob siv lub [`repeat()`] muaj nuj nqi.
///
///
/// Ib iterator ua los ntawm `repeat_with()` tsis yog ib tug [`DoubleEndedIterator`].
/// Yog tias koj xav tau `repeat_with()` xa rov [`DoubleEndedIterator`] X, thov qhib GitHub qhov teeb meem piav qhia koj rooj plaub siv.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Kev siv theem pib:
///
/// ```
/// use std::iter;
///
/// // cia peb xav tias peb muaj qee yam nqi ntawm ib hom uas tsis yog `Clone` lossis uas tsis xav kom muaj hauv txoj kev nco cia li tsis tau vim tias nws kim:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // ib qho muaj nqis tas mus li:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Siv kev hloov thiab yuav finite:
///
/// ```rust
/// use std::iter;
///
/// // Los ntawm zeroth mus rau lub zog thib peb ntawm ob:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... thiab tam sim no peb nyob nraum ua
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// Ib iterator uas repeats ntsiab ntawm hom `A` endlessly los ntawm ua ntawv thov cov muab kaw `F: FnMut() -> A`.
///
///
/// Qhov no `struct` yog tsim los ntawm lub [`repeat_with()`] muaj nuj nqi.
/// Saib nws cov ntawv pov thawj ntxiv.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}