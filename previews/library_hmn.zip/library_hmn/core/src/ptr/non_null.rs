use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` tab sis tsis-xoom thiab covariant.
///
/// Qhov no feem ntau yog qhov raug rau kev siv thaum tsim cov ntaub ntawv cov qauv siv raw taw qhia, tab sis thaum kawg txaus ntshai rau siv vim nws cov yam ntxwv ntxiv.Yog tias koj tsis paub tseeb tias koj yuav tsum siv `NonNull<T>`, tsuas yog siv `*mut T`!
///
/// Tsis zoo li `*mut T`, tus pointer yuav tsum ib txwm tsis yog-tus, txawm tias tus pointer yeej tsis ua.Qhov no yog kom enums yuav siv no txwv tsis pub tus nqi raws li ib tug discriminant-`Option<NonNull<T>>` muaj tus loj tib yam li `* mut T`.
/// Txawm li cas los tus taw qhia kuj tseem dai kom zoo yog tias nws tsis dereferenced.
///
/// Tsis zoo li `*mut T`, `NonNull<T>` tau raug xaiv los ua covariant dhau `T`.Qhov no ua rau nws siv tau `NonNull<T>` thaum tsim cov homariant, tab sis qhia txog kev pheej hmoo ntawm tsis zoo yog siv ib hom uas tsis yog tiag tiag yog covariant.
/// (Cov kev xaiv tsis sib haum tau ua rau `*mut T` txawm tias hais tias qhov thev tsis tau zoo tsuas yog ua los ntawm kev hu xov tooj tsis ua haujlwm tsis zoo.)
///
/// Covariance yog tseeb rau feem ntau muaj kev ruaj ntseg abstractions, xws li `Box`, `Rc`, `Arc`, `Vec`, thiab `LinkedList`.Qhov no yog qhov teeb meem vim tias lawv muab API pej xeem uas ua raws li ib txwm muaj kev sib faib txoj cai XOR mutable ntawm Rust.
///
/// Yog tias koj hom tsis tuaj yeem ruaj ntseg ua covariant, koj yuav tsum paub tseeb tias nws muaj qee daim teb ntxiv txhawm rau muab ntxig tau.Feem ntau daim teb no yuav yog [`PhantomData`] yam li `PhantomData<Cell<T>>` lossis `PhantomData<&'a mut T>`.
///
/// Daim ntawv ceeb toom tias `NonNull<T>` muaj `From` piv txwv rau `&T`.Txawm li cas los, qhov no tsis hloov qhov tseeb hais tias mutating los ntawm ib tug (pointer muab los ntawm ib tug) qhia siv yog undefined tus cwj pwm tshwj tsis yog tias lub hloov tshwm sim hauv ib qho [`UnsafeCell<T>`].Tib yam mus rau qhov tsim kev sib hloov los ntawm kev siv sib qhia.
///
/// Thaum siv qhov `From` piv txwv uas tsis muaj `UnsafeCell<T>`, nws yog koj lub luag haujlwm los xyuas kom meej tias `as_mut` yeej tsis tau hu, thiab `as_ptr` yeej tsis siv rau kev hloov pauv.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` pointers yog tsis `Send` vim hais tias cov ntaub ntawv lawv siv tej zaum yuav aliased.
// NB, qhov impl no tsis tsim nyog, tab sis yuav tsum tau muab cov lus zoo yuam kev.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` pointers yog tsis `Sync` vim hais tias cov ntaub ntawv lawv siv tej zaum yuav aliased.
// NB, qhov impl no tsis tsim nyog, tab sis yuav tsum tau muab cov lus zoo yuam kev.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Tsim tus `NonNull` tshiab uas tau dai caj dab, tab sis cov khoom siv kom zoo.
    ///
    /// Qhov no yog qhov pab tau rau kev pib cov hom uas yuav muab cov tsis nkag siab, zoo li `Vec::new`.
    ///
    /// Nco ntsoov tias tus pointer tus nqi yuav tuaj yeem sawv cev ntawm lub pointer siv tau rau `T`, uas txhais tau tias qhov no yuav tsum tsis txhob siv los ua tus nqi "not yet initialized" tus nqi xa mus.
    /// Cov hom uas lazily faib yuav tsum taug qab pib los ntawm lwm yam kev txhais tau tias.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // KEV RUAJ NTSEG: mem::align_of() rov ib tug non-xoom usize uas yog ces casted
        // to a * mut T.
        // Yog li no, `ptr` tsis yog qhov tsis zoo thiab muaj kev cai rau kev hu rau new_unchecked() yog kev hwm.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Rov qab xa cov ntawv xa mus rau tus nqi.Nyob rau hauv sib piv rau [`as_ref`], qhov no tsis tau hais tias tus nqi yuav tsum tau initialized.
    ///
    /// Rau tus sawv cev mutable pom [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Thaum hu no, koj yuav tsum xyuas kom meej tias tag nrho cov ntawm cov nram qab no yog muaj tseeb:
    ///
    /// * Tus taw tes yuav tsum tau ua kom haum txhua qhov.
    ///
    /// * Nws yuav tsum yog "dereferencable" hauv qhov kev txiav txim siab txhais hauv [the module documentation].
    ///
    /// * Koj yuav tsum tswj hwm Rust cov cai tswjfwm tsis zoo, txij li kev rov qab los ntawm `'a` lub neej yog kev xaiv thiab tsis tas yuav cuam tshuam qhov tseeb lub neej ntawm cov ntaub ntawv.
    ///
    ///   Tshwj xeeb, rau lub sijhawm ntawm lub neej no, lub cim xeeb lub ntsiab lus taw qhia kom tsis txhob muaj kev sib hloov (tshwj tsis yog sab hauv `UnsafeCell`).
    ///
    /// Qhov no siv tau txawm hais tias qhov txiaj ntsig ntawm hom no tsis siv!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // KEV RUAJ NTSEG: tus neeg hu yuav tsum lav tias `self` ntsib txhua tus
        // yuav tsum muaj rau kev siv.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Rov qab xa cov ntawv pov thawj tshwj xeeb rau tus nqi.Hauv kev sib piv rau [`as_mut`], qhov no tsis tas tias tus nqi yuav tsum tau pib.
    ///
    /// Rau cov sib koom tes xyuas saib [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Thaum hu no, koj yuav tsum xyuas kom meej tias tag nrho cov ntawm cov nram qab no yog muaj tseeb:
    ///
    /// * Tus taw tes yuav tsum tau ua kom haum txhua qhov.
    ///
    /// * Nws yuav tsum yog "dereferencable" hauv qhov kev txiav txim siab txhais hauv [the module documentation].
    ///
    /// * Koj yuav tsum tswj hwm Rust cov cai tswjfwm tsis zoo, txij li kev rov qab los ntawm `'a` lub neej yog kev xaiv thiab tsis tas yuav cuam tshuam qhov tseeb lub neej ntawm cov ntaub ntawv.
    ///
    ///   Tshwj xeeb, rau lub sijhawm rau lub neej no, lub cim xeeb lub ntsiab lus taw qhia kom tsis txhob nkag (nyeem lossis sau ntawv) los ntawm lwm lub pointer.
    ///
    /// Qhov no siv tau txawm hais tias qhov txiaj ntsig ntawm hom no tsis siv!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // KEV RUAJ NTSEG: tus neeg hu yuav tsum lav tias `self` ntsib txhua tus
        // yuav tsum muaj rau kev siv.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Tsim dua tshiab `NonNull`.
    ///
    /// # Safety
    ///
    /// `ptr` yuav tsum yog non-null.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // KEV RUAJ NTSEG: tus hu tuaj yuav tsum lav tias `ptr` tsis yog-tus.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Tsim tus tshiab `NonNull` yog `ptr` yog qhov tsis yog.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // KEV RUAJ NTSEG: Tus pointer twb txheeb xyuas lawm thiab tsis yog dab tsi
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Ua tib functionality li [`std::ptr::from_raw_parts`], tsuas yog hais tias ib tug `NonNull` pointer yog xa rov qab, raws li txwv mus rau ib tug nyoos `*const` pointer.
    ///
    ///
    /// Saib cov ntaub ntawv ntawm [`std::ptr::from_raw_parts`] kom paub meej ntxiv.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // KEV RUAJ NTSEG: Qhov tshwm sim ntawm `ptr::from::raw_parts_mut` yog cov tsis yog vim tias `data_address` yog.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Rho tawm ib (muaj peev xwm dav) tus pointer rau hauv yog qhov chaw nyob thiab metadata Cheebtsam.
    ///
    /// Lub pointer yuav tom qab reconstructed nrog [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Txais cov pib x00 X pointer.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Rov qab los sib qhia rau tus nqi.Yog tias tus nqi yuav ua tsis tau zoo, [`as_uninit_ref`] yuav tsum tau siv dua.
    ///
    /// Rau tus sawv cev mutable pom [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Thaum hu no, koj yuav tsum xyuas kom meej tias tag nrho cov ntawm cov nram qab no yog muaj tseeb:
    ///
    /// * Tus taw tes yuav tsum tau ua kom haum txhua qhov.
    ///
    /// * Nws yuav tsum yog "dereferencable" hauv qhov kev txiav txim siab txhais hauv [the module documentation].
    ///
    /// * Tus taw qhia yuav tsum taw rau qhov pib ntawm `T`.
    ///
    /// * Koj yuav tsum tswj hwm Rust cov cai tswjfwm tsis zoo, txij li kev rov qab los ntawm `'a` lub neej yog kev xaiv thiab tsis tas yuav cuam tshuam qhov tseeb lub neej ntawm cov ntaub ntawv.
    ///
    ///   Tshwj xeeb, rau lub sijhawm ntawm lub neej no, lub cim xeeb lub ntsiab lus taw qhia kom tsis txhob muaj kev sib hloov (tshwj tsis yog sab hauv `UnsafeCell`).
    ///
    /// Qhov no siv tau txawm hais tias qhov txiaj ntsig ntawm hom no tsis siv!
    /// (Ib feem hais txog kev pib ua tiav tseem tsis tau muaj kev txiav txim siab tag nrho, tab sis txog thaum nws yog, tib txoj kev nyab xeeb tsuas yog los xyuas kom meej tias lawv yog qhov tseeb pib.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // KEV RUAJ NTSEG: tus neeg hu yuav tsum lav tias `self` ntsib txhua tus
        // yuav tsum muaj rau kev siv.
        unsafe { &*self.as_ptr() }
    }

    /// Rov qab los ntawm kev siv tus cim rau tus nqi.Yog tias tus nqi yuav ua tsis tau zoo, [`as_uninit_mut`] yuav tsum tau siv dua.
    ///
    /// Rau cov sib koom tes xyuas saib [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Thaum hu no, koj yuav tsum xyuas kom meej tias tag nrho cov ntawm cov nram qab no yog muaj tseeb:
    ///
    /// * Tus taw tes yuav tsum tau ua kom haum txhua qhov.
    ///
    /// * Nws yuav tsum yog "dereferencable" hauv qhov kev txiav txim siab txhais hauv [the module documentation].
    ///
    /// * Tus taw qhia yuav tsum taw rau qhov pib ntawm `T`.
    ///
    /// * Koj yuav tsum tswj hwm Rust cov cai tswjfwm tsis zoo, txij li kev rov qab los ntawm `'a` lub neej yog kev xaiv thiab tsis tas yuav cuam tshuam qhov tseeb lub neej ntawm cov ntaub ntawv.
    ///
    ///   Tshwj xeeb, rau lub sijhawm rau lub neej no, lub cim xeeb lub ntsiab lus taw qhia kom tsis txhob nkag (nyeem lossis sau ntawv) los ntawm lwm lub pointer.
    ///
    /// Qhov no siv tau txawm hais tias qhov txiaj ntsig ntawm hom no tsis siv!
    /// (Ib feem hais txog kev pib ua tiav tseem tsis tau muaj kev txiav txim siab tag nrho, tab sis txog thaum nws yog, tib txoj kev nyab xeeb tsuas yog los xyuas kom meej tias lawv yog qhov tseeb pib.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // KEV RUAJ NTSEG: tus neeg hu yuav tsum lav tias `self` ntsib txhua tus
        // uas yuav tsum muaj rau kev siv tau kev hloov pauv.
        unsafe { &mut *self.as_ptr() }
    }

    /// Nrum rau lub pointer ntawm lwm hom.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // KEV RUAJ NTSEG: `self` yog `NonNull` lub pointer uas yog qhov tsis tsim nyog tsis muaj
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Tsim qhov tsis muaj null cov hlais tawm los ntawm nyias tus pointer thiab ntev.
    ///
    /// Lub `len` sib cav yog lub xov tooj ntawm **ntsiab**, tsis yog tus naj npawb ntawm cov bytes.
    ///
    /// Txoj haujlwm no muaj kev nyab xeeb, tab sis kev cais tus nqi xa rov qab yog tsis nyab xeeb.
    /// Saib cov ntaub ntawv ntawm [`slice::from_raw_parts`] rau cov ntawv pov thawj kev nyab xeeb.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // tsim cov hlais pointer thaum pib pib nrog tus pointer rau thawj lub ntsiab
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Nco ntsoov tias qhov kev piv txwv no ua qauv qhia kev siv ntawm tus qauv no, tab sis `cia hlais= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // KEV RUAJ NTSEG: `data` yog `NonNull` lub pointer uas yog qhov tsis tsim nyog tsis muaj
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Rov qab los qhov ntev ntawm cov nqaij uas tsis yog-null.
    ///
    /// Tus nqi xa rov qab yog tus lej **ntsiab**, tsis yog tus lej bytes.
    ///
    /// Txoj haujlwm no muaj kev nyab xeeb, txawm tias thaum tsis yog-tshiab nyoos hlais tawm tsis tuaj yeem txiav ua ib qho hlais vim tus pointer tsis muaj chaw nyob uas siv tau.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Rov qab los ib tug uas tsis yog-thov pointer mus rau lub hlais tus tsis.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // KEV RUAJ NTSEG: Peb paub `self` yog uas tsis yog-thov.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Rov ib tug nyoos pointer mus rau lub hlais tus tsis.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Rov qab los sib qhia siv rau ib qho me me ntawm qhov tsis muaj peev xwm pom tau qhov tseem ceeb.Hauv kev sib piv rau [`as_ref`], qhov no tsis tas tias tus nqi yuav tsum tau pib.
    ///
    /// Rau tus sawv cev mutable pom [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Thaum hu no, koj yuav tsum xyuas kom meej tias tag nrho cov ntawm cov nram qab no yog muaj tseeb:
    ///
    /// * Tus pointer yuav tsum yog [valid] rau kev nyeem rau `ptr.len() * mem::size_of::<T>()` ntau bytes, thiab nws yuav tsum tau ua kom haum rau qhov ncaj.Qhov no txhais tau rau hauv kev:
    ///
    ///     * Tag nrho cov cim xeeb ntau ntawm cov hlais no yuav tsum muaj nyob hauv ib tus kwv yees nkaus xwb!
    ///       Cov qib qis tsis tuaj yeem hla rau ntau cov khoom sib cais.
    ///
    ///     * Tus taw rau yuav tsum tau mus raws li txawm xoom-ntev hlais.
    ///     Ib qho laj thawj rau qhov no yog hais tias enum layout kev xaiv kom zoo dua yuav cia siab rau cov neeg ua tim khawv (suav nrog hlov ib qho twg ntev) tau sib txig thiab tsis yog-cais rau qhov txawv lawv los ntawm lwm cov ntaub ntawv.
    ///
    ///     Koj tuaj yeem muab cov pointer uas siv tau xws li `data` rau xoom qhov ntev ntev siv [`NonNull::dangling()`].
    ///
    /// * Tag nrho cov loj `ptr.len() * mem::size_of::<T>()` ntawm lub hlais yuav tsum tsis muaj loj tshaj `isize::MAX`.
    ///   Saib cov ntaub ntawv kev nyab xeeb ntawm [`pointer::offset`].
    ///
    /// * Koj yuav tsum tswj hwm Rust cov cai tswjfwm tsis zoo, txij li kev rov qab los ntawm `'a` lub neej yog kev xaiv thiab tsis tas yuav cuam tshuam qhov tseeb lub neej ntawm cov ntaub ntawv.
    ///   Tshwj xeeb, rau lub sijhawm ntawm lub neej no, lub cim xeeb lub ntsiab lus taw qhia kom tsis txhob muaj kev sib hloov (tshwj tsis yog sab hauv `UnsafeCell`).
    ///
    /// Qhov no siv tau txawm hais tias qhov txiaj ntsig ntawm hom no tsis siv!
    ///
    /// Xyuas [`slice::from_raw_parts`] thiab.
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // KEV RUAJ NTSEG: tus neeg hu yuav tsum khaws daim ntawv cog lus muaj kev nyab xeeb rau `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Rov ib tug tshwj xeeb siv rau ib hlais cov tejzaum uninitialized qhov tseem ceeb.Hauv kev sib piv rau [`as_mut`], qhov no tsis tas tias tus nqi yuav tsum tau pib.
    ///
    /// Rau cov sib koom tes xyuas saib [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Thaum hu no, koj yuav tsum xyuas kom meej tias tag nrho cov ntawm cov nram qab no yog muaj tseeb:
    ///
    /// * Tus pointer yuav tsum yog [valid] rau kev nyeem thiab sau ntawv rau `ptr.len() * mem::size_of::<T>()` ntau bytes, thiab nws yuav tsum tau ua kom zoo mus rau.Qhov no txhais tau rau hauv kev:
    ///
    ///     * Tag nrho cov cim xeeb ntau ntawm cov hlais no yuav tsum muaj nyob hauv ib tus kwv yees nkaus xwb!
    ///       Cov qib qis tsis tuaj yeem hla rau ntau cov khoom sib cais.
    ///
    ///     * Tus taw rau yuav tsum tau mus raws li txawm xoom-ntev hlais.
    ///     Ib qho laj thawj rau qhov no yog hais tias enum layout kev xaiv kom zoo dua yuav cia siab rau cov neeg ua tim khawv (suav nrog hlov ib qho twg ntev) tau sib txig thiab tsis yog-cais rau qhov txawv lawv los ntawm lwm cov ntaub ntawv.
    ///
    ///     Koj tuaj yeem muab cov pointer uas siv tau xws li `data` rau xoom qhov ntev ntev siv [`NonNull::dangling()`].
    ///
    /// * Tag nrho cov loj `ptr.len() * mem::size_of::<T>()` ntawm lub hlais yuav tsum tsis muaj loj tshaj `isize::MAX`.
    ///   Saib cov ntaub ntawv kev nyab xeeb ntawm [`pointer::offset`].
    ///
    /// * Koj yuav tsum tswj hwm Rust cov cai tswjfwm tsis zoo, txij li kev rov qab los ntawm `'a` lub neej yog kev xaiv thiab tsis tas yuav cuam tshuam qhov tseeb lub neej ntawm cov ntaub ntawv.
    ///   Tshwj xeeb, rau lub sijhawm rau lub neej no, lub cim xeeb lub ntsiab lus taw qhia kom tsis txhob nkag (nyeem lossis sau ntawv) los ntawm lwm lub pointer.
    ///
    /// Qhov no siv tau txawm hais tias qhov txiaj ntsig ntawm hom no tsis siv!
    ///
    /// Xyuas [`slice::from_raw_parts_mut`] thiab.
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Qhov no muaj kev nyab xeeb zoo li `memory` siv tau rau kev nyeem thiab sau rau `memory.len()` ntau bytes.
    /// // Nco ntsoov tias hu `memory.as_mut()` yog tsis tau tso cai no raws li cov ntsiab lus tej zaum yuav uninitialized.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // KEV RUAJ NTSEG: tus neeg hu yuav tsum khaws daim ntawv cog lus muaj kev nyab xeeb rau `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Rov qab los ua lub hauv paus loj nyoos mus rau ib qho khoom lossis subslice, tsis tas ua cov kev ntsuas.
    ///
    /// Hu rau cov qauv no nrog ib tug tawm-ntawm-bounds index los yog thaum `self` yog tsis dereferencable yog *[undefined tus cwj pwm]* txawm yog hais tias tus uas ua pointer yog tsis siv.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // KEV RUAJ NTSEG: tus hu tuaj xyuas kom meej tias `self` yog qhov uas dereferencable thiab `index` hauv-kev thaj tsam.
        // Raws li qhov tshwm sim, qhov ua rau tus pointer tsis tuaj yeem yog NULL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // KEV RUAJ NTSEG: Tus pointer uas tsis txawv nws tsis tuaj yeem null, yog li ntawd qhov xwm txheej rau
        // new_unchecked() yeej fwm.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // KEV RUAJ NTSEG: Qhov kev hloov pauv tsis tuaj yeem siv tsis tau.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // KEV RUAJ NTSEG: A reference tsis tau thov, ces cov tej yam kev mob rau
        // new_unchecked() yeej fwm.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}