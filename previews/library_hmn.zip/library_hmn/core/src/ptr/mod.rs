//! Ua tes tswj kev nco los ntawm cov ntsiab lus nyoos.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Ntau yam haujlwm hauv qhov qauv no siv cov lus qhia ua lub sib cav thiab nyeem los ntawm lossis sau rau lawv.Yuav kom qhov no muaj kev nyab xeeb, cov ntsiab lus no yuav tsum yog *siv tau*.
//! Txawm hais tias tus pointer siv tau yog nyob ntawm kev ua haujlwm nws tau siv rau (nyeem lossis sau), thiab qhov tsawg ntawm lub cim xeeb uas nkag (piv txwv li, ntau npaum li cas bytes yog read/written).
//! Feem ntau cov haujlwm siv `*mut T` thiab `* const T` los saib tsuas yog ib tus nqi, nyob rau hauv rooj plaub no cov ntaub ntawv rho qhov loj me thiab implicitly kwv yees nws yog `size_of::<T>()` bytes.
//!
//! Cov cai tseem ceeb rau kev siv tau tseem tsis tau txiav txim tseem.Lub lav uas muaj nyob ntawm lub sijhawm no yog tsawg heev:
//!
//! * [null] tus pointer yog *ib txwm* siv tsis tau, tsis hais txog kev nkag tau ntawm [size zero][zst].
//! * Rau tus pointer siv tau, nws yog qhov tsim nyog, tab sis tsis txaus ib txwm, tias tus pointer yuav *tsis nkag siab*: lub cim xeeb ntawm qhov loj muab pib ntawm tus pointer yuav tsum txhua yam nyob hauv qhov ciaj ciam ntawm ib qho kev faib khoom.
//!
//! Nco ntsoov tias hauv Rust, txhua txhua (stack-allocated) qhov sib txawv yog suav hais tias yog cais cov khoom tau sib txawv.
//! * Txawm hais tias kev ua haujlwm ntawm [size zero][zst], tus pointer yuav tsum tsis txhob taw tes rau qhov kev ua haujlwm nco, piv txwv li, kev sib cog lus ua rau cov taw tes tsis muaj tseeb txawm tias xoom ua haujlwm.
//! Txawm li cas los xij, ntiab tawm ib qho tsis yog xoom integer *lus ncaj nraim* rau tus pointer siv tau rau xoom-nkag mus, txawm tias qee qhov cim xeeb tshwm sim muaj nyob ntawm qhov chaw nyob thiab tau sib kis.
//! Qhov no sib raug rau sau koj tus kheej kev faib: kev faib cov khoom xoom tsis yog qhov nyuaj.
//! Txoj kev canonical kom tau txais lub pointer uas siv tau rau xoom-nkag mus yog [`NonNull::dangling`].
//! * Txhua qhov kev nkag nkag tau ua los ntawm kev ua haujlwm hauv qhov qauv no yog *tsis yog-atomic* hauv kev nkag siab ntawm [atomic operations] siv los synchronize ntawm cov xov.
//! Qhov no txhais tau tias nws yog undefined tus cwj pwm ua ob txhawb accesses rau tib qho chaw los ntawm ntau threads tshwj tsis yog tias ob leeg accesses tsuas nyeem los ntawm kev nco.
//! Daim ntawv ceeb toom tias qhov no ntsees suav nrog [`read_volatile`] thiab [`write_volatile`]: Cov kev hloov pauv yooj yim tsis tuaj yeem siv rau kev sib txuas lus xov.
//! * Qhov tshwm sim ntawm kev xa khoom siv mus rau tus pointer siv tau ntev li ntev tau qhov sib sib zog ua lub hauv paus yog nyob thiab tsis siv (tsuas yog tus taw tes nyoos) siv los nkag mus rau tib lub cim xeeb.
//!
//! Cov axioms no, nrog rau kev ceev faj siv [`offset`] rau kev kwv lub laij lej, yog qhov txaus los ua kom raug ua raws ntau yam muaj txiaj ntsig nyob hauv cov cai tsis zoo.
//! Cov kev ruaj khov zoo yuav muab qhov kawg, raws li [aliasing] cov kev cai tau txiav txim siab.
//! Xav paub ntau ntxiv, saib [book] ntxiv rau ntu hauv ntu siv rau [undefined behavior][ub].
//!
//! ## Alignment
//!
//! Siv tau cov ntsiab lus tseem ceeb raws li tau hais los saum toj no tsis yog ua raws li cov lus (qhov "proper" kev teeb tsa yog txhais los ntawm cov ntsuas hom, piv txwv li, `*const T` yuav tsum tau ua raws li `mem::align_of::<T>()`).
//! Txawm li cas los xij, feem ntau cov haujlwm xav tau lawv cov kev sib cav kom raug ua kom zoo, thiab yuav qhia meej qhov kev tseev kom muaj no hauv lawv cov ntaub ntawv.
//! Cov kev tsis suav tshwj xeeb rau qhov no yog [`read_unaligned`] thiab [`write_unaligned`].
//!
//! Thaum tus ua haujlwm yuav tsum tau ua kom haum, nws ua li ntawd txawm tias qhov nkag tau muaj qhov loj 0, piv txwv li, txawm tias lub cim xeeb tsis tau kov tiag.Xav txog kev siv [`NonNull::dangling`] thaum zoo li no.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Executes lub destructor (yog tias muaj) ntawm lub taw-rau nqi.
///
/// Qhov no yog semantically sib npaug rau hu rau [`ptr::read`] thiab muab pov tseg qhov tshwm sim, tab sis muaj cov txiaj ntsig zoo li nram no:
///
/// * Nws yog *yuav tsum tau* siv `drop_in_place` los tso cov hom tsis paub zoo li trait khoom, vim tias lawv tsis tuaj yeem nyeem tawm rau hauv pawg thiab poob qis dua.
///
/// * Nws yog friendlier rau lub optimizer los ua qhov no ntau dua [`ptr::read`] thaum xa me nyuam cim tseg cim xeeb (piv txwv li, hauv kev siv ntawm `Box`/`Rc`/`Vec`), raws li lub compiler tsis xav tau los ua pov thawj tias nws yog suab ua ke rau daim ntawv theej.
///
///
/// * Nws tuaj yeem siv los txo cov ntaub ntawv [pinned] thaum `T` tsis yog `repr(packed)` (cov ntaub ntawv pinned yuav tsum tsis txhob txav ua ntej nws poob).
///
/// Cov nqi tsis sib npaug tsis tuaj yeem muab tso rau hauv qhov chaw, lawv yuav tsum tau theej tawm rau qhov chaw uas txuas mus ntxiv ua ntej siv [`ptr::read_unaligned`].Rau packed structs, qhov no txav yog ua li cas cia li los ntawm lub compiler.
/// Qhov no txhais tau hais tias cov liaj teb ntawm cov txheej txheem ntim khoom tsis raug tso tawm hauv-chaw.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// Tus cwj pwm yog undefined yog ib yam ntawm cov nram qab no tej yam kev mob yog ua txhaum:
///
/// * `to_drop` yuav tsum yog [valid] rau kev nyeem thiab sau.
///
/// * `to_drop` yuav tsum muaj kev sib thooj.
///
/// * Tus nqi `to_drop` cov ntsiab lus yuav tsum siv tau rau kev poob qis, uas yuav txhais tau tias nws yuav tsum tau tuav pov hwm ntxiv, qhov no yog hom tso siab.
///
/// Tsis tas li ntawd, yog tias `T` tsis yog [`Copy`], siv cov taw qhia-rau tus nqi tom qab hu `drop_in_place` tuaj yeem ua rau tus cwj pwm tsis paub qhov tseeb.Nco ntsoov tias `*to_drop = foo` suav ua tus siv vim tias nws yuav ua rau tus nqi poob dua.
/// [`write()`] tuaj yeem siv rau kev sau ntaub ntawv tsis muaj qhov ua rau nws poob.
///
/// Nco ntsoov tias txawm tias `T` muaj qhov loj `0`, lub pointer yuav tsum tsis yog-NULL thiab ua raws li cov ntawv cog lus.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Ua kom tshem tawm cov khoom kawg los ntawm vector:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Tau txais lub pointer nyoos mus rau lub caij kawg hauv `v`.
///     let ptr = &mut v[1] as *mut _;
///     // Ua kom luv luv `v` txhawm rau tiv thaiv cov khoom kawg ntawm kev tso tawm.
///     // Peb ua li ntawd ua ntej, txhawm rau tiv thaiv teeb meem yog tias `drop_in_place` hauv qab panics.
///     v.set_len(1);
///     // Yog tsis muaj hu rau `drop_in_place`, cov khoom kawg yuav tsis raug tshem tawm, thiab qhov kev nco nws tswj nws yuav xau.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Ua kom ntseeg tau tias cov khoom kawg tau poob.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Daim ntawv ceeb toom hais tias cov compiler ua no luam thaum xa me nyuam rov ntim structs, piv txwv li, koj tsis feem ntau yog muaj rau worry txog cov teeb meem tshwj tsis yog tias koj hu rau `drop_in_place` manually.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Txoj cai ntawm no tsis muaj teeb meem, qhov no yog hloov los ntawm qhov tiag poob kua nplaum los ntawm tus sau.
    //

    // KEV RUAJ NTSEG: saib cov lus saum toj no
    unsafe { drop_in_place(to_drop) }
}

/// Tsim cov hnab ntawv tsis zoo.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Tsim cov pointer tsis muaj dab tsi hloov pauv.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// Phau ntawv impl xav tau kom tsis txhob cuam tshuam `T: Clone` ua txhua yam.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// Phau ntawv impl xav tau kom tsis txhob `T: Copy` ua txhua yam.
impl<T> Copy for FatPtr<T> {}

/// Ua cov ntawv ntuag nyoos ntawm tus taw thiab ntev.
///
/// Lub `len` sib cav yog lub xov tooj ntawm **ntsiab**, tsis yog tus naj npawb ntawm cov bytes.
///
/// Txoj haujlwm no muaj kev nyab xeeb, tab sis tiag tiag siv qhov xa rov qab tus nqi tsis nyab xeeb.
/// Saib cov ntaub ntawv ntawm [`slice::from_raw_parts`] rau cov ntawv pov thawj kev nyab xeeb.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // tsim cov hlais pointer thaum pib pib nrog tus pointer rau thawj lub ntsiab
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // KEV RUAJ NTSEG: Nkag mus rau qhov muaj nqis los ntawm `Repr` lub koomhaum muaj kev ruaj ntseg txij li * const [T]
        //
        // thiab FatPtr muaj qhov cim xeeb ntawm cov txheej txheem ib yam.Tsuas yog std tuaj yeem ua qhov kev lav no.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Ua tib lub luag haujlwm zoo ib yam li [`slice_from_raw_parts`], tshwj tsis yog tias ib qho nqaij nyoos hloov pauv tau rov qab, raws li txwv tsis pub rau cov nqaij nyoos hloov pauv tshiab.
///
///
/// Saib cov ntaub ntawv ntawm [`slice_from_raw_parts`] kom paub meej ntxiv.
///
/// Txoj haujlwm no muaj kev nyab xeeb, tab sis tiag tiag siv qhov xa rov qab tus nqi tsis nyab xeeb.
/// Saib cov ntaub ntawv ntawm [`slice::from_raw_parts_mut`] rau cov ntawv pov thawj kev nyab xeeb.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // cob rau tus nqi ntawm qhov raug ntsuas hauv daim hlais
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // KEV RUAJ NTSEG: Nkag mus rau tus nqi los ntawm `Repr` lub koomhaum muaj kev ruaj ntseg txij li * mut [T]
        // thiab FatPtr muaj tib lub cim xeeb layouts
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Swaps qhov muaj nuj nqis ntawm ob qhov chaw hloov pauv ntawm tib hom, tsis muaj kev txiav tawm ib qho twg.
///
/// Tab sis rau cov nram qab no ob yam, qhov no muaj nuj nqi yog semantically sib npaug rau [`mem::swap`]:
///
///
/// * Nws ua haujlwm ntawm cov taw tes nyoos hloov chaw siv.
/// Thaum cov ntaub ntawv muaj, [`mem::swap`] yuav tsum yog qhov zoo.
///
/// * Lub ob taw tes-rau qhov tseem ceeb tej zaum yuav sib tshooj.
/// Yog tias cov nuj nqis ua sib tshooj, tom qab thaj tsam ntawm cov cim xeeb los ntawm `x` yuav siv.
/// Qhov no yog pom nyob hauv qhov piv txwv thib ob hauv qab no.
///
/// # Safety
///
/// Tus cwj pwm yog undefined yog ib yam ntawm cov nram qab no tej yam kev mob yog ua txhaum:
///
/// * Ob qho `x` thiab `y` yuav tsum yog [valid] rau ob qho nyeem thiab sau.
///
/// * Ob qho `x` thiab `y` yuav tsum muaj kev ua tau zoo.
///
/// Nco ntsoov tias txawm tias `T` muaj qhov loj me `0`, cov taw tes yuav tsum tsis yog-NULL thiab ua raws li cov qauv.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Kev sib pauv ob thaj chaw uas tsis yog sib tshooj:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // qhov no yog `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // qhov no yog `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Swapping ob cheeb tsam sib tshooj:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // qhov no yog `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // qhov no yog `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // Qhov ntsuas kub `1..3` ntawm qhov sib tshooj sib tshooj ntawm `x` thiab `y`.
///     // Cov txiaj ntsig uas tsim nyog yuav yog rau lawv yog `[2, 3]`, yog li qhov ntsuas `0..3` yog `[1, 2, 3]` (kev sib piv `y` ua ntej `swap`);los yog rau lawv yuav tsum yog `[0, 1]` kom qhov taw qhia `1..4` yog `[0, 1, 2]` (sib piv `x` ua ntej `swap`).
/////
///     // Qhov kev siv no tau txhais los ua qhov kev xaiv tom kawg.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Muab peb tus kheej qee qhov chaw khawb los ua haujlwm nrog.
    // Peb tsis tas txhawj txog kev poob: `MaybeUninit` tsis muaj dab tsi thaum poob.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Ua qhov sib pauv Kev Ruaj Ntseg: tus hu yuav tsum lav tias `x` thiab `y` yog qhov siv tau rau kev sau thiab ua raws li cov ntawv sau cia.
    // `tmp` tsis tuaj yeem sib tshooj `x` lossis `y` vim `tmp` tsuas yog faib rau cov pawg ua ib qho sib cais sib cais cov khoom.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` thiab `y` tej zaum yuav sib tshooj
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Swaps `count * size_of::<T>()` bytes ntawm ob thaj tsam ntawm lub cim xeeb pib thaum `x` thiab `y`.
/// Ob cheeb tsam yuav tsum *tsis* sib tshooj.
///
/// # Safety
///
/// Tus cwj pwm yog undefined yog ib yam ntawm cov nram qab no tej yam kev mob yog ua txhaum:
///
/// * Ob qho `x` thiab `y` yuav tsum yog [valid] rau ob qho nyeem thiab sau ntawm `suav *
///   size_of: :<T>() `bytes.
///
/// * Ob qho `x` thiab `y` yuav tsum muaj kev ua tau zoo.
///
/// * Thaj av ntawm lub cim xeeb pib ntawm `x` nrog qhov loj ntawm `suav *
///   size_of: :<T>() `bytes yuav tsum *tsis* sib tshooj nrog thaj av ntawm lub cim xeeb pib ntawm `y` nrog qhov loj me.
///
/// Nco ntsoov tias txawm yog hais tias tus zoo theej loj ('suav * size_of: :<T>() ') Yog `0`, lub pointers yuav tsum uas tsis yog-thov thiab kom raws li.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Kev siv theem pib:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // KEV RUAJ NTSEG: tus hu yuav tsum lav tias `x` thiab `y` yog
    // siv tau rau kev sau ntawv thiab ua raws li cov kev cai.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // Rau cov hom me me dua ntawm cov block optimization hauv qab no, tsuas yog sib hloov ncaj qha kom tsis txhob pessimizing codegen.
    //
    if mem::size_of::<T>() < 32 {
        // KEV RUAJ NTSEG: tus hu yuav tsum lav tias `x` thiab `y` siv tau
        // rau kev sau ntawv, tsim nyog kom haum, thiab tsis yog sib tshooj.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // KEV RUAJ NTSEG: tus neeg hu yuav tsum khaws daim ntawv cog lus muaj kev nyab xeeb rau `swap_nonoverlapping`.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // Cov hau kev ntawm no yog siv simd los sib pauv x&y nraaj.
    // Kev sim qhia tawm tias kev sib pauv 32 bytes lossis 64 bytes ntawm lub sijhawm yog siv tau rau Intel Haswell E processors.
    // LLVM muaj peev xwm nce siab dua yog tias peb muab tus txheej txheem #[repr(simd)], txawm tias peb tsis tau siv cov qauv no ncaj qha.
    //
    //
    // FIXME repr(simd) tawg ntawm emscripten thiab redox
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Ntxees mus txog x&y, luam theej lawv `Block` ib lub sijhawm Tus optimizer yuav tsum sau lub voj tag nrho rau feem ntau hom NB
    // Peb siv tsis tau lub voj li `range` impl hu `mem::swap` recursively
    //
    let mut i = 0;
    while i + block_size <= len {
        // Tsim qee qhov tsis muaj qhov cim cia li kos qhov chaw tshaj tawm Tshaj tawm `t` ntawm no zam zam kev teeb tsa cov pawg thaum lub voj no tsis siv.
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // KEV RUAJ NTSEG: Raws li `i < len`, thiab raws li tus neeg hu yuav tsum lav tias `x` thiab `y` siv tau
        // rau `len` bytes, `x + i` thiab `y + i` yuav tsum yog chaw nyob siv, uas ua tiav daim ntawv cog lus muaj kev nyab xeeb rau `add`.
        //
        // Tsis tas li, tus hu yuav tsum lav tias `x` thiab `y` yog qhov siv tau rau kev sau, ua raws li cov txheej txheem sib dhos, thiab tsis yog sib tshooj, uas ua tiav daim ntawv cog lus muaj kev nyab xeeb rau `copy_nonoverlapping`.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Hloov qhov block ntawm bytes ntawm x&y, siv t ua qhov tsis yog ib ntus Qhov no yuav tsum tau ua kom zoo rau hauv cov kev ua haujlwm zoo ntawm SIMD thaum muaj
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Sib pauv lwm tus bytes
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // KEV RUAJ NTSEG: saib cov lus tshaj tawm kev nyab xeeb dhau los.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// Txav `src` rau hauv taw tes `dst`, rov qab dhau los `dst` tus nqi.
///
/// Tsis yog tus nqis.
///
/// Txoj haujlwm no yog sib npaug rau [`mem::replace`] tshwj tsis yog tias nws ua haujlwm ntawm cov taw tes nyoos tsis siv cov ntawv xa mus.
/// Thaum cov ntaub ntawv muaj, [`mem::replace`] yuav tsum yog qhov zoo.
///
/// # Safety
///
/// Tus cwj pwm yog undefined yog ib yam ntawm cov nram qab no tej yam kev mob yog ua txhaum:
///
/// * `dst` yuav tsum yog [valid] rau kev nyeem thiab sau.
///
/// * `dst` yuav tsum muaj kev sib thooj.
///
/// * `dst` yuav tsum taw rau qhov pib tsim nyog ntawm hom `T`.
///
/// Nco ntsoov tias txawm tias `T` muaj qhov loj `0`, lub pointer yuav tsum tsis yog-NULL thiab ua raws li cov ntawv cog lus.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` yuav muaj qhov cuam tshuam tib yam yam tsis tas yuav muaj lub thaiv tsis zoo.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // KEV RUAJ NTSEG: tus neeg hu yuav tsum lav tias `dst` siv tau los ua
    // pov rau ib qho hloov tau siv (siv tau rau sau, mus raws li, pib ua ntej), thiab tsis tuaj yeem sib tshooj `src` txij li `dst` yuav tsum taw rau qhov khoom sib cais tshwj xeeb.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // tsis sib tshooj
    }
    src
}

/// Nyeem tus nqi ntawm `src` yam tsis txav nws.Qhov no tawm lub cim xeeb hauv `src` tsis hloov pauv.
///
/// # Safety
///
/// Tus cwj pwm yog undefined yog ib yam ntawm cov nram qab no tej yam kev mob yog ua txhaum:
///
/// * `src` yuav tsum yog [valid] rau kev nyeem.
///
/// * `src` yuav tsum muaj kev sib thooj.Siv [`read_unaligned`] yog qhov no tsis zoo.
///
/// * `src` yuav tsum taw rau qhov pib tsim nyog ntawm hom `T`.
///
/// Nco ntsoov tias txawm tias `T` muaj qhov loj `0`, lub pointer yuav tsum tsis yog-NULL thiab ua raws li cov ntawv cog lus.
///
/// # Examples
///
/// Kev siv theem pib:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Tsim kev siv [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Tsim cov ntawv luam ntsis ntawm tus nqi ntawm `a` hauv `tmp`.
///         let tmp = ptr::read(a);
///
///         // Tawm hauv qhov teeb meem no (txawm yog los ntawm kev xa rov qab los yog hu xov tooj rau qhov haujlwm uas panics) yuav ua rau tus nqi hauv `tmp` los ua kom poob thaum uas tus nqi tseem raug xa los ntawm `a`.
///         // Qhov no tuaj yeem ua rau tus cwj pwm tsis paub tseeb yog tias `T` tsis yog `Copy`.
/////
/////
///
///         // Tsim cov ntawv luam ntsis ntawm tus nqi ntawm `b` hauv `a`.
///         // Qhov no muaj kev nyab xeeb vim tias kev xa tawm tsis tuaj yeem siv lub npe cuav.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Raws li saum toj no, kev tawm ntawm no tuaj yeem ua rau tus cwj pwm tsis paub vim tias tus nqi qub yog saib los ntawm `a` thiab `b`.
/////
///
///         // Txav `tmp` rau `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` tau hloov mus lawm (`write` yuav siv tswv cuab ntawm nws qhov kev sib cav zaum ob), yog li tsis muaj dab tsi poob nqis ntawm no.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Cov tswv ntawm cov nqi xa rov qab
///
/// `read` tsim cov ntawv luam ntsis ntawm `T`, tsis hais `T` yog [`Copy`].
/// Yog `T` tsis yog [`Copy`], siv ob qho tib si xa rov qab thiab tus nqi ntawm `*src` tuaj yeem ua txhaum kev nco txog kev nyab xeeb.
/// Nco ntsoov tias qhov muab rau `*src` suav tau siv yog tias nws yuav sim poob tus nqi ntawm `* src`.
///
/// [`write()`] tuaj yeem siv rau kev sau ntaub ntawv tsis muaj qhov ua rau nws poob.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` tam sim no taw rau cov teeb meem nco ib yam li `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // Kev muab rau `s2` ua rau nws cov nqi qub tau nqis.
///     // Tshaj tawm ntawm qhov point no, `s` yuav tsum tsis siv ntxiv lawm, raws li qhov kev nco hauv qab tau tso tawm.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // Kev muab rau `s` yuav ua rau tus nqi qub poob qis dua, uas ua rau tus cwj pwm tsis tau xaiv cia.
/////
///     // s= String::from("bar");//YEEM
///
///     // `ptr::write` yuav siv tau los sau qhov muaj nqis yam tsis muaj nqis.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // KEV RUAJ NTSEG: tus neeg hu yuav tsum lav tias `src` siv tau rau kev nyeem ntawv.
    // `src` yuav tsis sib tshooj `tmp` vim hais tias `tmp` twb cia li faib rau cov pawg raws li ib tug nyias muaj nyias ib faib khoom.
    //
    //
    // Tsis tas li, txij li peb tsuas yog sau tus nqi tsim nyog rau `tmp`, nws tau lees tias yuav tsum ua kom raug.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Nyeem tus nqi ntawm `src` yam tsis txav nws.Qhov no tawm lub cim xeeb hauv `src` tsis hloov pauv.
///
/// Tsis zoo li [`read`], `read_unaligned` ua haujlwm nrog cov ntsuas tsis pom.
///
/// # Safety
///
/// Tus cwj pwm yog undefined yog ib yam ntawm cov nram qab no tej yam kev mob yog ua txhaum:
///
/// * `src` yuav tsum yog [valid] rau kev nyeem.
///
/// * `src` yuav tsum taw rau qhov pib tsim nyog ntawm hom `T`.
///
/// Zoo li [`read`], `read_unaligned` tsim cov ntawv luam ntawm `T`, txawm tias `T` yog [`Copy`].
/// Yog `T` tsis yog [`Copy`], siv ob qho tib si xa rov qab thiab tus nqi ntawm `*src` tuaj yeem [violate memory safety][read-ownership].
///
/// Nco ntsoov tias txawm tias `T` muaj qhov loj `0`, lub pointer yuav tsum tsis yog-NULL.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## Ntawm `packed` qauv
///
/// Nws tam sim no tsis yooj yim sua los tsim cov taw tes nyoos rau unaligned teb ntawm ib txheej qauv.
///
/// Sim los tsim cov pointer nyoos rau ib qho `unaligned` struct teb nrog cov kev qhia xws li `&packed.unaligned as *const FieldType` tsim kev ntsuas qhov nruab nrab tsis txaus ntseeg ua ntej hloov ntawd mus rau lub pointer nyoos.
///
/// Tias qhov kev siv no tsuas yog ib ntus thiab raug ntiab tawm tam sim no tsis tseem ceeb raws li tus sau ntawv ib txwm cia siab tias cov ntawv xa mus yuav raug muab kho kom zoo.
/// Yog li ntawd, siv `&packed.unaligned as *const FieldType` ua rau tam sim* tus cwj pwm tsis txaus ntseeg * hauv koj qhov kev zov me nyuam.
///
/// Ib qho piv txwv txog yam uas tsis xav ua thiab qhov no cuam tshuam dab tsi rau `read_unaligned` yog:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Ntawm no peb sim mus coj qhov chaw nyob ntawm 32-ntsis tus lej zauv uas tsis sib thooj.
///     let unaligned =
///         // Ib ntus uas tsis tau lees paub yog tsim nyob rau ntawm no uas ua rau muaj tus cwj pwm tsis tau txiav txim siab tsis hais seb qhov siv raug siv los tsis siv.
/////
///         &packed.unaligned
///         // Caw rau tus pointer nyoos tsis pab;tus txhaum ces tshwm sim.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Kev nkag mus rau cov teb uas tsis tau txiav txim ncaj qha nrog piv txwv li `packed.unaligned` tseem muaj kev ruaj ntseg tab sis.
///
///
///
///
///
///
// FIXME: Hloov kho cov ntaub ntawv raws li kev tshwm sim ntawm RFC #2582 thiab cov phooj ywg.
/// # Examples
///
/// Nyeem tus nqi usize los ntawm lub byte tsis:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // KEV RUAJ NTSEG: tus neeg hu yuav tsum lav tias `src` siv tau rau kev nyeem ntawv.
    // `src` yuav tsis sib tshooj `tmp` vim hais tias `tmp` twb cia li faib rau cov pawg raws li ib tug nyias muaj nyias ib faib khoom.
    //
    //
    // Tsis tas li, txij li peb tsuas yog sau tus nqi tsim nyog rau `tmp`, nws tau lees tias yuav tsum ua kom raug.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Sau dua qhov chaw nco nrog qhov muaj txiaj ntsig tsis tau nyeem lossis poob tus nqi qub.
///
/// `write` tsis tso cov ntsiab lus ntawm `dst`.
/// Qhov no muaj kev nyab xeeb, tab sis nws tuaj yeem xau cov nyiaj los sis cov peev txheej, yog li kev saib xyuas yuav tsum tsis txhob saib xyuas ib qho khoom uas yuav tsum tau ua poob.
///
///
/// Tsis tas li ntawd, nws tsis poob `src`.Semantically, `src` tau hloov mus rau hauv qhov chaw qhia mus rau `dst`.
///
/// Qhov no yog qhov tsim nyog rau kev pib tsis nco qhov cim, lossis rov sau lub cim xeeb uas yav tas los tau [`read`] los ntawm.
///
/// # Safety
///
/// Tus cwj pwm yog undefined yog ib yam ntawm cov nram qab no tej yam kev mob yog ua txhaum:
///
/// * `dst` yuav tsum yog [valid] rau sau.
///
/// * `dst` yuav tsum muaj kev sib thooj.Siv [`write_unaligned`] yog qhov no tsis zoo.
///
/// Nco ntsoov tias txawm tias `T` muaj qhov loj `0`, lub pointer yuav tsum tsis yog-NULL thiab ua raws li cov ntawv cog lus.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Kev siv theem pib:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Tsim kev siv [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Tsim cov ntawv luam ntsis ntawm tus nqi ntawm `a` hauv `tmp`.
///         let tmp = ptr::read(a);
///
///         // Tawm hauv qhov teeb meem no (txawm yog los ntawm kev xa rov qab los yog hu xov tooj rau qhov haujlwm uas panics) yuav ua rau tus nqi hauv `tmp` los ua kom poob thaum uas tus nqi tseem raug xa los ntawm `a`.
///         // Qhov no tuaj yeem ua rau tus cwj pwm tsis paub tseeb yog tias `T` tsis yog `Copy`.
/////
/////
///
///         // Tsim cov ntawv luam ntsis ntawm tus nqi ntawm `b` hauv `a`.
///         // Qhov no muaj kev nyab xeeb vim tias kev xa tawm tsis tuaj yeem siv lub npe cuav.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Raws li saum toj no, kev tawm ntawm no tuaj yeem ua rau tus cwj pwm tsis paub vim tias tus nqi qub yog saib los ntawm `a` thiab `b`.
/////
///
///         // Txav `tmp` rau `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` tau hloov mus lawm (`write` yuav siv tswv cuab ntawm nws qhov kev sib cav zaum ob), yog li tsis muaj dab tsi poob nqis ntawm no.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Peb hu rau intrinsics ncaj qha kom tsis txhob muaj nuj nqi hu nyob rau hauv txoj cai generated li `intrinsics::copy_nonoverlapping` yog wrapper muaj nuj nqi.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // KEV RUAJ NTSEG: tus neeg hu yuav tsum lav tias `dst` yog qhov siv tau rau kev sau ntawv.
    // `dst` tsis tuaj yeem `src` vim tias tus hu tuaj yeem hloov mus rau `dst` thaum `src` yog los ntawm txoj haujlwm no.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Sau dua qhov chaw nco nrog qhov muaj txiaj ntsig tsis tau nyeem lossis poob tus nqi qub.
///
/// Tsis zoo li [`write()`], tus pointer tuaj yeem tsis muaj qhov sib txuas.
///
/// `write_unaligned` tsis tso cov ntsiab lus ntawm `dst`.Qhov no muaj kev nyab xeeb, tab sis nws tuaj yeem xau cov nyiaj los sis cov peev txheej, yog li kev saib xyuas yuav tsum tsis txhob saib xyuas ib qho khoom uas yuav tsum tau ua poob.
///
/// Tsis tas li ntawd, nws tsis poob `src`.Semantically, `src` tau hloov mus rau hauv qhov chaw qhia mus rau `dst`.
///
/// Qhov no yog qhov tsim nyog rau kev pib kev nco tsis tsim, lossis rov cim xeeb uas yav dhau los tau nyeem nrog [`read_unaligned`].
///
/// # Safety
///
/// Tus cwj pwm yog undefined yog ib yam ntawm cov nram qab no tej yam kev mob yog ua txhaum:
///
/// * `dst` yuav tsum yog [valid] rau sau.
///
/// Nco ntsoov tias txawm tias `T` muaj qhov loj `0`, lub pointer yuav tsum tsis yog-NULL.
///
/// [valid]: self#safety
///
/// ## Ntawm `packed` qauv
///
/// Nws tam sim no tsis yooj yim sua los tsim cov taw tes nyoos rau unaligned teb ntawm ib txheej qauv.
///
/// Sim los tsim cov pointer nyoos rau ib qho `unaligned` struct teb nrog cov kev qhia xws li `&packed.unaligned as *const FieldType` tsim kev ntsuas qhov nruab nrab tsis txaus ntseeg ua ntej hloov ntawd mus rau lub pointer nyoos.
///
/// Tias qhov kev siv no tsuas yog ib ntus thiab raug ntiab tawm tam sim no tsis tseem ceeb raws li tus sau ntawv ib txwm cia siab tias cov ntawv xa mus yuav raug muab kho kom zoo.
/// Yog li ntawd, siv `&packed.unaligned as *const FieldType` ua rau tam sim* tus cwj pwm tsis txaus ntseeg * hauv koj qhov kev zov me nyuam.
///
/// Ib qho piv txwv txog yam uas tsis xav ua thiab qhov no cuam tshuam dab tsi rau `write_unaligned` yog:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Ntawm no peb sim mus coj qhov chaw nyob ntawm 32-ntsis tus lej zauv uas tsis sib thooj.
///     let unaligned =
///         // Ib ntus uas tsis tau lees paub yog tsim nyob rau ntawm no uas ua rau muaj tus cwj pwm tsis tau txiav txim siab tsis hais seb qhov siv raug siv los tsis siv.
/////
///         &mut packed.unaligned
///         // Caw rau tus pointer nyoos tsis pab;tus txhaum ces tshwm sim.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Kev nkag mus rau cov teb uas tsis tau txiav txim ncaj qha nrog piv txwv li `packed.unaligned` tseem muaj kev ruaj ntseg tab sis.
///
///
///
///
///
///
///
///
///
// FIXME: Hloov kho cov ntaub ntawv raws li kev tshwm sim ntawm RFC #2582 thiab cov phooj ywg.
/// # Examples
///
/// Sau tus nqi usize rau tus byte tsis:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // KEV RUAJ NTSEG: tus neeg hu yuav tsum lav tias `dst` yog qhov siv tau rau kev sau ntawv.
    // `dst` tsis tuaj yeem `src` vim tias tus hu tuaj yeem hloov mus rau `dst` thaum `src` yog los ntawm txoj haujlwm no.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Peb yuav hu mus ncaj qha rau kom tsis txhob muaj nuj nqi hu nyob rau hauv cov lej generated.
        intrinsics::forget(src);
    }
}

/// Ua cov nyeem zoo li nthe ntawm qhov muaj nqis los ntawm `src` tsis tsiv nws.Qhov no tawm lub cim xeeb hauv `src` tsis hloov pauv.
///
/// Cov haujlwm ruaj khov yog npaj los ua ntawm I/O lub cim xeeb, thiab tau lees tias yuav tsum tsis txhob elided los yog reordered los ntawm cov compiler hla lwm cov kev ua haujlwm tsis huv.
///
/// # Notes
///
/// Rust tsis tam sim no muaj ib tug rigorously thiab kev lig kev cai hais tseg nco qauv, li ntawd, leej semantics ntawm dab tsi "volatile" txhais tau tias ntawm no yog kev kawm mus rau kev hloov lub sij hawm.
/// Qhov ntawd tau hais, lub semantics yuav luag txhua lub sijhawm zoo li [C11's definition of volatile][c11] zoo nkauj.
///
/// Lub compiler yuav tsum tsis hloov pauv qhov txheeb ze lossis tus lej ntawm cov haujlwm ntuag ib qho chaw ntuag.
/// Txawm li cas los xij, cov teeb meem ntog ua haujlwm ntawm cov xoom hom (piv txwv li, yog hais tias ib lub xoom hom xa mus rau `read_volatile`) yog noops thiab tej zaum yuav tsis quav ntsej.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Tus cwj pwm yog undefined yog ib yam ntawm cov nram qab no tej yam kev mob yog ua txhaum:
///
/// * `src` yuav tsum yog [valid] rau kev nyeem.
///
/// * `src` yuav tsum muaj kev sib thooj.
///
/// * `src` yuav tsum taw rau qhov pib tsim nyog ntawm hom `T`.
///
/// Zoo li [`read`], `read_volatile` tsim cov ntawv luam ntawm `T`, txawm tias `T` yog [`Copy`].
/// Yog `T` tsis yog [`Copy`], siv ob qho tib si xa rov qab thiab tus nqi ntawm `*src` tuaj yeem [violate memory safety][read-ownership].
/// Txawm li cas los xij, khaws cia cov tsis-[`Luam Ntawv '] hom hauv lub cim xeeb tsis tshua meej yog qhov yuav luag tsis raug.
///
/// Nco ntsoov tias txawm tias `T` muaj qhov loj `0`, lub pointer yuav tsum tsis yog-NULL thiab ua raws li cov ntawv cog lus.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Ib yam li hauv C, txawm hais tias lub sijhawm ua haujlwm tsis hloov pauv tsis muaj tus kabmob rau cov lus nug ntsig txog cov khoom nkag los ntawm ntau cov xov.Cov neeg tsis paub tab nkag siab coj zoo ib yam li cov tsis muaj atomic nkag hauv qhov ntawd.
///
/// Nyob rau hauv kev, ib haiv neeg ntawm ib tug `read_volatile` thiab tej sau lag luam rau tib qho chaw yog undefined tus cwj pwm.
///
/// # Examples
///
/// Kev siv theem pib:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Tsis panicking kom codegen feem me me.
        abort();
    }
    // KEV RUAJ NTSEG: tus neeg hu yuav tsum khaws daim ntawv cog lus muaj kev nyab xeeb rau `volatile_load`.
    unsafe { intrinsics::volatile_load(src) }
}

/// Ua qhov nrov tsis meej ntawm sau lub cim xeeb qhov chaw nrog muab tus nqi yam tsis tau nyeem lossis poob tus nqi qub.
///
/// Cov haujlwm ruaj khov yog npaj los ua ntawm I/O lub cim xeeb, thiab tau lees tias yuav tsum tsis txhob elided los yog reordered los ntawm cov compiler hla lwm cov kev ua haujlwm tsis huv.
///
/// `write_volatile` tsis tso cov ntsiab lus ntawm `dst`.Qhov no muaj kev nyab xeeb, tab sis nws tuaj yeem xau cov nyiaj los sis cov peev txheej, yog li kev saib xyuas yuav tsum tsis txhob saib xyuas ib qho khoom uas yuav tsum tau ua poob.
///
/// Tsis tas li ntawd, nws tsis poob `src`.Semantically, `src` tau hloov mus rau hauv qhov chaw qhia mus rau `dst`.
///
/// # Notes
///
/// Rust tsis tam sim no muaj ib tug rigorously thiab kev lig kev cai hais tseg nco qauv, li ntawd, leej semantics ntawm dab tsi "volatile" txhais tau tias ntawm no yog kev kawm mus rau kev hloov lub sij hawm.
/// Qhov ntawd tau hais, lub semantics yuav luag txhua lub sijhawm zoo li [C11's definition of volatile][c11] zoo nkauj.
///
/// Lub compiler yuav tsum tsis hloov pauv qhov txheeb ze lossis tus lej ntawm cov haujlwm ntuag ib qho chaw ntuag.
/// Txawm li cas los xij, cov teeb meem ntog ua haujlwm ntawm cov xoom hom (piv txwv li, yog hais tias ib lub xoom hom xa mus rau `write_volatile`) yog noops thiab tej zaum yuav tsis quav ntsej.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Tus cwj pwm yog undefined yog ib yam ntawm cov nram qab no tej yam kev mob yog ua txhaum:
///
/// * `dst` yuav tsum yog [valid] rau sau.
///
/// * `dst` yuav tsum muaj kev sib thooj.
///
/// Nco ntsoov tias txawm tias `T` muaj qhov loj `0`, lub pointer yuav tsum tsis yog-NULL thiab ua raws li cov ntawv cog lus.
///
/// [valid]: self#safety
///
/// Ib yam li hauv C, txawm hais tias lub sijhawm ua haujlwm tsis hloov pauv tsis muaj tus kabmob rau cov lus nug ntsig txog cov khoom nkag los ntawm ntau cov xov.Cov neeg tsis paub tab nkag siab coj zoo ib yam li cov tsis muaj atomic nkag hauv qhov ntawd.
///
/// Tshwj xeeb, kev sib tw ntawm `write_volatile` thiab lwm cov kev ua haujlwm (nyeem ntawv lossis sau ntawv) rau tib qho chaw yog tus cwj pwm tsis tau xaiv.
///
/// # Examples
///
/// Kev siv theem pib:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Tsis panicking kom codegen feem me me.
        abort();
    }
    // KEV RUAJ NTSEG: tus neeg hu yuav tsum khaws daim ntawv cog lus muaj kev nyab xeeb rau `volatile_store`.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Dlhos pointer `p`.
///
/// Xam xam offset (saib raws cov ntsiab lus ntawm `stride` stride) uas yuav tsum tau siv mus rau pointer `p` kom pointer `p` yuav tau mus raws li `a`.
///
/// Note: Qhov kev siv no tau ua tib zoo txiav txim siab tsis yog panic.Nws yog UB rau qhov no rau panic.
/// Tsuas yog kev hloov pauv tiag tiag uas tuaj yeem ua tau ntawm no yog kev hloov ntawm `INV_TABLE_MOD_16` thiab cov kab sib txuam.
///
/// Yog tias peb tau txiav txim siab ua kom nws hu mus rau qhov tseeb nrog `a` uas tsis yog lub zog ntawm ob, nws yuav zaum ntau rau kev hloov pauv mus rau qhov kev siv tsis zoo, tsis yog sim hloov qhov no kom haum rau qhov kev hloov ntawd.
///
///
/// Muaj lus nug mus rau@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): Kev siv ncaj qha ntawm cov intrinsics txhim kho codegen hloov chaw ntawm qib-<<
    // 1, qhov twg tus qauv versions ntawm cov ua hauj lwm tsis inlined.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Xam cov lej ntau tus qauv ntawm `x` modulo `m`.
    ///
    /// Qhov kev siv no yog tsim nyog rau `align_offset` thiab tau ua raws li qhov ua ntej:
    ///
    /// * `m` yog lub zog-ntawm-ob;
    /// * `x < m`; (Yog tias `x ≥ m`, hla hauv `x % m` hloov)
    ///
    /// Kev ua raws li txoj haujlwm no yuav tsum tsis yog panic.Puas.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Txooj sauv ntau hom modular 2 inverse table modulo 2⁴=16.
        ///
        /// Nco ntsoov, tias cov lus no tsis muaj cov nuj nqis uas qhov ntxeev tsis muaj nyob (piv txwv li, rau `0⁻¹ mod 16`, `2⁻¹ mod 16`, thiab lwm yam)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Modulo rau cov uas lub `INV_TABLE_MOD_16` yog npaj.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // KEV RUAJ NTSEG: `m` yuav tsum muaj lub zog-ntawm-ob, yog li tsis xoom.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Peb tua kab "up" siv cov qauv hauv qab no:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // txog 2²ⁿ ≥ m.Tom qab ntawd peb tuaj yeem txo qhov peb xav tau `m` los ntawm kev noj cov txiaj ntsig `mod m`.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // Nco ntsoov, tias peb siv cov haujlwm ntim ntawm no txhob txwm-cov qauv qub siv piv txwv li, rho `mod n`.
                // Nws tseem zoo ua lawv `mod usize::MAX` xwb, vim peb coj tus `mod n` kawg ua rau thaum kawg.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // KEV RUAJ NTSEG: `a` yog lub zog-ntawm-ob, yog li ntawd tsis xoom.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` rooj plaub tuaj yeem xaj ntau yooj yim los ntawm `-p (mod a)`, tab sis ua li ntawd inhibits LLVM lub peev xwm los xaiv cov lus qhia xws li `lea`.Hloov chaw peb suav
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // uas faib cov haujlwm ib ncig ntawm lub nra-cov kabmob, tab sis pessimizing `and` txaus rau LLVM kom muaj peev xwm siv ntau yam kev ua tau zoo nws paub txog.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Txheej Txheem Ua Ntej.Yij!
        return 0;
    } else if stride == 0 {
        // Yog tias tus pointer tsis sib txig, thiab cov khoom xoom yog lub xoom, yog li tsis muaj cov ntsiab lus ib txwm ib txwm ua tiav ntawm tus pointer.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // KEV RUAJ NTSEG: a zog-ntawm-ob li no tsis xoom.stride==0 rooj plaub yog hais los saum toj no.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // KEV RUAJ NTSEG: gcdpow muaj qaum-ntau qhov uas nyob ntawm ntau tus lej ntawm ib qho usize.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // KEV RUAJ NTSEG: gcd yog ib txwm ntau dua los yog sib npaug rau 1.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // Cov branch daws rau cov kab ke sib txig sib luag li nram no:
        //
        // ` p + so = 0 mod a `
        //
        // `p` ntawm no yog tus pointer nqi, `s`, kab ntawm `T`, `o` offset hauv `T`s, thiab `a`, kab ke thov.
        //
        // Nrog `g = gcd(a, s)`, thiab cov xwm txheej saum toj saud tias `p` tseem faib tau los ntawm `g`, peb tuaj yeem txhais tau `a' = a/g`, `s' = s/g`, `p' = p/g`, ces qhov no dhau los ua kom sib npaug:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // Thawj lo lus yog "the relative alignment of `p` to `a`" (muab faib los ntawm `g`), lub sij hawm ob yog "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (rov faib dua `g`).
        //
        // Kev faib los ntawm `g` yog qhov tsim nyog los ua kom qhov kev ua kom zoo yog tias `a` thiab `s` tsis muaj kev sib koom ua ke.
        //
        // Tsis tas li ntawd, qhov tshwm sim los ntawm cov tshuaj no tsis yog "minimal", li ntawd, nws yog tsim nyog los noj cov `o mod lcm(s, a)`.Peb tuaj yeem hloov `lcm(s, a)` nrog tsuas yog `a'`.
        //
        //
        //
        //
        //

        // KEV RUAJ NTSEG: `gcdpow` muaj qhov sib tw sab saud tsis ntau dua tus naj npawb ntawm cov ntawv sau 0-nyob hauv `a`.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // KEV RUAJ NTSEG: `a2` tsis yog xoom.Hloov `a` los ntawm `gcdpow` tsis tuaj yeem hloov tawm ntawm ib qho ntawm cov teeb me me
        // hauv `a` (ntawm qhov nws muaj ib qho).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // KEV RUAJ NTSEG: `gcdpow` muaj qhov sib tw sab saud tsis ntau dua tus naj npawb ntawm cov ntawv sau 0-nyob hauv `a`.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // KEV RUAJ NTSEG: `gcdpow` muaj qhov sib txawv sab saud tsis ntau dua tus naj npawb ntawm cov cim kab 0-kab hauv
        // `a`.
        // Tsis tas li ntawd, qhov sib rho tsis tau phwj, vim hais tias `a2 = a >> gcdpow` yeej yuav nruj me ntsis ntau tshaj li `(p % a) >> gcdpow`.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // KEV RUAJ NTSEG: `a2` yog lub zog-ntawm-ob, raws li muaj pov thawj saum toj no.`s2` yog nruj me ntsis tsawg dua `a2`
        // vim `(s % a) >> gcdpow` tsawg dua `a >> gcdpow`.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Tsis tuaj yeem sib thooj txhua.
    usize::MAX
}

/// Muab cov ntsiab lus nyoos coj los sib txig.
///
/// Qhov no yog tib yam li siv tus neeg teb xov tooj `==`, tab sis tsawg dua qhov tsis xws luag:
/// cov lus sib cav yuav tsum yog `*const T` tus taw tes nyoos, tsis yog txhua yam uas coj `PartialEq`.
///
/// Qhov no tuaj yeem siv los sib piv `&T` cov ntawv xa khoom (uas yuam rau `*const T` implicitly) los ntawm lawv qhov chaw nyob es tsis piv cov nqi uas lawv taw rau (uas yog qhov `PartialEq for &T` kev siv ua).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Cov hlais kuj tseem raug sib piv los ntawm lawv qhov ntev (rog cov rog):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Traits kuj tseem sib piv los ntawm lawv kev siv:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Cov lus qhia muaj qhov chaw nyob sib luag.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Cov khoom muaj cov chaw nyob sib luag, tab sis `Trait` muaj kev siv ntau yam.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Hloov cov ntawv xa mus rau `*const u8` sib piv los ntawm qhov chaw nyob.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Hash lub pointer nyoos.
///
/// Qhov no tuaj yeem siv rau hash `&T` X siv (uas yuam rau `*const T` implicitly) los ntawm nws qhov chaw nyob ntau dua li tus nqi nws taw rau (uas yog dab tsi `Hash for &T` kev siv ua).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Siv rau kev hais lus taw kev
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Nruab nrab nrum raws li usize yuav tsum muaj rau AVR
                // yog li ntawd qhov chaw nyob chaw ntawm tus pointer muaj nuj nqi yog khaws cia hauv qhov kawg kev ua haujlwm pointer.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Nruab nrab nrum raws li usize yuav tsum muaj rau AVR
                // yog li ntawd qhov chaw nyob chaw ntawm tus pointer muaj nuj nqi yog khaws cia hauv qhov kawg kev ua haujlwm pointer.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // Tsis muaj variadic haujlwm nrog 0 tsis
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Tsim ib tug `const` nyoos pointer rau ib qho chaw, tsis muaj tsim ib nrab siv.
///
/// Tsim kom muaj kev siv nrog `&`/`&mut` tsuas yog tso cai yog tias tus pointer raug raws li cov ntsiab lus thiab cov ntsiab lus rau thawj zaug cov ntaub ntawv.
/// Rau cov rooj plaub uas cov kev cai ntawd tsis tuav, cov taw tes nyoos yuav tsum tau siv.
/// Txawm li cas los xij, `&expr as *const _` tsim ib qho kev siv ua ntej nrum nws mus rau lub pointer nyoos, thiab cov ntaub ntawv ntawd yog raug rau tib cov cai ib yam li lwm cov ntawv xa.
///
/// Qhov no macro muaj peev xwm tsim ib tug nyoos pointer *tsis* tsim ib tug siv ua ntej.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` yuav tsim ib qho kev siv ncaj ncees, thiab yog li yuav tsum tsis txhob muaj tus cwj pwm!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Tsim `mut` lub pointer mus rau qhov chaw, tsis tas yuav tsim kev siv nruab nrab.
///
/// Tsim kom muaj kev siv nrog `&`/`&mut` tsuas yog tso cai yog tias tus pointer raug raws li cov ntsiab lus thiab cov ntsiab lus rau thawj zaug cov ntaub ntawv.
/// Rau cov rooj plaub uas cov kev cai ntawd tsis tuav, cov taw tes nyoos yuav tsum tau siv.
/// Txawm li cas los xij, `&mut expr as *mut _` tsim ib qho kev siv ua ntej nrum nws mus rau lub pointer nyoos, thiab cov ntaub ntawv ntawd yog raug rau tib cov cai ib yam li lwm cov ntawv pov thawj.
///
/// Qhov no macro muaj peev xwm tsim ib tug nyoos pointer *tsis* tsim ib tug siv ua ntej.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` yuav tsim ib qho kev siv ncaj ncees, thiab yog li yuav tsum tsis txhob muaj tus cwj pwm!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` yuam cov ntawv luam rau daim teb es tsis txhob tsim tus siv.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}