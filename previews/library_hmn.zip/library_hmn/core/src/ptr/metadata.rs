#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Muab cov pointer metadata hom ntawm qhov taw tes-rau hom.
///
/// # Tus taw tes metadata
///
/// Nyoo pointer hom thiab siv hom nyob rau hauv Rust yuav xav txog li ua los ntawm ob tug qhov chaw:
/// cov ntaub ntawv taw qhia uas muaj lub cim xeeb chaw nyob ntawm tus nqi, thiab qee qhov metadata.
///
/// Txog cov xwm txheej loj (uas siv `Sized` traits) ntxiv rau `extern` hom, cov taw tes tau hais tias tau "nyias": metadata yog xoom-qhov loj thiab nws hom yog `()`.
///
///
/// Qhov taw qhia rau [dynamically-sized types][dst] tau hais tias "dav" lossis "rog", lawv tsis muaj metadata tsis-xoom-me me:
///
/// * Txog cov qauv uas nws daim teb kawg yog DST, metadata yog metadata rau daim teb kawg
/// * Rau `str` hom, metadata yog qhov ntev hauv bytes li `usize`
/// * Rau cov hlais hom zoo li `[T]`, metadata yog qhov ntev hauv cov khoom raws li `usize`
/// * Rau trait cov khoom zoo li `dyn SomeTrait`, metadata yog [`DynMetadata<Self>`][DynMetadata] (piv txwv li `DynMetadata<dyn SomeTrait>`)
///
/// Hauv future, Rust cov lus yuav tau txais cov hom tshiab uas muaj qhov sib txawv ntawm pointer metadata.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # Lub `Pointee` trait
///
/// Cov ntsiab lus ntawm no trait yog nws `Metadata` hom yam, uas yog `()` lossis `usize` lossis `DynMetadata<_>` raws li tau piav saum toj no.
/// Nws yog nws cia li ua tiav txhua yam.
/// Nws tuaj yeem xav tias tau nqis tes ua hauv cov ntsiab lus tsis tseem ceeb, txawm tias tsis muaj kab sib cuam tshuam.
///
/// # Usage
///
/// Cov ntsiab lus nyoos tuaj yeem ua rau cov ntaub ntawv chaw nyob thiab cov khoom siv metadata nrog lawv cov [`to_raw_parts`] txoj kev.
///
/// Xwb, metadata ib leeg tuaj yeem muab rho tawm nrog [`metadata`] qhov haujlwm.
/// Ib qho ntaub ntawv tuaj yeem xa mus rau [`metadata`] thiab kev xav muab sib xyaw.
///
/// Tus (possibly-wide) tus pointer tuaj yeem muab tso rov qab ua ke ntawm nws qhov chaw nyob thiab metadata nrog [`from_raw_parts`] lossis [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Hom rau metadata hauv pointers thiab xa mus rau `Self`.
    #[lang = "metadata_type"]
    // NOTE: Khaws trait bounds hauv `static_assert_expected_bounds_for_metadata`
    //
    // hauv `library/core/src/ptr/metadata.rs` hauv sync nrog cov ntawm no:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Cov taw tes rau hom kev siv trait cai no "nyias".
///
/// Qhov no suav nrog hom ntawv sau-xwm txheej tus qauv thiab `extern` hom.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: tsis txhob nyob twj ywm qhov no ua ntej trait aliases tseem ruaj khov hauv cov lus?
pub trait Thin = Pointee<Metadata = ()>;

/// Extract tus metadata tivthaiv ntawm ib tug pointer.
///
/// Cov txiaj ntsig ntawm hom `*mut T`, `&T`, lossis `&mut T` tuaj yeem dhau ncaj qha rau txoj haujlwm no raws li lawv tau cog lus ncaj qha rau `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // KEV RUAJ NTSEG: Nkag mus rau tus nqi los ntawm `PtrRepr` lub koomhaum muaj kev nyab xeeb txij li * const T
    // thiab PtrComponents<T>muaj cov cim xeeb txheej txheem tib yam.
    // Tsuas yog std tuaj yeem ua qhov kev lav no.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Cov ntawv xa (possibly-wide) X pointer nyoos los ntawm cov ntaub ntawv chaw nyob thiab metadata.
///
/// Txoj haujlwm no muaj kev nyab xeeb tab sis tus pointer xa rov qab tsis tas muaj kev nyab xeeb rau kev dereference.
/// Rau cov nplais, saib cov ntaub ntawv ntawm [`slice::from_raw_parts`] rau kev xav tau kev nyab xeeb.
/// Txog trait cov khoom, metadata yuav tsum los ntawm tus taw qhia mus rau tib hom hauv qab.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // KEV RUAJ NTSEG: Nkag mus rau tus nqi los ntawm `PtrRepr` lub koomhaum muaj kev nyab xeeb txij li * const T
    // thiab PtrComponents<T>muaj cov cim xeeb txheej txheem tib yam.
    // Tsuas yog std tuaj yeem ua qhov kev lav no.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Ua tib lub luag haujlwm zoo ib yam li [`from_raw_parts`], tshwj tsis yog tias `*mut` lub pointer xa rov qab, tsis zoo li tus `* const` pointer.
///
///
/// Saib cov ntaub ntawv ntawm [`from_raw_parts`] kom paub meej ntxiv.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // KEV RUAJ NTSEG: Nkag mus rau tus nqi los ntawm `PtrRepr` lub koomhaum muaj kev nyab xeeb txij li * const T
    // thiab PtrComponents<T>muaj cov cim xeeb txheej txheem tib yam.
    // Tsuas yog std tuaj yeem ua qhov kev lav no.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Phau ntawv impl xav tau kom tsis txhob `T: Copy` ua txhua yam.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Phau ntawv impl xav tau kom tsis txhob cuam tshuam `T: Clone` ua txhua yam.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Cov metadata rau `Dyn = dyn SomeTrait` trait yam khoom.
///
/// Nws yog tus taw qhia rau lub vtable (lub rooj hu virtual) uas sawv cev rau txhua cov ntaub ntawv tsim nyog los tswj cov qhob hom khaws cia sab hauv trait khoom.
/// Lub vtable notably nws muaj:
///
/// * hom loj
/// * hom kev kawm tuab si lug
/// * tus taw qhia rau hom `drop_in_place` impl (tej zaum yuav tsis muaj-op rau cov ntawv sau ua qub-)
/// * taw tes rau txhua txoj hauv kev rau hom kev siv ntawm trait
///
/// Nco ntsoov tias thawj peb yog tshwj xeeb vim hais tias lawv nyob nraum tsim nyog los faib, nco, thiab deallocate tej trait kwv.
///
/// Nws muaj peev xwm rau lub npe no qauv nrog hom parameter uas tsis yog `dyn` trait kwv (piv txwv li `DynMetadata<u64>`) tab sis tsis yog kom tau txais txiaj ntsig zoo ntawm tus qauv ntawd.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Qhov uas siv ua ntej ntawm txhua vtables.Nws yog ua raws li kev ua haujlwm taw tes rau trait cov hau kev.
///
/// Cov kev siv ntawm kev nthuav dav ntawm `DynMetadata::size_of` thiab lwm yam
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Rov qab los qhov luaj li cas ntawm hom txuam nrog vtable no.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Rov qab muab cov kev hloov pauv ntawm hom uas cuam tshuam nrog daim ntawv no.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Rov qab rau qhov loj me thiab cov kab ke ua ke ua ib lub `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // KEV RUAJ NTSEG: tus kwv tso tawm emitted cov lus no rau ib qhob Rust yam uas
        // puas paub muaj txheej txheem siv tau.Tus cim aws ib yam li hauv `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Los ntawm txhais tes impls xav tau kom tsis txhob muaj kab `Dyn: $Trait`.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}