use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Cov ntaub qhwv ib ncig ntawm cov nqaij nyoos tsis-null `*mut T` uas qhia tau hais tias tus tswv ntawm qhov qhwv no yog tus tswv cuab.
/// Pab tau rau lub tsev tsis yooj yim xws li `Box<T>`, `Vec<T>`, `String`, thiab `HashMap<K, V>`.
///
/// Tsis zoo li `*mut T`, `Unique<T>` behaves "as if" nws yog ib tug piv txwv ntawm `T`.
/// Nws suav `Send`/`Sync` yog `T` yog `Send`/`Sync`.
/// Nws kuj implies hom zoo aliasing guarantees tus piv txwv ntawm `T` tuaj yeem cia siab tias:
/// kev xa tawm ntawm tus taw tes yuav tsum tsis txhob hloov kho uas tsis muaj txoj kev tshwj xeeb rau nws tus kheej tshwj xeeb.
///
/// Yog tias koj tsis paub tseeb seb nws puas siv tau `Unique` rau koj cov laj thawj, xav txog kev siv `NonNull`, uas muaj qhov tsis muaj zog.
///
///
/// Tsis zoo li `*mut T`, lub pointer yuav tsum nco ntsoov yuav tsis-thov, txawm yog hais tias tus pointer yog tsis dereferenced.
/// Qhov no yog kom cov enums yuav siv tus nqi txwv tsis pub muaj kev sib cais-`Option<Unique<T>>` muaj qhov loj tib yam li `Unique<T>`.
/// Txawm li cas los tus taw qhia kuj tseem dai kom zoo yog tias nws tsis dereferenced.
///
/// Tsis zoo li `*mut T`, `Unique<T>` yog covariant tshaj `T`.
/// Qhov no yuav tsum yog qhov tseeb rau txhua hom uas ua raws li Unique kev cai tus cai.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: no marker twb tsis muaj txim rau variance, tab sis yog tsim nyog
    // rau kev xa me me kom nkag siab tias peb txhim kho tus kheej yog `T`.
    //
    // Kom paub meej, saib:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` pointers yog `Send` yog `T` yog `Send` vim hais tias cov ntaub ntawv lawv reference yog unaliased.
/// Nco ntsoov tias qhov no aliasing invariant yog unenforced los ntawm hom system;cov kev tsis siv lub `Unique` yuav tsum tswj nws.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` cov taw tes yog `Sync` yog `T` yog `Sync` vim tias cov ntaub ntawv lawv siv tsis muaj npe.
/// Nco ntsoov tias qhov no aliasing invariant yog unenforced los ntawm hom system;cov kev tsis siv lub `Unique` yuav tsum tswj nws.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Tsim tus `Unique` tshiab uas tau dai caj dab, tab sis cov khoom siv kom zoo.
    ///
    /// Qhov no yog qhov pab tau rau kev pib cov hom uas yuav muab cov tsis nkag siab, zoo li `Vec::new`.
    ///
    /// Nco ntsoov tias tus pointer tus nqi yuav tuaj yeem sawv cev ntawm lub pointer siv tau rau `T`, uas txhais tau tias qhov no yuav tsum tsis txhob siv los ua tus nqi "not yet initialized" tus nqi xa mus.
    /// Cov hom uas lazily faib yuav tsum taug qab pib los ntawm lwm yam kev txhais tau tias.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // KEV RUAJ NTSEG: mem::align_of() xa rov qab siv tau, tsis yog-tsis muaj pointer.Tus
        // tej yam mob hu rau new_unchecked() yog li hwm.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Tsim dua tshiab `Unique`.
    ///
    /// # Safety
    ///
    /// `ptr` yuav tsum yog non-null.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // KEV RUAJ NTSEG: tus hu tuaj yuav tsum lav tias `ptr` tsis yog-tus.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Tsim tus tshiab `Unique` yog `ptr` yog qhov tsis yog.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // KEV RUAJ NTSEG: Lub pointer twb tau soj ntsuam thiab yog tsis thov.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Txais cov pib x00 X pointer.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Kev xa tawm cov ntsiab lus.
    ///
    /// Lub neej tau ua txhua yam rau tus kheej yog li qhov no mloog "as if" nws tau ua piv txwv ntawm T uas tau txais qiv.
    /// Yog tias xav tau ntev (unbound) lub neej ntev, siv `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // KEV RUAJ NTSEG: tus neeg hu yuav tsum lav tias `self` ntsib txhua tus
        // yuav tsum muaj rau kev siv.
        unsafe { &*self.as_ptr() }
    }

    /// Kev sib nkag siab cov ntsiab lus.
    ///
    /// Lub neej tau ua txhua yam rau tus kheej yog li qhov no mloog "as if" nws tau ua piv txwv ntawm T uas tau txais qiv.
    /// Yog tias xav tau ntev (unbound) lub neej ntev, siv `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // KEV RUAJ NTSEG: tus neeg hu yuav tsum lav tias `self` ntsib txhua tus
        // uas yuav tsum muaj rau kev siv tau kev hloov pauv.
        unsafe { &mut *self.as_ptr() }
    }

    /// Nrum rau lub pointer ntawm lwm hom.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // KEV RUAJ NTSEG: Unique::new_unchecked() tsim lub cim tshiab thiab kev xav tau
        // cov pointer uas muab los tsis thov.
        // Vim tias peb dhau tus kheej ua tus taw tes, nws tsis tuaj yeem thov.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // KEV RUAJ NTSEG: Qhov kev hloov pauv tsis tuaj yeem siv tsis tau
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}