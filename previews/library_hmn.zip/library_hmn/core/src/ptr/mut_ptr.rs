use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::slice::{self, SliceIndex};

#[lang = "mut_ptr"]
impl<T: ?Sized> *mut T {
    /// Rov qab `true` yog lub pointer tsis muaj.
    ///
    /// Nco ntsoov tias hom tsis muaj tseeb muaj ntau qhov ua tau thov taw, raws li tsuas yog cov ntaub ntawv raw cov pointer raug txiav txim, tsis yog lawv qhov ntev, vtable, thiab lwm yam.
    /// Yog li no, ob tus taw tes uas yog thov kuj tseem tsis tuaj yeem sib piv sib luag.
    ///
    /// ## Kev coj cwj pwm thaum soj ntsuam const
    ///
    /// Thaum txoj haujlwm no siv thaum ntsuas kev soj ntsuam, nws yuav rov qab `false` rau cov neeg taw tes uas tig tawm mus thov tom qab tsis pub tawm.
    /// Tshwj xeeb, thaum tus pointer rau qee lub cim xeeb yog qhov pab txhawb dhau ntawm nws cov ciam nyob rau hauv txoj kev uas tus pointer raug tshem tawm, txoj haujlwm yuav tseem rov qab `false`.
    ///
    /// Nws tsis muaj txoj hauv kev rau CTFE kom paub txog txoj haujlwm ntawm lub cim xeeb tiag tiag, yog li peb tsis tuaj yeem qhia yog tias tus pointer tsis muaj dab tsi los yog tsis.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Sib piv ntawm cov cam khwb cia rau lub pointer nyias, yog li cov roj taw tes tsuas yog xav txog lawv qhov "data" feem rau tsis muaj dab tsi.
        //
        (self as *mut u8).guaranteed_eq(null_mut())
    }

    /// Nrum rau lub pointer ntawm lwm hom.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *mut U {
        self as _
    }

    /// Rho tawm ib (muaj peev xwm dav) tus pointer rau hauv yog qhov chaw nyob thiab metadata Cheebtsam.
    ///
    /// Lub pointer yuav tom qab reconstructed nrog [`from_raw_parts_mut`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*mut (), <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self))
    }

    /// Rov qab `None` yog tias tus pointer tsis zoo, lossis lwm tus xa rov qab siv nqe lus qhia rau tus nqi qhwv hauv `Some`.Yog hais tias tus nqi tej zaum yuav uninitialized, [`as_uninit_ref`] yuav tsum tau siv xwb.
    ///
    /// Rau tus sawv cev mutable pom [`as_mut`].
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    /// [`as_mut`]: #method.as_mut
    ///
    /// # Safety
    ///
    /// Thaum hu xov tooj rau hom no, koj yuav tsum xyuas kom meej tias *tog twg los tus pointer yog NULL* lossis * tag nrho cov hauv qab no yog qhov tseeb:
    ///
    /// * Tus taw tes yuav tsum tau ua kom haum txhua qhov.
    ///
    /// * Nws yuav tsum yog "dereferencable" hauv qhov kev txiav txim siab txhais hauv [the module documentation].
    ///
    /// * Tus taw qhia yuav tsum taw rau qhov pib ntawm `T`.
    ///
    /// * Koj yuav tsum tswj hwm Rust cov cai tswjfwm tsis zoo, txij li kev rov qab los ntawm `'a` lub neej yog kev xaiv thiab tsis tas yuav cuam tshuam qhov tseeb lub neej ntawm cov ntaub ntawv.
    ///   Tshwj xeeb, rau lub sijhawm ntawm lub neej no, lub cim xeeb lub ntsiab lus taw qhia kom tsis txhob muaj kev sib hloov (tshwj tsis yog sab hauv `UnsafeCell`).
    ///
    /// Qhov no siv tau txawm hais tias qhov txiaj ntsig ntawm hom no tsis siv!
    /// (Ib feem hais txog kev pib ua tiav tseem tsis tau muaj kev txiav txim siab tag nrho, tab sis txog thaum nws yog, tib txoj kev nyab xeeb tsuas yog los xyuas kom meej tias lawv yog qhov tseeb pib.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Tsis thov-kos version
    ///
    /// Yog tias koj paub tseeb tias tus pointer tsis tuaj yeem null thiab tab tom nrhiav rau qee yam `as_ref_unchecked` uas xa rov qab `&T` hloov `Option<&T>`, paub tias koj tuaj yeem dereference lub pointer ncaj qha.
    ///
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // KEV RUAJ NTSEG: tus neeg hu yuav tsum lav tias `self` siv tau rau a
        // siv yog tias nws tsis yog thov.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Rov qab `None` yog tias tus pointer tsis zoo, lossis lwm tus xa rov qab siv nqe lus qhia rau tus nqi qhwv hauv `Some`.
    /// Hauv kev sib piv rau [`as_ref`], qhov no tsis tas tias tus nqi yuav tsum tau pib.
    ///
    /// Rau tus sawv cev mutable pom [`as_uninit_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    ///
    /// # Safety
    ///
    /// Thaum hu xov tooj rau hom no, koj yuav tsum xyuas kom meej tias *tog twg los tus pointer yog NULL* lossis * tag nrho cov hauv qab no yog qhov tseeb:
    ///
    /// * Tus taw tes yuav tsum tau ua kom haum txhua qhov.
    ///
    /// * Nws yuav tsum yog "dereferencable" hauv qhov kev txiav txim siab txhais hauv [the module documentation].
    ///
    /// * Koj yuav tsum tswj hwm Rust cov cai tswjfwm tsis zoo, txij li kev rov qab los ntawm `'a` lub neej yog kev xaiv thiab tsis tas yuav cuam tshuam qhov tseeb lub neej ntawm cov ntaub ntawv.
    ///
    ///   Tshwj xeeb, rau lub sijhawm ntawm lub neej no, lub cim xeeb lub ntsiab lus taw qhia kom tsis txhob muaj kev sib hloov (tshwj tsis yog sab hauv `UnsafeCell`).
    ///
    /// Qhov no siv tau txawm hais tias qhov txiaj ntsig ntawm hom no tsis siv!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // KEV RUAJ NTSEG: tus neeg hu yuav tsum lav tias `self` ntsib txhua tus
        // yuav tsum muaj rau kev siv.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Laij cov offset los ntawm ib lub pointer.
    ///
    /// `count` yog nyob rau hauv cov chav nyob ntawm T;piv txwv li, `count` ntawm 3 sawv cev rau pointer offset ntawm `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Yog hais tias ib yam ntawm cov nram qab no tej yam kev mob yog ua txhaum, qhov tshwm sim yog undefined cwj pwm:
    ///
    /// * Ob qhov pib thiab tshwm sim tus pointer yuav tsum nyob hauv kab lossis ib qho byte dhau los ntawm qhov kawg ntawm cov khoom sib txig tib yam.
    /// Nco ntsoov tias hauv Rust, txhua txhua (stack-allocated) qhov sib txawv yog suav hais tias yog cais cov khoom tau sib txawv.
    ///
    /// * Cov xam rho tawm,**hauv bytes**, tsis tuaj yeem dhau `isize`.
    ///
    /// * Qhov offset nyob hauv ciam tsis tuaj yeem cuam tshuam "wrapping around" chaw nyob.Ntawd yog, qhov tsis paub meej tshaj plaws suav-zaum,**hauv bytes** yuav tsum haum rau hauv usize.
    ///
    /// Lub compiler thiab lub tsev qiv ntawv txheem feem ntau sim ua kom paub tseeb tias cov kev faib yeej tsis ncav qhov loj me uas qhov kev daws txhaum yog qhov kev txhawj xeeb.
    /// Piv txwv li, `Vec` thiab `Box` kom lawv tsis txhob faib ntau dua `isize::MAX` bytes, yog li `vec.as_ptr().add(vec.len())` yog qhov muaj kev nyab xeeb tas mus li.
    ///
    /// Feem ntau cov hauv paus ntsiab lus tsis tuaj yeem txawm tias txhim tsa kev faib tawm no.
    /// Piv txwv li, tsis paub qhov 64-ntsis platform tuaj yeem ua haujlwm thov rau 2 <sup>63</sup> bytes vim los ntawm nplooj ntawv cov lus txwv lossis cais cov chaw nyob.
    /// Txawm li cas los xij, qee qhov 32-ntsis thiab 16-ntsis platform yuav ua tiav zoo thov rau ntau dua `isize::MAX` bytes nrog rau cov khoom xws li Lub Cev Chaw Txuas Lus.
    ///
    /// Xws li, lub cim xeeb kis tau ncaj qha los ntawm cov muab faib lossis cov ntaub ntawv nco mapped *yuav* loj dhau los ua nrog txoj haujlwm no.
    ///
    /// Xav txog kev siv [`wrapping_offset`] hloov yog tias cov kev txwv no nyuaj rau kev txaus siab.
    /// Qhov zoo dua ntawm cov qauv no yog tias nws ua kom nruj dua compiler optimizations.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1));
    ///     println!("{}", *ptr.offset(2));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // KEV RUAJ NTSEG: tus neeg hu yuav tsum khaws daim ntawv cog lus muaj kev nyab xeeb rau `offset`.
        // Lub pointer uas siv tau yog siv tau rau kev sau txij li tus neeg hu yuav tsum tau lees tias nws taw rau cov khoom tib yam li `self`.
        //
        unsafe { intrinsics::offset(self, count) as *mut T }
    }

    /// Laij cov offset los ntawm ib lub pointer uas siv qhwv cov lej laij zauv.
    /// `count` yog nyob rau hauv cov chav nyob ntawm T;piv txwv li, `count` ntawm 3 sawv cev rau pointer offset ntawm `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Qhov haujlwm no nws tus kheej ib txwm muaj kev nyab xeeb, tab sis kev siv tus pointer tawm tsis yog.
    ///
    /// Lub pointer resulting tseem txuas rau cov kwv tseg tib yam uas `self` cov ntsiab lus rau.
    /// Nws yuav *tsis* siv tau nkag mus rau qhov sib txawv sib txawv.Nco ntsoov tias hauv Rust, txhua txhua (stack-allocated) qhov sib txawv yog suav hais tias yog cais cov khoom tau sib txawv.
    ///
    /// Hauv lwm lo lus, `let z = x.wrapping_offset((y as isize) - (x as isize))` tsis *tsis* ua `z` zoo ib yam li `y` txawm tias peb xav tias `T` muaj qhov loj me `1` thiab tsis muaj dej ntws ntau: `z` tseem txuas rau tus kwv `x` txuas rau, thiab dereferencing nws yog Undefined Cwj pwm tshwj tsis yog `x` thiab `y` taw tes rau hauv cov khoom sib txig tib yam.
    ///
    /// Piv rau [`offset`], txoj kev no cia li ncua txoj kev tseev kom muaj nyob hauv tib lub hom phiaj: [`offset`] tam sim ntawd tus cwj pwm tsis tseem ceeb thaum hla ciam ciam chaw;`wrapping_offset` tsim tawm tus pointer tab sis tseem ua rau Undefined Kev coj cwj pwm yog tias tus pointer tsis zoo thaum nws tawm ntawm-ntawm-qhov khoom ntawm nws tau txuas rau.
    /// [`offset`] tuaj yeem pom zoo kom zoo dua thiab yog li xaiv tau nyob hauv qhov kev ua tau zoo-keej code.
    ///
    /// Qhov kev kuaj xyuas qeeb tsuas yog txiav txim siab tus nqi ntawm lub pointer uas tau dereferenced, tsis yog cov txiaj ntsig nruab nrab siv thaum lub sijhawm suav sau ntawm qhov txiaj ntsig kawg.
    /// Piv txwv li, `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` yog qhov tseem ceeb tib yam li `x`.Hauv lwm lo lus, tawm ntawm qhov khoom tau muab faib thiab tom qab ntawd rov nkag mus rau nws tom qab raug tso cai.
    ///
    /// Yog tias koj xav hla cov ciam ciam av, nrum lub pointer rau ib tus lej thiab ua tus lej nyob rau ntawd.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// // Siv cov pointer nyoos hauv kev nce ntawm ob qho
    /// let mut data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *mut u8 = data.as_mut_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         *ptr = 0;
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// assert_eq!(&data, &[0, 2, 0, 4, 0]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // KEV RUAJ NTSEG: `arith_offset` qhov tseem ceeb tsis muaj qhov yuav tsum tau ua kom tau hu.
        unsafe { intrinsics::arith_offset(self, count) as *mut T }
    }

    /// Rov qab `None` yog tias tus pointer tsis zoo, lossis lwm tus xa rov qab nws cov lus siv rau tus nqi qhwv hauv `Some`.Yog tias tus nqi yuav tsis ua tiav, [`as_uninit_mut`] yuav tsum tau siv.
    ///
    /// Rau cov sib koom tes xyuas saib [`as_ref`].
    ///
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    /// [`as_ref`]: #method.as_ref-1
    ///
    /// # Safety
    ///
    /// Thaum hu xov tooj rau hom no, koj yuav tsum xyuas kom meej tias *tog twg los tus pointer yog NULL* lossis * tag nrho cov hauv qab no yog qhov tseeb:
    ///
    /// * Tus taw tes yuav tsum tau ua kom haum txhua qhov.
    ///
    /// * Nws yuav tsum yog "dereferencable" hauv qhov kev txiav txim siab txhais hauv [the module documentation].
    ///
    /// * Tus taw qhia yuav tsum taw rau qhov pib ntawm `T`.
    ///
    /// * Koj yuav tsum tswj hwm Rust cov cai tswjfwm tsis zoo, txij li kev rov qab los ntawm `'a` lub neej yog kev xaiv thiab tsis tas yuav cuam tshuam qhov tseeb lub neej ntawm cov ntaub ntawv.
    ///   Tshwj xeeb, rau lub sijhawm rau lub neej no, lub cim xeeb lub ntsiab lus taw qhia kom tsis txhob nkag (nyeem lossis sau ntawv) los ntawm lwm lub pointer.
    ///
    /// Qhov no siv tau txawm hais tias qhov txiaj ntsig ntawm hom no tsis siv!
    /// (Ib feem hais txog kev pib ua tiav tseem tsis tau muaj kev txiav txim siab tag nrho, tab sis txog thaum nws yog, tib txoj kev nyab xeeb tsuas yog los xyuas kom meej tias lawv yog qhov tseeb pib.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { ptr.as_mut().unwrap() };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Nws mam luam: "[4, 2, 3]".
    /// ```
    ///
    /// # Tsis thov-kos version
    ///
    /// Yog tias koj paub tseeb tias tus pointer tsis tuaj yeem null thiab tab tom nrhiav rau qee yam `as_mut_unchecked` uas xa rov qab `&mut T` hloov `Option<&mut T>`, paub tias koj tuaj yeem dereference lub pointer ncaj qha.
    ///
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { &mut *ptr };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Nws mam luam: "[4, 2, 3]".
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_mut<'a>(self) -> Option<&'a mut T> {
        // KEV RUAJ NTSEG: tus neeg hu yuav tsum lav tias `self` siv tau rau
        // siv tau yog hais tias nws tsis yog thov.
        if self.is_null() { None } else { unsafe { Some(&mut *self) } }
    }

    /// Rov qab `None` yog tias tus pointer tsis zoo, lossis lwm tus xa rov qab siv nws tus kheej rau tus nqi qhwv hauv `Some`.
    /// Hauv kev sib piv rau [`as_mut`], qhov no tsis tas tias tus nqi yuav tsum tau pib.
    ///
    /// Rau cov sib koom tes xyuas saib [`as_uninit_ref`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    ///
    /// # Safety
    ///
    /// Thaum hu xov tooj rau hom no, koj yuav tsum xyuas kom meej tias *tog twg los tus pointer yog NULL* lossis * tag nrho cov hauv qab no yog qhov tseeb:
    ///
    /// * Tus taw tes yuav tsum tau ua kom haum txhua qhov.
    ///
    /// * Nws yuav tsum yog "dereferencable" hauv qhov kev txiav txim siab txhais hauv [the module documentation].
    ///
    /// * Koj yuav tsum tswj hwm Rust cov cai tswjfwm tsis zoo, txij li kev rov qab los ntawm `'a` lub neej yog kev xaiv thiab tsis tas yuav cuam tshuam qhov tseeb lub neej ntawm cov ntaub ntawv.
    ///
    ///   Tshwj xeeb, rau lub sijhawm rau lub neej no, lub cim xeeb lub ntsiab lus taw qhia kom tsis txhob nkag (nyeem lossis sau ntawv) los ntawm lwm lub pointer.
    ///
    /// Qhov no siv tau txawm hais tias qhov txiaj ntsig ntawm hom no tsis siv!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut<'a>(self) -> Option<&'a mut MaybeUninit<T>>
    where
        T: Sized,
    {
        // KEV RUAJ NTSEG: tus neeg hu yuav tsum lav tias `self` ntsib txhua tus
        // yuav tsum muaj rau kev siv.
        if self.is_null() { None } else { Some(unsafe { &mut *(self as *mut MaybeUninit<T>) }) }
    }

    /// Rov qab los txawm tias ob kis tau lees tias yog sib npaug.
    ///
    /// Thaum runtime txoj haujlwm no coj zoo li `self == other`.
    /// Txawm li cas los xij, hauv qee qhov kev sib tham (xws li, sib piv-lub sijhawm ntsuas), nws tsis yog ib txwm ua tau los txiav txim siab sib luag ntawm ob tus taw tes, yog li txoj haujlwm no tej zaum yuav rov qab sai dua `false` rau cov neeg taw qhia uas tom qab ntawd tiag tig los ua kom sib npaug.
    ///
    /// Tab sis thaum nws rov `true`, lub pointers yog guaranteed yuav sib npaug zos.
    ///
    /// Txoj haujlwm no yog daim iav ntawm [`guaranteed_ne`], tab sis tsis yog nws qhov ntxeev.Muaj cov pointer piv rau cov uas ob qho dej num rov `false`.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// Tus nqi xa rov qab tuaj yeem hloov pauv nyob ntawm qhov tsim ntawm tus lej tsim thiab kev nyab xeeb tsis zoo yuav tsis cia siab rau qhov txiaj ntsig ntawm qhov haujlwm no rau lub suab.
    /// Nws pom zoo kom tsuas yog siv txoj haujlwm no rau qhov kev ua tau zoo ntxiv qhov twg zoo nkauj `false` rov qab qhov tseem ceeb los ntawm txoj haujlwm no tsis cuam tshuam rau qhov tshwm sim, tab sis tsuas yog qhov kev ua tau zoo.
    /// Qhov tshwm sim ntawm kev siv hom qauv no los ua kom muaj lub sijhawm rhais thiab sib sau-lub sijhawm coj tus cwj pwm txawv tsis tau tshawb nrhiav.
    /// Txoj kev no yuav tsum tsis txhob siv los qhia qhov sib txawv ntawm qhov sib txawv, thiab nws yuav tsum tsis tas yuav tsum ruaj khov ua ntej peb muaj kev nkag siab zoo txog qhov teeb meem no.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self as *const _, other as *const _)
    }

    /// Rov qab los txawm hais tias ob tus taw tes yog qhov lees tias yuav tsis sib luag.
    ///
    /// Thaum runtime txoj haujlwm no coj zoo li `self != other`.
    /// Txawm li cas los xij, hauv qee qhov kev sib tham (xws li, ntsuas lub sijhawm ntsuas), nws tsis yog ib txwm ua tau los txiav txim siab qhov tsis sib xws ntawm ob tus taw tes, yog li qhov haujlwm no yuav ua rau rov qab sai dua `false` rau cov taw tes uas tom qab ntawd tiag tig tawm qhov tsis sib xws.
    ///
    /// Tab sis thaum nws rov `true`, cov taw tes tau lees tias yog qhov tsis sib xws.
    ///
    /// Txoj haujlwm no yog daim iav ntawm [`guaranteed_eq`], tab sis tsis yog nws qhov ntxeev.Muaj pointer sib piv rau cov uas ob leeg zog rov qab `false`.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// Tus nqi xa rov qab tuaj yeem hloov pauv nyob ntawm qhov tsim ntawm tus lej tsim thiab kev nyab xeeb tsis zoo yuav tsis cia siab rau qhov txiaj ntsig ntawm qhov haujlwm no rau lub suab.
    /// Nws pom zoo kom tsuas yog siv txoj haujlwm no rau qhov kev ua tau zoo ntxiv qhov twg zoo nkauj `false` rov qab qhov tseem ceeb los ntawm txoj haujlwm no tsis cuam tshuam rau qhov tshwm sim, tab sis tsuas yog qhov kev ua tau zoo.
    /// Qhov tshwm sim ntawm kev siv hom qauv no los ua kom muaj lub sijhawm rhais thiab sib sau-lub sijhawm coj tus cwj pwm txawv tsis tau tshawb nrhiav.
    /// Txoj kev no yuav tsum tsis txhob siv los qhia qhov sib txawv ntawm qhov sib txawv, thiab nws yuav tsum tsis tas yuav tsum ruaj khov ua ntej peb muaj kev nkag siab zoo txog qhov teeb meem no.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const unsafe fn guaranteed_ne(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self as *const _, other as *const _)
    }

    /// Laij cov nrug ntawm ob tus kis.Cov rov qab nqi yog nyob rau hauv cov chav nyob ntawm T: qhov kev ncua deb nyob rau hauv bytes yog muab faib los ntawm `mem::size_of::<T>()`.
    ///
    /// Txoj haujlwm no yog qhov ntxeev ntawm [`offset`].
    ///
    /// [`offset`]: #method.offset-1
    ///
    /// # Safety
    ///
    /// Yog hais tias ib yam ntawm cov nram qab no tej yam kev mob yog ua txhaum, qhov tshwm sim yog undefined cwj pwm:
    ///
    /// * Ob qhov pib thiab lwm lub pointer yuav tsum nyob hauv ib qho chaw lossis ib qho byte yav dhau los xaus rau cov khoom siv tib lub.
    /// Nco ntsoov tias hauv Rust, txhua txhua (stack-allocated) qhov sib txawv yog suav hais tias yog cais cov khoom tau sib txawv.
    ///
    /// * Ob pointers yuav tsum tau *derived ntawm* ib pointer mus rau tib yam twj paj nruas.
    ///   (Saib hauv qab rau qhov piv txwv.)
    ///
    /// * Qhov kev ncua deb ntawm cov taw tes, nyob rau hauv bytes, yuav tsum muaj ntau qhov sib txawv ntawm qhov loj me ntawm `T`.
    ///
    /// * Qhov kev ncua deb ntawm tus taw tes,**hauv bytes**, tsis tuaj yeem dhau ib qho `isize`.
    ///
    /// * Qhov kev ncua deb li hauv ciam tsis tuaj yeem cuam tshuam "wrapping around" qhov chaw nyob.
    ///
    /// Rust hom yog tsis loj tshaj `isize::MAX` thiab Rust nyiaj yeej tsis qhwv nyob ib ncig ntawm qhov chaw nyob qhov chaw, li ntawd, ob pointers hauv ib co nqi ntawm tej Rust hom `T` yuav yeej ib txwm siav kawg ob tug mob.
    ///
    /// Tus txheem tsev qiv ntawv kuj feem ntau kom hais tias nyiaj yeej tsis cuag ib tug loj uas ib tug offset yog ib tug txhawj xeeb.
    /// Piv txwv li, `Vec` thiab `Box` kom lawv tsis txhob faib ntau dua `isize::MAX` bytes, yog li `ptr_into_vec.offset_from(vec.as_ptr())` yeej ib txwm txaus siab rau ob qho xwm txheej kawg.
    ///
    /// Feem ntau cov hauv paus ntsiab lus tsis tuaj yeem txawm tias txhim tsa kev faib ntau.
    /// Piv txwv li, tsis paub qhov 64-ntsis platform tuaj yeem ua haujlwm thov rau 2 <sup>63</sup> bytes vim los ntawm nplooj ntawv cov lus txwv lossis cais cov chaw nyob.
    /// Txawm li cas los xij, qee qhov 32-ntsis thiab 16-ntsis platform yuav ua tiav zoo thov rau ntau dua `isize::MAX` bytes nrog rau cov khoom xws li Lub Cev Chaw Txuas Lus.
    /// Xws li, lub cim xeeb kis tau ncaj qha los ntawm cov muab faib lossis cov ntaub ntawv nco mapped *yuav* loj dhau los ua nrog txoj haujlwm no.
    /// (Nco ntsoov tias [`offset`] thiab [`add`] kuj tseem muaj qhov kev txwv zoo ib yam thiab yog li tsis tuaj yeem siv rau qhov kev faib loj ntawd.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Qhov haujlwm no panics yog `T` yog Xoom-Sized Hom ("ZST").
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let mut a = [0; 5];
    /// let ptr1: *mut i32 = &mut a[1];
    /// let ptr2: *mut i32 = &mut a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Tsis yog lawm* kev siv:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8));
    /// let ptr2 = Box::into_raw(Box::new(1u8));
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Ua ptr2_other ua "alias" ntawm ptr2, tab sis muab tau los ntawm ptr1.
    /// let ptr2_other = (ptr1 as *mut u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Txij li thaum ptr2_other thiab ptr2 muab tau los ntawm cov taw tes mus rau cov khoom sib txawv, xam lawv cov offset tsis muaj cwj pwm tsis zoo, txawm tias lawv taw rau tib qho chaw nyob!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Cwj Pwm Tsis Txaus Siab
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        // KEV RUAJ NTSEG: tus neeg hu yuav tsum khaws daim ntawv cog lus muaj kev nyab xeeb rau `offset_from`.
        unsafe { (self as *const T).offset_from(origin) }
    }

    /// Xam cov offset los ntawm pointer (yooj yim rau `.offset(count as isize)`).
    ///
    /// `count` yog nyob rau hauv cov chav nyob ntawm T;piv txwv li, `count` ntawm 3 sawv cev rau pointer offset ntawm `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Yog hais tias ib yam ntawm cov nram qab no tej yam kev mob yog ua txhaum, qhov tshwm sim yog undefined cwj pwm:
    ///
    /// * Ob qhov pib thiab tshwm sim tus pointer yuav tsum nyob hauv kab lossis ib qho byte dhau los ntawm qhov kawg ntawm cov khoom sib txig tib yam.
    /// Nco ntsoov tias hauv Rust, txhua txhua (stack-allocated) qhov sib txawv yog suav hais tias yog cais cov khoom tau sib txawv.
    ///
    /// * Cov xam rho tawm,**hauv bytes**, tsis tuaj yeem dhau `isize`.
    ///
    /// * Qhov offset nyob hauv ciam tsis tuaj yeem ntseeg "wrapping around" qhov chaw nyob chaw.Ntawd yog, infinite-precision sum yuav tsum haum rau hauv `usize`.
    ///
    /// Lub compiler thiab lub tsev qiv ntawv txheem feem ntau sim ua kom paub tseeb tias cov kev faib yeej tsis ncav qhov loj me uas qhov kev daws txhaum yog qhov kev txhawj xeeb.
    /// Piv txwv li, `Vec` thiab `Box` kom lawv tsis txhob faib ntau dua `isize::MAX` bytes, yog li `vec.as_ptr().add(vec.len())` yog qhov muaj kev nyab xeeb tas mus li.
    ///
    /// Feem ntau cov hauv paus ntsiab lus tsis tuaj yeem txawm tias txhim tsa kev faib tawm no.
    /// Piv txwv li, tsis paub qhov 64-ntsis platform tuaj yeem ua haujlwm thov rau 2 <sup>63</sup> bytes vim los ntawm nplooj ntawv cov lus txwv lossis cais cov chaw nyob.
    /// Txawm li cas los xij, qee qhov 32-ntsis thiab 16-ntsis platform yuav ua tiav zoo thov rau ntau dua `isize::MAX` bytes nrog rau cov khoom xws li Lub Cev Chaw Txuas Lus.
    ///
    /// Xws li, lub cim xeeb kis tau ncaj qha los ntawm cov muab faib lossis cov ntaub ntawv nco mapped *yuav* loj dhau los ua nrog txoj haujlwm no.
    ///
    /// Xav txog kev siv [`wrapping_add`] hloov yog tias cov kev txwv no nyuaj rau kev txaus siab.
    /// Qhov zoo dua ntawm cov qauv no yog tias nws ua kom nruj dua compiler optimizations.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // KEV RUAJ NTSEG: tus neeg hu yuav tsum khaws daim ntawv cog lus muaj kev nyab xeeb rau `offset`.
        unsafe { self.offset(count as isize) }
    }

    /// Xam cov offset los ntawm pointer (yooj yim rau `.offset ((suav li isize).wrapping_neg())`).
    ///
    /// `count` yog nyob rau hauv cov chav nyob ntawm T;piv txwv li, `count` ntawm 3 sawv cev rau pointer offset ntawm `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Yog hais tias ib yam ntawm cov nram qab no tej yam kev mob yog ua txhaum, qhov tshwm sim yog undefined cwj pwm:
    ///
    /// * Ob qhov pib thiab tshwm sim tus pointer yuav tsum nyob hauv kab lossis ib qho byte dhau los ntawm qhov kawg ntawm cov khoom sib txig tib yam.
    /// Nco ntsoov tias hauv Rust, txhua txhua (stack-allocated) qhov sib txawv yog suav hais tias yog cais cov khoom tau sib txawv.
    ///
    /// * Tus nqi suav tsis suav tshaj `isize::MAX`**bytes**.
    ///
    /// * Qhov offset nyob hauv ciam tsis tuaj yeem cuam tshuam "wrapping around" chaw nyob.Ntawd yog, lub infinite-precision sum yuav tsum haum nyob rau hauv ib tug usize.
    ///
    /// Lub compiler thiab lub tsev qiv ntawv txheem feem ntau sim ua kom paub tseeb tias cov kev faib yeej tsis ncav qhov loj me uas qhov kev daws txhaum yog qhov kev txhawj xeeb.
    /// Piv txwv li, `Vec` thiab `Box` kom lawv tsis txhob faib ntau dua `isize::MAX` bytes, yog li `vec.as_ptr().add(vec.len()).sub(vec.len())` yog qhov muaj kev nyab xeeb tas mus li.
    ///
    /// Feem ntau cov hauv paus ntsiab lus tsis tuaj yeem txawm tias txhim tsa kev faib tawm no.
    /// Piv txwv li, tsis paub qhov 64-ntsis platform tuaj yeem ua haujlwm thov rau 2 <sup>63</sup> bytes vim los ntawm nplooj ntawv cov lus txwv lossis cais cov chaw nyob.
    /// Txawm li cas los xij, qee qhov 32-ntsis thiab 16-ntsis platform yuav ua tiav zoo thov rau ntau dua `isize::MAX` bytes nrog rau cov khoom xws li Lub Cev Chaw Txuas Lus.
    ///
    /// Xws li, lub cim xeeb kis tau ncaj qha los ntawm cov muab faib lossis cov ntaub ntawv nco mapped *yuav* loj dhau los ua nrog txoj haujlwm no.
    ///
    /// Xav txog kev siv [`wrapping_sub`] hloov yog tias cov kev txwv no nyuaj rau kev txaus siab.
    /// Qhov zoo dua ntawm cov qauv no yog tias nws ua kom nruj dua compiler optimizations.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // KEV RUAJ NTSEG: tus neeg hu yuav tsum khaws daim ntawv cog lus muaj kev nyab xeeb rau `offset`.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Laij cov offset los ntawm ib lub pointer uas siv qhwv cov lej laij zauv.
    /// (yooj yim rau `.wrapping_offset(count as isize)`)
    ///
    /// `count` yog nyob rau hauv cov chav nyob ntawm T;piv txwv li, `count` ntawm 3 sawv cev rau pointer offset ntawm `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Qhov haujlwm no nws tus kheej ib txwm muaj kev nyab xeeb, tab sis kev siv tus pointer tawm tsis yog.
    ///
    /// Lub pointer resulting tseem txuas rau cov kwv tseg tib yam uas `self` cov ntsiab lus rau.
    /// Nws yuav *tsis* siv tau nkag mus rau qhov sib txawv sib txawv.Nco ntsoov tias hauv Rust, txhua txhua (stack-allocated) qhov sib txawv yog suav hais tias yog cais cov khoom tau sib txawv.
    ///
    /// Hauv lwm lo lus, `let z = x.wrapping_add((y as usize) - (x as usize))` tsis *tsis* ua `z` zoo ib yam li `y` txawm tias peb xav tias `T` muaj qhov loj me `1` thiab tsis muaj dej ntws ntau: `z` tseem txuas rau tus kwv `x` txuas rau, thiab dereferencing nws yog Undefined Cwj pwm tshwj tsis yog `x` thiab `y` taw tes rau hauv cov khoom sib txig tib yam.
    ///
    /// Piv rau [`add`], txoj kev no cia li ncua txoj kev tseev kom muaj nyob hauv tib lub hom phiaj: [`add`] tam sim ntawd tus cwj pwm tsis tseem ceeb thaum hla ciam ciam chaw;`wrapping_add` tsim tawm tus pointer tab sis tseem ua rau Undefined Kev coj cwj pwm yog tias tus pointer tsis zoo thaum nws tawm ntawm-ntawm-qhov khoom ntawm nws tau txuas rau.
    /// [`add`] tuaj yeem pom zoo kom zoo dua thiab yog li xaiv tau nyob hauv qhov kev ua tau zoo-keej code.
    ///
    /// Qhov kev kuaj xyuas qeeb tsuas yog txiav txim siab tus nqi ntawm lub pointer uas tau dereferenced, tsis yog cov txiaj ntsig nruab nrab siv thaum lub sijhawm suav sau ntawm qhov txiaj ntsig kawg.
    /// Piv txwv li, `x.wrapping_add(o).wrapping_sub(o)` yog yeej ib txwm yog tib yam li `x`.Hauv lwm lo lus, tawm ntawm qhov khoom tau muab faib thiab tom qab ntawd rov nkag mus rau nws tom qab raug tso cai.
    ///
    /// Yog tias koj xav hla cov ciam ciam av, nrum lub pointer rau ib tus lej thiab ua tus lej nyob rau ntawd.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// // Siv cov pointer nyoos hauv kev nce ntawm ob qho
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Lub voj no luam tawm "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Laij cov offset los ntawm ib lub pointer uas siv qhwv cov lej laij zauv.
    /// (yooj yim rau `.wrapping_offset ((suav li isize).wrapping_neg())`)
    ///
    /// `count` yog nyob rau hauv cov chav nyob ntawm T;piv txwv li, `count` ntawm 3 sawv cev rau pointer offset ntawm `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Qhov haujlwm no nws tus kheej ib txwm muaj kev nyab xeeb, tab sis kev siv tus pointer tawm tsis yog.
    ///
    /// Lub pointer resulting tseem txuas rau cov kwv tseg tib yam uas `self` cov ntsiab lus rau.
    /// Nws yuav *tsis* siv tau nkag mus rau qhov sib txawv sib txawv.Nco ntsoov tias hauv Rust, txhua txhua (stack-allocated) qhov sib txawv yog suav hais tias yog cais cov khoom tau sib txawv.
    ///
    /// Hauv lwm lo lus, `let z = x.wrapping_sub((x as usize) - (y as usize))` tsis *tsis* ua `z` zoo ib yam li `y` txawm tias peb xav tias `T` muaj qhov loj me `1` thiab tsis muaj dej ntws ntau: `z` tseem txuas rau tus kwv `x` txuas rau, thiab dereferencing nws yog Undefined Cwj pwm tshwj tsis yog `x` thiab `y` taw tes rau hauv cov khoom sib txig tib yam.
    ///
    /// Piv rau [`sub`], txoj kev no cia li ncua txoj kev tseev kom muaj nyob hauv tib lub hom phiaj: [`sub`] tam sim ntawd tus cwj pwm tsis tseem ceeb thaum hla ciam ciam chaw;`wrapping_sub` tsim tawm tus pointer tab sis tseem ua rau Undefined Kev coj cwj pwm yog tias tus pointer tsis zoo thaum nws tawm ntawm-ntawm-qhov khoom ntawm nws tau txuas rau.
    /// [`sub`] tuaj yeem pom zoo kom zoo dua thiab yog li xaiv tau nyob hauv qhov kev ua tau zoo-keej code.
    ///
    /// Qhov kev kuaj xyuas qeeb tsuas yog txiav txim siab tus nqi ntawm lub pointer uas tau dereferenced, tsis yog cov txiaj ntsig nruab nrab siv thaum lub sijhawm suav sau ntawm qhov txiaj ntsig kawg.
    /// Piv txwv li, `x.wrapping_add(o).wrapping_sub(o)` yog yeej ib txwm yog tib yam li `x`.Hauv lwm lo lus, tawm ntawm qhov khoom tau muab faib thiab tom qab ntawd rov nkag mus rau nws tom qab raug tso cai.
    ///
    /// Yog tias koj xav hla cov ciam ciam av, nrum lub pointer rau ib tus lej thiab ua tus lej nyob rau ntawd.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// // Txaws siv cov pointer nyoos hauv qhov nce ntawm ob lub ntsiab (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Lub voj no luam tawm "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Teev tus pointer tus nqi rau `ptr`.
    ///
    /// Nyob rau hauv rooj plaub `self` yog (fat) tus pointer rau hom tsis muaj kev ua haujlwm, qhov kev ua haujlwm no tsuas yog cuam tshuam qhov pointer feem, hos rau (thin) taw rau cov hom loj, qhov no muaj cov tib yam ua haujlwm yooj yim.
    ///
    /// Qhov tshwm sim pointer yuav muaj qhov tseeb ntawm `val`, piv txwv li, rau cov roj pointer, qhov kev ua haujlwm no yog semantically tib yam li tsim cov roj pointer tshiab nrog cov ntaub ntawv pointer tus nqi ntawm `val` tab sis metadata ntawm `self`.
    ///
    ///
    /// # Examples
    ///
    /// Muaj nuj nqi no cov neeg uas tau tso cai rau byte-ntse pointer laij zauv ntawm cov roj uas raug:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let mut arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &mut arr[0] as *mut dyn Debug;
    /// let thin = ptr as *mut u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *mut i32), 3);
    ///     println!("{:?}", &*ptr); // yuav sau "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *mut u8) -> Self {
        let thin = &mut self as *mut *mut T as *mut *mut u8;
        // KEV RUAJ NTSEG: Nyob rau hauv cov ntaub ntawv ntawm ib tug nyias pointer, qhov no ua hauj lwm yog zoo tib yam
        // kom muaj txoj haujlwm yooj yim.
        // Yog hais tias muaj roj pointer, nrog rau kev siv cov rog pointer tam sim no, thawj qhov chaw ntawm tus pointer yog ib txwm ua cov ntaub ntawv pointer, uas zoo li tau muab rau ua.
        //
        unsafe { *thin = val };
        self
    }

    /// Nyeem tus nqi ntawm `self` yam tsis txav nws.
    /// Qhov no tawm lub cim xeeb hauv `self` tsis hloov pauv.
    ///
    /// Saib [`ptr::read`] rau kev txhawj xeeb ntawm kev nyab xeeb thiab cov piv txwv.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // KEV RUAJ NTSEG: tus neeg hu yuav tsum khaws daim ntawv cog lus muaj kev nyab xeeb rau ``.
        unsafe { read(self) }
    }

    /// Ua cov nyeem zoo li nthe ntawm qhov muaj nqis los ntawm `self` yam tsis muaj txav mus.Qhov no tawm lub cim xeeb hauv `self` tsis hloov pauv.
    ///
    /// Cov haujlwm ruaj khov yog npaj los ua ntawm I/O lub cim xeeb, thiab tau lees tias yuav tsum tsis txhob elided los yog reordered los ntawm cov compiler hla lwm cov kev ua haujlwm tsis huv.
    ///
    ///
    /// Saib [`ptr::read_volatile`] rau kev txhawj xeeb ntawm kev nyab xeeb thiab cov piv txwv.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // KEV RUAJ NTSEG: tus neeg hu yuav tsum khaws daim ntawv cog lus muaj kev nyab xeeb rau `read_volatile`.
        unsafe { read_volatile(self) }
    }

    /// Nyeem tus nqi ntawm `self` yam tsis txav nws.
    /// Qhov no tawm lub cim xeeb hauv `self` tsis hloov pauv.
    ///
    /// Tsis zoo li `read`, tus pointer tuaj yeem tsis muaj qhov sib txuas.
    ///
    /// Saib [`ptr::read_unaligned`] rau kev txhawj xeeb ntawm kev nyab xeeb thiab cov piv txwv.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // KEV RUAJ NTSEG: tus neeg hu yuav tsum khaws daim ntawv cog lus muaj kev nyab xeeb rau `read_unaligned`.
        unsafe { read_unaligned(self) }
    }

    /// Luam tawm `count * size_of<T>` bytes los ntawm `self` rau `dest`.
    /// Lub hauv paus thiab qhov chaw hla yuav hla mus rau.
    ///
    /// NOTE: qhov no muaj tus *tib* sib cav txiav txim raws [`ptr::copy`].
    ///
    /// Saib [`ptr::copy`] rau kev txhawj xeeb ntawm kev nyab xeeb thiab cov piv txwv.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // KEV RUAJ NTSEG: tus neeg hu yuav tsum khaws daim ntawv cog lus muaj kev nyab xeeb rau `copy`.
        unsafe { copy(self, dest, count) }
    }

    /// Luam tawm `count * size_of<T>` bytes los ntawm `self` rau `dest`.
    /// Lub hauv paus thiab qhov chaw yuav hla *tsis* sib tshooj.
    ///
    /// NOTE: qhov no muaj *tib* kev sib cav xaj ib yam li [`ptr::copy_nonoverlapping`].
    ///
    /// Saib [`ptr::copy_nonoverlapping`] rau kev txhawj xeeb ntawm kev nyab xeeb thiab cov piv txwv.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // KEV RUAJ NTSEG: tus neeg hu yuav tsum khaws daim ntawv cog lus muaj kev nyab xeeb rau `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Luam tawm `count * size_of<T>` bytes los ntawm `src` rau `self`.
    /// Lub hauv paus thiab qhov chaw hla yuav hla mus rau.
    ///
    /// NOTE: qhov no muaj *qhov txawv* sib cav ntawm [`ptr::copy`].
    ///
    /// Saib [`ptr::copy`] rau kev txhawj xeeb ntawm kev nyab xeeb thiab cov piv txwv.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // KEV RUAJ NTSEG: tus neeg hu yuav tsum khaws daim ntawv cog lus muaj kev nyab xeeb rau `copy`.
        unsafe { copy(src, self, count) }
    }

    /// Luam tawm `count * size_of<T>` bytes los ntawm `src` rau `self`.
    /// Lub hauv paus thiab qhov chaw yuav hla *tsis* sib tshooj.
    ///
    /// NOTE: qhov no muaj *qhov txawv* sib cav ntawm [`ptr::copy_nonoverlapping`].
    ///
    /// Saib [`ptr::copy_nonoverlapping`] rau kev txhawj xeeb ntawm kev nyab xeeb thiab cov piv txwv.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from_nonoverlapping(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // KEV RUAJ NTSEG: tus neeg hu yuav tsum khaws daim ntawv cog lus muaj kev nyab xeeb rau `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(src, self, count) }
    }

    /// Executes lub destructor (yog tias muaj) ntawm lub taw-rau nqi.
    ///
    /// Saib [`ptr::drop_in_place`] rau kev ruaj ntseg kev txhawj xeeb thiab kev piv txwv.
    ///
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn drop_in_place(self) {
        // KEV RUAJ NTSEG: tus neeg hu yuav tsum khaws daim ntawv cog lus muaj kev nyab xeeb rau `drop_in_place`.
        unsafe { drop_in_place(self) }
    }

    /// Sau dua qhov chaw nco nrog qhov muaj txiaj ntsig tsis tau nyeem lossis poob tus nqi qub.
    ///
    ///
    /// Saib [`ptr::write`] rau kev txhawj xeeb ntawm kev nyab xeeb thiab cov piv txwv.
    ///
    /// [`ptr::write`]: crate::ptr::write()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write(self, val: T)
    where
        T: Sized,
    {
        // KEV RUAJ NTSEG: tus neeg hu yuav tsum khaws daim ntawv cog lus muaj kev nyab xeeb rau `write`.
        unsafe { write(self, val) }
    }

    /// Ua rau memset ntawm cov pointer uas tau hais tseg, teeb `count * size_of::<T>()` bytes ntawm lub cim xeeb pib ntawm `self` rau `val`.
    ///
    ///
    /// Saib [`ptr::write_bytes`] rau kev txhawj xeeb ntawm kev nyab xeeb thiab cov piv txwv.
    ///
    /// [`ptr::write_bytes`]: crate::ptr::write_bytes()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_bytes(self, val: u8, count: usize)
    where
        T: Sized,
    {
        // KEV RUAJ NTSEG: tus neeg hu yuav tsum khaws daim ntawv cog lus muaj kev nyab xeeb rau `write_bytes`.
        unsafe { write_bytes(self, val, count) }
    }

    /// Ua qhov nrov tsis meej ntawm sau lub cim xeeb qhov chaw nrog muab tus nqi yam tsis tau nyeem lossis poob tus nqi qub.
    ///
    /// Cov haujlwm ruaj khov yog npaj los ua ntawm I/O lub cim xeeb, thiab tau lees tias yuav tsum tsis txhob elided los yog reordered los ntawm cov compiler hla lwm cov kev ua haujlwm tsis huv.
    ///
    ///
    /// Saib [`ptr::write_volatile`] rau kev txhawj xeeb ntawm kev nyab xeeb thiab cov piv txwv.
    ///
    /// [`ptr::write_volatile`]: crate::ptr::write_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_volatile(self, val: T)
    where
        T: Sized,
    {
        // KEV RUAJ NTSEG: tus neeg hu yuav tsum khaws daim ntawv cog lus muaj kev nyab xeeb rau `write_volatile`.
        unsafe { write_volatile(self, val) }
    }

    /// Sau dua qhov chaw nco nrog qhov muaj txiaj ntsig tsis tau nyeem lossis poob tus nqi qub.
    ///
    ///
    /// Tsis zoo li `write`, tus pointer tuaj yeem tsis muaj qhov sib txuas.
    ///
    /// Saib [`ptr::write_unaligned`] rau kev txhawj xeeb ntawm kev nyab xeeb thiab cov piv txwv.
    ///
    /// [`ptr::write_unaligned`]: crate::ptr::write_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
    #[inline]
    pub const unsafe fn write_unaligned(self, val: T)
    where
        T: Sized,
    {
        // KEV RUAJ NTSEG: tus neeg hu yuav tsum khaws daim ntawv cog lus muaj kev nyab xeeb rau `write_unaligned`.
        unsafe { write_unaligned(self, val) }
    }

    /// Pauv tus nqi ntawm `self` nrog `src`, rov qab rau hauv lub qub nqi, tsis muaj xa me nyuam rov los.
    ///
    ///
    /// Saib [`ptr::replace`] rau kev txhawj xeeb ntawm kev nyab xeeb thiab cov piv txwv.
    ///
    /// [`ptr::replace`]: crate::ptr::replace()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn replace(self, src: T) -> T
    where
        T: Sized,
    {
        // KEV RUAJ NTSEG: tus neeg hu yuav tsum khaws daim ntawv cog lus muaj kev nyab xeeb rau `replace`.
        unsafe { replace(self, src) }
    }

    /// Swaps qhov muaj nuj nqis ntawm ob qhov chaw hloov pauv ntawm tib hom, tsis muaj kev txiav tawm ib qho twg.
    /// Lawv tuaj yeem sib tshooj, tsis zoo li `mem::swap` uas yog lwm yam sib npaug.
    ///
    /// Saib [`ptr::swap`] rau kev txhawj xeeb ntawm kev nyab xeeb thiab cov piv txwv.
    ///
    /// [`ptr::swap`]: crate::ptr::swap()
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn swap(self, with: *mut T)
    where
        T: Sized,
    {
        // KEV RUAJ NTSEG: tus neeg hu yuav tsum khaws daim ntawv cog lus muaj kev nyab xeeb rau `swap`.
        unsafe { swap(self, with) }
    }

    /// Computes cov offset uas xav tau kev pab yuav tsum tau ua ntawv thov mus rau lub pointer nyob rau hauv thiaj li yuav ua rau nws mus raws li `align`.
    ///
    /// Yog tias nws tsis tuaj yeem ua raws li lub pointer, qhov kev nqis tes ua rov `usize::MAX`.
    /// Nws yog kev tso cai rau kev nqis tes ua rau *ib txwm* rov `usize::MAX`.
    /// Tsuas yog koj qhov algorithm kev ua tau zoo nyob ntawm qhov tau txais qhov ua tau siv ntawm no, tsis yog nws qhov tseeb.
    ///
    /// Qhov offset tau qhia nyob rau hauv ntau ntawm `T` lub ntsiab, thiab tsis yog bytes.Tus nqi rov qab tuaj yeem siv nrog `wrapping_add` tus qauv.
    ///
    /// Tsis muaj kev tiv thaiv dab tsi los xij uas qhov pab daws lub pointer yuav tsis thim lossis mus dhau qhov kev faib tawm uas tus po taw tes nkag mus.
    ///
    /// Nws yog nyob ntawm tus neeg hu xov tooj kom paub meej tias qhov kev xa rov qab xa rov qab yog qhov tseeb ntawm txhua nqe lus dua li kev coj ua ke.
    ///
    /// # Panics
    ///
    /// Txoj haujlwm panics yog `align` tsis yog lub zog-ntawm ob.
    ///
    /// # Examples
    ///
    /// Kev nkag mus rau ib sab `u8` li `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // thaum tus pointer tuaj yeem ua raws li `offset`, nws yuav taw tes sab nraud qhov kev faib nyiaj
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // KEV RUAJ NTSEG: `align` tau soj ntsuam yuav tsum tau ib lub hwj chim ntawm 2 saum toj no
        unsafe { align_offset(self, align) }
    }
}

#[lang = "mut_slice_ptr"]
impl<T> *mut [T] {
    /// Rov qab los qhov ntev ntawm cov nqaij nyoos.
    ///
    /// Tus nqi xa rov qab yog tus lej **ntsiab**, tsis yog tus lej bytes.
    ///
    /// Txoj haujlwm no muaj kev nyab xeeb, txawm tias thaum hlais cov nqaij nyoos tsis tuaj yeem raug pov rau ib qho kev xa mus vim tias tus pointer tsis muaj dab tsi los yog tsis siv.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // KEV RUAJ NTSEG: qhov no muaj kev nyab xeeb vim `*const [T]` thiab `FatPtr<T>` muaj tib lub qauv.
            // Tsuas yog `std` thiaj ua tau qhov kev lav no.
            unsafe { Repr { rust_mut: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Rov ib tug nyoos pointer mus rau lub hlais tus tsis.
    ///
    /// Qhov no yog sib npaug rau nrum `self` rau `*mut T`, tab sis ntau yam-muaj kev nyab xeeb dua.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 0 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self as *mut T
    }

    /// Rov qab los ua lub hauv paus loj nyoos mus rau ib qho khoom lossis subslice, tsis tas ua cov kev ntsuas.
    ///
    /// Hu rau cov qauv no nrog ib tug tawm-ntawm-bounds index los yog thaum `self` yog tsis dereferencable yog *[undefined tus cwj pwm]* txawm yog hais tias tus uas ua pointer yog tsis siv.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &mut [1, 2, 4] as *mut [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1), x.as_mut_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> *mut I::Output
    where
        I: SliceIndex<[T]>,
    {
        // KEV RUAJ NTSEG: tus hu tuaj xyuas kom meej tias `self` yog qhov uas dereferencable thiab `index` hauv-kev thaj tsam.
        unsafe { index.get_unchecked_mut(self) }
    }

    /// Rov qab `None` yog tias tus pointer tsis zoo, lossis lwm tus xa rov qab ib qho sib koom mus rau tus nqi qhwv hauv `Some`.
    /// Hauv kev sib piv rau [`as_ref`], qhov no tsis tas tias tus nqi yuav tsum tau pib.
    ///
    /// Rau tus sawv cev mutable pom [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_slice_mut`]: #method.as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Thaum hu xov tooj rau hom no, koj yuav tsum xyuas kom meej tias *tog twg los tus pointer yog NULL* lossis * tag nrho cov hauv qab no yog qhov tseeb:
    ///
    /// * Tus pointer yuav tsum yog [valid] rau kev nyeem rau `ptr.len() * mem::size_of::<T>()` ntau bytes, thiab nws yuav tsum tau ua kom haum rau qhov ncaj.Qhov no txhais tau rau hauv kev:
    ///
    ///     * Tag nrho cov cim xeeb ntau ntawm cov hlais no yuav tsum muaj nyob hauv ib tus kwv yees nkaus xwb!
    ///       Cov qib qis tsis tuaj yeem hla rau ntau cov khoom sib cais.
    ///
    ///     * Tus taw rau yuav tsum tau mus raws li txawm xoom-ntev hlais.
    ///     Ib qho laj thawj rau qhov no yog hais tias enum layout kev xaiv kom zoo dua yuav cia siab rau cov neeg ua tim khawv (suav nrog hlov ib qho twg ntev) tau sib txig thiab tsis yog-cais rau qhov txawv lawv los ntawm lwm cov ntaub ntawv.
    ///
    ///     Koj tuaj yeem muab cov pointer uas siv tau xws li `data` rau xoom qhov ntev ntev siv [`NonNull::dangling()`].
    ///
    /// * Tag nrho cov loj `ptr.len() * mem::size_of::<T>()` ntawm lub hlais yuav tsum tsis muaj loj tshaj `isize::MAX`.
    ///   Saib cov ntaub ntawv kev nyab xeeb ntawm [`pointer::offset`].
    ///
    /// * Koj yuav tsum tswj hwm Rust cov cai tswjfwm tsis zoo, txij li kev rov qab los ntawm `'a` lub neej yog kev xaiv thiab tsis tas yuav cuam tshuam qhov tseeb lub neej ntawm cov ntaub ntawv.
    ///   Tshwj xeeb, rau lub sijhawm ntawm lub neej no, lub cim xeeb lub ntsiab lus taw qhia kom tsis txhob muaj kev sib hloov (tshwj tsis yog sab hauv `UnsafeCell`).
    ///
    /// Qhov no siv tau txawm hais tias qhov txiaj ntsig ntawm hom no tsis siv!
    ///
    /// Xyuas [`slice::from_raw_parts`][] thiab.
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // KEV RUAJ NTSEG: tus neeg hu yuav tsum khaws daim ntawv cog lus muaj kev nyab xeeb rau `as_uninit_slice`.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }

    /// Rov qab `None` yog tias tus pointer tsis zoo, lossis lwm tus xa rov qab tshwj xeeb hlais rau tus nqi qhwv hauv `Some`.
    /// Hauv kev sib piv rau [`as_mut`], qhov no tsis tas tias tus nqi yuav tsum tau pib.
    ///
    /// Rau cov sib koom tes xyuas saib [`as_uninit_slice`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_slice`]: #method.as_uninit_slice-1
    ///
    /// # Safety
    ///
    /// Thaum hu xov tooj rau hom no, koj yuav tsum xyuas kom meej tias *tog twg los tus pointer yog NULL* lossis * tag nrho cov hauv qab no yog qhov tseeb:
    ///
    /// * Tus pointer yuav tsum yog [valid] rau kev nyeem thiab sau ntawv rau `ptr.len() * mem::size_of::<T>()` ntau bytes, thiab nws yuav tsum tau ua kom zoo mus rau.Qhov no txhais tau rau hauv kev:
    ///
    ///     * Tag nrho cov cim xeeb ntau ntawm cov hlais no yuav tsum muaj nyob hauv ib tus kwv yees nkaus xwb!
    ///       Cov qib qis tsis tuaj yeem hla rau ntau cov khoom sib cais.
    ///
    ///     * Tus taw rau yuav tsum tau mus raws li txawm xoom-ntev hlais.
    ///     Ib qho laj thawj rau qhov no yog hais tias enum layout kev xaiv kom zoo dua yuav cia siab rau cov neeg ua tim khawv (suav nrog hlov ib qho twg ntev) tau sib txig thiab tsis yog-cais rau qhov txawv lawv los ntawm lwm cov ntaub ntawv.
    ///
    ///     Koj tuaj yeem muab cov pointer uas siv tau xws li `data` rau xoom qhov ntev ntev siv [`NonNull::dangling()`].
    ///
    /// * Tag nrho cov loj `ptr.len() * mem::size_of::<T>()` ntawm lub hlais yuav tsum tsis muaj loj tshaj `isize::MAX`.
    ///   Saib cov ntaub ntawv kev nyab xeeb ntawm [`pointer::offset`].
    ///
    /// * Koj yuav tsum tswj hwm Rust cov cai tswjfwm tsis zoo, txij li kev rov qab los ntawm `'a` lub neej yog kev xaiv thiab tsis tas yuav cuam tshuam qhov tseeb lub neej ntawm cov ntaub ntawv.
    ///   Tshwj xeeb, rau lub sijhawm rau lub neej no, lub cim xeeb lub ntsiab lus taw qhia kom tsis txhob nkag (nyeem lossis sau ntawv) los ntawm lwm lub pointer.
    ///
    /// Qhov no siv tau txawm hais tias qhov txiaj ntsig ntawm hom no tsis siv!
    ///
    /// Xyuas [`slice::from_raw_parts_mut`][] thiab.
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut<'a>(self) -> Option<&'a mut [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // KEV RUAJ NTSEG: tus neeg hu yuav tsum khaws daim ntawv cog lus muaj kev nyab xeeb rau `as_uninit_slice_mut`.
            Some(unsafe { slice::from_raw_parts_mut(self as *mut MaybeUninit<T>, self.len()) })
        }
    }
}

// Kev sib luag rau cov lus qhia
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *mut T {
    #[inline]
    fn eq(&self, other: &*mut T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *mut T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *mut T {
    #[inline]
    fn cmp(&self, other: &*mut T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *mut T {
    #[inline]
    fn partial_cmp(&self, other: &*mut T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*mut T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*mut T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*mut T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*mut T) -> bool {
        *self >= *other
    }
}