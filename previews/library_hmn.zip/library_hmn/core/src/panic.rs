//! Panic kev txhawb nqa hauv lub tsev qiv ntawv txheem.

#![stable(feature = "core_panic_info", since = "1.41.0")]

use crate::any::Any;
use crate::fmt;

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2015_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2015 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($msg:literal $(,)?) => (
        $crate::panicking::panic($msg)
    ),
    ($msg:expr $(,)?) => (
        $crate::panicking::panic_str($msg)
    ),
    ($fmt:expr, $($arg:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($fmt, $($arg)+))
    ),
}

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2021_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2021 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($($t:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($($t)+))
    ),
}

/// Tus qauv muab cov ntaub ntawv hais txog panic.
///
/// `PanicInfo` tus qauv dhau mus rau panic hook teem los ntawm [`set_hook`] muaj nuj nqi.
///
///
/// [`set_hook`]: ../../std/panic/fn.set_hook.html
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
///         println!("panic occurred: {:?}", s);
///     } else {
///         println!("panic occurred");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
#[lang = "panic_info"]
#[stable(feature = "panic_hooks", since = "1.10.0")]
#[derive(Debug)]
pub struct PanicInfo<'a> {
    payload: &'a (dyn Any + Send),
    message: Option<&'a fmt::Arguments<'a>>,
    location: &'a Location<'a>,
}

impl<'a> PanicInfo<'a> {
    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn internal_constructor(
        message: Option<&'a fmt::Arguments<'a>>,
        location: &'a Location<'a>,
    ) -> Self {
        struct NoPayload;
        PanicInfo { location, message, payload: &NoPayload }
    }

    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn set_payload(&mut self, info: &'a (dyn Any + Send)) {
        self.payload = info;
    }

    /// Rov qab them cov nuj nqis tau cuam tshuam nrog panic.
    ///
    /// Qhov no feem ntau, tab sis tsis yog tas li, yog `&'static str` lossis [`String`].
    ///
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
    ///         println!("panic occurred: {:?}", s);
    ///     } else {
    ///         println!("panic occurred");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn payload(&self) -> &(dyn Any + Send) {
        self.payload
    }

    /// Yog tias `panic!` macro los ntawm `core` crate (tsis yog los ntawm `std`) tau siv nrog txoj hlua ua qauv thiab qee cov kev sib cav ntxiv, rov cov lus ntawv npaj los siv rau piv txwv nrog [`fmt::write`]
    ///
    ///
    #[unstable(feature = "panic_info_message", issue = "66745")]
    pub fn message(&self) -> Option<&fmt::Arguments<'_>> {
        self.message
    }

    /// Rov qab cov ntaub ntawv hais txog qhov chaw nyob uas panic keeb kwm, yog tias muaj.
    ///
    /// Cov qauv no yuav tam sim no rov qab [`Some`], tab sis qhov no kuj yuav hloov pauv hauv future cov ntawv.
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}' at line {}",
    ///             location.file(),
    ///             location.line(),
    ///         );
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn location(&self) -> Option<&Location<'_>> {
        // NOTE: Yog tias qhov no raug hloov qee zaus rov Tsis muaj,
        // hais txog rooj plaub no hauv std::panicking::default_hook thiab std::panicking::begin_panic_fmt.
        Some(&self.location)
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for PanicInfo<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("panicked at ")?;
        if let Some(message) = self.message {
            write!(formatter, "'{}', ", message)?
        } else if let Some(payload) = self.payload.downcast_ref::<&'static str>() {
            write!(formatter, "'{}', ", payload)?
        }
        // NOTE: peb siv tsis tau downcast_ref: :<String>() no
        // vim tias Txoj hlua tsis muaj nyob hauv libcore!
        // Tus xa khoom yog tus hlua thaum `std::panic!` hu nrog ntau cov kev sib cav, tab sis nyob rau hauv rooj plaub no cov lus kuj tseem muaj.
        //

        self.location.fmt(formatter)
    }
}

/// Tus qauv txheej txheem muaj cov ntaub ntawv hais txog qhov chaw nyob ntawm panic.
///
/// Tus qauv no yog tsim los ntawm [`PanicInfo::location()`].
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(location) = panic_info.location() {
///         println!("panic occurred in file '{}' at line {}", location.file(), location.line());
///     } else {
///         println!("panic occurred but can't get location information...");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
///
/// # Comparisons
///
/// Kev sib piv rau kev sib luag thiab kev xaj yog ua hauv kab, kab, tom qab ntawv ces.
/// Cov ntaub ntawv piv nrog cov hlua, tsis yog `Path`, uas tuaj yeem tsis paub txog.
/// Saib [`Qhov Chaw: : file`] cov ntaub ntawv rau kev sib tham ntxiv.
#[lang = "panic_location"]
#[derive(Copy, Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[stable(feature = "panic_hooks", since = "1.10.0")]
pub struct Location<'a> {
    file: &'a str,
    line: u32,
    col: u32,
}

impl<'a> Location<'a> {
    /// Rov qab los ntawm qhov chaw nyob ntawm tus neeg hu ntawm txoj haujlwm no.
    /// Yog tias qhov haujlwm ntawd lub ntsiab lus tshaj tawm yog li ntawd nws qhov chaw hu xov tooj yuav xa rov qab, thiab yog li ntawm cov pawg mus rau thawj qhov kev hu hauv lub cev tsis ua haujlwm ntawm lub cev.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::panic::Location;
    ///
    /// /// Rov rau [`Location`] ntawm qhov nws hu ua.
    /// #[track_caller]
    /// fn get_caller_location() -> &'static Location<'static> {
    ///     Location::caller()
    /// }
    ///
    /// /// Rov ib [`Location`] los ntawm tsis pub dhau no muaj nuj nqi tus txhais.
    /// fn get_just_one_location() -> &'static Location<'static> {
    ///     get_caller_location()
    /// }
    ///
    /// let fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), file!());
    /// assert_eq!(fixed_location.line(), 14);
    /// assert_eq!(fixed_location.column(), 5);
    ///
    /// // khiav tib txoj haujlwm tsis muaj npe nyob hauv qhov chaw sib txawv muab peb qhov txiaj ntsig zoo ib yam
    /// let second_fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), second_fixed_location.file());
    /// assert_eq!(fixed_location.line(), second_fixed_location.line());
    /// assert_eq!(fixed_location.column(), second_fixed_location.column());
    ///
    /// let this_location = get_caller_location();
    /// assert_eq!(this_location.file(), file!());
    /// assert_eq!(this_location.line(), 28);
    /// assert_eq!(this_location.column(), 21);
    ///
    /// // khiav lub tracked muaj nuj nqi nyob rau hauv qhov chaw sib txawv tsim cov nqi sib txawv
    /// let another_location = get_caller_location();
    /// assert_eq!(this_location.file(), another_location.file());
    /// assert_ne!(this_location.line(), another_location.line());
    /// assert_ne!(this_location.column(), another_location.column());
    /// ```
    #[stable(feature = "track_caller", since = "1.46.0")]
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    #[track_caller]
    pub const fn caller() -> &'static Location<'static> {
        crate::intrinsics::caller_location()
    }
}

impl<'a> Location<'a> {
    #![unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    pub const fn internal_constructor(file: &'a str, line: u32, col: u32) -> Self {
        Location { file, line, col }
    }

    /// Rov qab los lub npe ntawm cov ntaub ntawv los ntawm cov chaw uas panic.
    ///
    /// # `&str`, tsis `&Path`
    ///
    /// Lub npe xa rov qab yog hais txog ib txoj hauv kev ntawm txoj kev suav sau, tab sis nws tsis tsim nyog los sawv cev rau qhov no ncaj qha ua `&Path`.
    /// Txoj cai tso ua ke yuav khiav ntawm kab ke sib txawv nrog kev siv `Path` sib txawv dua li cov kab ke muab cov ncauj lus thiab lub tsev qiv ntawv tam sim no tsis muaj "host path" yam sib txawv.
    ///
    /// Cov cwj pwm tsis txaus ntseeg feem ntau tshwm sim thaum "the same" cov ntaub ntawv xa mus cuag tau ntau txoj hauv kev hauv qhov system module (feem ntau siv `#[path = "..."]` attribute lossis zoo sib xws), uas tuaj yeem ua rau dab tsi zoo li cov lej rov qab sib txawv ntawm cov nuj nqi no.
    ///
    ///
    /// # Cross-compilation
    ///
    /// Cov nqi no tsis haum rau kev xa mus rau `Path::new` lossis cov kws tsim kho zoo sib xws thaum tus tswv tsev platform thiab lub hom phiaj platform sib txawv.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}'", location.file());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn file(&self) -> &str {
        self.file
    }

    /// Rov tau cov kab naj npawb uas panic tawm los.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at line {}", location.line());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn line(&self) -> u32 {
        self.line
    }

    /// Rov qab rau kab ntawv los ntawm lub panic keeb kwm.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at column {}", location.column());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_col", since = "1.25.0")]
    pub fn column(&self) -> u32 {
        self.col
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for Location<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{}:{}:{}", self.file, self.line, self.col)
    }
}

/// Sab hauv trait siv los ntawm libstd kom dhau cov ntaub ntawv los ntawm libstd rau `panic_unwind` thiab lwm yam panic.
/// Tsis tas yuav nyob ruaj khov txhua lub sijhawm sai sai, tsis txhob siv.
///
#[unstable(feature = "std_internals", issue = "none")]
#[doc(hidden)]
pub unsafe trait BoxMeUp {
    /// Siv tag nrho cov tswv cuab ntawm cov ncauj lus.
    /// Qhov rov qab hom yog tiag `Box<dyn Any + Send>`, tab sis peb tsis tuaj yeem siv `Box` hauv libcore.
    ///
    /// Tom qab cov qauv no tau hu ua, tsuas yog qee tus dummy vim tus nqi tshuav hauv `self`.
    /// Hu xov tooj rau tus qauv no ob zaug, lossis hu `get` tom qab hu tus qauv no, yog qhov yuam kev.
    ///
    /// Cov lus sib cav qiv vim tias panic Runtime (`__rust_start_panic`) tsuas yog tau txais ib qho xoo `dyn BoxMeUp`.
    ///
    fn take_box(&mut self) -> *mut (dyn Any + Send);

    /// Tsuas qiv cov ntawv xwb.
    fn get(&mut self) -> &(dyn Any + Send);
}