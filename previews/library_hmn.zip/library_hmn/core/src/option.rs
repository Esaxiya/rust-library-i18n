//! Yeem muaj nuj nqis.
//!
//! Hom [`Option`] sawv cev rau tus nqi xaiv: txhua [`Option`] yog [`Some`] thiab muaj tus nqi, lossis [`None`], thiab tsis tau.
//! [`Option`] hom muaj ntau heev nyob rau hauv Rust code, raws li lawv muaj tus lej siv:
//!
//! * Thaum pib qhov tseem ceeb
//! * Rov qab mus rau qhov tseem ceeb rau cov haujlwm uas tsis tau txhais dua tag nrho lawv cov kev tawm tswv yim (cov haujlwm ib nrab)
//! * Rov qab tus nqi rau lwm yam kev qhia tsis yoojyim, qhov twg [`None`] xa rov qab ntawm qhov yuam kev
//! * Xaiv teb
//! * Tus qauv teb uas tuaj yeem qiv lossis "taken"
//! * Yeem muaj nuj nqi sib cav
//! * Cov lus tsis muaj tseeb
//! * Muab tej yam pauv ntawm qhov nyuaj
//!
//! [`Xaiv`] s feem ntau ua ke nrog cov qauv txuam kom nug qhov kuaj pom ntawm tus nqi thiab nqis tes ua, ib txwm suav rau [`None`] rooj plaub.
//!
//!
//! ```
//! fn divide(numerator: f64, denominator: f64) -> Option<f64> {
//!     if denominator == 0.0 {
//!         None
//!     } else {
//!         Some(numerator / denominator)
//!     }
//! }
//!
//! // Tus nqi rov qab ntawm txoj haujlwm yog ib qho kev xaiv
//! let result = divide(2.0, 3.0);
//!
//! // Qauv phim rau qhov khaws tus nqi
//! match result {
//!     // Kev faib tawm tau siv tau
//!     Some(x) => println!("Result: {}", x),
//!     // Lub txim tau tsis muaj tseeb
//!     None    => println!("Cannot divide by 0"),
//! }
//! ```
//!
//!
//!
//!
//!
// FIXME: Qhia seb `Option` siv li cas hauv kev coj ua, nrog ntau txoj kev
//
//! # Kev xaiv thiab taw tes ("nullable" pointers)
//!
//! Rust lub pointer hom yuav tsum ib txwm taw rau qhov chaw siv tau;tsis muaj "null" xaim.Hloov chaw, Rust muaj *kev xaiv* taw qhia, zoo li lub thawv xaiv tau, [`Xaiv`] `<` [`Lub thawv<T>`]`>`.
//!
//! Cov piv txwv hauv qab no siv [`Option`] los tsim lub yeem xaiv ntawm [`i32`].
//! Daim ntawv ceeb toom tias txhawm rau siv lub sab hauv [`i32`] tus nqi ua ntej, `check_optional` kev ua haujlwm yuav tsum siv cov qauv sib txawv los txiav txim seb lub thawv ntawd puas muaj nuj nqis (piv txwv li, nws yog [`Some(...)`][`Some`]) lossis tsis ([`None`]).
//!
//!
//! ```
//! let optional = None;
//! check_optional(optional);
//!
//! let optional = Some(Box::new(9000));
//! check_optional(optional);
//!
//! fn check_optional(optional: Option<Box<i32>>) {
//!     match optional {
//!         Some(p) => println!("has value {}", p),
//!         None => println!("has no value"),
//!     }
//! }
//! ```
//!
//! # Representation
//!
//! Rust tuaj yeem kom ua kom zoo dua rau cov hom `T` hauv qab no xws li tias [`Option<T>`] muaj qhov loj tib yam li `T`:
//!
//! * [`Box<U>`]
//! * `&U`
//! * `&mut U`
//! * `fn`, `extern "C" fn`
//! * [`num::NonZero*`]
//! * [`ptr::NonNull<U>`]
//! * `#[repr(transparent)]` teeb ib ncig ntawm ib hom nyob hauv phau ntawv no.
//!
//! Nws yog qhov kev lees paub ntxiv tias, rau cov teeb meem saum toj no, ib qho tuaj yeem [`mem::transmute`] los ntawm txhua qhov tseem ceeb ntawm `T` rau `Option<T>` thiab los ntawm `Some::<T>(_)` rau `T` (tab sis transmuting `None::<T>` rau `T` yog tus cwj pwm tsis paub qhov tseeb).
//!
//! # Examples
//!
//! Cov qauv sib txuam hauv [`Option`]:
//!
//! ```
//! let msg = Some("howdy");
//!
//! // Siv ib qho siv rau txoj hlua uas muaj
//! if let Some(m) = &msg {
//!     println!("{}", *m);
//! }
//!
//! // Tshem tawm txoj hlua muaj, rhuav tshem Qhov Kev Xaiv
//! let unwrapped_msg = msg.unwrap_or("default message");
//! ```
//!
//! Pib ua haujlwm rau [`None`] ua ntej lub voj:
//!
//! ```
//! enum Kingdom { Plant(u32, &'static str), Animal(u32, &'static str) }
//!
//! // Cov npe ntawm cov ntaub ntawv los tshawb txog.
//! let all_the_big_things = [
//!     Kingdom::Plant(250, "redwood"),
//!     Kingdom::Plant(230, "noble fir"),
//!     Kingdom::Plant(229, "sugar pine"),
//!     Kingdom::Animal(25, "blue whale"),
//!     Kingdom::Animal(19, "fin whale"),
//!     Kingdom::Animal(15, "north pacific right whale"),
//! ];
//!
//! // Peb tab tom tshawb nrhiav lub npe ntawm tus tsiaj loj tshaj, tab sis pib nrog peb nyuam qhuav tau `None`.
//! //
//! let mut name_of_biggest_animal = None;
//! let mut size_of_biggest_animal = 0;
//! for big_thing in &all_the_big_things {
//!     match *big_thing {
//!         Kingdom::Animal(size, name) if size > size_of_biggest_animal => {
//!             // Tam sim no peb pom lub npe ntawm qee cov tsiaj loj
//!             size_of_biggest_animal = size;
//!             name_of_biggest_animal = Some(name);
//!         }
//!         Kingdom::Animal(..) | Kingdom::Plant(..) => ()
//!     }
//! }
//!
//! match name_of_biggest_animal {
//!     Some(name) => println!("the biggest animal is {}", name),
//!     None => println!("there are no animals :("),
//! }
//! ```
//!
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Box<U>`]: ../../std/boxed/struct.Box.html
//! [`num::NonZero*`]: crate::num
//! [`ptr::NonNull<U>`]: crate::ptr::NonNull
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::iter::{FromIterator, FusedIterator, TrustedLen};
use crate::pin::Pin;
use crate::{
    fmt, hint, mem,
    ops::{self, Deref, DerefMut},
};

/// `Option` hom.Saib [the module level documentation](self) rau ntxiv.
#[derive(Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[rustc_diagnostic_item = "option_type"]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Option<T> {
    /// Tsis muaj nqi
    #[lang = "None"]
    #[stable(feature = "rust1", since = "1.0.0")]
    None,
    /// Qee tus nqi `T`
    #[lang = "Some"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Some(#[stable(feature = "rust1", since = "1.0.0")] T),
}

/////////////////////////////////////////////////////////////////////////////
// Kev siv hom
/////////////////////////////////////////////////////////////////////////////

impl<T> Option<T> {
    /////////////////////////////////////////////////////////////////////////
    // Nug qhov muaj nuj nqis
    /////////////////////////////////////////////////////////////////////////

    /// Rov qab `true` yog tias qhov kev xaiv yog tus nqi [`Some`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_some(), true);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_some(), false);
    /// ```
    #[must_use = "if you intended to assert that this has a value, consider `.unwrap()` instead"]
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_some(&self) -> bool {
        matches!(*self, Some(_))
    }

    /// Rov qab `true` yog tias qhov kev xaiv yog tus nqi [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_none(), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_none(), true);
    /// ```
    #[must_use = "if you intended to assert that this doesn't have a value, consider \
                  `.and_then(|| panic!(\"`Option` had a value when expected `None`\"))` instead"]
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_none(&self) -> bool {
        !self.is_some()
    }

    /// Rov qab `true` yog tias qhov kev xaiv yog [`Some`] tus nqi uas muaj tus nqi muab.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_contains)]
    ///
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.contains(&2), true);
    ///
    /// let x: Option<u32> = Some(3);
    /// assert_eq!(x.contains(&2), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.contains(&2), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "option_result_contains", issue = "62358")]
    pub fn contains<U>(&self, x: &U) -> bool
    where
        U: PartialEq<T>,
    {
        match self {
            Some(y) => x == y,
            None => false,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Daim yoog rau kev ua hauj lwm nrog cov ntawv xa mus
    /////////////////////////////////////////////////////////////////////////

    /// Hloov pauv los ntawm `&Option<T>` rau `Option<&T>`.
    ///
    /// # Examples
    ///
    /// Hloov kev xaiv ``<`[`txoj hlua ']`>`rau hauv ib txoj kev xaiv <`[`usize`]`>, khaws cia cov qub.
    /// Tus txheej txheem [`map`] siv `self` kev sib cav los ntawm tus nqi, noj cov khoom qub, yog li cov txheej txheem no siv `as_ref` ua ntej coj `Option` rau qhov siv rau cov nqi hauv daim tseem.
    ///
    ///
    /// [`map`]: Option::map
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// ```
    /// let text: Option<String> = Some("Hello, world!".to_string());
    /// // Ua ntej, nrum `Option<String>` rau `Option<&String>` nrog `as_ref`, tom qab ntawd haus cov *uas* nrog `map`, tawm `text` ntawm pawg.
    /////
    /// let text_length: Option<usize> = text.as_ref().map(|s| s.len());
    /// println!("still can print text: {:?}", text);
    /// ```
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn as_ref(&self) -> Option<&T> {
        match *self {
            Some(ref x) => Some(x),
            None => None,
        }
    }

    /// Hloov pauv los ntawm `&mut Option<T>` rau `Option<&mut T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// match x.as_mut() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_mut(&mut self) -> Option<&mut T> {
        match *self {
            Some(ref mut x) => Some(x),
            None => None,
        }
    }

    /// Hloov pauv los ntawm [`Pin`] `<&Xaiv<T>>`rau`Xaiv <`[`Pin`]`<&T>>`.
    #[inline]
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn as_pin_ref(self: Pin<&Self>) -> Option<Pin<&T>> {
        // KEV RUAJ NTSEG: `x` yog guaranteed yuav tsum tau pinned vim hais tias nws los ntawm `self`
        // uas yog pinned.
        unsafe { Pin::get_ref(self).as_ref().map(|x| Pin::new_unchecked(x)) }
    }

    /// Hloov pauv los ntawm [`Pin`] `<&mut Xaiv<T>>`rau`Xaiv <`[`Pin`]`<&mut T>>`.
    #[inline]
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn as_pin_mut(self: Pin<&mut Self>) -> Option<Pin<&mut T>> {
        // KEV RUAJ NTSEG: `get_unchecked_mut` yeej tsis yog siv los txav tus `Option` sab hauv `self`.
        // `x` yog lav rau pinned vim tias nws los ntawm `self` uas yog pinned.
        unsafe { Pin::get_unchecked_mut(self).as_mut().map(|x| Pin::new_unchecked(x)) }
    }

    /////////////////////////////////////////////////////////////////////////
    // Txais kom tau rau hauv muaj nuj nqis
    /////////////////////////////////////////////////////////////////////////

    /// Rov qab cov nqi [`Some`] uas muaj, noj `self` tus nqi.
    ///
    /// # Panics
    ///
    /// Panics yog tias tus nqi yog [`None`] nrog kev cai panic xov muab los ntawm `msg`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("value");
    /// assert_eq!(x.expect("fruits are healthy"), "value");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// x.expect("fruits are healthy"); // panics with `fruits are healthy`
    /// ```
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn expect(self, msg: &str) -> T {
        match self {
            Some(val) => val,
            None => expect_failed(msg),
        }
    }

    /// Rov qab cov nqi [`Some`] uas muaj, noj `self` tus nqi.
    ///
    /// Vim tias cov haujlwm no yuav panic, nws txoj kev siv feem ntau poob siab.
    /// Hloov chaw, xum xaj siv cov qauv sib xws thiab daws teeb meem [`None`] meej meej, lossis hu [`unwrap_or`], [`unwrap_or_else`], lossis [`unwrap_or_default`].
    ///
    ///
    /// [`unwrap_or`]: Option::unwrap_or
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    /// [`unwrap_or_default`]: Option::unwrap_or_default
    ///
    /// # Panics
    ///
    /// Panics yog tus nqi nws tus kheej sib npaug [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("air");
    /// assert_eq!(x.unwrap(), "air");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// assert_eq!(x.unwrap(), "air"); // fails
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn unwrap(self) -> T {
        match self {
            Some(val) => val,
            None => panic!("called `Option::unwrap()` on a `None` value"),
        }
    }

    /// Rov qab muab cov nqi [`Some`] uas muaj lossis ib qho tshwj tseg.
    ///
    /// Cov lus sib cav kom dhau `unwrap_or` yog cov kev ntsuas siab;yog tias koj dhau ntawm qhov tshwm sim ntawm kev hu xov tooj, nws raug nquahu kom siv [`unwrap_or_else`], uas yog kev ntsuas plhu.
    ///
    ///
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(Some("car").unwrap_or("bike"), "car");
    /// assert_eq!(None.unwrap_or("bike"), "bike");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or(self, default: T) -> T {
        match self {
            Some(x) => x,
            None => default,
        }
    }

    /// Rov qab cov nqi [`Some`] uas muaj nyob lossis suav nws los ntawm kev kaw.
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 10;
    /// assert_eq!(Some(4).unwrap_or_else(|| 2 * k), 4);
    /// assert_eq!(None.unwrap_or_else(|| 2 * k), 20);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_else<F: FnOnce() -> T>(self, f: F) -> T {
        match self {
            Some(x) => x,
            None => f(),
        }
    }

    /// Rov qab cov nqi [`Some`], siv lub `self` tus nqi, tsis tas yuav kuaj xyuas tias tus nqi tsis yog [`None`].
    ///
    ///
    /// # Safety
    ///
    /// Hu tus qauv no ntawm [`None`] yog *[tus cwj pwm tsis paub]*.
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x = Some("air");
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air");
    /// ```
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Option<&str> = None;
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air"); // Tus cwj pwm tsis paub qhov tseeb!
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_unchecked(self) -> T {
        debug_assert!(self.is_some());
        match self {
            Some(val) => val,
            // KEV RUAJ NTSEG: kev ruaj ntseg daim ntawv cog lus yuav tsum tau upheld los ntawm ib tus neeg hu.
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Kev hloov pauv muaj nuj nqis
    /////////////////////////////////////////////////////////////////////////

    /// Maps tus `Option<T>` rau `Option<U>` los ntawm kev thov ua haujlwm rau ib tus nqi.
    ///
    /// # Examples
    ///
    /// Hloov kev xaiv ``<`[`txoj hlua]]>> rau hauv ib txoj kev xaiv <`[`usize`]`>, siv daim tseem:
    ///
    /// [`String`]: ../../std/string/struct.String.html
    /// ```
    /// let maybe_some_string = Some(String::from("Hello, World!"));
    /// // `Option::map` siv tus kheej *los ntawm tus nqi*, noj `maybe_some_string`
    /// let maybe_some_len = maybe_some_string.map(|s| s.len());
    ///
    /// assert_eq!(maybe_some_len, Some(13));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map<U, F: FnOnce(T) -> U>(self, f: F) -> Option<U> {
        match self {
            Some(x) => Some(f(x)),
            None => None,
        }
    }

    /// Siv kev ua haujlwm rau tus nqi uas muaj nyob (yog tias muaj), lossis rov qab muab lub neej ntawd (yog tias tsis).
    ///
    /// Cov lus sib cav kom dhau `map_or` yog cov kev ntsuas siab;yog tias koj dhau ntawm qhov tshwm sim ntawm kev hu xov tooj, nws raug nquahu kom siv [`map_or_else`], uas yog kev ntsuas plhu.
    ///
    ///
    /// [`map_or_else`]: Option::map_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.map_or(42, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or(42, |v| v.len()), 42);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_or<U, F: FnOnce(T) -> U>(self, default: U, f: F) -> U {
        match self {
            Some(t) => f(t),
            None => default,
        }
    }

    /// Siv kev ua haujlwm rau tus nqi uas muaj nyob (yog tias muaj), lossis xam lub neej ntawd (yog tias tsis yog).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 21;
    ///
    /// let x = Some("foo");
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 42);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_or_else<U, D: FnOnce() -> U, F: FnOnce(T) -> U>(self, default: D, f: F) -> U {
        match self {
            Some(t) => f(t),
            None => default(),
        }
    }

    /// Hloov cov `Option<T>` rau hauv [`Result<T, E>`], daim qhia chaw [`Some(v)`] rau [`Ok(v)`] thiab [`None`] rau [`Err(err)`].
    ///
    /// Cov lus sib cav kom dhau `ok_or` yog cov kev ntsuas siab;yog tias koj dhau ntawm qhov tshwm sim ntawm kev hu xov tooj, nws raug nquahu kom siv [`ok_or_else`], uas yog kev ntsuas plhu.
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err)`]: Err
    /// [`Some(v)`]: Some
    /// [`ok_or_else`]: Option::ok_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or(0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or(0), Err(0));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok_or<E>(self, err: E) -> Result<T, E> {
        match self {
            Some(v) => Ok(v),
            None => Err(err),
        }
    }

    /// Hloov cov `Option<T>` rau hauv [`Result<T, E>`], daim qhia chaw [`Some(v)`] rau [`Ok(v)`] thiab [`None`] rau [`Err(err())`].
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err())`]: Err
    /// [`Some(v)`]: Some
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or_else(|| 0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or_else(|| 0), Err(0));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok_or_else<E, F: FnOnce() -> E>(self, err: F) -> Result<T, E> {
        match self {
            Some(v) => Ok(v),
            None => Err(err()),
        }
    }

    /// Ntxig `value` rau hauv qhov kev xaiv xaiv ces rov qab los ua lwm yam lus siv rau nws.
    ///
    /// Yog tias qhov kev xaiv twb muaj ib tus nqi, tus nqi qub yog nqis.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(option_insert)]
    ///
    /// let mut opt = None;
    /// let val = opt.insert(1);
    /// assert_eq!(*val, 1);
    /// assert_eq!(opt.unwrap(), 1);
    /// let val = opt.insert(2);
    /// assert_eq!(*val, 2);
    /// *val = 3;
    /// assert_eq!(opt.unwrap(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "option_insert", reason = "newly added", issue = "78271")]
    pub fn insert(&mut self, value: T) -> &mut T {
        *self = Some(value);

        match self {
            Some(v) => v,
            // KEV RUAJ NTSEG: cov cai saum toj tsuas yog qhov kev xaiv nkaus xwb
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Kws txhais lus constructors
    /////////////////////////////////////////////////////////////////////////

    /// Xa rov qab rau tus ntsuas dua cov nqi muaj peev xwm.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(4);
    /// assert_eq!(x.iter().next(), Some(&4));
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.iter().next(), None);
    /// ```
    #[inline]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn iter(&self) -> Iter<'_, T> {
        Iter { inner: Item { opt: self.as_ref() } }
    }

    /// Rov qab los sib cuam tshuam tus nqi dua cov nqi muaj peev xwm.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(4);
    /// match x.iter_mut().next() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    ///
    /// let mut x: Option<u32> = None;
    /// assert_eq!(x.iter_mut().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { inner: Item { opt: self.as_mut() } }
    }

    /////////////////////////////////////////////////////////////////////////
    // Kev ua haujlwm Boolean ntawm qhov tseem ceeb, xav ua thiab tub nkeeg
    /////////////////////////////////////////////////////////////////////////

    /// Rov qab [`None`] yog tias qhov kev xaiv yog [`None`], txwv tsis pub rov `optb`.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), None);
    ///
    /// let x = Some(2);
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), Some("foo"));
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and<U>(self, optb: Option<U>) -> Option<U> {
        match self {
            Some(_) => optb,
            None => None,
        }
    }

    /// Rov qab [`None`] yog tias qhov kev xaiv yog [`None`], txwv tsis pub hu `f` nrog rau tus nqi qhwv thiab xa rov qab qhov txiaj ntsig.
    ///
    ///
    /// Qee yam lus hu rau lub lag luam no flatmap.
    ///
    /// # Examples
    ///
    /// ```
    /// fn sq(x: u32) -> Option<u32> { Some(x * x) }
    /// fn nope(_: u32) -> Option<u32> { None }
    ///
    /// assert_eq!(Some(2).and_then(sq).and_then(sq), Some(16));
    /// assert_eq!(Some(2).and_then(sq).and_then(nope), None);
    /// assert_eq!(Some(2).and_then(nope).and_then(sq), None);
    /// assert_eq!(None.and_then(sq).and_then(sq), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and_then<U, F: FnOnce(T) -> Option<U>>(self, f: F) -> Option<U> {
        match self {
            Some(x) => f(x),
            None => None,
        }
    }

    /// Rov qab [`None`] yog tias qhov kev xaiv yog [`None`], txwv tsis pub hu `predicate` nrog rau tus nqi qhwv thiab xa rov qab:
    ///
    ///
    /// - [`Some(t)`] yog `predicate` rov `true` (qhov twg `t` yog qhov qhwv nqi), thiab
    /// - [`None`] yog `predicate` rov `false`.
    ///
    /// Txoj haujlwm no ua haujlwm zoo ib yam li [`Iterator::filter()`].
    /// Koj tuaj yeem xav txog `Option<T>` ua tus ntsuas pa hla ib lossis pes tsawg lub ntsiab lus.
    /// `filter()` cia koj txiav txim siab cov ntsiab lus cia.
    ///
    /// # Examples
    ///
    /// ```rust
    /// fn is_even(n: &i32) -> bool {
    ///     n % 2 == 0
    /// }
    ///
    /// assert_eq!(None.filter(is_even), None);
    /// assert_eq!(Some(3).filter(is_even), None);
    /// assert_eq!(Some(4).filter(is_even), Some(4));
    /// ```
    ///
    /// [`Some(t)`]: Some
    ///
    #[inline]
    #[stable(feature = "option_filter", since = "1.27.0")]
    pub fn filter<P: FnOnce(&T) -> bool>(self, predicate: P) -> Self {
        if let Some(x) = self {
            if predicate(&x) {
                return Some(x);
            }
        }
        None
    }

    /// Rov qab qhov kev xaiv yog tias nws muaj tus nqi, txwv tsis pub rov `optb`.
    ///
    /// Cov lus sib cav kom dhau `or` yog cov kev ntsuas siab;yog tias koj dhau ntawm qhov tshwm sim ntawm kev hu xov tooj, nws raug nquahu kom siv [`or_else`], uas yog kev ntsuas plhu.
    ///
    ///
    /// [`or_else`]: Option::or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y = None;
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x = None;
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(100));
    ///
    /// let x = Some(2);
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = None;
    /// assert_eq!(x.or(y), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or(self, optb: Option<T>) -> Option<T> {
        match self {
            Some(_) => self,
            None => optb,
        }
    }

    /// Rov qab rau qhov kev xaiv yog tias nws muaj tus nqi, txwv tsis pub hu `f` thiab rov qhov tshwm sim.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn nobody() -> Option<&'static str> { None }
    /// fn vikings() -> Option<&'static str> { Some("vikings") }
    ///
    /// assert_eq!(Some("barbarians").or_else(vikings), Some("barbarians"));
    /// assert_eq!(None.or_else(vikings), Some("vikings"));
    /// assert_eq!(None.or_else(nobody), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or_else<F: FnOnce() -> Option<T>>(self, f: F) -> Option<T> {
        match self {
            Some(_) => self,
            None => f(),
        }
    }

    /// Rov qab [`Some`] yog tias ib qho `self`, `optb` yog [`Some`], txwv tsis pub rov [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x = Some(2);
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), None);
    /// ```
    #[inline]
    #[stable(feature = "option_xor", since = "1.37.0")]
    pub fn xor(self, optb: Option<T>) -> Option<T> {
        match (self, optb) {
            (Some(a), None) => Some(a),
            (None, Some(b)) => Some(b),
            _ => None,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Nkag mus-zoo li kev ua haujlwm los ntxig yog tias Tsis muaj thiab xa rov qab siv
    /////////////////////////////////////////////////////////////////////////

    /// Ntxig `value` rau hauv qhov kev xaiv yog tias nws yog [`None`], tom qab ntawd rov qab los qhia cov lus hloov rau cov nqi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert(5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    pub fn get_or_insert(&mut self, value: T) -> &mut T {
        self.get_or_insert_with(|| value)
    }

    /// Nkag mus rau tus nqi txiav ua ntej rau hauv qhov kev xaiv yog tias nws yog [`None`], tom qab ntawd rov qab los qhia cov lus hloov rau cov nqi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_get_or_insert_default)]
    ///
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_default();
    ///     assert_eq!(y, &0);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[unstable(feature = "option_get_or_insert_default", issue = "82901")]
    pub fn get_or_insert_default(&mut self) -> &mut T
    where
        T: Default,
    {
        self.get_or_insert_with(Default::default)
    }

    /// Ntxig tus nqi suav los ntawm `f` rau hauv qhov kev xaiv yog tias nws yog [`None`], tom qab ntawd rov qab los siv ib qho kev hloov pauv rau cov khoom muaj nqi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_with(|| 5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    pub fn get_or_insert_with<F: FnOnce() -> T>(&mut self, f: F) -> &mut T {
        if let None = *self {
            *self = Some(f());
        }

        match self {
            Some(v) => v,
            // KEV RUAJ NTSEG: tus nqi `None` rau `self` yuav hloov los ntawm `Some`
            // variant nyob rau hauv txoj cai saum toj no.
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Misc
    /////////////////////////////////////////////////////////////////////////

    /// Siv tus nqi tawm ntawm qhov kev xaiv, tawm hauv [`None`] nws qhov chaw.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, Some(2));
    ///
    /// let mut x: Option<u32> = None;
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self)
    }

    /// Hloov cov nqi tiag tiag hauv txoj kev xaiv los ntawm tus nqi muab rau hauv parameter, rov qab tus nqi qub yog tias tam sim no, tawm hauv [`Some`] nyob rau hauv nws qhov chaw tsis muaj deinitializing ib qho.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let old = x.replace(5);
    /// assert_eq!(x, Some(5));
    /// assert_eq!(old, Some(2));
    ///
    /// let mut x = None;
    /// let old = x.replace(3);
    /// assert_eq!(x, Some(3));
    /// assert_eq!(old, None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "option_replace", since = "1.31.0")]
    pub fn replace(&mut self, value: T) -> Option<T> {
        mem::replace(self, Some(value))
    }

    /// Zips `self` nrog lwm `Option`.
    ///
    /// Yog tias `self` yog `Some(s)` thiab `other` yog `Some(o)`, cov qauv no rov `Some((s, o))`.
    /// Txwv tsis pub, `None` xa rov qab.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(1);
    /// let y = Some("hi");
    /// let z = None::<u8>;
    ///
    /// assert_eq!(x.zip(y), Some((1, "hi")));
    /// assert_eq!(x.zip(z), None);
    /// ```
    #[stable(feature = "option_zip_option", since = "1.46.0")]
    pub fn zip<U>(self, other: Option<U>) -> Option<(T, U)> {
        match (self, other) {
            (Some(a), Some(b)) => Some((a, b)),
            _ => None,
        }
    }

    /// Zips `self` thiab lwm `Option` nrog kev ua haujlwm `f`.
    ///
    /// Yog tias `self` yog `Some(s)` thiab `other` yog `Some(o)`, cov qauv no rov `Some(f(s, o))`.
    /// Txwv tsis pub, `None` xa rov qab.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_zip)]
    ///
    /// #[derive(Debug, PartialEq)]
    /// struct Point {
    ///     x: f64,
    ///     y: f64,
    /// }
    ///
    /// impl Point {
    ///     fn new(x: f64, y: f64) -> Self {
    ///         Self { x, y }
    ///     }
    /// }
    ///
    /// let x = Some(17.5);
    /// let y = Some(42.7);
    ///
    /// assert_eq!(x.zip_with(y, Point::new), Some(Point { x: 17.5, y: 42.7 }));
    /// assert_eq!(x.zip_with(None, Point::new), None);
    /// ```
    #[unstable(feature = "option_zip", issue = "70086")]
    pub fn zip_with<U, F, R>(self, other: Option<U>, f: F) -> Option<R>
    where
        F: FnOnce(T, U) -> R,
    {
        Some(f(self?, other?))
    }
}

impl<T: Copy> Option<&T> {
    /// Maps ib lub `Option<&T>` rau `Option<T>` los ntawm kev luam cov ntsiab lus ntawm cov kev xaiv.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[stable(feature = "copied", since = "1.35.0")]
    pub fn copied(self) -> Option<T> {
        self.map(|&t| t)
    }
}

impl<T: Copy> Option<&mut T> {
    /// Maps ib lub `Option<&mut T>` rau `Option<T>` los ntawm kev luam cov ntsiab lus ntawm cov kev xaiv.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[stable(feature = "copied", since = "1.35.0")]
    pub fn copied(self) -> Option<T> {
        self.map(|&mut t| t)
    }
}

impl<T: Clone> Option<&T> {
    /// Daim ntawv qhia kev `Option<&T>` rau `Option<T>` los ntawm cloning cov ntsiab lus ntawm cov kev xaiv.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn cloned(self) -> Option<T> {
        self.map(|t| t.clone())
    }
}

impl<T: Clone> Option<&mut T> {
    /// Daim ntawv qhia kev `Option<&mut T>` rau `Option<T>` los ntawm cloning cov ntsiab lus ntawm cov kev xaiv.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[stable(since = "1.26.0", feature = "option_ref_mut_cloned")]
    pub fn cloned(self) -> Option<T> {
        self.map(|t| t.clone())
    }
}

impl<T: fmt::Debug> Option<T> {
    /// Noj `self` thaum uas cia siab [`None`] thiab rov tsis muaj dab tsi.
    ///
    /// # Panics
    ///
    /// Panics yog tias tus nqi yog [`Some`], nrog panic xov suav nrog rau cov kab lus dhau, thiab cov ntsiab lus ntawm [`Some`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_expect_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut squares = HashMap::new();
    /// for i in -10..=10 {
    ///     // Qhov no yuav tsis panic, vim txhua tus yuam sij yog qhov tshwj xeeb.
    ///     squares.insert(i, i * i).expect_none("duplicate key");
    /// }
    /// ```
    ///
    /// ```should_panic
    /// #![feature(option_expect_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut sqrts = HashMap::new();
    /// for i in -10..=10 {
    ///     // This will panic, since both negative and positive `i` will
    ///     // insert the same `i * i` key, returning the old `Some(i)`.
    ///     sqrts.insert(i * i, i).expect_none("duplicate key");
    /// }
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_expect_none", reason = "newly added", issue = "62633")]
    pub fn expect_none(self, msg: &str) {
        if let Some(val) = self {
            expect_none_failed(msg, &val);
        }
    }

    /// Noj `self` thaum uas cia siab [`None`] thiab rov tsis muaj dab tsi.
    ///
    /// # Panics
    ///
    /// Panics yog tias tus nqi yog [`Some`], nrog kev cai panic xov muab los ntawm [`Qee tus '] tus nqi.
    ///
    ///
    /// [`Some(v)`]: Some
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_unwrap_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut squares = HashMap::new();
    /// for i in -10..=10 {
    ///     // Qhov no yuav tsis panic, vim txhua tus yuam sij yog qhov tshwj xeeb.
    ///     squares.insert(i, i * i).unwrap_none();
    /// }
    /// ```
    ///
    /// ```should_panic
    /// #![feature(option_unwrap_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut sqrts = HashMap::new();
    /// for i in -10..=10 {
    ///     // This will panic, since both negative and positive `i` will
    ///     // insert the same `i * i` key, returning the old `Some(i)`.
    ///     sqrts.insert(i * i, i).unwrap_none();
    /// }
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_unwrap_none", reason = "newly added", issue = "62633")]
    pub fn unwrap_none(self) {
        if let Some(val) = self {
            expect_none_failed("called `Option::unwrap_none()` on a `Some` value", &val);
        }
    }
}

impl<T: Default> Option<T> {
    /// Rov qab rau cov nqi [`Some`] uas muaj los yog lub neej ntawd
    ///
    /// Consumes `self` kev sib cav ces, yog [`Some`], rov qab cov khoom muaj nqis, txwv tsis pub yog [`None`], rov [default value] rau hom ntawd.
    ///
    ///
    /// # Examples
    ///
    /// Hloov txoj hlua rau ib tus lej, hloov cov hlua tsis zoo rau hauv 0 (tus nqi qub rau kev suav).
    /// [`parse`] hloov txoj hlua ib yam rau lwm yam uas siv [`FromStr`], rov [`None`] ntawm qhov yuam kev.
    ///
    /// ```
    /// let good_year_from_input = "1909";
    /// let bad_year_from_input = "190blarg";
    /// let good_year = good_year_from_input.parse().ok().unwrap_or_default();
    /// let bad_year = bad_year_from_input.parse().ok().unwrap_or_default();
    ///
    /// assert_eq!(1909, good_year);
    /// assert_eq!(0, bad_year);
    /// ```
    ///
    /// [default value]: Default::default
    /// [`parse`]: str::parse
    /// [`FromStr`]: crate::str::FromStr
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_default(self) -> T {
        match self {
            Some(x) => x,
            None => Default::default(),
        }
    }
}

impl<T: Deref> Option<T> {
    /// Hloov siab los ntseeg los ntawm `Option<T>` (los yog `&Option<T>`) rau `Option<&T::Target>`.
    ///
    /// Tawm hauv qhov kev xaiv qhov tseem ceeb nyob rau hauv-chaw, tsim ib qho tshiab nrog kev siv rau tus thawj ib, ntxiv rau coercing cov ncauj lus ntawm [`Deref`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref(), Some("hey"));
    ///
    /// let x: Option<String> = None;
    /// assert_eq!(x.as_deref(), None);
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    pub fn as_deref(&self) -> Option<&T::Target> {
        self.as_ref().map(|t| t.deref())
    }
}

impl<T: DerefMut> Option<T> {
    /// Hloov siab los ntawm `Option<T>` (lossis `&mut Option<T>`) rau `Option<&mut T::Target>`.
    ///
    /// Tawm tus thawj `Option`-nyob rau hauv-qhov chaw, tsim lub tshiab uas muaj kev hloov pauv mus rau sab hauv hom `Deref::Target` yam.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref_mut().map(|x| {
    ///     x.make_ascii_uppercase();
    ///     x
    /// }), Some("HEY".to_owned().as_mut_str()));
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    pub fn as_deref_mut(&mut self) -> Option<&mut T::Target> {
        self.as_mut().map(|t| t.deref_mut())
    }
}

impl<T, E> Option<Result<T, E>> {
    /// Transposes `Option` ntawm [`Result`] rau [`Result`] ntawm `Option`.
    ///
    /// [`None`] yuav mapped rau [`Ok`] `(` [`Tsis Muaj]]`) `.
    /// [`Ib txhia`) `(` [`Ok`] `(_))` thiab [`Qee tus]` (`[` Err `]` (_)) `yuav mapped rau [` Ok `]` (`[` Ib txhia `)` (_)) `thiab [` Err `]` (_) `.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #[derive(Debug, Eq, PartialEq)]
    /// struct SomeErr;
    ///
    /// let x: Result<Option<i32>, SomeErr> = Ok(Some(5));
    /// let y: Option<Result<i32, SomeErr>> = Some(Ok(5));
    /// assert_eq!(x, y.transpose());
    /// ```
    #[inline]
    #[stable(feature = "transpose_result", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn transpose(self) -> Result<Option<T>, E> {
        match self {
            Some(Ok(x)) => Ok(Some(x)),
            Some(Err(e)) => Err(e),
            None => Ok(None),
        }
    }
}

// Qhov no yog cais muaj nuj nqi kom txo qhov chaws me me ntawm .expect() nws tus kheej.
#[inline(never)]
#[cold]
#[track_caller]
fn expect_failed(msg: &str) -> ! {
    panic!("{}", msg)
}

// Qhov no yog cais muaj nuj nqi kom txo qhov chaws me me ntawm .expect_none() nws tus kheej.
#[inline(never)]
#[cold]
#[track_caller]
fn expect_none_failed(msg: &str, value: &dyn fmt::Debug) -> ! {
    panic!("{}: {:?}", msg, value)
}

/////////////////////////////////////////////////////////////////////////////
// Kev ua Trait
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for Option<T> {
    #[inline]
    fn clone(&self) -> Self {
        match self {
            Some(x) => Some(x.clone()),
            None => None,
        }
    }

    #[inline]
    fn clone_from(&mut self, source: &Self) {
        match (self, source) {
            (Some(to), Some(from)) => to.clone_from(from),
            (to, from) => *to = from.clone(),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Option<T> {
    /// Rov [`None`][Option::None].
    ///
    /// # Examples
    ///
    /// ```
    /// let opt: Option<u32> = Option::default();
    /// assert!(opt.is_none());
    /// ```
    #[inline]
    fn default() -> Option<T> {
        None
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for Option<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Rov qab los siv tus ntsuas siv ntau dua tus nqi muaj peev xwm.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("string");
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert_eq!(v, ["string"]);
    ///
    /// let x = None;
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: Item { opt: self } }
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a Option<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a mut Option<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(since = "1.12.0", feature = "option_from")]
impl<T> From<T> for Option<T> {
    /// Luam tawm `val` rau hauv `Some` tshiab.
    ///
    /// # Examples
    ///
    /// ```
    /// let o: Option<u8> = Option::from(67);
    ///
    /// assert_eq!(Some(67), o);
    /// ```
    fn from(val: T) -> Option<T> {
        Some(val)
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
impl<'a, T> From<&'a Option<T>> for Option<&'a T> {
    /// Hloov pauv los ntawm `&Option<T>` rau `Option<&T>`.
    ///
    /// # Examples
    ///
    /// Hloov kev xaiv ``<`[`txoj hlua ']`>`rau hauv ib txoj kev xaiv <`[`usize`]`>, khaws cia cov qub.
    /// Tus txheej txheem [`map`] siv `self` kev sib cav los ntawm tus nqi, noj cov khoom qub, yog li cov txheej txheem no siv `as_ref` ua ntej coj `Option` rau qhov siv rau cov nqi hauv daim tseem.
    ///
    ///
    /// [`map`]: Option::map
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// ```
    /// let s: Option<String> = Some(String::from("Hello, Rustaceans!"));
    /// let o: Option<usize> = Option::from(&s).map(|ss: &String| ss.len());
    ///
    /// println!("Can still print s: {:?}", s);
    ///
    /// assert_eq!(o, Some(18));
    /// ```
    ///
    fn from(o: &'a Option<T>) -> Option<&'a T> {
        o.as_ref()
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
impl<'a, T> From<&'a mut Option<T>> for Option<&'a mut T> {
    /// Hloov pauv los ntawm `&mut Option<T>` rau `Option<&mut T>`
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = Some(String::from("Hello"));
    /// let o: Option<&mut String> = Option::from(&mut s);
    ///
    /// match o {
    ///     Some(t) => *t = String::from("Hello, Rustaceans!"),
    ///     None => (),
    /// }
    ///
    /// assert_eq!(s, Some(String::from("Hello, Rustaceans!")));
    /// ```
    fn from(o: &'a mut Option<T>) -> Option<&'a mut T> {
        o.as_mut()
    }
}

/////////////////////////////////////////////////////////////////////////////
// Kev Xaiv Tus Ntaus
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
struct Item<A> {
    opt: Option<A>,
}

impl<A> Iterator for Item<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.opt.take()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        match self.opt {
            Some(_) => (1, Some(1)),
            None => (0, Some(0)),
        }
    }
}

impl<A> DoubleEndedIterator for Item<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.opt.take()
    }
}

impl<A> ExactSizeIterator for Item<A> {}
impl<A> FusedIterator for Item<A> {}
unsafe impl<A> TrustedLen for Item<A> {}

/// Tus ntsuas hla hla siv rau [`Some`] variant ntawm ib qho [`Option`].
///
/// Tus ntsuas pa tawm ib qho nqi yog [`Option`] yog [`Some`], txwv tsis pub muaj.
///
/// Cov `struct` no yog tsim los ntawm [`Option::iter`] muaj nuj nqi.
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct Iter<'a, A: 'a> {
    inner: Item<&'a A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for Iter<'a, A> {
    type Item = &'a A;

    #[inline]
    fn next(&mut self) -> Option<&'a A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for Iter<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for Iter<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for Iter<'_, A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for Iter<'_, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Clone for Iter<'_, A> {
    #[inline]
    fn clone(&self) -> Self {
        Iter { inner: self.inner.clone() }
    }
}

/// Tus ntsuas ntsuas dua qhov hloov siv tau mus rau [`Some`] variant ntawm ib qho [`Option`].
///
/// Tus ntsuas pa tawm ib qho nqi yog [`Option`] yog [`Some`], txwv tsis pub muaj.
///
/// Cov `struct` no yog tsim los ntawm [`Option::iter_mut`] muaj nuj nqi.
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct IterMut<'a, A: 'a> {
    inner: Item<&'a mut A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for IterMut<'a, A> {
    type Item = &'a mut A;

    #[inline]
    fn next(&mut self) -> Option<&'a mut A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for IterMut<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IterMut<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IterMut<'_, A> {}
#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IterMut<'_, A> {}

/// Tus ntsuas pa hla tus nqi hauv [`Some`] variant ntawm ib qho [`Option`].
///
/// Tus ntsuas pa tawm ib qho nqi yog [`Option`] yog [`Some`], txwv tsis pub muaj.
///
/// Cov `struct` no yog tsim los ntawm [`Option::into_iter`] muaj nuj nqi.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<A> {
    inner: Item<A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Iterator for IntoIter<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> DoubleEndedIterator for IntoIter<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IntoIter<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IntoIter<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IntoIter<A> {}

/////////////////////////////////////////////////////////////////////////////
// FromIterator
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, V: FromIterator<A>> FromIterator<Option<A>> for Option<V> {
    /// Nqa txhua qhov khoom ua haujlwm hauv [`Iterator`]: yog tias nws yog [`None`][Option::None], tsis muaj cov ntsiab lus txuas ntxiv, thiab [`None`][Option::None] xa rov qab.
    /// Yuav tsum tsis muaj [`None`][Option::None] tshwm sim, ib lub taub ntim nrog qhov tseem ceeb ntawm txhua [`Option`] xa rov qab.
    ///
    /// # Examples
    ///
    /// Ntawm no yog ib qho piv txwv uas nce txhua tus lej sib npaug hauv vector.
    /// Peb siv cov ntsuas kev kuaj xyuas ntawm `add` uas rov `None` thaum qhov muab xam yuav ua rau muaj txeej.
    ///
    /// ```
    /// let items = vec![0_u16, 1, 2];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_add(1))
    ///     .collect();
    ///
    /// assert_eq!(res, Some(vec![1, 2, 3]));
    /// ```
    ///
    /// Raws li koj tuaj yeem pom, qhov no yuav rov qab qhov kev cia siab, cov khoom siv tau.
    ///
    /// Ntawm no yog lwm qhov piv txwv uas sim rho ib qho ntawm lwm daim ntawv teev tus naj npawb, lub sij hawm no kuaj xyuas rau underflow:
    ///
    /// ```
    /// let items = vec![2_u16, 1, 0];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_sub(1))
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// ```
    ///
    /// Txij thaum lub caij dhau los yog xoom, nws yuav nkag mus.Yog li, qhov txiaj ntsig tau yog `None`.
    ///
    /// Ntawm no yog qhov sib txawv ntawm qhov ua piv txwv dhau los, uas qhia tias tsis muaj cov ntsiab lus txuas ntxiv los ntawm `iter` tom qab thawj `None`.
    ///
    /// ```
    /// let items = vec![3_u16, 2, 1, 10];
    ///
    /// let mut shared = 0;
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| { shared += x; x.checked_sub(2) })
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// assert_eq!(shared, 6);
    /// ```
    ///
    /// Txij li thaum lub caij thib peb ua rau muaj kev nkag, tsis muaj cov ntsiab lus ntxiv tau coj mus, yog li tus nqi kawg ntawm `shared` yog 6 (= `3 + 2 + 1`), tsis yog 16.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn from_iter<I: IntoIterator<Item = Option<A>>>(iter: I) -> Option<V> {
        // FIXME(#11084): Qhov no tuaj yeem hloov nrog Iterator::scan thaum cov kab kev ua haujlwm no raug kaw.
        //

        iter.into_iter().map(|x| x.ok_or(())).collect::<Result<_, _>>().ok()
    }
}

/// Qhov yuam kev yam uas tshwm sim los ntawm kev thov cov neeg sim (`?`) rau `None` tus nqi.
/// Yog tias koj xav tso cai `x?` (qhov twg `x` yog `Option<T>`) hloov pauv rau koj hom kev ua yuam kev, koj tuaj yeem siv `impl From<NoneError>` rau `YourErrorType`.
///
/// Ua li ntawd, `x?` nyob rau hauv txoj haujlwm uas rov `Result<_, YourErrorType>` yuav txhais tus nqi `None` rau hauv `Err` qhov tshwm sim.
#[rustc_diagnostic_item = "none_error"]
#[unstable(feature = "try_trait", issue = "42327")]
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
pub struct NoneError;

#[unstable(feature = "try_trait", issue = "42327")]
impl<T> ops::Try for Option<T> {
    type Ok = T;
    type Error = NoneError;

    #[inline]
    fn into_result(self) -> Result<T, NoneError> {
        self.ok_or(NoneError)
    }

    #[inline]
    fn from_ok(v: T) -> Self {
        Some(v)
    }

    #[inline]
    fn from_error(_: NoneError) -> Self {
        None
    }
}

impl<T> Option<Option<T>> {
    /// Hloov pauv los ntawm `Option<Option<T>>` rau `Option<T>`
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let x: Option<Option<u32>> = Some(Some(6));
    /// assert_eq!(Some(6), x.flatten());
    ///
    /// let x: Option<Option<u32>> = Some(None);
    /// assert_eq!(None, x.flatten());
    ///
    /// let x: Option<Option<u32>> = None;
    /// assert_eq!(None, x.flatten());
    /// ```
    ///
    /// Flattening tsuas tuskheej ib theem ntawm zes ntawm ib lub sij hawm:
    ///
    /// ```
    /// let x: Option<Option<Option<u32>>> = Some(Some(Some(6)));
    /// assert_eq!(Some(Some(6)), x.flatten());
    /// assert_eq!(Some(6), x.flatten().flatten());
    /// ```
    #[inline]
    #[stable(feature = "option_flattening", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn flatten(self) -> Option<T> {
        match self {
            Some(inner) => inner,
            None => None,
        }
    }
}