//! Qias qhov tseem ceeb thiab ib-lub sij hawm pib ntawm cov ntaub ntawv zoo li qub.

use crate::cell::{Cell, UnsafeCell};
use crate::fmt;
use crate::mem;
use crate::ops::Deref;

/// Lub xovtooj ntawm uas tuaj yeem sau rau ib zaug nkaus xwb.
///
/// Tsis zoo li `RefCell`, ib tug `OnceCell` tsuas muab qhia `&T` ua tim khawv rau nws tus nqi.
/// Tsis zoo li `Cell`, ib tug `OnceCell` tsis yuav tsum tau luam los yog hloov tus nqi mus saib tau nws.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::OnceCell;
///
/// let cell = OnceCell::new();
/// assert!(cell.get().is_none());
///
/// let value: &String = cell.get_or_init(|| {
///     "Hello, World!".to_string()
/// });
/// assert_eq!(value, "Hello, World!");
/// assert!(cell.get().is_some());
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct OnceCell<T> {
    // Invariant: sau ntawv mus rau ntawm feem ntau ib zaug.
    inner: UnsafeCell<Option<T>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> Default for OnceCell<T> {
    fn default() -> Self {
        Self::new()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug> fmt::Debug for OnceCell<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.get() {
            Some(v) => f.debug_tuple("OnceCell").field(v).finish(),
            None => f.write_str("OnceCell(Uninit)"),
        }
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Clone> Clone for OnceCell<T> {
    fn clone(&self) -> OnceCell<T> {
        let res = OnceCell::new();
        if let Some(value) = self.get() {
            match res.set(value.clone()) {
                Ok(()) => (),
                Err(_) => unreachable!(),
            }
        }
        res
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: PartialEq> PartialEq for OnceCell<T> {
    fn eq(&self, other: &Self) -> bool {
        self.get() == other.get()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Eq> Eq for OnceCell<T> {}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> From<T> for OnceCell<T> {
    fn from(value: T) -> Self {
        OnceCell { inner: UnsafeCell::new(Some(value)) }
    }
}

impl<T> OnceCell<T> {
    /// Tsim lub khoob tshiab.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new() -> OnceCell<T> {
        OnceCell { inner: UnsafeCell::new(None) }
    }

    /// Tau txais kev siv rau qhov pib muaj nqis.
    ///
    /// Rov `None` yog hais tias tus cell yog empty.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get(&self) -> Option<&T> {
        // KEV RUAJ NTSEG: Safe vim 'inner` lub invariant
        unsafe { &*self.inner.get() }.as_ref()
    }

    /// Tau lub mutable siv rau lwm tus nqi.
    ///
    /// Rov `None` yog hais tias tus cell yog empty.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_mut(&mut self) -> Option<&mut T> {
        // KEV RUAJ NTSEG: Safe vim hais tias peb muaj cim nkag
        unsafe { &mut *self.inner.get() }.as_mut()
    }

    /// Poob lawm tus txheem ntawm lub cell rau `value`.
    ///
    /// # Errors
    ///
    /// Cov qauv no rov `Ok(())` yog tias lub xovtooj ntawm qhov khoob thiab `Err(value)` yog tias nws puv.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert!(cell.get().is_none());
    ///
    /// assert_eq!(cell.set(92), Ok(()));
    /// assert_eq!(cell.set(62), Err(62));
    ///
    /// assert!(cell.get().is_some());
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn set(&self, value: T) -> Result<(), T> {
        // KEV RUAJ NTSEG: Muaj kev nyab xeeb vim tias peb tsis tuaj yeem muaj qiv qiv sib cuam tshuam tau
        let slot = unsafe { &*self.inner.get() };
        if slot.is_some() {
            return Err(value);
        }

        // KEV RUAJ NTSEG: Qhov no yog qhov chaw uas peb teem lub qhov, tsis muaj haiv neeg
        // vim reentrancy/concurrency yog ua tau, thiab peb twb soj ntsuam uas qhov yog tam sim no `None`, yog li no sau koom tes rau 'inner` lub invariant.
        //
        //
        let slot = unsafe { &mut *self.inner.get() };
        *slot = Some(value);
        Ok(())
    }

    /// Tau txais cov ntsiab lus ntawm tes, pib nws nrog `f` yog tias lub xov tooj ntawm khoob.
    ///
    /// # Panics
    ///
    /// Yog hais tias `f` panics, lub panic yog propagated mus rau ib tus neeg hu, thiab cov cell tseem uninitialized.
    ///
    ///
    /// Nws yog ib qho kev ua yuam kev rau reentrantly initialize lub cell los ntawm `f`.Ua li ntawd tau nyob rau hauv ib tug panic.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// let value = cell.get_or_init(|| 92);
    /// assert_eq!(value, &92);
    /// let value = cell.get_or_init(|| unreachable!());
    /// assert_eq!(value, &92);
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_init<F>(&self, f: F) -> &T
    where
        F: FnOnce() -> T,
    {
        match self.get_or_try_init(|| Ok::<T, !>(f())) {
            Ok(val) => val,
        }
    }

    /// Tau txais cov ntsiab lus ntawm tes, pib nws nrog `f` yog tias lub xov tooj ntawm khoob.
    /// Yog tias lub xovtooj ntawm khoob thiab `f` ua tsis tiav, ib qho kev ua yuam kev rov qab.
    ///
    /// # Panics
    ///
    /// Yog hais tias `f` panics, lub panic yog propagated mus rau ib tus neeg hu, thiab cov cell tseem uninitialized.
    ///
    ///
    /// Nws yog ib qho kev ua yuam kev rau reentrantly initialize lub cell los ntawm `f`.Ua li ntawd tau nyob rau hauv ib tug panic.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert_eq!(cell.get_or_try_init(|| Err(())), Err(()));
    /// assert!(cell.get().is_none());
    /// let value = cell.get_or_try_init(|| -> Result<i32, ()> {
    ///     Ok(92)
    /// });
    /// assert_eq!(value, Ok(&92));
    /// assert_eq!(cell.get(), Some(&92))
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_try_init<F, E>(&self, f: F) -> Result<&T, E>
    where
        F: FnOnce() -> Result<T, E>,
    {
        if let Some(val) = self.get() {
            return Ok(val);
        }
        let val = f()?;
        // Nco ntsoov tias *ib co* ntaub ntawv ntawm reentrant initialization yuav ua rau UB (saib `reentrant_init` test).
        // Kuv ntseeg tias tsuas yog tshem tawm cov `assert` no, thaum khaws `set/get` yuav zoo, tab sis nws zoo li panic, ntau dua li ntsiag to siv tus nqi qub.
        //
        //
        assert!(self.set(val).is_ok(), "reentrant init");
        Ok(self.get().unwrap())
    }

    /// Kov lub cell, rov qab rau hauv lub qhwv tus nqi.
    ///
    /// Rov `None` yog hais tias tus cell yog empty.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.into_inner(), None);
    ///
    /// let cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.into_inner(), Some("hello".to_string()));
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn into_inner(self) -> Option<T> {
        // Vim hais tias `into_inner` yuav siv sij hawm `self` los ntawm tus nqi, cov compiler statically ntsuam xyuas hais tias nws yog tam sim no tsis borrowed.
        // Yog li nws muaj kev ruaj ntseg txav tawm `Option<T>`.
        self.inner.into_inner()
    }

    /// Yuav siv sij hawm tus nqi ntawm no `OnceCell`, nws tsiv mus nyob rov qab mus rau ib tug uninitialized lub xeev.
    ///
    /// Muaj tsis muaj cov nyhuv thiab rov `None` yog hais tias tus `OnceCell` tsis tau initialized.
    ///
    /// Kev Nyab Xeeb yog guaranteed los ntawm tau ib tug mutable siv.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let mut cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.take(), None);
    ///
    /// let mut cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.take(), Some("hello".to_string()));
    /// assert_eq!(cell.get(), None);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self).into_inner()
    }
}

/// Tus nqi uas yog initialized rau tus thawj saib.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::Lazy;
///
/// let lazy: Lazy<i32> = Lazy::new(|| {
///     println!("initializing");
///     92
/// });
/// println!("ready");
/// println!("{}", *lazy);
/// println!("{}", *lazy);
///
/// // Prints:
/// //   npaj txhij pib
/////
/// //   92
/// //   92
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct Lazy<T, F = fn() -> T> {
    cell: OnceCell<T>,
    init: Cell<Option<F>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug, F> fmt::Debug for Lazy<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Lazy").field("cell", &self.cell).field("init", &"..").finish()
    }
}

impl<T, F> Lazy<T, F> {
    /// Tsim ib tug tshiab tub nkeeg tus nqi nrog rau cov muab initializing muaj nuj nqi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// # fn main() {
    /// use std::lazy::Lazy;
    ///
    /// let hello = "Hello, World!".to_string();
    ///
    /// let lazy = Lazy::new(|| hello.to_uppercase());
    ///
    /// assert_eq!(&*lazy, "HELLO, WORLD!");
    /// # }
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new(init: F) -> Lazy<T, F> {
        Lazy { cell: OnceCell::new(), init: Cell::new(Some(init)) }
    }
}

impl<T, F: FnOnce() -> T> Lazy<T, F> {
    /// Rog qhov kev tshuaj ntsuam ntawm no tub nkeeg tus nqi thiab rov ib tug siv mus rau lub txiaj ntsim.
    ///
    ///
    /// Qhov no yog sib npaug rau `Deref` impl, tab sis yog qhia tau meej heev.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::Lazy;
    ///
    /// let lazy = Lazy::new(|| 92);
    ///
    /// assert_eq!(Lazy::force(&lazy), &92);
    /// assert_eq!(&*lazy, &92);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn force(this: &Lazy<T, F>) -> &T {
        this.cell.get_or_init(|| match this.init.take() {
            Some(f) => f(),
            None => panic!("`Lazy` instance has previously been poisoned"),
        })
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T, F: FnOnce() -> T> Deref for Lazy<T, F> {
    type Target = T;
    fn deref(&self) -> &T {
        Lazy::force(self)
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Default> Default for Lazy<T> {
    /// Tsim ib tug tshiab tub nkeeg tus nqi siv `Default` li cov initializing muaj nuj nqi.
    fn default() -> Lazy<T> {
        Lazy::new(T::default)
    }
}