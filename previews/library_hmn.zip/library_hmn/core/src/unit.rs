use crate::iter::FromIterator;

/// Khoom nqa tag nrho cov khoom siv los ntawm tus tsim rau ib qho.
///
/// Qhov no yog pab tau ntau thaum tag nrho nrog rau ntau dua-theem abstractions, zoo li sau mus rau ib tug `Result<(), E>` qhov twg koj tsuas pab txog uas tsis:
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}