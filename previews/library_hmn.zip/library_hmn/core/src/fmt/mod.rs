//! Utilities rau formatting thiab luam cov hlua.

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::{Cell, Ref, RefCell, RefMut, UnsafeCell};
use crate::marker::PhantomData;
use crate::mem;
use crate::num::flt2dec;
use crate::ops::Deref;
use crate::result;
use crate::str;

mod builders;
mod float;
mod num;

#[stable(feature = "fmt_flags_align", since = "1.28.0")]
/// Muaj kev hloov pauv tau rov qab los ntawm `Formatter::align`
#[derive(Debug)]
pub enum Alignment {
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Hais txog hais tias txheem yuav tsum tau sab laug-raws li.
    Left,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Qhia txog tias cov ncauj lus yuav tsum yog ua raws li sab xis.
    Right,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Hais txog hais tias txheem yuav tsum center-raws li.
    Center,
}

#[stable(feature = "debug_builders", since = "1.2.0")]
pub use self::builders::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};

#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub mod rt {
    pub mod v1;
}

/// Lub hom rov qab los ntawm formatter txoj kev.
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// #[derive(Debug)]
/// struct Triangle {
///     a: f32,
///     b: f32,
///     c: f32
/// }
///
/// impl fmt::Display for Triangle {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {}, {})", self.a, self.b, self.c)
///     }
/// }
///
/// let pythagorean_triple = Triangle { a: 3.0, b: 4.0, c: 5.0 };
///
/// assert_eq!(format!("{}", pythagorean_triple), "(3, 4, 5)");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub type Result = result::Result<(), Error>;

/// Hom kev ua yuam kev uas tau xa rov qab los ntawm kev xaiv ib kab lus rau hauv dej.
///
/// Qhov no hom tsis txhawb kis tau tus mob ntawm ib qho kev ua yuam kev uas tsis yog hais tias ib tug yuam kev tshwm sim.
/// Tej ntxiv ntaub ntawv yuav tsum tau npaj rau kis tau los ntawm ib co lwm yam txhais tau tias.
///
/// Ib qho tseem ceeb uas yuav tsum nco ntsoov yog tias hom `fmt::Error` yuav tsum tsis txhob tso siab rau [`std::io::Error`] lossis [`std::error::Error`], uas koj kuj tseem yuav muaj nyob hauv qhov ntsuas.
///
///
/// [`std::io::Error`]: ../../std/io/struct.Error.html
/// [`std::error::Error`]: ../../std/error/trait.Error.html
///
/// # Examples
///
/// ```rust
/// use std::fmt::{self, write};
///
/// let mut output = String::new();
/// if let Err(fmt::Error) = write(&mut output, format_args!("Hello {}!", "world")) {
///     panic!("An error occurred");
/// }
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Default, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct Error;

/// Ib tug trait rau sau ntawv los yog formatting rau hauv Unicode-txais buffers los yog kwj.
///
/// Qhov trait tsuas yog lees txais UTF-8 - cov ntaub ntawv encoded thiab tsis yog [flushable].
/// Yog hais tias koj tsuas xav mus txais Unicode thiab koj ua tsis tau yuav tsum tau yaug kais dej, koj yuav tsum tau siv no trait;
/// txwv tsis pub koj yuav tsum siv [`std::io::Write`].
///
/// [`std::io::Write`]: ../../std/io/trait.Write.html
/// [flushable]: ../../std/io/trait.Write.html#tymethod.flush
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Write {
    /// Sau ib txoj hlua txiav rau hauv tus kws sau ntawv no, rov qab seb qhov sau ntawv ua tiav.
    ///
    /// Txoj kev no tuaj yeem ua tiav tau yog tias tag nrho cov hlua hlais tau ua tiav sau tiav, thiab hom no yuav tsis rov qab kom txog thaum tag nrho cov ntaub ntawv tau sau cia lossis muaj qhov ua yuam kev.
    ///
    ///
    /// # Errors
    ///
    /// Txoj haujlwm no yuav rov qab ua piv txwv ntawm [`Error`] ntawm qhov yuam kev.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_str(s)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "hola").unwrap();
    /// assert_eq!(&buf, "hola");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_str(&mut self, s: &str) -> Result;

    /// Sau ib tug [`char`] rau hauv no txawj sau ntawv, rov qab seb tus sau tau zoo.
    ///
    /// Ib tug tib [`char`] tej zaum yuav kho li ntau tshaj ib tug byte.
    /// Hom no tuaj yeem ua tiav tau yog tias tag nrho cov kab ke ua tiav tau sau, thiab hom no yuav tsis rov qab kom txog thaum tag nrho cov ntaub ntawv tau sau lossis muaj qhov yuam kev.
    ///
    ///
    /// # Errors
    ///
    /// Txoj haujlwm no yuav rov qab ua piv txwv ntawm [`Error`] ntawm qhov yuam kev.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, c: char) -> Result<(), Error> {
    ///     f.write_char(c)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, 'a').unwrap();
    /// writer(&mut buf, 'b').unwrap();
    /// assert_eq!(&buf, "ab");
    /// ```
    ///
    #[stable(feature = "fmt_write_char", since = "1.1.0")]
    fn write_char(&mut self, c: char) -> Result {
        self.write_str(c.encode_utf8(&mut [0; 4]))
    }

    /// Siv ntaub nplaum rau kev pab ntawm cov [`write!`] macro nrog implementors ntawm no trait.
    ///
    /// Txoj kev no feem ntau tsis tau caw tus kheej, tab sis theej los ntawm [`write!`] macro nws tus kheej.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_fmt(format_args!("{}", s))
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "world").unwrap();
    /// assert_eq!(&buf, "world");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_fmt(mut self: &mut Self, args: Arguments<'_>) -> Result {
        write(&mut self, args)
    }
}

#[stable(feature = "fmt_write_blanket_impl", since = "1.4.0")]
impl<W: Write + ?Sized> Write for &mut W {
    fn write_str(&mut self, s: &str) -> Result {
        (**self).write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        (**self).write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        (**self).write_fmt(args)
    }
}

/// Kev teeb tsa rau lub qauv.
///
/// Ib tug `Formatter` nruab nrab ntau yam kev xaiv uas muaj feem rau formatting.
/// Cov neeg siv tsis txua cov `Formatter`s ncaj qha;ib tug mutable siv rau ib tug yog kis mus rau cov `fmt` txoj kev tag nrho formatting traits, zoo li [`Debug`] thiab [`Display`].
///
///
/// Txhawm rau cuam tshuam nrog ib tus `Formatter`, koj yuav hu rau ntau txoj kev los hloov cov ntau yam kev xaiv ntsig txog kev xaiv hom.
/// Rau piv txwv, thov mus saib cov ntaub ntawv ntawm cov kev txhais rau `Formatter` hauv qab no.
///
#[allow(missing_debug_implementations)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Formatter<'a> {
    flags: u32,
    fill: char,
    align: rt::v1::Alignment,
    width: Option<usize>,
    precision: Option<usize>,

    buf: &'a mut (dyn Write + 'a),
}

// NB.
// Sib cav no yeej tseem zoo ib optimized cov ntaub ntawv formatting muaj nuj nqi, sib npaug rau `exists T.(&T, fn(&T, &mut Formatter<'_>) -> Result`.

extern "C" {
    type Opaque;
}

/// Qhov no struct nruab nrab yog cov generic "argument" uas yog coj los ntawm cov Xprintf tsev neeg ntawm kev khiav dej num.Nws muaj ib tug muaj nuj nqi rau format muab tus nqi.
/// Thaum compile lub sij hawm nws yog ensured tias cov nuj nqi thiab tus nqi muaj qhov tseeb hom, thiab ces qhov no struct yog siv los canonicalize cov lus rau ib hom.
///
///
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub struct ArgumentV1<'a> {
    value: &'a Opaque,
    formatter: fn(&Opaque, &mut Formatter<'_>) -> Result,
}

// Qhov no guarantees ib zaug xwb ruaj khov tus nqi rau cov nuj nqi pointer txuam nrog indices/counts nyob rau hauv lub formatting infrastructure.
//
// Nco ntsoov tias lub luag haujlwm txhais tau hais tias yuav tsis raug raws li lub luag haujlwm yog ib txwm dai cim npe tsis npe_addr nrog qhov tam sim no qis rau LLVM IR, yog li lawv qhov chaw nyob tsis suav tias yog ib qho tseem ceeb rau LLVM thiab xws li as_usize cam khwb cia tuaj yeem ua tsis raug.
//
// Hauv kev coj ua, peb yeej tsis hu as_usize ntawm tsis siv cov muaj cov ntaub ntawv (qhov teeb meem zoo li qub tiam ntawm cov qauv kev sib cav), yog li qhov no tsuas yog kev kuaj xyuas ntxiv.
//
// Peb feem ntau xav kom xyuas kom meej tias cov nuj nqi pointer ntawm `USIZE_MARKER` muaj ib qho chaw nyob sib nug xov *xwb* zog uas tau siv sij hawm `&usize` raws li lawv cov thawj sib cav.
// Lub read_volatile no kom hais tias peb yuav tau xyuam xim npaj tawm ib usize los ntawm lub dhau siv thiab hais tias qhov chaw nyob no tsis taw tes rau ib tug uas tsis yog-usize kev muaj nuj nqi.
//
//
//
//
//
//
//
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
static USIZE_MARKER: fn(&usize, &mut Formatter<'_>) -> Result = |ptr, _| {
    // KEV RUAJ NTSEG: ptr yog qhov siv
    let _v: usize = unsafe { crate::ptr::read_volatile(ptr) };
    loop {}
};

impl<'a> ArgumentV1<'a> {
    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new<'b, T>(x: &'b T, f: fn(&T, &mut Formatter<'_>) -> Result) -> ArgumentV1<'b> {
        // KEV RUAJ NTSEG: `mem::transmute(x)` muaj kev ruaj ntseg vim hais tias
        //     1. `&'b T` yuav lub neej nws originated nrog `'b` (thiaj li tsis muaj ib tug unbounded lub neej)
        //     2.
        //     `&'b T` thiab `&'b Opaque` muaj tib lub cim xeeb (thaum `T` yog `Sized`, raws li nws nyob ntawm no) `mem::transmute(f)` muaj kev nyab xeeb vim `fn(&T, &mut Formatter<'_>) -> Result` thiab `fn(&Opaque, &mut Formatter<'_>) -> Result` muaj tib lub ABI (ntev li `T` yog `Sized`)
        //
        //
        //
        //
        unsafe { ArgumentV1 { formatter: mem::transmute(f), value: mem::transmute(x) } }
    }

    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn from_usize(x: &usize) -> ArgumentV1<'_> {
        ArgumentV1::new(x, USIZE_MARKER)
    }

    fn as_usize(&self) -> Option<usize> {
        if self.formatter as usize == USIZE_MARKER as usize {
            // KEV RUAJ NTSEG: Lub `formatter` teb no yog tsuas teem rau USIZE_MARKER yog
            // tus nqi yog ib tug usize, yog li no muaj kev ruaj ntseg
            Some(unsafe { *(self.value as *const _ as *const usize) })
        } else {
            None
        }
    }
}

// chij muaj nyob rau hauv lub v1 cov hom ntawv uas format_args
#[derive(Copy, Clone)]
enum FlagV1 {
    SignPlus,
    SignMinus,
    Alternate,
    SignAwareZeroPad,
    DebugLowerHex,
    DebugUpperHex,
}

impl<'a> Arguments<'a> {
    /// Thaum uas siv cov format_args! () Macro, qhov no muaj nuj nqi yog siv los ua kom cov nqe lus qauv.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1(pieces: &'a [&'static str], args: &'a [ArgumentV1<'a>]) -> Arguments<'a> {
        Arguments { pieces, fmt: None, args }
    }

    /// Txoj haujlwm no raug siv los qhia qhov tsis ua lub qauv tsis raug.
    /// Lub `pieces` array yuav tsum muaj tsawg kawg yog li ntev raws li `fmt` los mus tsim ib tug siv tau cov lus sib cav qauv.
    /// Tsis tas li, txhua `Count` hauv `fmt` uas yog `CountIsParam` lossis `CountIsNextParam` yuav tsum taw tes rau qhov kev sib cav tsim nrog `argumentusize`.
    ///
    /// Txawm li cas los, tsis ua li ntawd tsis ua unsafety, tab sis yuav las mees invalid.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1_formatted(
        pieces: &'a [&'static str],
        args: &'a [ArgumentV1<'a>],
        fmt: &'a [rt::v1::Argument],
    ) -> Arguments<'a> {
        Arguments { pieces, fmt: Some(fmt), args }
    }

    /// Kwv yees qhov ntev ntawm cov ntawv nyeem.
    ///
    /// Qhov no yog npaj los siv rau kev teeb tsa lub peev xwm pib `String` thaum siv `format!`.
    /// Note: qhov no tsis yog tus twg qis dua los yog sab sauv.
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn estimated_capacity(&self) -> usize {
        let pieces_length: usize = self.pieces.iter().map(|x| x.len()).sum();

        if self.args.is_empty() {
            pieces_length
        } else if self.pieces[0] == "" && pieces_length < 16 {
            // Yog tias txoj hlua hom pib nrog kev sib cav, tsis txhob txwv dab tsi, tshwj tsis yog tias ntev ntawm cov ntawv yog qhov tseem ceeb.
            //
            //
            0
        } else {
            // Muaj ib co nqe lus, yog li tej yam ntxiv laub yuav reallocate txoj hlua.
            //
            // Txhawm rau zam qhov ntawd, peb nyob nraum "pre-doubling" qhov muaj peev xwm ntawm no.
            pieces_length.checked_mul(2).unwrap_or(0)
        }
    }
}

/// Qhov no qauv nruab nrab yog ib tug xyuam xim precompiled version ntawm ib hom hlua thiab nws cov nqe lus.
/// Qhov no tsis tuaj yeem tsim tawm thaum runtime vim tias nws tsis tuaj yeem muaj kev nyab xeeb, yog li tsis muaj cov kws tsim tsa tau thiab cov chaw yuav ntiag tug los tiv thaiv kev hloov kho.
///
///
/// Lub [`format_args!`] macro yuav xyuam xim ua ib tug piv txwv ntawm cov qauv no.
/// Lub macro validates lub hom hlua ntawm compile-lub sij hawm kom pab ntawm lub [`write()`] thiab [`format()`] zog yuav xyuam xim ua.
///
/// Koj tuaj yeem siv `Arguments<'a>` uas [`format_args!`] xa rov qab rau hauv `Debug` thiab `Display` cov ntsiab lus raws li pom hauv qab no.
/// Cov piv txwv kuj qhia tau hais tias `Debug` thiab `Display` hom mus rau qhov qub: lub interpolated hom hlua nyob rau hauv `format_args!`.
///
/// ```rust
/// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
/// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
/// assert_eq!("1 foo 2", display);
/// assert_eq!(display, debug);
/// ```
///
/// [`format()`]: ../../std/fmt/fn.format.html
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone)]
pub struct Arguments<'a> {
    // Hom ntawv txoj hlua los luam.
    pieces: &'a [&'static str],

    // Placeholder specs, los yog `None` hais tias tag nrho specs yog neej ntawd (raws li nyob rau hauv "{}{}").
    fmt: Option<&'a [rt::v1::Argument]>,

    // Dynamic sib ceg rau interpolation, yuav tsum tau interleaved nrog txoj hlua daim.
    // (Txhua sib cav yog preceded by ib txoj hlua piece.)
    args: &'a [ArgumentV1<'a>],
}

impl<'a> Arguments<'a> {
    /// Tau txais txoj hlua ua lag luam, yog tias nws tsis muaj kev sib cav los ua hom.
    ///
    /// Qhov no yuav siv tau los tsis txhob nyiaj nyob rau hauv lub feem ntau tsis tseem ceeb cov ntaub ntawv.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt::Arguments;
    ///
    /// fn write_str(_: &str) { /* ... */ }
    ///
    /// fn write_fmt(args: &Arguments) {
    ///     if let Some(s) = args.as_str() {
    ///         write_str(s)
    ///     } else {
    ///         write_str(&args.to_string());
    ///     }
    /// }
    /// ```
    ///
    /// ```rust
    /// assert_eq!(format_args!("hello").as_str(), Some("hello"));
    /// assert_eq!(format_args!("").as_str(), Some(""));
    /// assert_eq!(format_args!("{}", 1).as_str(), None);
    /// ```
    #[stable(feature = "fmt_as_str", since = "1.52.0")]
    #[inline]
    pub fn as_str(&self) -> Option<&'static str> {
        match (self.pieces, self.args) {
            ([], []) => Some(""),
            ([s], []) => Some(s),
            _ => None,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        Display::fmt(self, fmt)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        write(fmt.buf, *self)
    }
}

/// `?` formatting.
///
/// `Debug` yuav tsum tawm tswv yim tawm qhov tso zis hauv qhov programmer-ntsib, debugging cov ntsiab lus teb.
///
/// Feem ntau hais lus, koj yuav tsum cia li `derive` ib `Debug` siv.
///
/// Thaum siv nrog lwm tus txheej txheem qhia ntsuas `#?`, qhov tso zis tawm zoo nkauj.
///
/// Yog xav paub cov ntaub ntawv ntau ntxiv ntawm cov formatters, saib [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// Qhov no trait yuav siv tau nrog `#[derive]` hais tias tag nrho teb siv `Debug`.
/// Thaum `derive`d rau kev teeb tsa, nws yuav siv lub npe ntawm `struct`, tom qab ntawd `{`, tom qab ntawd daim ntawv teev sau los ntawm txhua daim teb lub npe thiab tus nqi `Debug`, tom qab ntawd `}`.
/// Rau `enum`s, nws yuav siv lub npe ntawm cov sib txawv thiab, yog tias tsim nyog, `(`, tom qab ntawd `Debug` tus nqi ntawm lub teb, tom qab ntawd `)`.
///
/// # Stability
///
/// Muab `Debug` tawm tswv yim no tsis ruaj khov, thiab thiaj li yuav hloov nrog future Rust versions.
/// Tsis tas li ntawd, `Debug` implementations ntawm hom yog muab los ntawm tus txheej txheem tsev qiv ntawv ('libstd`, `libcore`, `liballoc`, etc.) yog tsis ruaj khov, thiab tej zaum yuav tau hloov nrog future Rust versions.
///
///
/// # Examples
///
/// Ua raws kev siv:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// Manually siv:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Debug for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         f.debug_struct("Point")
///          .field("x", &self.x)
///          .field("y", &self.y)
///          .finish()
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// Muaj ntau tus txheej txheem ntawm cov neeg pabcuam rau ntawm [`Formatter`] tus txheej txheem los pab koj nrog kev siv ua kev tuav, xws li [`debug_struct`].
///
/// `Debug` kev siv siv `derive` lossis debug builder API ntawm [`Formatter`] txhawb zoo nkauj-luam ntawv siv lwm tus chij: `{:#?}`.
///
/// [`debug_struct`]: Formatter::debug_struct
///
/// Zoo nkauj-luam nrog `#?`:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:#?}", origin),
/// "The origin is: Point {
///     x: 0,
///     y: 0,
/// }");
/// ```
///
///
///
///
///

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        crate_local,
        label = "`{Self}` cannot be formatted using `{{:?}}`",
        note = "add `#[derive(Debug)]` or manually implement `{Debug}`"
    ),
    message = "`{Self}` doesn't implement `{Debug}`",
    label = "`{Self}` cannot be formatted using `{{:?}}` because it doesn't implement `{Debug}`"
)]
#[doc(alias = "{:?}")]
#[rustc_diagnostic_item = "debug_trait"]
pub trait Debug {
    /// Tswv yim rau cov nqi uas siv tus muab formatter.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Debug for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         f.debug_tuple("")
    ///          .field(&self.longitude)
    ///          .field(&self.latitude)
    ///          .finish()
    ///     }
    /// }
    ///
    /// let position = Position { longitude: 1.987, latitude: 2.983 };
    /// assert_eq!(format!("{:?}", position), "(1.987, 2.983)");
    ///
    /// assert_eq!(format!("{:#?}", position), "(
    ///     1.987,
    ///     2.983,
    /// )");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

// Qhov txawv ntawm cov module los rov ua dua macro `Debug` los ntawm prelude tsis muaj trait `Debug`.
pub(crate) mod macros {
    /// Muab cov ntawv loj heev los tsim cov qog ntawm trait `Debug`.
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Debug($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Debug;

/// Format trait rau ib qho kev npliag hom ntawv, `{}`.
///
/// `Display` yog zoo li [`Debug`], tab sis `Display` yog rau cov neeg siv-txojkev tso zis, thiab thiaj li tsis tau muab tau.
///
///
/// Yog xav paub cov ntaub ntawv ntau ntxiv ntawm cov formatters, saib [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Siv `Display` rau ib hom:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Display for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {})", self.x, self.y)
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {}", origin), "The origin is: (0, 0)");
/// ```
#[rustc_on_unimplemented(
    on(
        _Self = "std::path::Path",
        label = "`{Self}` cannot be formatted with the default formatter; call `.display()` on it",
        note = "call `.display()` or `.to_string_lossy()` to safely print paths, \
                as they may contain non-Unicode data"
    ),
    message = "`{Self}` doesn't implement `{Display}`",
    label = "`{Self}` cannot be formatted with the default formatter",
    note = "in format strings you may be able to use `{{:?}}` (or {{:#?}} for pretty-print) instead"
)]
#[doc(alias = "{}")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Display {
    /// Tswv yim rau cov nqi uas siv tus muab formatter.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Display for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         write!(f, "({}, {})", self.longitude, self.latitude)
    ///     }
    /// }
    ///
    /// assert_eq!("(1.987, 2.983)",
    ///            format!("{}", Position { longitude: 1.987, latitude: 2.983, }));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `o` formatting.
///
/// Lub `Octal` trait yuav tsum tawm suab nws cov zis ua tus lej hauv base-8.
///
/// Rau txheej thaum ub kos npe zauv (`i8` rau `i128`, thiab `isize`), tsis zoo qhov tseem ceeb yog formatted li ob lub complement sawv cev.
///
///
/// Tus chij lwm txoj, `#`, ntxiv ib `0o` nyob rau pem hauv ntej ntawm cov zis.
///
/// Yog xav paub cov ntaub ntawv ntau ntxiv ntawm cov formatters, saib [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Kev siv theem pib nrog `i32`:
///
/// ```
/// let x = 42; // 42 yog '52' nyob rau hauv octal
///
/// assert_eq!(format!("{:o}", x), "52");
/// assert_eq!(format!("{:#o}", x), "0o52");
///
/// assert_eq!(format!("{:o}", -16), "37777777760");
/// ```
///
/// Kev siv `Octal` ntawm ib hom:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Octal for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Octal::fmt(&val, f) // tus sawv cev rau i32 kev nqis tes ua
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as octal is: {:o}", l), "l as octal is: 11");
///
/// assert_eq!(format!("l as octal is: {:#06o}", l), "l as octal is: 0o0011");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Octal {
    /// Tswv yim rau cov nqi uas siv tus muab formatter.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `b` formatting.
///
/// `Binary` trait yuav tsum tawm suab nws cov zis ua tus lej hauv binary.
///
/// Rau thawj daim ntawv xee npe ua haujlwm ([`i8`] rau [`i128`], thiab [`isize`]), cov txiaj ntsig tsis zoo raug teeb tsa raws li ob qho kev ua kom tiav cov sawv cev.
///
///
/// Tus tso chij, `#`, ntxiv ib `0b` nyob rau hauv pem hauv ntej ntawm lub qhov zis.
///
/// Yog xav paub cov ntaub ntawv ntau ntxiv ntawm cov formatters, saib [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Basic pab nrog [`i32`]:
///
/// ```
/// let x = 42; // 42 yog '101010' hauv binary
///
/// assert_eq!(format!("{:b}", x), "101010");
/// assert_eq!(format!("{:#b}", x), "0b101010");
///
/// assert_eq!(format!("{:b}", -16), "11111111111111111111111111110000");
/// ```
///
/// Kev siv `Binary` ntawm ib hom:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Binary for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Binary::fmt(&val, f) // tus sawv cev rau i32 kev nqis tes ua
///     }
/// }
///
/// let l = Length(107);
///
/// assert_eq!(format!("l as binary is: {:b}", l), "l as binary is: 1101011");
///
/// assert_eq!(
///     format!("l as binary is: {:#032b}", l),
///     "l as binary is: 0b000000000000000000000001101011"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Binary {
    /// Tswv yim rau cov nqi uas siv tus muab formatter.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `x` formatting.
///
/// Lub `LowerHex` trait yuav tsum format nws tso zis li ib tug xov tooj nyob rau hauv hexadecimal, nrog `a` los ntawm `f` nyob rau hauv qis cov ntaub ntawv.
///
/// Rau txheej thaum ub kos npe zauv (`i8` rau `i128`, thiab `isize`), tsis zoo qhov tseem ceeb yog formatted li ob lub complement sawv cev.
///
///
/// Tus chij lwm txoj, `#`, ntxiv ib `0x` nyob rau pem hauv ntej ntawm cov zis.
///
/// Yog xav paub cov ntaub ntawv ntau ntxiv ntawm cov formatters, saib [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Kev siv theem pib nrog `i32`:
///
/// ```
/// let x = 42; // 42 yog '2a' hauv hex
///
/// assert_eq!(format!("{:x}", x), "2a");
/// assert_eq!(format!("{:#x}", x), "0x2a");
///
/// assert_eq!(format!("{:x}", -16), "fffffff0");
/// ```
///
/// Siv `LowerHex` rau ib hom:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::LowerHex::fmt(&val, f) // tus sawv cev rau i32 kev nqis tes ua
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as hex is: {:x}", l), "l as hex is: 9");
///
/// assert_eq!(format!("l as hex is: {:#010x}", l), "l as hex is: 0x00000009");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerHex {
    /// Tswv yim rau cov nqi uas siv tus muab formatter.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `X` formatting.
///
/// `UpperHex` trait yuav tsum tawm suab nws cov zis ua tus lej hauv hexadecimal, nrog `A` txog `F` hauv cov ntawv loj.
///
/// Rau txheej thaum ub kos npe zauv (`i8` rau `i128`, thiab `isize`), tsis zoo qhov tseem ceeb yog formatted li ob lub complement sawv cev.
///
///
/// Tus chij lwm txoj, `#`, ntxiv ib `0x` nyob rau pem hauv ntej ntawm cov zis.
///
/// Yog xav paub cov ntaub ntawv ntau ntxiv ntawm cov formatters, saib [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Kev siv theem pib nrog `i32`:
///
/// ```
/// let x = 42; // 42 yog '2A' nyob rau hauv hex
///
/// assert_eq!(format!("{:X}", x), "2A");
/// assert_eq!(format!("{:#X}", x), "0x2A");
///
/// assert_eq!(format!("{:X}", -16), "FFFFFFF0");
/// ```
///
/// Siv `UpperHex` rau ib hom:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::UpperHex::fmt(&val, f) // tus sawv cev rau i32 kev nqis tes ua
///     }
/// }
///
/// let l = Length(i32::MAX);
///
/// assert_eq!(format!("l as hex is: {:X}", l), "l as hex is: 7FFFFFFF");
///
/// assert_eq!(format!("l as hex is: {:#010X}", l), "l as hex is: 0x7FFFFFFF");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperHex {
    /// Tswv yim rau cov nqi uas siv tus muab formatter.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `p` formatting.
///
/// `Pointer` trait yuav tsum tawm suab nws qhov tawm mus rau qhov chaw cim xeeb.
/// Qhov no yog feem ntau hais raws li hexadecimal.
///
/// Yog xav paub cov ntaub ntawv ntau ntxiv ntawm cov formatters, saib [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Basic pab nrog `&i32`:
///
/// ```
/// let x = &42;
///
/// let address = format!("{:p}", x); // no ua ib yam dab tsi zoo li '0x7f06092ac6d0'
/// ```
///
/// Kev siv `Pointer` ntawm ib hom:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Pointer for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         // siv `as` rau hloov siab los ntseeg mus rau ib tug `*const T`, uas siv Pointer, uas peb yuav siv tau
///
///         let ptr = self as *const Self;
///         fmt::Pointer::fmt(&ptr, f)
///     }
/// }
///
/// let l = Length(42);
///
/// println!("l is in memory here: {:p}", l);
///
/// let l_ptr = format!("{:018p}", l);
/// assert_eq!(l_ptr.len(), 18);
/// assert_eq!(&l_ptr[..2], "0x");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "pointer_trait"]
pub trait Pointer {
    /// Tswv yim rau cov nqi uas siv tus muab formatter.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "pointer_trait_fmt"]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `e` formatting.
///
/// Lub `LowerExp` trait yuav tsum format nws tso zis nyob rau hauv scientific cim nrog ib tug tsawg dua cov ntaub ntawv `e`.
///
/// Yog xav paub cov ntaub ntawv ntau ntxiv ntawm cov formatters, saib [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Basic pab nrog `f64`:
///
/// ```
/// let x = 42.0; // 42.0 yog '4.2e1' hauv kev sau npe rau scientific
///
/// assert_eq!(format!("{:e}", x), "4.2e1");
/// ```
///
/// Kev siv `LowerExp` ntawm ib hom:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::LowerExp::fmt(&val, f) // delegate rau f64 kev siv
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:e}", l),
///     "l in scientific notation is: 1e2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05e}", l),
///     "l in scientific notation is: 001e2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerExp {
    /// Tswv yim rau cov nqi uas siv tus muab formatter.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `E` formatting.
///
/// `UpperExp` trait yuav tsum tawm suab nws qhov kev tso tawm hauv kev sau ntawv pov thawj nrog rau sab saud `E`.
///
/// Yog xav paub cov ntaub ntawv ntau ntxiv ntawm cov formatters, saib [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Basic pab nrog `f64`:
///
/// ```
/// let x = 42.0; // 42.0 yog '4.2E1' nyob rau hauv scientific cim
///
/// assert_eq!(format!("{:E}", x), "4.2E1");
/// ```
///
/// Siv `UpperExp` rau ib hom:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::UpperExp::fmt(&val, f) // delegate rau f64 kev siv
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:E}", l),
///     "l in scientific notation is: 1E2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05E}", l),
///     "l in scientific notation is: 001E2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperExp {
    /// Tswv yim rau cov nqi uas siv tus muab formatter.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// Lub `write` muaj nuj nqi yuav siv sij hawm ib tug tso zis kwj, thiab ib tug `Arguments` struct uas yuav precompiled nrog lub `format_args!` macro.
///
///
/// Cov nqe lus yuav tsum formatted raws li cov kev cai tswjhwm hom hlua mus rau hauv lub tso zis kwj muab.
///
/// # Examples
///
/// Kev siv theem pib:
///
/// ```
/// use std::fmt;
///
/// let mut output = String::new();
/// fmt::write(&mut output, format_args!("Hello {}!", "world"))
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///
/// Thov nco ntsoov tias kev siv [`write!`] tej zaum yuav xum.Piv txwv:
///
/// ```
/// use std::fmt::Write;
///
/// let mut output = String::new();
/// write!(&mut output, "Hello {}!", "world")
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///  [`write!`]: crate::write!
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn write(output: &mut dyn Write, args: Arguments<'_>) -> Result {
    let mut formatter = Formatter {
        flags: 0,
        width: None,
        precision: None,
        buf: output,
        align: rt::v1::Alignment::Unknown,
        fill: ' ',
    };

    let mut idx = 0;

    match args.fmt {
        None => {
            // Peb yuav siv neej ntawd hais formatting tsis rau tag nrho cov nqe lus.
            for (arg, piece) in args.args.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                (arg.formatter)(arg.value, &mut formatter)?;
                idx += 1;
            }
        }
        Some(fmt) => {
            // Txhua spec muaj ib tug coj sib cav hais tias yog preceded by ib txoj hlua piece.
            //
            for (arg, piece) in fmt.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                // KEV RUAJ NTSEG: arg thiab args.args los ntawm tib lub lus,
                // uas guarantees lub indexes yeej ib txwm tsis pub dhau ciam teb.
                unsafe { run(&mut formatter, arg, &args.args) }?;
                idx += 1;
            }
        }
    }

    // Muaj yuav ua tau tsuas yog ib tug trailing hlua daim sab laug.
    if let Some(piece) = args.pieces.get(idx) {
        formatter.buf.write_str(*piece)?;
    }

    Ok(())
}

unsafe fn run(fmt: &mut Formatter<'_>, arg: &rt::v1::Argument, args: &[ArgumentV1<'_>]) -> Result {
    fmt.fill = arg.format.fill;
    fmt.align = arg.format.align;
    fmt.flags = arg.format.flags;
    // KEV RUAJ NTSEG: arg thiab args los ntawm tib lub lus,
    // uas guarantees lub indexes yeej ib txwm tsis pub dhau ciam teb.
    unsafe {
        fmt.width = getcount(args, &arg.format.width);
        fmt.precision = getcount(args, &arg.format.precision);
    }

    // Sau cov lus sib cav kom yog
    debug_assert!(arg.position < args.len());
    // KEV RUAJ NTSEG: arg thiab args los ntawm tib lub lus,
    // uas guarantees nws Performance index yog yeej ib txwm tsis pub dhau ciam teb.
    let value = unsafe { args.get_unchecked(arg.position) };

    // Tom qab ntawv ces ua qee yam luam ntawv
    (value.formatter)(value.value, fmt)
}

unsafe fn getcount(args: &[ArgumentV1<'_>], cnt: &rt::v1::Count) -> Option<usize> {
    match *cnt {
        rt::v1::Count::Is(n) => Some(n),
        rt::v1::Count::Implied => None,
        rt::v1::Count::Param(i) => {
            debug_assert!(i < args.len());
            // KEV RUAJ NTSEG: cnt thiab sib cav los ntawm tib cov lus sib cav,
            // uas guarantees no Performance index yog yeej ib txwm tsis pub dhau ciam teb.
            unsafe { args.get_unchecked(i).as_usize() }
        }
    }
}

/// Padding tom qab qhov kawg ntawm ib yam dab tsi.Rov qab los ntawm `Formatter::padding`.
#[must_use = "don't forget to write the post padding"]
struct PostPadding {
    fill: char,
    padding: usize,
}

impl PostPadding {
    fn new(fill: char, padding: usize) -> PostPadding {
        PostPadding { fill, padding }
    }

    /// Sau kab lus no.
    fn write(self, buf: &mut dyn Write) -> Result {
        for _ in 0..self.padding {
            buf.write_char(self.fill)?;
        }
        Ok(())
    }
}

impl<'a> Formatter<'a> {
    fn wrap_buf<'b, 'c, F>(&'b mut self, wrap: F) -> Formatter<'c>
    where
        'b: 'c,
        F: FnOnce(&'b mut (dyn Write + 'b)) -> &'c mut (dyn Write + 'c),
    {
        Formatter {
            // Peb xav hloov no
            buf: wrap(self.buf),

            // Thiab khaws cia no
            flags: self.flags,
            fill: self.fill,
            align: self.align,
            width: self.width,
            precision: self.precision,
        }
    }

    // Pab txoj kev siv rau padding thiab ua formatting nqe lus uas tag nrho cov formatting traits yuav siv tau.
    //

    /// Ua qhov tseeb padding rau ib qho integer uas twb tau tshaj tawm nyob rau hauv ib kab.
    /// Cov hlua yuav tsum *tsis* muaj daim phiajcim rau tus lej, uas yuav muab ntxiv los ntawm hom no.
    ///
    /// # Arguments
    ///
    /// * is_nonnegative, seb tus thawj integer yog yog zoo los yog pes tsawg.
    /// * ua ntej, yog tias '#' lub cim (Alternate) yog muab, qhov no yog qhov ua ntej muab tso rau hauv ntej ntawm tus lej.
    ///
    /// * buf, lub byte array hais tias cov xov tooj tau formatted rau hauv
    ///
    /// Txoj haujlwm no yuav ua kom raug rau cov chij muab raws li qhov dav dav tsawg.
    /// Nws yuav tsis siv precision mus rau hauv tus account.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo { nb: i32 }
    ///
    /// impl Foo {
    ///     fn new(nb: i32) -> Foo {
    ///         Foo {
    ///             nb,
    ///         }
    ///     }
    /// }
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         // Peb yuav tsum tau tshem tawm "-" ntawm tus naj npawb cov zis.
    ///         let tmp = self.nb.abs().to_string();
    ///
    ///         formatter.pad_integral(self.nb > 0, "Foo ", &tmp)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo::new(2)), "2");
    /// assert_eq!(&format!("{}", Foo::new(-1)), "-1");
    /// assert_eq!(&format!("{:#}", Foo::new(-1)), "-Foo 1");
    /// assert_eq!(&format!("{:0>#8}", Foo::new(-1)), "00-Foo 1");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad_integral(&mut self, is_nonnegative: bool, prefix: &str, buf: &str) -> Result {
        let mut width = buf.len();

        let mut sign = None;
        if !is_nonnegative {
            sign = Some('-');
            width += 1;
        } else if self.sign_plus() {
            sign = Some('+');
            width += 1;
        }

        let prefix = if self.alternate() {
            width += prefix.chars().count();
            Some(prefix)
        } else {
            None
        };

        // Sau lub cim yog tias nws muaj, thiab tom qab ntawd yog tias tau thov
        #[inline(never)]
        fn write_prefix(f: &mut Formatter<'_>, sign: Option<char>, prefix: Option<&str>) -> Result {
            if let Some(c) = sign {
                f.buf.write_char(c)?;
            }
            if let Some(prefix) = prefix { f.buf.write_str(prefix) } else { Ok(()) }
        }

        // Lub `width` teb yog ntau ntawm `min-width` parameter ntawm no.
        match self.width {
            // Yog hais tias muaj yog tsis muaj yam tsawg kawg nkaus ntev uas yuav tsum tau ces peb yuav tau cia li sau cov bytes.
            //
            None => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // Kos yog hais tias peb nyob tshaj qhov tsawg kawg nkaus dav, yog li ntawd, ces peb yuav tau kuj cia li sau cov bytes.
            //
            Some(min) if width >= min => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // Qhov kos npe rau thiab prefix mus ua ntej lub padding yog hais tias tus sau ua cim yog pes tsawg
            //
            Some(min) if self.sign_aware_zero_pad() => {
                let old_fill = crate::mem::replace(&mut self.fill, '0');
                let old_align = crate::mem::replace(&mut self.align, rt::v1::Alignment::Right);
                write_prefix(self, sign, prefix)?;
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)?;
                self.fill = old_fill;
                self.align = old_align;
                Ok(())
            }
            // Txwv tsis pub, kos npe thiab pib ua ntej mus tom qab padding
            Some(min) => {
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// Qhov no muaj nuj nqi yuav siv sij hawm ib tug hlua hlais thiab emits nws mus rau lub internal tsis tom qab thov cov formatting chij teev.
    /// Cov chij pom tau hais tias generic cov hlua yog:
    ///
    /// * dav, qhov tsawg kawg nkaus dav ntawm dab tsi rau emit
    /// * fill/align - dab tsi rau emit thiab qhov twg emit nws yog hais tias tus hlua muab xav tau kev pab yuav tsum tau padded
    /// * precision, lub siab tshaj plaws ntev mus emit, cov hlua yog truncated yog hais tias nws yog ntev tshaj li qhov no ntev
    ///
    /// Tsim hnog no muaj nuj nqi tsis mloog lub `flag` tsis.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.pad("Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<4}", Foo), "Foo ");
    /// assert_eq!(&format!("{:0>4}", Foo), "0Foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad(&mut self, s: &str) -> Result {
        // Xyuas kom tseeb tias muaj yog ib tug ceev ceev txoj kev mus pem lub taub hau
        if self.width.is_none() && self.precision.is_none() {
            return self.buf.write_str(s);
        }
        // Lub `precision` teb yuav muab txhais raws li ib tug `max-width` rau txoj hlua raug formatted.
        //
        let s = if let Some(max) = self.precision {
            // Yog hais tias peb cov hlua ntev hais tias tus precision, ces peb yuav tsum muaj truncation.
            // Txawm li cas los lwm tus chij zoo li `fill`, `width` thiab `align` yuav tsum ua raws li ib txwm.
            //
            if let Some((i, _)) = s.char_indices().nth(max) {
                // LLVM ntawm no tsis tuaj yeem ua pov thawj tias `..i` yuav tsis panic `&s[..i]`, tab sis peb paub tias nws tsis tuaj yeem panic.
                // Siv `get` + `unwrap_or` kom tsis txhob `unsafe` thiab lwm yam tsis emit tej panic-yam code no.
                //
                //
                s.get(..i).unwrap_or(&s)
            } else {
                &s
            }
        } else {
            &s
        };
        // Lub `width` teb yog ntau ntawm `min-width` parameter ntawm no.
        match self.width {
            // Yog hais tias peb nyob nraum nyob rau hauv lub siab tshaj plaws ntev, thiab yog tsis muaj yam tsawg kawg nkaus ntev uas yuav tsum tau, ces peb yuav cia li emit txoj hlua
            //
            None => self.buf.write_str(s),
            // Yog tias peb nyob hauv qhov siab tshaj qhov dav, txheeb xyuas yog tias peb hla qhov tsawg kawg nkaus qhov dav, yog tias nws yooj yim raws li kev tshaj tawm txoj hlua.
            //
            Some(width) if s.chars().count() >= width => self.buf.write_str(s),
            // Yog tias peb nyob hauv ob qhov siab thiab qhov tsawg kawg nkaus, ces sau qhov dav yam tsawg kawg nkaus nrog txoj kab kev sib tw + qee qhov sib luag.
            //
            Some(width) => {
                let align = rt::v1::Alignment::Left;
                let post_padding = self.padding(width - s.chars().count(), align)?;
                self.buf.write_str(s)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// Sau cov kab ntawv ua ntej thiab xa rov qab uas tsis muaj daim ntawv tom qab ntawv.
    /// Hu tuaj yog lub luag hauj lwm kom ntseeg tau post-padding yog sau tom qab tus tshaj plaws uas yog tau padded.
    ///
    fn padding(
        &mut self,
        padding: usize,
        default: rt::v1::Alignment,
    ) -> result::Result<PostPadding, Error> {
        let align = match self.align {
            rt::v1::Alignment::Unknown => default,
            _ => self.align,
        };

        let (pre_pad, post_pad) = match align {
            rt::v1::Alignment::Left => (0, padding),
            rt::v1::Alignment::Right | rt::v1::Alignment::Unknown => (padding, 0),
            rt::v1::Alignment::Center => (padding / 2, (padding + 1) / 2),
        };

        for _ in 0..pre_pad {
            self.buf.write_char(self.fill)?;
        }

        Ok(PostPadding::new(self.fill, post_pad))
    }

    /// Yuav siv sij hawm tus formatted qhov chaw thiab siv lub padding.
    /// Assumes uas tus neeg hu twb tau nws qhov chaw nrog yuav tsum tau precision, yog li ntawd `self.precision` yuav tsis quav ntsej li.
    ///
    fn pad_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        if let Some(mut width) = self.width {
            // rau hauv lub kos npe-paub pes tsawg padding, peb kav lub kos npe rau thawj thiab coj raws li yog hais tias peb twb tsis muaj kos npe rau los ntawm thaum pib.
            //
            let mut formatted = formatted.clone();
            let old_fill = self.fill;
            let old_align = self.align;
            let mut align = old_align;
            if self.sign_aware_zero_pad() {
                // ib tug kos npe rau ib txwm mus thawj
                let sign = formatted.sign;
                self.buf.write_str(sign)?;

                // tshem tawm cov kos npe rau los ntawm tus formatted qhov chaw
                formatted.sign = "";
                width = width.saturating_sub(sign.len());
                align = rt::v1::Alignment::Right;
                self.fill = '0';
                self.align = rt::v1::Alignment::Right;
            }

            // qhov seem ntxiv mus dhau ntawm qhov txheej txheem padding dog dig.
            let len = formatted.len();
            let ret = if width <= len {
                // tsis muaj padding
                self.write_formatted_parts(&formatted)
            } else {
                let post_padding = self.padding(width - len, align)?;
                self.write_formatted_parts(&formatted)?;
                post_padding.write(self.buf)
            };
            self.fill = old_fill;
            self.align = old_align;
            ret
        } else {
            // qhov no yog qhov xwm txheej dhau los thiab peb coj luv
            self.write_formatted_parts(formatted)
        }
    }

    fn write_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        fn write_bytes(buf: &mut dyn Write, s: &[u8]) -> Result {
            // TXUAG: Qhov no yog siv rau `flt2dec::Part::Num` thiab `flt2dec::Part::Copy`.
            // Nws muaj kev nyab xeeb rau siv rau `flt2dec::Part::Num` txij li txhua tus char `c` yog nruab nrab ntawm `b'0'` thiab `b'9'`, uas txhais tau tias `s` siv tau UTF-8.
            // Nws kuj tseem muaj kev nyab xeeb hauv kev coj ua rau siv rau `flt2dec::Part::Copy(buf)` txij li `buf` yuav tsum yog qhov tseeb ASCII, tab sis nws muaj peev xwm ua rau ib tus neeg dhau ntawm qhov tsis zoo rau `buf` rau `flt2dec::to_shortest_str` vim nws yog pej xeem muaj nuj nqi.
            //
            // FIXME: Txiav txim seb qhov no yuav ua nyob rau hauv UB.
            //
            //
            //
            buf.write_str(unsafe { str::from_utf8_unchecked(s) })
        }

        if !formatted.sign.is_empty() {
            self.buf.write_str(formatted.sign)?;
        }
        for part in formatted.parts {
            match *part {
                flt2dec::Part::Zero(mut nzeroes) => {
                    const ZEROES: &str = // 64 zeroes
                        "0000000000000000000000000000000000000000000000000000000000000000";
                    while nzeroes > ZEROES.len() {
                        self.buf.write_str(ZEROES)?;
                        nzeroes -= ZEROES.len();
                    }
                    if nzeroes > 0 {
                        self.buf.write_str(&ZEROES[..nzeroes])?;
                    }
                }
                flt2dec::Part::Num(mut v) => {
                    let mut s = [0; 5];
                    let len = part.len();
                    for c in s[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                    write_bytes(self.buf, &s[..len])?;
                }
                flt2dec::Part::Copy(buf) => {
                    write_bytes(self.buf, buf)?;
                }
            }
        }
        Ok(())
    }

    /// Sau ib co ntaub ntawv rau lwm tsis muaj nyob hauv no formatter.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_str("Foo")
    ///         // Qhov no yog sib npaug rau:
    ///         // sau! (qauv, "Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo), "Foo");
    /// assert_eq!(&format!("{:0>8}", Foo), "Foo");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_str(&mut self, data: &str) -> Result {
        self.buf.write_str(data)
    }

    /// Sau qee cov ntaub ntawv xov xwm rau hauv qhov ua piv txwv.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_fmt(format_args!("Foo {}", self.0))
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo(-1)), "Foo -1");
    /// assert_eq!(&format!("{:0>8}", Foo(2)), "Foo 2");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_fmt(&mut self, fmt: Arguments<'_>) -> Result {
        write(self.buf, fmt)
    }

    /// Chij rau formatting
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.24.0",
        reason = "use the `sign_plus`, `sign_minus`, `alternate`, \
                  or `sign_aware_zero_pad` methods instead"
    )]
    pub fn flags(&self) -> u32 {
        self.flags
    }

    /// Ximxoo siv raws li 'fill' thaum twg muaj ib kawm tuab si lug.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let c = formatter.fill();
    ///         if let Some(width) = formatter.width() {
    ///             for _ in 0..width {
    ///                 write!(formatter, "{}", c)?;
    ///             }
    ///             Ok(())
    ///         } else {
    ///             write!(formatter, "{}", c)
    ///         }
    ///     }
    /// }
    ///
    /// // Peb teeb kho kom haum rau sab xis nrog ">".
    /// assert_eq!(&format!("{:G>3}", Foo), "GGG");
    /// assert_eq!(&format!("{:t>6}", Foo), "tttttt");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn fill(&self) -> char {
        self.fill
    }

    /// Flag qhia dab tsi hauv daim ntawv ntawm kawm tuab si lug tau thov.
    ///
    /// # Examples
    ///
    /// ```
    /// extern crate core;
    ///
    /// use std::fmt::{self, Alignment};
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let s = if let Some(s) = formatter.align() {
    ///             match s {
    ///                 Alignment::Left    => "left",
    ///                 Alignment::Right   => "right",
    ///                 Alignment::Center  => "center",
    ///             }
    ///         } else {
    ///             "into the void"
    ///         };
    ///         write!(formatter, "{}", s)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<}", Foo), "left");
    /// assert_eq!(&format!("{:>}", Foo), "right");
    /// assert_eq!(&format!("{:^}", Foo), "center");
    /// assert_eq!(&format!("{}", Foo), "into the void");
    /// ```
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    pub fn align(&self) -> Option<Alignment> {
        match self.align {
            rt::v1::Alignment::Left => Some(Alignment::Left),
            rt::v1::Alignment::Right => Some(Alignment::Right),
            rt::v1::Alignment::Center => Some(Alignment::Center),
            rt::v1::Alignment::Unknown => None,
        }
    }

    /// Xaiv kev hais txog zauv dav uas qhov tawm yuav tsum yog.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(width) = formatter.width() {
    ///             // Yog tias peb tau txais qhov dav, peb siv nws
    ///             write!(formatter, "{:width$}", &format!("Foo({})", self.0), width = width)
    ///         } else {
    ///             // Txwv tsis pub peb ua ib yam dabtsi tshwj xeeb
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:10}", Foo(23)), "Foo(23)   ");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn width(&self) -> Option<usize> {
        self.width
    }

    /// Optionally teev precision rau numeric hom.
    /// Xwb, lub siab tshaj plaws dav rau txoj hlua hom.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(f32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(precision) = formatter.precision() {
    ///             // Yog tias peb tau txais qhov ua tiav, peb siv nws.
    ///             write!(formatter, "Foo({1:.*})", precision, self.0)
    ///         } else {
    ///             // Txwv tsis pub peb hloov rau 2.
    ///             write!(formatter, "Foo({:.2})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:.4}", Foo(23.2)), "Foo(23.2000)");
    /// assert_eq!(&format!("{}", Foo(23.2)), "Foo(23.20)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn precision(&self) -> Option<usize> {
        self.precision
    }

    /// Txiav txim siab yog tias `+` chij tau teev tseg.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_plus() {
    ///             write!(formatter,
    ///                    "Foo({}{})",
    ///                    if self.0 < 0 { '-' } else { '+' },
    ///                    self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:+}", Foo(23)), "Foo(+23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_plus(&self) -> bool {
        self.flags & (1 << FlagV1::SignPlus as u32) != 0
    }

    /// Txiav txim siab yog tias `-` chij tau teev tseg.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_minus() {
    ///             // Koj xav tau ib tug rho tawm kos npe rau?Muaj ib tug!
    ///             write!(formatter, "-Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:-}", Foo(23)), "-Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_minus(&self) -> bool {
        self.flags & (1 << FlagV1::SignMinus as u32) != 0
    }

    /// Txiav txim siab yog tias `#` chij tau teev tseg.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.alternate() {
    ///             write!(formatter, "Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "{}", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:#}", Foo(23)), "Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn alternate(&self) -> bool {
        self.flags & (1 << FlagV1::Alternate as u32) != 0
    }

    /// Txiav txim yog hais tias tus `0` chij twb teev.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         assert!(formatter.sign_aware_zero_pad());
    ///         assert_eq!(formatter.width(), Some(4));
    ///         // Peb tsis quav ntsej cov qauv xaiv.
    ///         write!(formatter, "{}", self.0)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:04}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_aware_zero_pad(&self) -> bool {
        self.flags & (1 << FlagV1::SignAwareZeroPad as u32) != 0
    }

    // FIXME: Txiav txim seb tus pej xeem API peb xav tau rau ob chij no.
    // https://github.com/rust-lang/rust/issues/48584
    fn debug_lower_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugLowerHex as u32) != 0
    }

    fn debug_upper_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugUpperHex as u32) != 0
    }

    /// Tsim ib tug [`DebugStruct`] builder tsim los pab nrog creation ntawm [`fmt::Debug`] implementations rau structs.
    ///
    ///
    /// [`fmt::Debug`]: self::Debug
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::net::Ipv4Addr;
    ///
    /// struct Foo {
    ///     bar: i32,
    ///     baz: String,
    ///     addr: Ipv4Addr,
    /// }
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_struct("Foo")
    ///             .field("bar", &self.bar)
    ///             .field("baz", &self.baz)
    ///             .field("addr", &format_args!("{}", self.addr))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo { bar: 10, baz: \"Hello World\", addr: 127.0.0.1 }",
    ///     format!("{:?}", Foo {
    ///         bar: 10,
    ///         baz: "Hello World".to_string(),
    ///         addr: Ipv4Addr::new(127, 0, 0, 1),
    ///     })
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_struct<'b>(&'b mut self, name: &str) -> DebugStruct<'b, 'a> {
        builders::debug_struct_new(self, name)
    }

    /// Tsim ib tug `DebugTuple` builder tsim los pab nrog creation ntawm `fmt::Debug` implementations rau tuple structs.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::marker::PhantomData;
    ///
    /// struct Foo<T>(i32, String, PhantomData<T>);
    ///
    /// impl<T> fmt::Debug for Foo<T> {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_tuple("Foo")
    ///             .field(&self.0)
    ///             .field(&self.1)
    ///             .field(&format_args!("_"))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo(10, \"Hello\", _)",
    ///     format!("{:?}", Foo(10, "Hello".to_string(), PhantomData::<u8>))
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_tuple<'b>(&'b mut self, name: &str) -> DebugTuple<'b, 'a> {
        builders::debug_tuple_new(self, name)
    }

    /// Tsim ib tug `DebugList` builder tsim los pab nrog creation ntawm `fmt::Debug` implementations rau daim ntawv teev zoo li lug.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_list().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "[10, 11]");
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_list<'b>(&'b mut self) -> DebugList<'b, 'a> {
        builders::debug_list_new(self)
    }

    /// Tsim ib tug `DebugSet` builder tsim los pab nrog creation ntawm `fmt::Debug` implementations rau txheej zoo li lug.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "{10, 11}");
    /// ```
    ///
    /// [`format_args!`]: crate::format_args
    ///
    /// Nyob rau hauv no ntau piv txwv li, peb siv [`format_args!`] thiab `.debug_set()` los tsim kom tau ib daim ntawv teev match caj npab:
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Arm<'a, L: 'a, R: 'a>(&'a (L, R));
    /// struct Table<'a, K: 'a, V: 'a>(&'a [(K, V)], V);
    ///
    /// impl<'a, L, R> fmt::Debug for Arm<'a, L, R>
    /// where
    ///     L: 'a + fmt::Debug, R: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         L::fmt(&(self.0).0, fmt)?;
    ///         fmt.write_str(" => ")?;
    ///         R::fmt(&(self.0).1, fmt)
    ///     }
    /// }
    ///
    /// impl<'a, K, V> fmt::Debug for Table<'a, K, V>
    /// where
    ///     K: 'a + fmt::Debug, V: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set()
    ///         .entries(self.0.iter().map(Arm))
    ///         .entry(&Arm(&(format_args!("_"), &self.1)))
    ///         .finish()
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_set<'b>(&'b mut self) -> DebugSet<'b, 'a> {
        builders::debug_set_new(self)
    }

    /// Tsim cov `DebugMap` cov kws tsim qauv tsim los pab nrog kev tsim cov `fmt::Debug` kev ua haujlwm rau cov qauv zoo li daim duab qhia.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_map().entries(self.0.iter().map(|&(ref k, ref v)| (k, v))).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}",  Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     r#"{"A": 10, "B": 11}"#
    ///  );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_map<'b>(&'b mut self) -> DebugMap<'b, 'a> {
        builders::debug_map_new(self)
    }
}

#[stable(since = "1.2.0", feature = "formatter_write")]
impl Write for Formatter<'_> {
    fn write_str(&mut self, s: &str) -> Result {
        self.buf.write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        self.buf.write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        write(self.buf, args)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Error {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt("an error occurred when formatting an argument", f)
    }
}

// Implementations ntawm cov tub ntxhais formatting traits

macro_rules! fmt_refs {
    ($($tr:ident),*) => {
        $(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &mut T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        )*
    }
}

fmt_refs! { Debug, Display, Octal, Binary, LowerHex, UpperHex, LowerExp, UpperExp }

#[unstable(feature = "never_type", issue = "35121")]
impl Debug for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl Display for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for bool {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for bool {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(if *self { "true" } else { "false" }, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('"')?;
        let mut from = 0;
        for (i, c) in self.char_indices() {
            let esc = c.escape_debug();
            // Yog tias char xav tau kev khiav dim, yaug backlog kom deb li deb thiab sau, lwm yam hla
            if esc.len() != 1 {
                f.write_str(&self[from..i])?;
                for c in esc {
                    f.write_char(c)?;
                }
                from = i + c.len_utf8();
            }
        }
        f.write_str(&self[from..])?;
        f.write_char('"')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('\'')?;
        for c in self.escape_debug() {
            f.write_char(c)?
        }
        f.write_char('\'')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        if f.width.is_none() && f.precision.is_none() {
            f.write_char(*self)
        } else {
            f.pad(self.encode_utf8(&mut [0; 4]))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        let old_width = f.width;
        let old_flags = f.flags;

        // Tus tso chij yog twb kho tau los ntawm LowerHex li ua special-nws qhia seb puas yuav prefix nrog 0 x.
        // Peb siv nws mus ua hauj lwm tawm seb puas los yog tsis tau pes tsawg ntev, thiab ces unconditionally teem nws mus rau hauv lub prefix.
        //
        //
        if f.alternate() {
            f.flags |= 1 << (FlagV1::SignAwareZeroPad as u32);

            if f.width.is_none() {
                f.width = Some((usize::BITS / 4) as usize + 2);
            }
        }
        f.flags |= 1 << (FlagV1::Alternate as u32);

        let ret = LowerHex::fmt(&(*self as *const () as usize), f);

        f.width = old_width;
        f.flags = old_flags;

        ret
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(&**self as *const T), f)
    }
}

// Yuav ua raws li Display/Debug rau ntau yam tseem ceeb hom

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}

macro_rules! peel {
    ($name:ident, $($other:ident,)*) => (tuple! { $($other,)* })
}

macro_rules! tuple {
    () => ();
    ( $($name:ident,)+ ) => (
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<$($name:Debug),+> Debug for ($($name,)+) where last_type!($($name,)+): ?Sized {
            #[allow(non_snake_case, unused_assignments)]
            fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                let mut builder = f.debug_tuple("");
                let ($(ref $name,)+) = *self;
                $(
                    builder.field(&$name);
                )+

                builder.finish()
            }
        }
        peel! { $($name,)+ }
    )
}

macro_rules! last_type {
    ($a:ident,) => { $a };
    ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
}

tuple! { T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, }

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Debug> Debug for [T] {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for () {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("()")
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for PhantomData<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("PhantomData")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy + Debug> Debug for Cell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_struct("Cell").field("value", &self.get()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        match self.try_borrow() {
            Ok(borrow) => f.debug_struct("RefCell").field("value", &borrow).finish(),
            Err(_) => {
                // Tus RefCell yog ob leeg qiv tau yog li peb tsis tuaj yeem saib nws tus nqi ntawm no.
                // Qhia cov chaw siv rau lwm tus.
                struct BorrowedPlaceholder;

                impl Debug for BorrowedPlaceholder {
                    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                        f.write_str("<borrowed>")
                    }
                }

                f.debug_struct("RefCell").field("value", &BorrowedPlaceholder).finish()
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for Ref<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefMut<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&*(self.deref()), f)
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: ?Sized + Debug> Debug for UnsafeCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("UnsafeCell")
    }
}

// Yog hais tias koj xav ntsuam xyuas kom tau nyob ntawm no, saib es tsis txhob nyob rau core/tests/fmt.rs cov ntaub ntawv, nws yog ib tug yooj yim heev tshaj txoj kev kom tag nrho cov rt::Piece lug no.
//
// Kuj tseem muaj cov kev sim hauv kev faib crate, rau cov uas xav tau kev faib nyiaj.