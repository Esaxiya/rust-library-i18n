//! Nov yog qhov khoos kas sab hauv uas siv los ntawm ifmt!runtime.Cov lug yog tawm txim liab rau zoo li qub arrays rau precompile hom hlua ua ntej ntawm lub sij hawm.
//!
//! Cov ntsiab lus muaj ntsis zoo li lawv `ct` kom muaj sib npaug, tab sis txawv nyob rau hauv hais tias cov muaj peev xwm yuav statically faib thiab me ntsis optimized rau cov runtime
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Tau alignments uas yuav thov raws li ib feem ntawm ib tug formatting qhia.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Hais txog hais tias txheem yuav tsum tau sab laug-raws li.
    Left,
    /// Qhia txog tias cov ncauj lus yuav tsum yog ua raws li sab xis.
    Right,
    /// Hais txog hais tias txheem yuav tsum center-raws li.
    Center,
    /// Tsis muaj kev sib thooj.
    Unknown,
}

/// Siv los ntawm [width](https://doc.rust-lang.org/std/fmt/#width) thiab [precision](https://doc.rust-lang.org/std/fmt/#precision) specifiers.
#[derive(Copy, Clone)]
pub enum Count {
    /// Teev nrog ib tug literal tooj, khw muag khoom cov nqi
    Is(usize),
    /// Teev siv `$` thiab `*` syntaxes, khw muag khoom qhov Performance index rau hauv `args`
    Param(usize),
    /// Tsis teev
    Implied,
}