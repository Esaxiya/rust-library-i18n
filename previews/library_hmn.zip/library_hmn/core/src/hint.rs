#![stable(feature = "core_hint", since = "1.27.0")]

//! Cov lus taw qhia rau cov sau uas cuam tshuam li cas code yuav tsum tau emitted lossis optimized.
//! Yim pab tej zaum yuav compile lub sij hawm los yog runtime.

use crate::intrinsics;

/// Qhia cov compiler hais tias qhov no taw tes nyob rau hauv lub code yog tsis field, enabling ntxiv optimizations.
///
/// # Safety
///
/// Ncav no muaj nuj nqi yog kiag li *undefined tus cwj pwm*(UB).Tshwj xeeb, tus sau xav tias txhua UB yuav tsum tsis txhob tshwm sim, thiab yog li yuav tshem tawm txhua ceg uas ncav cuag hu rau `unreachable_unchecked()`.
///
/// Zoo li tag nrho cov piv txwv ntawm UB, Yog hais tias qhov no assumption hloov tawm mus rau yuav tsis ncaj ncees lawm, piv txwv li, lub `unreachable_unchecked()` hu no yog hu ua field ntawm tag nrho cov tau tswj flow, lub compiler yuav siv cov tsis ncaj ncees lawm optimization zoo, thiab tej zaum yuav tej zaum kuj txawm corrupt seemingly ncaj code, ua difficult-rau-debug teeb meem.
///
///
/// Siv txoj haujlwm no tsuas yog thaum koj tuaj yeem ua pov thawj tias cov code yuav tsis hu nws.
/// Txwv tsis pub, muab siv lub [`unreachable!`] macro, uas tsis pub optimizations tab sis yuav panic thaum tua.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` yog yeej ib txwm zoo (tsis xoom), li no `checked_div` yuav tsis rov qab `None`.
/////
///     // Yog li ntawd, cov uas lwm tus neeg branch yog unreachable.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // KEV RUAJ NTSEG: kev ruaj ntseg daim ntawv cog lus rau `intrinsics::unreachable` yuav tsum
    // yuav upheld los ntawm ib tus neeg hu.
    unsafe { intrinsics::unreachable() }
}

/// Emits lub tshuab qhia rau teeb liab tus processor hais tias nws tab tom khiav ntawm qhov tsis khoom kiag li-tos kiv-ntxees ("spin ntsuas").
///
/// Thaum tau txais cov spin-voj teeb liab lub processor muaj peev xwm optimize cov cwj pwm los ntawm, piv txwv li, lub hwjchim los yog switching hyper-threads.
///
/// Qhov no muaj nuj nqi yog txawv los ntawm [`thread::yield_now`] uas ncaj qha yields rau lub system tus Schedule, whereas `spin_loop` tsis sib tham nrog cov kev khiav hauj lwm qhov system.
///
/// Ib tug kev siv cov ntaub ntawv rau `spin_loop` yog siv ciaj optimistic spinning nyob rau hauv ib tug CAS voj hauv synchronization primitives.
/// Yuav kom tsis txhob muaj teeb meem zoo li feem inversion, nws yog ntseeg tau pom zoo hais tias cov kiv voj haujlwm tom qab ib tug finite nyiaj ntawm iterations thiab ib tug tsim nyog thaiv lwm tus kev syscall yog ua.
///
///
/// **Thov Cim**: On platforms uas tsis txhawb tau txais spin-voj yim pab no muaj nuj nqi tsis tau ua dab tsi tag nrho.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // Ib tug qhia atomic nqi uas threads yuav siv los saib
/// let live = Arc::new(AtomicBool::new(false));
///
/// // Nyob rau hauv ib tug tom qab xov peb mam li nws thiaj li muab tus nqi
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Ua ib co ua hauj lwm, ces ua tus nqi nyob
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // Rov qab rau peb cov xov tam sim no, peb tos kom tus nqi tau teeb tsa
/// while !live.load(Ordering::Acquire) {
///     // Lub kiv voj yog ib tug hint rau lub CPU hais tias peb nyob nraum tos, tiam sis tej zaum tsis ntev heev
/////
///     hint::spin_loop();
/// }
///
/// // Tus nqi yog tam sim no teem
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // KEV RUAJ NTSEG: lub `cfg` attr kom peb tsuas ua li no rau x86 lub hom phaj.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // KEV RUAJ NTSEG: lub `cfg` attr kom peb tsuas ua li no rau x86_64 lub hom phaj.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // KEV RUAJ NTSEG: `cfg` attr xyuas kom peb tsuas ua qhov no ntawm aarch64 lub hom phiaj.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // KEV RUAJ NTSEG: lub `cfg` attr kom peb tsuas ua li no rau sab caj npab lub hom phaj
            // nrog them nyiaj yug rau lub v6 feature.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// Ib tug yog leejtwg nuj nqi uas *__ yim pab __* mus rau lub compiler yuav maximally phem heev hais txog dab tsi `black_box` yuav ua li cas.
///
/// Tsis zoo li [`std::convert::identity`], ib qho Rust compiler raug txhawb kom xav tias `black_box` tuaj yeem siv `dummy` ntawm txhua txoj kev siv tau uas Rust code raug tso cai rau yam tsis muaj kev qhia txog kev coj cwj pwm tsis zoo hauv kev hu tus lej.
///
/// Qhov no tej khoom vaj tse ua `black_box` pab tau rau sau ntawv cai nyob rau hauv uas tej optimizations tsis xav, xws li nrim.
///
/// Nco ntsoov li cas los xij, tias `black_box` tsuas yog (thiab tsuas yog muab tau) muab rau ib qho "best-effort".Raws li qhov uas nws yuav thaiv optimisations tej zaum yuav txawv nyob ntawm seb raws li qhov platform thiab code-gen backend siv.
/// Programs yuav tsis cia siab rau `black_box` rau *correctness* nyob rau hauv txhua txoj kev.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // Peb yuav tsum tau mus "use" lub cav nyob rau hauv ib txoj kev LLVM tsis tau introspect, thiab nyob rau lub hom phaj uas txhawb nws peb yuav feem ntau leverage inline los ua ke yuav ua li cas no.
    // LLVM kev txhais cov ntsiab lus ntawm kev sib dhos hauv pawg yog tias nws yog, zoo, dub thawv.
    // Qhov no tsis yog qhov kev siv loj tshaj plaws vim nws zaum deoptimizes ntau dua qhov peb xav tau, tab sis tam sim no zoo txaus.
    //
    //

    #[cfg(not(miri))] // Qhov no yog cia li ib tug hint, ces nws yog ib qho zoo mus hla nyob rau hauv Miri.
    // KEV RUAJ NTSEG: lub inline los ua ke yog ib tug tsis muaj-op.
    unsafe {
        // FIXME: Tsis tuaj yeem siv `asm!` vim tias nws tsis txhawb MIPS thiab lwm yam qauv kos duab.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}