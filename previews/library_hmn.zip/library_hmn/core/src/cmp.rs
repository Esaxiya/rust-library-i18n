//! Kev ua haujlwm rau kev ua raws thiab sib piv.
//!
//! Qhov no module muaj ntau yam cuab yeej rau ordering thiab muab piv qhov tseem ceeb.Nyob hauv kev xaus:
//!
//! * [`Eq`] thiab [`PartialEq`] yog traits uas tso cai rau koj txhais tau tag nrho thiab ib nrab koob pheej ntawm lawv nyob nruab nrab ntawm qhov tseem ceeb, ntsig txog.
//! Siv lawv overloads lub `==` thiab `!=` tswv.
//! * [`Ord`] thiab [`PartialOrd`] yog traits uas tso cai rau koj txhais tau tag nrho thiab ib nrab orderings ntawm qhov tseem ceeb, ntsig txog.
//!
//! Siv lawv overloads lub `<`, `<=`, `>`, thiab `>=` tswv.
//! * [`Ordering`] yog ib qho enum rov qab los ntawm cov haujlwm tseem ceeb ntawm [`Ord`] thiab [`PartialOrd`], thiab piav qhia txog kev xaj khoom.
//! * [`Reverse`] yog ib tug struct uas tso cai rau koj mus tau yooj yim rov qab ib tug ordering.
//! * [`max`] thiab [`min`] yog cov haujlwm uas tsim tawm ntawm [`Ord`] thiab tso cai rau koj kom pom qhov siab tshaj lossis tsawg kawg ntawm ob qhov tseem ceeb.
//!
//! Yog xav paub cov ntsiab lus ntxiv, saib cov ntaub ntawv sib txawv ntawm txhua yam khoom nyob hauv cov npe.
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// Trait rau koob pheej ntawm lawv kev sib piv uas yog [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation).
///
/// Qhov no trait tso cai rau ib nrab koob pheej ntawm lawv, rau hom uas tsis muaj ib tug tag nrho cov equivalence piv.
/// Piv txwv li, nyob rau hauv floating taw tes tus xov tooj `NaN != NaN`, yog li floating taw tes hom siv `PartialEq` tab sis tsis [`trait@Eq`].
///
/// Raws cai, kev sib luag yuav tsum yog (rau txhua `a`, `b`, `c` ntawm hom `A`, `B`, `C`):
///
/// - **yam**: yog hais tias `A: PartialEq<B>` thiab `B: PartialEq<A>`, ces **'ib tug==b`implies' b==a`**;thiab
///
/// - **transitive**: yog hais tias `A: PartialEq<B>` thiab `B: PartialEq<C>` thiab 'A:
///   Ib nrab<C>', Ces **' ib tug==b`thiab `b == c` implies 'ib tug==c`**.
///
/// Nco ntsoov tias lub `B: PartialEq<A>` (symmetric) thiab `A: PartialEq<C>` (transitive) impls tsis yuam kom nyob ua ib ke, tab sis cov no yuav tsum tau ua ntawv thov thaum twg lawv ua nyob ua ib ke.
///
/// ## Derivable
///
/// Cov trait no tuaj yeem siv nrog `#[derive]`.Thaum 'derive`d rau structs, ob zaus yog muaj sib npaug hais tias tag nrho teb yog muaj sib npaug, thiab tsis sib npaug yog tias muaj teb tsis muaj sib npaug.Thaum 'derive`d rau enums, txhua variant yog sib npaug zos rau nws tus kheej thiab tsis sib npaug mus rau lwm yam variants.
///
/// ## Kuv tuaj yeem siv `PartialEq` li cas?
///
/// `PartialEq` tsuas yuav tsum tau lub [`eq`] txoj kev yuav tsum tau siv;[`ne`] yog txhais nyob rau hauv cov nqe lus ntawm nws los lub neej ntawd.Tej phau ntawv kev siv ntawm [`ne`]*yuav tsum* hwm txoj cai uas [`eq`] yog ib tug nruj ntxeev ntawm [`ne`];ntawd yog, `!(a == b)` yog thiab tsuas yog `a != b`.
///
/// Kev siv ntawm `PartialEq`, [`PartialOrd`], thiab [`Ord`]*yuav tsum* pom zoo nrog lwm tus.Nws yog qhov yooj yim uas ua rau lawv tsis sib haum xeeb los ntawm kev coj ua qee yam ntawm traits thiab tswj kev siv rau lwm tus.
///
/// Kev siv piv txwv rau qhov sau uas ob phau ntawv tau txiav txim siab tib phau ntawv yog tias lawv ISBN ntais ntawv, txawm tias cov qauv sib txawv:
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## Kuv tuaj yeem piv ob hom sib txawv li cas?
///
/// Hom uas koj tuaj yeem sib piv nrog tswj hwm los ntawm `PartialEq` hom ntsuas.
/// Piv txwv li, cia tweak peb yav dhau los code ib tug me ntsis:
///
/// ```
/// // Cov neeg raug coj los siv<BookFormat>==<BookFormat>kev sib piv
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // siv<Book>==<BookFormat>kev sib piv
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // Muab los siv<BookFormat>==<Book>kev sib piv
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// By hloov `impl PartialEq for Book` rau `impl PartialEq<BookFormat> for Book`, peb tso cai rau 'BookFormat`s yuav tsum tau muab piv nrog' Book`s.
///
/// Ib tug sib piv ib yam li ib tug saum toj no, uas tsis mloog tej liaj teb ntawm lub struct, yuav ua tau txaus ntshai.Nws yuav yooj yim ua rau ib tug unintended txhaum cov cai rau ib tug ib nrab equivalence piv.
/// Piv txwv li, yog hais tias peb khaws cia rau hauv lub saum toj no kev siv ntawm `PartialEq<Book>` rau `BookFormat` thiab ntxiv ib qho kev siv ntawm `PartialEq<Book>` rau `Book` (yog ntawm ib tug `#[derive]` los ntawm cov phau ntawv siv los ntawm tus thawj piv txwv li) ces tus yuav ua txhaum transitivity:
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// Qhov no txoj kev ntsuam xyuas rau `self` thiab `other` qhov tseem ceeb yuav tsum tau sib npaug zos, thiab yog siv los ntawm `==`.
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// Qhov no txoj kev kuaj rau `!=`.
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// Muab cov ntawv loj heev los tsim cov qog ntawm trait `PartialEq`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// Trait rau koob pheej ntawm lawv kev sib piv uas yog [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation).
///
/// Qhov no txhais tau tias, uas nyob rau hauv tas li ntawd mus `a == b` thiab `a != b` ua nruj inverses, lub koob pheej ntawm lawv yuav tsum tau (rau tag nrho cov `a`, `b` thiab `c`):
///
/// - reflexive: `a == a`;
/// - yam: `a == b` implies `b == a`;thiab
/// - hloov pauv: `a == b` thiab `b == c` cuam tshuam `a == c`.
///
/// Cov cuab yeej no tsis tuaj yeem kuaj xyuas los ntawm cov kws sau ntawv, thiab yog li `Eq` cuam tshuam [`PartialEq`], thiab tsis muaj cov hau kev ntxiv.
///
/// ## Derivable
///
/// Cov trait no tuaj yeem siv nrog `#[derive]`.
/// Thaum 'derive`d, vim hais tias `Eq` muaj tsis muaj ntxiv txoj kev, yog nws tsuas qhia rau compiler hais tias qhov no yog ib qho equivalence piv es ib tug ib nrab equivalence piv.
///
/// Nco ntsoov tias `derive` lub tswv yim xav kom txhua daim teb yog `Eq`, uas tsis yog ib txwm xav tau.
///
/// ## Yuav ua li cas Kuv yuav siv `Eq`?
///
/// Yog tias koj tsis tuaj yeem siv lub `derive` lub tswv yim, qhia meej tias koj hom coj `Eq`, uas tsis muaj cov hau kev:
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // cov qauv no yog siv ib hom los ntawm#[deriving] paub tias txhua txhua feem ntawm ib hom implements#[deriving] nws tus kheej, tam sim no deriving infrastructure yog txhais tias ua li no assertion tsis tau siv ib txoj kev rau qhov no trait yog ze li ntawm tsis yooj yim sua.
    //
    //
    // Qhov no yuav tsum tsis txhob siv ntawm tes.
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// Muab cov ntawv loj heev los tsim cov qog ntawm trait `Eq`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: no struct yog siv ib hom los ntawm#[neeg] rau
// vajhuam hais tias txhua txhua feem ntawm ib hom implements Eq.
//
// Tus qauv no yuav tsum tsis txhob tshwm sim hauv cov neeg siv code.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Ib qho `Ordering` yog qhov tshwm sim ntawm kev sib piv ntawm ob qhov tseem ceeb.
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// Ib ordering qhov twg ib tug piv cov nqi yog tsawg tshaj li lwm tus.
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// Ib ordering qhov twg ib tug piv cov nqi yog sib npaug zos mus rau lwm lub.
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// Kev xaj qhov twg qhov kev sib piv tus nqi ntau dua lwm qhov.
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// Rov qab `true` yog tias qhov xaj yog `Equal` variant.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// Rov qab `true` yog tias qhov xaj tsis yog `Equal` variant.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// Rov qab `true` yog tias qhov xaj yog `Less` variant.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// Rov `true` yog hais tias tus ordering yog lub `Greater` variant.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// Rov qab `true` yog tias qhov xaj yog `Less` lossis `Equal` variant.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// Rov qab `true` yog tias qhov xaj yog `Greater` lossis `Equal` variant.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// Rov qab `Ordering`.
    ///
    /// * `Less` ua `Greater`.
    /// * `Greater` ua `Less`.
    /// * `Equal` yuav `Equal`.
    ///
    /// # Examples
    ///
    /// Basic tus cwj pwm:
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// Qhov no txoj kev yuav siv tau rau kom rov qab muaj kev sib piv:
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // txheeb cov array los ntawm coob tshaj plaws rau qhov me me.
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// Chais ob xaj.
    ///
    /// Rov qab `self` thaum nws tsis yog `Equal`.Txwv tsis pub rov `other`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// Chains lub ordering nrog qhov muab muaj nuj nqi.
    ///
    /// Rov qab los `self` thaum nws tseem tsis tau `Equal`.
    /// Txwv tsis pub hu `f` thiab xa rov qab qhov tshwm sim.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// Tus neeg pab struct rau rov qab ordering.
///
/// Tus qauv no yog tus pabcuam rau kev siv nrog cov haujlwm xws li [`Vec::sort_by_key`] thiab tuaj yeem siv tau rov qab txiav txim ib feem ntawm tus yuam sij.
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// Trait rau cov hom uas tsim [total order](https://en.wikipedia.org/wiki/Total_order).
///
/// Ib qho kev txiav txim yog qhov kev txiav txim tag nrho yog tias nws yog (rau txhua `a`, `b` thiab `c`):
///
/// - tag nrho thiab asymmetric: raws nraim ib tug ntawm `a < b`, `a == b` los yog `a > b` yog muaj tseeb tiag;thiab
/// - hloov pauv, `a < b` thiab `b < c` teeb meem `a < c`.Tib yam yuav tsum tuav rau ob qho `==` thiab `>`.
///
/// ## Derivable
///
/// Cov trait no tuaj yeem siv nrog `#[derive]`.
/// Thaum 'neeg nyiam `ntawm cov qauv, nws yuav tsim ib qho [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order) xaj raws li cov ntawv tshaj tawm saum toj-hauv qab kev txiav txim ntawm tus qauv cov tswv cuab.
///
/// Thaum 'neeg nyiam `nyob rau cov chaw, cov hloov pauv tau raug txiav txim los ntawm lawv sab saum toj-hauv qab kev cais tshwj xeeb.
///
/// ## Lexicographical sib piv
///
/// Lexicographical sib piv yog kev ua haujlwm nrog cov khoom hauv qab no:
///  - Ob kab xwm txheej yog muab sib piv los ntawm qhov khoom.
///  - Thawj lub ntsiab tsis raug txhais tau txiav txim seb qhov twg yog ntu uas tsawg dua los yog ntau dua qhov sib thooj.
///  - Yog tias ib qho kab ntawv yog qhov ua ntej ntawm lwm qhov, qhov luv ntawm zaj lus luv yog hais tsawg dua qhov sib thooj.
///  - Yog hais tias ob theem zuj zus muaj sib npaug ntsiab thiab yog ntawm tib ntev, ces tus sequences yog lexicographically sib npaug zos.
///  - Ib qho khoob zuj zus yog cov lus hais tsawg dua ib ntu uas tsis khoob.
///  - Ob kab kev sib tshooj uas muaj ntawv sib npaug.
///
/// ## Kuv tuaj yeem siv `Ord` li cas?
///
/// `Ord` yuav tsum tau hais tias hom kuj yuav [`PartialOrd`] thiab [`Eq`] (uas yuav tsum tau [`PartialEq`]).
///
/// Ces koj yuav tsum txhais tau ib tug siv rau [`cmp`].Tej zaum koj yuav nrhiav tau nws pab tau mus siv [`cmp`] rau koj hom lub teb.
///
/// Implementations ntawm [`PartialEq`], [`PartialOrd`], thiab `Ord`*yuav tsum* pom zoo nrog txhua lwm yam.
/// Hais tias yog, `a.cmp(b) == Ordering::Equal` yog tias thiab tsuas yog tias `a == b` thiab `Some(a.cmp(b)) == a.partial_cmp(b)` rau tag nrho cov `a` thiab `b`.
/// Nws yog qhov yooj yim uas ua rau lawv tsis sib haum xeeb los ntawm kev coj ua qee yam ntawm traits thiab tswj kev siv rau lwm tus.
///
/// Nov yog ib qho piv txwv uas koj xav kom cov neeg los ntawm qhov siab xwb, tsis saib xyuas `id` thiab `name`:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// Hom no rov qab los [`Ordering`] ntawm `self` thiab `other`.
    ///
    /// Los ntawm convention, `self.cmp(&other)` rov ordering txuam tus qhia `self <operator> other` yog muaj tseeb tiag.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// Piv thiab rov lub siab tshaj plaws ntawm ob qhov tseem ceeb.
    ///
    /// Rov qab los rau qhov kev sib cav thib ob yog tias qhov kev sib piv pom tias lawv yuav tsum sib npaug.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// Muab sib piv thiab rov qab qhov tsawg kawg ntawm ob qhov tseem ceeb.
    ///
    /// Rov thawj sib cav yog cov kev sib piv txiav txim tias yuav tsum tau sib npaug.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// Txwv tus nqi rau qee lub sijhawm luv.
    ///
    /// Rov `max` yog `self` yog ntau tshaj `max`, thiab `min` yog `self` yog tsawg tshaj li `min`.
    /// Txwv tsis pub no rov `self`.
    ///
    /// # Panics
    ///
    /// Panics yog `min > max`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// Muab cov ntawv loj heev los tsim cov qog ntawm trait `Ord`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// Trait rau qhov muaj nuj nqis uas tuaj yeem muab piv rau cov txheeb-txiav txim.
///
/// Qhov kev sib piv yuav tsum txaus siab, rau txhua `a`, `b` thiab `c`:
///
/// - asymmetry: yog hais tias `a < b` ces `!(a > b)`, raws li zoo raws li `a > b` implying `!(a < b)`;thiab
/// - transitivity: `a < b` thiab `b < c` implies `a < c`.Cov tib yuav tsum tuav rau ob qho tib si `==` thiab `>`.
///
/// Nco ntsoov tias cov uas yuav tsum tau txhais hais tias tus trait nws tus kheej yuav tsum muab los siv symmetrically thiab transitively: yog hais tias `T: PartialOrd<U>` thiab `U: PartialOrd<V>` ces `U: PartialOrd<T>` thiab 'T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// Qhov no trait yuav siv tau nrog `#[derive]`.Thaum 'derive`d rau structs, nws yuav tsim ib tug lexicographic ordering raws li nyob rau saum toj-rau-qab tshaj tawm kev txiav txim ntawm lub struct tus neeg.
/// Thaum 'neeg nyiam `nyob rau cov chaw, cov hloov pauv tau raug txiav txim los ntawm lawv sab saum toj-hauv qab kev cais tshwj xeeb.
///
/// ## Kuv tuaj yeem siv `PartialOrd` li cas?
///
/// `PartialOrd` tsuas yuav tsum tau ua raws li cov lub [`partial_cmp`] txoj kev, nrog rau lwm tus generated los ntawm neej ntawd hais implementations.
///
/// Txawm li cas los nws tseem tau los mus siv rau lwm tus neeg nyias rau hom uas tsis muaj ib tug tag nrho kev txiav txim.
/// Piv txwv li, rau cov naj npawb ntab, `NaN < 0 == false` thiab `NaN >= 0 == false` (cf.
/// IEEE 754-2008 ntu 5.11).
///
/// `PartialOrd` xav tau koj hom yuav tsum yog [`PartialEq`].
///
/// Kev siv ntawm [`PartialEq`], `PartialOrd`, thiab [`Ord`]*yuav tsum* pom zoo nrog lwm tus.
/// Nws yog qhov yooj yim uas ua rau lawv tsis sib haum xeeb los ntawm kev coj ua qee yam ntawm traits thiab tswj kev siv rau lwm tus.
///
/// Yog tias koj hom yog [`Ord`], koj tuaj yeem siv [`partial_cmp`] los ntawm kev siv [`cmp`]:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// Koj kuj tseem nrhiav nws pab tau mus siv [`partial_cmp`] rau koj hom lub teb.
/// Ntawm no yog ib qho piv txwv ntawm cov hom `Person` uas muaj cov lus ntab-`height` teb uas yog daim teb nkaus xwb siv los txheeb:
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// Qhov no txoj kev rov yog ib qho ordering ntawm `self` thiab `other` qhov tseem ceeb yog ib tug tshwm sim.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// Thaum sib piv tsis tau:
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// Hom qauv no ntsuas qis dua (rau `self` thiab `other`) thiab siv los ntawm tus neeg teb xov tooj `<`.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// Hom qauv no ntsuas tsawg dua lossis sib luag rau (rau `self` thiab `other`) thiab siv los ntawm tus neeg teb xov tooj `<=`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// Hom qauv no tau ntsuas ntau dua (rau `self` thiab `other`) thiab siv los ntawm tus neeg teb xov tooj `>`.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// Hom qauv no ntsuas tau ntau dua lossis sib luag rau (rau `self` thiab `other`) thiab siv los ntawm tus neeg ua haujlwm `>=`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// Neeg macro generating ib tug impl ntawm lub trait `PartialOrd`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// Muab sib piv thiab rov qab qhov tsawg kawg ntawm ob qhov tseem ceeb.
///
/// Rov thawj sib cav yog cov kev sib piv txiav txim tias yuav tsum tau sib npaug.
///
/// Sab hauv siv cov cai rau [`Ord::min`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// Rov qab los qhov tsawg kawg ntawm ob qhov tseem ceeb nrog rau kev ua piv txwv muaj nuj nqi.
///
/// Rov thawj sib cav yog cov kev sib piv txiav txim tias yuav tsum tau sib npaug.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// Rov qab los lub caij uas muab cov nqi yam tsawg kawg nkaus los ntawm txoj haujlwm ua haujlwm.
///
/// Rov thawj sib cav yog cov kev sib piv txiav txim tias yuav tsum tau sib npaug.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// Piv thiab rov lub siab tshaj plaws ntawm ob qhov tseem ceeb.
///
/// Rov qab los rau qhov kev sib cav thib ob yog tias qhov kev sib piv pom tias lawv yuav tsum sib npaug.
///
/// Sab hauv siv cov cai rau [`Ord::max`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// Rov cov nyiaj pab ntau tshaj ntawm ob qhov tseem ceeb rau kev hwm rau cov qee sib piv muaj nuj nqi.
///
/// Rov qab los rau qhov kev sib cav thib ob yog tias qhov kev sib piv pom tias lawv yuav tsum sib npaug.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// Rov qab los lub caij uas muab tus nqi siab tshaj plaws ntawm lub teev muaj nuj nqi.
///
/// Rov qab los rau qhov kev sib cav thib ob yog tias qhov kev sib piv pom tias lawv yuav tsum sib npaug.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// Yuav ua raws li PartialEq, Eq, PartialOrd thiab Lo rau txheej thaum ub hom
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // Qhov kev txiav txim no yog ib qho tseem ceeb los ua kom muaj ntau pom los ua ke.
                    // Saib <https://github.com/rust-lang/rust/issues/63758> rau cov lus qhia ntxiv.
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // Casting rau i8's thiab hloov qhov sib txawv rau Qhov Kev Ua Haujlwm ua kom muaj kev sib dhos ntau dua.
            //
            // Saib <https://github.com/rust-lang/rust/issues/66780> rau ntau info.
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // KEV RUAJ NTSEG: bool li i8 rov 0 los yog 1, yog li qhov sib txawv tsis tau lwm yam
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // &pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}