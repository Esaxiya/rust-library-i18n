//! Qhov tsis tu ncua tshwj xeeb rau `f64` ob npaug-precision ntus dej hom.
//!
//! *[See also the `f64` primitive type][f64].*
//!
//! Tus lej lej lej tseem ceeb tau muab rau hauv `consts` sub-module.
//!
//! Rau qhov tsis paub tseeb txhais tau ncaj qha hauv cov qauv no (zoo li txawv ntawm cov tau txhais hauv `consts` sub-module), cov cai tshiab yuav tsum siv cov kev sib txuam uas tau hais tseg ncaj qha rau `f64` hom.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// Lub voos kheej kheej lossis hauv paus ntawm cov sawv cev sab hauv ntawm `f64`.
/// Siv [`f64::RADIX`] hloov.
///
/// # Examples
///
/// ```rust
/// // saib tsis taug txoj kev
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f64::RADIX;
///
/// // npaj txoj kev
/// let r = f64::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f64`")]
pub const RADIX: u32 = f64::RADIX;

/// Cov naj npawb ntawm cov lej tseem ceeb hauv lub hauv paus 2.
/// Siv [`f64::MANTISSA_DIGITS`] hloov.
///
/// # Examples
///
/// ```rust
/// // saib tsis taug txoj kev
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f64::MANTISSA_DIGITS;
///
/// // npaj txoj kev
/// let d = f64::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f64`"
)]
pub const MANTISSA_DIGITS: u32 = f64::MANTISSA_DIGITS;

/// Kwv yees tus lej ntawm cov lej tseem ceeb hauv lub hauv paus 10.
/// Siv [`f64::DIGITS`] hloov.
///
/// # Examples
///
/// ```rust
/// // saib tsis taug txoj kev
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f64::DIGITS;
///
/// // npaj txoj kev
/// let d = f64::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f64`")]
pub const DIGITS: u32 = f64::DIGITS;

/// [Machine epsilon] tus nqi rau `f64`.
/// Siv [`f64::EPSILON`] hloov.
///
/// Qhov no yog qhov sib txawv ntawm `1.0` thiab tom ntej loj tuaj yeem sawv cev.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // saib tsis taug txoj kev
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f64::EPSILON;
///
/// // npaj txoj kev
/// let e = f64::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f64`"
)]
pub const EPSILON: f64 = f64::EPSILON;

/// Tsawg tshaj me me cov nqi `f64`.
/// Siv [`f64::MIN`] hloov.
///
/// # Examples
///
/// ```rust
/// // saib tsis taug txoj kev
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN;
///
/// // npaj txoj kev
/// let min = f64::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f64`")]
pub const MIN: f64 = f64::MIN;

/// Tsawg tshaj me me zoo ib txwm `f64` tus nqi.
/// Siv [`f64::MIN_POSITIVE`] hloov.
///
/// # Examples
///
/// ```rust
/// // saib tsis taug txoj kev
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_POSITIVE;
///
/// // npaj txoj kev
/// let min = f64::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f64`"
)]
pub const MIN_POSITIVE: f64 = f64::MIN_POSITIVE;

/// Loj tshaj plaws ua tus nqi `f64`.
/// Siv [`f64::MAX`] hloov.
///
/// # Examples
///
/// ```rust
/// // saib tsis taug txoj kev
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX;
///
/// // npaj txoj kev
/// let max = f64::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f64`")]
pub const MAX: f64 = f64::MAX;

/// Ib qho loj tshaj qhov tsawg kawg nkaus uas ib txwm muaj zog ntawm 2 exponent.
/// Siv [`f64::MIN_EXP`] hloov.
///
/// # Examples
///
/// ```rust
/// // saib tsis taug txoj kev
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_EXP;
///
/// // npaj txoj kev
/// let min = f64::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f64`"
)]
pub const MIN_EXP: i32 = f64::MIN_EXP;

/// Tshaj tawm lub zog ntawm 2 exponent.
/// Siv [`f64::MAX_EXP`] hloov.
///
/// # Examples
///
/// ```rust
/// // saib tsis taug txoj kev
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX_EXP;
///
/// // npaj txoj kev
/// let max = f64::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f64`"
)]
pub const MAX_EXP: i32 = f64::MAX_EXP;

/// Tsawg kawg uas muaj peev xwm ua kom muaj zog ntawm 10 exponent.
/// Siv [`f64::MIN_10_EXP`] hloov.
///
/// # Examples
///
/// ```rust
/// // saib tsis taug txoj kev
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_10_EXP;
///
/// // npaj txoj kev
/// let min = f64::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f64`"
)]
pub const MIN_10_EXP: i32 = f64::MIN_10_EXP;

/// Tshaj tawm lub zog muaj ntau tshaj ntawm 10 exponent.
/// Siv [`f64::MAX_10_EXP`] hloov.
///
/// # Examples
///
/// ```rust
/// // saib tsis taug txoj kev
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX_10_EXP;
///
/// // npaj txoj kev
/// let max = f64::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f64`"
)]
pub const MAX_10_EXP: i32 = f64::MAX_10_EXP;

/// Tsis Muaj Tus lej (NaN).
/// Siv [`f64::NAN`] hloov.
///
/// # Examples
///
/// ```rust
/// // saib tsis taug txoj kev
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f64::NAN;
///
/// // npaj txoj kev
/// let nan = f64::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f64`")]
pub const NAN: f64 = f64::NAN;

/// Infinity (∞).
/// Siv [`f64::INFINITY`] hloov.
///
/// # Examples
///
/// ```rust
/// // saib tsis taug txoj kev
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f64::INFINITY;
///
/// // npaj txoj kev
/// let inf = f64::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f64`"
)]
pub const INFINITY: f64 = f64::INFINITY;

/// Tsis zoo infinity (−∞).
/// Siv [`f64::NEG_INFINITY`] hloov.
///
/// # Examples
///
/// ```rust
/// // saib tsis taug txoj kev
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f64::NEG_INFINITY;
///
/// // npaj txoj kev
/// let ninf = f64::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f64`"
)]
pub const NEG_INFINITY: f64 = f64::NEG_INFINITY;

/// Yooj yim kawm zauv txwm.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: hloov nrog lej ua ntu zus los ntawm cmath.

    /// Archimedes 'tas li (π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f64 = 3.14159265358979323846264338327950288_f64;

    /// Tag nrho lub voj voos tas li (τ)
    ///
    /// Sib npaug rau 2π.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f64 = 6.28318530717958647692528676655900577_f64;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f64 = 1.57079632679489661923132169163975144_f64;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f64 = 1.04719755119659774615421446109316763_f64;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f64 = 0.785398163397448309615660845819875721_f64;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f64 = 0.52359877559829887307710723054658381_f64;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f64 = 0.39269908169872415480783042290993786_f64;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f64 = 0.318309886183790671537767526745028724_f64;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f64 = 0.636619772367581343075535053490057448_f64;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f64 = 1.12837916709551257389615890312154517_f64;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f64 = 1.41421356237309504880168872420969808_f64;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f64 = 0.707106781186547524400844362104849039_f64;

    /// Euler tus naj npawb (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f64 = 2.71828182845904523536028747135266250_f64;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f64 = 3.32192809488736234787031942948939018_f64;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f64 = 1.44269504088896340735992468100189214_f64;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f64 = 0.301029995663981195213738894724493027_f64;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f64 = 0.434294481903251827651128918916605082_f64;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f64 = 0.693147180559945309417232121458176568_f64;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f64 = 2.30258509299404568401799145468436421_f64;
}

#[lang = "f64"]
#[cfg(not(test))]
impl f64 {
    /// Lub voos kheej kheej lossis hauv paus ntawm cov sawv cev sab hauv ntawm `f64`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// Cov naj npawb ntawm cov lej tseem ceeb hauv lub hauv paus 2.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 53;
    /// Kwv yees tus lej ntawm cov lej tseem ceeb hauv lub hauv paus 10.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 15;

    /// [Machine epsilon] tus nqi rau `f64`.
    ///
    /// Qhov no yog qhov sib txawv ntawm `1.0` thiab tom ntej loj tuaj yeem sawv cev.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f64 = 2.2204460492503131e-16_f64;

    /// Tsawg tshaj me me cov nqi `f64`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f64 = -1.7976931348623157e+308_f64;
    /// Tsawg tshaj me me zoo ib txwm `f64` tus nqi.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f64 = 2.2250738585072014e-308_f64;
    /// Loj tshaj plaws ua tus nqi `f64`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f64 = 1.7976931348623157e+308_f64;

    /// Ib qho loj tshaj qhov tsawg kawg nkaus uas ib txwm muaj zog ntawm 2 exponent.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -1021;
    /// Tshaj tawm lub zog ntawm 2 exponent.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 1024;

    /// Tsawg kawg uas muaj peev xwm ua kom muaj zog ntawm 10 exponent.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -307;
    /// Tshaj tawm lub zog muaj ntau tshaj ntawm 10 exponent.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 308;

    /// Tsis Muaj Tus lej (NaN).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f64 = 0.0_f64 / 0.0_f64;
    /// Infinity (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f64 = 1.0_f64 / 0.0_f64;
    /// Tsis zoo infinity (−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f64 = -1.0_f64 / 0.0_f64;

    /// Rov qab `true` yog tias tus nqi no yog `NaN`.
    ///
    /// ```
    /// let nan = f64::NAN;
    /// let f = 7.0_f64;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): `abs` yog qhov tsis raug rau pej xeem nyob hauv libcore vim muaj kev txhawj xeeb txog kev hloov chaw, yog li qhov kev nqis tes no yog rau kev siv ntiag tug sab hauv.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f64 {
        f64::from_bits(self.to_bits() & 0x7fff_ffff_ffff_ffff)
    }

    /// Rov qab `true` yog tias tus nqi no yog qhov zoo infinity lossis tsis zoo infinity, thiab `false` txwv tsis pub.
    ///
    ///
    /// ```
    /// let f = 7.0f64;
    /// let inf = f64::INFINITY;
    /// let neg_inf = f64::NEG_INFINITY;
    /// let nan = f64::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// Rov qab `true` yog tias tus lej no tsis yog qhov tsis kawg thiab `NaN`.
    ///
    /// ```
    /// let f = 7.0f64;
    /// let inf: f64 = f64::INFINITY;
    /// let neg_inf: f64 = f64::NEG_INFINITY;
    /// let nan: f64 = f64::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // Tsis tas yuav lis NaN cais: yog tias tus kheej yog NaN, qhov sib piv tsis yog qhov tseeb, raws li qhov xav tau.
        //
        self.abs_private() < Self::INFINITY
    }

    /// Rov qab `true` yog tias tus lej yog [subnormal].
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f64::MIN_POSITIVE; // 2.2250738585072014e-308_f64
    /// let max = f64::MAX;
    /// let lower_than_min = 1.0e-308_f64;
    /// let zero = 0.0_f64;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f64::NAN.is_subnormal());
    /// assert!(!f64::INFINITY.is_subnormal());
    /// // Qhov tseem ceeb ntawm `0` thiab `min` yog Cov Qauv Tawm.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// Rov qab `true` yog tias tus lej tsis yog xoom, tsis kawg, [subnormal], lossis `NaN`.
    ///
    ///
    /// ```
    /// let min = f64::MIN_POSITIVE; // 2.2250738585072014e-308f64
    /// let max = f64::MAX;
    /// let lower_than_min = 1.0e-308_f64;
    /// let zero = 0.0f64;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f64::NAN.is_normal());
    /// assert!(!f64::INFINITY.is_normal());
    /// // Qhov tseem ceeb ntawm `0` thiab `min` yog Cov Qauv Tawm.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// Rov qab los rau qeb ntab cov qeb ntawm tus lej.
    /// Yog tias tsuas muaj ib qho cuab yeej yuav tau sim, feem ntau nws nrawm dua yog siv kev kwv yees tshwj xeeb.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f64;
    /// let inf = f64::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u64 = 0x7ff0000000000000;
        const MAN_MASK: u64 = 0x000fffffffffffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// Rov qab `true` yog `self` muaj qhov pom zoo, suav nrog `+0.0`, `NaN tus nrog kos npe me ntsis thiab zoo infinity.
    ///
    ///
    /// ```
    /// let f = 7.0_f64;
    /// let g = -7.0_f64;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.0.0", reason = "renamed to is_sign_positive")]
    #[inline]
    #[doc(hidden)]
    pub fn is_positive(self) -> bool {
        self.is_sign_positive()
    }

    /// Rov qab `true` yog `self` muaj qhov tsis zoo, suav nrog `-0.0`, `NaN tus nrog kos npe tsis zoo thiab infinity tsis zoo.
    ///
    ///
    /// ```
    /// let f = 7.0_f64;
    /// let g = -7.0_f64;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        self.to_bits() & 0x8000_0000_0000_0000 != 0
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.0.0", reason = "renamed to is_sign_negative")]
    #[inline]
    #[doc(hidden)]
    pub fn is_negative(self) -> bool {
        self.is_sign_negative()
    }

    /// Nqa cov XH hauv tus lej xov tooj, `1/x`.
    ///
    /// ```
    /// let x = 2.0_f64;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f64 {
        1.0 / self
    }

    /// Hloov pauv mus rau radians rau degrees.
    ///
    /// ```
    /// let angle = std::f64::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_degrees(self) -> f64 {
        // Qhov kev faib tawm ntawm no tau raug muab kwv nrawm nrog rau qhov muaj tseeb qhov tseeb ntawm 180/π.
        // (Qhov no txawv ntawm f32, qhov ib qho tas mus li yuav tsum tau siv los ua kom tau txais txiaj ntsig sib npaug.)
        //
        self * (180.0f64 / consts::PI)
    }

    /// Hloov pauv cov degrees rau radians.
    ///
    /// ```
    /// let angle = 180.0_f64;
    ///
    /// let abs_difference = (angle.to_radians() - std::f64::consts::PI).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_radians(self) -> f64 {
        let value: f64 = consts::PI;
        self * (value / 180.0)
    }

    /// Rov qab siab tshaj plaws ntawm ob tus lej.
    ///
    /// ```
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// Yog tias ib tus neeg sib ceg yog NaN, ces lwm cov lus sib ceg rov qab los.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f64) -> f64 {
        intrinsics::maxnumf64(self, other)
    }

    /// Rov qab tsawg kawg nkaus ntawm ob tus lej.
    ///
    /// ```
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// Yog tias ib tus neeg sib ceg yog NaN, ces lwm cov lus sib ceg rov qab los.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f64) -> f64 {
        intrinsics::minnumf64(self, other)
    }

    /// Hias mus rau xoom thiab hloov mus rau yam txheej txheem ib txwm suav, qhov kwv yees tias tus nqi ntawd zoo thiab haum rau hom ntawd.
    ///
    ///
    /// ```
    /// let value = 4.6_f64;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f64;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// Tus nqi yuav tsum:
    ///
    /// * Tsis yog `NaN`
    /// * Tsis yog infinite
    /// * Ua tus sawv cev hauv hom xa rov qab `Int`, tom qab txiav nws qhov feem ntawm qhov seem
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // KEV RUAJ NTSEG: tus neeg hu yuav tsum khaws daim ntawv cog lus muaj kev nyab xeeb rau `FloatToInt::to_int_unchecked`.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// Raw transmutation rau `u64`.
    ///
    /// Qhov no yog tam sim no zoo ib yam rau `transmute::<f64, u64>(self)` ntawm txhua lub platform.
    ///
    /// Saib `from_bits` rau qee qhov kev sib tham txog kev hloov kho ntawm txoj haujlwm no (yuav luag tsis muaj teeb meem).
    ///
    /// Nco ntsoov tias txoj haujlwm no txawv ntawm `as` casting, uas npaj siab khaws cia *tus lej* tus nqi, thiab tsis yog tus nqi bitwise.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((1f64).to_bits() != 1f64 as u64); // to_bits() tsis yog pov!
    /// assert_eq!((12.5f64).to_bits(), 0x4029000000000000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u64 {
        // KEV RUAJ NTSEG: `u64` yog lub tiaj teev cov ntawv qub vim li ntawd peb tuaj yeem xa mus rau nws
        unsafe { mem::transmute(self) }
    }

    /// Raw transmutation los ntawm `u64`.
    ///
    /// Qhov no yog tam sim no zoo ib yam rau `transmute::<u64, f64>(v)` ntawm txhua lub platform.
    /// Nws hloov tawm qhov no yog qhov tsis txaus ntseeg tau yooj yim, rau ob qho laj thawj:
    ///
    /// * Floats thiab Ints muaj qhov zoo tib yam ntawm txhua qhov chaw txhawb nqa.
    /// * IEEE-754 ib qho yooj yim heev tau qhia tseeb lub teeb me ntsis ntawm ntab.
    ///
    /// Txawm li cas los muaj yog ib tug caveat: ua ntej mus rau lub 2008 version ntawm IEEE-754, yuav ua li cas los txhais lus rau tus NaN signaling ntsis twb tsis tau teev.
    /// Feem ntau cov platforms (tsis pom zoo x86 thiab ARM) tau khaws cov txhais lus uas thaum kawg ua tiav xyoo 2008, tab sis qee tus tsis (tshwj xeeb MIPS).
    /// Raws li qhov tshwm sim, txhua daim paib NaNs ntawm MIPS yog ntsiag to NaNs ntawm x86, thiab hloov ua lwm yam.
    ///
    /// Ntau dua li kev sim khaws qhov taw qhia-tsis hais tus ntoo khaub lig-platform, qhov kev siv no nyiam khaws cia qhov tseeb.
    /// Qhov no txhais tau tias txhua qhov kev them nyiaj nkag rau hauv NaNs yuav khaws cia txawm tias qhov txiaj ntsig ntawm hom no tau xa hla lub network los ntawm lub tshuab x86 mus rau MIPS ib.
    ///
    ///
    /// Yog hais tias cov txiaj ntsig ntawm txoj kev no tsuas yog kev tswj hwm los ntawm tib lub tsev lag luam uas tsim lawv, tom qab ntawd tsis muaj kev txhawj xeeb txog kev tsiv mus ncig.
    ///
    /// Yog hais tias lub tswv yim tsis yog NaN, ces tsis muaj qhov txhawj txog qhov hloov ntawm lub neej.
    ///
    /// Yog tias koj tsis mob siab txog kev taw qhia-tsis zoo (ntxim li yuav muaj), yog li tsis muaj qhov txhawj xeeb txog ntawm lub rooj hloov kho.
    ///
    /// Nco ntsoov tias txoj haujlwm no txawv ntawm `as` casting, uas npaj siab khaws cia *tus lej* tus nqi, thiab tsis yog tus nqi bitwise.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f64::from_bits(0x4029000000000000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u64) -> Self {
        // KEV RUAJ NTSEG: `u64` yog lub tiaj teev cov ntawv qub vim li ntawd peb tuaj yeem xa tawm ntawm nws
        // Nws hloov tawm qhov teeb meem kev nyab xeeb nrog sNaN tau dhau los!Ntxawm!
        unsafe { mem::transmute(v) }
    }

    /// Xa rov qab lub cim sawv cev ntawm qhov taw tes ntab ntaws no raws li byte array hauv qhov loj-endian (network) byte kev txiav txim.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_be_bytes();
    /// assert_eq!(bytes, [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 8] {
        self.to_bits().to_be_bytes()
    }

    /// Rov qab cov cim sawv cev ntawm cov naj npawb ntab no ua ntu byte hauv me-endian byte kev txiav txim.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 8] {
        self.to_bits().to_le_bytes()
    }

    /// Rov qab cov cim sawv cev ntawm cov naj npawb ntab no ua ntu byte hauv ib txwm byte.
    ///
    /// Raws li lub hom phiaj platform lub haiv neeg endianness siv, portable code yuav tsum siv [`to_be_bytes`] lossis [`to_le_bytes`], raws li tsim nyog, hloov.
    ///
    ///
    /// [`to_be_bytes`]: f64::to_be_bytes
    /// [`to_le_bytes`]: f64::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 8] {
        self.to_bits().to_ne_bytes()
    }

    /// Rov qab cov cim sawv cev ntawm cov naj npawb ntab no ua ntu byte hauv ib txwm byte.
    ///
    ///
    /// [`to_ne_bytes`] yuav tsum tau xav zoo dua qhov no thaum twg ua tau.
    ///
    /// [`to_ne_bytes`]: f64::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f64;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 8] {
        // KEV RUAJ NTSEG: `f64` yog lub tiaj teev cov ntawv qub vim li ntawd peb tuaj yeem xa mus rau nws
        unsafe { &*(self as *const Self as *const _) }
    }

    /// Tsim qhov chaw ntab tus nqi los ntawm nws cov sawv cev ua ib byte array hauv endian loj.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_be_bytes([0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_be_bytes(bytes))
    }

    /// Tsim qhov chaw ntab tus nqi los ntawm nws cov sawv cev raws li byte array hauv me endian.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_le_bytes([0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_le_bytes(bytes))
    }

    /// Tsim qhov chaw ntab tus nqi ntawm nws cov sawv cev ua ib byte array hauv haiv neeg endian.
    ///
    /// Raws li lub hom phiaj platform lub haiv neeg endianness siv, portable code yuav xav siv [`from_be_bytes`] lossis [`from_le_bytes`], raws li tsim nyog hloov.
    ///
    ///
    /// [`from_be_bytes`]: f64::from_be_bytes
    /// [`from_le_bytes`]: f64::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_ne_bytes(bytes))
    }

    /// Rov qab los ib qho xaj ntawm tus kheej thiab lwm yam nqi.
    /// Tsis zoo li tus qauv ntawm qhov sib piv ntawm cov naj npawb ntab, qhov kev sib piv no ib txwm ua ib qho kev txiav txim siab raws li totalOrder kwv yees raws li tau txhais hauv IEEE 754 (2008 kev kho dua tshiab) ntab point standard.
    /// Tus nqi yog txiav txim raws li hauv qab no:
    /// - Lub Neej Tsis Ntshaw NaN
    /// - Kev Taw Qhia Tsis Zoo NaN
    /// - Tsis zoo infinity
    /// - Cov lej tsis zoo
    /// - Cov lej tsis zoo tsis xws luag
    /// - Kev tsis zoo xoom
    /// - Zoo xoom
    /// - Cov lej ntawm neeg siv tsis zoo
    /// - Cov zauv zoo
    /// - Zoo infinity
    /// - Muaj cim zoo NaN
    /// - Zoo ntsiag to NaN
    ///
    /// Nco ntsoov tias txoj haujlwm no ib txwm tsis pom zoo nrog [`PartialOrd`] thiab [`PartialEq`] kev coj ua ntawm `f64`.Tshwj xeeb, lawv suav qhov tsis zoo thiab qhov tsis zoo yog qhov sib luag, thaum `total_cmp` tsis.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f64,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f64::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f64::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f64::INFINITY, f64::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i64;
        let mut right = other.to_bits() as i64;

        // Thaum muaj teeb meem tsis zoo, rov qab txhua yam me me tsuas yog kos npe rau kom ua tiav qhov qauv zoo sib xws li ob qho kev sib txuam
        //
        // Vim li cas qhov haujlwm no?IEEE 754 ntab muaj peb daim teb:
        // Kos npe me ntsis, exponent thiab mantissa.Cov teeb ntawm qhov kev piav qhia thiab cov chaw mantissa raws li tag nrho muaj cov cuab yeej uas lawv cov kev txiav txim siab bitwise yog sib npaug nrog cov zauv suav qhov chaw uas qhov loj tau txhais.
        // Qhov ntau tsawg tsis yog ib txwm tau txhais ntawm NaN qhov tseem ceeb, tab sis IEEE 754 totalOrder txhais lub NaN qhov tseem ceeb tseem ua raws cov kev txiav txim siab bitwise.Qhov no ua rau kev txiav txim piav qhia hauv cov lus doc.
        // Txawm li cas los xij, kev sawv cev ntawm kev ntsuas tau zoo ib yam rau qhov tsis zoo thiab tus naj npawb zoo-tsuas yog qhov kos npe me ntsis muaj qhov sib txawv.
        // Yuav kom yooj yim piv cov floats uas tau kos npe rau hauv cov zauv, peb yuav tsum tig cov nplauv thiab mantissa cov teeb meem ntawm cov lej tsis zoo.
        // Peb tau hloov cov lej mus rau "two's complement" daim foos.
        //
        // Txhawm rau ua qhov ntxeev, peb tsim lub npog ntsej muag thiab XOR tiv thaiv nws.
        // Peb ceg tsis yooj yim suav lub "all-ones except for the sign bit" lub ntsej muag los ntawm kev tsis pom zoo kos npe qhov tseem ceeb: txoj cai txav-kos npe-txuas rau tus zauv, yog li peb "fill" lub npog ntsej muag nrog cov paib kos npe, thiab tom qab ntawd hloov mus rau unsigned kom thawb ib qho ntxiv xoom me.
        //
        // Ntawm cov txiaj ntsig zoo, daim npog ntsej muag yog txhua qhov xoom, yog li nws yog tsis muaj op.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 63) as u64) >> 1) as i64;
        right ^= (((right >> 63) as u64) >> 1) as i64;

        left.cmp(&right)
    }

    /// Txwv tus nqi rau qee lub sijhawm tshwj tsis yog nws yog NaN.
    ///
    /// Rov `max` yog `self` yog ntau tshaj `max`, thiab `min` yog `self` yog tsawg tshaj li `min`.
    /// Txwv tsis pub no rov `self`.
    ///
    /// Nco ntsoov tias txoj haujlwm no rov qab NaN yog tias tus nqi pib yog NaN ib yam nkaus.
    ///
    /// # Panics
    ///
    /// Panics yog `min > max`, `min` yog NaN, lossis `max` yog NaN.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f64).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f64).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f64).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f64::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f64, max: f64) -> f64 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}