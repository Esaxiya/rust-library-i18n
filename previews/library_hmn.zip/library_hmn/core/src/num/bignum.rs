//! Nchuav arbitrary-precision tooj (bignum) kev siv.
//!
//! Qhov no yog tsim los kom tsis txhob muaj cov heap faib nyob rau ntawm cov nuj nqis ntawm lub cim xeeb nco.
//! Kev siv bignum ntau tshaj plaws, `Big32x40`, tsuas yog txwv ntawm 32 × 40=1,280 khoom thiab yuav siv ntau ntawm 160 bytes ntawm cov cim xeeb tshooj.
//! Qhov no yog ntau tshaj li txaus rau puag ncig-tripping txhua qhov ua tau finite `f64` qhov tseem ceeb.
//!
//! Hauv txoj ntsiab cai nws muaj peev xwm kom muaj ntau hom bignum rau cov lus sib txawv, tab sis peb tsis ua li ntawd kom tsis txhob muaj qhov kev nrawm.
//!
//! Txhua daim bignum tseem tau taug qab rau kev siv tiag tiag, yog li nws ib txwm tsis muaj teeb meem.
//!

// Qhov qauv no tsuas yog rau dec2flt thiab flt2dec, thiab tsuas yog pej xeem vim ntawm coretests.
// Nws tsis yog yuav ruaj khov.
#![doc(hidden)]
#![unstable(
    feature = "core_private_bignum",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]
#![macro_use]

use crate::intrinsics;

/// Arithmetic kev khiav haujlwm xav tau los ntawm bignums.
pub trait FullOps: Sized {
    /// Rov qab `(carry', v')` xws li tias `carry' * 2^W + v' = self + other + carry`, qhov twg `W` yog tus lej ntawm cov hauv `Self`.
    ///
    fn full_add(self, other: Self, carry: bool) -> (bool /* carry */, Self);

    /// Rov qab `(carry', v')` xws li tias `carry'*2^W + v' = self* other + carry`, qhov twg `W` yog tus lej ntawm cov hauv `Self`.
    ///
    fn full_mul(self, other: Self, carry: Self) -> (Self /* carry */, Self);

    /// Rov qab `(carry', v')` xws li tias `carry'*2^W + v' = self* other + other2 + carry`, qhov twg `W` yog tus lej ntawm cov hauv `Self`.
    ///
    fn full_mul_add(self, other: Self, other2: Self, carry: Self) -> (Self /* carry */, Self);

    /// Rov qab `(quo, rem)` xws li tias `borrow *2^W + self = quo* other + rem` thiab `0 <= rem < other`, qhov twg `W` yog tus lej ntawm cov bits hauv `Self`.
    ///
    fn full_div_rem(self, other: Self, borrow: Self)
    -> (Self /* quotient */, Self /* remainder */);
}

macro_rules! impl_full_ops {
    ($($ty:ty: add($addfn:path), mul/div($bigty:ident);)*) => (
        $(
            impl FullOps for $ty {
                fn full_add(self, other: $ty, carry: bool) -> (bool, $ty) {
                    // Qhov no tsis tuaj yeem dhau;Cov zis yog nyob nruab nrab ntawm `0` thiab `2 * 2^nbits - 1`.
                    // FIXME: yuav LLVM ua kom zoo dua qhov no mus rau ADC lossis zoo sib xws?
                    let (v, carry1) = intrinsics::add_with_overflow(self, other);
                    let (v, carry2) = intrinsics::add_with_overflow(v, if carry {1} else {0});
                    (carry1 || carry2, v)
                }

                fn full_mul(self, other: $ty, carry: $ty) -> ($ty, $ty) {
                    // Qhov no tsis tuaj yeem dhau;
                    // Cov zis yog nyob nruab nrab ntawm `0` thiab `2^nbits * (2^nbits - 1)`.
                    // FIXME: yuav LLVM ua kom zoo dua qhov no mus rau ADC lossis zoo sib xws?
                    let v = (self as $bigty) * (other as $bigty) + (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_mul_add(self, other: $ty, other2: $ty, carry: $ty) -> ($ty, $ty) {
                    // Qhov no tsis tuaj yeem dhau;
                    // Cov zis yog nyob nruab nrab ntawm `0` thiab `2^nbits * (2^nbits - 1)`.
                    let v = (self as $bigty) * (other as $bigty) + (other2 as $bigty) +
                            (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_div_rem(self, other: $ty, borrow: $ty) -> ($ty, $ty) {
                    debug_assert!(borrow < other);
                    // Qhov no tsis tuaj yeem dhau;Cov zis yog nyob nruab nrab ntawm `0` thiab `other * (2^nbits - 1)`.
                    let lhs = ((borrow as $bigty) << <$ty>::BITS) | (self as $bigty);
                    let rhs = other as $bigty;
                    ((lhs / rhs) as $ty, (lhs % rhs) as $ty)
                }
            }
        )*
    )
}

impl_full_ops! {
    u8:  add(intrinsics::u8_add_with_overflow),  mul/div(u16);
    u16: add(intrinsics::u16_add_with_overflow), mul/div(u32);
    u32: add(intrinsics::u32_add_with_overflow), mul/div(u64);
    // Saib RFC #521 rau qhov no.
    // u64: add(intrinsics::u64_add_with_overflow), mul/div(u128);
}

/// Cov lus ntawm lub hwj chim ntawm 5 sawv cev hauv cov lej.Tshwj xeeb, ntau tshaj plaws {u8, u16, u32} tus nqi uas yog lub zog ntawm tsib, ntxiv rau cov ntsuas kev cuam tshuam.
/// Siv hauv `mul_pow5`.
const SMALL_POW5: [(u64, usize); 3] = [(125, 3), (15625, 6), (1_220_703_125, 13)];

macro_rules! define_bignum {
    ($name:ident: type=$ty:ty, n=$n:expr) => {
        /// Pawg-faib kev txiav txim siab-kev ncaj ncees (txog qee qhov txwv) tus lej.
        ///
        /// Qhov no yog rov qab los ntawm kev tsau ruaj ruaj uas muab hom ("digit").
        /// Thaum lub array tsis loj heev (feem ntau qee pua bytes), theej nws recklessly yuav ua rau muaj kev ntaus nrig.
        ///
        /// Yog li qhov no yog txhob txwm tsis `Copy`.
        ///
        /// Tag nrho cov kev ua haujlwm muaj rau bignums panic tus yam dhau.
        /// Tus neeg hu khoom yog lub luag haujlwm los siv hom loj loj bignum.
        pub struct $name {
            /// Ib qho ntxiv ntawm qhov offset rau qhov siab tshaj plaws "digit" hauv kev siv.
            /// Qhov no tsis txo, yog li paub txog kev txiav txim xaj.
            /// `base[size..]` yuav tsum xoom.
            size: usize,
            /// Digits.
            /// `[a, b, c, ...]` sawv cev `a + b *2^W + c* 2^(2W) + ...` qhov twg `W` yog tus lej ntawm cov lej.
            base: [$ty; $n],
        }

        impl $name {
            /// Ua rau bignum los ntawm ib tus lej.
            pub fn from_small(v: $ty) -> $name {
                let mut base = [0; $n];
                base[0] = v;
                $name { size: 1, base: base }
            }

            /// Ua rau bignum los ntawm `u64` tus nqi.
            pub fn from_u64(mut v: u64) -> $name {
                let mut base = [0; $n];
                let mut sz = 0;
                while v > 0 {
                    base[sz] = v as $ty;
                    v >>= <$ty>::BITS;
                    sz += 1;
                }
                $name { size: sz, base: base }
            }

            /// Rov qab rau hauv cov lej sab hauv li daim hlais `[a, b, c, ...]` xws tias tus lej suav yog `a + b *2^W + c* 2^(2W) + ...` qhov twg `W` yog tus lej ntawm cov lej hauv tus lej.
            ///
            ///
            pub fn digits(&self) -> &[$ty] {
                &self.base[..self.size]
            }

            /// Rov qab los rau `i`-th qhov twg ntsis 0 yog qhov tseem ceeb tshaj plaws.
            /// Hauv lwm lo lus, lub ntsis nrog hnyav `2^i`.
            pub fn get_bit(&self, i: usize) -> u8 {
                let digitbits = <$ty>::BITS as usize;
                let d = i / digitbits;
                let b = i % digitbits;
                ((self.base[d] >> b) & 1) as u8
            }

            /// Rov qab `true` yog tias bignum yog xoom.
            pub fn is_zero(&self) -> bool {
                self.digits().iter().all(|&v| v == 0)
            }

            /// Rov qab tus lej ntawm qhov tsim nyog los sawv cev tus nqi no.
            /// Nco ntsoov tias xoom yog xav tias yuav tsum muaj 0 cov khoom.
            pub fn bit_length(&self) -> usize {
                // Hla hla tus lej tseem ceeb tshaj plaws uas yog xoom.
                let digits = self.digits();
                let zeros = digits.iter().rev().take_while(|&&x| x == 0).count();
                let end = digits.len() - zeros;
                let nonzero = &digits[..end];

                if nonzero.is_empty() {
                    // Tsis muaj tus lej tsis xoom, piv txwv li, tus lej yog xoom.
                    return 0;
                }
                // Qhov no yuav kho kom zoo nrog leading_zeros() thiab hloov me ntsis, tab sis uas tej zaum tsis tsim nyog rau qhov hassle.
                //
                let digitbits = <$ty>::BITS as usize;
                let mut i = nonzero.len() * digitbits - 1;
                while self.get_bit(i) == 0 {
                    i -= 1;
                }
                i + 1
            }

            /// Ntxiv `other` rau nws tus kheej thiab rov nws tus kheej hloov kev siv tau.
            pub fn add<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let mut sz = cmp::max(self.size, other.size);
                let mut carry = false;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(*b, carry);
                    *a = v;
                    carry = c;
                }
                if carry {
                    self.base[sz] = 1;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            pub fn add_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let (mut carry, v) = self.base[0].full_add(other, false);
                self.base[0] = v;
                let mut i = 1;
                while carry {
                    let (c, v) = self.base[i].full_add(0, carry);
                    self.base[i] = v;
                    carry = c;
                    i += 1;
                }
                if i > self.size {
                    self.size = i;
                }
                self
            }

            /// Muab `other` rho tawm ntawm nws tus kheej thiab rov qab nws tus kheej hloov kev ua haujlwm.
            pub fn sub<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let sz = cmp::max(self.size, other.size);
                let mut noborrow = true;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(!*b, noborrow);
                    *a = v;
                    noborrow = c;
                }
                assert!(noborrow);
                self.size = sz;
                self
            }

            /// Tshaj tawm nws tus kheej los ntawm tus lej-`other` thiab rov nws tus kheej hloov siv tau.
            ///
            pub fn mul_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let mut sz = self.size;
                let mut carry = 0;
                for a in &mut self.base[..sz] {
                    let (c, v) = (*a).full_mul(other, carry);
                    *a = v;
                    carry = c;
                }
                if carry > 0 {
                    self.base[sz] = carry;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            /// Tshaj tawm nws tus kheej los ntawm `2^bits` thiab rov nws tus kheej hloov tau siv.
            pub fn mul_pow2(&mut self, bits: usize) -> &mut $name {
                let digitbits = <$ty>::BITS as usize;
                let digits = bits / digitbits;
                let bits = bits % digitbits;

                assert!(digits < $n);
                debug_assert!(self.base[$n - digits..].iter().all(|&v| v == 0));
                debug_assert!(bits == 0 || (self.base[$n - digits - 1] >> (digitbits - bits)) == 0);

                // hloov los ntawm `digits * digitbits` cov khoom me
                for i in (0..self.size).rev() {
                    self.base[i + digits] = self.base[i];
                }
                for i in 0..digits {
                    self.base[i] = 0;
                }

                // hloov los ntawm `bits` cov khoom me
                let mut sz = self.size + digits;
                if bits > 0 {
                    let last = sz;
                    let overflow = self.base[last - 1] >> (digitbits - bits);
                    if overflow > 0 {
                        self.base[last] = overflow;
                        sz += 1;
                    }
                    for i in (digits + 1..last).rev() {
                        self.base[i] =
                            (self.base[i] << bits) | (self.base[i - 1] >> (digitbits - bits));
                    }
                    self.base[digits] <<= bits;
                    // tus kheej.base [.. tus lej] yog xoom, tsis tas yuav hloov pauv
                }

                self.size = sz;
                self
            }

            /// Tshaj tawm nws tus kheej los ntawm `5^e` thiab rov nws tus kheej hloov tau siv.
            pub fn mul_pow5(&mut self, mut e: usize) -> &mut $name {
                use crate::mem;
                use crate::num::bignum::SMALL_POW5;

                // Muaj raws nraim n trailing xoom ntawm 2 ^ n, thiab tsuas yog tib qhov ntau thiab tsawg yog sib law liag fais fab ntawm ob, yog li qhov no yog qhov ntsuas tau zoo rau lub rooj.
                //
                let table_index = mem::size_of::<$ty>().trailing_zeros() as usize;
                let (small_power, small_e) = SMALL_POW5[table_index];
                let small_power = small_power as $ty;

                // Multiply nrog cov loj tshaj plaws ib-tus lej fais fab ntev li ntev tau ...
                while e >= small_e {
                    self.mul_small(small_power);
                    e -= small_e;
                }

                // ... tom qab ntawd ua kom tiav cov seem.
                let mut rest_power = 1;
                for _ in 0..e {
                    rest_power *= 5;
                }
                self.mul_small(rest_power);

                self
            }

            /// Txheeb nws tus kheej los ntawm tus lej piav qhia los ntawm `other[0] + other[1]*2^W + other[2]* 2^(2W) + ...` (qhov twg `W` yog tus lej ntawm cov lej ntawm tus lej) thiab rov qab nws tus kheej hloov kev siv tau.
            ///
            ///
            pub fn mul_digits<'a>(&'a mut self, other: &[$ty]) -> &'a mut $name {
                // txoj haujlwm sab hauv.ua haujlwm zoo tshaj plaws thaum aa.len() <= bb.len().
                fn mul_inner(ret: &mut [$ty; $n], aa: &[$ty], bb: &[$ty]) -> usize {
                    use crate::num::bignum::FullOps;

                    let mut retsz = 0;
                    for (i, &a) in aa.iter().enumerate() {
                        if a == 0 {
                            continue;
                        }
                        let mut sz = bb.len();
                        let mut carry = 0;
                        for (j, &b) in bb.iter().enumerate() {
                            let (c, v) = a.full_mul_add(b, ret[i + j], carry);
                            ret[i + j] = v;
                            carry = c;
                        }
                        if carry > 0 {
                            ret[i + sz] = carry;
                            sz += 1;
                        }
                        if retsz < i + sz {
                            retsz = i + sz;
                        }
                    }
                    retsz
                }

                let mut ret = [0; $n];
                let retsz = if self.size < other.len() {
                    mul_inner(&mut ret, &self.digits(), other)
                } else {
                    mul_inner(&mut ret, other, &self.digits())
                };
                self.base = ret;
                self.size = retsz;
                self
            }

            /// Faib nws tus kheej los ntawm tus lej-`other` thiab rov nws tus kheej los hloov siv *thiab* qhov seem.
            ///
            pub fn div_rem_small(&mut self, other: $ty) -> (&mut $name, $ty) {
                use crate::num::bignum::FullOps;

                assert!(other > 0);

                let sz = self.size;
                let mut borrow = 0;
                for a in self.base[..sz].iter_mut().rev() {
                    let (q, r) = (*a).full_div_rem(other, borrow);
                    *a = q;
                    borrow = r;
                }
                (self, borrow)
            }

            /// Faib rau tus kheej los ntawm lwm lub bignum, sau dua `q` nrog cov quotient thiab `r` nrog cov seem.
            ///
            pub fn div_rem(&self, d: &$name, q: &mut $name, r: &mut $name) {
                // Stupid qeeb base-2 ntev faib tshwm sim los ntawm
                // https://en.wikipedia.org/wiki/Division_algorithm
                // FIXME siv lub hauv paus loj dua ($ty) rau kev faib ntev.
                assert!(!d.is_zero());
                let digitbits = <$ty>::BITS as usize;
                for digit in &mut q.base[..] {
                    *digit = 0;
                }
                for digit in &mut r.base[..] {
                    *digit = 0;
                }
                r.size = d.size;
                q.size = 1;
                let mut q_is_zero = true;
                let end = self.bit_length();
                for i in (0..end).rev() {
                    r.mul_pow2(1);
                    r.base[0] |= self.get_bit(i) as $ty;
                    if &*r >= d {
                        r.sub(d);
                        // Teeb me ntsis `i` ntawm q rau 1.
                        let digit_idx = i / digitbits;
                        let bit_idx = i % digitbits;
                        if q_is_zero {
                            q.size = digit_idx + 1;
                            q_is_zero = false;
                        }
                        q.base[digit_idx] |= 1 << bit_idx;
                    }
                }
                debug_assert!(q.base[q.size..].iter().all(|&d| d == 0));
                debug_assert!(r.base[r.size..].iter().all(|&d| d == 0));
            }
        }

        impl crate::cmp::PartialEq for $name {
            fn eq(&self, other: &$name) -> bool {
                self.base[..] == other.base[..]
            }
        }

        impl crate::cmp::Eq for $name {}

        impl crate::cmp::PartialOrd for $name {
            fn partial_cmp(&self, other: &$name) -> crate::option::Option<crate::cmp::Ordering> {
                crate::option::Option::Some(self.cmp(other))
            }
        }

        impl crate::cmp::Ord for $name {
            fn cmp(&self, other: &$name) -> crate::cmp::Ordering {
                use crate::cmp::max;
                let sz = max(self.size, other.size);
                let lhs = self.base[..sz].iter().cloned().rev();
                let rhs = other.base[..sz].iter().cloned().rev();
                lhs.cmp(rhs)
            }
        }

        impl crate::clone::Clone for $name {
            fn clone(&self) -> Self {
                Self { size: self.size, base: self.base }
            }
        }

        impl crate::fmt::Debug for $name {
            fn fmt(&self, f: &mut crate::fmt::Formatter<'_>) -> crate::fmt::Result {
                let sz = if self.size < 1 { 1 } else { self.size };
                let digitlen = <$ty>::BITS as usize / 4;

                write!(f, "{:#x}", self.base[sz - 1])?;
                for &v in self.base[..sz - 1].iter().rev() {
                    write!(f, "_{:01$x}", v, digitlen)?;
                }
                crate::result::Result::Ok(())
            }
        }
    };
}

/// Cov lej rau `Big32x40`.
pub type Digit32 = u32;

define_bignum!(Big32x40: type=Digit32, n=40);

// qhov ib yog siv rau kev xeem nkaus xwb.
#[doc(hidden)]
pub mod tests {
    define_bignum!(Big8x3: type=u8, n=3);
}