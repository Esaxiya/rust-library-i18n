//! Ntsis fiddling ntawm zoo IEEE 754 ntab.Cov lej tsis zoo tsis yog thiab tsis tsim los daws.
//! Cov naj npawb floating niaj hnub muaj qhov sawv cev canonical raws li (frac, exp) xws li tias tus nqi yog 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)) qhov twg N yog tus lej ntawm cov khoom.
//!
//! Subnormals kuj sib txawv me ntsis thiab txawv, tab sis tib lub hauv paus ntawv siv tau.
//!
//! Ntawm no, txawm li cas los xij, peb sawv cev lawv li (sig, k) nrog f zoo, xws li tias tus nqi yog f *
//! 2 <sup>e</sup> .Dhau li ua qhov "hidden bit" qhia tau meej heev, qhov kev hloov pauv ntawm cov kev hloov pauv ntawm kev sib pauv mantissa.
//!
//! Muab lwm txoj kev, nquag ntab sau yog (1) tab sis ntawm no lawv tau sau ua (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Peb hu (1) tus **tus sawv cev feem pua** thiab (2) tus sawv cev **.
//!
//! Ntau yam haujlwm hauv qhov qauv no tsuas yog siv cov lej ib txwm xwb.Cov kab ke dec2flt txhawm rau txhawm rau txhawm rau siv txoj kev qeeb ntawm txoj kev (Algorithm M) rau tus lej me thiab loj heev.
//! Tias lub algorithm xav tau tsuas yog next_float() uas lis cov subnormals thiab tus lej.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// Tus pab trait kom tsis txhob theej tawm yooj yim dua txhua tus lej hloov dua siab tshiab rau `f32` thiab `f64`.
///
/// Saib tus niam txiv module tsim tawm lus hais rau vim li cas qhov no tsim nyog.
///
/// Yuav tsum **yeej tsis tau** yuav siv rau lwm hom lossis siv sab nraum dec2flt module.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Yam siv los ntawm `to_bits` thiab `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Ua lub transmutation nyoos rau cov zauv.
    fn to_bits(self) -> Self::Bits;

    /// Ua lub transmutation nyoos los ntawm ib tug zauv.
    fn from_bits(v: Self::Bits) -> Self;

    /// Rov qab rau qeb uas tus lej no poob rau hauv.
    fn classify(self) -> FpCategory;

    /// Rov qab los ntawm mantissa, exponent thiab sau npe ua zauv.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Txiav txim siab ntab.
    fn unpack(self) -> Unpacked;

    /// Casts los ntawm tus lej me me uas tuaj yeem sawv cev tau raws nraim.
    /// Panic yog tias tus lej tsis tuaj yeem sawv cev tau, lwm tus lej hauv qhov qauv no nco ntsoov tsis txhob cia qhov ntawd tshwm sim.
    fn from_int(x: u64) -> Self;

    /// Tau txais tus nqi 10 <sup>e</sup> los ntawm lub rooj xam ua ntej.
    /// Panics rau `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Dab tsi lub npe hais tias.
    /// Nws yooj yim dua qhov nyuaj dua li juggling intrinsics thiab cia siab LLVM khawm nws tas li.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Ib txoj kev xav tshwj tseg cia nyob rau ntawm tus lej zauv ntawm qhov muab nkag uas tsis tuaj yeem tsim txeej dhau los yog xoom lossis
    /// subnormals.Tej zaum cov zauv xaus ntawm qhov ntau tshaj ib txwm muaj nqis, chaw pib lub npe.
    const MAX_NORMAL_DIGITS: usize;

    /// Thaum cov zauv feem ntau tseem ceeb muaj lub chaw tus nqi ntau dua qhov no, tus naj npawb yeej yog qhov sib npaug ntawm infinity.
    ///
    const INF_CUTOFF: i64;

    /// Thaum cov lej tshwj xeeb tshaj plaws muaj cov chaw tus nqi tsawg dua qhov no, tus naj npawb yeej yog tus lej xoom.
    ///
    const ZERO_CUTOFF: i64;

    /// Tus naj npawb ntawm cov khoom hauv cov exponent.
    const EXP_BITS: u8;

    /// Tus lej ntawm cov khoom hauv qhov tseem ceeb thiab,*suav nrog* tus lej zais.
    const SIG_BITS: u8;

    /// Tus lej ntawm cov khoom hauv qhov tseem ceeb thiab,*tsis suav nrog* lub zais me.
    const EXPLICIT_SIG_BITS: u8;

    /// Qhov siab kawg tshaj plaws kev piav qhia nyob rau hauv feem fractional sawv cev.
    const MAX_EXP: i16;

    /// Qhov tsawg kawg tshaj plaws kev cai lij choj nyob rau hauv feem fractional sawv cev, tsis suav nrog subnormals.
    const MIN_EXP: i16;

    /// `MAX_EXP` rau kev sawv cev tam, piv txwv li, nrog kev hloov pauv tau thov.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` encoded (piv txwv li, nrog offset kev cuam tshuam)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` rau kev sawv cev tam, piv txwv li, nrog kev hloov pauv tau thov.
    const MIN_EXP_INT: i16;

    /// Qhov siab tshaj plaws ib txwm tau hais rau sawv cev.
    const MAX_SIG: u64;

    /// Tsawg tsawg kawg nkaus ib txwm siv rau kev sawv cev tam sim no.
    const MIN_SIG: u64;
}

// Feem ntau yog qhov kev ua haujlwm rau #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Rov qab los ntawm mantissa, exponent thiab sau npe ua zauv.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Qhia ncua kev tsis ncaj ncees + hloov pauv mantissa
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe tsis paub meej xyov `as` muab suav kom raug rau txhua lub platform.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Rov qab los ntawm mantissa, exponent thiab sau npe ua zauv.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Qhia ncua kev tsis ncaj ncees + hloov pauv mantissa
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe tsis paub meej xyov `as` muab suav kom raug rau txhua lub platform.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Converts `Fp` kom ze rau lub tshuab ntab hom.
/// Tsis coj mus raws li cov ntsiab lus tsis tau pom.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f yog 64 me ntsis, yog li xe muaj lub mantissa hloov ntawm 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Muab txoj kab 64 me ntsis txhais thiab rau T::SIG_BITS cov khoom nrog ib nrab-rau-txawm.
/// Tsis coj mus sab nrauv tshaj dhau.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Kho mantissa hloov pauv
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Rov qab ntawm `RawFloat::unpack()` rau cov lej ib txwm.
/// Panics yog tias qhov tseem ceeb thiab cov lej tsis siv rau cov naj npawb ib txwm.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Tshem tawm cov zais me ntsis
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Kho qhov ua kom nrov rau cov kev piav qhia kev ntxeev siab thiab mantissa hloov
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Tso npe kos ntsis ntawm 0 ("+"), peb tus lej sawv daws tau zoo
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Tsim kom muaj ib qho tsis meej.Lub mantissa ntawm 0 yog tso cai thiab tsim xoom.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Encoded exponent yog 0, qhov kos npe me ntsis yog 0, yog li peb tsuas yog yuav tsum txhais cov khoom me me rov qab.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Kwv yees ib bignum nrog ib qho Fp.Cov kab xaum nyob hauv 0.5 ULP nrog ib nrab-rau-txawm.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Peb txiav tawm txhua qhov me me ua ntej qhov ntsuas `start`, piv txwv li, peb muaj txoj cai zoo-hloov los ntawm tus nqi ntawm `start`, yog li qhov no kuj yog qhov kev nthuav qhia peb xav tau.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Hloov (half-to-even) nyob ntawm cov kab uas txiav tawm.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Pom cov xov tooj ntab ntau tshaj plaws me me tshaj li qhov sib cav.
/// Tsis siv subnormals, xoom, lossis exponent underflow.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Nrhiav cov ntsiab lus ntab tsawg tshaj plaws ntawm qhov kev sib cav.
// Txoj haujlwm no yog txaus, piv txwv li, next_float(inf) ==inf.
// Tsis zoo li feem ntau cov cai hauv qhov qauv no, qhov haujlwm no lis cov xoom, subnormals, thiab infinities.
// Txawm li cas los xij, zoo li txhua lwm cov cai ntawm no, nws tsis cuam tshuam nrog NaN thiab cov lej tsis zoo.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Qhov no zoo nkaus li dhau los ua qhov tseeb, tab sis nws ua haujlwm.
        // 0.0 yog tshaj plaws raws li txhua lo lus xoom.Subnormals yog 0x000m ... m qhov twg m yog mantissa.
        // Hauv tshwj xeeb, qhov tsis sib luag me me yog 0x0 ... 01 thiab qhov loj tshaj plaws yog 0x000F ... F.
        // Tus lej tsawg tshaj plaws yog 0x0010 ... 0, yog li cov ntaub ntawv no ib txwm ua haujlwm ib yam nkaus.
        // Yog tias qhov nce zuj zus dhau ntawm qhov mantissa, tus nqa khoom nce zuj zus cov kev nthuav qhia raws li peb xav tau, thiab cov khoom ntsuas mantissa dhau los ua xoom.
        // Vim hais tias zais lub rooj sib txoos me me, qhov no dhau lawm yog qhov peb xav tau!
        // Thaum kawg, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}