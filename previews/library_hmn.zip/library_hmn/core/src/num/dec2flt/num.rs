//! Kev siv dej ua haujlwm rau bignums uas tsis raug rau dhau los ua kev xav.

// FIXME Tus qauv ntawm lub npe no yog me ntsis tsis muaj hmoo, vim tias lwm qhov ntxiv kuj tau import `core::num`.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Ntsuam seb puas tau txiav txhua txoj kab me dua tsawg dua `ones_place` qhia txog qhov txheeb ze yuam kev tsawg dua, sib npaug, lossis ntau dua 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Yog tias txhua qhov txuas ntxiv yog xoom, nws yog= 0.5 ULP, txwv tsis pub> 0.5 Yog tias tsis muaj cov khoom me me ntxiv (half_bit==0), hauv qab no kuj raug rov qab sib npaug.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Hloov tus hlua ASCII uas tsuas muaj lej tsuas mus rau `u64`.
///
/// Tsis ua cov tshev rau txeej lossis cov cim tsis muaj tseeb, yog li yog tias tus neeg hu tsis ceev faj, qhov tshwm sim yog bogus thiab tuaj yeem panic (txawm tias nws yuav tsis yog `unsafe`).
/// Ib qho ntxiv, cov hlua khoob tau kho ua xoom.
/// Muaj nuj nqi no tshwm sim vim
///
/// 1. siv `FromStr` ntawm `&[u8]` xav tau `from_utf8_unchecked`, uas yog qhov tsis zoo, thiab
/// 2. piecing ua ke cov txiaj ntsig ntawm `integral.parse()` thiab `fractional.parse()` yog qhov nyuaj ntau dua li tag nrho cov haujlwm no.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Hloov ib txoj hlua ntawm ASCII tus lej mus rau bignum.
///
/// Zoo li `from_str_unchecked`, txoj haujlwm no tso siab rau kev tshawb rau weed tawm uas tsis yog tus lej.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Unwraps bignum rau hauv 64 tus lej zauv.Panics yog tias tus lej loj heev.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Extract ntau ntawm cov khoom me me.

/// Qhov ntsuas 0 yog qhov tseem ceeb me ntsis thiab qhov ntau yog ib nrab qhib raws li ib txwm muaj.
/// Panics yog nug kom rho tawm cov ntau tshaj li qhov haum rau hauv hom rov qab.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}