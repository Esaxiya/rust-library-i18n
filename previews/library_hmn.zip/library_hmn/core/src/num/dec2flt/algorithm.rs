//! Cov txheej txheem ntau yam los ntawm daim ntawv.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Tus naj npawb ntawm qhov ntsuas thiab cov khoom me me hauv Fp
const P: u32 = 64;

// Peb tsuas khaws cov khoom kwv yees zoo tshaj plaws rau *txhua qhov* exponents, yog li "h" X kuj sib txawv thiab cov mob uas cuam tshuam tuaj yeem raug rho tawm.
// Qhov no ua tiav kev ua haujlwm rau ob peb kilobytes ntawm qhov chaw.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// Nyob rau hauv feem ntau cov architectures, floating taw tes haujlwm muaj qhov sib txawv me ntsis qhov loj me, yog li ntawd qhov tseeb ntawm qhov ntsuas tau txiav txim siab ntawm kev ua haujlwm ib zaug.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// Ntawm x86, x87 FPU siv rau cov haujlwm ntab yog tias SSE/SSE2 txuas ntxiv tsis muaj.
// Lub x87 FPU kev khiav haujlwm nrog 80 cov kab lus ntawm qhov tseeb los ntawm lub neej ntawd, uas txhais tau tias kev ua haujlwm yuav ncig mus rau 80 me me ua rau ob chav kev sib hloov tshwm sim thaum cov nqi kawg nws thiaj li sawv cev
//
// 32/64 ntsis ntab qhov tseem ceeb.Yuav kom kov yeej qhov no, FPU lo lus tswj hwm tuaj yeem tsim kom thiaj li ua tiav kev ntsuas nyob rau hauv qhov xav tau ntsuas.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// Tus qauv siv los khaws lub qub nqi ntawm FPU kev tswj hwm lo lus, kom nws rov qab los thaum cov qauv poob.
    ///
    ///
    /// Lub x87 FPU yog 16-qho sau npe nws cov liaj teb yog li hauv qab no:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// Cov ntaub ntawv rau txhua daim teb muaj nyob hauv IA-32 Architectures Software Developer Phau Ntawv (Volume 1).
    ///
    /// Tsuas yog daim teb uas cuam tshuam rau cov cai hauv qab no yog PC, Precision Control.
    /// Daim teb no txiav txim siab qhov raug ntawm cov haujlwm uas tau ua los ntawm FPU.
    /// Nws tuaj yeem teeb tau:
    ///  - 0b00, ib qho meej piv txwv li, 32-txoj siv
    ///  - 0b10, ob chav precision qhov tseeb, 64-khoom
    ///  - 0b11, ob chav kev npliag piv txwv li, 80-txoj kab (lub xeev tsis raug) Tus nqi 0b01 tshwj tseg thiab tsis siv.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // KEV RUAJ NTSEG: kev qhia `fldcw` tau raug txheeb xyuas kom ua tiav tau nrog kev ua haujlwm tau zoo
        // tej `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: Peb tab tom siv ATT syntax los pab LLVM 8 thiab LLVM 9.
                options(att_syntax, nostack),
            )
        }
    }

    /// Teev qhov tseeb ntawm thaj FPU rau `T` thiab rov xa tus `FPUControlWord`.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Xam tus nqi rau Precision Control teb uas tsim nyog rau `T`.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 lub qhov
            8 => 0x0200, // 64 me me
            _ => 0x0300, // default, 80 khoom
        };

        // Tau txais tus nqi qub ntawm cov lus tswj kom rov qab nws tom qab, thaum tus qauv `FPUControlWord` poob qis Kev Ruaj Ntseg: qhov kev qhia `fnstcw` tau txheeb xyuas kom muaj peev xwm ua haujlwm tau nrog txhua `u16`
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: Peb tab tom siv ATT syntax los pab LLVM 8 thiab LLVM 9.
                options(att_syntax, nostack),
            )
        }

        // Teem cov lus tswj hwm rau qhov xav tau raug.
        // Qhov no yog ua tiav los ntawm kev npog qhov tseeb ntawm cov laus ua tiav (cov khoom 8 thiab 9, 0x300) thiab hloov nws nrog tus npliag precision xam rau saum toj no.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// Txoj kev nrawm nrawm ntawm Bellerophon siv lub cav loj-loj los sib xyaw thiab ntab.
///
/// Qhov no yog muab rho tawm ua haujlwm cais kom nws tuaj yeem sim ua ntej tsim bignum.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Peb piv tus nqi pes tsawg rau MAX_SIG ze rau qhov kawg, qhov no tsuas yog cuam tshuam sai, pheej yig tsis lees paub (thiab kuj tseem muaj qhov seem ntawm cov cai los ntawm kev txhawj xeeb txog underflow).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // Txoj kev nrawm tseem ceeb nyob ntawm kev laij zauv raug kwv yees mus rau qhov tseeb ntawm cov khoom siv yam tsis muaj kev sib puag ncig ib nrab.
    // Ntawm x86 (tsis muaj SSE lossis SSE2) qhov no xav tau qhov tseeb ntawm x87 FPU pawg yuav tsum tau hloov kom nws ncaj qha mus rau 64/32 ntsis.
    // Qhov `set_precision` muaj nuj nqi yuav saib xyuas kev teeb tsa lub precision ntawm cov qauv ua haujlwm uas yuav tsum teeb tsa nws los ntawm kev hloov pauv thoob lub ntiaj teb (zoo li cov lus tswj hwm ntawm x87 FPU).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // Qhov teeb meem e <0 tsis tuaj yeem muab zais mus rau lwm yam branch.
    // Cov hwj chim tsis zoo ua rau rov qab ua ntu zus rau hauv cov binary, uas yog cov sib npaug, uas ua rau muaj qhov yuam kev (thiab qee zaus tseem ceeb!) Qhov yuam kev thaum kawg tshwm sim.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// Algorithm Bellerophon yog tsis tseem ceeb txoj cai siv los ntawm tsis yog-tsis tseem ceeb tus lej tsom xam.
///
/// Nws muab ncig ``f` `rau ntab nrog 64 ntsis nqe thiab muab coj los sib ntxiv los ntawm qhov zoo tshaj plaws ntawm `10^e` (nyob rau tib hom kis taw tes).Qhov no feem ntau txaus kom tau txais cov txiaj ntsig kom raug.
/// Txawm li cas los xij, thaum qhov txiaj ntsig tau ze li ntawm ib nrab ntawm ob qho uas nyob ib sab (ordinary) floats, qhov sib txuam sib xyaw ua ke los ntawm sib npaug ntawm ob txoj kev kwv yees txhais tau tias qhov txiaj ntsig yuav tawm los ntawm ob peb lub cev.
/// Thaum qhov no tshwm sim, iterative Algorithm R kho qhov nce.
///
/// Qhov siv tes-laim ntoom "close to halfway" yog qhov tseeb ua los ntawm kev suav lej ntawm cov ntawv sau.
/// Hauv cov lus ntawm Clinger:
///
/// > Txoj hauv kev, qhia nyob rau hauv cov koog ntawm qhov tsawg tshaj plaws qhov tseem ceeb, yog qhov muaj kev suav nrog qhov yuam kev
/// > tsim nyog thaum lub sij hawm ntaws taw qhia kev kwv yees mus rau qhov kwv yees rau f * 10 ^ e.(Ua yog
/// > tsis yog txhua yam rau kev ua yuam kev muaj tseeb, tab sis ciam teb qhov txawv ntawm qhov ze ntawm z thiab
/// > qhov zoo tshaj plaws kwv yees uas siv p khoom los ntawm meanand.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // Tus mob abs(e) <log5(2^N) nyob hauv fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // Yog lub slop loj txaus mus ua ib tug sib txawv thaum pub muab kwv yees rau n khoom?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// Ib qho ntsuas kev ua tiav uas txhim kho cov ntab ntus ntus ntawm `f * 10^e`.
///
/// Txhua lub iteration tau txais ib chav nyob rau hauv qhov chaw kawg los ze zog, uas ntawm chav kawm siv sijhawm ua luaj ntev kom los sib hloov yog `z0` txawm tias mob me.
/// Hmoov zoo, thaum siv los ua fallback rau Bellerophon, qhov pib kwv yees yog tawm los ntawm feem ntau ib ULP.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Pom qhov zoo sib xyaw `x`, `y` xws tias `x / y` yog qhov muaj `(f *10^e) / (m* 2^k)`.
        // Qhov no tsis tsuas txhob soj ntsuam txog cov cim ntawm `e` thiab `k`, peb kuj tshem tawm lub hwj chim ntawm ob hom rau `10^e` thiab `2^k` yuav ua rau cov xov tooj me me thiab.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Qhov no tau sau me ntsis ua txawv vim tias peb bignums tsis txhawb nqa cov lej tsis zoo, yog li peb siv tus nqi kiag + cov ntaub ntawv kos npe.
        // Tus nruas nrog m_digits tsis tuaj yeem nqus.
        // Yog tias `x` lossis `y` yog qhov loj txaus uas peb xav txhawj xeeb txog qhov txeej dhau, tom qab ntawd lawv tseem loj txaus uas `make_ratio` tau txo qhov feem los ntawm qhov feem ntawm 2 ^ 64 lossis ntau dua.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Tsis txhob xav tau x ib qho twg ntxiv, tseg ib tus clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Tseem xav tau y, muab theej tawm.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// Muab `x = f` thiab `y = m` qhov twg `f` sawv cev rau cov lej sib ntxiv ntawm cov lej li niaj zaus thiab `m` yog lub ntsiab lus ntawm cov taw tes ntab, ua qhov sib piv `x / y` sib npaug rau `(f *10^e) / (m* 2^k)`, tej zaum txo los ntawm lub zog ntawm ob qho ob qho tib si muaj.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, tshwj tsis yog tias peb txo qhov feem los ntawm qee lub zog ntawm ob.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m Qhov no tsis tuaj yeem dhau vim tias nws yuav tsum xav kom zoo `e` thiab `k` tsis zoo, uas tsuas tuaj yeem tshwm sim rau cov txiaj ntsig tsis tshua zoo rau 1, uas txhais tau tias `e` thiab `k` yuav sib piv me me.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Qhov no tsis tuaj yeem nrawm dua, saib saum toj no.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), rov txo dua los ntawm ib lub zog ntawm ob.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Conceptsually, Algorithm M yog txoj kev yooj yim tshaj plaws los hloov tus zauv rau ib ntab.
///
/// Peb tsim qhov sib piv uas sib npaug rau `f * 10^e`, tom qab ntawd muab pov hauv lub zog ntawm ob txog ntua thaum nws muab cov ntab siv tau.
/// Binary exponent `k` yog tus naj npawb ntawm lub sij hawm peb khoo tus kwv los sis sib thooj ntawm ob, piv txwv li, txhua lub sijhawm `f *10^e` sib npaug `(u / v)* 2^k`.
/// Thaum peb tau pom muaj ntsiab lus ntau lawm, peb tsuas yog xav tau puag ncig los ntawm kev kuaj xyuas feem seem ntawm cov kev faib tawm, uas yog ua tiav hauv cov pab ua haujlwm ntxiv hauv qab no.
///
///
/// Lub algorithm no yog super qeeb qeeb, txawm tias muaj qhov hloov kho tau zoo piav qhia hauv `quick_start()`.
/// Txawm li cas los xij, nws yog qhov yooj yim tshaj ntawm cov kev hloov kho kom hloov mus rau kev tshaj dhau, ua haujlwm dhau, thiab cov txiaj ntsig tsis sib xws.
/// Qhov kev siv no yuav siv sij hawm thaum Bellerophon thiab Algorithm R dhau heev.
/// Txheeb xyuas underflow thiab txeej tau yooj yim: Qhov sib piv tseem tsis yog qhov tseem ceeb-thiab tsis tau, minimum/maximum kev nthuav qhia tau mus txog.
/// Tus uas hla dhau, peb tsuas rov qab infinity.
///
/// Tuav underflow thiab subnormals yog trickier.
/// Ib qho teeb meem loj yog tias, nrog rau kev txoom tsawg kawg nkaus, qhov piv no tseem yuav loj heev rau kev ntsuas.
/// Saib underflow() kom paub meej.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // FIXME qhov ua tau zoo: ua kom qhov tseeb loj_rau_fp kom peb tuaj yeem ua qhov sib npaug ntawm fp_to_float(big_to_fp(u)) ntawm no, tsuas yog tsis muaj qhov muab ob npaug ncig.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Peb yuav tsum nres ntawm qhov tsawg kawg tshaj tawm, yog tias peb tos kom txog thaum `k < T::MIN_EXP_INT`, tom qab ntawd peb yuav tawm los ntawm ib qho ntawm ob.
            // Hmoov tsis qhov no txhais tau tias peb yuav tsum tshwj xeeb cov lej ib txwm muaj tsawg tshaj plaws.
            // FIXME pom cov qauv tsim dua, tab sis khiav `tiny-pow10` kuaj kom paub tseeb tias nws yog qhov tseeb!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Hla hla feem ntau Algorithm M iterations los ntawm kev khij qhov ntev.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // Lub ntsis ntev yog qhov kwv yees ntawm lub hauv paus ob lub logarithm, thiab log(u / v) = log(u), log(v).
    // Qhov kwv yees tau tawm los ntawm feem ntau 1, tab sis tas li ib qho kev kwv yees tsis dhau, yog li qhov yuam kev ntawm log(u) thiab log(v) yog tib qho cim thiab rho tawm (yog tias ob qho loj).
    // Yog li no qhov yuam kev rau log(u / v) yog nyob rau ntau qhov ib yam nkaus.
    // Lub hom phiaj piv yog ib qho uas u/v yog nyob rau hauv-hauv qhov muaj txiaj ntsig zoo.Yog li peb qhov kev ua haujlwm xaus yog log2(u / v) yog qhov tseem ceeb thiab me me, plus/minus ib.
    // FIXME Saib ntawm tus lej thib ob tuaj yeem txhim kho qhov kev kwv yees thiab zam qee yam kev sib faib ntau.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Underflow lossis txawv txav.Tso nws rau lub luag haujlwm tseem ceeb.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Pauj dhau.Tso nws rau lub luag haujlwm tseem ceeb.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // Qhov ntsuas tsis yog ib qho nyob rau hauv ntau thiab tseem ceeb tshaj plaws ntxiv, yog li peb yuav tsum tau muab cov khoom sib tshooj thiab kho cov teeb meem kom haum ntxiv.
    // Tus nqi tam sim no zoo li no:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q trunc.(sawv cev los ntawm rem)
    //
    // Yog li no, thaum cov khoom sib tshooj tau sib tw!= 0.5 ULP, lawv txiav txim siab qhov sib npaug ntawm lawv tus kheej.
    // Thaum lawv muaj sib npaug thiab cov seem yog tsis xoom, tus nqi tseem yuav tsum muab cov khoom kheej.
    // Tsuas yog thaum sib npaug ntawm cov kab yog cov 1/2 thiab qhov seem yog xoom, peb muaj qhov teeb meem ib nrab-rau-txawm.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Ordinary round-to-even, obfuscated los ntawm qhov yuav tsum tau hloov mus raws li cov seem ntawm ib seem.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}