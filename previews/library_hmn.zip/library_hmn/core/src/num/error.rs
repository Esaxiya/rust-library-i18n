//! Kev ua yuam kev hloov dua siab tshiab rau hom siv tsis tau.

use crate::convert::Infallible;
use crate::fmt;

/// Cov hom yuam kev rov qab thaum tus soj ntsuam hom hloov dua siab tshiab tsis ua tiav.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Sib phim es tsis txhob yuam kom paub tseeb tias qhov code zoo li `From<Infallible> for TryFromIntError` saum toj no yuav ua haujlwm ntxiv thaum `Infallible` dhau los ua kev cai rau `!`.
        //
        //
        match never {}
    }
}

/// Ib qho yuam kev uas tuaj yeem xa rov qab thaum faib ib qho zauv.
///
/// Qhov yuam kev no yog siv ua hom kev ua yuam kev rau `from_str_radix()` kev ua haujlwm ntawm hom pib txheej txheem, xws li [`i8::from_str_radix`].
///
/// # Muaj peev xwm ua
///
/// Ntawm lwm qhov ua rau, `ParseIntError` tuaj yeem muab pov tseg vim hais tias ntawm kev coj ua lossis cov kab sib tw hauv txoj hlua piv txwv li, thaum nws tau los ntawm cov qauv txheem.
///
/// Siv cov [`str::trim()`] qauv ua kom ntseeg tau tias tsis muaj qhov tsis tseem ceeb nyob ua ntej kev txheeb.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum khaws ntau yam kev ua yuam kev uas tuaj yeem ua rau qee tus lej tsis dhau.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Tus nqi raug parsed yog khoob.
    ///
    /// Ntawm lwm cov laj thawj, qhov sib txawv no yuav raug tsim ua thaum hle ib txoj hlua khoob.
    Empty,
    /// Muaj cov lej tsis raug nyob hauv nws cov ntsiab lus teb.
    ///
    /// Ntawm lwm qhov laj thawj, qhov sib txawv no yuav raug tsim ua thaum huas txoj hlua uas muaj qhov tsis-ASCII char.
    ///
    /// Cov ntsuas hluav taws xob no tseem tau tsim ua thaum `+` lossis `-` tso rau hauv cov hlua ntawm nws tus kheej lossis nruab nrab ntawm tus lej.
    ///
    ///
    InvalidDigit,
    /// Qhov kev tiv thaiv loj dhau heev los cia rau hauv hom phiaj integer.
    PosOverflow,
    /// Cov zauv yog tsawg heev los khaws hauv phiaj integer hom.
    NegOverflow,
    /// Tus nqi yog xoom
    ///
    /// Qhov sib txawv no yuav tsim tawm thaum qhov kev qhia txoj xov muaj tus nqi ntawm xoom, uas yuav txwv tsis pub rau cov hom xoom.
    ///
    Zero,
}

impl ParseIntError {
    /// Tawm tawm cov ncauj lus kom ntxaws kev ua parsing ib qho lej tsis ua tiav.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}