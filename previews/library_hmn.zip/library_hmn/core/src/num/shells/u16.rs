//! Qhov tas li rau 16-ntsis unsigned integer hom.
//!
//! *[See also the `u16` primitive type][u16].*
//!
//! Cov cai tshiab yuav tsum siv cov kev sib txuam nrog ncaj qha rau ntawm hom txheej thaum ub.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u16`"
)]

int_module! { u16 }