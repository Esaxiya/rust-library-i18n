//! Txua rau 8-ntsis kos npe rau hom integer.
//!
//! *[See also the `i8` primitive type][i8].*
//!
//! Cov cai tshiab yuav tsum siv cov kev sib txuam nrog ncaj qha rau ntawm hom txheej thaum ub.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i8`"
)]

int_module! { i8 }