//! Txheem rau 8-ntsis kos npe rau hom tsis tuaj yeem.
//!
//! *[See also the `u8` primitive type][u8].*
//!
//! Cov cai tshiab yuav tsum siv cov kev sib txuam nrog ncaj qha rau ntawm hom txheej thaum ub.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u8`"
)]

int_module! { u8 }