//! Txheem rau pointer-qhov loj me tsis tau kos npe hom hom.
//!
//! *[See also the `usize` primitive type][usize].*
//!
//! Cov cai tshiab yuav tsum siv cov kev sib txuam nrog ncaj qha rau ntawm hom txheej thaum ub.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `usize`"
)]

int_module! { usize }