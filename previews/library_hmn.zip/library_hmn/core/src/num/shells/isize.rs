//! Tsis tu ncua rau pointer-qhov loj me kos npe integer hom.
//!
//! *[See also the `isize` primitive type][isize].*
//!
//! Cov cai tshiab yuav tsum siv cov kev sib txuam nrog ncaj qha rau ntawm hom txheej thaum ub.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `isize`"
)]

int_module! { isize }