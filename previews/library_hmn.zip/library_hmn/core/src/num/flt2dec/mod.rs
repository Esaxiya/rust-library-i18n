/*!

Floating-point number to decimal conversion routines.

# Problem statement

We are given the floating-point number `v = f * 2^e` with an integer `f`,
and its bounds `minus` and `plus` such that any number between `v - minus` and
`v + plus` will be rounded to `v`. For the simplicity we assume that
this range is exclusive. Then we would like to get the unique decimal
representation `V = 0.d[0..n-1] * 10^k` such that:

- `d[0]` is non-zero.

- It's correctly rounded when parsed back: `v - minus < V < v + plus`.
  Furthermore it is shortest such one, i.e., there is no representation
  with less than `n` digits that is correctly rounded.

- It's closest to the original value: `abs(V - v) <= 10^(k-n) / 2`. Note that
  there might be two representations satisfying this uniqueness requirement,
  in which case some tie-breaking mechanism is used.

We will call this mode of operation as to the *shortest* mode. This mode is used
when there is no additional constraint, and can be thought as a "natural" mode
as it matches the ordinary intuition (it at least prints `0.1f32` as "0.1").

We have two more modes of operation closely related to each other. In these modes
we are given either the number of significant digits `n` or the last-digit
limitation `limit` (which determines the actual `n`), and we would like to get
the representation `V = 0.d[0..n-1] * 10^k` such that:

- `d[0]` is non-zero, unless `n` was zero in which case only `k` is returned.

- It's closest to the original value: `abs(V - v) <= 10^(k-n) / 2`. Again,
  there might be some tie-breaking mechanism.

When `limit` is given but not `n`, we set `n` such that `k - n = limit`
so that the last digit `d[n-1]` is scaled by `10^(k-n) = 10^limit`.
If such `n` is negative, we clip it to zero so that we will only get `k`.
We are also limited by the supplied buffer. This limitation is used to print
the number up to given number of fractional digits without knowing
the correct `k` beforehand.

We will call the mode of operation requiring `n` as to the *exact* mode,
and one requiring `limit` as to the *fixed* mode. The exact mode is a subset of
the fixed mode: the sufficiently large last-digit limitation will eventually fill
the supplied buffer and let the algorithm to return.

# Implementation overview

It is easy to get the floating point printing correct but slow (Russ Cox has
[demonstrated](http://research.swtch.com/ftoa) how it's easy), or incorrect but
fast (naïve division and modulo). But it is surprisingly hard to print
floating point numbers correctly *and* efficiently.

There are two classes of algorithms widely known to be correct.

- The "Dragon" family of algorithm is first described by Guy L. Steele Jr. and
  Jon L. White. They rely on the fixed-size big integer for their correctness.
  A slight improvement was found later, which is posthumously described by
  Robert G. Burger and R. Kent Dybvig. David Gay's `dtoa.c` routine is
  a popular implementation of this strategy.

- The "Grisu" family of algorithm is first described by Florian Loitsch.
  They use very cheap integer-only procedure to determine the close-to-correct
  representation which is at least guaranteed to be shortest. The variant,
  Grisu3, actively detects if the resulting representation is incorrect.

We implement both algorithms with necessary tweaks to suit our requirements.
In particular, published literatures are short of the actual implementation
difficulties like how to avoid arithmetic overflows. Each implementation,
available in `strategy::dragon` and `strategy::grisu` respectively,
extensively describes all necessary justifications and many proofs for them.
(It is still difficult to follow though. You have been warned.)

Both implementations expose two public functions:

- `format_shortest(decoded, buf)`, which always needs at least
  `MAX_SIG_DIGITS` digits of buffer. Implements the shortest mode.

- `format_exact(decoded, buf, limit)`, which accepts as small as
  one digit of buffer. Implements exact and fixed modes.

They try to fill the `u8` buffer with digits and returns the number of digits
written and the exponent `k`. They are total for all finite `f32` and `f64`
inputs (Grisu internally falls back to Dragon if necessary).

The rendered digits are formatted into the actual string form with
four functions:

- `to_shortest_str` prints the shortest representation, which can be padded by
  zeroes to make *at least* given number of fractional digits.

- `to_shortest_exp_str` prints the shortest representation, which can be
  padded by zeroes when its exponent is in the specified ranges,
  or can be printed in the exponential form such as `1.23e45`.

- `to_exact_exp_str` prints the exact representation with given number of
  digits in the exponential form.

- `to_exact_fixed_str` prints the fixed representation with *exactly*
  given number of fractional digits.

They all return a slice of preallocated `Part` array, which corresponds to
the individual part of strings: a fixed string, a part of rendered digits,
a number of zeroes or a small (`u16`) number. The caller is expected to
provide a large enough buffer and `Part` array, and to assemble the final
string from resulting `Part`s itself.

All algorithms and formatting functions are accompanied by extensive tests
in `coretests::num::flt2dec` module. It also shows how to use individual
functions.

*/

// thaum lub sij hawm no yog cov ntaub ntawv sau cia, qhov no yog nyob rau hauv hauv paus ntsiab lus ntiag tug uas tsuas yog ua rau pej xeem mus kuaj.
// tsis hais tawm rau peb.
#![doc(hidden)]
#![unstable(
    feature = "flt2dec",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

pub use self::decoder::{decode, DecodableFloat, Decoded, FullDecoded};

use crate::mem::MaybeUninit;

pub mod decoder;
pub mod estimator;

/// Tus lej-cim algorithms.
pub mod strategy {
    pub mod dragon;
    pub mod grisu;
}

/// Qhov tsawg kawg nkaus me ntawm tsis tsim nyog rau qhov luv tshaj plaws hom.
///
/// Nws yog me ntsis tsis-tsis tseem ceeb kom tau txais, tab sis qhov no yog ib qho ntxiv rau tus naj npawb ntawm cov zauv tseem ceeb ntawm cov zauv los ntawm cov qauv txheej txheem algorithm nrog qhov tshwm sim luv tshaj plaws.
///
/// Tus qauv meej yog `ceil(# bits in mantissa * log_10 2 + 1)`.
pub const MAX_SIG_DIGITS: usize = 17;

/// Thaum `d` muaj cov lej zauv, nce ntxiv tus lej kawg thiab tawm mus nqa.
/// Rov qab rau tus lej tom ntej thaum nws ua rau qhov ntev hloov.
#[doc(hidden)]
pub fn round_up(d: &mut [u8]) -> Option<u8> {
    match d.iter().rposition(|&c| c != b'9') {
        Some(i) => {
            // d [i + 1..n] yog txhua cuaj
            d[i] += 1;
            for j in i + 1..d.len() {
                d[j] = b'0';
            }
            None
        }
        None if d.len() > 0 => {
            // 999..999 puag ncig txog 1000..000 nrog qhov kev nthuav qhia ntxiv
            d[0] = b'1';
            for j in 1..d.len() {
                d[j] = b'0';
            }
            Some(b'0')
        }
        None => {
            // tus tsis npliag ncig ncig (me ntsis txawv tab sis tsim nyog)
            Some(b'1')
        }
    }
}

/// Txheem qhov chaw.
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Part<'a> {
    /// Muab pes tsawg tus lej.
    Zero(usize),
    /// Tus lej cia txog 5 tus lej.
    Num(u16),
    /// Daim ntawv qhia txog cov lus bytes.
    Copy(&'a [u8]),
}

impl<'a> Part<'a> {
    /// Rov qab xa npaum li cas byte ntev ntawm ntu ntu.
    pub fn len(&self) -> usize {
        match *self {
            Part::Zero(nzeroes) => nzeroes,
            Part::Num(v) => {
                if v < 1_000 {
                    if v < 10 {
                        1
                    } else if v < 100 {
                        2
                    } else {
                        3
                    }
                } else {
                    if v < 10_000 { 4 } else { 5 }
                }
            }
            Part::Copy(buf) => buf.len(),
        }
    }

    /// Sau ib feem rau ntawm ntu khoom xa tuaj.
    /// Rov qab tus lej sau ua ntaub ntawv bytes, lossis `None` yog tias tsis zoo txaus.
    /// (Nws kuj tseem tawm qee qhov sau ntawv hauv qhov tsis; tsis txhob cia siab rau qhov ntawd.)
    pub fn write(&self, out: &mut [u8]) -> Option<usize> {
        let len = self.len();
        if out.len() >= len {
            match *self {
                Part::Zero(nzeroes) => {
                    for c in &mut out[..nzeroes] {
                        *c = b'0';
                    }
                }
                Part::Num(mut v) => {
                    for c in out[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                }
                Part::Copy(buf) => {
                    out[..buf.len()].copy_from_slice(buf);
                }
            }
            Some(len)
        } else {
            None
        }
    }
}

/// Txheeb tawm los uas muaj ib lossis ntau ntu.
/// Qhov no tuaj yeem sau rau hauv byte tsis lossis hloov mus rau txoj siv ceev.
#[allow(missing_debug_implementations)]
#[derive(Clone)]
pub struct Formatted<'a> {
    /// A byte hlais sawv cev rau cov paib, yog `""`, `"-"` lossis `"+"`.
    pub sign: &'static str,
    /// Tshawb cov feem tsim los hloov tom qab daim paib thiab xaiv xoom padding.
    pub parts: &'a [Part<'a>],
}

impl<'a> Formatted<'a> {
    /// Rov qab los pes tsawg byte ntev ntawm cov sib xyaw ua ke cov txiaj ntsig.
    pub fn len(&self) -> usize {
        let mut len = self.sign.len();
        for part in self.parts {
            len += part.len();
        }
        len
    }

    /// Sau txhua ntu ntawm cov qauv uas siv rau hauv qhov tsis zoo.
    /// Rov qab tus lej sau ua ntaub ntawv bytes, lossis `None` yog tias tsis zoo txaus.
    /// (Nws kuj tseem tawm qee qhov sau ntawv hauv qhov tsis; tsis txhob cia siab rau qhov ntawd.)
    pub fn write(&self, out: &mut [u8]) -> Option<usize> {
        if out.len() < self.sign.len() {
            return None;
        }
        out[..self.sign.len()].copy_from_slice(self.sign.as_bytes());

        let mut written = self.sign.len();
        for part in self.parts {
            let len = part.write(&mut out[written..])?;
            written += len;
        }
        Some(written)
    }
}

/// Cov tawm tswv yim muab cov zauv xaus `0.<...buf...> * 10^exp` rau hauv tus zauv nrog tsawg kawg muab tus zauv ntawm fractional.
///
/// Qhov txiaj ntsig yog khaws cia rau hauv ntu kev pabcuam thiab ib feem ntawm cov ntawv sau tau rov qab.
///
/// `frac_digits` tuaj yeem yog tsawg dua ntawm cov xov tooj fractional sib txawv hauv `buf`;
/// nws yuav tsis quav ntsej thiab tag nrho cov lej yuav muab luam tawm.Nws tsuas yog siv los luam tawm xoom ntxiv tom qab sau ua lej.
/// Yog li `frac_digits` ntawm 0 txhais tau tias nws yuav tsuas sau cov lej thiab tsis muaj dab tsi ntxiv.
///
fn digits_to_dec_str<'a>(
    buf: &'a [u8],
    exp: i16,
    frac_digits: usize,
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> &'a [Part<'a>] {
    assert!(!buf.is_empty());
    assert!(buf[0] > b'0');
    assert!(parts.len() >= 4);

    // yog tias muaj kev txwv rau tus lej kawg txoj hauj lwm, `buf` tau xav tias ua sab laug-xaum nrog lub xoom virtual.
    // tus naj npawb ntawm virtual zeroes, `nzeroes`, sib npaug rau `max(0, exp + frac_digits - buf.len())`, yog li ntawd txoj haujlwm ntawm tus lej kawg `exp - buf.len() - nzeroes` tsis tshaj `-frac_digits`:
    //
    //
    //                       |<-virtual->|
    //       | <----buf----> |zeroes |exp
    //    0. 1 2 3 4 5 6 7 8 9 _ _ _ _ _ _ x 10
    //    |                  |           |
    // 10 ^ exp 10^(exp-buf.len()) 10^(exp-buf.len()-nzeroes)
    //
    // `nzeroes` yog tus kheej xam rau txhua kis kom zam dhau kev phwj.
    //

    if exp <= 0 {
        // Txoj kab zauv yog ua ntej koj tus lej: [0.][000...000][1234][____]
        let minus_exp = -(exp as i32) as usize;
        parts[0] = MaybeUninit::new(Part::Copy(b"0."));
        parts[1] = MaybeUninit::new(Part::Zero(minus_exp));
        parts[2] = MaybeUninit::new(Part::Copy(buf));
        if frac_digits > buf.len() && frac_digits - buf.len() > minus_exp {
            parts[3] = MaybeUninit::new(Part::Zero((frac_digits - buf.len()) - minus_exp));
            // KEV RUAJ NTSEG: peb nyuam qhuav pib lub ntsiab `..4`.
            unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
        } else {
            // KEV RUAJ NTSEG: peb nyuam qhuav pib lub ntsiab `..3`.
            unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) }
        }
    } else {
        let exp = exp as usize;
        if exp < buf.len() {
            // Txoj kab zauv yog hauv nruab nrab ntawm cov lej: [12][.][34][____]
            parts[0] = MaybeUninit::new(Part::Copy(&buf[..exp]));
            parts[1] = MaybeUninit::new(Part::Copy(b"."));
            parts[2] = MaybeUninit::new(Part::Copy(&buf[exp..]));
            if frac_digits > buf.len() - exp {
                parts[3] = MaybeUninit::new(Part::Zero(frac_digits - (buf.len() - exp)));
                // KEV RUAJ NTSEG: peb nyuam qhuav pib lub ntsiab `..4`.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
            } else {
                // KEV RUAJ NTSEG: peb nyuam qhuav pib lub ntsiab `..3`.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) }
            }
        } else {
            // txoj kab zauv yog tom qab kev muab cov lej: [1234][____0000] lossis [1234][__][.][__].
            parts[0] = MaybeUninit::new(Part::Copy(buf));
            parts[1] = MaybeUninit::new(Part::Zero(exp - buf.len()));
            if frac_digits > 0 {
                parts[2] = MaybeUninit::new(Part::Copy(b"."));
                parts[3] = MaybeUninit::new(Part::Zero(frac_digits));
                // KEV RUAJ NTSEG: peb nyuam qhuav pib lub ntsiab `..4`.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
            } else {
                // KEV RUAJ NTSEG: peb nyuam qhuav pib lub ntsiab `..2`.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) }
            }
        }
    }
}

/// Tawm tswv yim muab cov lej zauv `0.<...buf...> * 10^exp` rau hauv daim foos nrog qhov tsawg kawg muab cov lej ntawm cov lej tseem ceeb.
///
/// Thaum `upper` yog `true`, qhov kev nthuav qhia yuav muab ua ntej los ntawm `E`;txwv tsis pub ntawd yog `e`.
/// Qhov txiaj ntsig yog khaws cia rau hauv ntu kev pabcuam thiab ib feem ntawm cov ntawv sau tau rov qab.
///
/// `min_digits` tuaj yeem tsawg dua tus lej ntawm cov lej tseem ceeb hauv `buf`;
/// nws yuav tsis quav ntsej thiab tag nrho cov lej yuav muab luam tawm.Nws tsuas yog siv los luam tawm xoom ntxiv tom qab sau ua lej.
/// Yog li, `min_digits == 0` txhais tau tias nws yuav tsuas sau cov lej muab thiab tsis muaj dab tsi ntxiv.
///
fn digits_to_exp_str<'a>(
    buf: &'a [u8],
    exp: i16,
    min_ndigits: usize,
    upper: bool,
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> &'a [Part<'a>] {
    assert!(!buf.is_empty());
    assert!(buf[0] > b'0');
    assert!(parts.len() >= 6);

    let mut n = 0;

    parts[n] = MaybeUninit::new(Part::Copy(&buf[..1]));
    n += 1;

    if buf.len() > 1 || min_ndigits > 1 {
        parts[n] = MaybeUninit::new(Part::Copy(b"."));
        parts[n + 1] = MaybeUninit::new(Part::Copy(&buf[1..]));
        n += 2;
        if min_ndigits > buf.len() {
            parts[n] = MaybeUninit::new(Part::Zero(min_ndigits - buf.len()));
            n += 1;
        }
    }

    // 0.1234 x 10 ^ exp= 1.234 x 10 ^ (exp-1)
    let exp = exp as i32 - 1; // zam dhau underflow thaum exp yog i16::MIN
    if exp < 0 {
        parts[n] = MaybeUninit::new(Part::Copy(if upper { b"E-" } else { b"e-" }));
        parts[n + 1] = MaybeUninit::new(Part::Num(-exp as u16));
    } else {
        parts[n] = MaybeUninit::new(Part::Copy(if upper { b"E" } else { b"e" }));
        parts[n + 1] = MaybeUninit::new(Part::Num(exp as u16));
    }
    // KEV RUAJ NTSEG: peb nyuam qhuav pib lub ntsiab `..n + 2`.
    unsafe { MaybeUninit::slice_assume_init_ref(&parts[..n + 2]) }
}

/// Kos npe rau kev xaiv hom.
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Sign {
    /// Prints `-` tsuas yog rau cov kev tsis zoo tsis tau xoom.
    Minus, // -inf -1 0 0 1 inf nan
    /// Prints `-` tsuas yog rau cov txiaj ntsig tsis zoo (suav nrog qhov tsis zoo).
    MinusRaw, // -inf -1 -0 0 1 inf nan
    /// Luam tawm `-` rau qhov tsis zoo-tsis muaj nuj nqis, lossis `+` txwv tsis pub.
    MinusPlus, // -inf -1 +0 +0 +1 + inf nan
    /// Luam tawm `-` rau txhua qhov txiaj ntsig tsis zoo (suav nrog qhov tsis zoo), lossis `+` txwv tsis pub.
    MinusPlusRaw, // -inf -1 -0 +0 +1 + inf nan
}

/// Rov qab los ntawm txoj hlua byte zoo li sib thooj rau daim paib los ua daim ntawv.
/// Nws tuaj yeem yog `""`, `"+"` lossis `"-"`.
fn determine_sign(sign: Sign, decoded: &FullDecoded, negative: bool) -> &'static str {
    match (*decoded, sign) {
        (FullDecoded::Nan, _) => "",
        (FullDecoded::Zero, Sign::Minus) => "",
        (FullDecoded::Zero, Sign::MinusRaw) => {
            if negative {
                "-"
            } else {
                ""
            }
        }
        (FullDecoded::Zero, Sign::MinusPlus) => "+",
        (FullDecoded::Zero, Sign::MinusPlusRaw) => {
            if negative {
                "-"
            } else {
                "+"
            }
        }
        (_, Sign::Minus | Sign::MinusRaw) => {
            if negative {
                "-"
            } else {
                ""
            }
        }
        (_, Sign::MinusPlus | Sign::MinusPlusRaw) => {
            if negative {
                "-"
            } else {
                "+"
            }
        }
    }
}

/// Tawm tswv yim muab cov xov tooj floating npov rau hauv tus zauv nruab nrab nrog tsawg kawg muab tus zauv fractional.
/// Qhov tshwm sim yog khaws cia rau kev muab khoom seem array thaum siv cov byte tsis raws li kos.
/// `upper` yog tam sim no tsis siv tab sis sab laug rau future kev txiav txim siab los hloov rooj plaub ntawm qhov tsis muaj nqis, piv txwv li, `inf` thiab `nan`.
///
/// Thawj ntu los hloov yog ib txwm `Part::Sign` (uas tuaj yeem yog txoj hlua khoob yog tias tsis muaj cim kos npe).
///
/// `format_shortest` yuav tsum ua lub hauv paus xaus-tiam muaj nuj nqi.
/// Nws yuav tsum rov qab feem ntawm qhov tsis zoo uas nws tau pib.
/// Koj yuav xav tau `strategy::grisu::format_shortest` rau qhov no.
///
/// `frac_digits` tuaj yeem yog tsawg dua ntawm cov xov tooj fractional sib txawv hauv `v`;
/// nws yuav tsis quav ntsej thiab tag nrho cov lej yuav muab luam tawm.Nws tsuas yog siv los luam tawm xoom ntxiv tom qab sau ua lej.
/// Yog li `frac_digits` ntawm 0 txhais tau tias nws yuav tsuas sau cov lej thiab tsis muaj dab tsi ntxiv.
///
/// Lub byte tsis yuav tsum yog tsawg kawg `MAX_SIG_DIGITS` bytes ntev.
/// Yuav tsum muaj tsawg kawg 4 ntu muaj, vim qhov xwm txheej phem tshaj plaws xws li `[+][0.][0000][2][0000]` nrog `frac_digits = 10`.
///
///
///
pub fn to_shortest_str<'a, T, F>(
    mut format_shortest: F,
    v: T,
    sign: Sign,
    frac_digits: usize,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>]) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 4);
    assert!(buf.len() >= MAX_SIG_DIGITS);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // KEV RUAJ NTSEG: peb nyuam qhuav pib lub ntsiab `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // KEV RUAJ NTSEG: peb nyuam qhuav pib lub ntsiab `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if frac_digits > 0 {
                // [0.][0000]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                Formatted {
                    sign,
                    // KEV RUAJ NTSEG: peb nyuam qhuav pib lub ntsiab `..2`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                Formatted {
                    sign,
                    // KEV RUAJ NTSEG: peb nyuam qhuav pib lub ntsiab `..1`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let (buf, exp) = format_shortest(decoded, buf);
            Formatted { sign, parts: digits_to_dec_str(buf, exp, frac_digits, parts) }
        }
    }
}

/// Tawm tswv yim muab cov kab npauj npaim tso rau hauv cov zauv ntawm cov zauv los yog cov foos ib qhov tseem ceeb, nyob ntawm seb qhov kev nthuav tawm ntxiv.
/// Qhov tshwm sim yog khaws cia rau kev muab khoom seem array thaum siv cov byte tsis raws li kos.
/// `upper` yog siv los txiav txim rooj plaub ntawm qhov tsis muaj qhov muaj nuj nqis (`inf` thiab `nan`) lossis rooj plaub ntawm cov ntawv cog lus sab nraud (`e` lossis `E`).
/// Thawj ntu los hloov yog ib txwm `Part::Sign` (uas tuaj yeem yog txoj hlua khoob yog tias tsis muaj cim kos npe).
///
/// `format_shortest` yuav tsum ua lub hauv paus xaus-tiam muaj nuj nqi.
/// Nws yuav tsum rov qab feem ntawm qhov tsis zoo uas nws tau pib.
/// Koj yuav xav tau `strategy::grisu::format_shortest` rau qhov no.
///
/// `dec_bounds` yog kev tuple `(lo, hi)` xws tias tus lej tau muab sau ua tus lej tsuas yog thaum `10^lo <= V < 10^hi`.
/// Nco ntsoov tias qhov no yog tus *pom*`V` hloov qhov `v` tiag tiag!Yog li cov ntawv luam tawm sab nraud ntawm daim foos luam yuav tsis muaj nyob rau hauv qhov no, zam qhov tsis meej pem.
///
///
/// Lub byte tsis yuav tsum yog tsawg kawg `MAX_SIG_DIGITS` bytes ntev.
/// Yuav tsum muaj tsawg kawg 6 ntu muaj, vim qhov xwm txheej phem tshaj plaws xws li `[+][1][.][2345][e][-][6]`.
///
///
///
///
///
pub fn to_shortest_exp_str<'a, T, F>(
    mut format_shortest: F,
    v: T,
    sign: Sign,
    dec_bounds: (i16, i16),
    upper: bool,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>]) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 6);
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(dec_bounds.0 <= dec_bounds.1);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // KEV RUAJ NTSEG: peb nyuam qhuav pib lub ntsiab `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // KEV RUAJ NTSEG: peb nyuam qhuav pib lub ntsiab `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            parts[0] = if dec_bounds.0 <= 0 && 0 < dec_bounds.1 {
                MaybeUninit::new(Part::Copy(b"0"))
            } else {
                MaybeUninit::new(Part::Copy(if upper { b"0E0" } else { b"0e0" }))
            };
            // KEV RUAJ NTSEG: peb nyuam qhuav pib lub ntsiab `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Finite(ref decoded) => {
            let (buf, exp) = format_shortest(decoded, buf);
            let vis_exp = exp as i32 - 1;
            let parts = if dec_bounds.0 as i32 <= vis_exp && vis_exp < dec_bounds.1 as i32 {
                digits_to_dec_str(buf, exp, 0, parts)
            } else {
                digits_to_exp_str(buf, exp, 0, upper, parts)
            };
            Formatted { sign, parts }
        }
    }
}

/// Rov qab los rau ib qho chaw ua kom ntuag (qaum txoj kab) rau qhov siab tshaj plaws loj me me xam los ntawm cov muab piav qhia sab nraud.
///
/// Qhov tsis pub muaj pes tsawg yog:
///
/// - thaum `exp < 0`, qhov ntev tshaj plaws yog `ceil(log_10 (5^-exp * (2^64 - 1)))`.
/// - thaum `exp >= 0`, qhov ntev tshaj plaws yog `ceil(log_10 (2^exp * (2^64 - 1)))`.
///
/// `ceil(log_10 (x^exp * (2^64 - 1)))` yog tsawg dua `ceil(log_10 (2^64 - 1)) + ceil(exp *log_10 x)`, uas yog nyob rau hauv lem tsawg dua `20 + (1 + exp* log_10 x)`.
/// Peb siv qhov tseeb tias `log_10 2 < 5/16` thiab `log_10 5 < 12/16`, uas yog txaus rau peb lub hom phiaj.
///
/// Vim li cas peb thiaj li xav tau qhov no?`format_exact` lub zog yuav ua rau tag nrho cov kev tsis suav tshwj tsis yog muaj kev txwv los ntawm kev txwv tus lej kawg, tab sis nws yog qhov ua tau tias cov lej ntawm tus lej thov yog qhov kev tsis txaus ntseeg loj (hais tias, 30,000 tus lej).
///
/// Qhov tsis ntau ntawm cov tsis yuav yuav tau sau nrog zeroes, yog li peb tsis xav kom faib txhua tus tsis ua ntej.
/// Yog li ntawd, rau ib qho kev sib cav,
/// 826 bytes ntawm tsis yuav tsum txaus rau `f64`.Piv qhov no nrog tus lej ntawm tus lej phem: 770 bytes (thaum `exp = -1074`).
///
///
///
///
///
fn estimate_max_buf_len(exp: i16) -> usize {
    21 + ((if exp < 0 { -12 } else { 5 } * exp as i32) as usize >> 4)
}

/// Tawm tswv yim muab cov ntsiab lus ntab rau hauv cov ntawv tseem ceeb uas muaj tus lej ntawm cov lej tseem ceeb.
/// Qhov tshwm sim yog khaws cia rau kev muab khoom seem array thaum siv cov byte tsis raws li kos.
/// `upper` yog siv los txiav txim cov ntaub ntawv ntawm cov nqe lus kev nthuav dav (`e` lossis `E`).
/// Thawj ntu los hloov yog ib txwm `Part::Sign` (uas tuaj yeem yog txoj hlua khoob yog tias tsis muaj cim kos npe).
///
/// `format_exact` yuav tsum ua lub hauv paus xaus-tiam muaj nuj nqi.
/// Nws yuav tsum rov qab feem ntawm qhov tsis zoo uas nws tau pib.
/// Koj yuav xav tau `strategy::grisu::format_exact` rau qhov no.
///
/// Lub byte tsis yuav tsum yog tsawg kawg `ndigits` bytes ntev tshwj tsis yog `ndigits` yog qhov loj heev tias tsuas yog tus lej tsis ruaj yuav raug sau.
/// (Cov taw tes rau `f64` yog li ntawm 800, yog li 1000 bytes yuav tsum txaus.) Yuav tsum muaj tsawg kawg 6 ntu muaj, vim qhov teeb meem tsis zoo ib yam li `[+][1][.][2345][e][-][6]`.
///
///
///
///
///
pub fn to_exact_exp_str<'a, T, F>(
    mut format_exact: F,
    v: T,
    sign: Sign,
    ndigits: usize,
    upper: bool,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>], i16) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 6);
    assert!(ndigits > 0);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // KEV RUAJ NTSEG: peb nyuam qhuav pib lub ntsiab `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // KEV RUAJ NTSEG: peb nyuam qhuav pib lub ntsiab `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if ndigits > 1 {
                // [0.][0000][e0]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(ndigits - 1));
                parts[2] = MaybeUninit::new(Part::Copy(if upper { b"E0" } else { b"e0" }));
                Formatted {
                    sign,
                    // KEV RUAJ NTSEG: peb nyuam qhuav pib lub ntsiab `..3`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(if upper { b"0E0" } else { b"0e0" }));
                Formatted {
                    sign,
                    // KEV RUAJ NTSEG: peb nyuam qhuav pib lub ntsiab `..1`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let maxlen = estimate_max_buf_len(decoded.exp);
            assert!(buf.len() >= ndigits || buf.len() >= maxlen);

            let trunc = if ndigits < maxlen { ndigits } else { maxlen };
            let (buf, exp) = format_exact(decoded, &mut buf[..trunc], i16::MIN);
            Formatted { sign, parts: digits_to_exp_str(buf, exp, ndigits, upper, parts) }
        }
    }
}

/// Tawm tswv yim muab floating point point rau hauv tus zauv hauv nruab nrog uas muaj tus lej feem ntawm cov lej feem.
/// Qhov tshwm sim yog khaws cia rau kev muab khoom seem array thaum siv cov byte tsis raws li kos.
/// `upper` yog tam sim no tsis siv tab sis sab laug rau future kev txiav txim siab los hloov rooj plaub ntawm qhov tsis muaj nqis, piv txwv li, `inf` thiab `nan`.
/// Thawj ntu los hloov yog ib txwm `Part::Sign` (uas tuaj yeem yog txoj hlua khoob yog tias tsis muaj cim kos npe).
///
/// `format_exact` yuav tsum ua lub hauv paus xaus-tiam muaj nuj nqi.
/// Nws yuav tsum rov qab feem ntawm qhov tsis zoo uas nws tau pib.
/// Koj yuav xav tau `strategy::grisu::format_exact` rau qhov no.
///
/// Lub byte tsis yuav tsum txaus rau cov zis tshwj tsis yog `frac_digits` yog tias muaj ntau qhov tsuas yog cov lej ruaj ruaj yuav raug sau.
/// (Cov taw tes rau `f64` yog li ntawm 800, thiab 1000 bytes yuav tsum txaus.) Yuav tsum muaj tsawg kawg 4 ntu muaj, vim qhov teeb meem tsis zoo xws li `[+][0.][0000][2][0000]` nrog `frac_digits = 10`.
///
///
///
///
///
pub fn to_exact_fixed_str<'a, T, F>(
    mut format_exact: F,
    v: T,
    sign: Sign,
    frac_digits: usize,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>], i16) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 4);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // KEV RUAJ NTSEG: peb nyuam qhuav pib lub ntsiab `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // KEV RUAJ NTSEG: peb nyuam qhuav pib lub ntsiab `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if frac_digits > 0 {
                // [0.][0000]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                Formatted {
                    sign,
                    // KEV RUAJ NTSEG: peb nyuam qhuav pib lub ntsiab `..2`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                Formatted {
                    sign,
                    // KEV RUAJ NTSEG: peb nyuam qhuav pib lub ntsiab `..1`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let maxlen = estimate_max_buf_len(decoded.exp);
            assert!(buf.len() >= maxlen);

            // nws *yog* tau tias `frac_digits` yog qhov muaj qhov loj.
            // `format_exact` yuav xaus cov lej ua ntej ntau hauv qhov no, vim tias peb tau nruj los ntawm `maxlen`.
            //
            let limit = if frac_digits < 0x8000 { -(frac_digits as i16) } else { i16::MIN };
            let (buf, exp) = format_exact(decoded, &mut buf[..maxlen], limit);
            if exp <= limit {
                // qhov kev txwv tsis tuaj yeem ua tau, yog li qhov no yuav tsum zoo li xoom tsis muaj teeb meem `exp` tau.
                // qhov no tsis suav nrog cov teeb meem uas qhov kev txwv pom tau ntsib tom qab kev hais kwv txhiaj ncig kawg nkaus xwb;nws yog rooj plaub tsis tu ncua nrog `exp = limit + 1`.
                //
                debug_assert_eq!(buf.len(), 0);
                if frac_digits > 0 {
                    // [0.][0000]
                    parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                    parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                    Formatted {
                        sign,
                        // KEV RUAJ NTSEG: peb nyuam qhuav pib lub ntsiab `..2`.
                        parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                    }
                } else {
                    parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                    Formatted {
                        sign,
                        // KEV RUAJ NTSEG: peb nyuam qhuav pib lub ntsiab `..1`.
                        parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                    }
                }
            } else {
                Formatted { sign, parts: digits_to_dec_str(buf, exp, frac_digits, parts) }
            }
        }
    }
}