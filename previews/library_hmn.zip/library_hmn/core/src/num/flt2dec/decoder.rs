//! Ntu cov txiaj ntsig ntab ua ke rau hauv cov khoom ntiag tug thiab ntu tsis raug.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Thim tawm daim ntawv tsis txaus ntseeg tus nqi kawg, xws li tias:
///
/// - Tus nqi qub vaj huam sib luag rau `mant * 2^exp`.
///
/// - Ib qho lej twg los ntawm `(mant - minus)*2^exp` rau `(mant + plus)* 2^exp` yuav hloov mus rau tus nqi qub.
/// Qhov ntau yog suav nrog thaum `inclusive` yog `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Cov ntsuas mantissa.
    pub mant: u64,
    /// Tus nqi yuam kev qis dua.
    pub minus: u64,
    /// Cov yuam kev sab sauv.
    pub plus: u64,
    /// Qhov muab sib qhia ntawm ncua hauv 2.
    pub exp: i16,
    /// Muaj tseeb thaum cov yuam kev ntau yog nyob rau hauv.
    ///
    /// Hauv IEEE 754, qhov no muaj tseeb thaum thawj mantissa txawm yog.
    pub inclusive: bool,
}

/// Thim tawm tus nqi tsis txaus.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Infinities, txawm yog zoo los sis tsis zoo.
    Infinite,
    /// Xoom, txawm tias yog qhov zoo lossis tsis zoo.
    Zero,
    /// Cov lej finite nrog cov teb txuas ntxiv.
    Finite(Decoded),
}

/// Floating point hom uas tuaj yeem yog 'txiav suab' d.
pub trait DecodableFloat: RawFloat + Copy {
    /// Yam tsawg kawg nkaus zoo muaj nuj nqis.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Rov qab xee npe (muaj tseeb thaum tsis zoo) thiab `FullDecoded` tus nqi los ntawm tus naj npawb ntab.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // cov neeg nyob ze: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode yeej ib txwm khaws cia cov kev nthuav qhia, yog li cov mantissa muaj qhov ntsuas qis rau cov subnormals.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // cov neeg nyob ze: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // qhov twg maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // cov neeg nyob ze: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}