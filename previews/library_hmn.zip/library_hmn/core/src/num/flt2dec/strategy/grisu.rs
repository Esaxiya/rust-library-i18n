//! Rust kev yoog ntawm Grisu3 algorithm piav qhia hauv "Luam Ntawv Npog-Ntev Tus lej sai thiab nrawm nrog cov lej" [^ 1].
//! Nws siv txog 1KB ntawm precomputed lub rooj, thiab nyob rau hauv lem, nws ceev heev rau feem ntau cov khoom siv.
//!
//! [^1]: Florian Loitsch.2010. Luam cov lej ntab tau sai thiab
//!   yog nrog zauv.SIGPLAN Tsis.45, 6 (Lub Rau Hli 2010), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// saib cov lus hauv `format_shortest_opt` rau cov cim.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-Kuv;e=4* Kuv, 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f e e, k) Q!
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// Muab `x > 0`, rov `(k, 10^k)` xws tias `10^k <= x < 10^(k+1)`.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// Qhov luv tshaj hom kev siv rau Grisu.
///
/// Nws rov `None` thaum nws yuav rov ua qhov sawv cev tsis muaj txiaj ntsig txwv tsis pub.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // peb xav tau tsawg kawg peb qho ntawm qhov tseeb

    // pib nrog qhov muaj nuj nqis ib txwm nrog rau kev sib piav qhia
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // pom ib qho `cached = 10^minusk` xws li `ALPHA <= minusk + plus.e + 64 <= GAMMA`.
    // txij `plus` ib txwm ua, qhov no txhais tau tias `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`;
    // muab peb cov kev xaiv ntawm `ALPHA` thiab `GAMMA`, qhov no tso `plus * cached` rau hauv `[4, 2^32)`.
    //
    // Nws yog qhov tsim nyog tau pom kom ua kom loj tshaj plaws `GAMMA - ALPHA`, yog li peb tsis xav tau ntau lub hwj chim ntawm 10, tab sis muaj qee qhov kev txiav txim siab:
    //
    //
    // 1. peb xav kom `floor(plus * cached)` nyob rau hauv `u32` vim nws xav tau tus nqi faib nyiaj.
    //    (qhov no tsis yog zam tau tiag tiag, qhov tseem tshuav yog qhov yuav tsum tau ua rau raug kwv yees tseeb.)
    // 2.
    // qhov seem ntawm `floor(plus * cached)` pheej tau khoo los ntawm 10, thiab nws yuav tsum tsis txhob dhau.
    //
    // thawj muab `64 + GAMMA <= 32`, thaum ob muab `10 * 2^-ALPHA <= 2^64`;
    // -60 thiab -32 yog qhov ntau ntau nrog cov kev txwv no, thiab V8 kuj siv lawv.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // nplai fps.qhov no muab qhov ua kom siab kawg ntawm 1 ulp (muaj pov thawj los ntawm Theorem 5.1).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-Qhov tseeb ntau ntawm rho tawm
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // saum toj no `minus`, `v` thiab `plus` yog *kom muaj nuj nqis* ua rau kwv yees (yuam kev <1 ulp).
    // raws li peb tsis paub qhov yuam kev yog qhov zoo los yog qhov tsis zoo, peb siv ob txoj kev kwv yees sib npaug sib npaug thiab muaj qhov ua siab tshaj plaws ntawm 2 ulps.
    //
    // lub "unsafe region" yog lub sijhawm ywj pheej uas peb pib tsim.
    // lub "safe region" yog qhov tsis muaj kev tsis pom zoo uas peb tsuas yog txais.
    // peb pib nrog qhov tseeb repr hauv thaj chaw tsis nyab xeeb, thiab sim nrhiav qhov ze tshaj rau `v` uas tseem nyob hauv thaj chaw nyab xeeb.
    // yog tias peb ua tsis tau, peb muab mus.
    //
    let plus1 = plus.f + 1;
    // cia plus0 = plus.f, 1;//tsuas yog rau kev piav qhia cia minus0 = minus.f + 1;//tsuas yog rau kev piav qhia
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // sib piav qhia

    // faib `plus1` rau hauv cov ntu thiab qhov seem.
    // qhov chaw tseem ceeb tau lees tias yuav haum hauv u32, txij li cached lub zog lav `plus < 2^32` thiab `plus.f` li qub ib txwm tsawg dua `2^64 - 2^4` vim muaj qhov yuav tsum tau siv.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // suav cov `10^max_kappa` coob tsis tshaj `plus1` (yog li `plus1 < 10^(max_kappa+1)`).
    // qhov no yog qaum qaum ntawm `kappa` hauv qab no.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // Theorem 6.2: yog `k` yog qhov loj tshaj integer st
    // `0 <= y mod 10^k <= y - x`,              ces `V = floor(y / 10^k) * 10^k` yog nyob rau hauv `[x, y]` thiab ib qho ntawm cov neeg sawv cev luv tshaj plaws (nrog cov lej tsawg kawg ntawm cov lej tseem ceeb) hauv qhov ntawd.
    //
    //
    // pom cov lej ntev `kappa` nruab nrab ntawm `(minus1, plus1)` as per Theorem 6.2.
    // Theorem 6.2 tuaj yeem saws cais tawm `x` los ntawm kev xav tau `y mod 10^k < y - x` hloov.
    // (Xws li, `x` =32000, `y` =32777; `kappa` =2 txij li thaum 'y mod 10 ^ 3=777 <y, x=777`.) Lub algorithm cia siab rau lub tom qab pov thawj theem mus kaws `y`.
    //
    let delta1 = plus1 - minus1;
    // cia delta1int=(delta1>> e) raws li usize;//tsuas yog rau kev piav qhia
    let delta1frac = delta1 & ((1 << e) - 1);

    // muab cov seem, thaum kuaj xyuas qhov tseeb ntawm txhua kauj ruam.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // tus lej tseem yuav tsis tau txais
    loop {
        // peb ib txwm muaj tsawg kawg ib tug lej los tshaj tawm, raws li `plus1 >= 10^kappa` tus neeg xa khoom:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (nws ua raws `remainder = plus1int % 10^(kappa+1)`)
        //
        //

        // faib `remainder` los ntawm `10^kappa`.ob qho tib si scaled los ntawm `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; peb pom qhov tseeb `kappa`.
            let ten_kappa = (ten_kappa as u64) << e; // nplai 10 ^ kappa rov qab rau cov kev faib tawm
            return round_and_weed(
                // KEV RUAJ NTSEG: peb tau pib qhov cim xeeb saum toj no.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // txhawm rau lub voj thaum peb tau rendered tag nrho cov lej.
        // Tus lej pes tsawg ntawm cov lej yog `max_kappa + 1` li `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // rov qab los ua kom tau zoo
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // kav fractional qhov chaw, thaum khij rau cov neeg nyob rau txhua kauj ruam.
    // lub sijhawm no peb tso siab rau qhov rov ua ntau dua, raws li kev faib yuav poob lub precision.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // tus lej tom ntej yuav tsum yog qhov tseem ceeb raws li peb tau sim ua ntej ua txhaum kev tawm tsam, qhov twg `m = max_kappa + 1` (#ntawm tus lej hauv feem tseem ceeb):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // yuav tsis phwj, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // faib `remainder` los ntawm `10^kappa`.
        // ob qho tag nrho cov scaled los ntawm `2^e / 10^kappa`, yog li tom kawg yog implicit ntawm no.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // implicit divisor
            return round_and_weed(
                // KEV RUAJ NTSEG: peb tau pib qhov cim xeeb saum toj no.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // rov qab los ua kom tau zoo
        kappa -= 1;
        remainder = r;
    }

    // peb tau tsim txhua tus lej tseem ceeb ntawm `plus1`, tab sis tsis paub meej tias nws yog qhov zoo.
    // piv txwv li, yog `minus1` yog 3.14153 ... thiab `plus1` yog 3.14158 ..., muaj 5 qhov sawv cev luv tshaj ntawm 3.14154 rau 3.14158 tab sis peb tsuas muaj qhov zoo tshaj.
    // peb yuav tsum ua kom tiav tsawg tus lej kawg thiab tshawb xyuas yog tias qhov no yog qhov zoo tshaj.
    // Muaj ntau ntawm 9 tus neeg sib tw (..1 txog ..9), yog li qhov no ncaj ncees.("rounding" theem)
    //
    // cov nuj nqi kuaj xyuas yog tias qhov no "optimal" repr yog qhov tseeb nyob rau hauv ulp ranges, thiab tseem, nws yog qhov ua tau tias "second-to-optimal" repr tuaj yeem ua tau zoo tshaj vim qhov yuam kev ncig.
    // nyob rau hauv txawm tias qhov no rov `None`.
    // ("weeding" theem)
    //
    // tag nrho cov kev sib cav ntawm no yog scaled los ntawm cov nquag (tab sis implicit) tus nqi `k`, yog li ntawd:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (thiab tseem, `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (thiab tseem, `threshold > plus1v` los ntawm kev tawm tsam ua ntej)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // tsim ob qhov kwv yees rau `v` (qhov tseeb `plus1 - v`) hauv 1.5 ulps.
        // cov sawv cev tsim nyog yuav tsum tau sawv cev ze tshaj plaws rau ob qho tib si.
        //
        // ntawm no `plus1 - v` tau siv txij li kev suav tau ua nrog kev saib xyuas `plus1` kom tsis txhob overflow/underflow (li no zoo li hloov npe).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1 ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 mob plab)

        // txo tus lej kawg thiab nres ntawm qhov sawv cev ze tshaj plaws rau `v + 1 ulp`.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // peb ua haujlwm nrog tus lej kwv yees `w(n)`, uas pib sib npaug rau `plus1 - plus1 % 10^kappa`.tom qab khiav lub voj lub cev `n` lub sijhawm, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // peb teeb `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` (yog li `tseem tshuav= plus1w(0)`) los piv rau cov tshev.
            // nco ntsoov tias `plus1w(n)` ib txwm nce zuj zus.
            //
            // peb muaj peb yam kev yuav tsum tu.ib qho ntawm lawv yuav ua rau lub voj tsis tuaj yeem ua mus ntxiv, tab sis peb tom qab muaj tsawg kawg yog ib tus sawv cev siv tau paub uas ze rau `v + 1 ulp` li cas los xij.
            // peb yuav txhais tau lawv li TC1 dhau TC3 rau kev txhim kho.
            //
            // TC1: `w(n) <= v + 1 ulp`, ie, qhov no yog zaum kawg repr uas tuaj yeem ua qhov ze tshaj plaws.
            // qhov no yog sib npaug rau `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up`.
            // ua ke nrog TC2 (uas tshawb xyuas yog `w(n+1)` is valid), qhov no tiv thaiv kom tsis muaj qhov cuam tshuam ntawm kev xam ntawm `plus1w(n)`.
            //
            // TC2: `w(n+1) < minus1`, piv txwv li, repr tom ntej no twv yuav raug hu tsis suav rau `v`.
            // qhov no yog sib npaug rau `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold`.
            // sab lauj sab laug tuaj yeem dhau, tab sis peb paub `threshold > plus1v`, yog li TC1 yog cuav, `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` thiab peb tuaj yeem kuaj xyuas yog tias `threshold - plus1w(n) < 10^kappa` hloov.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, piv txwv li, txuas ntxiv mus yog
            // tsis muaj los ze rau `v + 1 ulp` dua li cov repr tam sim no.
            // muab `z(n) = plus1v_up - plus1w(n)`, qhov no ua `abs(z(n)) <= abs(z(n+1))`.rov qab xav tias qhov TC1 yog cuav, peb muaj `z(n) > 0`.peb muaj ob kis los xav txog:
            //
            // - thaum `z(n+1) >= 0`: TC3 dhau los ua `z(n) <= z(n+1)`.
            // raws li `plus1w(n)` nce zuj zus, `z(n)` yuav tsum ua kom tsawg zuj zus thiab qhov no tsis muaj tseeb.
            // - thaum `z(n+1) < 0`:
            //   - TC3a: qhov tsim nyog ua ntej yog `plus1v_up < plus1w(n) + 10^kappa`.Piv txwv tias TC2 yog cuav, `threshold >= plus1w(n) + 10^kappa` yog li nws tsis tuaj yeem dhau.
            //   - TC3b: TC3 dhau los ua `z(n) <= -z(n+1)`, piv txwv li, `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   Cov negated TC1 muab `plus1v_up > plus1w(n)`, yog li nws tsis tuaj yeem dhau lossis nqus dhau thaum txuam nrog TC3a.
            //
            // yog li ntawd, peb yuav tsum nres thaum `TC1 || TC2 || (TC3a && TC3b)`.Cov hauv qab no yog sib npaug rau nws rov qab, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // txoj kev luv tshaj plaws tsis tau xaus nrog `0`
                plus1w += ten_kappa;
            }
        }

        // kos yog tias qhov sawv cev no tseem sawv cev ze tshaj plaws rau `v - 1 ulp`.
        //
        // qhov no tsuas yog zoo ib yam rau cov kab mob no xaus rau `v + 1 ulp`, nrog txhua `plus1v_up` hloov `plus1v_down` hloov.
        // txeej tshawb tib yam nkaus.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // tam sim no peb muaj cov sawv cev ze tshaj plaws rau `v` nruab nrab ntawm `plus1` thiab `minus1`.
        // qhov no tsis dhau kev ywj pheej, tab sis yog, yog li peb tsis lees txais `w(n)` tsis nruab nrab ntawm `plus0` thiab `minus0`, piv txwv li, `plus1 - plus1w(n) <= minus0` lossis `plus1 - plus1w(n) >= plus0`.
        // peb siv qhov tseeb uas `threshold = plus1 - minus1` thiab `plus1 - plus0 = minus0 - minus1 = 2 ulp`.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// Txoj kev luv tshaj plaws kev siv rau Grisu nrog Zaj fallback.
///
/// Qhov no yuav tsum raug siv rau feem ntau.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // KEV RUAJ NTSEG: Tus txheeb xyuas qiv tsis ntse tsis txaus cia peb siv `buf`
    // nyob rau hauv ob branch, yog li peb ntxhua lub neej ntawm no.
    // Tab sis peb tsuas yog rov siv `buf` yog `format_shortest_opt` xa rov `None` yog li qhov no zoo.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// Qhov tseeb thiab hom rau kev siv rau Grisu.
///
/// Nws rov `None` thaum nws yuav rov ua qhov sawv cev tsis muaj txiaj ntsig txwv tsis pub.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // peb xav tau tsawg kawg peb qho ntawm qhov tseeb
    assert!(!buf.is_empty());

    // normalize thiab nplai `v`.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // faib `v` rau hauv cov ntu thiab qhov seem.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // ob qho tib si `v` qub thiab `v` tshiab (ntsuas los ntawm `10^-k`) muaj qhov yuam kev ntawm <1 ulp (Theorem 5.1).
    // raws li peb tsis paub qhov yuam kev yog qhov zoo los yog qhov tsis zoo, peb siv ob txoj kev kwv yees sib npaug sib npaug thiab muaj qhov siab tshaj plaws ntawm 2 ulps (tib yam li qhov xwm txheej luv).
    //
    //
    // lub hom phiaj yog kom nrhiav tau cov kab uas muaj dab tsi zoo ib yam ntawm cov `v - 1 ulp` thiab `v + 1 ulp`, kom peb muaj kev ntseeg siab.
    // Yog tias qhov no ua tsis tau, peb tsis paub qhov twg yog qhov tsim tawm rau `v`, yog li peb muab thiab poob rov qab.
    //
    // `err` yog txhais tau tias yog `1 ulp * 2^e` ntawm no (zoo tib yam li ulp hauv `vfrac`), thiab peb yuav ntsuas nws thaum twg `v` raug ntsuas.
    //
    //
    //
    let mut err = 1;

    // suav cov `10^max_kappa` coob tsis tshaj `v` (yog li `v < 10^(max_kappa+1)`).
    // qhov no yog qaum qaum ntawm `kappa` hauv qab no.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // yog tias peb ua haujlwm dhau los ntawm qhov kev txwv kawg kawg, peb yuav tsum ua kom tsis zoo ua ntej ua ntej yuav tsum ua kom tiav kom tsis txhob sib npaug.
    //
    // Nco ntsoov tias peb yuav tsum ntug qhov tsis txaus siab thaum muab sib npaug!
    let len = if exp <= limit {
        // oops, Peb tsis tuaj yeem tsim *ib* tus lej.
        // qhov no ua tau thaum, hais tias, peb tau txais qee yam zoo li 9.5 thiab nws tau ua kom sib npaug rau 10.
        //
        // hauv txoj cai peb tuaj yeem hu `possibly_round` tam sim nrog qhov tsis muaj kev tiv thaiv, tab sis kev ntsuas rau `max_ten_kappa << e` los ntawm 10 tuaj yeem ua kom txeej.
        //
        // yog li peb tau nqes hav ntawm no thiab nthuav dav qhov yuam kev ntau yam los ntawm 10 ntawm.
        // qhov no yuav nce qhov cuav tsis tseeb, tab sis tsuas yog heev,*heev* me ntsis;
        // nws tsuas yog qhov tseem ceeb tshaj plaws thaum lub mantissa loj dua 60 qhov.
        //
        // KEV RUAJ NTSEG: `len=0`, yog li lub luag haujlwm ntawm kev pib qhov cim xeeb no tsis tseem ceeb.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // kav cov seem.
    // qhov kev ua yuam kev yog qhov fractional, yog li peb tsis tas kuaj nws hauv ntu no.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // tus lej tseem yuav tsis tau txais
    loop {
        // peb ib txwm muaj tsawg kawg ib tug lej los muab kev tawm tsam:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (nws ua raws `remainder = vint % 10^(kappa+1)`)
        //
        //

        // faib `remainder` los ntawm `10^kappa`.ob qho tib si scaled los ntawm `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // yog tus tsis tas?khiav kev sib hloov dhau nrog cov seem.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ kappa) * 2 ^ e
            // KEV RUAJ NTSEG: peb tau pib `len` ntau bytes.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // txhawm rau lub voj thaum peb tau rendered tag nrho cov lej.
        // Tus lej pes tsawg ntawm cov lej yog `max_kappa + 1` li `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // rov qab los ua kom tau zoo
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // kav seem seem.
    //
    // hauv txoj cai peb tuaj yeem txuas ntxiv mus rau tus lej kawg muaj tuaj thiab kuaj seb puas raug.
    // Hmoov tsis zoo peb tau ua haujlwm nrog cov zauv suav qhov ntsuas-qhov loj me, yog li peb xav tau qee qhov ntsuas los kuaj xyuas cov txeej.
    // V8 siv `remainder > err`, uas dhau los ua tsis tseeb thaum thawj `i` tus lej tseem ceeb ntawm `v - 1 ulp` thiab `v` txawv.
    // txawm li cas los qhov no tsis lees txais ntau dhau los siv tau kev tawm tswv yim.
    //
    // txij li theem tom qab muaj qhov paub meej dhau nrhiav kom tau, peb hloov siv tus qauv nruj:
    // peb txuas ntxiv til `err` tshaj `10^kappa / 2`, kom qhov ntau ntawm `v - 1 ulp` thiab `v + 1 ulp` twv yuav raug hu muaj ob lossis ntau dua cov duab sawv cev.
    //
    // qhov no zoo tib yam rau thawj ob qhov sib piv los ntawm `possibly_round`, rau kev siv.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // invariants, qhov twg `m = max_kappa + 1` (#ntawm tus lej hauv feem tseem ceeb):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // yuav tsis phwj, `2^e * 10 < 2^64`
        err *= 10; // yuav tsis phwj, `err * 10 < 2^e * 5 < 2^64`

        // faib `remainder` los ntawm `10^kappa`.
        // ob qho tag nrho cov scaled los ntawm `2^e / 10^kappa`, yog li tom kawg yog implicit ntawm no.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // yog tus tsis tas?khiav kev sib hloov dhau nrog cov seem.
        if i == len {
            // KEV RUAJ NTSEG: peb tau pib `len` ntau bytes.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // rov qab los ua kom tau zoo
        remainder = r;
    }

    // kev xam ntxiv tsis muaj txiaj ntsig (`possibly_round` twv yuav raug tsis ua hauj lwm), yog li peb tso tawm.
    return None;

    // peb tau tsim txhua tus lej thov ntawm `v`, uas yuav tsum zoo ib yam rau cov lej ntawm `v - 1 ulp`.
    // tam sim no peb xyuas yog tias muaj cov sawv cev tshwj xeeb tau qhia los ntawm ob qho `v - 1 ulp` thiab `v + 1 ulp`;qhov no tuaj yeem ua tau zoo ib yam rau cov lej tsim tawm, lossis rau cov kab sib npaug ntawm cov lej.
    //
    // yog tias cov ntau muaj ntau cov sawv cev ntawm tib qho ntev, peb tsis tuaj yeem paub meej thiab yuav tsum rov qab `None` hloov.
    //
    // tag nrho cov kev sib cav ntawm no yog scaled los ntawm cov nquag (tab sis implicit) tus nqi `k`, yog li ntawd:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // KEV RUAJ NTSEG: thawj `len` bytes ntawm `buf` yuav tsum tau pib ua ntej.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (rau qhov siv, kab teev dotted qhia qhov muaj nuj nqis rau cov sawv cev muaj peev xwm hauv tus lej ntawm tus lej.)
        //
        //
        // qhov yuam kev loj heev uas muaj tsawg kawg peb qhov sawv cev ntawm `v - 1 ulp` thiab `v + 1 ulp`.
        // peb tsis tuaj yeem txiav txim siab tias qhov twg yog qhov tseeb.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // qhov tseeb, 1/2 ulp yog qhov txaus los qhia ob qho kev ua sawv cev.
        // (Nco ntsoov tias peb xav tau cov qauv sawv cev rau ob qho `v - 1 ulp` thiab `v + 1 ulp`.) qhov no yuav tsis dhau, qhov `ulp < ten_kappa` los ntawm thawj daim tshev.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ kappa-- -------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // yog `v + 1 ulp` los ze dua rau cov sawv cev sib npaug (uas twb tau nyob hauv `buf`), ces peb tuaj yeem rov qab los nyab xeeb.
        // nco ntsoov tias `v - 1 ulp`*tuaj yeem* tsawg dua cov sawv cev tam sim no, tab sis raws li `1 ulp < 10^kappa / 2`, cov mob no txaus:
        // qhov kev ncua deb ntawm `v - 1 ulp` thiab tus sawv cev tam sim no tsis pub tshaj `10^kappa / 2`.
        //
        // tus mob yog sib npaug rau `remainder + ulp < 10^kappa / 2`.
        // vim qhov no tuaj yeem yooj yim txeej, thawj zaug kos yog `remainder < 10^kappa / 2`.
        // peb twb qhia tau tseeb lawm tias `ulp < 10^kappa / 2`, tsuav `10^kappa` tsis dhau ua cov cuam tshuam tom qab tag nrho, daim tshev thib ob zoo.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // KEV RUAJ NTSEG: peb cov neeg hu nws pib ntawd nco.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------qhov seem-- ----> |:
        //   :                          |   :
        //   : <---------10 ^ kappa-- ------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // ntawm qhov tod tes, yog tias `v - 1 ulp` los ze dua rau cov sawv cev kab puag ncig, peb yuav tsum puag ncig thiab xa rov qab.
        // rau tib qho laj thawj peb tsis tas yuav txheeb xyuas `v + 1 ulp`.
        //
        // tus mob yog sib npaug rau `remainder - ulp >= 10^kappa / 2`.
        // dua peb xub xyuas yog `remainder > ulp` (nco ntsoov tias qhov no tsis yog `remainder >= ulp`, li `10^kappa` yeej tsis tau xoom).
        //
        // tseem nco ntsoov tias `remainder - ulp <= 10^kappa`, yog li daim tshev thib ob tsis txeej.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // KEV RUAJ NTSEG: peb tus hu yuav tsum muaj qhov pib tias qhov kev nco.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // tsuas yog ntxiv ib tus lej ntxiv thaum peb tau thov kom lub sijhawm muaj kev txwv.
                // peb kuj yuav tsum tau xyuas tias, yog tus thawj tsis nyob hauv lub qub, tus lej ntxiv tsuas muab tau thaum muaj `exp == limit` (edge rooj plaub).
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // KEV RUAJ NTSEG: peb thiab peb tus hu pib ua qhov kev nco ntawd.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // txwv tsis pub peb yuav ibtxhi (piv txwv li, qee qhov tseem ceeb ntawm `v - 1 ulp` thiab `v + 1 ulp` yog kev sib faib thiab lwm tus tab tom muab ncig) thiab tso tawm.
        //
        None
    }
}

/// Qhov tseeb thiab hom rau kev siv rau Grisu nrog Zaj fallback.
///
/// Qhov no yuav tsum raug siv rau feem ntau.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // KEV RUAJ NTSEG: Tus txheeb xyuas qiv tsis ntse tsis txaus cia peb siv `buf`
    // nyob rau hauv ob branch, yog li peb ntxhua lub neej ntawm no.
    // Tab sis peb tsuas yog rov siv `buf` yog `format_exact_opt` xa rov `None` yog li qhov no zoo.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}