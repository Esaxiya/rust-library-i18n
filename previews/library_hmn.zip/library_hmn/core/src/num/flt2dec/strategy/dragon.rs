//! Yuav luag ncaj qha (tab sis muaj ntsis zoo me ntsis) Rust kev txhais lus ntawm Daim Duab 3 ntawm "Luam Ntawv Npav-Taw Qhia tus lej nrawm thiab nrawm" [^ 1].
//!
//!
//! [^1]: Burger, RG thiab Dybvig, RK 1996. Luam cov naj npawb ntawm ntab
//!   sai thiab meej.SIGPLAN Tsis.31, 5 (Tsib Hlis Ntuj 1996), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// precalculated arrays ntawm `Zauv` rau 10 ^ (2 ^ n)
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// tsuas siv tau thaum `x < 16 * scale`;`scaleN` yuav tsum `scale.mul_small(N)`
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// Qhov luv tshaj hom kev siv rau Zaj.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // tus lej `v` rau hom ntawv yog paub tias yog:
    // - sib npaug `mant * 2^exp`;
    // - ua ntej los ntawm `(mant - 2 *minus)* 2^exp` hauv thawj hom;thiab
    // - ua raws li `(mant + 2 *plus)* 2^exp` nyob rau hauv hom thawj.
    //
    // pom tseeb, `minus` thiab `plus` tsis tuaj yeem yog xoom.(rau cov tsis tseem ceeb, peb siv qhov tsis muaj txiaj ntsig tawm.) Peb kuj xav tias tsawg kawg ib tus lej yog tsim tawm, piv txwv li, `mant` tsis tuaj yeem yog xoom ib yam nkaus.
    //
    // qhov no kuj txhais tau tias txhua tus lej nruab nrab ntawm `low = (mant - minus)*2^exp` thiab `high = (mant + plus)* 2^exp` yuav ua daim phiaj rau tus naj npawb ntab ntab, nrog cov ciam nrog thaum tus thawj mantissa tseem yog (piv txwv li, `!mant_was_odd`).
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` yog `if d.inclusive {a <= b} else {a < b}`
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // kwv yees `k_0` ntawm thawj cov tswv yim txhawb siab `10^(k_0-1) < high <= 10^(k_0+1)`.
    // nruj khi `k` txaus siab `10^(k-1) < high <= 10^k` suav tom qab.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // hloov `{mant, plus, minus} * 2^exp` rau hauv cov fractional li ntawd:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // faib `mant` los ntawm `10^k`.tam sim no `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // kho tas thaum `mant + plus > scale` (lossis `>=`).
    // peb tsis tau hloov kho `scale`, vim tias peb tuaj yeem hla thawj cov sib npaug tsis hloov.
    // tam sim no `scale < mant + plus <= scale * 10` thiab peb npaj siab tsim cov lej.
    //
    // nco ntsoov tias `d[0]`*tuaj yeem* yog xoom, thaum `scale - plus < mant < scale`.
    // hauv qhov no rounding-up mob (`up` hauv qab) yuav ua rau muaj kev cuam tshuam tam sim ntawd.
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // sib npaug rau ntsuas `scale` los ntawm 10
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // cache `(2, 4, 8) * scale` rau lej tiam.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // invariants, qhov twg `d[0..n-1]` yog cov lej generated kom deb li deb:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (Yog li `mant / scale < 10`) qhov twg `d[i..j]` yog ib tug shorthand rau 'd [i] * 10 ^ (ji) + ...
        // + d [j-1] * 10 + d[j]`.

        // tsim ib tug lej: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // qhov no yog cov lus piav qhia yooj yim ntawm Cov Lus Hloov kho.
        // ntau cov kev sib txuas lus nruab nrab thiab kev sib cav tag nrho tau muab tso tseg kom yooj yim.
        //
        // pib nrog hloov kho tshiab, raws li peb tau hloov kho `n`:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // xav tias `d[0..n-1]` yog cov sawv cev luv tshaj plaws ntawm `low` thiab `high`, piv txwv li, `d[0..n-1]` txaus siab rau tag nrho ob qho hauv qab no tab sis `d[0..n-2]` tsis:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (bijectivity: tus lej puag ncig mus rau `v`);thiab
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (tus lej kawg yog qhov tseeb).
        //
        // qhov xwm txheej thib ob yooj yim rau `2 * mant <= scale`.
        // daws cov kab tsis haum nyob rau hauv cov nqe lus ntawm `mant`, `low` thiab `high` yields yooj yim dua cov thawj cov mob: `-plus < mant < minus`.
        // txij `-plus < 0 <= mant`, peb muaj qhov ua kom luv luv sawv cev thaum `mant < minus` thiab `2 * mant <= scale`.
        // (tus qub dhau los ua `mant <= minus` thaum lub mantissa tseem yog.)
        //
        // thaum tus thib ob tsis tuav (`2 * mant> scale`), peb yuav tsum nce tus lej kawg.
        // qhov no yog txaus rau kev kho kom rov zoo li ntawd: peb twb paub tias tus lej lej lav lub `0 <= v / 10^(k-n) - d[0..n-1] < 1`.
        // nyob rau hauv cov ntaub ntawv no, thawj tus mob ua `-plus < mant - scale < minus`.
        // txij `mant < scale` tom qab tiam, peb muaj `scale < mant + plus`.
        // (dua, qhov no ua `scale <= mant + plus` thaum tus thawj mantissa tseem.)
        //
        // nyob rau hauv luv luv:
        // - nres thiab ncig `down` (khaws cov lej tseem yog) thaum `mant < minus` (lossis `<=`).
        // - nres thiab ncig `up` (nce tus lej kawg) thaum `scale < mant + plus` (lossis `<=`).
        // - cia rau kom muaj roj ntau.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // peb muaj qhov sawv cev luv tshaj plaws, pib mus rau kev sib hloov

        // rov qab cov invariants.
        // qhov no ua rau lub algorithm ib txwm tso tseg: `minus` thiab `plus` ib txwm nce, tab sis `mant` clipped modulo `scale` thiab `scale` tsau.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // kev sib hloov tshwm sim thaum i) tsuas yog kev sib hloov zuj zus xwb, lossis II) ob qho kev ua tau tshwm sim thiab khi tawg txoj kev nyiam muab sib npaug.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // Yog hais tias kev muab sib hloov hloov qhov ntev, tus piav qhia yuav tsum hloov.
        // nws zoo li tias qhov xwm txheej no nyuaj heev rau kev txaus siab (tejzaum nws ua tsis tau), tab sis peb tsuas yog ua kom zoo thiab zoo nyob ntawm no.
        //
        // KEV RUAJ NTSEG: peb tau pib qhov cim xeeb saum toj no.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // KEV RUAJ NTSEG: peb tau pib qhov cim xeeb saum toj no.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// Qhov tseeb thiab hom hloov siv rau Zaj.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // kwv yees `k_0` ntawm thawj cov tswv yim txhawb siab `10^(k_0-1) < v <= 10^(k_0+1)`.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // faib `mant` los ntawm `10^k`.tam sim no `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // kho thaum `mant + plus >= scale`, qhov twg `plus / scale = 10^-buf.len() / 2`.
    // txhawm rau kom ceev-loj bignum, peb yeej siv `mant + floor(plus) >= scale`.
    // peb tsis tau hloov kho `scale`, vim tias peb tuaj yeem hla thawj cov sib npaug tsis hloov.
    // dua nrog cov kev txiav txim siab luv luv, `d[0]` tuaj yeem yog xoom tab sis yuav thaum kawg ua kom sib npaug.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // sib npaug rau ntsuas `scale` los ntawm 10
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // yog tias peb ua haujlwm dhau los ntawm qhov kev txwv kawg kawg, peb yuav tsum ua kom tsis zoo ua ntej ua ntej yuav tsum ua kom tiav kom tsis txhob sib npaug.
    //
    // Nco ntsoov tias peb yuav tsum ntug qhov tsis txaus siab thaum muab sib npaug!
    let mut len = if k < limit {
        // oops, Peb tsis tuaj yeem tsim *ib* tus lej.
        // qhov no ua tau thaum, hais tias, peb tau txais qee yam zoo li 9.5 thiab nws tau ua kom sib npaug rau 10.
        // peb rov qab tsis npliag, nrog rau qhov kev zam ntawm tom ntej rounding-up rooj plaub uas tshwm sim thaum `k == limit` thiab yuav tsum tau ua raws nraim li ib tug lej.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // cache `(2, 4, 8) * scale` rau lej tiam.
        // (qhov no tuaj yeem yuav kim, yog li tsis txhob xam lawv thaum tsis yog khoob.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // cov lej hauv qab no txhua tus xoom, peb nres ntawm no ua *tsis* sim ua cov kev sib hloov!theej, sau cov lej seem.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // KEV RUAJ NTSEG: peb tau pib qhov cim xeeb saum toj no.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // kev sib puag ncig yog tias peb nres rau hauv nruab nrab ntawm cov lej yog tias cov lej hauv qab no yog muaj 5000 ..., kos lub taub ua ntej thiab sim ua kom sib npaug txawm tias (piv txwv li, zam kev sib puag thaum tus lej ua ntej yog txawm).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // KEV RUAJ NTSEG: `buf[len-1]` yog pib.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // Yog hais tias kev muab sib hloov hloov qhov ntev, tus piav qhia yuav tsum hloov.
        // tab sis peb tau thov kom muaj qee tus lej, yog li tsis hloov cov tsis ...
        // KEV RUAJ NTSEG: peb tau pib qhov cim xeeb saum toj no.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... tshwj tsis yog peb tau thov kom muaj lub chaw ruaj hloov.
            // peb kuj yuav tsum tau xyuas tias, yog tus thawj tsis nyob hauv lub qub, tus lej ntxiv tsuas muab tau thaum muaj `k == limit` (edge rooj plaub).
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // KEV RUAJ NTSEG: peb tau pib qhov cim xeeb saum toj no.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}