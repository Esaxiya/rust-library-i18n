use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// Ib tug wrapper hom los mus tsim uninitialized piv txwv ntawm `T`.
///
/// # initialization invariant
///
/// Lub compiler, nyob rau hauv Feem ntau, assumes hais tias ib tug nce mus nce los yog kom initialized raws li cov uas yuav tsum tau ntawm lub nce mus nce los lub hom.Piv txwv li, ib qho sib txawv ntawm kev siv hom yuav tsum mus ua ke thiab tsis-NULL.
/// Qhov no yog ib qho invariant uas yuav tsum *yeej ib txwm* yuav upheld, txawm nyob rau hauv tsis zoo code.
/// Raws li ib tug tsim nyog tau, pes tsawg-initializing ib tug nce mus nce los ntawm reference hom ua instantaneous [undefined behavior][ub], tsis muaj teeb meem seb uas siv puas tau tau siv rau kev nkag tau mus nco:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // kev coj cwj pwm tsis paub!⚠️
/// // Txoj cai sib npaug nrog `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // kev coj cwj pwm tsis paub!⚠️
/// ```
///
/// Qhov no yog exploited los ntawm cov compiler rau ntau yam optimizations, xws li eliding run-lub sij hawm cov tshev mis thiab optimizing `enum` layout.
///
/// Ib yam li ntawd, nkaus uninitialized nco tej zaum yuav muaj cov ntsiab lus, thaum ib tug `bool` yuav tsum nco ntsoov yuav `true` los yog `false`.Li no, tsim kom muaj uninitialized `bool` yog tus cwj pwm tsis paub tseeb:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // kev coj cwj pwm tsis paub!⚠️
/// // Lub sib npaug code nrog `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // kev coj cwj pwm tsis paub!⚠️
/// ```
///
/// Ntxiv mus, uninitialized nco yog tshwj xeeb nyob rau hauv hais tias nws tsis muaj ib tug tsau nqi ("fixed" ntsiab lus "it won't change without being written to").Nyeem cov tib uninitialized byte ntau lub sij hawm yuav muab sib txawv tau.
/// Qhov no ua rau nws undefined tus cwj pwm kom muaj uninitialized ntaub ntawv nyob rau hauv ib tug nce mus nce los txawm yog hais tias nce mus nce los muaj ib tug integer yam, uas tsis muaj peev xwm tuav tej *tsau* ntsis qauv:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // kev coj cwj pwm tsis paub!⚠️
/// // Lub sib npaug code nrog `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // kev coj cwj pwm tsis paub!⚠️
/// ```
/// (Daim ntawv ceeb toom hais tias cov kev cai nyob ib ncig ntawm uninitialized zauv tsis tiav tsis tau, tab sis mus txog rau thaum lawv yog, nws yog advisable kom tsis txhob rau lawv.)
///
/// Nyob rau sab saum toj ntawm uas, nco ntsoov tias feem ntau hom muaj ntxiv invariants tshaj tsuas xam tau tias yog initialized ntawm lub hom theem.
/// Piv txwv li, ib tug '1`-initialized [`Vec<T>`] yog suav tias yog initialized (nyob rau hauv lub tam sim no siv; qhov no tsis roos ib tug ruaj khov guarantee) vim hais tias cov tsuas yuav tsum tau cov compiler paub txog nws yog tias cov ntaub ntawv pointer yuav tsum uas tsis yog-thov.
/// Tsim xws li ib tug `Vec<T>` tsis ua *tam sim ntawd* undefined tus cwj pwm, tab sis yuav ua rau undefined tus cwj pwm nrog rau feem ntau muaj kev ruaj ntseg ua hauj lwm (xws li xa me nyuam rov nws).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` ua hauj lwm pab los pab kom tsis zoo code kam nrog uninitialized ntaub ntawv.
/// Nws yog ib lub teeb liab mus rau lub compiler qhia tias cov ntaub ntawv no tej zaum yuav *tsis* raug initialized:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Tsim ib tug ntsees uninitialized siv.
/// // Lub compiler yeej paub tias cov ntaub ntawv hauv ib lub `MaybeUninit<T>` tej zaum yuav invalid, thiab chaw pib no tsis yog UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Teem nws rau tus nqi siv tau.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Extract tus initialized cov ntaub ntawv-qhov no yog tsuas pub *tom qab* kom zoo initializing `x`!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Lub compiler ces paub tsis ua tej yam tsis yog kev xav los yog optimizations rau no code.
///
/// Koj tuaj yeem xav txog `MaybeUninit<T>` tau zoo li `Option<T>` tab sis tsis muaj ib qho ntawm cov khiav khiav sijhawm thiab tsis muaj kev kuaj xyuas kev nyab xeeb.
///
/// ## out-pointers
///
/// Koj muaj peev xwm siv `MaybeUninit<T>` siv "out-pointers": es tsis txhob ntawm rov qab los cov ntaub ntawv los ntawm ib tug muaj nuj nqi, kis tau nws ib tug pointer rau ib co (uninitialized) nco mus muab lub txiaj ntsim mus rau hauv.
/// Qhov no yuav ua tau pab tau thaum nws yog ib qho tseem ceeb rau tus neeg hu rau kev tswj yuav ua li cas lub cim xeeb cov kev tshwm sim yog muab cia rau hauv twg thiaj li raug faib, thiab koj xav kom tsis txhob muaj kev ruaj tsiv.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` tsis poob lub qub txheem, uas yog ib qho tseem ceeb.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Tam sim no peb paub `v` yog pib!Qhov no kuj ua kom paub tseeb lub vector twg thiaj li raug zoo poob.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Initializing ib array caij-by-caij
///
/// `MaybeUninit<T>` yuav siv tau los initialize ib tug loj array caij-by-caij:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Tsim ib tug uninitialized array ntawm `MaybeUninit`.
///     // Lub `assume_init` muaj kev nyab xeeb vim hais tias hom uas peb thov kom tau pib ua ntej ntawm no yog ib pawg ntawm `MaybeUninit`s, uas tsis tas yuav tsum pib ua ntej.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Xa tus `MaybeUninit` tsis muaj dab tsi.
///     // Yog li siv nyoos pointer hauj lwm es tsis txhob ntawm `ptr::write` tsis ua cov laus uninitialized nqi yuav tsum tau poob.
/////
///     // Tsis tas li ntawd yog hais tias muaj yog ib tug panic thaum lub sij hawm no voj, peb muaj ib tug cim xeeb los, tab sis yog tsis muaj lub cim xeeb kev nyab xeeb qhov teeb meem.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Txhua yam pib ua haujlwm.
///     // Transmute lub array mus rau lub initialized hom.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Koj muaj peev xwm tseem ua hauj lwm nrog cov initialized arrays, uas yuav muaj nyob rau hauv low-level datastructures.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Tsim ib tug uninitialized array ntawm `MaybeUninit`.
/// // Lub `assume_init` muaj kev nyab xeeb vim hais tias hom uas peb thov kom tau pib ua ntej ntawm no yog ib pawg ntawm `MaybeUninit`s, uas tsis tas yuav tsum pib ua ntej.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Suav cov naj npawb ntawm cov khoom peb tau muab rau.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Rau txhua yam khoom nyob rau hauv lub array, poob yog hais tias peb faib nws.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Initializing ib struct teb-by-teb
///
/// Koj muaj peev xwm siv `MaybeUninit<T>`, thiab cov [`std::ptr::addr_of_mut`] macro, initialize structs teb los ntawm teb:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Initializing lub `name` teb
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Initializing lub `list` teb Yog hais tias muaj yog ib tug panic no, ces tus `String` nyob rau hauv lub `name` teb txia.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Tag nrho cov teb cov initialized, yog li peb hu `assume_init` kom tau ib tug initialized Foo.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` yog lav kom muaj tib qhov loj me, kev ua kom haum, thiab ABI raws li `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Txawm li cas los xij nco ntsoov tias ib hom *muaj* ib qho `MaybeUninit<T>` tsis tas yuav yog tib cov qauv;Rust tsis nyob rau hauv kev guarantee hais tias lub teb ntawm ib tug `Foo<T>` muaj qhov kev txiav txim raws li ib tug `Foo<U>` txawm tias `T` thiab `U` muaj tib lub loj thiab kawm tuab si lug.
///
/// Tsis tas li ntawd vim hais tias tej me ntsis nqi yog siv tau rau ib `MaybeUninit<T>` lub compiler yuav tsis thov non-zero/niche-filling optimizations, uas ua rau ib tug loj loj:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Yog hais tias `T` yog FFI-kev nyab xeeb, ces thiaj li yog `MaybeUninit<T>`.
///
/// Thaum `MaybeUninit` yog `#[repr(transparent)]` (qhia tias nws lav qhov loj me, kev sib thooj, thiab ABI raws li `T`), qhov no ua rau *tsis* hloov pauv txhua yam ntawm yav dhau los caveats.
/// `Option<T>` thiab `Option<MaybeUninit<T>>` tej zaum tseem muaj ntau ntau thiab tsawg, thiab hom uas muaj ib daim teb ntawm hom `T` yuav tsum tau pw tawm (thiab me) txawv dua li yog hais tias teb tau `MaybeUninit<T>`.
/// `MaybeUninit` yog ib tug union hom, thiab `#[repr(transparent)]` rau cov tsev koom nyiaj no yog tsis ruaj tsis khov (saib [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Thaum lub sij hawm, lub caij nyoog guarantees ntawm `#[repr(transparent)]` rau cov tsev koom nyiaj evolve, thiab `MaybeUninit` yuav yog los kuj tsis nyob twj ywm `#[repr(transparent)]`.
/// Hais tias, `MaybeUninit<T>` yuav *yeej ib txwm* guarantee tias nws muaj tus loj tib yam, kawm tuab si lug, thiab ABI li `T`;nws cia li hais tias txoj kev `MaybeUninit` implements uas guarantee yuav evolve.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Lang yam khoom ces peb yuav qhwv lwm yam nyob rau hauv nws.Qhov no pab tau rau generators.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Tsis hu `T::clone()`, peb yuav tsis paub hais tias peb yog initialized txaus rau cov uas.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Tsim tus tshiab `MaybeUninit<T>` pib nrog tus nqi muab.
    /// Nws yog muaj kev ruaj ntseg yuav tau hu rau [`assume_init`] rau cov tuaj tus nqi ntawm no muaj nuj nqi.
    ///
    /// Nco ntsoov tias kev xa ib tus `MaybeUninit<T>` yuav tsis hu lub `T` tus lej poob.
    /// Nws yog koj lub luag hauj lwm kom paub tseeb tias `T` twg thiaj li raug poob yog hais tias nws tau initialized.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Tsim ib tug tshiab `MaybeUninit<T>` nyob rau hauv ib tug uninitialized lub xeev.
    ///
    /// Nco ntsoov tias kev xa ib tus `MaybeUninit<T>` yuav tsis hu lub `T` tus lej poob.
    /// Nws yog koj lub luag hauj lwm kom paub tseeb tias `T` twg thiaj li raug poob yog hais tias nws tau initialized.
    ///
    /// Saib cov [type-level documentation][MaybeUninit] rau ib co piv txwv.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Tsim kev tshiab ntawm `MaybeUninit<T>` cov khoom, nyob rau hauv lub xeev tsis txaus ntseeg.
    ///
    /// Note: nyob rau hauv ib tug future Rust version no txoj kev yuav ua ruaj thaum array literal syntax tso cai [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// Cov piv txwv hauv qab no ces tuaj yeem siv `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Rov qab ib feem me me ntawm cov ntaub ntawv uas tau nyeem
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // KEV RUAJ NTSEG: Ib uninitialized `[MaybeUninit<_>; LEN]` yog siv tau.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Tsim ib tug tshiab `MaybeUninit<T>` nyob rau hauv ib tug uninitialized lub xeev, nrog lub cim xeeb puv npo nrog `0` bytes.Nws nyob rau ntawm `T` seb uas twb ua rau kom initialization.
    ///
    /// Piv txwv li, `MaybeUninit<usize>::zeroed()` yog qhov pib, tab sis `MaybeUninit<&'static i32>::zeroed()` tsis yog vim kev xa mus yuav tsum tsis muaj dab tsi.
    ///
    /// Nco ntsoov tias kev xa ib tus `MaybeUninit<T>` yuav tsis hu lub `T` tus lej poob.
    /// Nws yog koj lub luag hauj lwm kom paub tseeb tias `T` twg thiaj li raug poob yog hais tias nws tau initialized.
    ///
    /// # Example
    ///
    /// Kev siv txoj haujlwm ntawm txoj haujlwm no: pib tsim tus qauv nrog xoom, qhov twg txhua daim teb ntawm tus qauv yuav tuav tus qauv me ntsis 0 ua tus nqi siv tau.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Qhov tsis raug* kev siv ntawm txoj haujlwm no: hu `x.zeroed().assume_init()` thaum `0` tsis yog siv tau me me-qauv rau hom:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Sab hauv khub, peb tsim `NotZero` uas tsis muaj kev ntxub ntxaug.
    /// // Nov yog kev coj tsis tus.️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // KEV RUAJ NTSEG: `u.as_mut_ptr()` cov ntsiab lus rau faib lub cim xeeb.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Poob lawm tus nqi ntawm cov `MaybeUninit<T>`.
    /// Qhov no overwrites yav dhau los tus nqi tsis muaj xa me nyuam rov nws li ntawd, yuav ceev faj tsis txhob siv no ob zaug tshwj tsis yog tias koj xav kom hla khiav lub destructor.
    ///
    /// Yooj yim rau koj, qhov no kuj rov mutable kev siv rau tus (tam sim no yam xyuam xim initialized) txheem ntawm `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // KEV RUAJ NTSEG: Peb nyuam qhuav pib tus nqi no.
        unsafe { self.assume_init_mut() }
    }

    /// Tau ib tug pointer mus rau lub muaj nqi.
    /// Nyeem ntawm tus pointer no los yog tig nws mus rau hauv kev siv yog tus cwj pwm tsis paub tshwj tsis yog tias `MaybeUninit<T>` tau pib ua ntej.
    /// Sau ntawv mus rau lub cim xeeb tias qhov no pointer (non-transitively) cov ntsiab lus los yog undefined tus cwj pwm (tsuas yog hauv ib lub `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Yog pab ntawm no txoj kev:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Tsim ib tug siv mus rau hauv lub `MaybeUninit<T>`.Qhov no yog li cas vim hais tias peb initialized nws.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *Tsis raug* kev siv ntawm hom no:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Peb tau tsim ib tug siv rau ib tug uninitialized vector!Qhov no yog undefined tus cwj pwm.️
    /// ```
    ///
    /// (Daim ntawv ceeb toom tias cov cai nyob ib puag ncig xa mus rau cov ntaub ntawv tsis tau tiav tseem tsis tau tiav tiav, tab sis txog thaum lawv ua tiav, nws raug nquahu kom zam lawv.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` thiab `ManuallyDrop` yog ob qho tib si `repr(transparent)` li ntawd, peb yuav muab pov rau hauv lub pointer.
        self as *const _ as *const T
    }

    /// Tau ib tug mutable pointer mus rau lub muaj nqi.
    /// Nyeem ntawm tus pointer no los yog tig nws mus rau hauv kev siv yog tus cwj pwm tsis paub tshwj tsis yog tias `MaybeUninit<T>` tau pib ua ntej.
    ///
    /// # Examples
    ///
    /// Yog pab ntawm no txoj kev:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Tsim ib tug siv mus rau hauv lub `MaybeUninit<Vec<u32>>`.
    /// // Qhov no yog li cas vim hais tias peb initialized nws.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *Tsis raug* kev siv ntawm hom no:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Peb tau tsim ib tug siv rau ib tug uninitialized vector!Qhov no yog undefined tus cwj pwm.️
    /// ```
    ///
    /// (Daim ntawv ceeb toom tias cov cai nyob ib puag ncig xa mus rau cov ntaub ntawv tsis tau tiav tseem tsis tau tiav tiav, tab sis txog thaum lawv ua tiav, nws raug nquahu kom zam lawv.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` thiab `ManuallyDrop` yog ob qho tib si `repr(transparent)` li ntawd, peb yuav muab pov rau hauv lub pointer.
        self as *mut _ as *mut T
    }

    /// Extract tus nqi ntawm lub thawv `MaybeUninit<T>`.Qhov no yog ib txoj kev zoo los xyuas kom meej tias cov ntaub ntawv yuav tau poob, vim hais tias cov uas ua `T` yog raug mus rau lub txwm nco tuav.
    ///
    /// # Safety
    ///
    /// Nws yog li ib tus neeg hu rau guarantee hais tias tus `MaybeUninit<T>` tiag tiag yog nyob rau hauv ib tug initialized lub xeev.Hu no thaum lub ntsiab lus yog tsis tau tag nrho initialized ua tam sim ntawd undefined tus cwj pwm.
    /// Lub [type-level documentation][inv] muaj cov ntaub ntawv ntxiv ntsig txog qhov pib ntawm qhov tsis tseem ceeb.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Nyob rau sab saum toj ntawm uas, nco ntsoov tias feem ntau hom muaj ntxiv invariants tshaj tsuas xam tau tias yog initialized ntawm lub hom theem.
    /// Piv txwv li, ib tug '1`-initialized [`Vec<T>`] yog suav tias yog initialized (nyob rau hauv lub tam sim no siv; qhov no tsis roos ib tug ruaj khov guarantee) vim hais tias cov tsuas yuav tsum tau cov compiler paub txog nws yog tias cov ntaub ntawv pointer yuav tsum uas tsis yog-thov.
    ///
    /// Tsim xws li ib tug `Vec<T>` tsis ua *tam sim ntawd* undefined tus cwj pwm, tab sis yuav ua rau undefined tus cwj pwm nrog rau feem ntau muaj kev ruaj ntseg ua hauj lwm (xws li xa me nyuam rov nws).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Yog pab ntawm no txoj kev:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *Tsis raug* kev siv ntawm hom no:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` twb tsis tau initialized tsis tau, yog li no kawg kab tshwm sim los undefined tus cwj pwm.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // KEV RUAJ NTSEG: tus hu yuav tsum lav tias `self` yog kev pib.
        // Qhov no kuj txhais tau tias `self` yuav tsum muaj ib `value` variant.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Nyeem tus nqi los ntawm lub `MaybeUninit<T>` thawv.Qhov tshwm sim `T` yog kev rau ib txwm poob poob.
    ///
    /// Thaum twg ua tau, nws yog preferable siv [`assume_init`] xwb, uas tiv thaiv duplicating cov ntsiab lus ntawm cov `MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// Nws yog li ib tus neeg hu rau guarantee hais tias tus `MaybeUninit<T>` tiag tiag yog nyob rau hauv ib tug initialized lub xeev.Hu rau qhov no thaum cov ntsiab lus tseem tsis tau pib siab ua rau muaj tus cwj pwm tsis paub qhov tseeb.
    /// Lub [type-level documentation][inv] muaj cov ntaub ntawv ntxiv ntsig txog qhov pib ntawm qhov tsis tseem ceeb.
    ///
    /// Ntxiv mus, qhov no nplooj ib daim qauv ntawm cov tib cov ntaub ntawv tom qab nyob rau hauv lub `MaybeUninit<T>`.
    /// Thaum uas siv cov ntau cov ntawv luam ntawm cov ntaub ntawv (los ntawm kev hu mus rau `assume_init_read` ntau lub sij hawm, los yog thawj hu `assume_init_read` thiab ces [`assume_init`]), nws yog koj lub luag hauj lwm los xyuas kom meej tias cov ntaub ntawv tej zaum yuav tseeb yuav duplicated.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Yog pab ntawm no txoj kev:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` yog `Copy`, li ntawd, tej zaum peb yuav nyeem ntau lub sij hawm.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Ua li ntawv `None` tus nqi tsis zoo, yog li peb yuav nyeem ntau zaug.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *Tsis raug* kev siv ntawm hom no:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Tam sim no peb tsim ob daim qauv ntawm tib vector, ua rau ob leeg tsis pub dhau ⚠️ thaum nkawd ob leeg nqis!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // KEV RUAJ NTSEG: tus hu yuav tsum lav tias `self` yog kev pib.
        // Nyeem los ntawm `self.as_ptr()` muaj kev ruaj ntseg vim `self` yuav tsum tau initialized.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Ncos tus nqi muaj nyob hauv qhov chaw.
    ///
    /// Yog hais tias koj muaj cov tswv cuab ntawm lub `MaybeUninit`, koj muaj peev xwm siv [`assume_init`] xwb.
    ///
    /// # Safety
    ///
    /// Nws yog li ib tus neeg hu rau guarantee hais tias tus `MaybeUninit<T>` tiag tiag yog nyob rau hauv ib tug initialized lub xeev.Hu rau qhov no thaum cov ntsiab lus tseem tsis tau pib siab ua rau muaj tus cwj pwm tsis paub qhov tseeb.
    ///
    /// Nyob rau sab saum toj ntawm uas, tag nrho cov ntxiv invariants ntawm lub hom `T` yuav tsum tau txaus siab, raws li cov `Drop` kev siv ntawm `T` (los yog nws cov tswv cuab) tej zaum yuav tau cia siab rau qhov no.
    /// Piv txwv li, ib tug '1`-initialized [`Vec<T>`] yog suav tias yog initialized (nyob rau hauv lub tam sim no siv; qhov no tsis roos ib tug ruaj khov guarantee) vim hais tias cov tsuas yuav tsum tau cov compiler paub txog nws yog tias cov ntaub ntawv pointer yuav tsum uas tsis yog-thov.
    ///
    /// Tee xws li `Vec<T>` txawm li cas los xij yuav ua rau tus cwj pwm tsis paub tseeb.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // KEV RUAJ NTSEG: tus neeg hu yuav tsum lees tias `self` yog initialized thiab
        // txaus siab rau txhua tus neeg xa khoom ntawm `T`.
        // Xa me nyuam rov cov nqi nyob rau hauv qhov chaw muaj kev ruaj ntseg yog hais tias yog cov ntaub ntawv.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Tau ib tug sib kev siv rau tus muaj nqi.
    ///
    /// Qhov no tuaj yeem pab tau thaum peb xav nkag mus rau `MaybeUninit` uas tau pib tab sis tsis muaj tswv cuab ntawm `MaybeUninit` (tiv thaiv kev siv `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Hu no thaum lub ntsiab lus yog tsis tau tag nrho initialized ua undefined tus cwj pwm: nws yog li ib tus neeg hu rau guarantee hais tias tus `MaybeUninit<T>` tiag tiag yog nyob rau hauv ib tug initialized lub xeev.
    ///
    ///
    /// # Examples
    ///
    /// ### Yog pab ntawm no txoj kev:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Initialize `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Tam sim no hais tias peb `MaybeUninit<_>` yog paub tias yuav tsum initialized, nws yog li cas los mus tsim ib tug sib reference rau nws:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // KEV RUAJ NTSEG: `x` tau initialized.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *Tsis raug* siv cov qauv no:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Peb tau tsim ib tug siv rau ib tug uninitialized vector!Qhov no yog undefined tus cwj pwm.️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Initialize lub `MaybeUninit` siv `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Xa mus rau uninitialized `Cell<bool>`: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // KEV RUAJ NTSEG: tus hu yuav tsum lav tias `self` yog kev pib.
        // Qhov no kuj txhais tau tias `self` yuav tsum muaj ib `value` variant.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Tau ib tug mutable (unique) kev siv rau tus muaj nqi.
    ///
    /// Qhov no tuaj yeem pab tau thaum peb xav nkag mus rau `MaybeUninit` uas tau pib tab sis tsis muaj tswv cuab ntawm `MaybeUninit` (tiv thaiv kev siv `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Hu no thaum lub ntsiab lus yog tsis tau tag nrho initialized ua undefined tus cwj pwm: nws yog li ib tus neeg hu rau guarantee hais tias tus `MaybeUninit<T>` tiag tiag yog nyob rau hauv ib tug initialized lub xeev.
    /// Piv txwv li, `.assume_init_mut()` tsis tuaj yeem siv los pib tus `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### Yog pab ntawm no txoj kev:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Pib *tag nrho* lub bytes ntawm lub tswv yim tsis.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Pib `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Tam sim no peb paub tias `buf` tau initialized, li ntawd, peb yuav `.assume_init()` nws.
    /// // Txawm li cas los, siv `.assume_init()` tej zaum yuav ua ib tug `memcpy` ntawm lub 2048 bytes.
    /// // Vajhuam peb tsis tau initialized tsis muaj kev luam, peb txawj tej yam ntxiv cov `&mut MaybeUninit<[u8; 2048]>` mus rau ib tug `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // KEV RUAJ NTSEG: `buf` tau initialized.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Tam sim no peb muaj peev xwm siv `buf` raws li ib tug qub hlais:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *Tsis raug* siv cov qauv no:
    ///
    /// Koj tsis tuaj yeem siv `.assume_init_mut()` los pib tus nqi:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Peb tau tsim ib tug (mutable) siv rau ib tug uninitialized `bool`!
    ///     // Nov yog kev coj tsis tus.️
    /// }
    /// ```
    ///
    /// Piv txwv li, koj yuav tsis [`Read`] rau hauv ib qho uninitialized tsis:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) siv rau uninitialized nco!
    ///                             // Qhov no yog undefined tus cwj pwm.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Tsis yog koj siv tsis tau daim ntawv tso cai ncaj qha nkag teb mus rau cov chaw ua teb ib pob zuj zus:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) siv rau uninitialized nco!
    ///                  // Qhov no yog undefined tus cwj pwm.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) siv rau uninitialized nco!
    ///                  // Qhov no yog undefined tus cwj pwm.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Peb tam sim no vam khom rau tus saum toj no ua tsis yog, piv txwv li, peb muaj neeg ua tim khawv rau uninitialized ntaub ntawv (xws li, nyob rau hauv `libcore/fmt/float.rs`).
    // Peb yuav tsum tau ua ib tug txiav txim zaum kawg hais txog cov kev cai ua ntej stabilization.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // KEV RUAJ NTSEG: tus hu yuav tsum lav tias `self` yog kev pib.
        // Qhov no kuj txhais tau tias `self` yuav tsum muaj ib `value` variant.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Cia lub qhov tseem ceeb los ntawm ib tug array ntawm `MaybeUninit` ntim.
    ///
    /// # Safety
    ///
    /// Nws yog li ib tus neeg hu rau guarantee hais tias tag nrho cov ntsiab ntawm cov array yog nyob rau hauv ib tug initialized lub xeev.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // KEV RUAJ NTSEG: Tam sim no muaj kev ruaj ntseg raws li peb initialised tag nrho cov ntsiab
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Cov neeg hu tuaj lees tias txhua yam ntawm kev ntsuas tau pib
        // * `MaybeUninit<T>` thiab T yog guaranteed muaj tib lub layout
        // * MaybeUnint tsis poob, yog li ntawd muaj tsis muaj double-frees Thiab yog li cov hloov dua siab tshiab yog muaj kev ruaj ntseg
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Piv txwv tias yog tag nrho cov ntsiab yog initialized, tau txais ib daim rau lawv.
    ///
    /// # Safety
    ///
    /// Nws yog li ib tus neeg hu yuav lav tsis tau hais tias cov `MaybeUninit<T>` ntsiab tiag tiag yog nyob rau hauv ib tug initialized lub xeev.
    ///
    /// Hu rau qhov no thaum cov ntsiab lus tseem tsis tau pib siab ua rau muaj tus cwj pwm tsis paub qhov tseeb.
    ///
    /// Saib [`assume_init_ref`] kom paub meej ntxiv thiab cov piv txwv.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // KEV RUAJ NTSEG: casting hlais mus rau ib tug `*const [T]` muaj kev ruaj ntseg vim hais tias cov neeg hu guarantees uas
        // `slice` yog initialized, and`MaybeUninit` yog guaranteed muaj tib layout li `T`.
        // Lub pointer tau yog siv tau txij li thaum nws yog hais txog nco uas los ntawm `slice` uas yog ib tug siv thiab yog li guaranteed yuav siv tau rau nyeem.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Piv txwv tias tag nrho cov khoom tau pib ua ntej, tau txais qhov sib txuam sib luag rau lawv.
    ///
    /// # Safety
    ///
    /// Nws yog li ib tus neeg hu yuav lav tsis tau hais tias cov `MaybeUninit<T>` ntsiab tiag tiag yog nyob rau hauv ib tug initialized lub xeev.
    ///
    /// Hu rau qhov no thaum cov ntsiab lus tseem tsis tau pib siab ua rau muaj tus cwj pwm tsis paub qhov tseeb.
    ///
    /// Saib [`assume_init_mut`] kom paub meej ntxiv thiab cov piv txwv.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // KEV RUAJ NTSEG: zoo ib yam li kev nyab xeeb sau ntawv rau `slice_get_ref`, tiam sis peb muaj ib tug
        // hloov siv tau uas tseem tuaj yeem lav tias siv tau rau cov ntawv sau.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Tau ib tug pointer mus rau tus thawj lub caij ntawm lub array.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Tau ib tug mutable pointer mus rau tus thawj lub caij ntawm lub array.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Luam tawm cov ntsiab lus los ntawm `src` rau `this`, rov qab los ua lwm qhov kev hloov pauv rau cov ntsiab lus tam sim no ntawm `this`.
    ///
    /// Yog hais tias `T` tsis siv `Copy`, siv [`write_slice_cloned`]
    ///
    /// Qhov no yog zoo xws li cov [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Txoj haujlwm no yuav panic yog tias ob lub ncuav nyias nyias nyias ntev.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // KEV RUAJ NTSEG: peb nyuam qhuav tau theej tag nrho cov ntsiab ntawm len mus rau hauv lub spare muaj peev xwm
    /// // thawj src.len() ntsiab ntawm lub vec yog siv tau tam sim no.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // KEV RUAJ NTSEG: &[T] thiab&[MaybeUninit<T>] muaj cov qauv tib yam
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // KEV RUAJ NTSEG: Siv ntsiab tau cia li tau theej rau hauv `this` li ntawd nws yog initalized
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Clones lub ntsiab los ntawm `src` rau `this`, rov qab ib tug mutable siv rau qhov tam sim no initalized txheem ntawm `this`.
    /// Cov twb initalized ntsiab yuav tsis tsum poob.
    ///
    /// Yog `T` ua raws `Copy`, siv [`write_slice`]
    ///
    /// Qhov no yog zoo xws li cov [`slice::clone_from_slice`] tab sis tsis poob uas twb muaj lawm hais.
    ///
    /// # Panics
    ///
    /// Txoj haujlwm no yuav panic yog tias ob lub hlais nyias muaj nyias qhov ntev, lossis yog siv ntawm `Clone` panics.
    ///
    /// Yog tias muaj panic, qhov tseem ceeb twb tau muab tso cia.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // KEV RUAJ NTSEG: peb tsuas yog cloned tag nrho cov ntsiab ntawm len rau hauv lub peev xwm spare
    /// // thawj src.len() ntsiab ntawm lub vec yog siv tau tam sim no.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // Tsis zoo li copy_from_slice qhov no tsis hu clone_from_slice ntawm daim hlais qhov no vim tias `MaybeUninit<T: Clone>` tsis siv Clone.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // KEV RUAJ NTSEG: no nyoos hlais yuav muaj tsuas initialized khoom
                // yog vim li cas, nws yog tau tso cai rau poob nws.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Peb yuav tsum ntsees hlais lawv mus rau lub tib ntev
        // rau ciam teb xyuas yuav tsum tau elided, thiab cov optimizer yuav tsim memcpy rau tej yam yooj yim tus neeg mob (piv txwv li T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // khwb uas yuav tsum tau b/c panic yuav tshwm sim thaum lub sij hawm ib tug clone
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // KEV RUAJ NTSEG: Siv ntsiab tau cia li tau sau rau hauv `this` li ntawd nws yog initalized
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}