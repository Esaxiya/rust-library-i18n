use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Ib tug wrapper rau inhibit compiler los ntawm txiav hu 'T` tus destructor.
/// Qhov no wrapper yog 0-nqi.
///
/// `ManuallyDrop<T>` yog kev kawm mus rau tib layout optimizations li `T`.
/// Raws li ib tug tsim nyog tau, nws muaj *tsis ntxim* nyob rau hauv kev xav hais tias cov compiler ua hais txog nws cov txheem.
/// Piv txwv li, initializing ib `ManuallyDrop<&mut T>` nrog [`mem::zeroed`] yog undefined tus cwj pwm.
/// Yog hais tias koj xav tau lis uninitialized cov ntaub ntawv, siv [`MaybeUninit<T>`] xwb.
///
/// Nco ntsoov tias tus txheejtxheem tus nqi hauv ib `ManuallyDrop<T>` muaj kev ruaj ntseg.
/// Qhov no txhais tau hais tias ib tug `ManuallyDrop<T>` uas nws cov ntsiab lus tau tau poob yuav tsum tsis txhob yuav tsum tau raug los ntawm ib tug pej xeem muaj kev ruaj ntseg API.
/// Correspondingly, `ManuallyDrop::drop` yog tsis zoo.
///
/// # `ManuallyDrop` thiab poob kev txiav txim.
///
/// Rust muaj ib tug zoo-txhais [drop order] ntawm qhov tseem ceeb.
/// Txhawm rau kom paub tseeb tias thaj teb lossis cov chaw hauv ib cheeb tsam raug tso rau hauv ib qho kev txiav txim tshwj xeeb, kho cov lus tshaj tawm tias qhov kev txiav txim siab poob yog qhov tseeb.
///
/// Nws yog qhov tsim nyog los siv `ManuallyDrop` los tswj cov kev txiav txim siab poob, tab sis qhov no yuav tsum muaj txoj cai tsis nyab xeeb thiab nyuaj ua qhov yog nyob rau ntawm qhov tsis pom zoo.
///
///
/// Piv txwv li, yog tias koj xav kom paub tseeb tias ib tug kev teb no yog poob tom qab lwm tus, ua rau nws lub xeem teb ntawm ib tug struct:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` yuav tsum poob tom qab `children`.
///     // Rust guarantees uas tau teb cov poob nyob rau hauv qhov kev txiav txim ntawm kev tshaj tawm.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Qhwv ib tug nqi yuav tsum tau manually poob.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Koj tseem tuaj yeem ua kom nyab xeeb ntawm tus nqi
    /// assert_eq!(*x, "Hello");
    /// // Tab sis `Drop` yuav tsis tau khiav ntawm no
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Cia tus nqi los ntawm lub `ManuallyDrop` thawv.
    ///
    /// Qhov no tso cai rau tus nqi kom poob dua.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Cov tshuaj no poob rau `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Yuav siv sij hawm tus nqi ntawm lub `ManuallyDrop<T>` thawv tawm.
    ///
    /// Qhov no yog feem ntau npaj kev tsiv tawm qhov tseem ceeb nyob rau hauv nco.
    /// Hloov ntawm kev siv [`ManuallyDrop::drop`] los sau tus nqi poob, koj tuaj yeem siv tus qauv no coj tus nqi thiab siv nws txawm li cas los xav.
    ///
    /// Thaum twg ua tau, nws yog preferable siv [`into_inner`][`ManuallyDrop::into_inner`] xwb, uas tiv thaiv duplicating cov ntsiab lus ntawm cov `ManuallyDrop<T>`.
    ///
    ///
    /// # Safety
    ///
    /// Qhov no muaj nuj nqi semantically tsiv tawm lub muaj nqi yam tsis muaj kev tiv thaiv ntxiv pab, tawm hauv lub xeev ntawm no lub thawv unchanged.
    /// Nws yog koj lub luag hauj lwm los xyuas kom meej tias qhov no `ManuallyDrop` yog tsis siv dua.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // KEV RUAJ NTSEG: peb nyeem los ntawm ib tug siv, uas yog guaranteed
        // yuav siv tau rau nyeem.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Manually dauv cov muaj nqi.Qhov no yog raws nraim sib npaug rau hu [`ptr::drop_in_place`] nrog ib tug pointer mus rau lub muaj nqi.
    /// Raws li xws li, tshwj tsis yog tias lub muaj nqi yog ib tug packed struct, lub destructor yuav tsum tau hu ua nyob rau hauv-chaw tsis muaj mus rau tus nqi, thiab yog li yuav siv tau los yam xyuam xim poob [pinned] cov ntaub ntawv.
    ///
    /// Yog hais tias koj muaj cov tswv cuab ntawm cov nqi, koj yuav tau siv [`ManuallyDrop::into_inner`] xwb.
    ///
    /// # Safety
    ///
    /// Txoj haujlwm no sau lub destructor ntawm tus nqi uas muaj.
    /// Lwm yam tshaj kev hloov los ntawm lub destructor nws tus kheej, lub cim xeeb yog tshuav unchanged, thiab thiaj li deb raws li cov compiler yog kev txhawj xeeb tseem tuas ib tug me ntsis-qauv uas yog siv tau rau lub hom `T`.
    ///
    ///
    /// Txawm li cas los xij, tus nqi "zombie" no yuav tsum tsis txhob nthuav tawm txoj kev nyab xeeb, thiab txoj haujlwm no yuav tsum tsis txhob hu ntau dua ib zaug.
    /// Yuav kom siv tau ib tus nqi tom qab nws tau poob, los yog poob ib tug nqi ntau lub sij hawm, yuav ua rau undefined cwj pwm (nyob ntawm seb dab tsi `drop` puas).
    /// Qhov no yog feem ntau tiv thaiv los ntawm lub hom system, tab sis cov neeg siv ntawm `ManuallyDrop` yuav tsum tau uphold cov guarantees tsis muaj kev pab los ntawm lub compiler.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // KEV RUAJ NTSEG: peb yog xa me nyuam rov cov nqi taw mus rau los ntawm ib tug mutable siv
        // uas yuav lav yuav tsum siv tau rau sau.
        // Nws yog li ib tus neeg hu kom paub tseeb tias `slot` yog tsis poob dua.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}