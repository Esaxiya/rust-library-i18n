//! Cov haujlwm yooj yim rau kev ua haujlwm nrog kev nco.
//!
//! Qhov no module muaj zog rau querying qhov luaj li cas thiab kawm tuab si lug ntawm hom, initializing thiab manipulating nco.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Yuav siv tswv cuab thiab "forgets" txog tus nqi **tsis tau khiav nws lub destructor**.
///
/// Ib qho kev pab twg tus nqi tswj hwm, xws li heap nco los yog cov ntaub ntawv tuav, yuav nyob tas mus li hauv ib lub xeev uas tsis cuag.Txawm li cas los xij, nws tsis lees tias cov lus taw qhia rau txoj kev nco no yuav siv tau.
///
/// * Yog hais tias koj xav mus paim quav nco, saib [`Box::leak`].
/// * Yog hais tias koj xav kom tau ib tug nyoos pointer rau lub cim xeeb, saib [`Box::into_raw`].
/// * Yog hais tias koj xav mus pov tseg ntawm ib tug nqi kom zoo, khiav nws destructor, saib [`mem::drop`].
///
/// # Safety
///
/// `forget` yog tsis cim raws li `unsafe`, vim hais tias Rust txoj kev nyab xeeb guarantees tsis muaj xws li ib tug guarantee hais tias destructors yuav yeej ib txwm khiav.
/// Piv txwv, ib qho kev zov me nyuam tuaj yeem tsim qhov kev siv caij nyoog siv [`Rc`][rc], lossis hu [`process::exit`][exit] tawm kom tsis muaj kev cuam tshuam kev cuam tshuam.
/// Yog li, tso cai `mem::forget` los ntawm kev ruaj ntseg code tsis hloov pauv hloov Rust kev tiv thaiv kev nyab xeeb.
///
/// Ntawd tau hais tias, to cov khoom siv xws li nco lossis I/O khoom yog feem ntau tsis xav tau.
/// Qhov xav tau los ntawm qee kis tshwj xeeb siv rau FFI lossis kev cai tsis raug cai, tab sis txawm li ntawd los, [`ManuallyDrop`] feem ntau nyiam.
///
/// Vim hais tias tsis nco qab ib tug nqi yog tso cai, tej `unsafe` code koj sau yuav tsum tau cia rau qhov no tau.Koj tsis tuaj yeem rov qab tus nqi thiab cia siab tias tus neeg hu tuaj yuav tsum khiav tus nqi destructor.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// Txoj kev siv lub `mem::forget` kev nyab xeeb yog kom dhau tus nqi ntawm lub neej puas tsuaj los ntawm `Drop` trait.Piv txwv li, qhov no yuav paim quav ib `File`, piv txwv li
/// reclaim qhov chaw coj los ntawm cov kuj tsis paub meej tiam sis yeej tsis nyob ze rau lwm system pab:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Qhov no yog qhov muaj txiaj ntsig thaum qhov ua tswv ntawm cov peev txheej yav dhau los pauv mus rau qhov chaws sab nraud ntawm Rust, piv txwv los ntawm kev xa cov ntaub ntawv nyoos mus rau C code.
///
/// # Kev sib raug zoo nrog `ManuallyDrop`
///
/// Thaum `mem::forget` kuj yuav siv tau mus rau cov hloov *nco* tswv cuab, ua li ntawd yog kev ua yuam kev-nws.
/// [`ManuallyDrop`] yuav tsum siv dua xwb.Xav txog, piv txwv li, cov cai no:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Tsim kom muaj ib tug `String` siv tus txheem ntawm `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // paim quav `v` vim hais tias nws nco yog tam sim no tswj los ntawm `s`
/// mem::forget(v);  // YUAM KEV, v yog invalid thiab yuav tsum tsis txhob yuav kis mus rau ib tug muaj nuj nqi
/// assert_eq!(s, "Az");
/// // `s` yog implicitly poob thiab nws lub cim xeeb sib cais.
/// ```
///
/// Muaj ob teeb meem nrog rau saum toj no piv txwv:
///
/// * Yog tias muaj cov lej ntau ntxiv nyob nruab nrab ntawm kev tsim kho `String` thiab kev caw `mem::forget()`, ib panic nyob rau hauv nws yuav ua rau muaj ob qho pub dawb vim tias kev nco qab tib leej los ntawm `v` thiab `s`.
/// * Tom qab hu xov tooj `v.as_mut_ptr()` thiab kis cov tswv cuab ntawm cov ntaub ntawv rau `s`, lub `v` nqi yog invalid.
/// Txawm tias thaum twg ib tug nqi yog cia li tsiv mus rau `mem::forget` (uas yuav tsis tshawb xyuas nws), tej yam muaj nruj uas yuav tsum tau nyob rau hauv lawv qhov tseem ceeb uas ua rau lawv invalid thaum dangling los yog tsis muaj.
/// Siv cov txiaj ntsig tsis raug nyob rau txhua txoj kev, suav nrog kev dhau mus rau los yog rov qab los ntawm kev ua haujlwm, suav ua tus cwj pwm tsis tau txiav txim siab thiab yuav rhuav cov kev xav tau los ntawm tus sau
///
/// Hloov mus rau `ManuallyDrop` zam ob qho teeb meem:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Ua ntej peb yuav lauj `v` rau hauv nws cov nqaij nyoos qhov chaw, nco ntsoov nws tsis tau poob!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Tam sim no disassemble `v`.Cov haujlwm no tsis tuaj yeem panic, yog li tsis muaj dej xau.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Thaum kawg, tsim kom muaj `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` yog implicitly poob thiab nws lub cim xeeb sib cais.
/// ```
///
/// `ManuallyDrop` robustly tiv thaiv ob-dawb vim tias peb xiam `v` lub destructor ua ntej ua lwm yam.
/// `mem::forget()` tsis tso cai qhov no vim tias nws noj nws qhov kev sib cav, yuam peb hu nws tsuas yog tom qab rho txhua yam peb xav tau ntawm `v`.
/// Txawm hais tias panic tau qhia nruab nrab ntawm kev tsim kho `ManuallyDrop` thiab txhim kho txoj hlua (uas tsis tuaj yeem tshwm sim nyob rau hauv txoj cai raws li qhia), nws yuav ua rau xau thiab tsis pub dawb ob npaug.
/// Hauv lwm lo lus, `ManuallyDrop` errs nyob rau sab ntawm xau kom tsis txhob ua txhaum ntawm sab ntawm (ob--poob).
///
/// Tsis tas li, `ManuallyDrop` txwv tsis pub peb muaj "touch" `v` tom qab hloov cov tswv cuab rau `s`-kauj ruam kawg ntawm kev sib tham nrog `v` rau pov tseg ntawm nws yam tsis tau khiav nws destructor yog zam tag nrho.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Zoo li [`forget`], tab sis kuj lees txais qhov tsis muaj nuj nqis.
///
/// Txoj haujlwm no tsuas yog lub ntsej muag lub ntsej muag uas yuav tsum tau muab tshem tawm thaum lub `unsized_locals` qhov nta tau ruaj khov.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Rov qab los qhov loj me ntawm ib hom hauv bytes.
///
/// Tshwj xeeb tshaj yog, qhov no yog qhov offset hauv bytes ntawm cov ntsiab lus tom hauv ntu uas muaj yam khoom ntawd suav nrog kev sib xyaw padding.
///
/// Yog li, rau ib hom `T` thiab ntev `n`, `[T; n]` muaj qhov loj me ntawm `n * size_of::<T>()`.
///
/// Feem ntau, qhov loj me ntawm ib hom yog tsis ruaj khov nyob rau hauv kev suav sau, tab sis qee yam tshwj xeeb xws li cov thawj.
///
/// Cov lus hauv qab no muab qhov loj me rau cov thawj.
///
/// Hom |size_of: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 char |4
///
/// Txuas ntxiv mus, `usize` thiab `isize` muaj qhov loj tib yam.
///
/// Cov hom `*const T`, `&T`, `Box<T>`, `Option<&T>`, thiab `Option<Box<T>>` txhua qhov loj tib yam.
/// Yog tias `T` yog Sized, txhua yam ntawm cov ntawd muaj qhov loj me tib yam li `usize`.
///
/// Qhov hloov pauv ntawm tus pointer tsis hloov nws loj.Xws li, `&T` thiab `&mut T` muaj qhov loj me tib yam.
/// Ib yam li ntawd rau `*const T` thiab `* mut T`.
///
/// # Loj ntawm `#[repr(C)]` khoom
///
/// Tus sawv cev `C` rau cov khoom muaj cov qauv piav qhia.
/// Nrog rau cov kab ntawv no, qhov loj me ntawm cov khoom kuj tseem ruaj khov ntev li txhua daim teb muaj qhov kom ruaj khov.
///
/// ## Qhov loj me ntawm Cov Qauv
///
/// Rau `structs`, qhov loj yog txiav txim siab los ntawm cov algorithm hauv qab no.
///
/// Rau txhua daim teb hauv tus txheej txheem xaj los ntawm kev tshaj tawm xaj:
///
/// 1. Ntxiv qhov loj me me ntawm lub tshav pob.
/// 2. Sau rau tam sim no qhov loj me kom ze rau ntau qhov chaw tom ntej ntawm [alignment].
///
/// Thaum kawg, muab qhov loj me ntawm kev teeb tsa mus rau qhov ze nws ntau nws [alignment].
/// Kev sib thooj ntawm txoj kev teeb tsa feem ntau yog qhov loj tshaj plaws kev teeb tsa ntawm tag nrho nws cov liaj;qhov no tuaj yeem hloov nrog kev siv `repr(align(N))`.
///
/// Tsis zoo li `C`, xoom cov khoom siv me me tsis sib npaug li ib byte hauv qhov loj me.
///
/// ## Qhov loj me ntawm Enums
///
/// Cov chaw tos uas tsis muaj cov ntaub ntawv tshaj li qhov kev sib cais muaj qhov loj tib yam nkaus li C enums ntawm lub platform uas lawv tau suav ua.
///
/// ## Qhov luaj li cas ntawm Kev Sib Koom
///
/// Qhov loj ntawm ib lub koomhaum yog qhov loj ntawm nws daim teb loj tshaj plaws.
///
/// Tsis zoo li `C`, cov koomhaum xoom tsis muaj txog li ib qho byte hauv loj.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Qee cov qauv
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Qee tus arrays
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Pointer loj koob pheej ntawm lawv
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Siv `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Qhov luaj li cas ntawm cov thawj teb yog 1, yog li ntxiv 1 mus rau qhov luaj li cas.Loj yog 1.
/// // Cov kawm tuab si lug ntawm lub thib ob teb yog 2, yog li ntxiv 1 mus rau qhov luaj li cas rau padding.Loj yog 2.
/// // Qhov loj ntawm daim teb thib ob yog 2, yog li ntxiv 2 rau qhov loj me.Qhov loj me yog 4.
/// // Qhov sib cais ntawm peb daim teb yog 1, yog li ntxiv 0 rau qhov loj me rau padding.Loj yog 4.
/// // Qhov loj ntawm daim teb peb yog 1, yog li ntxiv 1 rau qhov loj.Loj yog 5.
/// // Thaum kawg, cov kawm tuab si lug ntawm lub struct yog 2 (vim hais tias cov coob kawm tuab si lug nrad nws teb yog 2), li ntawd, ntxiv 1 mus rau qhov luaj li cas rau padding.
/// // Loj yog 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Tuple cov qauv ua raws tib cov cai.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Nco ntsoov tias reordering lub teb yuav txo qhov luaj li cas.
/// // Peb tuaj yeem tshem ob qho padding bytes los ntawm kev muab `third` ua ntej `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Union loj yog qhov loj ntawm daim teb ntau tshaj plaws.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Rov qab los qhov loj me ntawm qhov taw qhia-mus rau tus nqi hauv bytes.
///
/// Qhov no feem ntau yog tib yam li `size_of::<T>()`.
/// Txawm li cas los xij, thaum `T`*muaj* tsis muaj qhov paub txog qhov loj me, piv txwv li, hlais [`[T]`][slice] lossis [trait object], ces `size_of_val` tuaj yeem siv kom tau txais qhov loj-paub qhov loj me.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // KEV RUAJ NTSEG: `val` yog qhov siv, yog li nws siv tau lub pointer raw khoom
    unsafe { intrinsics::size_of_val(val) }
}

/// Rov qab los qhov loj me ntawm qhov taw qhia-mus rau tus nqi hauv bytes.
///
/// Qhov no feem ntau yog tib yam li `size_of::<T>()`.Txawm li cas los xij, thaum `T`*muaj* tsis muaj qhov paub txog qhov loj me, piv txwv li, hlais [`[T]`][slice] lossis [trait object], tom qab ntawd `size_of_val_raw` tuaj yeem siv kom tau txais qhov loj-paub qhov loj me.
///
/// # Safety
///
/// Txoj haujlwm no tsuas muaj kev ruaj ntseg hu yog tias cov xwm txheej hauv qab no tuav:
///
/// - Yog `T` yog `Sized`, txoj haujlwm no ib txwm muaj kev nyab xeeb hu.
/// - Yog tias tus Tsov tus tw ntawm `T` yog:
///     - ib [slice], tom qab ntawd qhov ntev ntawm cov hlais tsaj yuav tsum yog tus pib sib ntxiv, thiab qhov loj ntawm *tag nrho tus nqi*(dynamic tw ntev + raws li qhov loj me sau ua ntej) yuav tsum haum hauv `isize`.
///     - ib qho [trait object], tom qab ntawd lub vtable ntawm tus pointer yuav tsum taw mus rau lub vtable siv tau los ntawm kev ntsuas tsis tau, thiab qhov loj ntawm *tag nrho tus nqi*(dynamic tw ntev + qhov tshwj xeeb ua ntej sau ua ntej) yuav tsum haum hauv `isize`.
///
///     - ib qho (unstable) [extern type], tom qab ntawd txoj haujlwm no ib txwm muaj kev nyab xeeb hu, tab sis tej zaum panic lossis lwm yam rov qab mus rau tus nqi tsis raug, vim hais tias dhau ntawm hom txheej txheem tsis paub.
///     Qhov no yog tus cwj pwm zoo ib yam li [`size_of_val`] ntawm kev siv rau ib hom nrog tus qauv txawv tus Tsov tus tw.
///     - txwv tsis pub, nws yog conservatively tsis tso cai rau qhov no hu ua muaj nuj nqi.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // KEV RUAJ NTSEG: tus hu yuav tsum tau muab lub xov tooj siv raws li kev cai
    unsafe { intrinsics::size_of_val(val) }
}

/// Rov qab tau [ABI]-toom thaiv cov yam ntxwv tsawg kawg ntawm ib hom.
///
/// Txhua qhov siv rau tus nqi ntawm hom `T` yuav tsum yog ntau ntawm tus lej no.
///
/// Nov yog qhov sib ncag siv rau cov qauv liaj teb.Tej zaum nws yuav me dua qhov ua kom haum.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Rov qab tau [ABI]-toom thaiv cov kab ntawv yam tsawg kawg ntawm hom ntawm tus nqi uas `val` taw rau.
///
/// Txhua qhov siv rau tus nqi ntawm hom `T` yuav tsum yog ntau ntawm tus lej no.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // KEV RUAJ NTSEG: val yog siv, yog li nws siv tau lub pointer raw khoom
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Rov qab tau [ABI]-toom thaiv cov yam ntxwv tsawg kawg ntawm ib hom.
///
/// Txhua qhov siv rau tus nqi ntawm hom `T` yuav tsum yog ntau ntawm tus lej no.
///
/// Nov yog qhov sib ncag siv rau cov qauv liaj teb.Tej zaum nws yuav me dua qhov ua kom haum.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Rov qab tau [ABI]-toom thaiv cov kab ntawv yam tsawg kawg ntawm hom ntawm tus nqi uas `val` taw rau.
///
/// Txhua qhov siv rau tus nqi ntawm hom `T` yuav tsum yog ntau ntawm tus lej no.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // KEV RUAJ NTSEG: val yog siv, yog li nws siv tau lub pointer raw khoom
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Rov qab tau [ABI]-toom thaiv cov kab ntawv yam tsawg kawg ntawm hom ntawm tus nqi uas `val` taw rau.
///
/// Txhua qhov siv rau tus nqi ntawm hom `T` yuav tsum yog ntau ntawm tus lej no.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Txoj haujlwm no tsuas muaj kev ruaj ntseg hu yog tias cov xwm txheej hauv qab no tuav:
///
/// - Yog `T` yog `Sized`, txoj haujlwm no ib txwm muaj kev nyab xeeb hu.
/// - Yog tias tus Tsov tus tw ntawm `T` yog:
///     - ib [slice], tom qab ntawd qhov ntev ntawm cov hlais tsaj yuav tsum yog tus pib sib ntxiv, thiab qhov loj ntawm *tag nrho tus nqi*(dynamic tw ntev + raws li qhov loj me sau ua ntej) yuav tsum haum hauv `isize`.
///     - ib qho [trait object], tom qab ntawd lub vtable ntawm tus pointer yuav tsum taw mus rau lub vtable siv tau los ntawm kev ntsuas tsis tau, thiab qhov loj ntawm *tag nrho tus nqi*(dynamic tw ntev + qhov tshwj xeeb ua ntej sau ua ntej) yuav tsum haum hauv `isize`.
///
///     - ib qho (unstable) [extern type], tom qab ntawd txoj haujlwm no ib txwm muaj kev nyab xeeb hu, tab sis tej zaum panic lossis lwm yam rov qab mus rau tus nqi tsis raug, vim hais tias dhau ntawm hom txheej txheem tsis paub.
///     Qhov no yog tus cwj pwm zoo ib yam li [`align_of_val`] ntawm kev siv rau ib hom nrog tus qauv txawv tus Tsov tus tw.
///     - txwv tsis pub, nws yog conservatively tsis tso cai rau qhov no hu ua muaj nuj nqi.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // KEV RUAJ NTSEG: tus hu yuav tsum tau muab lub xov tooj siv raws li kev cai
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Rov qab `true` yog tias poob cov nqi ntawm hom `T` teeb meem.
///
/// Qhov no yog qhov qhia tau qhov tseeb rau lub siab dawb, thiab tej zaum yuav tau ua kev siv txhag cia:
/// nws yuav rov `true` rau cov hom uas tsis tshua xav tau poob.
/// Xws li ib txwm rov los `true` yuav yog qhov siv tau ntawm lub luag haujlwm no.Txawm li cas los xij yog tias txoj haujlwm no yeej rov `false`, tom qab ntawd koj tuaj yeem ua qee yam xa me nyuam rov `T` tsis muaj kev cuam tshuam dab tsi.
///
/// Qib qib kev siv ntawm yam xws li kev sib sau, uas yuav tsum muab sau lawv cov ntaub ntawv, yuav tsum siv txoj haujlwm no kom tsis txhob ua qhov tsis tas ua rau poob tag nrho lawv cov ntsiab lus thaum lawv rhuav tshem.
///
/// Qhov no tej zaum yuav tsis ua qhov sib txawv ntawm qhov tso tawm tsim (qhov twg lub voj uas tsis muaj cov kev mob tshwm sim yooj yim pom thiab rhuav tshem), tab sis feem ntau yeej loj rau kev ua kom debug.
///
/// Nco ntsoov tias [`drop_in_place`] twb tau ua tiav qhov kev kuaj xyuas no, yog li yog koj qhov haujlwm yuav raug txo kom tsawg rau qee tus lej [`drop_in_place`] hu, siv qhov no tsis tsim nyog.
/// Hauv kev ceeb toom tshwj xeeb uas koj tuaj yeem [`drop_in_place`] ib qho hlais, thiab qhov ntawd yuav ua ib qho kev xav tau_drop kuaj rau txhua qhov tseem ceeb.
///
/// Cov hom zoo li Vec yog li ntawd tsuas yog `drop_in_place(&mut self[..])` tsis tas siv `needs_drop` ntsees.
/// Cov hom zoo li [`HashMap`], ntawm qhov tod tes, yuav tsum poob tus nqi ib qho zuj zus thiab yuav tsum siv tus lej API no.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Ntawm no yog ib qho piv txwv ntawm yuav ua li cas tus sau tuaj yeem siv `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // xa cov ntaub ntawv
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Rov qab cov nqi ntawm hom `T` sawv cev los ntawm tag nrho-xoom byte-qauv.
///
/// Qhov no txhais tau hais tias, piv txwv li, padding byte hauv `(u8, u16)` tsis tas yuav muaj dab tsi.
///
/// Tsis muaj qhov lees tias ib qho-xoom byte-qauv sawv cev tus nqi siv tau ntawm qee hom `T`.
/// Piv txwv li, tag nrho-xoom byte-tus qauv tsis yog tus nqi siv tau rau kev siv hom (`&T`, `&mut T`) thiab cov kev ua haujlwm cov taw qhia.
/// Siv `zeroed` ntawm cov hom zoo ua rau [undefined behavior][ub] tam sim ntawd vim [the Rust compiler assumes][inv] tias muaj ib txwm muaj nuj nqis nyob rau ntawm cov kuj sib txawv thiab nws suav tias yog qhov pib.
///
///
/// Qhov no muaj cov tib yam li [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// Nws pab tau rau FFI qee zaum, tab sis feem ntau yuav tsum zam.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Kev siv txoj cai ntawm txoj haujlwm no: pib kev suav nrog tus lej xoom.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Qhov tsis raug* kev siv ntawm txoj haujlwm no: kev pib siv tus lej nrog xoom.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Tus cwj pwm tsis paub qhov tseeb!
/// let _y: fn() = unsafe { mem::zeroed() }; // Thiab dua!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // KEV RUAJ NTSEG: tus hu yuav tsum lav tias tus lej xoom yog siv tau rau `T`.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Bypasses Rust li qub nco-pib kev kuaj xyuas los ntawm kev ua txuj ua lag luam tus nqi ntawm hom `T`, thaum tsis ua dab tsi hlo li.
///
/// **Qhov haujlwm no tsis pom zoo.** Siv [`MaybeUninit<T>`] hloov.
///
/// Qhov laj thawj ntawm kev tso tawm yog qhov kev ua haujlwm tsis tuaj yeem siv tsis raug: nws muaj cov nyhuv tib yam li [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// Raws li [`assume_init` documentation][assume_init] piav qhia, [the Rust compiler assumes][inv] qhov muaj nuj nqis yog pib ua ntej.
/// Yog li ntawd, hu rau yam li
/// `mem::uninitialized::<bool>()` ua rau muaj kev coj cwj pwm tam sim rau kev xa rov qab `bool` uas tsis yog ib qho `true` lossis `false`.
/// Zuj zus, tiag tiag uninitialized nco zoo li dab tsi tau txais rov qab no yog tshwj xeeb nyob rau hauv uas compiler paub tias nws tsis muaj tus nqi taag.
/// Qhov no ua rau nws tsis muaj cwj pwm tsis txaus los ua cov ntaub ntawv tsis muaj qhov txawv txav hauv ib qho kev hloov pauv txawm tias cov sib txawv ntawd muaj hom sib npaug.
/// (Daim ntawv ceeb toom hais tias cov kev cai nyob ib ncig ntawm uninitialized zauv tsis tiav tsis tau, tab sis mus txog rau thaum lawv yog, nws yog advisable kom tsis txhob rau lawv.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // KEV RUAJ NTSEG: tus hu yuav tsum lav tias tus nqi unitialized siv tau rau `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Swaps qhov muaj nuj nqis ntawm ob qhov chaw tuaj yeem hloov chaw, yam tsis muaj deinitializing ib qho.
///
/// * Yog tias koj xav sib pauv nrog lub neej ntawd lossis cov nqi them txhua hnub, saib [`take`].
/// * Yog tias koj xav pauv nrog tus nqi dhau, rov qab tus nqi qub, saib [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // KEV RUAJ NTSEG: cov ntsiab lus nyoos tau raug tsim los ntawm kev hais tau zoo hloov tau zoo txhua tus
    // xyuas ntawm `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Xyoo `dest` nrog lub neej ntawd tus nqi ntawm `T`, rov qab rau hauv lub yav dhau los `dest` nqi.
///
/// * Yog tias koj xav hloov lub txiaj ntsig ntawm ob tus hloov pauv, saib [`swap`].
/// * Yog tias koj xav hloov nrog tus nqi dhau los hloov tus nqi qub, saib [`replace`].
///
/// # Examples
///
/// Piv txwv uas yooj yim:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` tso cai rau coj tus tswv cuab ntawm ib daim teb los ntawm kev hloov nws nrog tus nqi "empty".
/// Tsis muaj `take` koj tuaj yeem khiav mus rau cov teeb meem zoo li cov no:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Nco ntsoov tias `T` tsis tas siv [`Clone`], yog li nws tsis tuaj yeem txawm clone thiab pib dua `self.buf`.
/// Tab sis `take` tuaj yeem siv los txiav tawm tus nqi qub `self.buf` los ntawm `self`, cia nws rov qab:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Txav `src` rau hauv kev hais txog `dest`, rov qab dhau los `dest` tus nqi.
///
/// Tsis yog tus nqis.
///
/// * Yog tias koj xav hloov lub txiaj ntsig ntawm ob tus hloov pauv, saib [`swap`].
/// * Yog tias koj xav hloov nrog tus nqi qub, saib [`take`].
///
/// # Examples
///
/// Piv txwv uas yooj yim:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` tso cai kev noj haus ntawm ib cheeb tsam muaj los ntawm hloov nws nrog lwm tus nqi.
/// Tsis muaj `replace` koj tuaj yeem khiav mus rau cov teeb meem zoo li cov no:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Nco ntsoov tias `T` tsis tas siv [`Clone`], yog li peb txawm tsis tuaj yeem clone `self.buf[i]` kom tsis txhob muaj qhov txav mus los.
/// Tab sis `replace` tuaj yeem siv los cais tawm tus nqi qub ntawm qhov ntawv txheeb xyuas los ntawm `self`, cia nws rov qab:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // KEV RUAJ NTSEG: Peb nyeem los ntawm `dest` tab sis sau `src` ncaj qha rau nws tom qab,
    // xws tias tus nqi qub tsis tau theej tawm.
    // Tsis muaj dab tsi tau nqis thiab tsis muaj dab tsi ntawm no tuaj yeem panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Pov tseg ntawm tus nqi.
///
/// Qhov no ua li ntawd los ntawm kev hu xov tooj rau kev sib cav cov kev coj ua ntawm [`Drop`][drop].
///
/// Qhov no ua tau tsis muaj dab tsi rau cov hom uas siv `Copy`, yam li cov neeg
/// integers.
/// Cov txiaj ntsig zoo li no tau theej thiab _then_ tsiv mus rau hauv qhov kev ua haujlwm, yog li tus nqi tseem nyiaj tom qab lub luag haujlwm hu no.
///
///
/// Txoj haujlwm no tsis yog khawv koob;nws yog lus txhais raws li
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Vim tias `_x` txav mus rau hauv txoj haujlwm, nws yog qhov txiav nqis ua ntej txoj haujlwm rov los.
///
/// [drop]: Drop
///
/// # Examples
///
/// Kev siv theem pib:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // ntsees poob tus vector
/// ```
///
/// Txij li [`RefCell`] tswj cov cai qiv thaum runtime, `drop` tuaj yeem tso tawm [`RefCell`] qiv:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // relinquish lub mutable qiv rau no qhov
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Cov kab sib xyaw thiab lwm hom kev siv [`Copy`] tsis muaj cuam tshuam los ntawm `drop`.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // daim ntawv luam ntawm `x` tau txav thiab tso tawm
/// drop(y); // ib daim qauv ntawm `y` yog tsiv thiab poob
///
/// println!("x: {}, y: {}", x, y.0); // tseem muaj
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Txhais lus `src` raws li muaj hom `&U`, thiab tom qab ntawd nyeem `src` yam tsis tau tsiv tus nqi.
///
/// Txoj haujlwm no yuav tsis txaus ntseeg tias tus pointer `src` siv tau rau [`size_of::<U>`][size_of] bytes los ntawm transmuting `&T` rau `&U` thiab tom qab ntawd nyeem `&U` (tshwj tsis yog tias qhov no tau ua ib txoj hauv kev uas yog lawm txawm tias `&U` ua rau kev ua raws li kev cai nruj dua `&T`).
/// Nws tseem yuav tsis tsim txoj kev luam ntawm cov ntawv muaj nqis hloov chaw tawm ntawm `src`.
///
/// Nws tsis yog kev ua yuam kev-sijhawm yog `T` thiab `U` muaj ntau qhov sib txawv, tab sis nws raug txhawb kom tsuas yog ua kom tiav txoj haujlwm no qhov twg `T` thiab `U` muaj qhov loj tib yam.Txoj haujlwm no ua rau [undefined behavior][ub] yog `U` loj dua `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Luam cov ntaub ntawv los ntawm 'foo_array' thiab kho nws raws li ib tug 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Hloov cov theej cov ntaub ntawv
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // Tus txheem ntawm 'foo_array' yuav tsum tsis txhob muaj hloov
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Yog tias U muaj kev sib thooj ntau dua, src kuj yuav tsis haum rau kev ua haujlwm.
    if align_of::<U>() > align_of::<T>() {
        // KEV RUAJ NTSEG: `src` yog qhov siv tau uas tau lees tias yuav siv tau rau kev nyeem ntawv.
        // Tus neeg hu yuav tsum tau lees tias qhov tseeb transmutation muaj kev ruaj ntseg.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // KEV RUAJ NTSEG: `src` yog qhov siv tau uas tau lees tias yuav siv tau rau kev nyeem ntawv.
        // Peb tsuas yog khij tias `src as *const U` tau ua raws li tau tsim nyog.
        // Tus neeg hu yuav tsum tau lees tias qhov tseeb transmutation muaj kev ruaj ntseg.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Opaque yam sawv cev rau qhov kev ntxub ntxaug ntawm ib qho enum.
///
/// Saib [`discriminant`] ua haujlwm hauv qhov qauv no rau cov lus qhia ntxiv.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Cov kev siv trait tsis tuaj yeem muab los tau vim tias peb tsis xav tau ib qho ciam ntawm T.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Rov qab rau tus nqi tsis txawv tshwj xeeb txheeb xyuas qhov enum sib txawv hauv `v`.
///
/// Yog tias `T` tsis yog qhov khoob, hu rau txoj haujlwm no yuav tsis ua rau tsis muaj kev coj cwj pwm, tab sis tus nqi xa rov qab yog tsis paub tseeb.
///
///
/// # Stability
///
/// Kev cais tshwj ntawm ib tus kab mob kis tau txawv txav yog tias lub ntsiab lus enum hloov pauv.
/// Kev cais tawm ntawm qee qhov kev hloov pauv yuav tsis hloov pauv ntawm cov kev suav nrog tib tus sau.
///
/// # Examples
///
/// Qhov no tuaj yeem siv los sib piv cov enums uas nqa cov ntaub ntawv, thaum tsis saib xyuas cov ntaub ntawv tiag tiag:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Rov qab tus naj npawb ntawm cov variants hauv cov enum hom `T`.
///
/// Yog tias `T` tsis yog qhov khoob, hu rau txoj haujlwm no yuav tsis ua rau tsis muaj kev coj cwj pwm, tab sis tus nqi xa rov qab yog tsis paub tseeb.
/// Qhov sib npaug, yog `T` yog qhov thaiv uas muaj ntau yam sib txawv ntau dua `usize::MAX` tus nqi xa rov qab yog tsis paub meej.
/// Cov uas tsis nyob hauv yuav tau suav rau.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}