//! Shareable mutable ntim.
//!
//! Rust nco kev nyab xeeb yog ua raws li txoj cai no: Muab ib tug kwv `T`, nws tsuas yog ua tau kom muaj ib qho ntawm cov nram qab no:
//!
//! - Muaj ob peb immutable ua tim khawv (`&T`) rau tus kwv (kuj hu ua **aliasing**).
//! - Muaj ib qho hloov pauv (`&mut T`) rau tus kwv (tseem hu ua **mutability**).
//!
//! Qhov no raug tswj los ntawm Rust compiler.Txawm li cas los, muaj tej yam teeb meem nyob qhov twg txoj cai no yog tsis saj zawg zog txaus.Qee lub sij hawm nws yuav tsum muaj ntau yam pov thawj rau ib qho khoom thiab tseem hloov nws.
//!
//! Shareable mutable ntim muaj nyob rau daim ntawv tso cai mutability nyob rau hauv ib tug tswj yam, txawm nyob rau hauv lub xub ntiag ntawm aliasing.Ob [`Cell<T>`] thiab [`RefCell<T>`] cia li ua li no nyob rau hauv ib tug ib leeg-threaded txoj kev.
//! Txawm li cas los xij, tsis yog `Cell<T>` thiab `RefCell<T>` yog xov muaj kev nyab xeeb (lawv tsis siv [`Sync`]).
//! Yog tias koj xav tau aliasing thiab hloov pauv ntawm ntau cov xov nws yog ib qho ua tau los siv [`Mutex<T>`], [`RwLock<T>`] lossis [`atomic`] hom.
//!
//! Qhov tseem ceeb ntawm lub `Cell<T>` thiab `RefCell<T>` hom tej zaum yuav mutated los ntawm sib koom ua tim khawv (ie
//! hom `&T` hom), whereas feem ntau Rust hom tsuas tuaj yeem hloov tau los ntawm cov ntaub ntawv sib txawv (`&mut T`).
//! Peb hais tias `Cell<T>` thiab `RefCell<T>` muab 'sab hauv mutability', nyob rau hauv zoo uas raug Rust hom uas sau 'pub mutability'.
//!
//! Cov hom cell tuaj hauv ob qho kev tsw: `Cell<T>` thiab `RefCell<T>`.`Cell<T>` implements sab hauv mutability los tsiv qhov tseem ceeb nyob rau hauv thiab tawm ntawm lub `Cell<T>`.
//! Txhawm rau siv cov ntawv xa mus tsis txhob muaj nuj nqis, ib qho yuav tsum siv `RefCell<T>` hom, txais cov ntawv sau ua ntej sib hloov.`Cell<T>` muab txoj kev mus muab kom tau thiab hloov tau lub tam sim no sab hauv tus nqi:
//!
//!  - Rau cov hom uas siv [`Copy`], [`get`](Cell::get) tus qauv khaws cov nqi sab hauv tam sim no.
//!  - Rau cov hom uas siv [`Default`], [`take`](Cell::take) tus qauv hloov tus nqi sab hauv tam sim no nrog [`Default::default()`] thiab rov muab tus nqi hloov pauv.
//!  - Rau txhua hom, [`replace`](Cell::replace) tus qauv hloov tus nqi sab hauv tam sim no thiab rov qab tus nqi hloov pauv thiab [`into_inner`](Cell::into_inner) tus qauv siv `Cell<T>` thiab xa rov qab tus nqi sab hauv.
//!  Txuas ntxiv, [`set`](Cell::set) tus qauv hloov pauv rau sab hauv tus nqi, thau tus nqi hloov pauv.
//!
//! `RefCell<T>` siv Rust lub lifetimes siv 'dynamic qiv', ib tug txheej txheem uas ib tug yuav hais tias ib ntus, kom, mutable nkag tau mus rau lub puab nqi.
//! Cov ntawv qiv rau `RefCell<T>'S yog tracked' ntawm runtime, tsis zoo li Rust hom siv hom uas yog nkaus tracked statically, nyob compile lub sij hawm.
//! Vim hais tias `RefCell<T>` borrows yog dynamic nws yog tau mus sim tau qiv ib tug nqi uas yog twb mutably borrowed;thaum qhov no tshwm sim nws ua rau xov panic.
//!
//! # Thaum xaiv sab hauv kev sib hloov
//!
//! Qhov ntau tau txais txiaj ntsig hloov dua tshiab, qhov twg ib qho yuav tsum muaj kev nkag mus rau tshwj xeeb rau mutate tus nqi, yog ib qho ntawm cov ntsiab lus tseem ceeb uas ua rau Rust kev xav txog qhov nyuaj ntawm pointer aliasing, statically tiv thaiv cov kab sib tsoo.
//! Vim tias, kev hloov caj ces yog qhov zoo dua, thiab kev hloov pauv sab hauv yog ib yam dab tsi los ntawm qhov chaw kawg.
//! Txij li thaum cell hom pab kom hloov qhov twg nws yuav txwv tsis pub yuav disallowed tab sis, muaj qee zaus thaum sab hauv mutability tej zaum yuav tsim nyog, los yog txawm *yuav tsum* tau siv, xws li
//!
//! * Qhia cov mutability 'inside' ntawm qee yam tsis tuaj yeem
//! * Yuav ua raws li paub meej ntawm qhov tawm qhov tseeb-immutable txoj kev.
//! * Hloov kho kev siv ntawm [`Clone`].
//!
//! ## Qhia cov mutability 'inside' ntawm qee yam tsis tuaj yeem
//!
//! Muaj ntau muab qhia ntse pointer hom, xws li [`Rc<T>`] thiab [`Arc<T>`], muab ntim uas yuav cloned thiab qhia ntawm ntau yam ob tog.
//! Vim hais tias cov muaj qhov tseem ceeb tej zaum yuav multiply-aliased, lawv yuav tsuas yuav borrowed nrog `&`, tsis `&mut`.
//! Yog tsis muaj hlwb nws yuav tsis yooj yim sua rau mutate cov ntaub ntawv hauv cov ntse pointers rau hauv tag nrho.
//!
//! Nws yog heev ces mus rau muab tso rau ib tug `RefCell<T>` hauv qhia pointer hom rau reintroduce mutability:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Tsim qhov tshiab thaiv kom txwv qhov kev txiav txim siab ntawm cov nqi qiv quab yuam
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Nco ntsoov tias yog tias peb tsis tau cia lub qiv nyiaj dhau los ntawm lub cache poob tawm ntawm qhov kev txiav txim siab tom qab ntawd cov qiv nyiaj tom ntej yuav ua rau kom muaj xov zoo panic.
//!     //
//!     // Qhov no yog qhov phom sij txaus ntshai ntawm kev siv `RefCell`.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Nco ntsoov tias cov piv txwv no siv `Rc<T>` thiab tsis `Arc<T>`.`RefCell<T>'S yog rau ib leeg-threaded scenarios.Xav txog kev siv [`RwLock<T>`] lossis [`Mutex<T>`] yog tias koj xav tau sib pauv hloov nyob rau ntau qhov xwm txheej.
//!
//! ## Yuav ua raws li cov ntsiab lus ntawm qhov tawm qhov tseeb-immutable txoj kev
//!
//! Lub sij hawm nws yuav tsum ntshaw tsis tau las nyob rau hauv ib tug API hais tias muaj yog hloov tshwm sim "under the hood".
//! Qhov no yuav yog vim tias qhov haujlwm ua haujlwm yog qhov tsis muaj peev xwm hloov tau, tab sis, piv txwv li, caching yuam kev siv rau kev hloov ua;los yog vim tias koj yuav tsum siv kev hloov pauv kom ua raws li trait tus qauv thaum xub thawj txhais tias coj `&self`.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Kev suav nqe kim ntawm no mus
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## Hloov kho kev siv ntawm `Clone`
//!
//! Nov yog qhov tshwj xeeb, tab sis ib qho xwm txheej ntawm yav dhau los: zais kev tsis sib luag rau kev ua haujlwm uas zoo li tsis tuaj yeem hloov pauv.
//! [`clone`](Clone::clone) tus qauv xav tias yuav tsis hloov pauv cov nqi, thiab tau tshaj tawm tias yuav tsum coj `&self`, tsis yog `&mut self`.
//! Yog li no, ib qho kev hloov pauv uas tshwm sim hauv `clone` tus qauv yuav tsum siv hom cell.
//! Piv txwv li, [`Rc<T>`] khaws nws txoj siv suav tsis pub dhau `Cell<T>`.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// Ib tug mutable nco qhov chaw.
///
/// # Examples
///
/// Hauv qhov ua piv txwv, koj tuaj yeem pom tias `Cell<T>` ua kom hloov kev sib hloov hauv sab hauv kev hloov pauv.
/// Nyob rau hauv lwm yam lus, nws enables "interior mutability".
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // Yuam kev: `my_struct` yeej hloov tsis tau
/// // my_struct.regular_field =tshiab_value;
///
/// // WORKS: txawm hais tias `my_struct` yog immutable, `special_field` yog ib tug `Cell`,
/// // uas ib txwm ua tau mutated
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Saib cov [module-level documentation](self) rau ntau.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// Tsim ib tug `Cell<T>`, nrog rau cov `Default` muaj nuj nqis rau T.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Tsim ib tug tshiab `Cell` muaj qhov muab tus nqi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Teev tus nqi uas muaj nyob ntawd.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Swaps qhov tseem ceeb ntawm ob hlwb.
    /// Qhov sib txawv nrog `std::mem::swap` yog hais tias qhov no muaj nuj nqi tsis tau `&mut` siv.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // KEV RUAJ NTSEG: Qhov no yuav ua tau pheej hmoo ua, yog hais tias hu ua los ntawm cais threads, tab sis `Cell`
        // yog `!Sync` li no yuav tsis tshwm sim.
        // Qhov no kuj yuav tsis invalidate tej pointers vim `Cell` ua kom paub tseeb tsis muaj dab tsi lwm tus yuav tsum taw tes rau hauv tog twg los ntawm cov 'Cell`s.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Hloov cov nqi uas muaj nrog `val`, thiab rov qab cov khoom qub uas muaj nqi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // KEV RUAJ NTSEG: Qhov no yuav ua rau cov ntaub ntawv haiv neeg, yog hais tias hu ua los ntawm ib tug nyias muaj nyias ib xov,
        // tab sis `Cell` yog `!Sync` li no yuav tsis tshwm sim.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Unwraps tus nqi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Rov ib daim qauv ntawm cov muaj nqi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // KEV RUAJ NTSEG: Qhov no yuav ua rau cov ntaub ntawv haiv neeg, yog hais tias hu ua los ntawm ib tug nyias muaj nyias ib xov,
        // tab sis `Cell` yog `!Sync` li no yuav tsis tshwm sim.
        unsafe { *self.value.get() }
    }

    /// Tshiab cov muaj nqi siv ib tug muaj nuj nqi thiab rov qab rau hauv lub tshiab tus nqi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Rov qab los ib tug nyoos pointer rau lwm cov ntaub ntawv nyob rau hauv no cell.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Rov qab los cuam tshuam cov lus siv rau cov ntaub ntawv hauv qab.
    ///
    /// Qhov kev hu no qiv `Cell` mutably (thaum sau-ua ke) uas tau lees tias peb muaj qhov tsuas siv.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Rov qab `&Cell<T>` los ntawm `&mut T`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // KEV RUAJ NTSEG: `&mut` xyuas kom cov neeg siv tshwj xeeb.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Nqa cov nqi ntawm tes, tawm `Default::default()` hauv nws qhov chaw.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// Rov qab `&[Cell<T>]` los ntawm `&Cell<[T]>`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // KEV RUAJ NTSEG: `Cell<T>` muaj cov cim xeeb tib yam li `T`.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Ib tug mutable nco qhov chaw nyob nrog dynamically soj ntsuam qiv cai
///
/// Saib cov [module-level documentation](self) rau ntau.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// Ib qho yuam kev rov qab los ntawm [`RefCell::try_borrow`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// Ib qho yuam kev rov qab los ntawm [`RefCell::try_borrow_mut`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Zoo qhov tseem ceeb sawv cev rau tus xov tooj ntawm `Ref` kom nquag plias.Tsis zoo qhov tseem ceeb sawv cev rau tus xov tooj ntawm `RefMut` kom nquag plias.
// Ntau yam 'RefMut`tsuas tuaj yeem ua haujlwm nyob rau hauv ib lub sijhawm yog tias lawv hais txog qhov sib txawv, cov khoom sib txuas ntawm cov `RefCell` (piv txwv li, ntau qhov sib txawv ntawm ib qho).
//
// `Ref` thiab `RefMut` yog ob qho tib si ob lo lus hauv qhov loj me, thiab yog li yuav muaj yeej yuav tsis muaj txaus `Ref`s lossis`RefMut`s hauv hav zoov kom dhau ib nrab ntawm cov `usize` ntau.
// Yog li, ib lub `BorrowFlag` yuav tsis muaj txeej lossis qaug dhau.
// Txawm li cas los, qhov no tsis yog ib tug guarantee, raws li ib tug pathological kev pab cuam yuav pheej tsim thiab ces mem::forget 'Ref`s los yog' RefMut`s.
// Yog li, tag nrho cov code yuav tsum ntsees xyuas rau phwj thiab underflow nyob rau hauv thiaj li yuav tsis txhob unsafety, los yog tsawg kawg coj kom nyob rau hauv cov kev tshwm sim hais tias phwj los yog underflow tshwm sim (eg, saib BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// Tsim ib tug tshiab `RefCell` muaj `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// Khaws cov `RefCell`, rov qab los qhwv tus nqi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Txij li thaum txoj haujlwm no yuav siv `self` (`RefCell`) los ntawm tus nqi, tus compiler ua haujlwm ua pov thawj tias tam sim no nws tsis tau qiv.
        //
        self.value.into_inner()
    }

    /// Pauv lub qhwv tus nqi nrog ib lub tshiab, rov qab los rau hauv lub qub nqi, tsis muaj deinitializing yog ib tug.
    ///
    ///
    /// Qhov no muaj nuj nqi raws nkaus Ii [`std::mem::replace`](../mem/fn.replace.html).
    ///
    /// # Panics
    ///
    /// Panics yog tias tus nqi tam sim no tau qiv.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Hloov cov nqi qhwv nrog ib qho tshiab suav los ntawm `f`, rov qab cov nqi qub, tsis muaj kev txiav tawm ib qho.
    ///
    ///
    /// # Panics
    ///
    /// Panics yog tias tus nqi tam sim no tau qiv.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Swaps lub qhwv tus nqi ntawm `self` nrog lub qhwv tus nqi ntawm `other`, tsis muaj deinitializing yog ib tug.
    ///
    ///
    /// Txoj haujlwm no sib raug rau [`std::mem::swap`](../mem/fn.swap.html).
    ///
    /// # Panics
    ///
    /// Panics yog tias tus nqi hauv ib qho `RefCell` tam sim no tau qiv.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Immutably borrows lub qhwv tus nqi.
    ///
    /// Cov qiv kav kom txog thaum lub rov qab `Ref` nyob tau.
    /// Ntau immutable borrows yuav npaum li cas tawm ntawm lub tib lub sij hawm.
    ///
    /// # Panics
    ///
    /// Panics hais tias tus nqi yog tam sim no mutably borrowed.
    /// Rau ib tug uas tsis-panicking variant, siv [`try_borrow`](#method.try_borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// Ib qho piv txwv ntawm panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Immutably borrows lub qhwv tus nqi, rov qab ua yuam kev hais tias tus nqi yog tam sim no mutably borrowed.
    ///
    ///
    /// Cov qiv kav kom txog thaum lub rov qab `Ref` nyob tau.
    /// Ntau immutable borrows yuav npaum li cas tawm ntawm lub tib lub sij hawm.
    ///
    /// Qhov no yog qhov uas tsis yog-panicking variant ntawm [`borrow`](#method.borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // KEV RUAJ NTSEG: `BorrowRef` kom muaj no tsuas muaj immutable nkag
            // rau tus nqi thaum qiv.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Mutably borrows lub qhwv tus nqi.
    ///
    /// Cov nyiaj txais tau kom txog thaum xa rov qab `RefMut` lossis tag nrho `RefMut tus muab tau los ntawm nws tawm qhov kev txiav txim.
    ///
    /// Tus nqi tsis tau qiv tawm thaum lub sijhawm qiv no tseem muaj siab.
    ///
    /// # Panics
    ///
    /// Panics yog tias tus nqi tam sim no tau qiv.
    /// Rau ib tug uas tsis-panicking variant, siv [`try_borrow_mut`](#method.try_borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// Ib qho piv txwv ntawm panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Kev sib nrig sib qiv tus nqi qhwv, rov ua yuam kev yog tias tus nqi tam sim no qiv.
    ///
    ///
    /// Cov nyiaj txais tau kom txog thaum xa rov qab `RefMut` lossis tag nrho `RefMut tus muab tau los ntawm nws tawm qhov kev txiav txim.
    /// Tus nqi tsis tau qiv tawm thaum lub sijhawm qiv no tseem muaj siab.
    ///
    /// Nov yog qhov tsis-panicking variant ntawm [`borrow_mut`](#method.borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // KEV RUAJ NTSEG: `BorrowRef` guarantees cim saib.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Rov qab los ib tug nyoos pointer rau lwm cov ntaub ntawv nyob rau hauv no cell.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Rov qab los cuam tshuam cov lus siv rau cov ntaub ntawv hauv qab.
    ///
    /// Qhov no hu borrows `RefCell` mutably (ntawm compile-lub sij hawm) thiaj li muaj yog tsis muaj yuav tsum tau rau dynamic tshev.
    ///
    /// Txawm li cas los yuav tau ceev faj: cov qauv no xav kom `self` yuav mutable, uas yog feem ntau tsis yog cov ntaub thaum uas siv cov ib `RefCell`.
    ///
    /// Noj ib tug saib lub [`borrow_mut`] txoj kev es tsis txhob yog `self` yog tsis mutable.
    ///
    /// Tsis tas li ntawd, thov tsum paub hais tias txoj kev no yog tsuas yog rau cov tej yam tshwj xeeb thiab yog feem ntau tsis zoo li cas koj xav tau.
    /// Nyob rau hauv cov ntaub ntawv ntawm tsis ntseeg, siv [`borrow_mut`] xwb.
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Undo qhov ntxim ntawm cov dej xau tiv thaiv ntawm lub xeev qiv ntawm `RefCell`.
    ///
    /// Qhov no hu no yog hu uas zoo sib xws rau [`get_mut`] tab sis ntau tshwj xeeb.
    /// Nws borrows `RefCell` mutably kom tsis muaj borrows ua ib ke thiab ces resets lub xeev nrhiav qhia borrows.
    /// Qhov no yog ib yam yog ib co `Ref` los yog `RefMut` borrows tau leaked.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Immutably borrows lub qhwv tus nqi, rov qab ua yuam kev hais tias tus nqi yog tam sim no mutably borrowed.
    ///
    /// # Safety
    ///
    /// Tsis zoo li `RefCell::borrow`, cov qauv no yog tsis zoo vim hais tias nws tsis rov qab ib tug `Ref`, yog li tawm hauv lub qiv chij untouched.
    /// Mutably txais lub `RefCell` thaum lub siv rov qab los ntawm cov qauv no yog ciaj sia yog undefined tus cwj pwm.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // KEV RUAJ NTSEG: Peb xyuas uas tsis muaj leej twg yog koom sau ntawv tam sim no, tab sis nws yog ib
            // tus neeg lub luag hauj lwm kom ntseeg tau tias tsis muaj leej twg sau kom txog thaum lub rov qab siv yog tsis nyob rau hauv kev siv.
            // Tsis tas li ntawd, `self.value.get()` hais txog tus nqi uas los ntawm `self` thiab yog li no guaranteed yuav siv tau rau lub neej ntawm `self`.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// Yuav siv sij hawm tus qhwv tus nqi, tawm hauv `Default::default()` nyob rau hauv nws qhov chaw.
    ///
    /// # Panics
    ///
    /// Panics yog tias tus nqi tam sim no tau qiv.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics hais tias tus nqi yog tam sim no mutably borrowed.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// Tsim ib tug `RefCell<T>`, nrog rau cov `Default` muaj nuj nqis rau T.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics yog tias tus nqi hauv ib qho `RefCell` tam sim no tau qiv.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics yog tias tus nqi hauv ib qho `RefCell` tam sim no tau qiv.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics yog tias tus nqi hauv ib qho `RefCell` tam sim no tau qiv.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics yog tias tus nqi hauv ib qho `RefCell` tam sim no tau qiv.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics yog tias tus nqi hauv ib qho `RefCell` tam sim no tau qiv.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics yog tias tus nqi hauv ib qho `RefCell` tam sim no tau qiv.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics yog tias tus nqi hauv ib qho `RefCell` tam sim no tau qiv.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Incrementing qiv yuav ua nyob rau hauv ib tug uas tsis yog-kev nyeem ntawv nqi (<=0) nyob rau hauv cov neeg mob:
            // 1. Nws yog <0, piv txwv li muaj sau borrows, li ntawd, peb yuav tsis tso cai rau ib tug nyeem qiv vim Rust tus reference aliasing cai
            // 2.
            // Nws yog isize::MAX (qhov ntau npaum li cas ntawm kev nyeem ntawv qev) thiab nws tau dhau mus rau isize::MIN (qhov nyiaj ntau tshaj plaws ntawm kev sau ntawv qiv nyiaj) yog li peb tsis tuaj yeem tso cai nyeem ntxiv vim tias isize tsis tuaj yeem sawv cev ntau yam nyeem ntawv qiv nyiaj (qhov no tsuas tuaj yeem tshwm sim yog koj mem::forget ntau dua li tus nqi tsawg tsawg ntawm `Ref`s, uas tsis yog kev coj ua zoo)
            //
            //
            //
            //
            None
        } else {
            // Ntxiv qiv yuav ua rau nyeem ntawv tus nqi (> 0) hauv cov xwm txheej no:
            // 1. Nws yog=0, piv txwv li nws tsis tau qiv, thiab peb tabtom nyeem thawj qiv qiv
            // 2. Nws yog> 0 thiab <isize::MAX, piv txwv li
            // muaj nyeem ntawv qiv, thiab isize yog loj txaus los sawv cev muaj ib tug ntau nyeem qiv
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Vim qhov no nyob tshwm sim, peb paub tias cov qiv chij yog ib tug nyeem ntawv qiv.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Tiv thaiv kom txhob qiv counter los ntawm xos mus rau hauv ib tug sau ntawv qiv.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Kauv ib borrowed siv rau ib tug nqi nyob rau hauv ib tug `RefCell` box.
/// Ib hom ntawv qhwv rau ib qho immutably borrowed tus nqi los ntawm `RefCell<T>`.
///
/// Saib cov [module-level documentation](self) rau ntau.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Luam ib tus `Ref`.
    ///
    /// Lub `RefCell` yog twb immutably borrowed, yog li no yuav tsis tau swb.
    ///
    /// Qhov no yog ib qho kab nuj nqi uas yuav tsum tau siv raws li `Ref::clone(...)`.
    /// Ib tug `Clone` siv los yog ib txoj kev yuav cuam tshuam nrog cov thoob plaws siv cov `r.borrow().clone()` clone tus txheem ntawm ib tug `RefCell`.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Ua tshiab `Ref` rau cov khoom siv ntawm cov ntaub ntawv qiv.
    ///
    /// Lub `RefCell` yog twb immutably borrowed, yog li no yuav tsis tau swb.
    ///
    /// Qhov no yog ib qho kab nuj nqi uas yuav tsum tau siv raws li `Ref::map(...)`.
    /// Ib tug qauv yuav cuam tshuam nrog txoj kev ntawm lub tib lub npe nyob rau hauv lub txheem ntawm ib tug `RefCell` siv los ntawm `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Ua ib tug tshiab `Ref` rau ib tug tuamyeem ua ib feem ntawm lub borrowed cov ntaub ntawv.
    /// Tus neeg zov qub tau xa rov qab raws li `Err(..)` yog tias kaw kaw `None`.
    ///
    /// Lub `RefCell` yog twb immutably borrowed, yog li no yuav tsis tau swb.
    ///
    /// Qhov no yog ib qho kab nuj nqi uas yuav tsum tau siv raws li `Ref::filter_map(...)`.
    /// Ib tug qauv yuav cuam tshuam nrog txoj kev ntawm lub tib lub npe nyob rau hauv lub txheem ntawm ib tug `RefCell` siv los ntawm `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Splits ib `Ref` rau hauv ntau 'Ref`s rau txawv Cheebtsam ntawm lub borrowed cov ntaub ntawv.
    ///
    /// Lub `RefCell` yog twb immutably borrowed, yog li no yuav tsis tau swb.
    ///
    /// Qhov no yog kev cuam tshuam ua haujlwm uas yuav tsum tau siv `Ref::map_split(...)`.
    /// Ib tug qauv yuav cuam tshuam nrog txoj kev ntawm lub tib lub npe nyob rau hauv lub txheem ntawm ib tug `RefCell` siv los ntawm `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Hloov mus rau hauv qhov siv rau cov ntaub ntawv pib.
    ///
    /// Cov lwm `RefCell` yuav tsis raug mutably borrowed los ntawm dua thiab yuav nco ntsoov tshwm sim twb immutably borrowed.
    ///
    /// Nws tsis yog lub tswv yim zoo los xau ntau dua qhov muaj cov ntaub ntawv tas mus li.
    /// Lub `RefCell` tuaj yeem hloov kho tsis tau ntxiv yog tias tsuas muaj cov lej me me ntawm cov dej txia tau tshwm sim nyob rau hauv tag nrho.
    ///
    /// Qhov no yog kev cuam tshuam ua haujlwm uas yuav tsum tau siv `Ref::leak(...)`.
    /// Ib tug qauv yuav cuam tshuam nrog txoj kev ntawm lub tib lub npe nyob rau hauv lub txheem ntawm ib tug `RefCell` siv los ntawm `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // Los ntawm tsis nco qab txog Ref no peb kom ntseeg tau tias cov qiv qiv nyiaj hauv RefCell tsis tuaj yeem rov qab mus rau Kev Siv Tsis pub dhau `'b` lub neej.
        // Rov qab kho cov lus qhia kev taug qab lub xeev yuav xav tau ib qho kev siv tshwj xeeb rau qhov qiv RefCell.
        // Tsis muaj qhov hloov txuas ntxiv tuaj yeem tsim los ntawm tus thawj ntawm tes.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Ua ib tug tshiab `RefMut` rau ib feem ntawm cov borrowed cov ntaub ntawv, xws li, ib tug enum variant.
    ///
    /// Lub `RefCell` yog twb mutably borrowed, yog li no yuav tsis tau swb.
    ///
    /// Qhov no yog kev cuam tshuam ua haujlwm uas yuav tsum tau siv `RefMut::map(...)`.
    /// Ib tug qauv yuav cuam tshuam nrog txoj kev ntawm lub tib lub npe nyob rau hauv lub txheem ntawm ib tug `RefCell` siv los ntawm `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): txhim kho qiv-tshawb xyuas
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Ua tshiab `RefMut` rau kev xaiv sib ntxiv ntawm cov ntaub ntawv qiv.
    /// Tus neeg zov qub tau xa rov qab raws li `Err(..)` yog tias kaw kaw `None`.
    ///
    /// Lub `RefCell` yog twb mutably borrowed, yog li no yuav tsis tau swb.
    ///
    /// Qhov no yog kev cuam tshuam ua haujlwm uas yuav tsum tau siv `RefMut::filter_map(...)`.
    /// Ib tug qauv yuav cuam tshuam nrog txoj kev ntawm lub tib lub npe nyob rau hauv lub txheem ntawm ib tug `RefCell` siv los ntawm `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): txhim kho qiv-tshawb xyuas
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // KEV RUAJ NTSEG: muaj nuj nqi tuas rau ib tug tsuas yog siv rau lub caij
        // ntawm nws hu los ntawm `orig`, thiab tus pointer tsuas yog de-referenced sab hauv ntawm cov nuj nqi hu yeej tsis tso cai siv tshwj xeeb kom dim.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // KEV RUAJ NTSEG: tib yam li saum toj no.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Sib cais `RefMut` mus rau ntau qhov `RefMut` rau cov sib txawv ntawm cov ntaub ntawv qiv.
    ///
    /// Lub hauv paus `RefCell` yuav nyob twj ywm rau kev sib qiv kom txog thaum ob qho tag nrho rov qab `RefMut`s mus rau qhov tsis muaj peev xwm.
    ///
    /// Lub `RefCell` yog twb mutably borrowed, yog li no yuav tsis tau swb.
    ///
    /// Qhov no yog ib qho kab nuj nqi uas yuav tsum tau siv raws li `RefMut::map_split(...)`.
    /// Ib tug qauv yuav cuam tshuam nrog txoj kev ntawm lub tib lub npe nyob rau hauv lub txheem ntawm ib tug `RefCell` siv los ntawm `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Hloov siab los ntseeg mus rau hauv ib tug mutable siv rau qhov pib cov ntaub ntawv.
    ///
    /// Cov lwm `RefCell` tsis tau borrowed los ntawm dua thiab yuav nco ntsoov tshwm sim twb mutably borrowed, ua lub rov qab siv lub xwb rau qhov sab hauv.
    ///
    ///
    /// Qhov no yog kev cuam tshuam ua haujlwm uas yuav tsum tau siv `RefMut::leak(...)`.
    /// Ib tug qauv yuav cuam tshuam nrog txoj kev ntawm lub tib lub npe nyob rau hauv lub txheem ntawm ib tug `RefCell` siv los ntawm `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Los ntawm tsis nco qab no BorrowRefMut peb xyuas kom meej tias cov qiv qiv nyiaj hauv RefCell tsis tuaj yeem rov qab mus rau UNUSED nyob rau hauv lub neej `'b`.
        // Rov qab kho cov lus qhia kev taug qab lub xeev yuav xav tau ib qho kev siv tshwj xeeb rau qhov qiv RefCell.
        // Tsis muaj ntxiv ua tim khawv yuav tsum tsim los ntawm tus thawj cell li ntawd lub neej, ua rau tam sim no qiv lub xwb siv rau hauv seem uas yog lub neej.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: Tsis zoo li BorrowRefMut::clone, tshiab yog hu ua mus tsim lub thawj zaug
        // hloov siv tau, thiab yog li yuav tsum muaj tam sim no tsis muaj cov ntawv xa mus.
        // Yog li, thaum clone nce ntxiv qhov sib pauv sib ntxiv, ntawm no peb tsuas yog tso cai kom mus ntawm kev siv UNUSED rau UNUSED, 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // Clones tus `BorrowRefMut`.
    //
    // Qhov no tsuas siv tau yog tias txhua tus `BorrowRefMut` siv los taug qab qhov kev hloov pauv mus rau qhov sib txawv, nonoverlapping ntau yam ntawm cov khoom qub.
    //
    // Qhov no yog tsis nyob rau hauv ib tug Clone impl li ntawd code tsis hu no implicitly.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Tiv thaiv cov neeg qiv qiv nyiaj los ntawm qis dua.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// Ib hom ntawv qhwv rau sib nrig sib qiv ntawm tus nqi `RefCell<T>`.
///
/// Saib cov [module-level documentation](self) rau ntau.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Cov tub ntxhais txheej thaum ub rau sab hauv mutability nyob rau hauv Rust.
///
/// Yog tias koj muaj kev siv `&T`, tom qab ntawd ib txwm nyob hauv Rust lub compiler ua qhov kev ua tau zoo raws li kev paub tias `&T` cov ntsiab lus rau cov ntaub ntawv tsis muaj peev xwm.Hloov cov ntaub ntawv ntawd, piv txwv li dhau los ntawm kev tsis muaj npe lossis los ntawm transmuting `&T` rau hauv `&mut T`, suav tias yog kev coj cwj pwm tsis tau hais tawm.
/// `UnsafeCell<T>` opts-tawm ntawm lub immutability lav rau `&T`: ib qho sib qhia siv `&UnsafeCell<T>` yuav taw rau cov ntaub ntawv uas tau tab tom hloov.Qhov no yog hu ua "interior mutability".
///
/// Tag nrho lwm yam uas tso cai rau hauv mutability, xws li `Cell<T>` thiab `RefCell<T>`, hauv siv `UnsafeCell` los qhwv lawv cov ntaub ntawv.
///
/// Nco ntsoov tias tsuas yog immutability lav rau cov ntaub ntawv sib qhia tau cuam tshuam los ntawm `UnsafeCell`.Qhov tsis zoo tshaj plaws lav lav rau cov ntawv xa tawm tuaj yeem tsis muaj kev cuam tshuam.Muaj yog *tsis muaj* kev cai lij choj txoj kev kom tau aliasing `&mut`, tsis txawm nrog `UnsafeCell<T>`.
///
/// Lub `UnsafeCell` API nws tus kheej yog qhov ua tau yooj yim: [`.get()`] muab koj lub pointer `*mut T` rau nws cov ncauj lus.Nws nce txog _you_ raws li tus tsim teeb meem siv los siv tus pointer nyoos kom raug.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// Tus Rust qhia txog cai muaj qee yam hauv flux, tab sis cov ntsiab lus tseem ceeb tsis muaj kev sib cav:
///
/// - Yog hais tias koj tsim tau ib lub zoo siv nrog lub neej `'a` (xws li ib tug `&T` los yog `&mut T` siv) uas yog siv tau los ntawm kev ruaj ntseg code (piv txwv li, vim hais tias koj xa rov qab nws), ces koj yuav tsum tsis txhob nkag tau rau hauv cov ntaub ntawv nyob rau hauv tej txoj kev uas contradicts uas siv rau tas ntawm `'a`.
/// Piv txwv li, qhov no txhais tau tias yog tias koj coj tus `*mut T` los ntawm `UnsafeCell<T>` thiab pov nws mus rau `&T`, tom qab ntawd cov ntaub ntawv hauv `T` yuav tsum nyob twj ywm tsis hloov (modulo ib qho `UnsafeCell` cov ntaub ntawv pom nyob hauv `T`, tau kawg) kom txog thaum cov ntawv ntawd lub neej tag sijhawm.
/// Ib yam li ntawd, yog tias koj tsim `&mut T` siv uas tau tso tawm rau kev nyab xeeb cov cai, ces koj yuav tsum tsis nkag mus rau cov ntaub ntawv hauv `UnsafeCell` kom txog rau thaum cov ntawv ntawd tas.
///
/// - Txhua lub sijhawm, koj yuav tsum zam cov ntaub ntawv sib tw.Yog hais tias ntau yam threads muaj kev nkag tau mus rau cov tib `UnsafeCell`, ces tej sau yuav tsum muaj ib tug zoo tshwm sim-ua ntej kev sib raug zoo rau tag nrho lwm cov accesses (los yog siv atomics).
///
/// Yuav kom pab nrog rau txoj kev tsim, cov nram qab no scenarios yog ntsees tshaj tawm hais tias kev cai lij choj rau ib leeg-threaded code:
///
/// 1. Ib qho `&T` siv tuaj yeem tso tawm mus rau qhov chaws zoo thiab nws muaj peev xwm sib koom ua ke nrog lwm `&T` cov ntawv xa mus, tab sis tsis nrog `&mut T`
///
/// 2. Ib tug `&mut T` siv yuav tsum tau tso tawm rau kev nyab xeeb code muab tej nuj nqis lwm `&mut T` tsis `&T` co-nyob ua ib ke nrog nws.Ib tug `&mut T` yuav tsum nco ntsoov yuav cim.
///
/// Nco ntsoov tias whilst mutating tus txheem ntawm ib tug `&UnsafeCell<T>` (Txawm tias thaum lwm `&UnsafeCell<T>` ua tim khawv cai lub cell) yog ok (muab koj tswj lub saum toj no invariants ib co lwm txoj kev), nws yog tseem undefined tus cwj pwm kom muaj ntau yam `&mut UnsafeCell<T>` Aliases.
/// Hais tias yog, `UnsafeCell` yog ib tug wrapper tsim kom muaj ib tug tshwj xeeb kev sis raug zoo nrog _shared_ accesses (_i.e._, los ntawm ib tug `&UnsafeCell<_>` siv);muaj yog tsis muaj khawv koob los xij thaum soj ntsuam nrog _exclusive_ accesses (_e.g._, los ntawm ib tug `&mut UnsafeCell<_>`): tej nuj nqis cov cell los yog cov qhwv tus nqi tej zaum yuav aliased rau lub caij ntawm uas `&mut` qiv.
///
/// Qhov no yog showcased los ntawm cov [`.get_mut()`] accessor, uas yog ib tug _safe_ getter uas yields ib `&mut T`.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Ntawm no yog ib qho piv txwv showcasing yuav ua li cas rau soundly mutate cov ntsiab lus ntawm ib qho `UnsafeCell<_>` txawm hais tias muaj ntau cov ntawv siv qhia txog lub xov tooj ntawm tes:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Tau ntau/sib koom ua tim khawv rau tib `x`.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // KEV RUAJ NTSEG: hauv no uas muaj muaj tsis muaj lwm yam neeg ua tim khawv rau 'x` tus txheem,
///     // yog li peb tus kheej muaj txiaj ntsig zoo.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- qiv-+
///     *p1_exclusive += 27; // |
/// } // <---------- mus tsis tau dhau ntawm qhov no -------------------+
///
/// unsafe {
///     // KEV RUAJ NTSEG: nyob rau hauv qhov no tsis muaj leej twg xav tias yuav muaj kev nkag mus rau `x` tus txheem,
///     // li ntawd, peb yuav muaj ntau yam qhia accesses tib.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// Cov piv txwv nram qab showcases qhov tseeb hais tias kom nkag tau mus rau ib tug `UnsafeCell<T>` implies kom nkag tau mus rau nws `T`:
///
/// ```rust
/// #![forbid(unsafe_code)] // nrog kom accesses,
///                         // `UnsafeCell` yog pob tshab tsis muaj op-qhwv, yog li tsis xav tau `unsafe` ntawm no.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Tau txais kev suav ua ke-sijhawm tshawb xyuas tus kheej siv rau `x`.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Nrog rau kev siv tshwj xeeb, peb tuaj yeem hloov cov ntsiab lus dawb.
/// *p_unique.get_mut() = 0;
/// // Los sis, sib npaug:
/// x = UnsafeCell::new(0);
///
/// // Thaum peb muaj tus nqi, peb yuav extract tus txheem dawb.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Constructs ib tug tshiab lom ntawm `UnsafeCell` uas yuav qhwv lub teev nqi.
    ///
    ///
    /// Txhua tus nkag mus rau sab hauv tus nqi los ntawm cov hau kev yog `unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Unwraps tus nqi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Tau txais cov pointer uas hloov pauv tau rau tus nqi qhwv.
    ///
    /// Qhov no tuaj yeem pov rau lub pointer ntawm txhua yam.
    /// Xyuas kom meej tias cov kev nkag yog cim (tsis muaj active neeg ua tim khawv, mutable los yog tsis) thaum casting mus `&mut T`, thiab xyuas kom meej tias muaj cov tsis muaj change los yog mutable Aliases yuav mus nyob rau thaum casting mus `&T`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // Peb yuav cia li muab pov rau hauv lub pointer los ntawm `UnsafeCell<T>` rau `T` vim hais tias ntawm #[repr(transparent)].
        // Qhov no siv libstd qhov xwm txheej tshwj xeeb, tsis muaj kev lees paub rau cov neeg siv code uas qhov no yuav ua haujlwm hauv future versions ntawm cov compiler!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Rov qab los cuam tshuam cov lus siv rau cov ntaub ntawv hauv qab.
    ///
    /// Qhov kev hu no qiv `UnsafeCell` mutably (thaum sau-ua ke) uas tau lees tias peb muaj qhov tsuas siv.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Tau txais cov pointer uas hloov pauv tau rau tus nqi qhwv.
    /// Qhov sib txawv rau [`get`] yog tias lub luag haujlwm no lees txais lub pointer nyoos, uas yog cov txiaj ntsig kom tsis txhob muaj kev tsim cov ntawv xa mus ib ntus.
    ///
    /// Cov yuav raug muab pov mus rau ib tug pointer ntawm txhua yam.
    /// Xyuas kom meej tias cov kev nkag yog cim (tsis muaj active neeg ua tim khawv, mutable los yog tsis) thaum casting mus `&mut T`, thiab xyuas kom meej tias muaj cov tsis muaj change los yog mutable Aliases yuav mus nyob rau thaum casting mus `&T`.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// Gradual initialization ntawm ib tug `UnsafeCell` yuav tsum tau `raw_get`, li hu `get` puas yuav tsum tau tsim ib tug siv rau uninitialized ntaub ntawv:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // Peb yuav cia li muab pov rau hauv lub pointer los ntawm `UnsafeCell<T>` rau `T` vim hais tias ntawm #[repr(transparent)].
        // Qhov no siv libstd qhov xwm txheej tshwj xeeb, tsis muaj kev lees paub rau cov neeg siv code uas qhov no yuav ua haujlwm hauv future versions ntawm cov compiler!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// Tsim tus `UnsafeCell`, nrog tus nqi `Default` rau T.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}