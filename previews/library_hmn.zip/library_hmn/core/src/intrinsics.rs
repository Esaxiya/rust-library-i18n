//! Compiler intrinsics.
//!
//! Cov coj cov ntsiab lus txhais muaj nyob rau hauv `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! Cov coj const implementations yog nyob rau hauv `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # const intrinsics
//!
//! Note: cov kev pauv hloov ntawm qhov teeb meem ntawm kev nkag siab yuav tsum tau tham nrog pab pawg lus.
//! Qhov no muaj xws li kev hloov nyob rau hauv lub stability ntawm lub constness.
//!
//! Txhawm rau txiav txim siab siv tau thaum ua tiav-lub sijhawm, ib qho xav tau theej ntawm qhov kev nqis tes los ntawm <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> rau `compiler/rustc_mir/src/interpret/intrinsics.rs` thiab ntxiv `#[rustc_const_unstable(feature = "foo", issue = "01234")]` rau intrinsic.
//!
//!
//! Yog hais tias ib tug tseem ceeb yog yuav tsum tau siv los ntawm ib tug `const fn` nrog ib tug `rustc_const_stable` attribute, cov intrinsic tus cwj pwm yuav tsum tau `rustc_const_stable`, ib yam nkaus thiab.
//! Xws li kev hloov pauv yuav tsum tsis txhob ua yam tsis muaj kev sib tham hauv T-lang, vim tias nws coj tau ntau yam lus rau hauv cov lus uas tsis tuaj yeem rov ua dua hauv tus lej siv tsis muaj kev txhawb nqa.
//!
//! # Volatiles
//!
//! Lub volatile intrinsics muab haujlwm los ua rau I/O nco, uas yog guaranteed tsis tau reordered los ntawm cov compiler thoob plaws lwm volatile intrinsics.Saib cov ntawv LLVM ntawm [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Lub atomic intrinsics muab ntau atomic operations on tshuab cov lus, muaj ntau yam tau nco orderings.Lawv ua li tib semantics li C++ 11.Saib cov LLVM ntaub ntawv rau [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! Lub nras sai ntawm lub cim xeeb:
//!
//! * Tau, ib tug teeb meem rau kis ib tug xauv.Tom ntej nyeem thiab sau tau qhov chaw tom qab lub teeb meem.
//! * Tshaj tawm, qhov khuam siab rau kev tso ib lub xauv.Ua ntej nyeem thiab sau siv qhov chaw ua ntej lub barrier.
//! * Cov haujlwm uas xwm yeem, txuas ntxiv ua haujlwm raug ruaj khov tau lees tias yuav tshwm sim hauv kev txiav txim.Qhov no yog hom qauv rau kev ua haujlwm nrog atomic hom thiab yog sib npaug rau Java's `volatile`.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Cov tuaj txawv teb chaws yog siv rau cov simplifying intra-doc mus
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // KEV RUAJ NTSEG: saib `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, cov intrinsics coj nyoos pointers vim hais tias lawv mutate aliased nco, uas yog siv tsis tau rau tog twg los `&` los yog `&mut`.
    //

    /// Khw tus nqi yog tias tus nqi tam sim no yog tib yam li tus nqi `old`.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`atomic`] hom ntawm lub `compare_exchange` los ntawm txoj kev dua [`Ordering::SeqCst`] li ob lub `success` thiab `failure` tsis.
    ///
    /// Piv txwv li, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Khw tus nqi yog tias tus nqi tam sim no yog tib yam li tus nqi `old`.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`atomic`] hom ntawm lub `compare_exchange` los ntawm txoj kev dua [`Ordering::Acquire`] li ob lub `success` thiab `failure` tsis.
    ///
    /// Piv txwv li, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Khw tus nqi yog tias tus nqi tam sim no yog tib yam li tus nqi `old`.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`atomic`] hom ntawm lub `compare_exchange` los ntawm txoj kev dua [`Ordering::Release`] li cov `success` thiab [`Ordering::Relaxed`] li cov `failure` tsis.
    /// Piv txwv li, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Khw tus nqi yog tias tus nqi tam sim no yog tib yam li tus nqi `old`.
    ///
    /// Cov tshuaj khov kho ntawm qhov kev nkag siab no muaj nyob rau ntawm [`atomic`] hom ntawm `compare_exchange` txoj kev los ntawm kev dhau [`Ordering::AcqRel`] raws li `success` thiab [`Ordering::Acquire`] raws li cov `failure` tsis dhau.
    /// Piv txwv li, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Khw tus nqi yog tias tus nqi tam sim no yog tib yam li tus nqi `old`.
    ///
    /// Cov tshuaj khov kho ntawm qhov kev nkag siab no muaj nyob rau ntawm [`atomic`] hom ntawm `compare_exchange` txoj kev los ntawm kev dhau [`Ordering::Relaxed`] raws li ob qho dhau los `success` thiab `failure` tsis dhau.
    ///
    /// Piv txwv li, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Khw tus nqi yog tias tus nqi tam sim no yog tib yam li tus nqi `old`.
    ///
    /// Cov tshuaj khov kho ntawm qhov kev nkag siab no muaj nyob rau ntawm [`atomic`] hom ntawm `compare_exchange` txoj kev los ntawm kev dhau [`Ordering::SeqCst`] raws li `success` thiab [`Ordering::Relaxed`] raws li cov `failure` tsis dhau.
    /// Piv txwv li, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Khw tus nqi yog tias tus nqi tam sim no yog tib yam li tus nqi `old`.
    ///
    /// Cov tshuaj khov kho ntawm qhov kev nkag siab no muaj nyob rau ntawm [`atomic`] hom ntawm `compare_exchange` txoj kev los ntawm kev dhau [`Ordering::SeqCst`] raws li `success` thiab [`Ordering::Acquire`] raws li cov `failure` tsis dhau.
    /// Piv txwv li, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Khw tus nqi yog tias tus nqi tam sim no yog tib yam li tus nqi `old`.
    ///
    /// Cov tshuaj khov kho ntawm qhov kev nkag siab no muaj nyob rau ntawm [`atomic`] hom ntawm `compare_exchange` txoj kev los ntawm kev dhau [`Ordering::Acquire`] raws li `success` thiab [`Ordering::Relaxed`] raws li cov `failure` tsis dhau.
    /// Piv txwv li, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Khw tus nqi yog tias tus nqi tam sim no yog tib yam li tus nqi `old`.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`atomic`] hom ntawm lub `compare_exchange` los ntawm txoj kev dua [`Ordering::AcqRel`] li cov `success` thiab [`Ordering::Relaxed`] li cov `failure` tsis.
    /// Piv txwv li, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Khw tus nqi yog tias tus nqi tam sim no yog tib yam li tus nqi `old`.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`atomic`] hom ntawm lub `compare_exchange_weak` los ntawm txoj kev dua [`Ordering::SeqCst`] li ob lub `success` thiab `failure` tsis.
    ///
    /// Piv txwv li, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Khw tus nqi yog tias tus nqi tam sim no yog tib yam li tus nqi `old`.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`atomic`] hom ntawm lub `compare_exchange_weak` los ntawm txoj kev dua [`Ordering::Acquire`] li ob lub `success` thiab `failure` tsis.
    ///
    /// Piv txwv li, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Khw tus nqi yog tias tus nqi tam sim no yog tib yam li tus nqi `old`.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`atomic`] hom ntawm lub `compare_exchange_weak` los ntawm txoj kev dua [`Ordering::Release`] li cov `success` thiab [`Ordering::Relaxed`] li cov `failure` tsis.
    /// Piv txwv li, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Khw tus nqi yog tias tus nqi tam sim no yog tib yam li tus nqi `old`.
    ///
    /// Cov tshuaj khov kho ntawm qhov kev nkag siab no muaj nyob rau ntawm [`atomic`] hom ntawm `compare_exchange_weak` txoj kev los ntawm kev dhau [`Ordering::AcqRel`] raws li `success` thiab [`Ordering::Acquire`] raws li cov `failure` tsis dhau.
    /// Piv txwv li, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Khw tus nqi yog tias tus nqi tam sim no yog tib yam li tus nqi `old`.
    ///
    /// Cov tshuaj khov kho ntawm qhov kev nkag siab no muaj nyob rau ntawm [`atomic`] hom ntawm `compare_exchange_weak` txoj kev los ntawm kev dhau [`Ordering::Relaxed`] raws li ob qho dhau los `success` thiab `failure` tsis dhau.
    ///
    /// Piv txwv li, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Khw tus nqi yog tias tus nqi tam sim no yog tib yam li tus nqi `old`.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`atomic`] hom ntawm lub `compare_exchange_weak` los ntawm txoj kev dua [`Ordering::SeqCst`] li cov `success` thiab [`Ordering::Relaxed`] li cov `failure` tsis.
    /// Piv txwv li, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Khw tus nqi yog tias tus nqi tam sim no yog tib yam li tus nqi `old`.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`atomic`] hom ntawm lub `compare_exchange_weak` los ntawm txoj kev dua [`Ordering::SeqCst`] li cov `success` thiab [`Ordering::Acquire`] li cov `failure` tsis.
    /// Piv txwv li, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Khw tus nqi yog tias tus nqi tam sim no yog tib yam li tus nqi `old`.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`atomic`] hom ntawm lub `compare_exchange_weak` los ntawm txoj kev dua [`Ordering::Acquire`] li cov `success` thiab [`Ordering::Relaxed`] li cov `failure` tsis.
    /// Piv txwv li, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Khw tus nqi yog tias tus nqi tam sim no yog tib yam li tus nqi `old`.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`atomic`] hom ntawm lub `compare_exchange_weak` los ntawm txoj kev dua [`Ordering::AcqRel`] li cov `success` thiab [`Ordering::Relaxed`] li cov `failure` tsis.
    /// Piv txwv li, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Thaws cov nqi tam sim no ntawm tus pointer.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`atomic`] hom ntawm lub `load` los ntawm txoj kev dua [`Ordering::SeqCst`] li cov `order`.
    /// Piv txwv li, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Thaws cov nqi tam sim no ntawm tus pointer.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`atomic`] hom ntawm lub `load` los ntawm txoj kev dua [`Ordering::Acquire`] li cov `order`.
    /// Piv txwv li, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Thaws cov nqi tam sim no ntawm tus pointer.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`atomic`] hom ntawm lub `load` los ntawm txoj kev dua [`Ordering::Relaxed`] li cov `order`.
    /// Piv txwv li, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Khw cov nqi ntawm cov chaw cim tshwj xeeb.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`atomic`] hom ntawm lub `store` los ntawm txoj kev dua [`Ordering::SeqCst`] li cov `order`.
    /// Piv txwv li, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Khw cov nqi ntawm cov chaw cim tshwj xeeb.
    ///
    /// Cov qauv ruaj khov ntawm qhov kev nkag siab no yog muaj nyob rau ntawm [`atomic`] hom dhau ntawm `store` txoj kev los ntawm txoj kev dhau [`Ordering::Release`] li `order`.
    /// Piv txwv li, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Khw cov nqi ntawm cov chaw cim tshwj xeeb.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`atomic`] hom ntawm lub `store` los ntawm txoj kev dua [`Ordering::Relaxed`] li cov `order`.
    /// Piv txwv li, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Stores tus nqi ntawm cov kev cai tswjhwm nco qhov chaw, rov qab los rau hauv lub qub tus nqi.
    ///
    /// Cov qauv ruaj khov ntawm qhov kev nkag siab no yog muaj nyob rau ntawm [`atomic`] hom dhau ntawm `swap` txoj kev los ntawm txoj kev dhau [`Ordering::SeqCst`] li `order`.
    /// Piv txwv li, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Stores tus nqi ntawm cov kev cai tswjhwm nco qhov chaw, rov qab los rau hauv lub qub tus nqi.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`atomic`] hom ntawm lub `swap` los ntawm txoj kev dua [`Ordering::Acquire`] li cov `order`.
    /// Piv txwv li, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Stores tus nqi ntawm cov kev cai tswjhwm nco qhov chaw, rov qab los rau hauv lub qub tus nqi.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`atomic`] hom ntawm lub `swap` los ntawm txoj kev dua [`Ordering::Release`] li cov `order`.
    /// Piv txwv li, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Stores tus nqi ntawm cov kev cai tswjhwm nco qhov chaw, rov qab los rau hauv lub qub tus nqi.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`atomic`] hom ntawm lub `swap` los ntawm txoj kev dua [`Ordering::AcqRel`] li cov `order`.
    /// Piv txwv li, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Stores tus nqi ntawm cov kev cai tswjhwm nco qhov chaw, rov qab los rau hauv lub qub tus nqi.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`atomic`] hom ntawm lub `swap` los ntawm txoj kev dua [`Ordering::Relaxed`] li cov `order`.
    /// Piv txwv li, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Ntxiv rau qhov tam sim no tus nqi, rov qab rau hauv lub yav dhau los tus nqi.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`atomic`] hom ntawm lub `fetch_add` los ntawm txoj kev dua [`Ordering::SeqCst`] li cov `order`.
    /// Piv txwv li, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ntxiv rau qhov tam sim no tus nqi, rov qab rau hauv lub yav dhau los tus nqi.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`atomic`] hom ntawm lub `fetch_add` los ntawm txoj kev dua [`Ordering::Acquire`] li cov `order`.
    /// Piv txwv li, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ntxiv rau qhov tam sim no tus nqi, rov qab rau hauv lub yav dhau los tus nqi.
    ///
    /// Cov qauv ruaj khov ntawm qhov kev nkag siab no yog muaj nyob rau ntawm [`atomic`] hom dhau ntawm `fetch_add` txoj kev los ntawm txoj kev dhau [`Ordering::Release`] li `order`.
    /// Piv txwv li, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ntxiv rau qhov tam sim no tus nqi, rov qab rau hauv lub yav dhau los tus nqi.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`atomic`] hom ntawm lub `fetch_add` los ntawm txoj kev dua [`Ordering::AcqRel`] li cov `order`.
    /// Piv txwv li, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ntxiv rau qhov tam sim no tus nqi, rov qab rau hauv lub yav dhau los tus nqi.
    ///
    /// Cov qauv ruaj khov ntawm qhov kev nkag siab no yog muaj nyob rau ntawm [`atomic`] hom dhau ntawm `fetch_add` txoj kev los ntawm txoj kev dhau [`Ordering::Relaxed`] li `order`.
    /// Piv txwv li, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Rho los ntawm cov tam sim no tus nqi, rov qab rau hauv lub yav dhau los tus nqi.
    ///
    /// Cov qauv ruaj khov ntawm qhov kev nkag siab no yog muaj nyob rau ntawm [`atomic`] hom dhau ntawm `fetch_sub` txoj kev los ntawm txoj kev dhau [`Ordering::SeqCst`] li `order`.
    /// Piv txwv li, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Rho los ntawm cov tam sim no tus nqi, rov qab rau hauv lub yav dhau los tus nqi.
    ///
    /// Cov qauv ruaj khov ntawm qhov kev nkag siab no yog muaj nyob rau ntawm [`atomic`] hom dhau ntawm `fetch_sub` txoj kev los ntawm txoj kev dhau [`Ordering::Acquire`] li `order`.
    /// Piv txwv li, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Rho los ntawm cov tam sim no tus nqi, rov qab rau hauv lub yav dhau los tus nqi.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`atomic`] hom ntawm lub `fetch_sub` los ntawm txoj kev dua [`Ordering::Release`] li cov `order`.
    /// Piv txwv li, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Rho los ntawm cov tam sim no tus nqi, rov qab rau hauv lub yav dhau los tus nqi.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`atomic`] hom ntawm lub `fetch_sub` los ntawm txoj kev dua [`Ordering::AcqRel`] li cov `order`.
    /// Piv txwv li, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Rho los ntawm cov tam sim no tus nqi, rov qab rau hauv lub yav dhau los tus nqi.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`atomic`] hom ntawm lub `fetch_sub` los ntawm txoj kev dua [`Ordering::Relaxed`] li cov `order`.
    /// Piv txwv li, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise thiab qhov tam sim no tus nqi, rov qab rau hauv lub yav dhau los tus nqi.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`atomic`] hom ntawm lub `fetch_and` los ntawm txoj kev dua [`Ordering::SeqCst`] li cov `order`.
    /// Piv txwv li, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise thiab qhov tam sim no tus nqi, rov qab rau hauv lub yav dhau los tus nqi.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`atomic`] hom ntawm lub `fetch_and` los ntawm txoj kev dua [`Ordering::Acquire`] li cov `order`.
    /// Piv txwv li, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise thiab qhov tam sim no tus nqi, rov qab rau hauv lub yav dhau los tus nqi.
    ///
    /// Cov qauv ruaj khov ntawm qhov kev nkag siab no yog muaj nyob rau ntawm [`atomic`] hom dhau ntawm `fetch_and` txoj kev los ntawm txoj kev dhau [`Ordering::Release`] li `order`.
    /// Piv txwv li, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise thiab qhov tam sim no tus nqi, rov qab rau hauv lub yav dhau los tus nqi.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`atomic`] hom ntawm lub `fetch_and` los ntawm txoj kev dua [`Ordering::AcqRel`] li cov `order`.
    /// Piv txwv li, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise thiab qhov tam sim no tus nqi, rov qab rau hauv lub yav dhau los tus nqi.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`atomic`] hom ntawm lub `fetch_and` los ntawm txoj kev dua [`Ordering::Relaxed`] li cov `order`.
    /// Piv txwv li, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise nand nrog tus nqi tam sim no, rov qab cov nqi yav dhau los.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`AtomicBool`] hom ntawm lub `fetch_nand` los ntawm txoj kev dua [`Ordering::SeqCst`] li cov `order`.
    /// Piv txwv li, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand nrog tus nqi tam sim no, rov qab cov nqi yav dhau los.
    ///
    /// Cov qauv ruaj khov ntawm qhov kev nkag siab no yog muaj nyob rau ntawm [`AtomicBool`] hom ntawm `fetch_nand` txoj kev los ntawm txoj kev dhau [`Ordering::Acquire`] li `order`.
    /// Piv txwv li, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand nrog tus nqi tam sim no, rov qab cov nqi yav dhau los.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`AtomicBool`] hom ntawm lub `fetch_nand` los ntawm txoj kev dua [`Ordering::Release`] li cov `order`.
    /// Piv txwv li, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand nrog tus nqi tam sim no, rov qab cov nqi yav dhau los.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`AtomicBool`] hom ntawm lub `fetch_nand` los ntawm txoj kev dua [`Ordering::AcqRel`] li cov `order`.
    /// Piv txwv li, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand nrog tus nqi tam sim no, rov qab cov nqi yav dhau los.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`AtomicBool`] hom ntawm lub `fetch_nand` los ntawm txoj kev dua [`Ordering::Relaxed`] li cov `order`.
    /// Piv txwv li, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise los yog nrog tus nqi tam sim no, rov qab cov nqi yav dhau los.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`atomic`] hom ntawm lub `fetch_or` los ntawm txoj kev dua [`Ordering::SeqCst`] li cov `order`.
    /// Piv txwv li, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise los yog nrog tus nqi tam sim no, rov qab cov nqi yav dhau los.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`atomic`] hom ntawm lub `fetch_or` los ntawm txoj kev dua [`Ordering::Acquire`] li cov `order`.
    /// Piv txwv li, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise los yog nrog tus nqi tam sim no, rov qab cov nqi yav dhau los.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`atomic`] hom ntawm lub `fetch_or` los ntawm txoj kev dua [`Ordering::Release`] li cov `order`.
    /// Piv txwv li, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise los yog nrog tus nqi tam sim no, rov qab cov nqi yav dhau los.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`atomic`] hom ntawm lub `fetch_or` los ntawm txoj kev dua [`Ordering::AcqRel`] li cov `order`.
    /// Piv txwv li, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise los yog nrog tus nqi tam sim no, rov qab cov nqi yav dhau los.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`atomic`] hom ntawm lub `fetch_or` los ntawm txoj kev dua [`Ordering::Relaxed`] li cov `order`.
    /// Piv txwv li, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise xor nrog cov nqi tam sim no, rov qab cov nqi yav dhau los.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`atomic`] hom ntawm lub `fetch_xor` los ntawm txoj kev dua [`Ordering::SeqCst`] li cov `order`.
    /// Piv txwv li, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor nrog cov nqi tam sim no, rov qab cov nqi yav dhau los.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`atomic`] hom ntawm lub `fetch_xor` los ntawm txoj kev dua [`Ordering::Acquire`] li cov `order`.
    /// Piv txwv li, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor nrog cov nqi tam sim no, rov qab cov nqi yav dhau los.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`atomic`] hom ntawm lub `fetch_xor` los ntawm txoj kev dua [`Ordering::Release`] li cov `order`.
    /// Piv txwv li, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor nrog cov nqi tam sim no, rov qab cov nqi yav dhau los.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`atomic`] hom ntawm lub `fetch_xor` los ntawm txoj kev dua [`Ordering::AcqRel`] li cov `order`.
    /// Piv txwv li, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor nrog cov nqi tam sim no, rov qab cov nqi yav dhau los.
    ///
    /// Cov qauv ruaj khov ntawm qhov kev nkag siab no yog muaj nyob rau ntawm [`atomic`] hom dhau ntawm `fetch_xor` txoj kev los ntawm txoj kev dhau [`Ordering::Relaxed`] li `order`.
    /// Piv txwv li, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Tshaj siab nrog tus nqi tam sim no siv kos npe sib piv.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`atomic`] kos npe integer hom ntawm lub `fetch_max` los ntawm txoj kev dua [`Ordering::SeqCst`] li cov `order`.
    /// Piv txwv li, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Tshaj siab nrog tus nqi tam sim no siv kos npe sib piv.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`atomic`] kos npe integer hom ntawm lub `fetch_max` los ntawm txoj kev dua [`Ordering::Acquire`] li cov `order`.
    /// Piv txwv li, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Tshaj siab nrog tus nqi tam sim no siv kos npe sib piv.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`atomic`] kos npe integer hom ntawm lub `fetch_max` los ntawm txoj kev dua [`Ordering::Release`] li cov `order`.
    /// Piv txwv li, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Tshaj siab nrog tus nqi tam sim no siv kos npe sib piv.
    ///
    /// Cov qauv ruaj khov ntawm qhov kev nkag siab no yog muaj nyob rau ntawm [`atomic`] kos npe hom lej ntawm `fetch_max` txoj kev los ntawm txoj kev dhau [`Ordering::AcqRel`] li `order`.
    /// Piv txwv li, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Qhov siab tshaj nrog tus nqi tam sim no.
    ///
    /// Cov qauv ruaj khov ntawm qhov kev nkag siab no yog muaj nyob rau ntawm [`atomic`] kos npe hom lej ntawm `fetch_max` txoj kev los ntawm txoj kev dhau [`Ordering::Relaxed`] li `order`.
    /// Piv txwv li, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Yam tsawg kawg nkaus nrog tus nqi tam sim no siv kos npe sib piv.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`atomic`] kos npe integer hom ntawm lub `fetch_min` los ntawm txoj kev dua [`Ordering::SeqCst`] li cov `order`.
    /// Piv txwv li, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Yam tsawg kawg nkaus nrog tus nqi tam sim no siv kos npe sib piv.
    ///
    /// Cov qauv ruaj khov ntawm qhov kev nkag siab no yog muaj nyob rau ntawm [`atomic`] kos npe hom lej ntawm `fetch_min` txoj kev los ntawm txoj kev dhau [`Ordering::Acquire`] li `order`.
    /// Piv txwv li, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Yam tsawg kawg nkaus nrog tus nqi tam sim no siv kos npe sib piv.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`atomic`] kos npe integer hom ntawm lub `fetch_min` los ntawm txoj kev dua [`Ordering::Release`] li cov `order`.
    /// Piv txwv li, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Yam tsawg kawg nkaus nrog tus nqi tam sim no siv kos npe sib piv.
    ///
    /// Cov qauv ruaj khov ntawm qhov kev nkag siab no yog muaj nyob rau ntawm [`atomic`] kos npe hom lej ntawm `fetch_min` txoj kev los ntawm txoj kev dhau [`Ordering::AcqRel`] li `order`.
    /// Piv txwv li, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Yam tsawg kawg nkaus nrog tus nqi tam sim no siv kos npe sib piv.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`atomic`] kos npe integer hom ntawm lub `fetch_min` los ntawm txoj kev dua [`Ordering::Relaxed`] li cov `order`.
    /// Piv txwv li, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Yam tsawg kawg nkaus nrog tus nqi tam sim no uas siv kev sib piv tsis tau kos.
    ///
    /// Cov qauv ruaj khov ntawm qhov kev nkag siab no yog muaj nyob rau ntawm [`atomic`] cov ntawv kos npe tsis tiav hom `fetch_min` los ntawm kev dhau [`Ordering::SeqCst`] ua tus `order`.
    /// Piv txwv li, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Yam tsawg kawg nkaus nrog tus nqi tam sim no uas siv kev sib piv tsis tau kos.
    ///
    /// Cov qauv ruaj khov ntawm qhov kev nkag siab no yog muaj nyob rau ntawm [`atomic`] cov ntawv kos npe tsis tiav hom `fetch_min` los ntawm kev dhau [`Ordering::Acquire`] ua tus `order`.
    /// Piv txwv li, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Yam tsawg kawg nkaus nrog tus nqi tam sim no uas siv kev sib piv tsis tau kos.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`atomic`] unsigned integer hom ntawm lub `fetch_min` los ntawm txoj kev dua [`Ordering::Release`] li cov `order`.
    /// Piv txwv li, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Yam tsawg kawg nkaus nrog tus nqi tam sim no uas siv kev sib piv tsis tau kos.
    ///
    /// Cov qauv ruaj khov ntawm qhov kev nkag siab no yog muaj nyob rau ntawm [`atomic`] cov ntawv kos npe tsis tiav hom `fetch_min` los ntawm kev dhau [`Ordering::AcqRel`] ua tus `order`.
    /// Piv txwv li, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Yam tsawg kawg nkaus nrog tus nqi tam sim no uas siv kev sib piv tsis tau kos.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`atomic`] unsigned integer hom ntawm lub `fetch_min` los ntawm txoj kev dua [`Ordering::Relaxed`] li cov `order`.
    /// Piv txwv li, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maximum qhov tam sim no tus nqi siv ib tug unsigned sib piv.
    ///
    /// Cov qauv ruaj khov ntawm qhov kev nkag siab no yog muaj nyob rau ntawm [`atomic`] cov ntawv kos npe tsis tiav hom `fetch_max` los ntawm kev dhau [`Ordering::SeqCst`] ua tus `order`.
    /// Piv txwv li, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum qhov tam sim no tus nqi siv ib tug unsigned sib piv.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`atomic`] unsigned integer hom ntawm lub `fetch_max` los ntawm txoj kev dua [`Ordering::Acquire`] li cov `order`.
    /// Piv txwv li, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum qhov tam sim no tus nqi siv ib tug unsigned sib piv.
    ///
    /// Cov qauv ruaj khov ntawm qhov kev nkag siab no yog muaj nyob rau ntawm [`atomic`] cov ntawv kos npe tsis tiav hom `fetch_max` los ntawm kev dhau [`Ordering::Release`] ua tus `order`.
    /// Piv txwv li, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum qhov tam sim no tus nqi siv ib tug unsigned sib piv.
    ///
    /// Cov qauv ruaj khov ntawm qhov kev nkag siab no yog muaj nyob rau ntawm [`atomic`] cov ntawv kos npe tsis tiav hom `fetch_max` los ntawm kev dhau [`Ordering::AcqRel`] ua tus `order`.
    /// Piv txwv li, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum qhov tam sim no tus nqi siv ib tug unsigned sib piv.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau ntawm lub [`atomic`] unsigned integer hom ntawm lub `fetch_max` los ntawm txoj kev dua [`Ordering::Relaxed`] li cov `order`.
    /// Piv txwv li, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Lub `prefetch` intrinsic yog ib tug hint rau lub code generator mus tau ntxig ib prefetch qhia tias kev txhawb;txwv tsis pub, nws yog ib qho tsis muaj op.
    /// Prefetches muaj tsis ntxim rau cov tus cwj pwm ntawm qhov kev pab cuam tab sis muaj peev xwm hloov nws kev kawm yam ntxwv.
    ///
    /// Lub `locality` sib cav yuav tsum muaj ib tug qhov integer thiab yog ib tug sab nqaij daim tawv tas specifier xws li los ntawm (0), tsis muaj tas, rau (3), tsis tshua muaj lub zos kom nyob rau hauv cache.
    ///
    ///
    /// Qhov kev sib txuas hauv no tsis muaj qhov chaw ruaj khov.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// Lub `prefetch` intrinsic yog ib tug hint rau lub code generator mus tau ntxig ib prefetch qhia tias kev txhawb;txwv tsis pub, nws yog ib qho tsis muaj op.
    /// Prefetches muaj tsis ntxim rau cov tus cwj pwm ntawm qhov kev pab cuam tab sis muaj peev xwm hloov nws kev kawm yam ntxwv.
    ///
    /// Lub `locality` sib cav yuav tsum muaj ib tug qhov integer thiab yog ib tug sab nqaij daim tawv tas specifier xws li los ntawm (0), tsis muaj tas, rau (3), tsis tshua muaj lub zos kom nyob rau hauv cache.
    ///
    ///
    /// Qhov kev sib txuas hauv no tsis muaj qhov chaw ruaj khov.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// Lub `prefetch` intrinsic yog ib tug hint rau lub code generator mus tau ntxig ib prefetch qhia tias kev txhawb;txwv tsis pub, nws yog ib qho tsis muaj op.
    /// Prefetches muaj tsis ntxim rau cov tus cwj pwm ntawm qhov kev pab cuam tab sis muaj peev xwm hloov nws kev kawm yam ntxwv.
    ///
    /// Lub `locality` sib cav yuav tsum muaj ib tug qhov integer thiab yog ib tug sab nqaij daim tawv tas specifier xws li los ntawm (0), tsis muaj tas, rau (3), tsis tshua muaj lub zos kom nyob rau hauv cache.
    ///
    ///
    /// Qhov kev sib txuas hauv no tsis muaj qhov chaw ruaj khov.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// Lub `prefetch` intrinsic yog ib tug hint rau lub code generator mus tau ntxig ib prefetch qhia tias kev txhawb;txwv tsis pub, nws yog ib qho tsis muaj op.
    /// Prefetches muaj tsis ntxim rau cov tus cwj pwm ntawm qhov kev pab cuam tab sis muaj peev xwm hloov nws kev kawm yam ntxwv.
    ///
    /// Lub `locality` sib cav yuav tsum muaj ib tug qhov integer thiab yog ib tug sab nqaij daim tawv tas specifier xws li los ntawm (0), tsis muaj tas, rau (3), tsis tshua muaj lub zos kom nyob rau hauv cache.
    ///
    ///
    /// Qhov kev sib txuas hauv no tsis muaj qhov chaw ruaj khov.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Ib qho kev atomic laj kab.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau hauv [`atomic::fence`] los ntawm xeem dhau [`Ordering::SeqCst`] li cov `order`.
    ///
    ///
    pub fn atomic_fence();
    /// Ib qho kev atomic laj kab.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau hauv [`atomic::fence`] los ntawm xeem dhau [`Ordering::Acquire`] li cov `order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Ib qho kev atomic laj kab.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau hauv [`atomic::fence`] los ntawm xeem dhau [`Ordering::Release`] li cov `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Ib qho kev atomic laj kab.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau hauv [`atomic::fence`] los ntawm xeem dhau [`Ordering::AcqRel`] li cov `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Ib tug compiler-tsuas nco barrier.
    ///
    /// Nco accesses yuav tsis raug reordered hla no barrier ntawm lub compiler, tab sis tsis muaj cov lus qhia yuav tsum tawm txim liab rau nws.
    /// Qhov no yog qhov tsim nyog rau kev ua haujlwm ntawm tib txoj xov uas yuav raug thaiv ua ntej, xws li thaum sib cuam tshuam nrog lub teeb liab tuav.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau hauv [`atomic::compiler_fence`] los ntawm xeem dhau [`Ordering::SeqCst`] li cov `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Ib tug compiler-tsuas nco barrier.
    ///
    /// Nco accesses yuav tsis raug reordered hla no barrier ntawm lub compiler, tab sis tsis muaj cov lus qhia yuav tsum tawm txim liab rau nws.
    /// Qhov no yog qhov tsim nyog rau kev ua haujlwm ntawm tib txoj xov uas yuav raug thaiv ua ntej, xws li thaum sib cuam tshuam nrog lub teeb liab tuav.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau hauv [`atomic::compiler_fence`] los ntawm xeem dhau [`Ordering::Acquire`] li cov `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Ib tug compiler-tsuas nco barrier.
    ///
    /// Nco accesses yuav tsis raug reordered hla no barrier ntawm lub compiler, tab sis tsis muaj cov lus qhia yuav tsum tawm txim liab rau nws.
    /// Qhov no yog qhov tsim nyog rau kev ua haujlwm ntawm tib txoj xov uas yuav raug thaiv ua ntej, xws li thaum sib cuam tshuam nrog lub teeb liab tuav.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau hauv [`atomic::compiler_fence`] los ntawm xeem dhau [`Ordering::Release`] li cov `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Ib tug compiler-tsuas nco barrier.
    ///
    /// Nco accesses yuav tsis raug reordered hla no barrier ntawm lub compiler, tab sis tsis muaj cov lus qhia yuav tsum tawm txim liab rau nws.
    /// Qhov no yog qhov tsim nyog rau kev ua haujlwm ntawm tib txoj xov uas yuav raug thaiv ua ntej, xws li thaum sib cuam tshuam nrog lub teeb liab tuav.
    ///
    /// Lub stabilized version ntawm no intrinsic yog muaj nyob rau hauv [`atomic::compiler_fence`] los ntawm xeem dhau [`Ordering::AcqRel`] li cov `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Magic intrinsic uas derives nws cov ntsiab lus los ntawm tej cwj pwm uas txuas mus rau cov nuj nqi.
    ///
    /// Piv txwv li, dataflow siv tau qhov no rau hno zoo li qub assertions yog li ntawd `rustc_peek(potentially_uninitialized)` yuav ua tau ob-check uas dataflow puas tseeb laij hais tias nws yog uninitialized ntawm tus taw tes nyob rau hauv cov kev tswj txaus.
    ///
    ///
    /// Qhov no tseem ceeb yuav tsum tsis txhob yuav siv sab nraum lub compiler.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Aborts lub tua ntawm tus txheej txheem.
    ///
    /// Ib tug ntau tus neeg siv-phooj ywg thiab ruaj khov version ntawm lub lag luam no yog [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Qhia rau lub optimizer tias qhov no taw tes rau hauv txoj cai tsis ncav cuag, ua kom zoo dua ntxiv.
    ///
    /// NB, qhov no yog sib txawv heev los ntawm cov `unreachable!()` macro: Tsis zoo li cov macro, uas panics thaum nws yog tua, nws yog *undefined tus cwj pwm* mus cuag code cim nrog no muaj nuj nqi.
    ///
    ///
    /// Lub stabilized version ntawm no intrinsic yog [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Qhia rau lub tswv yim zoo tias ib qho mob yog ib txwm muaj tseeb.
    /// Yog tias qhov xwm txheej tsis raug, qhov kev coj ua tsis muaj tseeb.
    ///
    /// Tsis muaj tus lej tsim tawm rau qhov kev nkag siab no, tab sis tus neeg ua kom zoo yuav sim khaws nws (thiab nws cov xwm txheej) ntawm kev hla, uas yuav cuam tshuam nrog kev ua kom tau zoo ntawm ib puag ncig cov cai thiab txo qis kev ua haujlwm.
    /// Nws yuav tsum tsis txhob siv yog tias qhov tsis pom kev tuaj yeem nrhiav pom los ntawm qhov ntsuas qhov zoo ntawm nws tus kheej, lossis yog tias nws tsis tuaj yeem siv ib qho kev txhim kho loj.
    ///
    /// Qhov kev sib txuas hauv no tsis muaj qhov chaw ruaj khov.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Yim pab rau cov compiler uas branch mob no tej zaum yuav muaj tseeb.
    /// Rov qhov muaj nqis kis mus rau nws.
    ///
    /// Ib qho kev siv uas tsis yog nrog `if` cov nqe lus yuav tsis muaj qhov cuam tshuam.
    ///
    /// Qhov kev sib txuas hauv no tsis muaj qhov chaw ruaj khov.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Yim pab rau cov compiler uas branch mob no tej zaum yuav tsis muaj tseeb.
    /// Rov qhov muaj nqis kis mus rau nws.
    ///
    /// Ib qho kev siv uas tsis yog nrog `if` cov nqe lus yuav tsis muaj qhov cuam tshuam.
    ///
    /// Qhov kev sib txuas hauv no tsis muaj qhov chaw ruaj khov.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Ua rau lub cuab yeej daws txhaum, rau kev soj ntsuam los ntawm tus debugger.
    ///
    /// Qhov kev sib txuas hauv no tsis muaj qhov chaw ruaj khov.
    pub fn breakpoint();

    /// Qhov luaj li cas ntawm ib yam nyob rau hauv bytes.
    ///
    /// Tshwj xeeb tshaj yog, qhov no yog qhov offset hauv bytes ntawm cov khoom ua tiav ntawm tib hom, suav nrog kev sib dhos padding.
    ///
    ///
    /// Lub stabilized version ntawm no intrinsic yog [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// Qhov tsawg kawg nkaus kawm tuab si lug ntawm ib hom.
    ///
    /// Cov qauv siv ruaj khov ntawm qhov intrinsic no yog [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// Lub nyiam kawm tuab si lug ntawm ib hom.
    ///
    /// Qhov kev sib txuas hauv no tsis muaj qhov chaw ruaj khov.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// Qhov luaj li cas ntawm cov hais tus nqi nyob hauv bytes.
    ///
    /// Cov qauv siv ruaj khov ntawm qhov intrinsic no yog [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// Qhov yuav tsum tau kawm tuab si lug ntawm lub pov thawj nqi.
    ///
    /// Lub stabilized version ntawm no intrinsic yog [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Tau ib tug zoo li qub hlua hlais muaj lub npe ntawm ib yam.
    ///
    /// Cov qauv siv ruaj khov ntawm qhov intrinsic no yog [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Tau txais cov cim uas yog thoob ntiaj teb cov cim tshwj xeeb.
    /// Txoj haujlwm no yuav rov qab tus nqi rau ib hom tsis hais hom twg crate nws tau dhau los.
    ///
    ///
    /// Cov qauv siv ruaj khov ntawm qhov intrinsic no yog [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// Ib tug neeg zov nyas rau tsis zoo zog uas yuav tsis tau raug tua yog `T` yog uninhabited:
    /// Qhov no yuav zoo ib yam li panic, lossis tsis muaj dabtsi ua.
    ///
    /// Qhov kev sib txuas hauv no tsis muaj qhov chaw ruaj khov.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// Tus neeg saib xyuas rau lub haujlwm tsis zoo uas tsis tuaj yeem raug tua yog `T` tsis tso cai xoom-pib: Qhov no yuav ua rau yog panic, lossis tsis muaj dab tsi ua.
    ///
    ///
    /// Qhov kev sib txuas hauv no tsis muaj qhov chaw ruaj khov.
    pub fn assert_zero_valid<T>();

    /// Ib tug neeg zov nyas rau tsis zoo zog uas yuav tsis tau raug tua yog `T` muaj invalid ntsis qauv: Qhov no yuav statically yog panic, los yog ua ib yam dabtsi.
    ///
    ///
    /// Qhov kev sib txuas hauv no tsis muaj qhov chaw ruaj khov.
    pub fn assert_uninit_valid<T>();

    /// Tau txais cov ntawv pov thawj rau daim ntawv cog lus `Location` qhia qhov chaw uas nws tau hu ua.
    ///
    /// Xav txog kev siv [`core::panic::Location::caller`](crate::panic::Location::caller) xwb.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Tsiv ib tug nqi tawm tau tsis tau khiav nco nplaum.
    ///
    /// Qhov no tshwm sim thiaj tau tuaj rau [`mem::forget_unsized`];ib txwm `forget` siv `ManuallyDrop` hloov.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Reinterprets cov khoom ntawm ib tug nqi ntawm ib hom raws li lwm hom.
    ///
    /// Ob hom yuav tsum muaj tib lub loj.
    /// Tsis yog tus twg tus thawj, los yog cov tshwm sim, tej zaum yuav ua tau ib tug [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` yog semantically sib npaug mus rau ib tug Bitwise txav ntawm ib hom mus rau lwm lub.Nws luam cov khoom los ntawm cov peev txheej muaj nuj nqis rau cov nqe lus kawg, ces tsis nco qab qhov qub.
    /// Nws tau sib npaug nrog C's `memcpy` hauv qab hood, ib yam li `transmute_copy`.
    ///
    /// Vim tias `transmute` yog kev lag luam los ntawm kev ua haujlwm, kev sib thooj ntawm *transmuted tus nqi lawv tus kheej* tsis muaj kev txhawj xeeb.
    /// Raws li nrog rau lwm yam muaj nuj nqi, cov compiler twb kom ob leeg `T` thiab `U` no kom raws li.
    /// Txawm li cas los xij, thaum transmuting qhov tseem ceeb uas *taw tes rau lwm qhov*(xws li taw tes, cov ntawv xa mus, lub thawv ...), tus neeg hu yuav tsum xyuas kom meej cov kev ua kom haum ntawm cov taw-rau qhov tseem ceeb.
    ///
    /// `transmute` yog **incredibly** tsis zoo.Muaj ntau txoj hauv kev ua rau [undefined behavior][ub] nrog txoj haujlwm no.`transmute` yuav tsum yog tus tsis kawg resort.
    ///
    /// Lub [nomicon](../../nomicon/transmutes.html) muaj ntxiv cov ntaub ntawv.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Muaj ob peb yam uas `transmute` yog qhov muaj txiaj ntsig zoo rau.
    ///
    /// Xa mus rau tus pointer rau hauv lub pointer muaj nuj nqi.Qhov no yog *tsis* portable rau cov cav qhov twg ua haujlwm cov taw tes thiab cov ntsuas cov ntaub ntawv muaj qhov ntau thiab tsawg.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Ncua sijhawm tas sim neej, lossis ua kom lub neej tsis muaj qhov txawv txav ntxiv.Qhov no yog advanced, heev tsis zoo Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Koj tsis muaj peevxwm: ntau yam kev siv ntawm `transmute` yuav ua tau tiav los ntawm lwm yam.
    /// Hauv qab no yog ntau daim ntaub ntawv ntawm `transmute` uas yuav tsum tau hloov nrog kev ruaj ntseg constructs.
    ///
    /// Txoj siav nyoos bytes(`&[u8]`) rau `u32`, `f64`, thiab lwm yam .:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // siv `u32::from_ne_bytes` hloov
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // los yog siv `u32::from_le_bytes` los yog `u32::from_be_bytes` qhia kom meej rau endianness
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Xa tus pointer rau hauv lub `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Siv ib tug `as` cam khwb cia es tsis txhob
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// Xa ib `*mut T` rau hauv ib qho `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Siv ib tug reborrow es tsis txhob
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// Txoj siav ib `&mut T` rau hauv ib qho `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Tam sim no, muab tso ua ke `as` thiab reborrowing, nco ntsoov lub chaining ntawm `as` `as` yog tsis transitive
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// Xa `&str` mus rau ib qho `&[u8]`:
    ///
    /// ```
    /// // Qhov no tsis zoo rau txoj kev ua.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Koj yuav siv `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Los sis, tsuas siv txoj hlua ntawm byte, yog tias koj tau tswj txoj hlua ntawm qhov tseeb
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// Xa Xoo `Vec<&T>` rau hauv `Vec<Option<&T>>`.
    ///
    /// Yuav kom transmute lub puab hom ntawm cov txheem ntawm ib lub taub ntim, koj yuav tsum nco ntsoov tsis ua txhaum ib yam ntawm cov thawv tus invariants.
    /// Rau `Vec`, qhov no txhais tau hais tias ob qho tag nrho cov loj *thiab kawm tuab si lug* ntawm lub puab hom muaj kom phim.
    /// Lwm lub ntim yuav cia siab rau qhov loj me ntawm hom, sib thooj, lossis tseem `TypeId`, nyob rau hauv rooj plaub uas transmuting yuav tsis tuaj yeem ua txhua yam yam tsis tau ua txhaum cov thawv ntim tshuaj.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // clone lub vector raws li peb yuav rov qab siv lub lawv tom qab
    /// let v_clone = v_orig.clone();
    ///
    /// // Siv transmute: no cia siab rau lub unspecified cov ntaub ntawv layout ntawm `Vec`, uas yog ib tug lub tswv yim phem thiab yuav ua rau undefined cwj pwm.
    /////
    /// // Txawm li cas los, nws yog tsis muaj-daim ntawv.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Qhov no yog qhov hais tias, muaj kev ruaj ntseg txoj kev.
    /// // Nws luam tag nrho vector, tab sis yog, mus rau hauv ib tug tshiab array.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Qhov no yog qhov tsis zoo-luam, txoj kev tsis zoo ntawm "transmuting" ib lub `Vec`, tsis muaj kev cuam tshuam cov ntaub ntawv txheej txheem.
    /// // Hloov chaw hu rau `transmute`, peb ua lub pointer cam khwb cia, tab sis nyob rau hauv cov nqe lus ntawm hloov cov qub puab hom (`&i32`) rau tus tshiab ib (`Option<&i32>`), qhov no muaj tag nrho cov qub caveats.
    /////
    /// // Dhau li cov ntaub ntawv muab saum toj no, kuj sab laj rau [`from_raw_parts`] ntaub ntawv.
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME hloov tshiab no thaum vec_into_raw_parts stabilized.
    ///     // Xyuas kom cov thawj vector yog tsis poob.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Siv `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Muaj ntau txoj hauv kev los ua qhov no, thiab muaj ntau yam teeb meem nrog txoj kev (transmute) hauv qab no.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // thawj: transmute tsis yog hom kev nyab xeeb;txhua qhov nws kuaj tau yog tias T thiab
    ///         // U muaj tib lub loj.
    ///         // Thib ob, txoj cai ntawm no, koj muaj ob qho lus sib hloov uas tau taw qhia rau tib lub cim xeeb.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Qhov no tau tshem ntawm cov teeb meem kev nyab xeeb;`&mut *` yuav* tsuas *muab koj `&mut T` los ntawm `&mut T` lossis `* mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // Txawm li cas los, koj tseem muaj ob tug mutable ua tim khawv taw tes rau tus tib nco.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Qhov no yog yuav ua li cas rau tus txheej txheem tsev qiv ntawv ua li ntawd.
    /// // Qhov no yog qhov zoo tshaj plaws txoj kev, Yog hais tias koj yuav tsum tau ua ib yam dab tsi zoo li no
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Qhov no tam sim no muaj peb mutable ua tim khawv taw nyob rau tib lub cim xeeb.`slice`, lub rvalue ret.0, thiab cov rvalue ret.1.
    ///         // `slice` yeej tsis tau siv tom qab `let ptr = ...`, thiab yog li ib qho tuaj yeem kho nws li "dead", thiab yog li ntawd, koj tsuas yog muaj ob qho kev hloov pauv tiag.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Thaum lub sij hawm no ua rau kev nkag siab zoo ruaj khov, peb muaj qee tus lej kev cai hauv const fn
    // cov tshev mis uas tiv thaiv tau nws siv nyob rau hauv `const fn`.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Rov `true` yog hais tias tus tiag tiag hom muab raws li `T` yuav tsum tau nco lo;rov qab `false` yog hais tias tus tiag tiag hom muab rau `T` siv `Copy`.
    ///
    ///
    /// Yog hais tias qhov tseeb hom tsis yog tus yuav tsum tau lo kua nplaum los tsis ua raws li `Copy`, tom qab ntawd tus nqi xa rov qab ntawm txoj haujlwm no tsis pom tseeb.
    ///
    /// Cov qauv siv ruaj khov ntawm qhov intrinsic no yog [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Laij cov offset los ntawm ib lub pointer.
    ///
    /// Qhov no yog siv raws li ib tug tseem ceeb kom tsis txhob hloov mus rau thiab los ntawm ib tug integer, txij thaum lub hloov dua siab tshiab yuav muab pov tseg aliasing ntaub ntawv.
    ///
    /// # Safety
    ///
    /// Ob lub pib thiab ua pointer yuav tsum yog nyob rau hauv ciam teb los yog ib tug byte yav dhau los rau thaum xaus rau ib tug faib khoom.
    /// Yog hais tias yog pointer yog tawm ntawm ciam teb los yog xam phwj tshwm sim ces tej yam ntxiv siv cov rov qab nqi yuav raug nyob rau hauv undefined tus cwj pwm.
    ///
    ///
    /// Lub stabilized version ntawm no intrinsic yog [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Laij cov offset los ntawm ib tug pointer, uas wrapping.
    ///
    /// Qhov no yog siv raws li ib tug tseem ceeb kom tsis txhob hloov mus rau thiab los ntawm ib tug integer, txij thaum lub hloov dua siab tshiab cheeb tej optimizations.
    ///
    /// # Safety
    ///
    /// Tsis zoo li `offset` kev nkag siab, qhov kev nkag siab no tsis txwv qhov tshwm sim pointer taw tes rau hauv los yog ib qho byte dhau los kawg ntawm qhov khoom tau faib, thiab nws nrog ob qhov sib tw xam.
    /// Cov uas ua tus nqi yog tsis tas siv tau yuav tsum tau siv los ua tau nkag nco.
    ///
    /// Cov qauv siv ruaj khov ntawm qhov intrinsic no yog [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Sib npaug rau cov tsim nyog `llvm.memcpy.p0i8.0i8.*` intrinsic, nrog ib tug loj ntawm `count`*`size_of::<T>()` thiab ib tug kawm tuab si lug ntawm
    ///
    /// `min_align_of::<T>()`
    ///
    /// Lub ntsuas kub tsis taus tau tsim rau `true`, yog li nws yuav tsis kho kom zoo dua tshwj tsis yog qhov loj me sib npaug nrog xoom.
    ///
    /// Qhov kev sib txuas hauv no tsis muaj qhov chaw ruaj khov.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Sib npaug rau cov tsim nyog `llvm.memmove.p0i8.0i8.*` intrinsic, nrog ib tug loj ntawm `count* size_of::<T>()` thiab ib tug kawm tuab si lug ntawm
    ///
    /// `min_align_of::<T>()`
    ///
    /// Lub ntsuas kub tsis taus tau tsim rau `true`, yog li nws yuav tsis kho kom zoo dua tshwj tsis yog qhov loj me sib npaug nrog xoom.
    ///
    /// Qhov kev sib txuas hauv no tsis muaj qhov chaw ruaj khov.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Sib npaug rau qhov tsim nyog `llvm.memset.p0i8.*` intrinsic, nrog qhov loj me ntawm `count* size_of::<T>()` thiab kev haum ntawm `min_align_of::<T>()`.
    ///
    ///
    /// Lub ntsuas kub tsis taus tau tsim rau `true`, yog li nws yuav tsis kho kom zoo dua tshwj tsis yog qhov loj me sib npaug nrog xoom.
    ///
    /// Qhov kev sib txuas hauv no tsis muaj qhov chaw ruaj khov.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Co ib volatile load los ntawm cov `src` pointer.
    ///
    /// Lub stabilized version ntawm no intrinsic yog [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Ua lub khw ruaj khov ua rau `dst` pointer.
    ///
    /// Cov qauv siv ruaj khov ntawm qhov intrinsic no yog [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Ua ib tug neeg tsis mloog hais load los ntawm cov `src` pointer Lub pointer yog tsis yuav tsum tau yuav tsum tau raws li.
    ///
    ///
    /// Qhov kev sib txuas hauv no tsis muaj qhov chaw ruaj khov.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Ua lub khw ruaj khov ua rau `dst` pointer.
    /// Lub pointer yog tsis yuav tsum tau yuav tsum tau raws li.
    ///
    /// Qhov kev sib txuas hauv no tsis muaj qhov chaw ruaj khov.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Rov qab rau cov hauv paus plaub ntawm ib qho `f32`
    ///
    /// Lub stabilized version ntawm no intrinsic yog
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Rov cov square hauv paus ntawm ib tug `f64`
    ///
    /// Lub stabilized version ntawm no intrinsic yog
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Tsa ib tug `f32` rau ib tug integer lub hwj chim.
    ///
    /// Lub stabilized version ntawm no intrinsic yog
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Tsa ib tug `f64` rau ib tug integer lub hwj chim.
    ///
    /// Lub stabilized version ntawm no intrinsic yog
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Rov qab sine ntawm `f32`.
    ///
    /// Lub stabilized version ntawm no intrinsic yog
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Rov qab sine ntawm `f64`.
    ///
    /// Lub stabilized version ntawm no intrinsic yog
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Rov cov cosine ntawm ib tug `f32`.
    ///
    /// Lub stabilized version ntawm no intrinsic yog
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Rov cov cosine ntawm ib tug `f64`.
    ///
    /// Lub stabilized version ntawm no intrinsic yog
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Tsa ib tug `f32` rau ib tug `f32` lub hwj chim.
    ///
    /// Lub stabilized version ntawm no intrinsic yog
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Tsa ib tug `f64` rau ib tug `f64` lub hwj chim.
    ///
    /// Lub stabilized version ntawm no intrinsic yog
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Rov qab cov exponential ntawm ib qho `f32`.
    ///
    /// Lub stabilized version ntawm no intrinsic yog
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Rov cov exponential ntawm ib tug `f64`.
    ///
    /// Lub stabilized version ntawm no intrinsic yog
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Rov qab los 2 tsa ceg rau lub zog ntawm `f32`.
    ///
    /// Lub stabilized version ntawm no intrinsic yog
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Rov qab los 2 tsa mus rau lub hwj chim ntawm ib tug `f64`.
    ///
    /// Lub stabilized version ntawm no intrinsic yog
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Rov cov natural logarithm ntawm ib tug `f32`.
    ///
    /// Lub stabilized version ntawm no intrinsic yog
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Rov qab cov logarithm ntuj ntawm cov `f64`.
    ///
    /// Lub stabilized version ntawm no intrinsic yog
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Rov puag 10 logarithm ntawm ib tug `f32`.
    ///
    /// Lub stabilized version ntawm no intrinsic yog
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Rov puag 10 logarithm ntawm ib tug `f64`.
    ///
    /// Lub stabilized version ntawm no intrinsic yog
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Rov puag 2 logarithm ntawm ib tug `f32`.
    ///
    /// Lub stabilized version ntawm no intrinsic yog
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Rov qab cov hauv paus 2 logarithm ntawm ib qho `f64`.
    ///
    /// Lub stabilized version ntawm no intrinsic yog
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Rov qab `a * b + c` rau `f32` qhov tseem ceeb.
    ///
    /// Lub stabilized version ntawm no intrinsic yog
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Rov `a * b + c` rau `f64` qhov tseem ceeb.
    ///
    /// Lub stabilized version ntawm no intrinsic yog
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Rov qab tus nqi tsis txaus ntawm ib qho `f32`.
    ///
    /// Lub stabilized version ntawm no intrinsic yog
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Rov qhov tsis muaj nqis ntawm ib qho kev `f64`.
    ///
    /// Lub stabilized version ntawm no intrinsic yog
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Rov qab cov tsawg kawg ntawm ob lub `f32` qhov tseem ceeb.
    ///
    /// Lub stabilized version ntawm no intrinsic yog
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Rov qhov tsawg kawg nkaus ntawm ob tug `f64` qhov tseem ceeb.
    ///
    /// Lub stabilized version ntawm no intrinsic yog
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Rov cov nyiaj pab ntau tshaj ntawm ob `f32` qhov tseem ceeb.
    ///
    /// Lub stabilized version ntawm no intrinsic yog
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Rov qab rau qhov siab tshaj plaws ntawm ob tus nqi `f64`.
    ///
    /// Lub stabilized version ntawm no intrinsic yog
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Luam tus kos npe rau los ntawm `y` rau `x` rau `f32` qhov tseem ceeb.
    ///
    /// Lub stabilized version ntawm no intrinsic yog
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Luam tus kos npe rau los ntawm `y` rau `x` rau `f64` qhov tseem ceeb.
    ///
    /// Lub stabilized version ntawm no intrinsic yog
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Rov qab los cov loj tshaj plaws integer tsawg dua los sis sib npaug mus rau ib qho `f32`.
    ///
    /// Lub stabilized version ntawm no intrinsic yog
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Rov qab los rau cov lej ntau tshaj tsawg dua los yog sib npaug rau ib qho `f64`.
    ///
    /// Lub stabilized version ntawm no intrinsic yog
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Rov qab los rau tus lej me me ntau dua lossis sib npaug rau ib qho `f32`.
    ///
    /// Lub stabilized version ntawm no intrinsic yog
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Rov qhov tsawg tshaj plaws integer ntau dua los yog sib npaug rau ib tug `f64`.
    ///
    /// Lub stabilized version ntawm no intrinsic yog
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Rov cov integer ib feem ntawm ib tug `f32`.
    ///
    /// Lub stabilized version ntawm no intrinsic yog
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Rov cov integer ib feem ntawm ib tug `f64`.
    ///
    /// Lub stabilized version ntawm no intrinsic yog
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Rov qhov ze integer rau ib tug `f32`.
    /// Tej zaum tsa ib tug inexact floating-point kos yog hais tias tus cav tsis yog ib qho integer.
    pub fn rintf32(x: f32) -> f32;
    /// Xa rov rau cov zauv ze tshaj plaws rau ib qho `f64`.
    /// Tej zaum tsa ib tug inexact floating-point kos yog hais tias tus cav tsis yog ib qho integer.
    pub fn rintf64(x: f64) -> f64;

    /// Rov qhov ze integer rau ib tug `f32`.
    ///
    /// Qhov kev sib txuas hauv no tsis muaj qhov chaw ruaj khov.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Xa rov rau cov zauv ze tshaj plaws rau ib qho `f64`.
    ///
    /// Qhov kev sib txuas hauv no tsis muaj qhov chaw ruaj khov.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Xa rov rau cov zauv ze tshaj plaws rau ib qho `f32`.Cov kab ib nrab ntawm cov kev ncua deb ntawm xoom.
    ///
    /// Lub stabilized version ntawm no intrinsic yog
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Rov qhov ze integer rau ib tug `f64`.Cov kab ib nrab ntawm cov kev ncua deb ntawm xoom.
    ///
    /// Lub stabilized version ntawm no intrinsic yog
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Ntab ntxiv uas tso cai rau kev ua kom tau zoo raws li cov cai algebraic.
    /// Tej zaum kev txiav txim siab kev nkag siab yog qhov ntau.
    ///
    /// Qhov kev sib txuas hauv no tsis muaj qhov chaw ruaj khov.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Ntab sib rho uas tso cai rau optimizations raws li algebraic cai.
    /// Tej zaum kev txiav txim siab kev nkag siab yog qhov ntau.
    ///
    /// Qhov kev sib txuas hauv no tsis muaj qhov chaw ruaj khov.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Ntab npaug uas tso cai rau optimizations raws li algebraic cai.
    /// Tej zaum kev txiav txim siab kev nkag siab yog qhov ntau.
    ///
    /// Qhov kev sib txuas hauv no tsis muaj qhov chaw ruaj khov.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Ntab division uas tso cai rau optimizations raws li algebraic cai.
    /// Tej zaum kev txiav txim siab kev nkag siab yog qhov ntau.
    ///
    /// Qhov kev sib txuas hauv no tsis muaj qhov chaw ruaj khov.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Ntab seem uas tso cai rau optimizations raws li algebraic cai.
    /// Tej zaum kev txiav txim siab kev nkag siab yog qhov ntau.
    ///
    /// Qhov kev sib txuas hauv no tsis muaj qhov chaw ruaj khov.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Hloov nrog LLVM's fptoui/fptosi, uas tuaj yeem rov qab tsis tau mus rau qhov tsis muaj nuj nqis ntawm ntau yam
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Stabilized raws li [`f32::to_int_unchecked`] thiab [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Rov qab tus naj npawb ntawm cov khoom teeb nyob rau hauv ib qho integer hom `T`
    ///
    /// Lub stabilized versions ntawm no intrinsic yog muaj nyob rau ntawm lub integer primitives ntawm lub `count_ones` txoj kev.
    /// Piv txwv li,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Rov tus xov tooj ntawm uas unset khoom (zeroes) nyob rau hauv ib tug integer hom `T`.
    ///
    /// Lub stabilized versions ntawm no intrinsic yog muaj nyob rau ntawm lub integer primitives ntawm lub `leading_zeros` txoj kev.
    /// Piv txwv li,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// Ib `x` nrog rau nqi `0` yuav rov qab lub ntsis dav ntawm `T`.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Zoo li `ctlz`, tab sis ntxiv-tsis zoo li nws rov `undef` thaum muab ib tug `x` nrog rau nqi `0`.
    ///
    ///
    /// Qhov kev sib txuas hauv no tsis muaj qhov chaw ruaj khov.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Rov tus xov tooj ntawm trailing unset khoom (zeroes) nyob rau hauv ib tug integer hom `T`.
    ///
    /// Cov kev tsim kho kom ruaj khov ntawm kev nkag siab no muaj nyob rau ntawm qhov kev suav tus lej ntawm `trailing_zeros` tus qauv.
    /// Piv txwv li,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// Ib `x` nrog rau nqi `0` yuav rov qab lub ntsis dav ntawm `T`:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Zoo li `cttz`, tab sis ntxiv-tsis nyab xeeb raws li nws rov `undef` thaum muab `x` nrog tus nqi `0`.
    ///
    ///
    /// Qhov kev sib txuas hauv no tsis muaj qhov chaw ruaj khov.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Reverses lub bytes hauv kev suav hom `T`.
    ///
    /// Cov kev tsim kho kom ruaj khov ntawm kev nkag siab no muaj nyob rau ntawm qhov kev suav tus lej ntawm `swap_bytes` tus qauv.
    /// Piv txwv li,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Rov qab cov me me hauv ib qho lej hom `T`.
    ///
    /// Cov kev tsim kho kom ruaj khov ntawm kev nkag siab no muaj nyob rau ntawm qhov kev suav tus lej ntawm `reverse_bits` tus qauv.
    /// Piv txwv li,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Muaj kev tshuaj xyuas kab zauv txuas ntxiv.
    ///
    /// Cov kev tsim kho kom ruaj khov ntawm kev nkag siab no muaj nyob rau ntawm qhov kev suav tus lej ntawm `overflowing_add` tus qauv.
    /// Piv txwv li,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Ua kev saib xyuas cov zauv sib rho
    ///
    /// Lub stabilized versions ntawm no intrinsic yog muaj nyob rau ntawm lub integer primitives ntawm lub `overflowing_sub` txoj kev.
    /// Piv txwv li,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Ua kev soj ntsuam cov zauv npaug
    ///
    /// Lub stabilized versions ntawm no intrinsic yog muaj nyob rau ntawm lub integer primitives ntawm lub `overflowing_mul` txoj kev.
    /// Piv txwv li,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Ua tau qhov kev cais meej, ua rau tsis muaj kev coj cwj pwm uas `x % y != 0` lossis `y == 0` lossis `x == T::MIN && y == -1`
    ///
    ///
    /// Qhov kev sib txuas hauv no tsis muaj qhov chaw ruaj khov.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Ua tug tsi kuaj xyuas division, uas ua rau undefined tus cwj pwm uas `y == 0` los yog `x == T::MIN && y == -1`
    ///
    ///
    /// Cov ntaub qhwv ntawv nyab xeeb rau qhov kev nkag siab zoo no muaj nyob ntawm cov lej sib sau ntawm `checked_div` txoj kev.
    /// Piv txwv li,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Rov qhov seem ntawm ib tug tsi kuaj xyuas division, uas ua rau undefined tus cwj pwm thaum `y == 0` los yog `x == T::MIN && y == -1`
    ///
    ///
    /// Muaj kev nyab xeeb wrappers rau no tseem ceeb muaj nyob rau hauv lub integer primitives ntawm lub `checked_rem` txoj kev.
    /// Piv txwv li,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Ua ib tug tsi kuaj xyuas sab laug ua haujlwm, ua rau undefined tus cwj pwm thaum `y < 0` los yog `y >= N`, qhov twg N yog cov dav uas T nyob rau hauv me me.
    ///
    ///
    /// Muaj kev nyab xeeb wrappers rau no tseem ceeb muaj nyob rau hauv lub integer primitives ntawm lub `checked_shl` txoj kev.
    /// Piv txwv li,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Ua ib tug tsi kuaj xyuas txoj cai ua haujlwm, ua rau undefined tus cwj pwm thaum `y < 0` los yog `y >= N`, qhov twg N yog cov dav uas T nyob rau hauv me me.
    ///
    ///
    /// Cov ntaub qhwv ntawv nyab xeeb rau qhov kev nkag siab zoo no muaj nyob ntawm cov lej sib sau ntawm `checked_shr` txoj kev.
    /// Piv txwv li,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Rov qhov tshwm sim ntawm ib tug tsi kuaj xyuas tas li ntawd, ua rau undefined tus cwj pwm thaum `x + y > T::MAX` los yog `x + y < T::MIN`.
    ///
    ///
    /// Qhov kev sib txuas hauv no tsis muaj qhov chaw ruaj khov.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Rov qhov tshwm sim ntawm ib tug tsi kuaj xyuas kev rho tawm, uas ua rau undefined tus cwj pwm thaum `x - y > T::MAX` los yog `x - y < T::MIN`.
    ///
    ///
    /// Qhov kev sib txuas hauv no tsis muaj qhov chaw ruaj khov.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Rov qhov tshwm sim ntawm ib tug tsi kuaj xyuas multiplication, uas ua rau undefined tus cwj pwm thaum `x *y > T::MAX` los yog `x* y < T::MIN`.
    ///
    ///
    /// Qhov kev sib txuas hauv no tsis muaj qhov chaw ruaj khov.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Ua tig sab laug.
    ///
    /// Cov kev tsim kho kom ruaj khov ntawm kev nkag siab no muaj nyob rau ntawm qhov kev suav tus lej ntawm `rotate_left` tus qauv.
    /// Piv txwv li,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Ua tig txoj cai.
    ///
    /// Lub stabilized versions ntawm no intrinsic yog muaj nyob rau ntawm lub integer primitives ntawm lub `rotate_right` txoj kev.
    /// Piv txwv li,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Rov qab los (a + b) mod 2 <sup>N</sup>, qhov twg N yog qhov dav ntawm T hauv qhov me me.
    ///
    /// Lub stabilized versions ntawm no intrinsic yog muaj nyob rau ntawm lub integer primitives ntawm lub `wrapping_add` txoj kev.
    /// Piv txwv li,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Rov qab los (a, b) mod 2 <sup>N,</sup> qhov twg N yog cov dav uas T nyob rau hauv me me.
    ///
    /// Lub stabilized versions ntawm no intrinsic yog muaj nyob rau ntawm lub integer primitives ntawm lub `wrapping_sub` txoj kev.
    /// Piv txwv li,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Rov qab los (a * b) mod 2 <sup>N,</sup> qhov twg N yog cov dav uas T nyob rau hauv me me.
    ///
    /// Cov kev tsim kho kom ruaj khov ntawm kev nkag siab no muaj nyob rau ntawm qhov kev suav tus lej ntawm `wrapping_mul` tus qauv.
    /// Piv txwv li,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Sib dhos `a + b`, saturating ntawm cov lej ciam.
    ///
    /// Cov kev tsim kho kom ruaj khov ntawm kev nkag siab no muaj nyob rau ntawm qhov kev suav tus lej ntawm `saturating_add` tus qauv.
    /// Piv txwv li,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Sib dhos `a - b`, saturating ntawm cov lej ciam.
    ///
    /// Cov kev tsim kho kom ruaj khov ntawm kev nkag siab no muaj nyob rau ntawm qhov kev suav tus lej ntawm `saturating_sub` tus qauv.
    /// Piv txwv li,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Rov qab cov nqi ntawm cov kev sib cais rau cov sib txawv hauv 'v';
    /// yog `T` twb tsis muaj discriminant, rov `0`.
    ///
    /// Lub stabilized version ntawm no intrinsic yog [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Rov qab tus naj npawb ntawm cov kev sib txawv ntawm hom `T` nrum rau `usize`;
    /// yog `T` twb tsis muaj variants, rov `0`.Tsis muaj neeg nyob variants yuav raug suav.
    ///
    /// Cov uas yuav-stabilized version ntawm no intrinsic yog [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Rust lub "try catch" dlaim uas thov cov nuj nqi pointer `try_fn` nrog cov ntaub ntawv pointer `data`.
    ///
    /// Qhov thib peb sib cav yog ib tug muaj nuj nqi hu ua yog ib tug panic tshwm sim.
    /// Qhov no muaj nuj nqi yuav siv sij hawm cov ntaub ntawv pointer thiab ib tug pointer mus rau lub hom phiaj kev kos yam khoom uas tau ntes tau.
    ///
    /// Yog xav paub ntxiv saib hauv lub compiler lub qhov chaw raws li tau zoo raws li std tus catch siv.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Emits ib `!nontemporal` khw raws li LLVM (saib lawv docs).
    /// Ntshe yuav tsis ua ruaj.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Saib cov ntaub ntawv ntawm `<*const T>::offset_from` kom paub meej.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Saib cov ntaub ntawv ntawm `<*const T>::guaranteed_eq` kom paub meej.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Saib cov ntaub ntawv ntawm `<*const T>::guaranteed_ne` kom paub meej.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Faib rau ntawm cov sijhawm sib piv.Yuav tsum tsis txhob muab hu ua ntawm runtime.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Qee lub zog tau sau tseg ntawm no vim tias lawv tau txhob txwm ua tau muaj nyob hauv qhov qauv no ntawm ruaj khov.
// Saib <https://github.com/rust-lang/rust/issues/15702>.
// (`transmute` kuj poob rau hauv pawg no, tab sis nws tsis tuaj yeem qhwv vim yog daim tshev uas `T` thiab `U` muaj qhov loj tib yam.)
//

/// Cov tshev mis seb puas `ptr` yog zoo raws li txoj kev `align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Luam `count *size_of::<T>()` bytes los ntawm `src` rau `dst`.Lub qhov twg los thiab lo lus uas peb yuav tsum* tsis * sib tshooj.
///
/// Rau cov cheeb tsam ntawm lub cim xeeb uas yuav sib tshooj, siv [`copy`] hloov.
///
/// `copy_nonoverlapping` yog semantically sib npaug rau C's [`memcpy`], tab sis nrog cov lus sib cav sib pauv.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Tus cwj pwm yog undefined yog ib yam ntawm cov nram qab no tej yam kev mob yog ua txhaum:
///
/// * `src` yuav tsum [valid] rau nyeem ntawm `count * size_of::<T>()` bytes.
///
/// * `dst` yuav tsum yog [valid] rau sau ntawm `count * size_of::<T>()` bytes.
///
/// * Ob `src` thiab `dst` yuav tsum tau kom raws.
///
/// * Thaj av ntawm lub cim xeeb pib ntawm `src` nrog qhov loj ntawm `suav *
///   size_of: :<T>() 'Bytes yuav tsum *tsis* overlap nrog lub cheeb tsam ntawm lub cim xeeb pib thaum `dst` nrog loj tib yam.
///
/// Zoo li [`read`], `copy_nonoverlapping` tsim ib tug Bitwise daim qauv ntawm `T`, tsis hais seb `T` yog [`Copy`].
/// Yog hais tias `T` yog tsis [`Copy`], siv *ob qho tib si* lub qhov tseem ceeb nyob rau hauv lub cheeb tsam yuav pib thaum `*src` thiab hauv lub cheeb tsam yuav pib thaum `* dst` tau [violate memory safety][read-ownership].
///
///
/// Nco ntsoov tias txawm yog hais tias tus zoo theej loj ('suav * size_of: :<T>() ') Yog `0`, lub pointers yuav tsum uas tsis yog-thov thiab kom raws li.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Manually siv [`Vec::append`]:
///
/// ```
/// use std::ptr;
///
/// /// Tsiv tag nrho cov ntsiab ntawm `src` rau hauv `dst`, tawm hauv `src` npliag.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Xyuas kom meej tias `dst` muaj peev xwm txaus los tuav tag nrho cov `src`.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Txoj kev hu mus them nqi ib txwm muaj kev nyab xeeb vim `Vec` yuav tsis faib ntau dua `isize::MAX` bytes.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Txiav `src` yam tsis poob cov ntawv nws cov ntsiab lus.
///         // Peb ua li no ua ntej, tsis txhob muaj teeb meem nyob rau hauv cov ntaub ntawv ib yam dab tsi ntxiv down panics.
///         src.set_len(0);
///
///         // Ob thaj av ntawd tsis tuaj yeem sib tshooj tau vim tias qhov chaw xa xov hloov pauv tsis muaj npe, thiab ob qho sib txawv vectors tsis tuaj yeem muaj qhov cim xeeb zoo ib yam.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Ceeb toom `dst` tias tam sim no nws tuav cov `src` X.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Ua cov tshev tsuas yog nyob rau lub sij hawm mus dhia
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Tsis panicking kom codegen feem me me.
        abort();
    }*/

    // KEV RUAJ NTSEG: daim ntawv cog lus muaj kev nyab xeeb rau `copy_nonoverlapping` yuav tsum yog
    // upheld los ntawm ib tus neeg hu.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Luam `count * size_of::<T>()` bytes los ntawm `src` rau `dst`.Lub qhov twg los thiab lo lus uas peb yuav sib tshooj.
///
/// Yog hais tias lub hauv paus thiab lo lus uas peb yuav *yeej tsis* overlap, [`copy_nonoverlapping`] yuav siv tau xwb.
///
/// `copy` yog semantically sib npaug rau C cov [`memmove`], tab sis, nrog rau lub cav txiav txim swapped.
/// Luam yuav siv sij hawm qhov chaw raws li yog hais tias tus bytes twb tau theej los ntawm `src` mus rau ib tug ib ntus array thiab ces tau theej los ntawm lub array rau `dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Tus cwj pwm yog undefined yog ib yam ntawm cov nram qab no tej yam kev mob yog ua txhaum:
///
/// * `src` yuav tsum [valid] rau nyeem ntawm `count * size_of::<T>()` bytes.
///
/// * `dst` yuav tsum yog [valid] rau sau ntawm `count * size_of::<T>()` bytes.
///
/// * Ob `src` thiab `dst` yuav tsum tau kom raws.
///
/// Zoo li [`read`], `copy` tsim ib tug Bitwise daim qauv ntawm `T`, tsis hais seb `T` yog [`Copy`].
/// Yog hais tias `T` yog tsis [`Copy`], siv ob lub qhov tseem ceeb nyob rau hauv lub cheeb tsam yuav pib thaum `*src` thiab hauv lub cheeb tsam yuav pib thaum `* dst` tau [violate memory safety][read-ownership].
///
///
/// Nco ntsoov tias txawm yog hais tias tus zoo theej loj ('suav * size_of: :<T>() ') Yog `0`, lub pointers yuav tsum uas tsis yog-thov thiab kom raws li.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Tsim ib qho Rust vector los ntawm qhov tsis zoo:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` yuav tsum tau kom raws li rau nws cov hom thiab uas tsis yog-zero.
/// /// * `ptr` yuav tsum siv tau rau nyeem ntawm `elts` contiguous ntsiab ntawm hom `T`.
/// /// * Cov ntsiab yuav tsum tsis txhob muab siv tom qab hu no muaj nuj nqi tshwj tsis yog tias `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // KEV RUAJ NTSEG: Peb qhov ua ntej xyuas kom ntseeg tau tias cov khoom kom haum thiab siv tau,
///     // thiab `Vec::with_capacity` ua kom muaj qhov chaw zoo los sau lawv.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // KEV RUAJ NTSEG: Peb tsim nws nrog no ntau npaum li cas muaj peev xwm ua ntej lawm,
///     // thiab `copy` dhau los tau pib ua cov khoom no.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Ua cov tshev tsuas yog nyob rau lub sij hawm mus dhia
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Tsis panicking kom codegen feem me me.
        abort();
    }*/

    // KEV RUAJ NTSEG: daim ntawv cog lus muaj kev nyab xeeb rau `copy` yuav tsum tau nqa los ntawm tus neeg hu.
    unsafe { copy(src, dst, count) }
}

/// Teem `count * size_of::<T>()` bytes ntawm lub cim xeeb pib thaum `dst` txog `val`.
///
/// `write_bytes` yog zoo li C lub [`memset`], tab sis teev `count * size_of::<T>()` bytes rau `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Tus cwj pwm yog undefined yog ib yam ntawm cov nram qab no tej yam kev mob yog ua txhaum:
///
/// * `dst` yuav tsum yog [valid] rau sau ntawm `count * size_of::<T>()` bytes.
///
/// * `dst` yuav tsum muaj kev sib thooj.
///
/// Tsis tas li ntawd, tus neeg hu yuav tsum xyuas kom meej tias sau ntawv `count * size_of::<T>()` bytes rau qhov muab cheeb tsam ntawm lub cim xeeb tau nyob rau hauv ib tug siv tau tus nqi ntawm `T`.
/// Siv ib cheeb tsam ntawm lub cim xeeb ntaus raws li ib tug `T` uas muaj ib tug tsis tseeb nqi ntawm `T` yog undefined tus cwj pwm.
///
/// Nco ntsoov tias txawm yog hais tias tus zoo theej loj ('suav * size_of: :<T>() ') Yog `0`, lub pointer yuav tsum uas tsis yog-thov thiab kom raws li.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Kev siv theem pib:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Tsim ib tug tsis tseeb nqi:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Txo lub txiaj ntsig yav dhau los los ntawm kev sau dua ntawm `Box<T>` nrog tus xaum khoob.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // Thaum no tus taw tes, siv los yog xa me nyuam rov `v` tau nyob rau hauv undefined tus cwj pwm.
/// // drop(v); // ERROR
///
/// // Txawm to `v` "uses" nws, thiab chaw pib yog undefined tus cwj pwm.
/// // mem::forget(v); // ERROR
///
/// // Qhov tseeb, `v` yog qhov tsis raug raws li hom pib txheej invariants, yog li *ib qho* kev ua haujlwm kov nws yog tus cwj pwm tsis paub tseeb.
/////
/// // cia v2 =v;//YUAM KEV
///
/// unsafe {
///     // Cia peb muab tso rau hauv qhov siv tau tus nqi
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Tam sim no lub thawv no zoo
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // KEV RUAJ NTSEG: kev ruaj ntseg daim ntawv cog lus rau `write_bytes` yuav tsum tau upheld los ntawm ib tus neeg hu.
    unsafe { write_bytes(dst, val, count) }
}