//! Trait implementations rau `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Kev nqes tes ua los ntawm cov hlua.
///
/// Cov hlua txiav xaj [lexicographically](Ord#lexicographical-comparison) los ntawm lawv cov byte qhov tseem ceeb.
/// Qhov no xaj Unicode code cov ntsiab lus raws li lawv cov haujlwm hauv cov kab cim kab ntawv.
/// Qhov no tsis tas yuav zoo tib yam li "alphabetical" kev txiav txim, uas sib txawv ntawm cov lus thiab thaj chaw.
/// Sorting hlua raws li kev lis kev cai-txais cov qauv yuav tsum tau chaw-tej ntaub ntawv uas yog nyob sab nraum lub Scope ntawm cov `str` hom.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Implements sib piv haujlwm rau cov hlua.
///
/// Cov hlua yuav piv [lexicographically](Ord#lexicographical-comparison) los ntawm lawv cov byte qhov tseem ceeb.
/// Qhov no muab cov ntsiab lus tsis raug cai ntawm Unicode nyob ntawm lawv txoj haujlwm hauv cov kab kos kab ntawv.
/// Qhov no tsis tas yuav zoo tib yam li "alphabetical" kev txiav txim, uas sib txawv ntawm cov lus thiab thaj chaw.
/// Sib piv cov hlua raws li kab lis kev cai-lees paub yuav tsum muaj cov ntaub ntawv hauv zos uas nyob sab nraud ntawm `str` hom.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Ua piv txwv slicing nrog syntax `&self[..]` lossis `&mut self[..]`.
///
/// Rov qab los ib tug ib nplais ntawm tag nrho cov hlua, ie, rov qab `&self` los yog `&mut self`.Sib npaug rau '&self [0 ..
/// len] `los yog`&mut tus kheej [0 ..
/// len]`.
/// Tsis zoo li lwm yam kev ua haujlwm indexing, qhov no tuaj yeem tsis txhob panic.
///
/// Qhov haujlwm no yog *O*(1).
///
/// Ua ntej 1.20.0, cov haujlwm ntsuas kev ua haujlwm tseem raug txhawb los ntawm kev siv ncaj qha `Index` thiab `IndexMut`.
///
/// Sib npaug `&self[0 .. len]` lossis `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Implements substring slicing nrog syntax `&self[begin .. end]` los yog `&mut self[begin .. end]`.
///
/// Rov qab los ib tug hlais cov muab txoj hlua los ntawm lub byte ntau ['begin`, `end`).
///
/// Qhov haujlwm no yog *O*(1).
///
/// Ua ntej 1.20.0, cov haujlwm ntsuas kev ua haujlwm tseem raug txhawb los ntawm kev siv ncaj qha `Index` thiab `IndexMut`.
///
/// # Panics
///
/// Panics yog `begin` los yog `end` tsis taw tes rau lub pib byte offset ntawm cov ua cim (raws li txhais los ntawm `is_char_boundary`), Yog hais tias `begin > end`, los yog hais tias `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // Cov no yuav panic:
/// // byte 2 nyob rau hauv `ö`:
/// // &S [2 ..3];
///
/// // byte 8 lies tsis pub dhau `老`&s [1 ..
/// // 8];
///
/// // byte 100 nyob sab nraud txoj hlua&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // KEV RUAJ NTSEG: tsuas yog khij tias `start` thiab `end` nyob ntawm tus ciam ciam av,
            // thiab peb dhau mus rau qhov kev nyab xeeb, yog li tus nqi xa rov qab los kuj yuav yog ib qho.
            // Peb kuj tau kuaj cov ciam ciam av, yog li qhov no siv tau UTF-8.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // KEV RUAJ NTSEG: tsuas yog khij tias `start` thiab `end` nyob ntawm tus ciam ciam av.
            // Peb paub tus pointer yog qhov tshwj xeeb vim tias peb tau txais los ntawm `slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // KEV RUAJ NTSEG: tus neeg hu guarantees uas `self` yog nyob rau hauv ciam teb ntawm `slice`
        // uas txaus siab rau txhua yam kev mob rau `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // KEV RUAJ NTSEG: saib cov lus pom rau `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary tshev hais tias cov index yog nyob rau hauv [0, .len()] tsis tau rov qab siv lub `get` li saum toj no, vim hais tias ntawm NLL teeb meem
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // KEV RUAJ NTSEG: tsuas yog khij tias `start` thiab `end` nyob ntawm tus ciam ciam av,
            // thiab peb dhau mus rau qhov kev nyab xeeb, yog li tus nqi xa rov qab los kuj yuav yog ib qho.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Ua piv txwv slicing nrog syntax `&self[.. end]` lossis `&mut self[.. end]`.
///
/// Rov ib tug hlais cov muab txoj hlua los ntawm lub byte ntau ['0`, `end`).
/// Sib npaug `&self[0 .. end]` lossis `&mut self[0 .. end]`.
///
/// Qhov haujlwm no yog *O*(1).
///
/// Ua ntej 1.20.0, cov haujlwm ntsuas kev ua haujlwm tseem raug txhawb los ntawm kev siv ncaj qha `Index` thiab `IndexMut`.
///
/// # Panics
///
/// Panics yog `end` tsis taw tes rau lub pib byte offset ntawm cov ua cim (raws li txhais los ntawm `is_char_boundary`), los yog hais tias `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // KEV RUAJ NTSEG: cia li mus soj ntsuam hais tias `end` yog rau ib tug char ciam,
            // thiab peb dhau mus rau qhov kev nyab xeeb, yog li tus nqi xa rov qab los kuj yuav yog ib qho.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // KEV RUAJ NTSEG: cia li mus soj ntsuam hais tias `end` yog rau ib tug char ciam,
            // thiab peb dhau mus rau qhov kev nyab xeeb, yog li tus nqi xa rov qab los kuj yuav yog ib qho.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // KEV RUAJ NTSEG: cia li mus soj ntsuam hais tias `end` yog rau ib tug char ciam,
            // thiab peb dhau mus rau qhov kev nyab xeeb, yog li tus nqi xa rov qab los kuj yuav yog ib qho.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Implements substring slicing nrog syntax `&self[begin ..]` los yog `&mut self[begin ..]`.
///
/// Rov qab los ib tug hlais cov muab txoj hlua los ntawm lub byte ntau ['begin`, `len`).Sib npaug rau '&self [pib ..
/// len] 'los yog'&Mut tus kheej [pib ..
/// len]`.
///
/// Qhov haujlwm no yog *O*(1).
///
/// Ua ntej 1.20.0, cov haujlwm ntsuas kev ua haujlwm tseem raug txhawb los ntawm kev siv ncaj qha `Index` thiab `IndexMut`.
///
/// # Panics
///
/// Panics yog `begin` tsis taw tes rau lub pib byte offset ntawm cov ua cim (raws li txhais los ntawm `is_char_boundary`), los yog hais tias `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // KEV RUAJ NTSEG: tsuas yog khij tias `start` nyob rau ntawm tus ciam ciam av,
            // thiab peb dhau mus rau qhov kev nyab xeeb, yog li tus nqi xa rov qab los kuj yuav yog ib qho.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // KEV RUAJ NTSEG: tsuas yog khij tias `start` nyob rau ntawm tus ciam ciam av,
            // thiab peb dhau mus rau qhov kev nyab xeeb, yog li tus nqi xa rov qab los kuj yuav yog ib qho.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // KEV RUAJ NTSEG: tus neeg hu guarantees uas `self` yog nyob rau hauv ciam teb ntawm `slice`
        // uas txaus siab rau txhua yam kev mob rau `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // KEV RUAJ NTSEG: zoo tib yam rau `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // KEV RUAJ NTSEG: tsuas yog khij tias `start` nyob rau ntawm tus ciam ciam av,
            // thiab peb dhau mus rau qhov kev nyab xeeb, yog li tus nqi xa rov qab los kuj yuav yog ib qho.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Ua piv txwv slicing nrog syntax `&self[begin ..= end]` lossis `&mut self[begin ..= end]`.
///
/// Rov qab ib feem ntawm txoj hlua muab los ntawm byte ntau yam [`begin`, `end`].Sib npaug rau `&self [begin .. end + 1]` lossis `&mut self[begin .. end + 1]`, tshwj tsis yog `end` muaj tus nqi siab tshaj plaws rau `usize`.
///
/// Qhov haujlwm no yog *O*(1).
///
/// # Panics
///
/// Panics yog `begin` tsis taw tes rau lub pib byte offset ntawm cov ua cim (raws li txhais los ntawm `is_char_boundary`), Yog hais tias `end` tsis taw tes rau qhov xaus byte offset ntawm cov ua cim (`end + 1` yog tog twg los ib tug pib byte offset los yog sib npaug rau `len`), Yog hais tias `begin > end`, lossis yog `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // KEV RUAJ NTSEG: tus neeg hu yuav tsum khaws daim ntawv cog lus muaj kev nyab xeeb rau `get_unchecked`.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // KEV RUAJ NTSEG: tus neeg hu yuav tsum khaws daim ntawv cog lus muaj kev nyab xeeb rau `get_unchecked_mut`.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Implements substring slicing nrog syntax `&self[..= end]` los yog `&mut self[..= end]`.
///
/// Rov ib tug hlais cov muab txoj hlua los ntawm lub byte ntau [0, `end`].
/// Sib npaug rau `&self [0 .. end + 1]`, tsuas yog tias `end` muaj nqi siab tshaj plaws rau `usize`.
///
/// Qhov haujlwm no yog *O*(1).
///
/// # Panics
///
/// Panics yog `end` tsis taw tes rau qhov xaus byte offset ntawm lub cim (`end + 1` yog ib qho kev pib byte offset raws li tau txhais los ntawm `is_char_boundary`, lossis sib npaug rau `len`), lossis yog `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // KEV RUAJ NTSEG: tus neeg hu yuav tsum khaws daim ntawv cog lus muaj kev nyab xeeb rau `get_unchecked`.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // KEV RUAJ NTSEG: tus neeg hu yuav tsum khaws daim ntawv cog lus muaj kev nyab xeeb rau `get_unchecked_mut`.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Txaws tus nqi ntawm txoj hlua
///
/// 'FromStr`lub [`from_str`] txoj kev no feem ntau yog siv implicitly, los ntawm [' str`] 's [`parse`] txoj kev.
/// Saib [`parse`] 's cov ntaub ntawv rau ua piv txwv.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` tsis muaj ib lub neej parameter, thiab yog li ntawd koj ua tau tsuas yog parse hom uas tsis muaj ib tug lub neej parameter lawv tus kheej.
///
/// Hauv lwm lo lus, koj tuaj yeem parse `i32` nrog `FromStr`, tab sis tsis yog `&i32`.
/// Koj tuaj yeem txheeb tus qauv uas muaj `i32`, tab sis tsis yog ib qho uas muaj `&i32`.
///
/// # Examples
///
/// Basic kev siv ntawm `FromStr` rau ib qho piv txwv `Point` hom:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// Qhov cuam tshuam yuam kev uas tuaj yeem xa rov qab los ntawm kev txheeb xyuas.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Parses ib txoj hlua `s` rov qab rau tus nqi ntawm hom no.
    ///
    /// Yog tias parsing ua tiav, rov qab tus nqi hauv [`Ok`], txwv tsis pub thaum txoj hlua tsis yog-nqa cov ntawv rov qab ua yuam kev tshwj xeeb rau sab hauv [`Err`].
    /// Cov kev ua yuam kev yam no yog hais rau kev siv ntawm cov trait.
    ///
    /// # Examples
    ///
    /// Basic pab nrog [`i32`], ib hom uas implements `FromStr`:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Parse ib tug `bool` los ntawm hlua.
    ///
    /// Yields ib lub `Result<bool, ParseBoolError>`, vim `s` yuav lossis tsis tuaj yeem yog parseable.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Nco tseg, feem ntau, txoj kev `.parse()` ntawm `str` yog qhov zoo dua.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}