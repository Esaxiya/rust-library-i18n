//! Txoj kev los tsim ib lub `str` los ntawm bytes hlais.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Converts ib tug hlais cov bytes rau ib txoj hlua hlais.
///
/// Ib tug hlua hlais ([`&str`]) yog ua los ntawm bytes ([`u8`]), thiab ib tug byte hlais ([`&[u8]`][byteslice]) yog ua los ntawm bytes, yog li no muaj nuj nqi hloov siab los ntseeg nruab nrab ntawm ob.
/// Tsis yog txhua txhua byte slices yog siv tau txoj hlua slices, txawm li cas los: [`&str`] yuav tsum tau hais tias nws yog siv tau UTF-8.
/// `from_utf8()` tshuaj xyuas kom paub meej tias lub bytes siv tau UTF-8, thiab tom qab ntawd hloov lub siab.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Yog tias koj paub tseeb tias daim byte hlais yog qhov siv tau UTF-8, thiab koj tsis xav kom tshwm sim tawm nyiaj siv ua haujlwm ntawm kev kuaj xyuas siv tau, muaj qhov tsis nyab xeeb ntawm txoj haujlwm no, [`from_utf8_unchecked`], uas muaj tus cwj pwm qub tab sis hla daim tshev.
///
///
/// Yog tias koj xav tau `String` hloov `&str`, xav txog [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Vim tias koj tuaj yeem muab pawg-faib `[u8; N]`, thiab koj tuaj yeem nqa ib qho [`&[u8]`][byteslice] ntawm nws, txoj haujlwm no yog ib txoj hauv kev muaj txoj hlua sib faib.Muaj ib qho piv txwv ntawm qhov no hauv qhov piv txwv hauv qab no.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Rov qab `Err` yog tias qhov hlaws tsis yog UTF-8 nrog cov lus piav qhia vim li cas qhov muab hlais tsis yog UTF-8.
///
/// # Examples
///
/// Kev siv theem pib:
///
/// ```
/// use std::str;
///
/// // qee qhov bytes, hauv vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Peb paub cov bytes yog siv tau, li ntawd, cia li siv `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Bytes tsis yog:
///
/// ```
/// use std::str;
///
/// // ib co invalid bytes, nyob rau hauv ib tug vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Saib cov docs rau [`Utf8Error`] kom paub meej ntxiv nyob rau hauv cov kev uas tsis muaj peev xwm yuav xa rov qab.
///
/// A "stack allocated string":
///
/// ```
/// use std::str;
///
/// // qee qhov bytes, hauv cov khoom sib faib
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Peb paub cov bytes yog siv tau, li ntawd, cia li siv `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // KEV RUAJ NTSEG: Cia li khiav siv tau.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Hloov pauv cov hlais ib qho sib xyaw ntawm bytes rau ib txoj kab sib hloov tau.
///
/// # Examples
///
/// Kev siv theem pib:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" raws li ib tug mutable vector
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Raws li peb paub cov bytes no siv tau, peb tuaj yeem siv `unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Bytes tsis yog:
///
/// ```
/// use std::str;
///
/// // Qee qhov tsis muaj tseeb bytes hauv ib qho hloov pauv vector
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Saib cov docs rau [`Utf8Error`] kom paub meej ntxiv nyob rau hauv cov kev uas tsis muaj peev xwm yuav xa rov qab.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // KEV RUAJ NTSEG: Cia li khiav siv tau.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Hloov siab cov hlais bytes rau ib txoj hlua sib txig uas tsis tas xyuas tias txoj hlua muaj cov UTF-8 siv tau.
///
/// Saib tus xov tooj nyab xeeb, [`from_utf8`], kom paub cov ntaub ntawv ntau ntxiv.
///
/// # Safety
///
/// Txoj haujlwm no tsis zoo vim tias nws tsis xyuas tias qhov bytes dhau mus rau nws yog qhov siv tau UTF-8.
/// Yog hais tias qhov no constraint yog ua txhaum, undefined tus cwj pwm tau, raws li tus so ntawm Rust assumes uas ['&str`] s yog siv tau UTF-8.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Kev siv theem pib:
///
/// ```
/// use std::str;
///
/// // qee qhov bytes, hauv vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // KEV RUAJ NTSEG: tus hu yuav tsum lav tias bytes `v` yog qhov tseem ceeb UTF-8.
    // Tsis tas li ntawd tso siab rau `&str` thiab `&[u8]` muaj tib lub txheej txheem.
    unsafe { mem::transmute(v) }
}

/// Hloov siab cov hlais bytes rau ib txoj hlua sib txuas yam tsis tau xyuas tias txoj hlua muaj cov UTF-8 siv tau;mutable version.
///
///
/// Saib qhov hloov tsis tau hloov, [`from_utf8_unchecked()`] rau cov lus qhia ntxiv.
///
/// # Examples
///
/// Kev siv theem pib:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // KEV RUAJ NTSEG: tus hu tuaj yuav tsum lav tias bytes `v`
    // yog siv tau UTF-8, yog li cov cam khwb cia rau `*mut str` muaj kev ruaj ntseg.
    // Tsis tas li, lub pointer dereference muaj kev nyab xeeb vim tias pointer los ntawm kev siv tau uas tau lees tias yuav siv tau rau cov ntawv sau.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}