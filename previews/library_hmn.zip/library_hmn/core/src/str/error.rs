//! Txhais hom utf8 yuam kev.

use crate::fmt;

/// Cov kev ua yuam kev uas tuaj yeem tshwm sim thaum sim los txhais cov qib ntawm [`u8`] raws li ib txoj hlua.
///
/// Xws li, `from_utf8` tsev neeg ntawm cov haujlwm thiab cov hau kev rau ob leeg [`String`] s thiab [`&str`] siv qhov yuam kev no, piv txwv.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// Qhov kev ua yuam kev ntawm txoj kev no tuaj yeem siv los tsim cov haujlwm zoo ib yam li `String::from_utf8_lossy` yam tsis muaj kev faib cov heap nco:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// Rov qab muab cov lej tso rau hauv txoj hlua muab rau txog uas qhov UTF-8 siv tau tau kuaj xyuas.
    ///
    /// Nws yog cov ntsiab lus siab tshaj plaws uas `from_utf8(&input[..index])` yuav rov `Ok(_)`.
    ///
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// use std::str;
    ///
    /// // ib co invalid bytes, nyob rau hauv ib tug vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 rov los Utf8Error
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // tus thib ob byte tsis nyob ntawm no
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// Muab ntau cov ntaub ntawv hais txog qhov tsis ua tiav:
    ///
    /// * `None`: qhov kawg ntawm lub tswv yim tau mus txog qhov kev npaj txhij txog.
    ///   `self.valid_up_to()` yog 1 txog 3 bytes los ntawm qhov kawg ntawm lub tswv yim.
    ///   Yog hais tias ib tug byte kwj (xws li ib cov ntaub ntawv los yog ib tug network socket) yog decoded incrementally, qhov no yuav yog ib tug siv tau `char` uas nws UTF-8 byte ib theem zuj zus yog ib ntau chunks.
    ///
    ///
    /// * `Some(len)`: npaj txhij txog byte tau ntsib.
    ///   Qhov ntev tau muab yog ntawm qhov tsis muaj tseeb byte kab uas pib ntawm qhov ntsuas muab los ntawm `valid_up_to()`.
    ///   Kev txiav txim siab yuav rov qab pib tom qab kab ntawv ntawd (tom qab tso [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD] X) thaum muaj kev ploj lawm.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// Ib qho yuam kev rov qab thaum tshawb xyuas ib qho `bool` siv [`from_str`] swb
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}