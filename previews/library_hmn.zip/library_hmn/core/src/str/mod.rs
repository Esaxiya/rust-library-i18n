//! Txoj hlua ntxias.
//!
//! Yog xav paub cov ntsiab lus ntau ntxiv, saib ntawm [`std::str`] module.
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. tawm ntawm ciam teb
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. pib <=kawg
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. cim tus ciam
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // pom cov xeeb ceem
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` yuav tsum muaj tsawg dua qhov len thiab lub thaj tsam pov thawj
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// Rov qhov ntev ntawm `self`.
    ///
    /// Qhov ntev yog nyob rau hauv bytes, tsis yog [`char`] s lossis graphemes.
    /// Hauv lwm lo lus, nws yuav tsis yog qhov uas tib neeg xav txog qhov ntev ntawm txoj hlua.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // suab nkauj f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// Rov `true` yog `self` muaj ib tug ntev ntawm xoom bytes.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Txheeb xyuas tias `Performance`-th byte yog thawj byte hauv UTF-8 code taw los sis xaus rau txoj hlua.
    ///
    ///
    /// Qhov pib thiab xaus ntawm txoj hlua (thaum `Performance== self.len()`) pom tau tias muaj ciam chaw.
    ///
    /// Rov `false` yog `index` yog ntau tshaj `self.len()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // pib ntawm `老`
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // ob byte ntawm `ö`
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // peb byte ntawm `老`
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 thiab len yeej ib txwm aws.
        // Xeem rau 0 kom meej meej kom nws tuaj yeem txhim kho daim tshev yooj yim thiab hla kev nyeem cov hlua cov ntaub ntawv rau qhov xwm txheej ntawd.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // Qhov no yog me ntsis cov khawv koob sib npaug mus rau: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// Hloov cov hlua ib qho rau ib qho ntawm daim nyias.
    /// Txhawm rau hloov lub byte hlais rov qab rau hauv ib txoj hlua hlais, siv [`from_utf8`] muaj nuj nqi.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // KEV RUAJ NTSEG: const suab vim hais tias peb transmute ob yam uas tib layout
        unsafe { mem::transmute(self) }
    }

    /// Hloov pauv txoj hlua sib txuas mus rau ib qho sib xyaw nrog byte hlais.
    ///
    /// # Safety
    ///
    /// Cov kev hem yuav tsum xyuas kom meej tias cov ntsiab lus ntawm cov hlais yog siv tau UTF-8 ua ntej lub qiv xaus thiab qhov pib `str` siv.
    ///
    ///
    /// Kev siv lub `str` uas nws cov ntsiab lus tsis raug UTF-8 yog qhov tsis muaj cwj pwm tsis zoo.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // KEV RUAJ NTSEG: tus cam los ntawm `&str` rau `&[u8]` muaj kev nyab xeeb txij thaum `str`
        // muaj tib lub layout li `&[u8]` (tsuas libstd yuav ua no guarantee).
        // Tus pointer dereference muaj kev nyab xeeb vim tias nws los ntawm kev siv hluav taws xob hloov uas tau lees tias yuav siv tau rau sau.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// Hloov txoj hlua ib qho rau ib tus pointer nyoos.
    ///
    /// Raws li txoj hlua slices yog ib tug hlais cov bytes, cov nqaij nyoos pointer cov ntsiab lus mus rau ib tug [`u8`].
    /// Lub pointer no yuav taw rau thawj daim byte ntawm txoj hlua hlais.
    ///
    /// Tus neeg hu yuav tsum xyuas kom meej tias tus xa xov xa rov qab yeej tsis tau sau rau.
    /// Yog tias koj xav hloov pauv cov ntsiab lus ntawm cov hlua hlaws, siv [`as_mut_ptr`].
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// Hloov pauv txoj hlua sib txuas mus rau lub pointer nyoos.
    ///
    /// Raws li txoj hlua slices yog ib tug hlais cov bytes, cov nqaij nyoos pointer cov ntsiab lus mus rau ib tug [`u8`].
    /// Lub pointer no yuav taw rau thawj daim byte ntawm txoj hlua hlais.
    ///
    /// Nws yog koj qhov kev lav phib xaj kom paub tseeb tias txoj hlua hlais tsuas tau hloov kho hauv txoj kev uas nws tseem siv tau UTF-8.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// Rov qab ib qho nyiaj ntawm `str`.
    ///
    /// Nov yog qhov kev xaiv tsis yog yias rau lub ntsiab lus `str`.
    /// Rov qab [`None`] thaum twg los ua qhov sib npaug ua haujlwm yuav panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // qhov ntsuas tsis yog ntawm UTF-8 kab txuas tus ciam
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // tawm ntawm ciam teb
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// Rov qab tau cov subslice hloov pauv ntawm `str`.
    ///
    /// Nov yog qhov kev xaiv tsis yog yias rau lub ntsiab lus `str`.
    /// Rov qab [`None`] thaum twg los ua qhov sib npaug ua haujlwm yuav panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // tseeb kav ntev
    /// assert!(v.get_mut(0..5).is_some());
    /// // tawm ntawm ciam teb
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// Rov ib tug tsi kuaj xyuas subslice ntawm `str`.
    ///
    /// Nov yog kev xaiv tau xaiv rau hauv `str`.
    ///
    /// # Safety
    ///
    /// Cov neeg hu ntawm lub luag haujlwm no tau lees paub tias cov kev txwv no tau txaus siab:
    ///
    /// * Qhov pib ntsuas pib yuav tsum tsis pub tshaj qhov ntsuas tom qab xaus;
    /// * Cov cim yuav tsum tsis pub dhau ib feem ntawm qhov kev hlais xub thawj;
    /// * Cov cim yuav tsum dag ntawm UTF-8 cov chaw sib lawv liag.
    ///
    /// Ua tsis tiav, qhov rov qab txoj hlua hlais tuaj yeem siv lub cim xeeb tsis raug lossis txhaum kev cai sib cuam tshuam los ntawm `str` hom.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // TXUJ CI: tus neeg hu yuav tsum khaws daim ntawv cog lus muaj kev nyab xeeb rau `get_unchecked`;
        // cov hlais yog dereferencable vim `self` yog qhov siv nyab xeeb.
        // Tus pointer rov qab muaj kev nyab xeeb vim tias impls ntawm `SliceIndex` yuav tsum tau lees tias nws yog.
        unsafe { &*i.get_unchecked(self) }
    }

    /// Rov qab tau cov kev hloov pauv, tsis tau yoo ntawm `str`.
    ///
    /// Nov yog kev xaiv tau xaiv rau hauv `str`.
    ///
    /// # Safety
    ///
    /// Cov neeg hu ntawm lub luag haujlwm no tau lees paub tias cov kev txwv no tau txaus siab:
    ///
    /// * Qhov pib ntsuas pib yuav tsum tsis pub tshaj qhov ntsuas tom qab xaus;
    /// * Cov cim yuav tsum tsis pub dhau ib feem ntawm qhov kev hlais xub thawj;
    /// * Cov cim yuav tsum dag ntawm UTF-8 cov chaw sib lawv liag.
    ///
    /// Ua tsis tiav, qhov rov qab txoj hlua hlais tuaj yeem siv lub cim xeeb tsis raug lossis txhaum kev cai sib cuam tshuam los ntawm `str` hom.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // TXUJ CI: tus neeg hu yuav tsum khaws daim ntawv cog lus muaj kev nyab xeeb rau `get_unchecked_mut`;
        // cov hlais yog dereferencable vim `self` yog qhov siv nyab xeeb.
        // Tus pointer rov qab muaj kev nyab xeeb vim tias impls ntawm `SliceIndex` yuav tsum tau lees tias nws yog.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// Tsim ib txoj hlua hlais los ntawm lwm txoj hlua hlais, bypassing muaj kev ruaj ntseg cov tshev mis.
    ///
    /// Qhov no feem ntau tsis pom zoo, siv nrog ceev faj!Txhawm rau kom muaj kev nyab xeeb ntxiv saib [`str`] thiab [`Index`].
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// Daim tshiab tshiab no mus ntawm `begin` rau `end`, suav nrog `begin` tab sis tsis suav nrog `end`.
    ///
    /// Yog xav tau ib tug mutable hlua hlais xwb, saib cov [`slice_mut_unchecked`] txoj kev.
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// Cov neeg hu ntawm lub luag haujlwm no tau lees paub tias peb qho kev lees paub ua ntej yog txaus siab:
    ///
    /// * `begin` yuav tsum tsis pub tshaj `end`.
    /// * `begin` thiab `end` yuav tsum byte txaus qhia nyob rau hauv txoj hlua hlais.
    /// * `begin` thiab `end` yuav tsum pw ntawm UTF-8 kab sib lawv liag.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // TXUJ CI: tus neeg hu yuav tsum khaws daim ntawv cog lus muaj kev nyab xeeb rau `get_unchecked`;
        // cov hlais yog dereferencable vim `self` yog qhov siv nyab xeeb.
        // Tus pointer rov qab muaj kev nyab xeeb vim tias impls ntawm `SliceIndex` yuav tsum tau lees tias nws yog.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// Tsim ib txoj hlua hlais los ntawm lwm txoj hlua hlais, bypassing muaj kev ruaj ntseg cov tshev mis.
    /// Qhov no yog feem ntau tsis pom zoo, siv rau cov kev ceev faj!Txhawm rau kom muaj kev nyab xeeb ntxiv saib [`str`] thiab [`IndexMut`].
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// Daim tshiab tshiab no mus ntawm `begin` rau `end`, suav nrog `begin` tab sis tsis suav nrog `end`.
    ///
    /// Yog xav tau ib immutable hlua hlais xwb, saib cov [`slice_unchecked`] txoj kev.
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// Cov neeg hu ntawm lub luag haujlwm no tau lees paub tias peb qho kev lees paub ua ntej yog txaus siab:
    ///
    /// * `begin` yuav tsum tsis pub tshaj `end`.
    /// * `begin` thiab `end` yuav tsum byte txaus qhia nyob rau hauv txoj hlua hlais.
    /// * `begin` thiab `end` yuav tsum pw ntawm UTF-8 kab sib lawv liag.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // TXUJ CI: tus neeg hu yuav tsum khaws daim ntawv cog lus muaj kev nyab xeeb rau `get_unchecked_mut`;
        // cov hlais yog dereferencable vim `self` yog qhov siv nyab xeeb.
        // Tus pointer rov qab muaj kev nyab xeeb vim tias impls ntawm `SliceIndex` yuav tsum tau lees tias nws yog.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// Faib ib txoj hlua ib sab rau ob qho ntawm qhov ntsuas.
    ///
    /// Kev sib cav, `mid`, yuav tsum yog lub byte offset los ntawm qhov pib ntawm txoj hlua.
    /// Nws kuj tseem yuav tsum nyob ntawm tus ciam ntawm UTF-8 code point.
    ///
    /// Lub ob slices rov qab mus rau ntawm qhov pib ntawm txoj hlua hlais rau `mid`, thiab los ntawm `mid` mus rau thaum xaus ntawm txoj hlua hlais.
    ///
    /// Txhawm rau kom hloov cov hlua sib hloov tau, saib [`split_at_mut`] tus qauv.
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics yog tias `mid` tsis nyob rau ntawm UTF-8 tus lej chaw nyob tus ciam, lossis yog tias dhau lawm qhov kawg ntawm tus lej kawg ntawm cov kab txiav.
    ///
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary cov tshev mis uas qhov ntsuas yog nyob rau hauv [0, .len()]
        if self.is_char_boundary(mid) {
            // KEV RUAJ NTSEG: tsuas yog khij tias `mid` yog nyob ntawm tus ciam ciam av.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Faib ib txoj hlua sib hloov rau hauv ob ntawm qhov ntsuas.
    ///
    /// Kev sib cav, `mid`, yuav tsum yog lub byte offset los ntawm qhov pib ntawm txoj hlua.
    /// Nws kuj tseem yuav tsum nyob ntawm tus ciam ntawm UTF-8 code point.
    ///
    /// Lub ob slices rov qab mus rau ntawm qhov pib ntawm txoj hlua hlais rau `mid`, thiab los ntawm `mid` mus rau thaum xaus ntawm txoj hlua hlais.
    ///
    /// Txhawm rau kom tsis tuaj yeem hloov txoj hlua hlais tawm, saib [`split_at`] tus qauv.
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics yog tias `mid` tsis nyob rau ntawm UTF-8 tus lej chaw nyob tus ciam, lossis yog tias dhau lawm qhov kawg ntawm tus lej kawg ntawm cov kab txiav.
    ///
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary cov tshev mis uas qhov ntsuas yog nyob rau hauv [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // KEV RUAJ NTSEG: tsuas yog khij tias `mid` yog nyob ntawm tus ciam ciam av.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Xa rov qab rau tus ntsuas khoom sab rau [`char`] ntawm txoj hlua hlais.
    ///
    /// Raws li txoj hlua hlaws hlaws muaj qhov siv tau UTF-8, peb tuaj yeem them los ntawm txoj hlua hlais los ntawm [`char`].
    /// Hom no rov los xws li tus ntsuas.
    ///
    /// Nws tseem ceeb heev kom nco ntsoov tias [`char`] sawv cev rau ntawm Unicode Scalar Nqi, thiab tej zaum yuav tsis phim koj lub tswv yim ntawm 'character' yog dab tsi.
    ///
    /// Kev sib nkag siab dhau grapheme pawg tej zaum yuav yog qhov koj xav tau.
    /// Qhov no functionality yog tsis yog muab los ntawm Rust tus txheem tsev qiv ntawv, xyuas crates.io xwb.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// Nco ntsoov, [`char`] yuav tsis phim koj txoj kev xav txog cov cim:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // tsis 'y̆'
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// Rov ib iterator hla lub ['char`] s ntawm ib txoj hlua hlais, thiab lawv txoj haujlwm.
    ///
    /// Raws li txoj hlua hlaws hlaws muaj qhov siv tau UTF-8, peb tuaj yeem them los ntawm txoj hlua hlais los ntawm [`char`].
    /// Cov qauv no rov los ntsuas dua rau ntawm ob qho no [`char`], nrog rau lawv txoj haujlwm byte.
    ///
    /// Tus tsim cov txaws txiav tuples.Txoj haujlwm yog thawj, [`char`] yog zaum ob.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// Nco ntsoov, [`char`] yuav tsis phim koj txoj kev xav txog cov cim:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // tsis yog (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // cim rau 3 ntawm no, lub cim kawg coj ob bytes
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// Ib iterator hla lub bytes ntawm ib txoj hlua hlais.
    ///
    /// Raws li ib txoj hlua hlais muaj ib theem ntawm bytes, peb yuav iterate los ntawm ib txoj hlua hlais los ntawm byte.
    /// Hom no rov los xws li tus ntsuas.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// Sib phua ib txoj hlua txiav los ntawm whitespace.
    ///
    /// Tus tsim tawm rov qab yuav rov qab cov hlua hlais uas tau ncua ntawm cov hlua ib txwm hlais, sib cais los ntawm txhua qhov nyiaj tsis pub dawb.
    ///
    ///
    /// 'Whitespace' yog txhais raws li cov lus ntawm Unicode Derived Core Property `White_Space`.
    /// Yog tias koj tsuas xav tau phua rau ntawm ASCII whitespace xwb, siv [`split_ascii_whitespace`].
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Txhua qhov chaw tsis muaj kev txiav txim siab yog:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// Sib cais txoj hlua txiav los ntawm ASCII whitespace.
    ///
    /// Tus tsim tawm rov qab yuav rov qab cov hlua hlais uas yog cov hlais ntawm cov hlua ib txwm hlais, sib cais los ntawm txhua qhov nyiaj ntawm ASCII whitespace.
    ///
    ///
    /// Yuav kom phua los ntawm Unicode `Whitespace` xwb, siv [`split_whitespace`].
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Txhua yam ntawm ASCII whitespace raug txiav txim siab:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// Ib iterator tshaj cov kab ntawm ib txoj hlua, raws li txoj hlua slices.
    ///
    /// Cov kab tiav tas nrog txoj kab tshiab (`\n`) lossis carriage xa rov qab nrog kab noj (`\r\n`).
    ///
    /// Kab ntawv kawg xaus yog xaiv tau.
    /// Txoj hlua uas xaus nrog txoj kab kawg yuav xaus rov qab los ua tib txoj kab li ib txoj hlua sib txawv uas tsis muaj txoj kab kawg.
    ///
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// Kab kawg tsis tas yuav tsum muaj:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// Tus ntsuas pa hla ntawm kab ntawm txoj hlua.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// Rov ib iterator ntawm `u16` tshaj txoj hlua encoded li UTF-16.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// Rov qab `true` yog tias cov qauv muab ntais ntawv ncua ntu ntawm txoj hlua hlais.
    ///
    /// Rov qab `false` yog tias nws tsis muaj.
    ///
    /// [pattern] tuaj yeem yog `&str`, [`char`], ib qho sib cais ntawm [`char`] s, lossis ua haujlwm lossis kaw uas txiav txim siab yog qhov cim tus cwj pwm.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// Rov qab `true` yog tias cov qauv muab tau phim cov kab ua ntej ntawm txoj hlua txiav.
    ///
    /// Rov qab `false` yog tias nws tsis muaj.
    ///
    /// [pattern] tuaj yeem yog `&str`, [`char`], ib qho sib cais ntawm [`char`] s, lossis ua haujlwm lossis kaw uas txiav txim siab yog qhov cim tus cwj pwm.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// Rov `true` yog hais tias tus muab cov qauv ntais ntawv ib tug tom qab ntawm no hlua hlais.
    ///
    /// Rov qab `false` yog tias nws tsis muaj.
    ///
    /// [pattern] tuaj yeem yog `&str`, [`char`], ib qho sib cais ntawm [`char`] s, lossis ua haujlwm lossis kaw uas txiav txim siab yog qhov cim tus cwj pwm.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// Rov qab los byte index ntawm thawj lub cim ntawm txoj hlua hlais uas phim cov qauv.
    ///
    /// Rov qab [`None`] yog tias tus qauv tsis phim.
    ///
    /// [pattern] tuaj yeem yog `&str`, [`char`], ib qho sib cais ntawm [`char`] s, lossis ua haujlwm lossis kaw uas txiav txim siab yog qhov cim tus cwj pwm.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Cov qauv yooj yim:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// Ntau cov qauv dhau los uas siv cov ntsiab lus-free style thiab kaw:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// Tsis pom tus qauv:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// Rov qab los rau byte index rau thawj lub cim ntawm txoj cai sib phim ntawm cov qauv hauv txoj hlua sib dhos no.
    ///
    /// Rov qab [`None`] yog tias tus qauv tsis phim.
    ///
    /// [pattern] tuaj yeem yog `&str`, [`char`], ib qho sib cais ntawm [`char`] s, lossis ua haujlwm lossis kaw uas txiav txim siab yog qhov cim tus cwj pwm.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Cov qauv yooj yim:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// Ntau cov qauv dhau los nrog kev kaw:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// Tsis pom tus qauv:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// Tus ntsuas pa hla txoj kab ntawm txoj hlua khi, sib cais los ntawm cov cim sib luag los ntawm tus qauv.
    ///
    /// [pattern] tuaj yeem yog `&str`, [`char`], ib qho sib cais ntawm [`char`] s, lossis ua haujlwm lossis kaw uas txiav txim siab yog qhov cim tus cwj pwm.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Tus cwj pwm coj
    ///
    /// Tus xa rov qab yuav yog [`DoubleEndedIterator`] yog tias tus qauv tso cai rau rov qab tshawb thiab forward/reverse kev tshawb nrhiav cov khoom tib yam.
    /// Qhov no muaj tseeb rau, piv txwv li, [`char`], tab sis tsis yog rau `&str`.
    ///
    /// Yog tias tus qauv tso cai rau kev tshawb nrhiav rov qab tab sis nws cov txiaj ntsig yuav txawv ntawm kev tshawb nrhiav tom ntej, [`rsplit`] txoj kev tuaj yeem siv.
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// Cov qauv yooj yim:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// Yog hais tias qhov txawv yog ib tug hlais cov chars, phua rau txhua tshwm sim ntawm ib yam ntawm cov cim:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// Tus qauv ntau dua, siv kaw:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// Yog hais tias ib txoj hlua muaj ntau yam contiguous separators, koj yuav mus nrog tas cov hlua nyob rau hauv lub tso zis:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Cov sib cais sib cais tau sib cais los ntawm txoj hlua khoob.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// Cov cais cais thaum pib lossis xaus ntawm ib txoj hlua yog cov neeg nyob ze ntawm txoj hlua khoob.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// Thaum lub empty txoj hlua yog siv raws li ib tug separator, nws cais txhua txhua tus ua cim nyob rau hauv txoj hlua, nrog rau thaum pib thiab thaum xaus ntawm txoj hlua.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// Cov khoom sib cais sib cais tuaj yeem ua rau qhov kev xav tsis txaus ntseeg thaum whitespace siv raws li lub cais.Tus lej no yog qhov tseeb:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Nws ua _not_ muab rau koj:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// Siv [`split_whitespace`] rau qhov kev coj cwj pwm no.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// Tus ntsuas pa hla txoj kab ntawm txoj hlua khi, sib cais los ntawm cov cim sib luag los ntawm tus qauv.
    /// Cov neeg sib txawv ntawm tus kav tsim tawm los ntawm `split` nyob rau hauv uas `split_inclusive` tawm qhov sib txuam ib feem ua tus terminator ntawm lub raj.
    ///
    ///
    /// [pattern] tuaj yeem yog `&str`, [`char`], ib qho sib cais ntawm [`char`] s, lossis ua haujlwm lossis kaw uas txiav txim siab yog qhov cim tus cwj pwm.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// Yog hais tias lub xeem caij ntawm txoj hlua yog matched, uas caij yuav tau suav hais tias yog Terminator ntawm lub ua ntej substring.
    /// Txoj hlua yuav yog qhov khoom kawg uas rov los ntawm tus kav.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// Tus ntsuas pa hla txoj kab ntawm txoj hlua muab txoj kab sib cais, sib cais los ntawm cov cim sib luag los ntawm tus qauv thiab ua tau nyob hauv qhov kev txiav txim rov qab.
    ///
    /// [pattern] tuaj yeem yog `&str`, [`char`], ib qho sib cais ntawm [`char`] s, lossis ua haujlwm lossis kaw uas txiav txim siab yog qhov cim tus cwj pwm.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Tus cwj pwm coj
    ///
    /// Tus xa rov qab yuav tsum tau hais tias tus qauv txhawb txoj kev tshawb nrhiav rov qab, thiab nws yuav yog [`DoubleEndedIterator`] yog tias forward/reverse tshawb fawb yoog tib yam.
    ///
    ///
    /// Rau iterating los ntawm pem hauv ntej, lub [`split`] txoj kev yuav siv tau.
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// Cov qauv yooj yim:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// Tus qauv ntau dua, siv kaw:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// Tus ntsuas pa hla txoj hauv qab ntawm txoj kab muab txoj kab txiav, sib cais los ntawm cov cim sib luag los ntawm tus qauv.
    ///
    /// [pattern] tuaj yeem yog `&str`, [`char`], ib qho sib cais ntawm [`char`] s, lossis ua haujlwm lossis kaw uas txiav txim siab yog qhov cim tus cwj pwm.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Sib npaug rau [`split`], tshwj tsis yog tias txoj hlua qis qis yog hla yog tias khoob.
    ///
    /// [`split`]: str::split
    ///
    /// Hom no tuaj yeem siv rau cov hlua cov ntaub ntawv uas yog _terminated_, es tsis yog _separated_ los ntawm tus qauv.
    ///
    /// # Tus cwj pwm coj
    ///
    /// Tus xa rov qab yuav yog [`DoubleEndedIterator`] yog tias tus qauv tso cai rau rov qab tshawb thiab forward/reverse kev tshawb nrhiav cov khoom tib yam.
    /// Qhov no muaj tseeb rau, piv txwv li, [`char`], tab sis tsis yog rau `&str`.
    ///
    /// Yog tias tus qauv tso cai rau kev tshawb nrhiav rov qab tab sis nws cov txiaj ntsig yuav txawv ntawm kev tshawb nrhiav tom ntej, [`rsplit_terminator`] txoj kev tuaj yeem siv.
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// Ib iterator tshaj substrings ntawm `self`, sib cais los ntawm cov cim sib phim los ntawm ib tug qauv thiab yielded nyob rau hauv rov qab kev txiav txim.
    ///
    /// [pattern] tuaj yeem yog `&str`, [`char`], ib qho sib cais ntawm [`char`] s, lossis ua haujlwm lossis kaw uas txiav txim siab yog qhov cim tus cwj pwm.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Sib npaug rau [`split`], tshwj tsis yog tias txoj hlua qis qis yog hla yog tias khoob.
    ///
    /// [`split`]: str::split
    ///
    /// Hom no tuaj yeem siv rau cov hlua cov ntaub ntawv uas yog _terminated_, es tsis yog _separated_ los ntawm tus qauv.
    ///
    /// # Tus cwj pwm coj
    ///
    /// Tus xa rov qab yuav tsum tau hais tias tus qauv txhawb txoj kev tshawb nrhiav thim rov qab, thiab nws yuav yog ob zaug tiav yog tias forward/reverse tshawb fawb yoog tib yam.
    ///
    ///
    /// Rau iterating los ntawm pem hauv ntej, lub [`split_terminator`] txoj kev yuav siv tau.
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// Ib iterator tshaj substrings ntawm qhov muab txoj hlua hlais, sib cais los ntawm ib tug qauv, txwv rau rov qab rau ntawm cov `n` khoom.
    ///
    /// Yog tias `n` substings raug xa rov qab, tom qab kawg kab (`n`th sab hauv qab) yuav muaj cov seem ntawm txoj hlua.
    ///
    /// [pattern] tuaj yeem yog `&str`, [`char`], ib qho sib cais ntawm [`char`] s, lossis ua haujlwm lossis kaw uas txiav txim siab yog qhov cim tus cwj pwm.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Tus cwj pwm coj
    ///
    /// Cov rov qab iterator yuav tsis tau muab ob npaug rau lawm, vim hais tias nws yog tsis npaum los pab txhawb.
    ///
    /// Yog tias tus qauv tso cai rau kev tshawb nrhiav rov qab, [`rsplitn`] tus qauv siv tau.
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// Cov qauv yooj yim:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// Tus qauv ntau dua, siv kaw:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// Tus ntsuas pa hla txoj kab ntawm txoj hlua no, sib cais los ntawm tus qauv, pib ntawm qhov kawg ntawm txoj hlua, txwv tsis pub rov qab los ntawm cov khoom feem ntau `n`.
    ///
    ///
    /// Yog tias `n` substings raug xa rov qab, tom qab kawg kab (`n`th sab hauv qab) yuav muaj cov seem ntawm txoj hlua.
    ///
    /// [pattern] tuaj yeem yog `&str`, [`char`], ib qho sib cais ntawm [`char`] s, lossis ua haujlwm lossis kaw uas txiav txim siab yog qhov cim tus cwj pwm.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Tus cwj pwm coj
    ///
    /// Cov rov qab iterator yuav tsis tau muab ob npaug rau lawm, vim hais tias nws yog tsis npaum los pab txhawb.
    ///
    /// Rau kev sib cais los ntawm sab xub ntiag, txoj kev [`splitn`] tuaj yeem siv tau.
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// Cov qauv yooj yim:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// Tus qauv ntau dua, siv kaw:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// Sib cais txoj hlua ntawm thawj qhov tshwm sim ntawm daim ntawv qhia kev txiav txim siab thiab xa rov qab ua ntej ua ntej delimiter thiab tom qab tom qab delimiter.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// Sib cais txoj hlua ntawm qhov tshwm sim zaum kawg ntawm kev sau tseg ua ntej thiab rov qab los ua ntej ua ntej delimiter thiab tom qab tom qab delimiter.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// Tus txhuam tawm hla qhov ntais ntawv qhov sib luag ntawm cov qauv hauv qhov muab txoj hlua khi.
    ///
    /// [pattern] tuaj yeem yog `&str`, [`char`], ib qho sib cais ntawm [`char`] s, lossis ua haujlwm lossis kaw uas txiav txim siab yog qhov cim tus cwj pwm.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Tus cwj pwm coj
    ///
    /// Tus xa rov qab yuav yog [`DoubleEndedIterator`] yog tias tus qauv tso cai rau rov qab tshawb thiab forward/reverse kev tshawb nrhiav cov khoom tib yam.
    /// Qhov no muaj tseeb rau, piv txwv li, [`char`], tab sis tsis yog rau `&str`.
    ///
    /// Yog hais tias tus qauv tso cai rau ib tug rov qab nrhiav, tiam sis nws tau yuav txawv los ntawm ib tug rau pem hauv ntej search, lub [`rmatches`] txoj kev yuav siv tau.
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// Tus ntsuas pa hla qhov phom sij disjoint ntawm tus qauv hauv txoj hlua khi no, tau txiav txim kom rov qab.
    ///
    /// [pattern] tuaj yeem yog `&str`, [`char`], ib qho sib cais ntawm [`char`] s, lossis ua haujlwm lossis kaw uas txiav txim siab yog qhov cim tus cwj pwm.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Tus cwj pwm coj
    ///
    /// Tus xa rov qab yuav tsum tau hais tias tus qauv txhawb txoj kev tshawb nrhiav rov qab, thiab nws yuav yog [`DoubleEndedIterator`] yog tias forward/reverse tshawb fawb yoog tib yam.
    ///
    ///
    /// Rau iterating los ntawm sab xub ntiag, [`matches`] txoj kev tuaj yeem siv tau.
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// Tus ntsuas pa hla lub disjoint ntais ntawv ntawm cov qauv hauv cov hlua no nrog rau qhov ntsuas uas pib qhov sib tw pib.
    ///
    /// Rau cov ntais ntawv ntawm `pat` nyob rau hauv `self` uas sib tshooj, tsuas yog qhov ntsuas tau coj los ua thawj qhov kev sib tw rov qab.
    ///
    /// [pattern] tuaj yeem yog `&str`, [`char`], ib qho sib cais ntawm [`char`] s, lossis ua haujlwm lossis kaw uas txiav txim siab yog qhov cim tus cwj pwm.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Tus cwj pwm coj
    ///
    /// Tus xa rov qab yuav yog [`DoubleEndedIterator`] yog tias tus qauv tso cai rau rov qab tshawb thiab forward/reverse kev tshawb nrhiav cov khoom tib yam.
    /// Qhov no muaj tseeb rau, piv txwv li, [`char`], tab sis tsis yog rau `&str`.
    ///
    /// Yog tias tus qauv tso cai rau kev tshawb nrhiav rov qab tab sis nws cov txiaj ntsig yuav txawv ntawm kev tshawb nrhiav tom ntej, [`rmatch_indices`] txoj kev tuaj yeem siv.
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // tsuas yog thawj `aba`
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// Tus ntsuas pa hla lub disjoint ntais ntawv ntawm cov qauv tsis pub dhau `self`, tawm suab hauv kev txiav txim rov qab nrog rau qhov ntsuas ntawm qhov phim.
    ///
    /// Rau qhov yuam kev ntawm `pat` hauv `self` uas sib tshooj, tsuas yog tus indices coj mus rau qhov kawg match yog xa rov qab.
    ///
    /// [pattern] tuaj yeem yog `&str`, [`char`], ib qho sib cais ntawm [`char`] s, lossis ua haujlwm lossis kaw uas txiav txim siab yog qhov cim tus cwj pwm.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Tus cwj pwm coj
    ///
    /// Tus xa rov qab yuav tsum tau hais tias tus qauv txhawb txoj kev tshawb nrhiav rov qab, thiab nws yuav yog [`DoubleEndedIterator`] yog tias forward/reverse tshawb fawb yoog tib yam.
    ///
    ///
    /// Rau iterating los ntawm pem hauv ntej, lub [`match_indices`] txoj kev yuav siv tau.
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // tsuas kawg `aba`
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// Rov qab txoj hlua hlais nrog rau kev coj thiab taug kev qhov chaw tshem tawm.
    ///
    /// 'Whitespace' yog txhais raws li cov lus ntawm Unicode Derived Core Property `White_Space`.
    ///
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// Rov qab ib txoj hlua hlais nrog cov whitespace tshem tawm.
    ///
    /// 'Whitespace' yog txhais raws li cov lus ntawm Unicode Derived Core Property `White_Space`.
    ///
    /// # Phau ntawv kev taw qhia
    ///
    /// Txoj hlua yog ib theem ntawm bytes.
    /// `start` hauv cov ntsiab lus teb no txhais tau tias yog thawj txoj haujlwm ntawm qhov ntawd byte hlua;rau sab laug rau sab xis xws li lus Askiv lossis Lavxias, qhov no yuav tau sab laug, thiab rau cov lus sab xis mus rau sab xis xws li Arabic lossis Hebrew, qhov no yuav yog rau sab xis.
    ///
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// Rov qab txoj hlua hlais nrog cov kab yuav raug tshem tawm.
    ///
    /// 'Whitespace' yog txhais raws li cov lus ntawm Unicode Derived Core Property `White_Space`.
    ///
    /// # Phau ntawv kev taw qhia
    ///
    /// Txoj hlua yog ib theem ntawm bytes.
    /// `end` hauv cov ntsiab lus no txhais tau tias yog qhov kawg ntawm txoj kab ntawd byte;rau ib tug tshuav-rau-txoj cai cov lus zoo li lus Askiv los yog Lavxias teb sab, qhov no yuav sab xis, thiab rau txoj kev-rau-laug hom lus xws li Arabic los yog Hebrew, qhov no yuav tsum yog tus sab laug.
    ///
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// Rov qab ib txoj hlua hlais nrog cov whitespace tshem tawm.
    ///
    /// 'Whitespace' yog txhais raws li cov lus ntawm Unicode Derived Core Property `White_Space`.
    ///
    /// # Phau ntawv kev taw qhia
    ///
    /// Txoj hlua yog ib theem ntawm bytes.
    /// 'Left' nyob rau hauv qhov ntsiab lus teb txhais tau tias cov thawj txoj hauj lwm ntawm uas byte hlua;rau ib hom lus zoo li Arabic los yog Hebrew uas yog 'txoj cai mus rau sab laug' es 'sab laug rau xis', qhov no yuav tsum yog tus _right_ sab, tsis yog tus sab laug.
    ///
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// Rov qab txoj hlua hlais nrog cov kab yuav raug tshem tawm.
    ///
    /// 'Whitespace' yog txhais raws li cov lus ntawm Unicode Derived Core Property `White_Space`.
    ///
    /// # Phau ntawv kev taw qhia
    ///
    /// Txoj hlua yog ib theem ntawm bytes.
    /// 'Right' hauv cov ntsiab lus no txhais tau tias yog qhov kawg ntawm txoj kab ntawd byte;rau ib hom lus zoo li Arabic los yog Hebrew uas yog 'txoj cai mus rau sab laug' es 'sab laug rau xis', qhov no yuav tsum yog tus _left_ sab, tsis ntawm txoj cai.
    ///
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// Rov qab muab txoj hlua ib feem nrog txhua yam lus tso ua ntej thiab tom qab uas phim tus qauv raug tshem tawm ntau zaus.
    ///
    /// Cov [pattern] tuaj yeem yog [`char`], ib qho sib cais ntawm [`char`] s, lossis ua haujlwm lossis kaw uas txiav txim siab yog qhov cim tus cwj pwm.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Cov qauv yooj yim:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// Tus qauv ntau dua, siv kaw:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // Nco ntsoov qhov kev paub ntxov tshaj plaws, muab kho rau hauv qab no yog
            // zaum kawg nkaus sib txawv
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // KEV RUAJ NTSEG: `Searcher` yog lub npe paub kom rov qab muaj qhov ntsuas tau.
        unsafe { self.get_unchecked(i..j) }
    }

    /// Rov qab txoj hlua ib txoj hlua nrog txhua lo lus ua ntej uas phim tus qauv raug tshem tawm ntau zaus.
    ///
    /// [pattern] tuaj yeem yog `&str`, [`char`], ib qho sib cais ntawm [`char`] s, lossis ua haujlwm lossis kaw uas txiav txim siab yog qhov cim tus cwj pwm.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Phau ntawv kev taw qhia
    ///
    /// Txoj hlua yog ib theem ntawm bytes.
    /// `start` hauv cov ntsiab lus teb no txhais tau tias yog thawj txoj haujlwm ntawm qhov ntawd byte hlua;rau sab laug rau sab xis xws li lus Askiv lossis Lavxias, qhov no yuav tau sab laug, thiab rau cov lus sab xis mus rau sab xis xws li Arabic lossis Hebrew, qhov no yuav yog rau sab xis.
    ///
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // KEV RUAJ NTSEG: `Searcher` yog lub npe paub kom rov qab muaj qhov ntsuas tau.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// Rov qab ib txoj hlua hlais nrog cov kab sau ua ntej tshem tawm.
    ///
    /// Yog tias txoj hlua pib nrog tus qauv `prefix`, rov qab los ua haujlwm tom qab ua ntej sau, qhwv hauv `Some`.
    /// Tsis zoo li `trim_start_matches`, hom no tshem tawm cov tsiaj ntawv ua ntej ib zaug.
    ///
    /// Yog tias txoj hlua tsis pib nrog `prefix`, rov `None`.
    ///
    /// [pattern] tuaj yeem yog `&str`, [`char`], ib qho sib cais ntawm [`char`] s, lossis ua haujlwm lossis kaw uas txiav txim siab yog qhov cim tus cwj pwm.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// Rov qab ib txoj hlua txiav nrog cov tsiaj ntawv tshem tom qab.
    ///
    /// Yog tias txoj hlua xaus nrog tus qauv `suffix`, rov qab muab txoj hlua khi ua ntej tom kawg, qhwv hauv `Some`.
    /// Tsis zoo li `trim_end_matches`, cov qauv no tshem tawm cov tsiaj ntawv tom kawg ua tiav ib zaug.
    ///
    /// Yog hais tias cov hlua tsis xaus nrog `suffix`, rov `None`.
    ///
    /// [pattern] tuaj yeem yog `&str`, [`char`], ib qho sib cais ntawm [`char`] s, lossis ua haujlwm lossis kaw uas txiav txim siab yog qhov cim tus cwj pwm.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// Rov qab muab txoj hlua ib txwm nrog txhua cov lus sib dhos uas phim tus qauv tshem tawm ntau zaus.
    ///
    /// [pattern] tuaj yeem yog `&str`, [`char`], ib qho sib cais ntawm [`char`] s, lossis ua haujlwm lossis kaw uas txiav txim siab yog qhov cim tus cwj pwm.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Phau ntawv kev taw qhia
    ///
    /// Txoj hlua yog ib theem ntawm bytes.
    /// `end` hauv cov ntsiab lus no txhais tau tias yog qhov kawg ntawm txoj kab ntawd byte;rau ib tug tshuav-rau-txoj cai cov lus zoo li lus Askiv los yog Lavxias teb sab, qhov no yuav sab xis, thiab rau txoj kev-rau-laug hom lus xws li Arabic los yog Hebrew, qhov no yuav tsum yog tus sab laug.
    ///
    ///
    /// # Examples
    ///
    /// Cov qauv yooj yim:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// Tus qauv ntau dua, siv kaw:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // KEV RUAJ NTSEG: `Searcher` yog lub npe paub kom rov qab muaj qhov ntsuas tau.
        unsafe { self.get_unchecked(0..j) }
    }

    /// Rov qab txoj hlua ib txoj hlua nrog txhua lo lus ua ntej uas phim tus qauv raug tshem tawm ntau zaus.
    ///
    /// [pattern] tuaj yeem yog `&str`, [`char`], ib qho sib cais ntawm [`char`] s, lossis ua haujlwm lossis kaw uas txiav txim siab yog qhov cim tus cwj pwm.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Phau ntawv kev taw qhia
    ///
    /// Txoj hlua yog ib theem ntawm bytes.
    /// 'Left' nyob rau hauv qhov ntsiab lus teb txhais tau tias cov thawj txoj hauj lwm ntawm uas byte hlua;rau ib hom lus zoo li Arabic los yog Hebrew uas yog 'txoj cai mus rau sab laug' es 'sab laug rau xis', qhov no yuav tsum yog tus _right_ sab, tsis yog tus sab laug.
    ///
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// Rov qab muab txoj hlua ib txwm nrog txhua cov lus sib dhos uas phim tus qauv tshem tawm ntau zaus.
    ///
    /// [pattern] tuaj yeem yog `&str`, [`char`], ib qho sib cais ntawm [`char`] s, lossis ua haujlwm lossis kaw uas txiav txim siab yog qhov cim tus cwj pwm.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Phau ntawv kev taw qhia
    ///
    /// Txoj hlua yog ib theem ntawm bytes.
    /// 'Right' hauv cov ntsiab lus no txhais tau tias yog qhov kawg ntawm txoj kab ntawd byte;rau ib hom lus zoo li Arabic los yog Hebrew uas yog 'txoj cai mus rau sab laug' es 'sab laug rau xis', qhov no yuav tsum yog tus _left_ sab, tsis ntawm txoj cai.
    ///
    ///
    /// # Examples
    ///
    /// Cov qauv yooj yim:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// Tus qauv ntau dua, siv kaw:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// Parses no hlua hlais mus rau lwm yam.
    ///
    /// Vim tias `parse` yog qhov dav dav, nws tuaj yeem tsim teeb meem nrog hom kev nkag siab.
    /// Raws li xws li, `parse` yog ib tug ntawm ob peb lub sij hawm koj yuav pom cov syntax affectionately hu ua tus 'turbofish': `::<>`.
    ///
    /// Qhov no yuav pab kom cov inference algorithm to taub hais uas ntaus koj nyob nraum sim rau parse rau hauv.
    ///
    /// `parse` tuaj yeem faib rau txhua hom uas coj los [`FromStr`] trait.
    ///

    /// # Errors
    ///
    /// Yuav rov [`Err`] yog tias nws tsis tuaj yeem tawm ntawm txoj hlua txoj hlua no rau hauv hom yam.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// Kev siv theem pib
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// Siv 'turbofish' hloov kev suav `four`:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// Ua tsis tiav:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// Tshawb xyuas yog tias txhua tus cim hauv txoj hlua no nyob hauv ASCII ntau.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // Peb tuaj yeem kho txhua byte raws li cov cim ntawm no: tag nrho cov cim multibyte pib nrog lub byte uas tsis nyob hauv qhov sib koom ua ke, ces peb yuav nres nyob ntawd.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// Cov tshev mis uas ob cov hlua yog ib tug ASCII cov ntaub ntawv-insensitive match.
    ///
    /// Tib yam li `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, tab sis tsis muaj kev faib tawm thiab cov ntawv sau tseg ntawm lub ntsej muag.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// Hloov pauv txoj hlua no rau nws ASCII sab sau ntawv sib npaug hauv-chaw.
    ///
    /// ASCII cov ntawv 'a' rau 'z' yog mapped rau 'A' rau 'Z', tab sis cov tsiaj ntawv tsis-ASCII tsis hloov pauv.
    ///
    /// Rov qab mus rau ib tug tshiab uppercased nqi tsis modifying uas twb muaj lawm ib tug, siv [`to_ascii_uppercase()`].
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // KEV RUAJ NTSEG: muaj kev nyab xeeb vim tias peb hla ob hom nrog tib lub qauv.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// Hloov siab los ntseeg no txoj hlua rau nws ASCII qis cov ntaub ntawv sib npaug nyob rau hauv-qhov chaw.
    ///
    /// ASCII cov ntawv 'A' rau 'Z' yog mapped rau 'a' rau 'z', tab sis cov tsiaj ntawv tsis-ASCII tsis hloov pauv.
    ///
    /// Txhawm rau rov qab tus nqi qis qis dua yam tsis muaj kev hloov kho rau ib tus uas twb muaj lawm, siv [`to_ascii_lowercase()`].
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // KEV RUAJ NTSEG: muaj kev nyab xeeb vim tias peb hla ob hom nrog tib lub qauv.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// Xa rov qab rau tus ntsuas qhov uas tshem txhua tus nqi hauv `self` nrog [`char::escape_debug`].
    ///
    ///
    /// Note: tsuas ncua grapheme codepoints uas pib txoj hlua yuav tsum dim.
    ///
    /// # Examples
    ///
    /// Raws li ib tug iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Siv `println!` ncaj qha:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// Ob qho tib si sib npaug rau:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// Siv `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// Xa rov qab rau tus ntsuas qhov uas tshem txhua tus nqi hauv `self` nrog [`char::escape_default`].
    ///
    ///
    /// # Examples
    ///
    /// Raws li ib tug iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Siv `println!` ncaj qha:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// Ob qho tib si sib npaug rau:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// Siv `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// Xa rov rau tus ntsuas uas khiav txhua tus nqi hauv `self` nrog [`char::escape_unicode`].
    ///
    ///
    /// # Examples
    ///
    /// Raws li ib tug iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Siv `println!` ncaj qha:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// Ob qho tib si sib npaug rau:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// Siv `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// Tsim ib qho kev npliag str
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// Tsim ib txoj hlua khoob uas hloov tsis tau
    #[inline]
    fn default() -> Self {
        // KEV RUAJ NTSEG: Cov hlua khoob siv tau yog UTF-8.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// Ib lub npe, cloneable fn hom
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // KEV RUAJ NTSEG: tsis muaj kev nyab xeeb
        unsafe { from_utf8_unchecked(bytes) }
    };
}