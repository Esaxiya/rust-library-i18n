#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Muaj cov ntsiab lus txhais rau cov qauv ntawm cov compiler tsim-hauv hom.
//!
//! Lawv tuaj yeem siv los ua hom phiaj ntawm transmutes hauv txoj cai tsis zoo rau kev tswj cov khoom nyoos ncaj qha.
//!
//!
//! Lawv qhov kev txhais yuav tsum sib phim rau ABI uas txhais hauv `rustc_middle::ty::layout`.
//!

/// Cov sawv cev ntawm ib qho khoom trait zoo ib yam li `&dyn SomeTrait`.
///
/// Cov qauv no muaj tib lub qauv raws li hom xws li `&dyn SomeTrait` thiab `Box<dyn AnotherTrait>`.
///
/// `TraitObject` yog lav kom phim cov txheej txheem, tab sis nws tsis yog hom trait cov khoom (piv txwv li, cov liaj teb tsis ncaj qha rau ntawm `&dyn SomeTrait`) tsis yog nws tswj cov kev teeb tsa (hloov cov lus txhais yuav tsis hloov pauv qhov teeb meem ntawm `&dyn SomeTrait`).
///
/// Nws tsuas yog tsim los siv los ntawm kev tsis nyab xeeb tus lej uas yuav tsum muaj kev tswj hwm cov lus qib qis.
///
/// Tsis muaj txoj hauv kev xa mus rau txhua qhov trait cov khoom lag luam feem ntau, yog li txoj kev los tsim qhov tseem ceeb ntawm hom no yog nrog cov haujlwm xws li [`std::mem::transmute`][transmute].
/// Ib yam li ntawd, tib txoj kev los tsim cov khoom muaj tseeb trait tawm ntawm `TraitObject` tus nqi yog nrog `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Synthesizing lub trait kwv nrog cov hom tsis sib haum-ib qho uas lub vtable tsis raug raws li hom ntawm tus nqi uas cov ntsiab lus pointer cov ntsiab lus-muaj feem ntau yuav ua rau tus cwj pwm tsis paub tseeb.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // ib qho piv txwv trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // cia cov compiler ua ib tug trait khoom
/// let object: &dyn Foo = &value;
///
/// // saib cov sawv cev nyoos
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // cov ntaub ntawv pointer yog qhov chaw nyob ntawm `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // txua cov khoom tshiab, taw rau qhov txawv `i32`, ua tib zoo siv `i32` vtable ntawm `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // nws yuav tsum ua haujlwm ib yam li peb tau tsim lub trait tawm ntawm `other_value` ncaj qha
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}