//! Unwinding panics rau Miri.
use alloc::boxed::Box;
use core::any::Any;

// Lub hom ntawm cov payload hais tias cov Miri engine propagates los ntawm unwinding rau peb.
// Yuav tsum muaj pointer-sized.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Miri-muab cov sab nrauv muaj nuj nqi los pib ua kom txaus.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // Lub payload peb dhau mus rau `miri_start_panic` yuav raws nraim qhov sib cav peb tau txais nyob rau hauv `cleanup` hauv qab no.
    // Yog li peb tsuas yog tso nws ua ke ib zaug, kom tau txais qee yam pointer-nruab nrab.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Rov qab qhov pib `Box`.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}