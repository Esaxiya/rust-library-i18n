//! Unwinding rau *emscripten* phiaj.
//!
//! Whereas Rust li ib txwm tsis siv kev ua tiav rau Unix cov xov tooj hu rau hauv libunwind APIs ncaj qha, ntawm Emscripten peb hloov hu rau C++ unwinding APIs.
//! Qhov no tsuas yog ua kom ceev nrooj txij li Emscripten lub sijhawm runtime ib txwm coj cov APIs thiab tsis siv libunwind.
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;
use core::mem;
use core::ptr;
use core::sync::atomic::{AtomicBool, Ordering};
use libc::{self, c_int};
use unwind as uw;

// Qhov no phim tus qauv ntawm std::type_info hauv C++
#[repr(C)]
struct TypeInfo {
    vtable: *const usize,
    name: *const u8,
}
unsafe impl Sync for TypeInfo {}

extern "C" {
    // Tus thawj coj `\x01` byte ntawm no yog lub teeb liab tej yam yees siv rau LLVM rau *tsis* siv lwm yam kev yos hav zoov zoo li qhov ua ntej nrog lub cim `_`.
    //
    //
    // Lub cim no yog lub vtable siv los ntawm C++ 's `std::type_info`.
    // Khoom ntawm hom `std::type_info`, hom piav qhia, muaj ib tug pointer rau cov lus no.
    // Cov lus piav qhia yog hais los ntawm C++ EH cov qauv sau tseg saum toj saud thiab peb tsim hauv qab no.
    //
    // Nco ntsoov tias qhov loj me yog qhov loj dua 3 usize, tab sis peb tsuas yog xav tau peb lub vtable taw tes rau qhov khoom thib peb.
    //
    //
    #[link_name = "\x01_ZTVN10__cxxabiv117__class_type_infoE"]
    static CLASS_TYPE_INFO_VTABLE: [usize; 3];
}

// std::type_info rau chav kawm rust_panic
#[lang = "eh_catch_typeinfo"]
static EXCEPTION_TYPE_INFO: TypeInfo = TypeInfo {
    // Feem ntau peb yuav siv .as_ptr().add(2) tab sis qhov no tsis ua haujlwm hauv lub ntsiab lus teb const.
    vtable: unsafe { &CLASS_TYPE_INFO_VTABLE[2] },
    // Qhov no txhob txwm tsis siv lub npe mangling txwm vim tias peb tsis xav kom C++ tuaj yeem tsim lossis ntes Rust panics.
    //
    name: b"rust_panic\0".as_ptr(),
};

struct Exception {
    // Qhov no yog tsim nyog vim hais tias C++ code yuav ntes peb execption nrog std::exception_ptr thiab rethrow nws ntau zaus, tejzaum nws txawm nyob rau hauv lwm thread.
    //
    //
    caught: AtomicBool,

    // Qhov no yuav tsum yog Kev Xaiv vim tias tus kwv lub neej ua raws C++ semantics: thaum catch_unwind tsiv lub thawv tawm ntawm qhov tshwj tseg nws yuav tsum tseem tshuav qhov khoom tshwj xeeb rau hauv lub xeev siv tau vim nws lub destructor tseem yuav raug hu los ntawm __cxa_end_catch.
    //
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    // intrinsics::try ua tau muab peb lub pointer rau cov qauv no.
    #[repr(C)]
    struct CatchData {
        ptr: *mut u8,
        is_rust_panic: bool,
    }
    let catch_data = &*(ptr as *mut CatchData);

    let adjusted_ptr = __cxa_begin_catch(catch_data.ptr as *mut libc::c_void) as *mut Exception;
    let out = if catch_data.is_rust_panic {
        let was_caught = (*adjusted_ptr).caught.swap(true, Ordering::SeqCst);
        if was_caught {
            // Txij li thaum cleanup() yog tsis tau tso cai rau panic, peb cia li ho xwb.
            intrinsics::abort();
        }
        (*adjusted_ptr).data.take().unwrap()
    } else {
        super::__rust_foreign_exception();
    };
    __cxa_end_catch();
    out
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let sz = mem::size_of_val(&data);
    let exception = __cxa_allocate_exception(sz) as *mut Exception;
    if exception.is_null() {
        return uw::_URC_FATAL_PHASE1_ERROR as u32;
    }
    ptr::write(exception, Exception { caught: AtomicBool::new(false), data: Some(data) });
    __cxa_throw(exception as *mut _, &EXCEPTION_TYPE_INFO, exception_cleanup);
}

extern "C" fn exception_cleanup(ptr: *mut libc::c_void) -> *mut libc::c_void {
    unsafe {
        if let Some(b) = (ptr as *mut Exception).read().data {
            drop(b);
            super::__rust_drop_panic();
        }
        ptr
    }
}

#[lang = "eh_personality"]
unsafe extern "C" fn rust_eh_personality(
    version: c_int,
    actions: uw::_Unwind_Action,
    exception_class: uw::_Unwind_Exception_Class,
    exception_object: *mut uw::_Unwind_Exception,
    context: *mut uw::_Unwind_Context,
) -> uw::_Unwind_Reason_Code {
    __gxx_personality_v0(version, actions, exception_class, exception_object, context)
}

extern "C" {
    fn __cxa_allocate_exception(thrown_size: libc::size_t) -> *mut libc::c_void;
    fn __cxa_begin_catch(thrown_exception: *mut libc::c_void) -> *mut libc::c_void;
    fn __cxa_end_catch();
    fn __cxa_throw(
        thrown_exception: *mut libc::c_void,
        tinfo: *const TypeInfo,
        dest: extern "C" fn(*mut libc::c_void) -> *mut libc::c_void,
    ) -> !;
    fn __gxx_personality_v0(
        version: c_int,
        actions: uw::_Unwind_Action,
        exception_class: uw::_Unwind_Exception_Class,
        exception_object: *mut uw::_Unwind_Exception,
        context: *mut uw::_Unwind_Context,
    ) -> uw::_Unwind_Reason_Code;
}