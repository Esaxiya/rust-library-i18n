//! Windows SEH
//!
//! Ntawm Windows (tam sim no tsuas yog nyob rau MSVC), lub neej ntawd kev zam kev tuav tseg yog Txheej Txheem Txheej Txheem (SEH).
//! Qhov no txawv heev tshaj li Dwarf-based kos tuav (piv txwv li cas lwm qhov unix platform siv) hais txog kev sib sau ua ke, yog li LLVM yuav tsum muaj qhov zoo ntawm kev txhawb nqa tshwj xeeb rau SEH.
//!
//! Nyob rau hauv nutshell, dab tsi tshwm sim ntawm no yog:
//!
//! 1. Lub `panic` nuj nqi hu rau tus txheej txheem Windows muaj nuj nqi `_CxxThrowException` pov ib tug C++ -zoo li tsuas yog, triggering lub unwinding txheej txheem.
//! 2.
//! Txhua daim ntawv tsaws tsim tawm los ntawm cov lus tso ua ke siv tus cwm pwm kev coj ua `__CxxFrameHandler3`, muaj nuj nqi hauv CRT, thiab cov lus tsis sib haum hauv Windows yuav siv tus cwj pwm no coj los siv rau txhua qhov kev ua kom huv si ntawm cov pawg.
//!
//! 3. Txhua tus sau cov cuab yeej hu tawm mus rau `invoke` muaj qhov tsaws tsaws teeb ua `cleanuppad` LLVM kev qhia, uas qhia tau hais tias pib kev ua haujlwm tsis huv.
//! Cov cwm pwm (nyob rau hauv kauj ruam 2, txhais nyob rau hauv lub CRT) yog lub luag hauj lwm kom khiav ntxuav tu txhua hnub.
//! 4. Nws thiaj li cov "catch" code nyob rau hauv lub `try` intrinsic (generated los ntawm cov compiler) yog tua thiab qhia tau hais tias kev tswj yuav tsum tau rov qab los rau Rust.
//! Qhov no tau ua dhau los ntawm `catchswitch` ntxiv rau `catchpad` kev qhia hauv LLVM IR cov lus, thaum kawg rov qab tswj hwm qub rau qhov kev zov me nyuam nrog kev qhia `catchret`.
//!
//! Qee qhov sib txawv tshwj xeeb los ntawm gcc-based kev kos yog:
//!
//! * Rust twb tsis muaj kev cai cwm pwm muaj nuj nqi, nws yog es tsis txhob *yeej ib txwm*`__CxxFrameHandler3`.Tsis tas li ntawd, tsis muaj kev lim dej ntxiv, yog li peb mus ntes txhua C++ qhov tshwj xeeb uas tshwm sim zoo li yam uas peb tau pov tseg.
//! Nco ntsoov tias ntuav ib qho kev zam rau hauv Rust yog undefined tus cwj pwm lawm, yog li no yuav tsum tau zoo.
//! * Peb tau txais qee cov ntaub ntawv xa mus rau kis mus rau ciam chaw tsis sib haum, tshwj xeeb `Box<dyn Any + Send>`.Zoo li nrog ntsias zam no ob pointers yog muab raws li ib tug payload nyob rau hauv kos nws tus kheej.
//! Nyob rau MSVC, txawm li cas los, yog tsis muaj yuav tsum tau rau ib tug ntxiv heap qee vim hais tias cov hu pawg yog fwm thaum lim zog yog raug tua pov tseg.
//! Qhov no txhais tau tias cov ntsiab lus kis tau ncaj qha rau `_CxxThrowException` uas tom qab ntawd rov ua kom zoo dua nyob rau hauv lub lim lim dej kom tau sau rau pawg teeb ntawm `try` intrinsic.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Qhov no xav tau kev pab yuav tsum tau ib tug xaiv vim peb txais kev zam los ntawm kev siv thiab nws cov destructor yog tua los ntawm cov C++ runtime.
    // Thaum peb coj cov Box tawm ntawm lub zam, peb yuav tsum tau tawm hauv lub kos nyob rau hauv ib tug siv tau lub xeev no rau nws cov destructor khiav tsis muab ob npaug rau-xa me nyuam rov Box.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// First up, ib pawg tag nrho ntawm cov ntsiab lus txhais.Muaj yog ib tug ob peb platform kev oddities ntawm no, thiab ib tug ntau uas cia li blatantly theej los ntawm LLVM.Lub hom phiaj ntawm tag nrho cov no yog mus siv cov `panic` muaj nuj nqi hauv qab no los ntawm ib tug hu rau `_CxxThrowException`.
//
// Txoj haujlwm no yuav siv ob qho kev sib cav.Thawj yog tus taw tes rau cov ntaub ntawv uas peb tau hla rau, uas qhov no yog peb lub trait object.Zoo nkauj yooj yim mus nrhiav tau!Tom ntej no, li cas los xij, yog qhov nyuaj dua.
// Qhov no yog ib pointer mus rau ib tug `_ThrowInfo` qauv, thiab nws feem ntau yog cia li npaj mus cia li piav qhia txog cov kev zam tau ces muab pov tseg.
//
// Tam sim no lub ntsiab txhais ntawm no hom [1] yog ib tug me ntsis plaub, thiab lub ntsiab oddity (thiab txawv los ntawm lub hauv internet tsab xov xwm) yog hais tias nyob rau hauv 32-ntsis cov pointers yog pointers tab sis rau 64-ntsis cov pointers yog qhia raws li 32-ntsis offsets los ntawm cov `__ImageBase` cim.
//
// Lub `ptr_t` thiab `ptr!` macro nyob rau hauv lub modules hauv qab no yog siv los qhia no.
//
// Cov kev tshawb ntawm hom lus txhais kuj zoo raws li LLVM emits rau no tsi ntawm cov lag luam.Piv txwv li, yog tias koj sau no C++ code rau MSVC thiab emit lub LLVM IR:
//
//      #include <stdint.h>
//
//      qauv rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      khoob foo() { rust_panic a = {0, 1};
//          pov a;}
//
// Qhov ntawd yeej tseem zoo li cas peb nyob nraum sim rau emulate.Feem ntau ntawm cov qhov teeb meem hauv qab no tsuas yog tau theej los ntawm LLVM,
//
// Nyob rau hauv txhua rooj plaub, cov qauv no yog txhua txoj haujlwm ua haujlwm zoo ib yam, thiab nws tsuas yog ua dog dig rau peb.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Nco ntsoov tias peb txhob txwm tsis quav ntsej txog lub npe mangling cai nyob ntawm no: peb tsis xav C++ yuav tau txais Rust panics los tsuas hais tias ib tug `struct rust_panic`.
//
//
// Thaum hloov kho, nco ntsoov tias cov hom hlua lub npe tau sib phim ib qho siv hauv `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // Tus thawj coj `\x01` byte ntawm no yog lub teeb liab tej yam yees siv rau LLVM rau *tsis* siv lwm yam kev yos hav zoov zoo li qhov ua ntej nrog lub cim `_`.
    //
    //
    // Lub cim no yog lub vtable siv los ntawm C++ 's `std::type_info`.
    // Khoom ntawm hom `std::type_info`, hom piav qhia, muaj ib tug pointer rau cov lus no.
    // Cov lus piav qhia yog hais los ntawm C++ EH cov qauv sau tseg saum toj saud thiab peb tsim hauv qab no.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Qhov no hom descriptor yog tsuas siv thaum ntuav ib qho kev zam.
// Lub catch ib feem yog leej twg los ntawm cov zaug intrinsic, uas generates nws tus kheej TypeDescriptor.
//
// Qhov no yog ib qho zoo vim lub MSVC runtime siv txoj hlua sib piv rau lub hom lub npe rau match TypeDescriptors es pointer koob pheej ntawm lawv.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Destructor siv yog hais tias tus C++ code txiav txim siab mus ntes tus kos thiab poob nws tsis propagating nws.
// Lub catch ib feem ntawm lub zaug intrinsic yuav teem caij rau thawj lo lus ntawm tsuas yog kwv 0 li hais tias nws yog raug hla lawm los ntawm lub destructor.
//
// Nco ntsoov tias x86 Windows siv cov "thiscall" hu convention rau C++ neeg khiav dej num es tsis txhob ntawm lub neej ntawd "C" hu convention.
//
// Kev ua haujlwm ntawm exception_copy yog qhov tshwj xeeb me ntsis ntawm no: nws tau hu los ntawm MSVC runtime hauv qab try/catch thaiv thiab panic uas peb tsim tawm ntawm no yuav siv raws li daim ntawv tsis suav.
//
// Qhov no yog siv los ntawm C++ lub sijhawm txhawb nqa kom ntes tau kev zam nrog std::exception_ptr, uas peb tsis tuaj yeem txhawb vim tias Box<dyn Any>tsis yog clonable.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException executes nkaus rau no cov kablus, yog li tsis tas xav hloov lwm lub sijhawm `data` rau qhov heap.
    // Peb tsuas yog hla lub pob taw ntawm tus pointer rau txoj haujlwm no.
    //
    // Qhov ManuallyDrop xav tau ntawm no txij li peb tsis xav kom zam tshwj tsis yog poob thaum tsis ceev faj.
    // Es tsis txhob nws yuav poob los ntawm exception_cleanup uas yog invoked los ntawm cov C++ runtime.
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Qhov no ... yuav nkawd ceeb, thiab justifiably li ntawd.Nyob rau 32-ntsis MSVC lub pointers ntawm cov qauv no yog cia li hais tias, pointers.
    // Ntawm 64-ntsis MSVC, txawm li cas los xij, cov ntsiab lus ntawm cov qauv theej qhia raws li 32-ntsis offsets los ntawm `__ImageBase`.
    //
    // Thiaj li, nyob rau 32-ntsis MSVC peb yuav tshaj tawm rau tag nrho cov pointers nyob rau hauv lub 'static`s saum toj no.
    // Nyob rau 64-ntsis MSVC, peb yuav tau qhia kev rho tawm ntawm pointers nyob rau hauv statics, uas Rust tsis tam sim no tso cai rau, li ntawd, peb tsis tau ua li ntawd.
    //
    // Qhov zoo tshaj plaws tom ntej, tom qab ntawd yog los sau rau hauv cov qauv ntawm runtime (panicking yog twb tus "slow path" rau nkawv noj).
    // Yog li ntawm no peb rov txhais txhua yam ntawm pointer teb li 32-ntsis kev sib tshooj thiab tom qab ntawv khaws cov nqi cuam tshuam rau hauv nws (atomically, raws li panics yuav tshwm sim).
    //
    // Technically lub runtime yuav zaum ua ib tug nonatomic nyeem ntawm cov teb, tab sis nyob rau hauv kev tshawb xav lawv yeej tsis nyeem cov *tsis ncaj ncees lawm* nqi li ntawd nws yuav tsum tsis txhob yuav ib yam nkaus thiab phem ...
    //
    // Nyob rau hauv txhua rooj plaub, peb yeej yuav tsum tau ua ib yam dab tsi zoo li no kom txog thaum peb yuav nthuav qhia ntau ua hauj lwm nyob rau hauv statics (thiab tej zaum peb yuav tsis muaj peev xwm).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // NULL payload ntawm no txhais tau tias peb tau txais ntawm no los ntawm kev ntes (...) ntawm __rust_try.
    // Qhov no tshwm sim thaum uas tsis yog-Rust txawv teb chaws ntes tau.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Qhov no yuav tsum los ntawm lub compiler nyob ua ib ke (xws li, nws yog ib tug lang yam khoom), tab sis nws yeej tsis tau hu ua los ntawm lub compiler vim hais tias __C_specific_handler los yog_except_handler3 yog cov cwm pwm kev ua uas yog ib txwm siv.
//
// Li no cov lus no tsuas yog tso tseg txoj kev iab liam xwb.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}