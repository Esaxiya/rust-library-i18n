//! Yuav ua raws li panics ntawm pawg unwinding
//!
//! Qhov crate yog qhov kev siv ntawm panics hauv Rust siv "most native" pawg unwinding mechanism ntawm lub platform no tau muab tso ua ke rau.
//! Qhov no yeej tseem ceeb tau cais rau hauv peb lub thoob:
//!
//! 1. MSVC lub hom phiaj siv SEH hauv `seh.rs` cov ntaub ntawv.
//! 2. Emscripten siv C++ kev zam hauv `emcc.rs` cov ntaub ntawv.
//! 3. Tag nrho lwm cov hom phiaj siv libunwind/libgcc hauv `gcc.rs` cov ntaub ntawv.
//!
//! Ntau cov ntaub ntawv hais txog txhua qhov kev nqis tes ua yuav pom nyob hauv cov qauv siv.
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` yog tsis siv nrog Miri, yog li kev ceeb toom ntsiag to.
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // Rust runtime lub sijhawm pib khoom yog nyob ntawm cov cim no, thiaj li ua rau pej xeem.
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // Hom Phaj uas tsis txhawb unwinding.
        // - arch=wasm32
        // - os=tsis muaj ("bare metal" lub hom phiaj)
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // Siv cov Miri runtime.
        // Peb tseem yuav tsum tau ntim cov qub runtime saum toj no, raws li rustc cia siab tias qee yam lang khoom los ntawm muaj yuav tsum tau txhais.
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // Siv lub tiag tiag runtime.
        use real_imp as imp;
    }
}

extern "C" {
    /// Handler nyob rau hauv libstd hu ua thaum ib tug panic kwv yog poob sab nraum ntawm `catch_unwind`.
    ///
    fn __rust_drop_panic() -> !;

    /// Handler hauv libstd hu ua thaum muaj kev txawv txav txawv tebchaws.
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// Nkag lub ntsiab lus rau kev tsa qhov kev zam, tsuas yog cov neeg sawv cev mus rau qhov kev ua haujlwm ntawm lub platform.
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}