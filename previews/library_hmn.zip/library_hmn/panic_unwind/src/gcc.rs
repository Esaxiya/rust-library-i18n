//! Kev siv ntawm panics rov qab los ntawm libgcc/libunwind (nyob rau hauv qee daim ntawv).
//!
//! Txog tom qab ntawm kev zam kev tuav thiab cov tshooj tsis sib tsoo thov saib "Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html) thiab cov ntawv sib txuas los ntawm nws.
//! Cov no tseem yog nyeem zoo:
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## Ib nyuag ntsiab lus
//!
//! Exception tuav tshwm sim nyob rau hauv ob theem: ib tug nrhiav theem thiab ib tug tej theem.
//!
//! Nyob rau hauv ob qho tib si theem lub unwinder mus taug kev teeb ntas los ntawm sab saum toj mus rau nram qab siv ntaub ntawv los ntawm lub teeb ncej so seem ntawm qhov tam sim no cov txheej txheem lub modules ("module" no yog hais txog ib tug OS module, piv txwv li, ib tug executable los yog ib tug dynamic tsev qiv ntawv).
//!
//!
//! Rau txhua pawg ncej, nws thov cov kab "personality routine", uas nws qhov chaw nyob yog tseem muab cia rau hauv lub so info seem.
//!
//! Hauv kev tshawb nrhiav theem, txoj haujlwm ntawm tus cwj pwm ib txwm yog los tshuaj xyuas cov kwv tsis raug pov, thiab los txiav txim siab seb nws yuav tsum raug ntes ntawm tus ncej ntawd.Thaum lub handler ncej tau lawm tias, tej theem pib.
//!
//! Hauv kev ua kev nyiam huv, qhov kev faib pov tseg txwv txhua tus kev coj ua ib zaug ntxiv.
//! Lub sij hawm no nws txiav txim siab uas (yog tias muaj) tej code xav tau kev pab yuav tsum tau khiav rau qhov tam sim no pawg ncej.Yog hais tias yog li ntawd, cov kev tswj yog pauv mus rau ib tug tshwj xeeb branch nyob rau hauv cov kev ua lub cev, lub "landing pad", uas nws thov destructors, frees nco, etc.
//! Ntawm qhov kawg ntawm daim tsaws tsaws, kev tswj tau yog xa rov qab mus rau qhov chaw tsis muaj khoom thiab tsis pom zoo.
//!
//! Thaum cov pawg lawm tsis txaus nqis mus rau theem ntawm tus tes tuav qib theem, unwinding nres thiab kawg tus cwj pwm niaj hnub hloov chaw tswj mus rau lub thaiv block.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// Rust lub kos chav kawm ntawv qhia tau.
// Qhov no yog siv los ntawm kev tswj hwm tus kheej los txiav txim siab seb qhov kev zam tau pov los ntawm lawv tus kheej lub sijhawm.
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // MOZ\0 RUST-tus muag khoom, lus
    0x4d4f5a_00_52555354
}

// Cov ntaub ntawv sau npe raug tshem tawm los ntawm LLVM TargetLowering::getExceptionPointerRegister() thiab TargetLowering::getExceptionSelectorRegister() rau txhua lub architecture, tom qab ntawd kos rau DWARF cov lej sau npe ntawm cov npe txhais cov ntsiab lus (feem ntau<arch>RegisterInfo.td, nrhiav "DwarfRegNum").
//
// Xyuas http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register thiab.
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // EAX, EDX

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // RAX, RDX

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0, X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3, X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// Cov cai hauv qab no yog raws li GCC's C thiab C++ kev coj ua haujlwm ib puag ncig.Rau kev siv, saib:
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM EHABI tus kheej niaj hnub ua.
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS siv cov txheej txheem niaj zaus hloov vim tias nws siv SjLj unwinding.
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // Backtraces rau NPAB yuav hu rau tus niaj hnub nrog lub xeev==_US_VIRTUAL_UNWIND_FRAME |_US_FORCE_UNWIND.
                // Hauv cov xwm txheej no peb xav txuas mus txuas ntxiv tsis siv pawg, txwv tsis pub peb txhua tus backtraces yuav xaus ntawm __rust_try
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // Lub ntsias unwinder assumes uas_Unwind_Context tuas tej yam xws li cov nuj nqi thiab LSDA pointers, txawm li cas los NPAB EHABI muab lawv mus rau hauv lub kos kwv.
            // Khaws cia rau kos npe ntawm kev khiav dej num xws li _Unwind_GetLanguageSpecificData(), uas noj xwb lub ntsiab lus teb pointer, GCC cwm pwm txhua hnub stash ib tug pointer rau exception_object nyob rau hauv cov ntsiab lus teb, siv qhov chaw nyob tseg rau NPAB lub "scratch register" (r12).
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ... Ib qho kev qhia ntxiv yuav tau muab tag nrho cov ntsiab lus ntawm ARM lub_Unwind_Context hauv peb qhov libunwind khi thiab coj cov ntaub ntawv xav tau los ntawm muaj ncaj qha, bypassing DWARF compatibility functions.
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // EHABI xav kom tus kheej tus cwj pwm niaj hnub hloov kho tus nqi SP rau hauv kev siv khoom tsis zoo ntawm cov khoom siv tshwj xeeb.
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // Nyob rau NPAB EHABI cov cwm pwm sij yog lub luag hauj lwm rau ua tau unwinding ib zaug xwb pawg ncej ua ntej rov qab los (NPAB EHABI Sec.
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // txhais nyob rau hauv libgcc
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // Tus yam ntxwv tsis raws sijhawm, uas yog siv ncaj qha rau feem ntau ntawm cov hom phiaj thiab ncaj qha ntawm Windows x86_64 ntawm SEH.
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // Ntawm x86_64 MinGW lub hom phiaj, lub tshuab tsis siv neeg yog SEH txawm li cas los xij cov ntaub ntawv tsis siv tes (aka LSDA) siv GCC-tshaj encoding.
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // Cov cwm pwm niaj hnub rau feem ntau ntawm peb cov hom phaj.
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // Qhov chaw nyob rov qab cov ntsiab lus 1 byte dhau los ntawm qhov kev qhia hu, uas yuav yog tus IP tom ntej hauv LSDA ntau lub rooj.
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// Ncej so info sau npe
//
// Txhua lub duab tso cov duab muaj cov kablus rub tawm cov lus qhia (feem ntau ".eh_frame").Thaum ib tug module yog loaded/unloaded rau hauv tus txheej txheem, lub unwinder yuav tsum tau paub txog qhov chaw ntawm no seem nyob rau hauv lub cim xeeb.Cov kev ntawm tsis tau zoo uas sib txawv los ntawm lub platform.
// Nyob rau ib co (xws li, Linux), lub unwinder yuav nrhiav tau so info seem rau nws tus kheej (los ntawm dynamically enumerating tam sim no loaded modules ntawm lub dl_iterate_phdr() API and finding their ".eh_frame" sections); Lwm tus, zoo li Windows, yuav tsum tau modules los mus sau npe rau lawv so info seem ntawm unwinder API.
//
//
// Qhov no module sij ob cim uas yog hais thiab hu ua los ntawm rsbegin.rs mus sau npe peb cov ntaub ntawv nrog lub GCC runtime.
// Cov kev siv ntawm pawg unwinding yog (tam sim no) deferred rau libgcc_eh, txawm li cas los Rust crates siv tau cov no Rust kev nkag ntsiab lus kom tsis txhob muaj tej zaum clashes nrog tej GCC runtime.
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}