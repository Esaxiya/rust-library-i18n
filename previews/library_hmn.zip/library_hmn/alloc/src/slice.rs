//! Qhov pom me me rau qhov sib txuam ua ntu zus, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Cov nplais me me yog qhov pom rau ntawm lub block ntawm lub cim xeeb sawv cev raws li tus taw qhia thiab ntev.
//!
//! ```
//! // slicing ib Vec
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // coercing ib qho array rau ib qho
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! Daim slices yog hloov tau lossis sib qhia tau.
//! Cov hlais sib xyaw ua ke yog `&[T]`, thaum hloov hom tuaj yeem yog `&mut [T]`, qhov twg `T` sawv cev rau cov hom khoom.
//! Piv txwv li, koj tuaj yeem hloov ua qhov thaiv ntawm lub cim xeeb uas ib qho sib hloov sib hloov tau mus rau:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Nov yog qee yam uas qhov qauv no muaj:
//!
//! ## Structs
//!
//! Muaj ntau tus qauv ua kom muaj txiaj ntsig zoo rau cov hlais, xws li [`Iter`], uas sawv cev rau iteration dua ib qho.
//!
//! ## Kev Siv Trait
//!
//! Muaj ntau qhov kev siv los ntawm cov traits rau cov nplais.Qee cov qauv suav nrog:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], rau cov hle uas nws cov hom yog [`Eq`] lossis [`Ord`].
//! * [`Hash`] - rau cov nplais uas nws hom hom yog [`Hash`].
//!
//! ## Iteration
//!
//! Cov txheej txheem siv `IntoIterator`.Tus tsim tawm los ua tim khawv rau cov hlais.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! Cov kev hloov pauv tau tuaj yeem ua rau muaj kev sib hloov hais txog cov ntsiab lus:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Tus tsim tawm yoov hloov mus rau lwm qhov hauv cov nplais, yog li thaum lub hom phaj ntawm cov hlais yog `i32`, cov khoom siv ntawm cov kuj yog `&mut i32`.
//!
//!
//! * [`.iter`] thiab [`.iter_mut`] yog cov kev qhia meej meej kom rov ua qhov qub.
//! * Ntxiv txoj kev uas rov qab iterators yog [`.split`], [`.splitn`], [`.chunks`], [`.windows`] thiab tshaj.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Ntau yam kev siv hauv qhov qauv no tsuas yog siv hauv kev ntsuas teeb tsa.
// Nws yog tsev ntxhua khaub ncaws kom tsuas yog kaw cov lus ceeb toom tsis siv-tshaj tawm dua li txhim kho lawv.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Txoj hauv kev hlais cov hau kev txuas ntxiv
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) xav tau rau kev nqis tes ua ntawm `vec!` macro thaum kuaj NB, saib `hack` module hauv cov ntaub ntawv no kom paub meej ntxiv.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) xav tau rau kev nqis tes ua ntawm `Vec::clone` thaum kuaj NB, saib `hack` module hauv cov ntaub ntawv no kom paub meej ntxiv.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): Nrog cfg(test) `impl [T]` yog tsis muaj, peb khiav dej num yog ua tau txoj kev uas yog nyob rau hauv `impl [T]` tab sis tsis nyob rau hauv `core::slice::SliceExt`, peb yuav tsum tau muab cov kev khiav dej num rau lub `test_permutations` xeem
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // Peb yuav tsum tsis txhob ntxiv inline attribute rau qhov no vim tias qhov no siv hauv `vec!` macro feem ntau thiab ua rau reg region zoo nkauj.
    // Saib #71204 rau kev sib tham thiab cov txiaj ntsig zoo.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // cov khoom tau cim pib hauv lub voj hauv qab
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) yog tsim nyog rau LLVM tshem tawm cov ciaj ciam thiab muaj codegen zoo dua li zip.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // lub vec tau faib thiab pib saum toj no kom tsawg kawg qhov ntev no.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // faib rau saum toj no nrog lub peev xwm ntawm `s`, thiab pib rau `s.len()` hauv ptr::copy_to_non_overlapping hauv qab no.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Teeb cov hlais.
    ///
    /// Qhov kev xaiv no tau ruaj khov (piv txwv li, tsis hloov kho cov khoom sib luag) thiab *O*(*n*\*log(* n*)) qhov tsis zoo-rooj plaub.
    ///
    /// Thaum tsim nyog, kev xaiv tsis ruaj tsis khov yog qhov tshwj xeeb vim tias nws ib txwm nrawm dua li kev teeb txheeb ruaj khov thiab nws tsis faib cov ntu pab tsis tau.
    /// Saib [`sort_unstable`](slice::sort_unstable).
    ///
    /// # Kev siv tam sim no
    ///
    /// Tus tam sim no algorithm yog ib tug coj, iterative sib tshuam uake tsi tshwm sim los ntawm [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Nws yog tsim kom nrawm heev nyob rau hauv cov xwm txheej uas cov hlais tau ze li ntawm kev txheeb, lossis muaj ob lossis ntau cov kev sib txig sib luag concatenated ib qho dhau ib qho.
    ///
    ///
    /// Tsis tas li ntawd, nws faib chaw nyob ib ntus cia ib nrab ntawm `self` qhov loj me, tab sis rau cov hlais me me ib qho kev faib tawm tsis tau muab tso ua ke tau siv dua.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Teeb cov hlais nrog cov sib piv ua kom zoo li qub.
    ///
    /// Qhov kev xaiv no tau ruaj khov (piv txwv li, tsis hloov kho cov khoom sib luag) thiab *O*(*n*\*log(* n*)) qhov tsis zoo-rooj plaub.
    ///
    /// Kev ntsuas kev sib piv yuav tsum txhais tag nrho cov khoom xaj rau cov khoom hauv cov hlais.Yog tias qhov kev txiav txim tsis suav tag nrho, qhov kev xaj ntawm cov khoom tsis tau txheeb xyuas.
    /// Ib qho kev txiav txim yog qhov kev txiav txim tag nrho yog tias nws yog (rau txhua `a`, `b` thiab `c`):
    ///
    /// * tag nrho thiab antisymmetric: ib qho `a < b`, `a == b` lossis `a > b` yog qhov tseeb, thiab
    /// * hloov pauv, `a < b` thiab `b < c` teeb meem `a < c`.Tib yam yuav tsum tuav rau ob qho `==` thiab `>`.
    ///
    /// Piv txwv li, thaum [`f64`] tsis siv [`Ord`] vim `NaN != NaN`, peb tuaj yeem siv `partial_cmp` raws li peb cov haujlwm ua haujlwm thaum peb paub cov hlais tsis muaj `NaN`.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Thaum tsim nyog, kev xaiv tsis ruaj tsis khov yog qhov tshwj xeeb vim tias nws ib txwm nrawm dua li kev teeb txheeb ruaj khov thiab nws tsis faib cov ntu pab tsis tau.
    /// Saib [`sort_unstable_by`](slice::sort_unstable_by).
    ///
    /// # Kev siv tam sim no
    ///
    /// Tus tam sim no algorithm yog ib tug coj, iterative sib tshuam uake tsi tshwm sim los ntawm [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Nws yog tsim kom nrawm heev nyob rau hauv cov xwm txheej uas cov hlais tau ze li ntawm kev txheeb, lossis muaj ob lossis ntau cov kev sib txig sib luag concatenated ib qho dhau ib qho.
    ///
    /// Tsis tas li ntawd, nws faib chaw nyob ib ntus cia ib nrab ntawm `self` qhov loj me, tab sis rau cov hlais me me ib qho kev faib tawm tsis tau muab tso ua ke tau siv dua.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // rov qab sorting
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Teeb cov hlais nrog cov tseem ceeb rho tawm haujlwm.
    ///
    /// Qhov kev xaiv no tau ruaj khov (piv txwv li, tsis hloov kho cov khoom sib npaug) thiab *O*(*m*\* * n *\* log(*n*)) qhov tsis zoo-qhov teeb meem, qhov twg txoj haujlwm tseem ceeb yog *O*(*m*).
    ///
    /// Rau qhov haujlwm tseem ceeb kim (piv txwv li
    /// cov haujlwm uas tsis yog cov cuab yeej yooj yim nkag los lossis cov haujlwm yooj yim), [`sort_by_cached_key`](slice::sort_by_cached_key) yog qhov muaj peev xwm hloov tau sai dua, vim nws tsis tau hais tias lub hauv paus tseem ceeb.
    ///
    ///
    /// Thaum tsim nyog, kev xaiv tsis ruaj tsis khov yog qhov tshwj xeeb vim tias nws ib txwm nrawm dua li kev teeb txheeb ruaj khov thiab nws tsis faib cov ntu pab tsis tau.
    /// Saib [`sort_unstable_by_key`](slice::sort_unstable_by_key).
    ///
    /// # Kev siv tam sim no
    ///
    /// Tus tam sim no algorithm yog ib tug coj, iterative sib tshuam uake tsi tshwm sim los ntawm [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Nws yog tsim kom nrawm heev nyob rau hauv cov xwm txheej uas cov hlais tau ze li ntawm kev txheeb, lossis muaj ob lossis ntau cov kev sib txig sib luag concatenated ib qho dhau ib qho.
    ///
    /// Tsis tas li ntawd, nws faib chaw nyob ib ntus cia ib nrab ntawm `self` qhov loj me, tab sis rau cov hlais me me ib qho kev faib tawm tsis tau muab tso ua ke tau siv dua.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Teeb cov hlais nrog cov tseem ceeb rho tawm haujlwm.
    ///
    /// Thaum lub sij hawm xaiv, qhov tseem ceeb hu ua tsuas yog ib zaug hauv ib lub.
    ///
    /// Qhov kev xaiv no tau ruaj khov (piv txwv li, tsis hloov kho cov khoom sib npaug) thiab *O*(*m*\* * n *+* n *\* log(*n*)) qhov tsis zoo-qhov teeb meem, qhov twg ua haujlwm tseem ceeb yog *O*(*m*) .
    ///
    /// Txog cov haujlwm tseem ceeb yooj yim (piv txwv, cov haujlwm uas yog cov khoom nkag los yog cov haujlwm yooj yim), [`sort_by_key`](slice::sort_by_key) yog qhov yuav ua tau nrawm dua.
    ///
    /// # Kev siv tam sim no
    ///
    /// Qhov kev daws teeb meem tam sim no yog txiav los ntawm [pattern-defeating quicksort][pdqsort] los ntawm Orson Peters, uas sib xyaw cov ntaub ntawv ceev nrawm ntawm randomized quicksort nrog cov teeb meem sai ntawm heapsort, thaum ua tiav cov kab sij hawm ntawm cov hlais nrog qee cov qauv.
    /// Nws siv qee cov kev tsis suav nrog kom zam dhau cov xwm txheej tsis zoo, tab sis nrog lub chaw ruaj khov seed los ib txwm coj tus cwj pwm txiav txim siab.
    ///
    /// Hauv qhov xwm txheej phem tshaj plaws, lub algorithm faib cov chaw cia ib ntus rau hauv `Vec<(K, usize)>` qhov ntev ntawm cov hlais.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Kev Pab rau macro rau indexing peb vector los ntawm hom me me, kom txo qis kev faib tawm.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // Cov ntsiab lus ntawm `indices` yog qhov tsis xws leej twg, raws li lawv tau ntsuas, yog li ib qho kev xaiv twg yuav ruaj nrog hwm rau cov thawj daim.
                // Peb siv `sort_unstable` ntawm no vim tias nws yuav tsum muaj kev nco qab tsawg.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// Luam tawm `self` rau hauv `Vec` tshiab.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Ntawm no, `s` thiab `x` tuaj yeem hloov kho ntawm nws tus kheej.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// Luam cov `self` rau hauv `Vec` tshiab nrog cov kev faib khoom.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Ntawm no, `s` thiab `x` tuaj yeem hloov kho ntawm nws tus kheej.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // NB, saib `hack` module hauv cov ntaub ntawv no kom paub meej ntxiv.
        hack::to_vec(self, alloc)
    }

    /// Converts `self` rau hauv vector tsis muaj clones lossis kev faib tawm.
    ///
    /// Qhov tshwm sim vector tuaj yeem hloov mus rov qab rau hauv lub thawv ntawm `Vec<T>`'s `into_boxed_slice` qauv.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` tsis tuaj yeem siv ntxiv lawm vim tias nws tau txia mus ua `x`.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // NB, saib `hack` module hauv cov ntaub ntawv no kom paub meej ntxiv.
        hack::into_vec(self)
    }

    /// Tsim vector los ntawm kev rov ua dua ib daim `n` lub sijhawm.
    ///
    /// # Panics
    ///
    /// Txoj haujlwm no yuav panic yog tias lub peev xwm yuav dhau.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// A panic li txeej:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // Yog `n` loj dua xoom, nws tuaj yeem faib ua `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)`.
        // `2^expn` yog tus lej sawv cev los ntawm sab laug '1' me ntsis ntawm `n`, thiab `rem` yog seem ntu ntawm `n`.
        //
        //

        // Siv `Vec` los nkag rau `set_len()`.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` kev rov ua dua yog ua tiav los ntawm doubling `buf` `expn`-zaug.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // Yog `m > 0`, tseem tshuav qhov me me tseem tshuav ntawm sab laug '1'.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` muaj peev xwm ntawm `self.len() * n`.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) kev rov ua dua yog ua los ntawm kev luam thawj `rem` rov ua dua los ntawm `buf` nws tus kheej.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Qhov no tsis yog sib tshooj txij li `2^expn > rem`.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` sib npaug rau `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// Flattens ib qho ntawm `T` rau ib tus nqi `Self::Output`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// Flattens ib qho hlais ntawm `T` rau hauv tus nqi ib qho `Self::Output`, muab tso rau ib qho kev sib cais ntawm txhua.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// Flattens ib qho hlais ntawm `T` rau hauv tus nqi ib qho `Self::Output`, muab tso rau ib qho kev sib cais ntawm txhua.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// Rov qab tau vector uas muaj cov ntawv luam ntawm qhov no qhov twg txhua byte yog mapped rau nws ASCII rooj plaub uas sib npaug.
    ///
    ///
    /// ASCII cov ntawv 'a' rau 'z' yog mapped rau 'A' rau 'Z', tab sis cov tsiaj ntawv tsis-ASCII tsis hloov pauv.
    ///
    /// Txhawm rau ua kom tus nqi nyob rau hauv-qhov chaw, siv [`make_ascii_uppercase`].
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// Rov qab tau vector uas muaj cov ntawv luam ntawm qhov no qhov twg txhua byte mapped rau nws ASCII cov ntaub ntawv sib npaug.
    ///
    ///
    /// ASCII cov ntawv 'A' rau 'Z' yog mapped rau 'a' rau 'z', tab sis cov tsiaj ntawv tsis-ASCII tsis hloov pauv.
    ///
    /// Txhawm rau txo tus nqi hauv-chaw, siv [`make_ascii_lowercase`].
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// Txuas traits rau kev txiav dua cov hom ntawm cov ntaub ntawv
////////////////////////////////////////////////////////////////////////////////

/// Pab trait rau ['[T]: : concat`](hlais::concat).
///
/// Note: lub `Item` hom parameter yog tsis siv nyob rau hauv no trait, tab sis nws tso cai rau impls yuav tsum tau ntau generic.
/// Yog tsis muaj nws, peb tau txais qhov yuam kev no:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// Qhov no yog vim hais tias muaj yuav nyob ua ib ke `V` hom uas muaj ntau hom `Borrow<[_]>` impls, xws li hais tias ntau yam `T` hom yuav thov:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Qhov tshwm sim hom tom qab concatenation
    type Output;

    /// Kev siv ntawm [`[T]: : concat`](hlais::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Muaj Kev Pab trait rau [`[T]: : koom nrog]((:::koom nrog)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Qhov tshwm sim hom tom qab concatenation
    type Output;

    /// Kev siv ntawm [`[T]: : koom nrog]](hlais::koom nrog)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Txheem trait kev siv rau cov nplais
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // muab txhua yam tso rau hauv phiaj uas yuav tsis muab sau tseg
        target.truncate(self.len());

        // target.len <= self.len vim qhov muaj qhov txwv qhov saum toj no, yog li cov hlais ntawm no ib txwm nyob hauv-ciam teb.
        //
        let (init, tail) = self.split_at(target.len());

        // rov qab siv lub cim muaj nuj nqi allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// Tso `v[0]` rau kev xaiv ua ntej ua ntu zus `v[1..]` kom tag nrho `v[..]` dhau los ua kev ntseeg.
///
/// Qhov no yog qhov tseem ceeb subroutine ntawm tso ntxig.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // Muaj peb txoj hauv kev los siv ntxig rau ntawm no:
            //
            // 1. Sib puav uas nyob ib sab kom txog rau thaum thawj qhov tau los rau nws lub hom phiaj kawg.
            //    Txawm li cas los xij, txoj kev no peb luam cov ntaub ntawv ncig ntau dua qhov tsim nyog.
            //    Yog tias cov ntsiab lus yog cov qauv loj (raug nqi rau luam), cov qauv no yuav qeeb.
            //
            // 2. Sib txig kom txog thaum tsim nyog rau qhov chaw rau thawj lub hauv paus pom.
            // Tom qab ntawd hloov cov ntsiab ua tau zoo nws ua kom muaj chaw rau nws thiab thaum kawg muab tso rau hauv qhov seem.
            // Nov yog ib qho qauv zoo.
            //
            // 3. Luam tawm thawj lub ntsiab rau hauv cov hloov pauv ib ntus.Iterate kom txog rau thaum qhov chaw rau nws nyob.
            // Raws li peb mus raws, luam txhua cov khoom sib pauv mus rau hauv cov kab ua ntej ntawm nws.
            // Thaum kawg, luam cov ntaub ntawv los ntawm cov kis ib ntus rau hauv seem uas seem.
            // Qhov no txoj kev yog heev zoo.
            // Txo lus me me qhia tau zoo me ntsis kev ua tau zoo dua nrog tus qauv thib 2.
            //
            // Txhua txoj kev tau raug ntsuas, thiab qhov 3 qhia tau zoo tshaj plaws.Yog li peb tau xaiv qhov ntawd.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // Nruab nrab lub xeev ntawm cov txheej txheem nkag yog ib txwm taug qab los ntawm `hole`, uas pabcuam ob lub hom phiaj:
            // 1. Tiv thaiv kev ncaj ncees ntawm `v` los ntawm panics hauv `is_less`.
            // 2. Ua kom tiav qhov seem hauv `v` thaum kawg.
            //
            // Panic kev nyab xeeb:
            //
            // Yog tias `is_less` panics thaum twg los tau thaum lub sijhawm ua, `hole` yuav tau poob thiab sau lub qhov hauv `v` nrog `tmp`, yog li xyuas kom meej tias `v` tseem tuav txhua yam nws pib tuav ib zaug.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` tau txais poob thiab yog li luam cov `tmp` rau hauv qhov seem ntxiv hauv `v`.
        }
    }

    // Thaum poob, luam tawm los ntawm `src` rau `dest`.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// Kev sib txuas ua ke uas tsis txo qis sau `v[..mid]` thiab `v[mid..]` siv `buf` li kev cia ib ntus, thiab khaws cov txiaj ntsig mus rau `v[..]`.
///
/// # Safety
///
/// Lub ob slices yuav tsum tau uas tsis yog-empty thiab `mid` yuav tsum nyob rau hauv ciam teb.
/// Buffer `buf` yuav tsum tau siv sijhawm ntev los tuav daim ntawv luv ntawm daim ntawv luv.
/// Kuj, `T` yuav tsum tsis yog xoom hom.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // Cov txheej txheem sib xyaw ua ntej luam cov luv khiav mus rau `buf`.
    // Ces nws ib co kua nplaum rau hauv lub tshiab khiv theej mus dhia thiab ntev mus dhia forwards (los yog rov mus), muab piv lawv cov tom ntej unconsumed ntsiab thiab luam cov lesser (los yog siab dua) ib tug mus rau `v`.
    //
    // Sai li lub sijhawm luv luv tau siv tag nrho, txoj kev ua tiav.Yog tias ntev mus dhia tau txais ua ntej, tom qab ntawd peb yuav tsum luam txhua qhov seem ntawm qhov luv luv khiav mus rau hauv seem uas nyob hauv `v`.
    //
    // Nruab nrab ntawm lub xeev cov txheej txheem ib txwm taug qab los ntawm `hole`, uas pabcuam ob lub hom phiaj:
    // 1. Tiv thaiv kev ncaj ncees ntawm `v` los ntawm panics hauv `is_less`.
    // 2. Ua kom tiav cov seem nyob rau hauv `v` yog qhov ntev khiav tau txais ua ntej.
    //
    // Panic kev nyab xeeb:
    //
    // Yog tias `is_less` panics thaum twg los tau thaum lub sijhawm ua, `hole` yuav tau poob thiab sau lub qhov hauv `v` nrog rau qhov tsis muaj qhov ntsuas nyob hauv `buf`, yog li xyuas kom meej tias `v` tseem tuav txhua yam khoom nws pib tuav ib zaug.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // Cov laug khiav ua luv dua.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // Chiv, cov pointers taw tes rau lub pib ntawm lawv cov arrays.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Haus tsawg dua sab.
            // Yog muaj kev sib txig sib luag, xum mus rau sab laug kom muaj kev ruaj khov.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // Txoj kev khiav nrawm yog luv dua.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // Thaum pib, cov ntsiab lus no taw tes dhau mus rau qhov xaus ntawm lawv cov arrays.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Haus ntau dua rau sab.
            // Yog hais tias sib npaug, xav rau txoj kev khiav kom muaj stability.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // Thaum kawg, `hole` poob qis.
    // Yog tias qhov luv khiav mus tsis tau noj tag nrho, txhua yam seem ntawm nws yuav tam sim no tau theej rau hauv lub qhov `v` X.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // Thaum poob, luam cov kab ntawv `start..end` rau `dest..`.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` tsis yog xoom hom me me, yog li nws faib tawm los ntawm nws qhov loj.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Qhov kev sib txuam no qiv qee cov tswv yim (tab sis tsis yog tag nrho) los ntawm TimSort, uas tau piav qhia meej [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt).
///
///
/// Lub algorithm qhia nruj me ntsis nqis thiab uas tsis yog-nqis subsequences, uas yog hu ua ntuj sau.Muaj ib pawg ntawm cov sau cia thaum tseem tsis tau muab tso ua ke.
/// Txhua qhov kev tawm tshiab uas tau pom thawb thawb mus rau hauv pawg, thiab tom qab ntawd qee qhov kev sib tw uas tau sib txuas yog sib xyaw ua ke kom txog thaum ob kab ntawm no txaus siab:
///
/// 1. rau txhua txhua `i` hauv `1..runs.len()`: `runs[i - 1].len > runs[i].len`
/// 2. rau txhua txhua `i` hauv `2..runs.len()`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// Cov kev lees paub tseeb tias tag nrho lub sijhawm khiav yog *O*(*n*\*log(* n*)) qhov tsis zoo tshaj plaws.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Slices ntawm li no ntev tau txheeb siv zoo tsi.
    const MAX_INSERTION: usize = 20;
    // Cov kev khiav tawm luv heev yog ncua siv cov ntxig rau kom nruj txog qhov tsawg kawg no ntau yam khoom siv.
    const MIN_RUN: usize = 10;

    // Qhov muaj tsis muaj nuj nqis tus cwj pwm nyob rau hauv xoom-sized hom.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // Cov teeb qhia luv tau txheeb nyob rau hauv-chaw ntawm teeb ntxig kom tsis txhob muaj kev faib tawm.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Teem ib tug tsis siv raws li kos nco.Peb khaws qhov ntev 0 yog li peb tuaj yeem khaws cia nyob rau hauv nws ntiav cov ntawv luam ntawm cov ntsiab lus ntawm `v` yam tsis muaj kev pheej hmoo rau cov dtors khiav ntawm cov ntawv luam yog `is_less` panics.
    //
    // Thaum sib koom ua ke ob txoj kev sib tw, tus tsis zoo no khaws cov ntawv sau luv, uas yuav ib txwm muaj qhov ntev ntawm feem ntau `len / 2`.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // Txhawm rau kom paub qhov tseeb khiav hauv `v`, peb hle nws rov qab.
    // Qhov ntawd yuav zoo li kev txiav txim siab coj txawv txawv, tab sis xav txog qhov tseeb tias kev sib koom tes ntau dua mus rau hauv cov lus rov (forwards).
    // Raws li kev ntsuas, kev sib koom tes forwards yog nrawm dua li kev sib koom ua ke rov qab.
    // Los ntawm xaus, txheeb xyuas los ntawm kev ua lag luam thim rov qab txhim kho kev ua tau zoo.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Nrhiav lub ntuj tom ntej khiav, thiab rov qab nws yog tias nws ncaj qha nqis los.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Ntxig qee lub ntsiab ntxiv rau hauv kev khiav yog tias nws luv heev.
        // Tso ntxig tau ua ke tau nrawm dua ntawm kev sib dhos ntawm cov qib luv, yog li qhov no cuam tshuam kev ua tau zoo.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Tso qhov no khiav mus rau pawg.
        runs.push(Run { start, len: end - start });
        end = start;

        // Kev sib koom ua ke ib co khub sib txuas khiav ua ke kom txaus siab rau qhov chaw sau npe.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // Thaum kawg, raws nraim ib qho kev khiav tawm yuav tsum nyob twj ywm hauv pawg.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Tshuaj xyuas cov theem ntawm kev khiav thiab qhia txog kev sib tw tom ntej kom sib sau ua ke.
    // Tshwj xeeb tshaj yog, yog `Some(r)` xa rov qab, nws txhais tau tias `runs[r]` thiab `runs[r + 1]` yuav tsum sib koom ua ke tom ntej.
    // Yog hais tias lub algorithm yuav tsum txuas ntxiv tsim kev khiav tshiab hloov, `None` xa rov qab.
    //
    // TimSort tsis zoo rau nws qhov kev siv buggy, raws li tau piav qhia ntawm no:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // Tus gist ntawm zaj dab neeg yog: peb yuav tsum tswj hwm cov kev nkag ntawm plaub lub ncov qaum rau ntawm pawg.
    // Yuam kom lawv tsuas yog peb qho saum toj nkaus xwb tsis txaus kom ntseeg tau tias tus neeg nkag mus rau hauv tseem yuav tuav rau *txhua qhov* khiav hauv pawg.
    //
    // Txoj haujlwm no raug kuaj xyuas qhov chaw nyob ncaj ncees rau saum plaub sau.
    // Tsis tas li ntawd, yog tias kev khiav sab saum toj pib ntawm qhov ntsuas 0, nws yuav ib txwm xav ua haujlwm sib koom ua ke kom txog rau thaum cov ntaiv tag nrho sib tsoo, thiaj li ua tiav qhov kev txiav txim.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}