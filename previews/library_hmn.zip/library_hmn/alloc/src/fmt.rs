//! Cov cuab yeej siv rau kev tawm tswv yim thiab luam ntawv `txoj hlua.
//!
//! Qhov qauv no muaj lub sijhawm txhawb rau lub [`format!`] syntax txuas ntxiv.
//! Qhov no macro yog siv nyob rau hauv lub compiler rau emit hu rau no module nyob rau hauv thiaj li yuav hom lus sib cav ntawm runtime rau hauv cov hlua.
//!
//! # Usage
//!
//! [`format!`] macro yog npaj los ua kom paub cov neeg tuaj ntawm C's `printf`/`fprintf` haujlwm lossis Python's `str.format` muaj nuj nqi.
//!
//! Qee cov piv txwv ntawm cov [`format!`] txuas ntxiv yog:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" nrog ua zeros
//! ```
//!
//! Los ntawm cov no, koj tuaj yeem pom tias thawj kev sib cav yog qhov tawm suab.Nws yog qhov tsim nyog los ntawm cov lus sib dhos rau qhov no yuav yog txoj hlua tiag tiag;nws yuav tsis yog ib tug nce mus nce los dhau nyob rau hauv (nyob rau hauv thiaj li yuav ua validity checking).
//! Tus kwv yees yuav txheeb tawm txoj hlua kab ntawv thiab txiav txim siab seb daim ntawv sib ceg puas tsim nyog dhau rau kab ntawv no.
//!
//! Txhawm rau kom hloov ib tus nqi rau txoj hlua, siv txoj kev [`to_string`].Qhov no yuav siv [`Display`] formatting trait.
//!
//! ## Chaw rau luag
//!
//! Txhua cov kev sib cav tawm tswv yim tau tso cai hais kom meej qhov txiaj ntsig sib cav nws tau hais txog, thiab yog tias rho tawm nws tau kwv yees yog "the next argument".
//! Piv txwv li, hom kab ntawv `{} {} {}` yuav siv peb qho tsis suav, thiab lawv yuav tau kho rau hauv tib qho kev txiav txim raws li lawv tau muab.
//! Cov qauv hlua `{2} {1} {0}`, txawm li cas los xij, yuav tau muab cov lus sib cav hauv kev rov qab txiav txim.
//!
//! Tej yam tuaj yeem nkag mus ib qho me ntsis thaum koj pib sib quas ntus ob hom kev qhia tshwj xeeb.Tus "next argument" qhov tshwj xeeb tuaj yeem xav txog kev ua tus thev dhau kev sib cav.
//! Txhua lub sijhawm "next argument" tus ntsuas pom tau pom, cov ntsuas hluav taws xob nce qib.Qhov no ua rau kev coj cwj pwm zoo li no:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! Lub sab hauv iterator hla lub sib cav tsis tau paub los ntawm lub sij hawm thawj `{}` yog pom, ces nws prints cov thawj sib cav.Tom qab ntawd ncav cuag tus thib ob `{}`, tus tiv thaiv tau nce mus lawm tom ntej rau kev sib ceg zaum ob.
//! Qhov tseem ceeb, cov kev txwv uas qhia meej lub npe lawv cov kev sib cav tsis muaj kev cuam tshuam cov tsis muaj npe uas tsis muaj npe sib cav nyob hauv txoj hauj lwm tshwj xeeb.
//!
//! A hom hlua yuav tsum tau siv tag nrho nws cov lus, txwv tsis pub nws yog ib tug compile-lub sij hawm kev ua yuam kev.Koj tuaj yeem xa mus rau tib qhov kev sib cav ntau dua ib zaug hauv cov kab ntawv.
//!
//! ## Named tsis
//!
//! Rust nws tus kheej tsis muaj Python zoo li sib npaug ntawm cov npe hu ua kom tsis muaj nuj nqi, tab sis [`format!`] macro yog ib qho txuas lus txuas ntxiv uas tso cai rau nws mus leverage lub npe hu ua tsis.
//! Npe tsis muaj npe nyob ntawm qhov kawg ntawm kev sib cav daim ntawv teev npe thiab muaj cov ntawv cim:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Piv txwv li, cov lus hauv qab no [`format!`] txhua qhov siv hu ua kev sib cav:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Nws tsis siv tau los tso rau qhov tsis suav (cov tsis muaj npe) tom qab kev sib cav uas muaj npe.Zoo li nrog cov ntsuas qhov chaw, nws tsis siv tau los muab cov npe uas tsis siv los ntawm txoj hlua hom.
//!
//! # Kev Tawm Tsam Tsis Muaj
//!
//! Txhua qhov kev sib cav uas tau muab kho tau tuaj yeem hloov los ntawm ntau tus qauv tsis haum (sib haum rau `format_spec` hauv [the syntax](#syntax)). Cov kev cuam tshuam no cuam tshuam txoj hlua sawv cev ntawm dab tsi raug tsim.
//!
//! ## Width
//!
//! ```
//! // Tag nrho cov luam tawm "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Qhov no yog qhov tseem ceeb rau lub "minimum width" tias hom yuav tsum nqa.
//! Yog hais tias tus nqi txoj hlua tsis sau txog ntau lub cim no, ces padding teev ntawm fill/alignment yuav siv los coj mus rau qhov chaw xav tau (saib hauv qab).
//!
//! Tus nqi rau qhov dav kuj tuaj yeem muab raws li [`usize`] hauv daim ntawv teev cov tsis dhau los ntawm kev ntxiv postfix `$`, taw qhia tias kev sib cav thib ob yog [`usize`] kev qhia qhov dav.
//!
//! Xa mus rau kev sib cav nrog lub duas syntax tsis cuam tshuam rau "next argument" lub txee, yog li nws feem ntau yog lub tswv yim zoo rau kev xa mus rau kev sib cav los ntawm txoj haujlwm, lossis siv lub npe sib cav.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! Cov yeem sau cov cim thiab cov kab ke yog muab ib txwm nrog kev ua haujlwm nrog [`width`](#width) parameter.Nws yuav tsum tau txhais kom meej ua ntej `width`, txoj cai tom qab `:`.
//! Qhov no qhia tau tias yog tias tus nqi raug tsim yog me dua `width` qee cov cim ntxiv yuav luam tawm ncig nws.
//! Txhaws los nyob rau hauv cov sib txawv hauv qab no rau qhov sib txawv:
//!
//! * `[fill]<` - qhov kev sib cav yog sab laug-sab hauv `width` txhua
//! * `[fill]^` - Cov lus sib cav yog qhov nruab nrab hauv `width` cov kab
//! * `[fill]>` - cov lus sib cav yog txoj cai-txuas hauv `width` cov kab
//!
//! Lub neej qub [fill/alignment](#fillalignment) rau cov tsis muaj lej yog qhov chaw thiab sab laug-dlhos.Lub neej ntawd rau cov lej ua cov zauv tseem yog qhov chaw cim tab sis nrog kho kom haum.
//! Yog tias `0` chij (saib hauv qab) yog teev rau tus lej, tom qab ntawd cov cim sau tag nrho yog `0`.
//!
//! Nco ntsoov tias kev hloov mus ua ke tsis tuaj yeem siv los ntawm qee hom.Hauv kev tshwj xeeb, nws tsis feem ntau ua rau `Debug` trait.
//! Ib txoj hauv kev zoo kom ntseeg tias padding yog thov yog kom koj cov tswv yim, tom qab ntawd qhwv cov hlua no kom tau txais koj cov zis:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Nyob zoo Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Cov no yog cov tag nrho cov chij kev Process lub cwj pwm ntawm qhov formatter.
//!
//! * `+` - Qhov no yog npaj rau cov lej ntau thiab qhia tias lub cim yuav tsum tau luam tawm tas li.Cov phiajcim zoo yeej tsis tau luam tawm los ntawm lub neej ntawd, thiab cov paib tsis zoo tsuas yog luam tawm los ntawm lub neej ntawd rau `Signed` trait.
//! Daim chij no taw qhia tias cov paib raug (`+` lossis `-`) yuav tsum luam tawm tas li.
//! * `-` - Tam sim no tsis siv
//! * `#` - Cov chij no qhia tias "alternate" daim ntawv luam tawm yuav tsum tau siv.Lwm daim foos yog:
//!     * `#?` - zoo nkauj-luam tawm [`Debug`] formatting
//!     * `#x` - ua ntej kev sib cav nrog `0x`
//!     * `#X` - ua ntej kev sib cav nrog `0x`
//!     * `#b` - ua ntej kev sib cav nrog `0b`
//!     * `#o` - ua ntej kev sib cav nrog `0o`
//! * `0` - Qhov no yog siv txhawm rau taw rau cov hom ntawv sib xyaw uas lub padding rau `width` yuav tsum ob qho tib si nrog `0` tus cwj pwm zoo li kos npe-paub.
//! Ib hom ntawv zoo li `{:08}` yuav tawm `00000001` rau tus lej `1`, thaum tib hom ntawv yuav muab `-0000001` rau tus lej `-1`.
//! Daim ntawv ceeb toom tias qhov tsis zoo version muaj tsawg dua xoom tshaj qhov zoo version.
//!         Nco ntsoov tias padding zeros yeej ib txwm tso tom qab lub cim (yog tias muaj) thiab ua ntej tus lej.Thaum siv ua ke nrog `#` chij, txoj cai zoo sib xws siv: lub padding xoom tau muab tso tom qab ua ntej tab sis ua ntej pib tus lej.
//!         Cov lus ua ntej muaj nyob rau hauv tag nrho cov dav.
//!
//! ## Precision
//!
//! Rau cov hom tsis muaj lej, qhov no tuaj yeem suav ua tus "maximum width".
//! Yog hais tias txoj xov xwm tshwm sim tau ntev dua qhov dav no, tom qab ntawd nws raug txiav rau qhov ntau ntawm cov cim thiab tias tus nqi raug txiav tawm tau tsim nrog qhov tsim nyog `fill`, `alignment` thiab `width` yog tias cov tsis tau teeb tsa.
//!
//! Rau cov kev hom, qhov no tsis quav ntsej.
//!
//! Rau cov hom ntab-ntus, qhov no qhia tau tias muaj pes tsawg tus lej tom qab tus lej zauv yuav tsum tau luam tawm.
//!
//! Muaj peb txoj hauv kev los qhia qhov xav tau `precision`:
//!
//! 1. Tus lej `.N`:
//!
//!    Tus lej zauv `N` nws tus kheej yog qhov meej.
//!
//! 2. Tus lej lossis lub npe tom qab daus las kos npe `.N$`:
//!
//!    siv hom ntawv *sib cav*`N` (uas yuav tsum yog `usize`) raws li cov kev paub tseeb.
//!
//! 3. Lub Cim `.*`:
//!
//!    `.*` txhais tau hais tias cov `{...}` no cuam tshuam nrog *ob* hom ntawv sau ntau dua li ib qho: thawj cov tswv yim tuav `usize` qhov tseeb, thiab tus thib ob tuav tus nqi luam tawm.
//!    Nco ntsoov tias qhov xwm txheej no, yog tias ib qho siv cov qauv kab ntawv `{<arg>:<spec>.*}`, tom qab `<arg>` ntu hais txog* tus nqi * luam tawm, thiab `precision` yuav tsum tuaj hauv cov tswv yim ua ntej `<arg>`.
//!
//! Piv txwv li, cov hu hauv qab no txhua yam sau tib qhov `Hello x is 0.01000`:
//!
//! ```
//! // Nyob zoo {arg 0 ("x")} yog {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Nyob zoo {arg 1 ("x")} yog {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Nyob zoo {arg 0 ("x")} yog {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Nyob zoo {next arg ("x")} yog {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Nyob zoo {next arg ("x")} yog {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Nyob zoo {next arg ("x")} yog {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Thaum no:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! luam tawm peb yam sib txawv:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! Hauv qee qhov kev sau ntawv, tus cwj pwm ntawm txoj hlua sib txawv ntawm cov haujlwm ua raws ntawm kev ua haujlwm ntawm thaj chaw ua haujlwm.
//! Cov hom kab ke muab los ntawm Rust lub tsev qiv ntawv txheem tsis muaj ib lub tswvyim ntawm thaj chaw thiab yuav ua cov txiaj ntsig zoo ib yam rau txhua lub tshuab tsis hais tus neeg siv teeb tsa.
//!
//! Piv txwv li, cov cai hauv qab no yuav ib txwm luam ntawv `1.5` txawm tias qhov chaw hauv thaj chaw siv cov zauv cais tawm uas tsis yog dot.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! Cov cim cia `{` thiab `}` tej zaum yuav suav nrog hauv txoj hlua los ntawm kev dhau los ua lawv tus cwj pwm qub.Piv txwv li, `{` tus cwj pwm tau khiav dim nrog `{{` thiab `}` lub cim yog dim nrog `}}`.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Txhawm rau cov ntsiab lus, ntawm no koj tuaj yeem nrhiav cov qauv sau ntawv tag nrho ntawm hom kab ntawv.
//! Cov lus syntax rau cov ntawv siv hom lus yog kos los ntawm lwm hom lus, yog li nws yuav tsum tsis txhob ua neeg txawv txawv ntxiv.Cov lus sib cav yog tsim nrog Python zoo li syntax, txhais tau tias cov lus sib cav tau ncig los ntawm `{}` es tsis yog C-zoo li `%`.
//! Cov qauv sau ntawv tiag tiag rau cov ntawv syntax yog:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! Hauv cov qauv saud saum toj no, `text` tsis tuaj yeem tsis muaj `'{'` lossis `'}'` cov cim.
//!
//! # Kev Ua Qauv traits
//!
//! Thaum thov kom muaj kev sib cav kom haum nrog hom tshwj xeeb, koj yeej thov qhov kev sib cav ascribes rau ib qho trait.
//! Qhov no tso cai rau ntau hom tseeb kom tau teeb tsa ntawm `{:x}` (zoo li [`i8`] thiab [`isize`]).Qhov tam sim no ntawm cov hom rau traits yog:
//!
//! * *tsis muaj dab tsi* ⇒ [`Display`]
//! * `?` [`Debug`]
//! * `x?` ⇒ [`Debug`] nrog qis-rooj plaub hexadecimal suav
//! * `X?` ⇒ [`Debug`] nrog cov tsiaj ntawv loj nrog tus lej sibxws
//! * `o` [`Octal`]
//! * `x` [`LowerHex`]
//! * `X` [`UpperHex`]
//! * `p` [`Pointer`]
//! * `b` [`Binary`]
//! * `e` [`LowerExp`]
//! * `E` [`UpperExp`]
//!
//! Yuav ua li cas no txhais tau tias yog hais tias txhua hom kev sib cav uas siv cov [`fmt::Binary`][`Binary`] trait ces yuav formatted nrog `{:b}`.Qhov kev nqis tes ua tau muab rau cov traits rau ntau tus qauv qub los ntawm lub tsev qiv ntawv txheem zoo ib yam.
//!
//! Yog tias tsis muaj cov hom teev tshwj xeeb (xws li hauv `{}` lossis `{:6}`), tom qab ntawv trait siv yog [`Display`] trait.
//!
//! Thaum siv hom trait rau koj tus kheej hom, koj yuav tsum ua raws li ib txoj kev ntawm kev kos npe:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // peb hom kev cai
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Koj hom yuav dhau los ua `self` los-siv, thiab tom qab ntawd txoj haujlwm yuav tsum tso tawm cov zis rau hauv `f.buf` ntws.Nws yog nyob ntawm txhua hom trait kev siv kom raug raws li cov lus thov cov qauv tsis raug.
//! Lub txiaj ntsig ntawm cov ntsuas no yuav tau teev nyob rau hauv cov yam ntxwv ntawm [`Formatter`] tus qauv.Txhawm rau pab nrog qhov no, [`Formatter`] tus qauv kuj tseem muaj qee txoj kev pabcuam.
//!
//! Tsis tas li ntawd, rov qab tus nqi ntawm no muaj nuj nqi yog [`fmt::Result`] uas yog ib hom kev cai ntawm ['Result`]' <(), '[' std: : fmt::Error`] '>'.
//! Kev siv cov txheej txheem yuav tsum xyuas kom meej tias lawv nthuav tawm yuam kev los ntawm [`Formatter`] (piv txwv li, thaum hu [`write!`]).
//! Txawm li cas los xij, lawv yuav tsum tsis txhob rov ua yuam kev sai sai.
//! Ntawd yog, kev ua qauv siv yuav tsum thiab tsuas yog rov qab ua yuam kev yog tias dhau-hauv [`Formatter`] rov ua qhov yuam kev.
//! Qhov no vim tias, qhov tsis zoo rau qhov kos npe rau lub luag haujlwm yuav qhia, txoj hlua khi qauv yog ib txoj haujlwm tsis ua haujlwm zoo.
//! Qhov no muaj nuj nqi tsuas rov ib tug tshwm sim vim hais tias sau ntawv mus rau lwm kwj yuav tsis thiab nws yuav tsum muab ib txoj kev mus rau propagate lub fact tias ib tug yuam kev tau tshwm sim rov qab mus rau lub teeb.
//!
//! Ib qho piv txwv ntawm kev coj ua cov traits yuav zoo li:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // Tus nqi `f` coj los siv `Write` trait, uas yog dab tsi sau!macro yog expecting.
//!         // Nco ntsoov tias cov hom ntawv no tsis quav ntsej txog ntau tus chij muab rau hom kab ntawv.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // Txawv traits cia cov ntawv sib txawv ntawm cov zis ntawm ib hom.
//! // Lub ntsiab lus ntawm hom ntawv no yog luam tawm qhov loj ntawm vector.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Hwm cov chij hom sau ntawv los ntawm kev siv tus txheej txheem pabcuam `pad_integral` ntawm daim ntawv foos Formatter.
//!         // Saib cov qauv txheej txheem rau cov ntsiab lus, thiab cov haujlwm `pad` tuaj yeem siv los tuav cov hlua.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` vs `fmt::Debug`
//!
//! Ob hom ntawv traits no muaj lub hom phiaj sib txawv:
//!
//! - [`fmt::Display`][`Display`] kev siv qhia tias hom tuaj yeem sawv cev ncaj ncees raws li txoj hlua UTF-8 txhua lub sijhawm.Nws yog **tsis yog** xav kom txhua hom siv [`Display`] trait.
//! - [`fmt::Debug`][`Debug`] kev siv yuav tsum ua rau **txhua** hom pej xeem.
//!   Cov neeg tso zis yuav feem ntau sawv cev rau lub xeev sab hauv raws li qhov ua tau.
//!   Lub hom phiaj ntawm [`Debug`] trait yog txhawm rau txhim kho kev debugging Rust code.Feem ntau, siv `#[derive(Debug)]` yog qhov txaus thiab pom zoo.
//!
//! Qee cov qauv ntawm cov zis los ntawm ob traits:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Muaj feem xyuam macros
//!
//! Muaj ntau tus naj npawb ntawm cov macros hauv [`format!`] tsev neeg.Cov uas tab tom siv tam sim no yog:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Qhov no thiab [`writeln!`] yog ob qho loj heev uas yog siv los emit cov hom ntawv qhia rau cov kwj teev.Qhov no yog siv los tiv thaiv nruab nrab ntawm kev faib cov hom hlua thiab tsis sau ncaj qha tsim tawm.
//! Hauv qab hood, qhov haujlwm no tau hais tiag [`write_fmt`] kev ua haujlwm tau txhais ntawm [`std::io::Write`] trait.
//! Piv txwv li kev siv yog:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Qhov no thiab [`println!`] emit lawv cov zis rau stdout.Ib yam li ntawd mus rau lub [`write!`] macro, lub hom phiaj ntawm cov macros yog kom tsis txhob intermediate nyiaj thaum luam zis.Piv txwv li kev siv yog:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! Qhov [`eprint!`] thiab [`eprintln!`] macros zoo ib yam rau [`print!`] thiab [`println!`], ntsig txog, tshwj tsis yog lawv emit lawv cov zis rau stderr.
//!
//! ### `format_args!`
//!
//! Qhov no yog qhov xav paub mas siv rau kev nyab xeeb dhau nyob ib ncig ntawm cov khoom opaque piav txog hom hlua.Qhov khoom siv no tsis tas yuav siv lub heap faib los tsim, thiab nws tsuas yog siv cov ntaub ntawv hais txog ntawm pawg.
//! Hauv qab qhov hood, txhua yam ntsig txog macros yog ua raws li qhov no.
//! Xub tawm, qee qhov kev siv piv txwv yog:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! Qhov tshwm sim ntawm [`format_args!`] macro yog tus nqi ntawm hom [`fmt::Arguments`].
//! Cov qauv no tom qab ntawd tuaj yeem xa mus rau [`write`] thiab [`format`] haujlwm hauv qhov qauv no thiaj li ua tiav cov qauv txheej txheem.
//! Lub hom phiaj ntawm loj heev no yog kom txawm tias tiv thaiv kev faib tawm qib nruab nrab thaum cuam tshuam nrog kev ua cov hlua.
//!
//! Piv txwv li, lub tsev qiv ntawv txiav tawm tuaj yeem siv cov qauv sau ntawv sib txawv, tab sis nws yuav nyob sab hauv ib ncig ntawm cov qauv no kom txog thaum nws tau txiav txim siab tias cov zis yuav tsum mus rau qhov twg.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// Tus `format` muaj nuj nqi yuav siv ib qho [`Arguments`] tus qauv thiab rov muab txoj xov tshwm sim.
///
///
/// [`Arguments`] piv txwv tuaj yeem tsim nrog [`format_args!`] loj heev.
///
/// # Examples
///
/// Kev siv theem pib:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Thov nco ntsoov tias kev siv [`format!`] tej zaum yuav xum.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}