//! Ntawv hlais Unicode.
//!
//! *[See also the `str` primitive type](str).*
//!
//! `&str` hom yog ib qho ob txoj hlua loj, ib qho yog `String`.
//! Tsis zoo li nws cov `String` counterpart, nws cov ntsiab lus tau qiv.
//!
//! # Kev Siv Yooj Yim
//!
//! Ntawv tshaj tawm txoj kab theem pib ntawm `&str` yam:
//!
//! ```
//! let hello_world = "Hello, World!";
//! ```
//!
//! Ntawm no peb tau tshaj tawm txoj hlua khoob, tseem hu ua ib txoj hlua sib dhos.
//! Hlua literals muaj ib tug zoo li qub neej, uas txhais tau tias cov hlua `hello_world` yuav lav yuav tsum siv tau rau lub caij ntawm tag nrho cov kev pab cuam.
//!
//! Peb tuaj yeem hais meej meej meej nyob ntawm 'hello_world` lub neej zoo ib yam:
//!
//! ```
//! let hello_world: &'static str = "Hello, world!";
//! ```

#![stable(feature = "rust1", since = "1.0.0")]
// Ntau yam kev siv hauv qhov qauv no tsuas yog siv hauv kev ntsuas teeb tsa.
// Nws yog tsev ntxhua khaub ncaws kom tsuas yog kaw cov lus ceeb toom tsis siv-tshaj tawm dua li txhim kho lawv.
#![allow(unused_imports)]

use core::borrow::{Borrow, BorrowMut};
use core::iter::FusedIterator;
use core::mem;
use core::ptr;
use core::str::pattern::{DoubleEndedSearcher, Pattern, ReverseSearcher, Searcher};
use core::unicode::conversions;

use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::slice::{Concat, Join, SliceIndex};
use crate::string::String;
use crate::vec::Vec;

#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::pattern;
#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use core::str::EncodeUtf16;
#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use core::str::SplitAsciiWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::SplitWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8, from_utf8_mut, Bytes, CharIndices, Chars};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8_unchecked, from_utf8_unchecked_mut, ParseBoolError};
#[stable(feature = "str_escape", since = "1.34.0")]
pub use core::str::{EscapeDebug, EscapeDefault, EscapeUnicode};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{FromStr, Utf8Error};
#[allow(deprecated)]
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Lines, LinesAny};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{MatchIndices, RMatchIndices};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Matches, RMatches};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplit, Split};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitN, SplitN};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitTerminator, SplitTerminator};

/// Note: `str` hauv `Concat<str>` tsis tseem ceeb rau ntawm no.
/// Hom parameter ntawm trait tsuas yog tshwm sim los ua kom lwm tus impl.
#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Concat<str> for [S] {
    type Output = String;

    fn concat(slice: &Self) -> String {
        Join::join(slice, "")
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Join<&str> for [S] {
    type Output = String;

    fn join(slice: &Self, sep: &str) -> String {
        unsafe { String::from_utf8_unchecked(join_generic_copy(slice, sep.as_bytes())) }
    }
}

macro_rules! specialize_for_lengths {
    ($separator:expr, $target:expr, $iter:expr; $($num:expr),*) => {{
        let mut target = $target;
        let iter = $iter;
        let sep_bytes = $separator;
        match $separator.len() {
            $(
                // loops nrog qhov ntau thiab tsawg hardcoded khiav ntau nrawm dua tshwj xeeb cov kis nrog qhov ntev me cais
                //
                $num => {
                    for s in iter {
                        copy_slice_and_advance!(target, sep_bytes);
                        let content_bytes = s.borrow().as_ref();
                        copy_slice_and_advance!(target, content_bytes);
                    }
                },
            )*
            _ => {
                // arbitrary tsis-xoom me me poob
                for s in iter {
                    copy_slice_and_advance!(target, sep_bytes);
                    let content_bytes = s.borrow().as_ref();
                    copy_slice_and_advance!(target, content_bytes);
                }
            }
        }
        target
    }}
}

macro_rules! copy_slice_and_advance {
    ($target:expr, $bytes:expr) => {
        let len = $bytes.len();
        let (head, tail) = { $target }.split_at_mut(len);
        head.copy_from_slice($bytes);
        $target = tail;
    };
}

// Zoo dua koom nrog kev siv uas ua haujlwm rau ob qho tib si Vec<T>(T: Luam) thiab String's puab vec Tam sim no (2018-05-13) muaj kab laum nrog hom kev nkag siab thiab tshwj xeeb (saib qhov teeb meem #36262) Vim li no SliceConcat<T>tsis yog tshwj xeeb rau T: Luam Ntawv thiab SliceConcat<str>tsuas yog tus siv ntawm txoj haujlwm no.
// Nws tseem tshuav nyob hauv qhov chaw rau lub sijhawm thaum teem tau.
//
// cov ciaj ciam rau txoj hlua-koom nrog yog S: Qiv<str>thiab rau Vec-koom Qiv <[T]> [T] thiab str ob impl AsRef <[T]> rau qee T
// => s.borrow().as_ref() thiab peb ib txwm muaj xais
//
//
//
fn join_generic_copy<B, T, S>(slice: &[S], sep: &[T]) -> Vec<T>
where
    T: Copy,
    B: AsRef<[T]> + ?Sized,
    S: Borrow<B>,
{
    let sep_len = sep.len();
    let mut iter = slice.iter();

    // thawj daim tsuas yog tib qho tsis muaj tus muab cais ua ntej nws
    let first = match iter.next() {
        Some(first) => first,
        None => return vec![],
    };

    // laij lub caij nyoog tag nrho ntev ntawm lub koom Vec yog hais tias tus `len` xam overflows, peb mam li panic peb yuav tau khiav tawm ntawm lub cim xeeb lawm thiab tus so ntawm cov nuj nqi yuav tsum tau tag nrho cov Vec pre-faib kev ruaj ntseg
    //
    //
    //
    let reserved_len = sep_len
        .checked_mul(iter.len())
        .and_then(|n| {
            slice.iter().map(|s| s.borrow().as_ref().len()).try_fold(n, usize::checked_add)
        })
        .expect("attempt to join into collection with len > usize::MAX");

    // npaj ib qho tsis muaj kauv
    let mut result = Vec::with_capacity(reserved_len);
    debug_assert!(result.capacity() >= reserved_len);

    result.extend_from_slice(first.borrow().as_ref());

    unsafe {
        let pos = result.len();
        let target = result.get_unchecked_mut(pos..reserved_len);

        // daim ntawv separator thiab hlais dua yam tsis muaj qhov tsem tsim kom muaj cov loops nrog cov tso tawm kom ruaj khov rau cov separator me me txhim kho tau (~ x2)
        //
        //
        let remain = specialize_for_lengths!(sep, target, iter; 0, 1, 2, 3, 4);

        // Kev siv qiv txawv txawv tuaj yeem rov qab nyias cov txheej txheem rau kev xam lub sijhawm thiab daim qauv luam.
        //
        // Nco ntsoov peb tsis txhob lam tau lam ua cov uas tsis tsim nyog rau tus hu.
        let result_len = reserved_len - remain.len();
        result.set_len(result_len);
    }
    result
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Borrow<str> for String {
    #[inline]
    fn borrow(&self) -> &str {
        &self[..]
    }
}

#[stable(feature = "string_borrow_mut", since = "1.36.0")]
impl BorrowMut<str> for String {
    #[inline]
    fn borrow_mut(&mut self) -> &mut str {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ToOwned for str {
    type Owned = String;
    #[inline]
    fn to_owned(&self) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().to_owned()) }
    }

    fn clone_into(&self, target: &mut String) {
        let mut b = mem::take(target).into_bytes();
        self.as_bytes().clone_into(&mut b);
        *target = unsafe { String::from_utf8_unchecked(b) }
    }
}

/// Cov hau kev rau cov hlua hlais.
#[lang = "str_alloc"]
#[cfg(not(test))]
impl str {
    /// Converts ib `Box<str>` rau hauv ib lub `Box<[u8]>` tsis luam los yog allocating.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let s = "this is a string";
    /// let boxed_str = s.to_owned().into_boxed_str();
    /// let boxed_bytes = boxed_str.into_boxed_bytes();
    /// assert_eq!(*boxed_bytes, *s.as_bytes());
    /// ```
    #[stable(feature = "str_box_extras", since = "1.20.0")]
    #[inline]
    pub fn into_boxed_bytes(self: Box<str>) -> Box<[u8]> {
        self.into()
    }

    /// Pauv tag nrho qhov yuam kev ntawm ib tug qauv rau lwm txoj hlua.
    ///
    /// `replace` tsim ib tug tshiab [`String`], thiab cov ntawv luam cov ntaub ntawv los ntawm no txoj hlua hlais mus rau hauv nws.
    /// Thaum ua li ntawd, nws sim nrhiav qhov yuam kev ntawm cov qauv.
    /// Yog tias nws pom ib qho twg, nws hloov lawv nrog cov hlua hloov tshiab.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let s = "this is old";
    ///
    /// assert_eq!("this is new", s.replace("old", "new"));
    /// ```
    ///
    /// Thaum tus qauv tsis phim:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replace("cookie monster", "little lamb"));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn replace<'a, P: Pattern<'a>>(&'a self, from: P, to: &str) -> String {
        let mut result = String::new();
        let mut last_end = 0;
        for (start, part) in self.match_indices(from) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Hloov ua ntej N ntais ntawv ntawm cov qauv nrog lwm txoj hlua khi.
    ///
    /// `replacen` tsim ib tug tshiab [`String`], thiab cov ntawv luam cov ntaub ntawv los ntawm no txoj hlua hlais mus rau hauv nws.
    /// Thaum ua li ntawd, nws sim nrhiav qhov yuam kev ntawm cov qauv.
    /// Yog tias nws pom ib qho twg, nws hloov lawv nrog cov hlua hloov hloov ntawm feem ntau `count` sijhawm.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let s = "foo foo 123 foo";
    /// assert_eq!("new new 123 foo", s.replacen("foo", "new", 2));
    /// assert_eq!("faa fao 123 foo", s.replacen('o', "a", 3));
    /// assert_eq!("foo foo new23 foo", s.replacen(char::is_numeric, "new", 1));
    /// ```
    ///
    /// Thaum tus qauv tsis phim:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replacen("cookie monster", "little lamb", 10));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "str_replacen", since = "1.16.0")]
    pub fn replacen<'a, P: Pattern<'a>>(&'a self, pat: P, to: &str, count: usize) -> String {
        // Vam tias yuav txo qis lub sijhawm ntawm rov faib cov ntawv
        let mut result = String::with_capacity(32);
        let mut last_end = 0;
        for (start, part) in self.match_indices(pat).take(count) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Rov qab qis dua qhov qis tshaj ntawm txoj hlua hlais, li [`String`] tshiab.
    ///
    /// 'Lowercase' yog txhais raws li cov lus ntawm Unicode Derived Core Property `Lowercase`.
    ///
    /// Txij li thaum qee cov cim tuaj yeem nthuav dav mus rau ntau lub cim thaum hloov rooj plaub, txoj haujlwm no xa rov qab [`String`] hloov qhov hloov kho qhov parameter hauv-chaw.
    ///
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let s = "HELLO";
    ///
    /// assert_eq!("hello", s.to_lowercase());
    /// ```
    ///
    /// Piv txwv lo qhia, nrog sigma:
    ///
    /// ```
    /// let sigma = "Σ";
    ///
    /// assert_eq!("σ", sigma.to_lowercase());
    ///
    /// // tab sis qhov kawg ntawm ib lo lus, nws yog ς, tsis yog σ:
    /// let odysseus = "ὈΔΥΣΣΕΎΣ";
    ///
    /// assert_eq!("ὀδυσσεύς", odysseus.to_lowercase());
    /// ```
    ///
    /// Cov lus tsis muaj kis tsis raug hloov:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_lowercase());
    /// ```
    ///
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_lowercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for (i, c) in self[..].char_indices() {
            if c == 'Σ' {
                // Σ maps rau σ, tsuas yog qhov kawg ntawm ib lo lus qhov twg nws maps rau ς.
                // Qhov no tsuas yog cov neeg mob (contextual) tab sis cov lus-ywj siab daim phiaj qhia hauv `SpecialCasing.txt`, yog li cov lej nyuaj nws es tsis muaj cov xaim "condition" cov qauv.
                //
                // See https://github.com/rust-lang/rust/issues/26035
                //
                map_uppercase_sigma(self, i, &mut s)
            } else {
                match conversions::to_lower(c) {
                    [a, '\0', _] => s.push(a),
                    [a, b, '\0'] => {
                        s.push(a);
                        s.push(b);
                    }
                    [a, b, c] => {
                        s.push(a);
                        s.push(b);
                        s.push(c);
                    }
                }
            }
        }
        return s;

        fn map_uppercase_sigma(from: &str, i: usize, to: &mut String) {
            // See http://www.unicode.org/versions/Unicode7.0.0/ch03.pdf#G33992
            // rau cov lus txhais ntawm `Final_Sigma`.
            debug_assert!('Σ'.len_utf8() == 2);
            let is_word_final = case_ignoreable_then_cased(from[..i].chars().rev())
                && !case_ignoreable_then_cased(from[i + 2..].chars());
            to.push_str(if is_word_final { "ς" } else { "σ" });
        }

        fn case_ignoreable_then_cased<I: Iterator<Item = char>>(iter: I) -> bool {
            use core::unicode::{Case_Ignorable, Cased};
            match iter.skip_while(|&c| Case_Ignorable(c)).next() {
                Some(c) => Cased(c),
                None => false,
            }
        }
    }

    /// Rov qab xa cov ntawv loj dua ntawm txoj hlua hlais, li [`String`] tshiab.
    ///
    /// 'Uppercase' yog txhais raws li cov lus ntawm Unicode Derived Core Property `Uppercase`.
    ///
    /// Txij li thaum qee cov cim tuaj yeem nthuav dav mus rau ntau lub cim thaum hloov rooj plaub, txoj haujlwm no xa rov qab [`String`] hloov qhov hloov kho qhov parameter hauv-chaw.
    ///
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let s = "hello";
    ///
    /// assert_eq!("HELLO", s.to_uppercase());
    /// ```
    ///
    /// Cov ntawv sau tsis muaj rooj plaub tsis hloov:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_uppercase());
    /// ```
    ///
    /// Ib lub cim tuaj yeem dhau los ua ntau yam:
    ///
    /// ```
    /// let s = "tschüß";
    ///
    /// assert_eq!("TSCHÜSS", s.to_uppercase());
    /// ```
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_uppercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for c in self[..].chars() {
            match conversions::to_upper(c) {
                [a, '\0', _] => s.push(a),
                [a, b, '\0'] => {
                    s.push(a);
                    s.push(b);
                }
                [a, b, c] => {
                    s.push(a);
                    s.push(b);
                    s.push(c);
                }
            }
        }
        s
    }

    /// Hloov tus [`Box<str>`] rau [`String`] tsis tau theej lossis faib.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// let string = String::from("birthday gift");
    /// let boxed_str = string.clone().into_boxed_str();
    ///
    /// assert_eq!(boxed_str.into_string(), string);
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_string(self: Box<str>) -> String {
        let slice = Box::<[u8]>::from(self);
        unsafe { String::from_utf8_unchecked(slice.into_vec()) }
    }

    /// Tsim tus tshiab [`String`] los ntawm kev rov ua txoj hlua `n` zaug.
    ///
    /// # Panics
    ///
    /// Txoj haujlwm no yuav panic yog tias lub peev xwm yuav dhau.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// assert_eq!("abc".repeat(4), String::from("abcabcabcabc"));
    /// ```
    ///
    /// A panic li txeej:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// "0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_str", since = "1.16.0")]
    pub fn repeat(&self, n: usize) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().repeat(n)) }
    }

    /// Rov qab daim ntawv theej ntawm txoj hlua no qhov twg txhua tus cim tau mapped rau nws ASCII qaum rooj plaub sib npaug.
    ///
    ///
    /// ASCII cov ntawv 'a' rau 'z' yog mapped rau 'A' rau 'Z', tab sis cov tsiaj ntawv tsis-ASCII tsis hloov pauv.
    ///
    /// Txhawm rau ua kom tus nqi nyob rau hauv-qhov chaw, siv [`make_ascii_uppercase`].
    ///
    /// Txhawm rau uppercase ASCII cov cim ntxiv rau tsis yog-ASCII cov cim, siv [`to_uppercase`].
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase`]: str::make_ascii_uppercase
    /// [`to_uppercase`]: #method.to_uppercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_uppercase();
        // make_ascii_uppercase() khaws cia UTF-8 qhov tsis txaus.
        unsafe { String::from_utf8_unchecked(bytes) }
    }

    /// Rov qab daim ntawv theej ntawm txoj hlua no qhov twg txhua tus cim tau mapped rau nws ASCII cov ntaub ntawv sib npaug.
    ///
    ///
    /// ASCII cov ntawv 'A' rau 'Z' yog mapped rau 'a' rau 'z', tab sis cov tsiaj ntawv tsis-ASCII tsis hloov pauv.
    ///
    /// Txhawm rau txo tus nqi hauv-chaw, siv [`make_ascii_lowercase`].
    ///
    /// Txo qis ASCII cov cim ntxiv rau cov tsis yog-ASCII cov cim, siv [`to_lowercase`].
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("grüße, jürgen ❤", s.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase`]: str::make_ascii_lowercase
    /// [`to_lowercase`]: #method.to_lowercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_lowercase();
        // make_ascii_lowercase() khaws cia UTF-8 qhov tsis txaus.
        unsafe { String::from_utf8_unchecked(bytes) }
    }
}

/// Hloov ib qho sib txuas ntawm lub npov ntawm lub bytes rau ib lub thawv txoj kab ntawv uas tsis tau xyuas tias txoj hlua muaj qhov siv tau UTF-8.
///
///
/// # Examples
///
/// Kev siv theem pib:
///
/// ```
/// let smile_utf8 = Box::new([226, 152, 186]);
/// let smile = unsafe { std::str::from_boxed_utf8_unchecked(smile_utf8) };
///
/// assert_eq!("☺", &*smile);
/// ```
#[stable(feature = "str_box_extras", since = "1.20.0")]
#[inline]
pub unsafe fn from_boxed_utf8_unchecked(v: Box<[u8]>) -> Box<str> {
    unsafe { Box::from_raw(Box::into_raw(v) as *mut str) }
}