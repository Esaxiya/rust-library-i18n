//! Ib tug pointer hom rau heap faib.
//!
//! [`Box<T>`], casually xa mus rau raws li 'box', muab qhov yooj yim tshaj plaws daim ntawv ntawm heap faib hauv Rust.Cov npov muab cov tswv cuab rau cov kev faib no, thiab tso lawv cov ncauj lus thaum lawv mus tsis muaj peev xwm.Cov thawv kuj tseem kom lawv tsis txhob faib ntau tshaj `isize::MAX` bytes.
//!
//! # Examples
//!
//! Tsiv tus nqi ntawm cov tshooj rau hauv heap los ntawm kev tsim lub [`Box`]:
//!
//! ```
//! let val: u8 = 5;
//! let boxed: Box<u8> = Box::new(val);
//! ```
//!
//! Tsiv tawm tus nqi ntawm [`Box`] rov qab rau pawg los ntawm [dereferencing]:
//!
//! ```
//! let boxed: Box<u8> = Box::new(5);
//! let val: u8 = *boxed;
//! ```
//!
//! Tsim tus qauv hais rov txuas ntxiv:
//!
//! ```
//! #[derive(Debug)]
//! enum List<T> {
//!     Cons(T, Box<List<T>>),
//!     Nil,
//! }
//!
//! let list: List<i32> = List::Cons(1, Box::new(List::Cons(2, Box::new(List::Nil))));
//! println!("{:?}", list);
//! ```
//!
//! Qhov no yuav luam `Cons (1, Cons(2, Nil))`.
//!
//! Rov teeb tsa tus txheej txheem yuav tsum tau thawv, vim tias yog tias cov ntsiab lus ntawm `Cons` zoo li qhov no:
//!
//! ```compile_fail,E0072
//! # enum List<T> {
//! Cons(T, List<T>),
//! # }
//! ```
//!
//! Nws yuav tsis ua haujlwm.Qhov no yog vim tias qhov luaj li cas ntawm `List` nyob ntawm seb muaj pes tsawg lub ntsiab lus nyob hauv, thiab yog li peb tsis paub ntau npaum li cas lub cim xeeb faib rau `Cons`.Los ntawm kev qhia txog [`Box<T>`], uas muaj qhov txhais tau loj, peb paub tias `Cons` loj npaum li cas.
//!
//! # Cim xeeb
//!
//! Rau qhov tsis yog-xoom xoom qhov tseem ceeb, ib qho [`Box`] yuav siv [`Global`] kev faib khoom rau nws cov kev faib.Nws yog qhov siv tau los hloov ob txoj hauv kev los ntawm [`Box`] thiab cov pointer nyoo faib nrog [`Global`] tus muab, muab tias [`Layout`] siv nrog cov neeg faib khoom yog qhov tseeb rau hom.
//!
//! Ntau qhov tseeb, ib qho `value:*mut T` uas tau faib nrog [`Global`] tshwj xeeb nrog `Layout::for_value(&* value)` tej zaum yuav hloov mus rau hauv ib lub thawv uas siv [`Box::<T>::from_raw(value)`].
//! Hloov pauv, lub cim xeeb thaub qab `value:*mut T` tau los ntawm [`Box::<T>::into_raw`] tej zaum yuav sib cog lus siv [`Global`] kev faib nrog [`Layout::for_value(&* value)`].
//!
//! Txog rau cov ntsuas xoom, qhov tseem ceeb ntawm `Box` lub pointer tseem yuav tsum yog [valid] rau kev nyeem thiab sau thiab ua raws li cov ntawv sau txaus.
//! Hauv tshwj xeeb, nrum kev siv cov xaim tsis-xoom tus lej nkag mus rau lub pointer nyoos tsim tawm lub pointer siv tau, tab sis tus po taw tes rau hauv kev faib ua ntej kev nco uas txij li tau txais kev ywj pheej tsis siv tau.
//! Cov kev pom zoo los tsim Lub Box rau ZST yog tias `Box::new` tsis tuaj yeem siv yog siv [`ptr::NonNull::dangling`].
//!
//! Yog li ntawd ntev li `T: Sized`, `Box<T>` tau lees tias sawv cev raws li ib tus pointer thiab tseem yog ABI-sib haum nrog C pointers (piv txwv li C hom `T*`).
//! Qhov no txhais tau tias yog tias koj muaj sab nrauv "C" Rust kev ua haujlwm uas yuav raug hu los ntawm C, koj tuaj yeem txhais cov haujlwm Rust uas siv `Box<T>` hom, thiab siv `T*` raws li cov coj ntawm C sab.
//! Ua piv txwv, xav txog qhov C header uas tshaj tawm cov haujlwm uas tsim thiab rhuav tshem qee yam `Foo` nqi:
//!
//! ```c
//! /* C taub */
//!
//! /* Rov qab cov tswv cuab rau tus neeg hu */
//! struct Foo* foo_new(void);
//!
//! /* Yuav siv tswv yim los ntawm tus hu;tsis-op thaum invoked nrog NULL */
//! void foo_delete(struct Foo*);
//! ```
//!
//! Ob txoj haujlwm no tej zaum yuav ua tiav hauv Rust raws li hauv qab no.Ntawm no, `struct Foo*` hom ntawm C yog txhais rau `Box<Foo>`, uas ceev cov tswv cuab kev txwv.
//! Nco ntsoov tias qhov kev tsis txaus ntseeg rau `foo_delete` yog sawv cev hauv Rust ua `Option<Box<Foo>>`, txij li `Box<Foo>` tsis tuaj yeem thov tsis tau.
//!
//! ```
//! #[repr(C)]
//! pub struct Foo;
//!
//! #[no_mangle]
//! pub extern "C" fn foo_new() -> Box<Foo> {
//!     Box::new(Foo)
//! }
//!
//! #[no_mangle]
//! pub extern "C" fn foo_delete(_: Option<Box<Foo>>) {}
//! ```
//!
//! Txawm hais tias `Box<T>` muaj tib qho kev sawv cev thiab C ABI ua C pointer, qhov no tsis txhais tau tias koj tuaj yeem hloov tus lej `T*` dhau los ua `Box<T>` thiab cia siab tias tej yam yuav ua haujlwm.
//! `Box<T>` qhov tseem ceeb yuav ib txwm ua raws li kev kawm, cov tsis muaj dab tsi.Ntxiv mus, destructor rau `Box<T>` yuav sim kom pub dawb tus nqi nrog lub ntiaj teb neeg faib khoom.Feem ntau, qhov kev coj ua zoo tshaj plaws tsuas yog siv `Box<T>` rau cov taw qhia uas yog los ntawm cov neeg hauv ntiaj teb.
//!
//! **Tseem ceeb.** Tsawg kawg tam sim no, koj yuav tsum tsis txhob siv `Box<T>` hom rau cov haujlwm uas tau txhais hauv C tab sis tau hu ua Rust.Hauv cov xwm txheej ntawd, koj yuav tsum ncaj qha tsom iav qhov C hom sai li sai tau.
//! Kev siv hom zoo li `Box<T>` qhov twg C kev txhais tau tsuas yog siv `T*` tuaj yeem ua rau tus cwj pwm tsis tau xaiv, raws li tau piav qhia hauv [rust-lang/unsafe-code-guidelines#198][ucg#198].
//!
//! [ucg#198]: https://github.com/rust-lang/unsafe-code-guidelines/issues/198
//! [dereferencing]: core::ops::Deref
//! [`Box::<T>::from_raw(value)`]: Box::from_raw
//! [`Global`]: crate::alloc::Global
//! [`Layout`]: crate::alloc::Layout
//! [`Layout::for_value(&*value)`]: crate::alloc::Layout::for_value
//! [valid]: ptr#safety
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::future::Future;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator, Iterator};
use core::marker::{Unpin, Unsize};
use core::mem;
use core::ops::{
    CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Generator, GeneratorState, Receiver,
};
use core::pin::Pin;
use core::ptr::{self, Unique};
use core::stream::Stream;
use core::task::{Context, Poll};

use crate::alloc::{handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw};
use crate::borrow::Cow;
use crate::raw_vec::RawVec;
use crate::str::from_boxed_utf8_unchecked;
use crate::vec::Vec;

/// Ib tug pointer hom rau heap faib.
///
/// Saib rau [module-level documentation](../../std/boxed/index.html) ntxiv.
#[lang = "owned_box"]
#[fundamental]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Box<
    T: ?Sized,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
>(Unique<T>, A);

impl<T> Box<T> {
    /// Allocates nco txog ntawm qhov heap thiab tom qab ntawd tso `x` rau hauv nws.
    ///
    /// Qhov no tsis tau faib yog tias `T` yog xoom.
    ///
    /// # Examples
    ///
    /// ```
    /// let five = Box::new(5);
    /// ```
    #[inline(always)]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(x: T) -> Self {
        box x
    }

    /// Ua lub thawv tshiab nrog cov ncauj lus tsis zoo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Xa pib:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn new_uninit() -> Box<mem::MaybeUninit<T>> {
        Self::new_uninit_in(Global)
    }

    /// Ua dua tshiab `Box` nrog cov ntsiab lus tsis tsim nyog, nrog lub cim xeeb tau sau nrog `0` bytes.
    ///
    ///
    /// Saib [`MaybeUninit::zeroed`][zeroed] piv txwv txog kev siv kom raug thiab tsis raug ntawm hom no.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let zero = Box::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[inline]
    #[doc(alias = "calloc")]
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Box<mem::MaybeUninit<T>> {
        Self::new_zeroed_in(Global)
    }

    /// Tsim dua tshiab `Pin<Box<T>>`.
    /// Yog tias `T` tsis siv `Unpin`, ces `x` yuav pinned hauv lub cim xeeb thiab tsis tuaj yeem txav mus.
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn pin(x: T) -> Pin<Box<T>> {
        (box x).into()
    }

    /// Allocates nco txog ntawm qhov heap ces tso `x` rau hauv nws, rov qab ua yuam kev yog qhov kev faib tawm tsis ua tiav
    ///
    ///
    /// Qhov no tsis tau faib yog tias `T` yog xoom.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// let five = Box::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(x: T) -> Result<Self, AllocError> {
        Self::try_new_in(x, Global)
    }

    /// Ua lub thawv tshiab nrog cov ntawv tsis tseem ceeb ntawm lub heap, rov ua yuam kev yog tias qhov kev faib tawm tsis ua tiav
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let mut five = Box::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Xa pib:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_uninit() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_uninit_in(Global)
    }

    /// Ua lub `Box` tshiab nrog cov txheej txheem tsis qhia qhov tseeb, nrog lub cim xeeb tau sau nrog `0` bytes ntawm lub heap
    ///
    ///
    /// Saib [`MaybeUninit::zeroed`][zeroed] piv txwv txog kev siv kom raug thiab tsis raug ntawm hom no.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let zero = Box::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_zeroed() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_zeroed_in(Global)
    }
}

impl<T, A: Allocator> Box<T, A> {
    /// Faib cov cim xeeb hauv qhov muab faib rau cov neeg ua haujlwm ces tso `x` rau hauv.
    ///
    /// Qhov no tsis tau faib yog tias `T` yog xoom.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::new_in(5, System);
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn new_in(x: T, alloc: A) -> Self {
        let mut boxed = Self::new_uninit_in(alloc);
        unsafe {
            boxed.as_mut_ptr().write(x);
            boxed.assume_init()
        }
    }

    /// Faib cov cim xeeb hauv qhov muab faib rau ces muab cov `x` rau hauv nws, rov ua yuam kev yog qhov kev faib tawm tsis ua tiav
    ///
    ///
    /// Qhov no tsis tau faib yog tias `T` yog xoom.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::try_new_in(5, System)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new_in(x: T, alloc: A) -> Result<Self, AllocError> {
        let mut boxed = Self::try_new_uninit_in(alloc)?;
        unsafe {
            boxed.as_mut_ptr().write(x);
            Ok(boxed.assume_init())
        }
    }

    /// Ua lub thawv tshiab nrog cov ncauj lus tsis zoo nyob hauv cov neeg muab rau siv.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::new_uninit_in(System);
    ///
    /// let five = unsafe {
    ///     // Xa pib:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: Xhim tau cov lus tshaj dhau hwv lawm vim tias qee zaum kaw tsis ua ke.
        // Qhov ntawd yuav ua rau qhov chaws loj dua.
        match Box::try_new_uninit_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// Ua lub thawv tshiab nrog cov ncauj lus tsis zoo nyob rau hauv cov muab faib, rov ua ib qho yuam kev yog qhov kev faib tawm tsis ua tiav
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::try_new_uninit_in(System)?;
    ///
    /// let five = unsafe {
    ///     // Xa pib:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// Constructs ib tug tshiab `Box` nrog uninitialized txheem, nrog lub cim xeeb puv npo nrog `0` bytes nyob rau hauv lub muab allocator.
    ///
    ///
    /// Saib [`MaybeUninit::zeroed`][zeroed] piv txwv txog kev siv kom raug thiab tsis raug ntawm hom no.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::new_zeroed_in(System);
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: Xhim tau cov lus tshaj dhau hwv lawm vim tias qee zaum kaw tsis ua ke.
        // Qhov ntawd yuav ua rau qhov chaws loj dua.
        match Box::try_new_zeroed_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// Ua tus tshiab `Box` nrog cov ntsiab lus tsis muaj qhov cim tseg, nrog lub cim xeeb tau sau nrog `0` bytes hauv cov muab faib, rov qab ua yuam kev yog qhov kev faib tawm tsis ua tiav,
    ///
    ///
    /// Saib [`MaybeUninit::zeroed`][zeroed] piv txwv txog kev siv kom raug thiab tsis raug ntawm hom no.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::try_new_zeroed_in(System)?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate_zeroed(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// Tsim dua tshiab `Pin<Box<T, A>>`.
    /// Yog tias `T` tsis siv `Unpin`, ces `x` yuav pinned hauv lub cim xeeb thiab tsis tuaj yeem txav mus.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline(always)]
    pub fn pin_in(x: T, alloc: A) -> Pin<Self>
    where
        A: 'static,
    {
        Self::new_in(x, alloc).into()
    }

    /// Hloov tus `Box<T>` rau hauv `Box<[T]>`
    ///
    /// Qhov kev hloov pauv no tsis faib rau ntawm lub pob taws thiab tshwm sim hauv qhov chaw.
    #[unstable(feature = "box_into_boxed_slice", issue = "71582")]
    pub fn into_boxed_slice(boxed: Self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(boxed);
        unsafe { Box::from_raw_in(raw as *mut [T; 1], alloc) }
    }

    /// Khaws cov `Box`, rov qab los qhwv tus nqi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(box_into_inner)]
    ///
    /// let c = Box::new(5);
    ///
    /// assert_eq!(Box::into_inner(c), 5);
    /// ```
    #[unstable(feature = "box_into_inner", issue = "80437")]
    #[inline]
    pub fn into_inner(boxed: Self) -> T {
        *boxed
    }
}

impl<T> Box<[T]> {
    /// Ua lub thawv tshiab hliv nrog cov ncauj lus tsis zoo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Xa pib:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity(len).into_box(len) }
    }

    /// Ua lub thawv tshiab kem nrog cov ntsiab lus tsis zoo, nrog lub cim xeeb tau sau nrog `0` bytes.
    ///
    ///
    /// Saib [`MaybeUninit::zeroed`][zeroed] piv txwv txog kev siv kom raug thiab tsis raug ntawm hom no.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let values = Box::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity_zeroed(len).into_box(len) }
    }
}

impl<T, A: Allocator> Box<[T], A> {
    /// Ua lub thawv tshiab kem nrog cov tsis muaj ntsiab lus tseem ceeb nyob hauv tus neeg muab cov neeg faib khoom.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut values = Box::<[u32], _>::new_uninit_slice_in(3, System);
    ///
    /// let values = unsafe {
    ///     // Xa pib:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_in(len, alloc).into_box(len) }
    }

    /// Ua lub thawv tshiab cov thawv hlais nrog cov ntsiab lus tsis zoo nyob rau hauv cov neeg muab khoom, nrog lub cim xeeb tau sau nrog `0` bytes.
    ///
    ///
    /// Saib [`MaybeUninit::zeroed`][zeroed] piv txwv txog kev siv kom raug thiab tsis raug ntawm hom no.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let values = Box::<[u32], _>::new_zeroed_slice_in(3, System);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_zeroed_in(len, alloc).into_box(len) }
    }
}

impl<T, A: Allocator> Box<mem::MaybeUninit<T>, A> {
    /// Hloov pauv mus rau `Box<T, A>`.
    ///
    /// # Safety
    ///
    /// Ib yam li [`MaybeUninit::assume_init`], nws yog nyob ntawm tus neeg hu kom tau lees tias tus nqi tiag tiag yog nyob rau hauv lub xeev xub thawj.
    ///
    /// Hu rau qhov no thaum cov ntsiab lus tseem tsis tau pib siab ua rau muaj kev coj cwj pwm tsis txaus ntseeg tam sim ntawd.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five: Box<u32> = unsafe {
    ///     // Xa pib:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<T, A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut T, alloc) }
    }
}

impl<T, A: Allocator> Box<[mem::MaybeUninit<T>], A> {
    /// Hloov pauv mus rau `Box<[T], A>`.
    ///
    /// # Safety
    ///
    /// Ib yam li [`MaybeUninit::assume_init`], nws yog nyob ntawm tus neeg hu kom tau lees tias cov nqi tiag tiag hauv lub xeev pib.
    ///
    /// Hu rau qhov no thaum cov ntsiab lus tseem tsis tau pib siab ua rau muaj kev coj cwj pwm tsis txaus ntseeg tam sim ntawd.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Xa pib:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut [T], alloc) }
    }
}

impl<T: ?Sized> Box<T> {
    /// Ua lub thawv los ntawm lub pointer nyoos.
    ///
    /// Tom qab hu qhov haujlwm no, tus pointer nyoos yog tus tswv ntawm `Box` X ua kom tiav.
    /// Tshwj xeeb, `Box` destructor yuav hu rau destructor ntawm `T` thiab pub dawb lub cim xeeb.
    /// Rau qhov no kom muaj kev nyab xeeb, lub cim xeeb yuav tsum tau faib raws li [memory layout] siv los ntawm `Box`.
    ///
    ///
    /// # Safety
    ///
    /// Txoj haujlwm no tsis zoo vim tias kev siv tsis raug yuav ua rau lub cim xeeb tsis haum.
    /// Piv txwv li, ob-dawb yuav tshwm sim yog tias txoj haujlwm raug hu ob zaug ntawm tib lub pointer nyoos.
    ///
    /// Cov xwm txheej nyab xeeb tau piav qhia hauv [memory layout] ntu.
    ///
    /// # Examples
    ///
    /// Rov Ua Dua `Box` uas yav dhau los pauv mus rau lub pointer nyoos siv [`Box::into_raw`]:
    ///
    /// ```
    /// let x = Box::new(5);
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// Tsim kev siv tus `Box` los ntawm kos los ntawm kev siv thoob ntiaj teb kev faib khoom:
    ///
    /// ```
    /// use std::alloc::{alloc, Layout};
    ///
    /// unsafe {
    ///     let ptr = alloc(Layout::new::<i32>()) as *mut i32;
    ///     // Feem ntau .write yog qhov yuav tsum zam kom dhau kev sim rhuav tshem (uninitialized) cov ntsiab lus dhau los ntawm `ptr`, txawm hais tias rau qhov piv txwv yooj yim `*ptr = 5` yuav tau ua haujlwm zoo li.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw(ptr);
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub unsafe fn from_raw(raw: *mut T) -> Self {
        unsafe { Self::from_raw_in(raw, Global) }
    }
}

impl<T: ?Sized, A: Allocator> Box<T, A> {
    /// Ua lub thawv los ntawm lub hauv paus nyob hauv qhov muab cov kwv yees.
    ///
    /// Tom qab hu qhov haujlwm no, tus pointer nyoos yog tus tswv ntawm `Box` X ua kom tiav.
    /// Tshwj xeeb, `Box` destructor yuav hu rau destructor ntawm `T` thiab pub dawb lub cim xeeb.
    /// Rau qhov no kom muaj kev nyab xeeb, lub cim xeeb yuav tsum tau faib raws li [memory layout] siv los ntawm `Box`.
    ///
    ///
    /// # Safety
    ///
    /// Txoj haujlwm no tsis zoo vim tias kev siv tsis raug yuav ua rau lub cim xeeb tsis haum.
    /// Piv txwv li, ob-dawb yuav tshwm sim yog tias txoj haujlwm raug hu ob zaug ntawm tib lub pointer nyoos.
    ///
    /// # Examples
    ///
    /// Rov Ua Dua `Box` uas yav dhau los pauv mus rau lub pointer nyoos siv [`Box::into_raw_with_allocator`]:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(5, System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// Tsim kev siv tus `Box` los ntawm kos los ntawm kev siv tus txheej txheem faib:
    ///
    /// ```
    /// #![feature(allocator_api, slice_ptr_get)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    ///
    /// unsafe {
    ///     let ptr = System.allocate(Layout::new::<i32>())?.as_mut_ptr();
    ///     // Feem ntau .write yog qhov yuav tsum zam kom dhau kev sim rhuav tshem (uninitialized) cov ntsiab lus dhau los ntawm `ptr`, txawm hais tias rau qhov piv txwv yooj yim `*ptr = 5` yuav tau ua haujlwm zoo li.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw_in(ptr, System);
    /// }
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub unsafe fn from_raw_in(raw: *mut T, alloc: A) -> Self {
        Box(unsafe { Unique::new_unchecked(raw) }, alloc)
    }

    /// Xaj cov `Box`, rov qab qhwv ib lub pointer nyoos.
    ///
    /// Tus taw tes yuav raug muab ua kom zoo thiab tsis yog-null.
    ///
    /// Tom qab hu rau txoj haujlwm no, tus hu yog lub luag haujlwm rau lub cim xeeb yav dhau los tswj hwm los ntawm `Box`.
    /// Tshwj xeeb, tus hu yuav tsum tsim nyog rhuav tshem `T` thiab tso lub cim xeeb, coj mus rau hauv tus account [memory layout] siv los ntawm `Box`.
    /// Qhov yooj yim ntawm kev ua no yog hloov tus pointer nyoos rov qab mus rau `Box` nrog [`Box::from_raw`] txoj haujlwm, tso cai rau `Box` destructor ua qhov ntxuav.
    ///
    ///
    /// Note: qhov no yog qhov cuam tshuam ua haujlwm, uas txhais tau tias koj yuav tsum hu nws li `Box::into_raw(b)` hloov `b.into_raw()`.
    /// Nov yog kom tsis muaj kev sib cav nrog txoj kev ntawm sab hauv.
    ///
    /// # Examples
    /// Hloov pauv cov pointer nyoos rov qab mus rau hauv `Box` nrog [`Box::from_raw`] rau kev rho tawm tsis siv neeg:
    ///
    /// ```
    /// let x = Box::new(String::from("Hello"));
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// Los ntawm txhais tes tu tej los ntawm ntsees khiav lub destructor thiab khom lub cim xeeb:
    ///
    /// ```
    /// use std::alloc::{dealloc, Layout};
    /// use std::ptr;
    ///
    /// let x = Box::new(String::from("Hello"));
    /// let p = Box::into_raw(x);
    /// unsafe {
    ///     ptr::drop_in_place(p);
    ///     dealloc(p as *mut u8, Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub fn into_raw(b: Self) -> *mut T {
        Self::into_raw_with_allocator(b).0
    }

    /// Txwm rau `Box`, rov qab los qhwv ib lub pob nrig tsis zoo thiab tus muab cais.
    ///
    /// Tus taw tes yuav raug muab ua kom zoo thiab tsis yog-null.
    ///
    /// Tom qab hu rau txoj haujlwm no, tus hu yog lub luag haujlwm rau lub cim xeeb yav dhau los tswj hwm los ntawm `Box`.
    /// Tshwj xeeb, tus hu yuav tsum tsim nyog rhuav tshem `T` thiab tso lub cim xeeb, coj mus rau hauv tus account [memory layout] siv los ntawm `Box`.
    /// Qhov yooj yim ntawm kev ua no yog hloov tus pointer nyoos rov qab mus rau `Box` nrog [`Box::from_raw_in`] txoj haujlwm, tso cai rau `Box` destructor ua qhov ntxuav.
    ///
    ///
    /// Note: qhov no yog qhov cuam tshuam ua haujlwm, uas txhais tau tias koj yuav tsum hu nws li `Box::into_raw_with_allocator(b)` hloov `b.into_raw_with_allocator()`.
    /// Nov yog kom tsis muaj kev sib cav nrog txoj kev ntawm sab hauv.
    ///
    /// # Examples
    /// Hloov pauv cov pointer nyoos rov qab mus rau hauv `Box` nrog [`Box::from_raw_in`] rau kev rho tawm tsis siv neeg:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// Los ntawm txhais tes tu tej los ntawm ntsees khiav lub destructor thiab khom lub cim xeeb:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    /// use std::ptr::{self, NonNull};
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// unsafe {
    ///     ptr::drop_in_place(ptr);
    ///     let non_null = NonNull::new_unchecked(ptr);
    ///     alloc.deallocate(non_null.cast(), Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn into_raw_with_allocator(b: Self) -> (*mut T, A) {
        let (leaked, alloc) = Box::into_unique(b);
        (leaked.as_ptr(), alloc)
    }

    #[unstable(
        feature = "ptr_internals",
        issue = "none",
        reason = "use `Box::leak(b).into()` or `Unique::from(Box::leak(b))` instead"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn into_unique(b: Self) -> (Unique<T>, A) {
        // Lub thawv tau lees paub tias yog "unique pointer" los ntawm Stacked Borrows, tab sis sab hauv nws yog qhov pointer nyoos rau hom kab ke.
        // Kev xa nws ncaj qha mus rau lub pointer nyoos yuav tsis raug lees paub tias yog "releasing" tus taw qhia tshwj xeeb kom tso cai rau cov khoom siv nyoos nkag, yog li txhua tus pointer nyoos yuav tsum dhau `Box::leak`.
        //
        // Tig *uas* rau lub pointer nyoos coj qhov raug.
        //
        let alloc = unsafe { ptr::read(&b.1) };
        (Unique::from(Box::leak(b)), alloc)
    }

    /// Rov qab xa mus rau cov hauv paus hauv paus kev faib nyiaj.
    ///
    /// Note: qhov no yog qhov cuam tshuam ua haujlwm, uas txhais tau tias koj yuav tsum hu nws li `Box::allocator(&b)` hloov `b.allocator()`.
    /// Nov yog kom tsis muaj kev sib cav nrog txoj kev ntawm sab hauv.
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(b: &Self) -> &A {
        &b.1
    }

    /// Xwv thiab txia lub `Box`, rov qab los ua lwm tus, `&'a mut T`.
    /// Nco ntsoov tias hom `T` yuav tsum outlive tus xaiv lub neej `'a`.
    /// Yog tias hom tau tsuas yog cov ntawv pov thawj zoo li qub, lossis tsis muaj hlo li, ces qhov no yuav raug xaiv los ua `'static`.
    ///
    /// Txoj haujlwm no yog qhov tseem ceeb rau cov ntaub ntawv uas nyob rau qhov seem ntawm qhov kev pab cuam lub neej.
    /// Xa qhov xa rov qab yuav ua rau lub cim xeeb xau.
    /// Yog tias qhov no tsis tuaj yeem siv tau, kev siv yuav tsum xub muab qhwv nrog [`Box::from_raw`] ua haujlwm ua ib tus `Box`.
    ///
    /// Qhov no `Box` tuaj yeem tom qab uas yuav muab tso cia uas yuav rhuav tshem `T` thiab tso lub cim xeeb tseg.
    ///
    /// Note: qhov no yog qhov cuam tshuam ua haujlwm, uas txhais tau tias koj yuav tsum hu nws li `Box::leak(b)` hloov `b.leak()`.
    /// Nov yog kom tsis muaj kev sib cav nrog txoj kev ntawm sab hauv.
    ///
    /// # Examples
    ///
    /// Kev siv yooj yim:
    ///
    /// ```
    /// let x = Box::new(41);
    /// let static_ref: &'static mut usize = Box::leak(x);
    /// *static_ref += 1;
    /// assert_eq!(*static_ref, 42);
    /// ```
    ///
    /// Cov ntaub ntawv tsis raug xaiv:
    ///
    /// ```
    /// let x = vec![1, 2, 3].into_boxed_slice();
    /// let static_ref = Box::leak(x);
    /// static_ref[0] = 4;
    /// assert_eq!(*static_ref, [4, 2, 3]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "box_leak", since = "1.26.0")]
    #[inline]
    pub fn leak<'a>(b: Self) -> &'a mut T
    where
        A: 'a,
    {
        unsafe { &mut *mem::ManuallyDrop::new(b).0.as_ptr() }
    }

    /// Hloov tus `Box<T>` rau hauv `Pin<Box<T>>`
    ///
    /// Qhov kev hloov pauv no tsis faib rau ntawm lub pob taws thiab tshwm sim hauv qhov chaw.
    ///
    /// Qhov no kuj tseem muaj nyob ntawm [`From`].
    #[unstable(feature = "box_into_pin", issue = "62370")]
    pub fn into_pin(boxed: Self) -> Pin<Self>
    where
        A: 'static,
    {
        // Nws tsis tuaj yeem txav lossis hloov cov kab sab hauv ntawm `Pin<Box<T>>` thaum `T: !Unpin`, yog li nws muaj kev nyab xeeb los tus pin nws ncaj qha tsis muaj kev txwv ntxiv.
        //
        //
        unsafe { Pin::new_unchecked(boxed) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized, A: Allocator> Drop for Box<T, A> {
    fn drop(&mut self) {
        // FIXME: Tsis muaj dab tsi, tso yog tam sim no tau ua los ntawm compiler.
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Box<T> {
    /// Tsim tus `Box<T>`, nrog tus nqi `Default` rau T.
    fn default() -> Self {
        box T::default()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Box<[T]> {
    fn default() -> Self {
        Box::<[T; 0]>::new([])
    }
}

#[stable(feature = "default_box_extra", since = "1.17.0")]
impl Default for Box<str> {
    fn default() -> Self {
        unsafe { from_boxed_utf8_unchecked(Default::default()) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<T, A> {
    /// Rov qab rau lub thawv tshiab nrog `clone()` ntawm lub npov kab ntawv.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let y = x.clone();
    ///
    /// // Tus nqi yog tib yam
    /// assert_eq!(x, y);
    ///
    /// // Tab sis lawv yog cov khoom tshwj xeeb
    /// assert_ne!(&*x as *const i32, &*y as *const i32);
    /// ```
    #[inline]
    fn clone(&self) -> Self {
        // Pre-faib nco cia sau cov cloned nqi ncaj qha.
        let mut boxed = Self::new_uninit_in(self.1.clone());
        unsafe {
            (**self).write_clone_into_raw(boxed.as_mut_ptr());
            boxed.assume_init()
        }
    }

    /// Luam cov `source`'s contents rau hauv `self` yam uas tsis tsim ib qho kev faib tawm tshiab.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let mut y = Box::new(10);
    /// let yp: *const i32 = &*y;
    ///
    /// y.clone_from(&x);
    ///
    /// // Tus nqi yog tib yam
    /// assert_eq!(x, y);
    ///
    /// // Thiab tsis muaj kev faib nyiaj tshwm sim
    /// assert_eq!(yp, &*y);
    /// ```
    #[inline]
    fn clone_from(&mut self, source: &Self) {
        (**self).clone_from(&(**source));
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl Clone for Box<str> {
    fn clone(&self) -> Self {
        // qhov no ua rau daim ntawv theej ntawm cov ntaub ntawv
        let buf: Box<[u8]> = self.as_bytes().into();
        unsafe { from_boxed_utf8_unchecked(buf) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq, A: Allocator> PartialEq for Box<T, A> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        PartialEq::eq(&**self, &**other)
    }
    #[inline]
    fn ne(&self, other: &Self) -> bool {
        PartialEq::ne(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd, A: Allocator> PartialOrd for Box<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
    #[inline]
    fn lt(&self, other: &Self) -> bool {
        PartialOrd::lt(&**self, &**other)
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        PartialOrd::le(&**self, &**other)
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        PartialOrd::ge(&**self, &**other)
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        PartialOrd::gt(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord, A: Allocator> Ord for Box<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq, A: Allocator> Eq for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash, A: Allocator> Hash for Box<T, A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "indirect_hasher_impl", since = "1.22.0")]
impl<T: ?Sized + Hasher, A: Allocator> Hasher for Box<T, A> {
    fn finish(&self) -> u64 {
        (**self).finish()
    }
    fn write(&mut self, bytes: &[u8]) {
        (**self).write(bytes)
    }
    fn write_u8(&mut self, i: u8) {
        (**self).write_u8(i)
    }
    fn write_u16(&mut self, i: u16) {
        (**self).write_u16(i)
    }
    fn write_u32(&mut self, i: u32) {
        (**self).write_u32(i)
    }
    fn write_u64(&mut self, i: u64) {
        (**self).write_u64(i)
    }
    fn write_u128(&mut self, i: u128) {
        (**self).write_u128(i)
    }
    fn write_usize(&mut self, i: usize) {
        (**self).write_usize(i)
    }
    fn write_i8(&mut self, i: i8) {
        (**self).write_i8(i)
    }
    fn write_i16(&mut self, i: i16) {
        (**self).write_i16(i)
    }
    fn write_i32(&mut self, i: i32) {
        (**self).write_i32(i)
    }
    fn write_i64(&mut self, i: i64) {
        (**self).write_i64(i)
    }
    fn write_i128(&mut self, i: i128) {
        (**self).write_i128(i)
    }
    fn write_isize(&mut self, i: isize) {
        (**self).write_isize(i)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Box<T> {
    /// Hloov tus lej ntau hom `T` rau `Box<T>` X
    ///
    /// Lub hloov pauv faib rau ntawm lub heap thiab txav `t` los ntawm cov pawg rau nws.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let x = 5;
    /// let boxed = Box::new(5);
    ///
    /// assert_eq!(Box::from(x), boxed);
    /// ```
    fn from(t: T) -> Self {
        Box::new(t)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> From<Box<T, A>> for Pin<Box<T, A>>
where
    A: 'static,
{
    /// Hloov tus `Box<T>` rau hauv `Pin<Box<T>>`
    ///
    /// Qhov kev hloov pauv no tsis faib rau ntawm lub pob taws thiab tshwm sim hauv qhov chaw.
    fn from(boxed: Box<T, A>) -> Self {
        Box::into_pin(boxed)
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl<T: Copy> From<&[T]> for Box<[T]> {
    /// Hloov tus `&[T]` rau hauv `Box<[T]>`
    ///
    /// Qhov hloov dua siab tshiab no faib rau lub heap thiab ua ib daim ntawv `slice`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // tsim ib&[u8] uas yuav raug siv los tsim Lub thawv <[u8]>
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice: Box<[u8]> = Box::from(slice);
    ///
    /// println!("{:?}", boxed_slice);
    /// ```
    fn from(slice: &[T]) -> Box<[T]> {
        let len = slice.len();
        let buf = RawVec::with_capacity(len);
        unsafe {
            ptr::copy_nonoverlapping(slice.as_ptr(), buf.ptr(), len);
            buf.into_box(slice.len()).assume_init()
        }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl<T: Copy> From<Cow<'_, [T]>> for Box<[T]> {
    #[inline]
    fn from(cow: Cow<'_, [T]>) -> Box<[T]> {
        match cow {
            Cow::Borrowed(slice) => Box::from(slice),
            Cow::Owned(slice) => Box::from(slice),
        }
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl From<&str> for Box<str> {
    /// Hloov tus `&str` rau hauv `Box<str>`
    ///
    /// Qhov hloov dua siab tshiab no faib rau lub heap thiab ua ib daim ntawv `s`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<str> = Box::from("hello");
    /// println!("{}", boxed);
    /// ```
    #[inline]
    fn from(s: &str) -> Box<str> {
        unsafe { from_boxed_utf8_unchecked(Box::from(s.as_bytes())) }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl From<Cow<'_, str>> for Box<str> {
    #[inline]
    fn from(cow: Cow<'_, str>) -> Box<str> {
        match cow {
            Cow::Borrowed(s) => Box::from(s),
            Cow::Owned(s) => Box::from(s),
        }
    }
}

#[stable(feature = "boxed_str_conv", since = "1.19.0")]
impl<A: Allocator> From<Box<str, A>> for Box<[u8], A> {
    /// Hloov tus `Box<str>` rau `Box<[u8]>` X
    /// Qhov kev hloov pauv no tsis faib rau ntawm lub pob taws thiab tshwm sim hauv qhov chaw.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // tsim Lub Box<str>uas yuav siv los tsim Lub thawv <[u8]>
    /// let boxed: Box<str> = Box::from("hello");
    /// let boxed_str: Box<[u8]> = Box::from(boxed);
    ///
    /// // tsim ib&[u8] uas yuav raug siv los tsim Lub thawv <[u8]>
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice = Box::from(slice);
    ///
    /// assert_eq!(boxed_slice, boxed_str);
    /// ```
    #[inline]
    fn from(s: Box<str, A>) -> Self {
        let (raw, alloc) = Box::into_raw_with_allocator(s);
        unsafe { Box::from_raw_in(raw as *mut [u8], alloc) }
    }
}

#[stable(feature = "box_from_array", since = "1.45.0")]
impl<T, const N: usize> From<[T; N]> for Box<[T]> {
    /// Hloov tus `[T; N]` rau hauv `Box<[T]>`
    /// Qhov kev hloov pauv no hloov cov kab lus rau cov cim xeeb tshiab heap-faib kev nco.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<[u8]> = Box::from([4, 2]);
    /// println!("{:?}", boxed);
    /// ```
    fn from(array: [T; N]) -> Box<[T]> {
        box array
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Box<[T]>> for Box<[T; N]> {
    type Error = Box<[T]>;

    fn try_from(boxed_slice: Box<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Box::from_raw(Box::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

impl<A: Allocator> Box<dyn Any, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// Sim nqes mus rau lub thawv rau ib hom pob zeb.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut dyn Any, _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// Sim nqes mus rau lub thawv rau ib hom pob zeb.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send), _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send + Sync, A> {
    #[inline]
    #[stable(feature = "box_send_sync_any_downcast", since = "1.51.0")]
    /// Sim nqes mus rau lub thawv rau ib hom pob zeb.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send + Sync), _) =
                    Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized, A: Allocator> fmt::Display for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug + ?Sized, A: Allocator> fmt::Debug for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> fmt::Pointer for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Nws tseem tsis tau mus extract lub puab uniq ncaj qha los ntawm lub Box, es tsis txhob peb cam khwb cia nws mus rau ib tug * const uas Aliases lub Cim
        //
        let ptr: *const T = &**self;
        fmt::Pointer::fmt(&ptr, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> Deref for Box<T, A> {
    type Target = T;

    fn deref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> DerefMut for Box<T, A> {
    fn deref_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized, A: Allocator> Receiver for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized, A: Allocator> Iterator for Box<I, A> {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth(n)
    }
    fn last(self) -> Option<I::Item> {
        BoxIter::last(self)
    }
}

trait BoxIter {
    type Item;
    fn last(self) -> Option<Self::Item>;
}

impl<I: Iterator + ?Sized, A: Allocator> BoxIter for Box<I, A> {
    type Item = I::Item;
    default fn last(self) -> Option<I::Item> {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }
}

/// Kev Tshwj Xeeb rau qhov loj me `Kuv`s uas siv` Kuv ua raws li `last()` hloov qhov tsis ua ntej.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator, A: Allocator> BoxIter for Box<I, A> {
    fn last(self) -> Option<I::Item> {
        (*self).last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: DoubleEndedIterator + ?Sized, A: Allocator> DoubleEndedIterator for Box<I, A> {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized, A: Allocator> ExactSizeIterator for Box<I, A> {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized, A: Allocator> FusedIterator for Box<I, A> {}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnOnce<Args> + ?Sized, A: Allocator> FnOnce<Args> for Box<F, A> {
    type Output = <F as FnOnce<Args>>::Output;

    extern "rust-call" fn call_once(self, args: Args) -> Self::Output {
        <F as FnOnce<Args>>::call_once(*self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnMut<Args> + ?Sized, A: Allocator> FnMut<Args> for Box<F, A> {
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output {
        <F as FnMut<Args>>::call_mut(self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: Fn<Args> + ?Sized, A: Allocator> Fn<Args> for Box<F, A> {
    extern "rust-call" fn call(&self, args: Args) -> Self::Output {
        <F as Fn<Args>>::call(self, args)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized, A: Allocator> CoerceUnsized<Box<U, A>> for Box<T, A> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Box<U>> for Box<T, Global> {}

#[stable(feature = "boxed_slice_from_iter", since = "1.32.0")]
impl<I> FromIterator<I> for Box<[I]> {
    fn from_iter<T: IntoIterator<Item = I>>(iter: T) -> Self {
        iter.into_iter().collect::<Vec<_>>().into_boxed_slice()
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<[T], A> {
    fn clone(&self) -> Self {
        let alloc = Box::allocator(self).clone();
        self.to_vec_in(alloc).into_boxed_slice()
    }

    fn clone_from(&mut self, other: &Self) {
        if self.len() == other.len() {
            self.clone_from_slice(&other);
        } else {
            *self = other.clone();
        }
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::Borrow<T> for Box<T, A> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::BorrowMut<T> for Box<T, A> {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsRef<T> for Box<T, A> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsMut<T> for Box<T, A> {
    fn as_mut(&mut self) -> &mut T {
        &mut **self
    }
}

/* Nota bene
 *
 *  We could have chosen not to add this impl, and instead have written a
 *  function of Pin<Box<T>> to Pin<T>. Such a function would not be sound,
 *  because Box<T> implements Unpin even when T does not, as a result of
 *  this impl.
 *
 *  We chose this API instead of the alternative for a few reasons:
 *      - Logically, it is helpful to understand pinning in regard to the
 *        memory region being pointed to. For this reason none of the
 *        standard library pointer types support projecting through a pin
 *        (Box<T> is the only pointer type in std for which this would be
 *        safe.)
 *      - It is in practice very useful to have Box<T> be unconditionally
 *        Unpin because of trait objects, for which the structural auto
 *        trait functionality does not apply (e.g., Box<dyn Foo> would
 *        otherwise not be Unpin).
 *
 *  Another type with the same semantics as Box but only a conditional
 *  implementation of `Unpin` (where `T: Unpin`) would be valid/safe, and
 *  could have a method to project a Pin<T> from it.
 */
#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> Unpin for Box<T, A> where A: 'static {}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R, A: Allocator> Generator<R> for Box<G, A>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R, A: Allocator> Generator<R> for Pin<Box<G, A>>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin, A: Allocator> Future for Box<F, A>
where
    A: 'static,
{
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut *self), cx)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for Box<S> {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        Pin::new(&mut **self).poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}