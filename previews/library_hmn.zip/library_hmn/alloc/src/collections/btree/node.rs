// Nov yog qhov kev sim ntawm kev nqis tes ua tom qab qhov zoo tagnrho
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Vim Rust tsis tshua muaj hom thiab polymorphic recursion, peb ua ntau ntau tsis muaj kev ruaj ntseg.
//

// Lub hom phiaj tseem ceeb ntawm cov qauv no yog kom tsis txhob muaj kev kub ntxhov los ntawm kev saib xyuas tsob ntoo ua lub zog (yog tias zoo li tus cwj pwm tsis sib luag) ntim thiab zam kev cuam tshuam nrog feem ntau ntawm B-Ntoo cov kab mob.
//
// Raws li xws li, qhov qauv no tsis quav ntsej txog seb cov khoom nkag tau txheeb, cov twg tuaj yeem yog qhov tsis txaus ntseeg, lossis txawm tias txhais tau tias tsis nkag siab.Txawm li cas los xij, peb vam khom rau qee tus neeg sau npe:
//
// - Cov ntoo yuav tsum muaj cov teeb meem zoo depth/height.Qhov no txhais tau tias txhua txoj kev nqes mus rau nplooj los ntawm ib cov muab tau muaj raws nraim tib ntev.
// - Ib kis ntawm ntev `n` muaj `n` yuam sij, `n` qhov tseem ceeb, thiab `n + 1` sawv.
//   Qhov no qhia tau hais tias txawm tias khoob node muaj tsawg kawg ib qho edge.
//   Rau cov nplooj hlav, "having an edge" tsuas yog txhais tau tias peb tuaj yeem paub txoj haujlwm ntawm ntawm, vim tias cov nplooj tsawb nyob khoob thiab tsis tas yuav tsum muaj cov ntaub ntawv sawv cev.
// Hauv cov node sab hauv, ib qho edge ob qho tib si qhia txog txoj haujlwm thiab muaj lub pointer rau tus me nyuam ntawm.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// Lub hauv paus sawv cev ntawm cov nplooj nodes thiab ib feem ntawm qhov sawv cev ntawm cov nodes.
struct LeafNode<K, V> {
    /// Peb xav tau covariant hauv `K` thiab `V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Qhov node's index rau niam txiv node `edges` array.
    /// `*node.parent.edges[node.parent_idx]` yuav tsum yog qhov qub tib yam li `node`.
    /// Qhov no tsuas yog lav ua kom tau ua ntej thaum `parent` tsis yog-tus.
    parent_idx: MaybeUninit<u16>,

    /// Tus lej ntawm cov yuam sij thiab muaj txiaj ntsig ntawm cov ntawm no lub khw muag khoom.
    len: u16,

    /// Cov arrays khaws cov ntaub ntawv tiag tiag ntawm node.
    /// Tsuas yog thawj `len` lub ntsiab ntawm txhua kab yog pib thiab siv tau.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Pib `LeafNode` tshiab-hauv-chaw.
    unsafe fn init(this: *mut Self) {
        // Raws li txoj cai dav dav, peb tawm thaj chaw tsis muaj kev xav yog tias lawv tuaj yeem ua tau, vim tias qhov no yuav tsum yog ob qho tib si sai dua thiab yooj yim dua los taug qab hauv Valgrind.
        //
        unsafe {
            // parent_idx, yawm sij, thiab vals yog Txhua Qhov Tej zaumUninit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Tsim lub thawv tshiab `LeafNode`.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// Lub hauv paus sawv cev ntawm cov nodes sab hauv.Ib yam li nrog 'LeafNode`s, cov no yuav tsum tau muab zais tom qab ntawm' BoxedNode`s kom tiv thaiv kev poob qis hauv cov yuam sij thiab qhov tseem ceeb.
/// Txhua tus pointer rau ib qho `InternalNode` tuaj yeem ncaj qha cuam rau lub pointer mus rau qhov pib `LeafNode` ntawm ntu, cia txoj cai ua rau ntawm nplooj thiab cov nkees sab hauv feem ntau yam tsis tas txawm tias tus twg ntawm ob lub pointer taw tes ntawm.
///
/// Cov cuab yeej no tau tsim los ntawm kev siv `repr(C)`.
///
#[repr(C)]
// gdb_providers.py siv lub npe no rau kev soj ntsuam.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Cov lus qhia rau cov me nyuam ntawm cov ntawm no.
    /// `len + 1` ntawm cov no suav hais tias yog pib thiab siv tau, tshwj tsis yog tias ze rau thaum kawg, thaum tsob ntoo tuav los ntawm qiv hom `Dying`, qee cov taw tes no dai kom zoo.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Tsim lub thawv tshiab `InternalNode`.
    ///
    /// # Safety
    /// Qhov tsis ntxiv ntawm sab hauv nodes yog tias lawv muaj tsawg kawg yog ib qho pib thiab siv tau edge.
    /// Txoj haujlwm no tsis teeb tsa edge.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Peb tsuas yog xav pib ua cov ntaub ntawv;cov npoo yog Tej zaumUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Muaj kev tswj hwm, tsis yog-tus pointer rau ntawm.Qhov no yog ib tus pointer rau `LeafNode<K, V>` lossis tus pointer tug rau `InternalNode<K, V>`.
///
/// Txawm li cas los xij, `BoxedNode` tsis muaj cov ntaub ntawv hais txog qhov twg ntawm ob hom nodes nws yeej muaj, thiab, ib feem vim los ntawm cov ntaub ntawv tsis txaus, nws tsis yog ib hom cais thiab tsis muaj destructor.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Lub hauv paus cag ntawm tsob ntoo uas yog tus tswv.
///
/// Nco ntsoov tias qhov no tsis muaj lub destructor, thiab yuav tsum tau ntxuav kom huv.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Rov qab tau ib tsob ntoo tshiab, nrog nws cov cag ntoo uas thaum pib khoob.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` yuav tsum tsis xoom.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Nyuaj rau qiv tus tsim lub hauv paus ntawm.
    /// Tsis zoo li `reborrow_mut`, qhov no muaj kev nyab xeeb vim tias tus nqi xa rov qab tsis tuaj yeem siv los rhuav tshem lub hauv paus, thiab tsis tuaj yeem muaj lwm yam siv rau tsob ntoo.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Me ntsis kev sib ntxub qiv cov hauv paus hniav ntawm.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Irreversibly transitions rau ib qho siv uas tso cai traversal thiab muaj cov hauv kev cuam tshuam thiab lwm yam.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Ntxiv cov tshiab sab hauv ntawm qhov txuas nrog ib tus edge taw rau qhov dhau los ntawm cov nkees, ua qhov ntawd tawm ntawm node lub hauv paus, thiab xa rov tuaj.
    /// Qhov no nce qhov siab los ntawm 1 thiab yog tus txheem ntawm `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, tshwj tsis yog tias peb tsuas yog tsis nco qab peb nyob sab hauv tam sim no:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Tshem tawm hauv paus hauv, siv nws thawj tus menyuam los ua lub hauv paus tshiab.
    /// Raws li nws tau npaj tsuas yog hu ua thaum lub hauv paus ntawm tsuas muaj ib tus menyuam, tsis muaj kev ntxuav tu ib qho twg ntawm cov yuam sij, kom muaj nuj nqis thiab lwm tus menyuam yaus.
    ///
    /// Qhov no txo qhov siab los ntawm 1 thiab yog qhov txawv ntawm `push_internal_level`.
    ///
    /// Yuav tsum muaj kev nkag mus rau `Root` X yam twj paj nruag tab sis tsis pom lub hauv paus;
    /// nws yuav tsis yog yam ua tsis zoo ntawm lwm cov tes haujlwm lossis cov ntawv xa mus rau lub hauv paus cag.
    ///
    /// Panics yog tias tsis muaj qib sab hauv, piv txwv li, yog tias cov cag nus yog daim nplooj.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // KEV RUAJ NTSEG: peb khav tias yog sab hauv.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // KEV RUAJ NTSEG: peb qiv `self` tshwj xeeb thiab nws qiv hom tsuas yog tshwj xeeb.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // KEV RUAJ NTSEG: thawj edge yog ib txwm pib.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` yog ib txwm muajarar hauv `K` thiab `V`, txawm tias `BorrowType` yog `Mut`.
// Qhov no txhaum kev cai, tab sis tsis tuaj yeem ua rau muaj qhov tsis muaj kev nyab xeeb vim yog kev siv sab hauv `NodeRef` vim tias peb nyob tag nrho cov txiaj ntsig dhau `K` thiab `V`.
//
// Txawm li cas los xij, thaum twg cov hom pej xeem qhwv `NodeRef`, nco ntsoov tias nws muaj cov khoom sib txawv.
//
/// Kev siv rau ntawm ib qho ntawm.
///
/// Hom no muaj ntau tus lej uas tswj hwm nws ua li cas:
/// - `BorrowType`: Dummy hom uas piav txog hom qiv thiab nqa lub neej.
///    - Thaum no yog `Immut<'a>`, `NodeRef` ua haujlwm maj li `&'a Node`.
///    - Thaum no yog `ValMut<'a>`, `NodeRef` ua haujlwm ntxhib li `&'a Node` nrog rau cov yawm sij thiab cov qauv ntoo, tab sis kuj tseem tso cai rau ntau cov ntawv xa mus rau qhov muaj nuj nqis thoob plaws tsob ntoo kom sib xyaw.
///    - Thaum qhov no yog `Mut<'a>`, lub `NodeRef` ua roughly zoo li `&'a mut Node`, txawm hais tias insert txoj kev tso cai rau ib tug mutable pointer mus rau ib tug nqi rau coexist.
///    - Thaum no yog `Owned`, `NodeRef` ua haujlwm ntxhib los ntawm `Box<Node>`, tab sis tsis muaj qhov puas tsuaj, thiab yuav tsum tau ntxuav kom huv.
///    - Thaum qhov no yog `Dying`, `NodeRef` tseem ua haujlwm ntxaws xws li `Box<Node>`, tab sis muaj cov qauv kev rhuav tshem tsob ntoo me ntsis los ntawm me ntsis, thiab cov qauv zoo tib yam, thaum tsis muaj cim tsis zoo hu, tuaj yeem hu UB yog hu ua tsis raug.
///
///   Txij thaum ib qho `NodeRef` tso cai rau kev mus hla cov ntoo, `BorrowType` siv tau rau tag nrho cov ntoo, tsis yog rau cov ntawm nws tus kheej.
/// - `K` thiab `V`: Cov no yog cov hom yuam sij thiab muaj nqis khaws cia hauv cov nodes.
/// - `Type`: Qhov no tuaj yeem yog `Leaf`, `Internal`, lossis `LeafOrInternal`.
/// Thaum no yog `Leaf`, `NodeRef` taw rau nplooj ntawm nplooj, thaum qhov no yog `Internal` `NodeRef` rau ib qho ntawm sab hauv, thiab thaum no yog `LeafOrInternal` `NodeRef` tuaj yeem taw rau ob hom.
///   `Type` yog muaj npe `NodeType` thaum siv sab nraum `NodeRef`.
///
/// Ob lub `BorrowType` thiab `NodeType` txwv cov kev coj ua peb siv, ua kom muaj txiaj ntsig zoo li qub kev nyab xeeb.Muaj cov kev txwv hauv txoj hauv kev uas peb tuaj yeem siv cov kev txwv no:
/// - Rau txhua hom parameter, peb tsuas txhais tau ib txoj kev ua ib qho qauv los yog rau ib hom.
/// Piv txwv li, peb tsis tuaj yeem txhais txoj kev zoo li `into_kv` qhov muaj txiaj ntsig rau txhua tus `BorrowType`, lossis ib zaug rau txhua yam uas muaj lub neej ntev ntev, vim tias peb xav kom nws rov qab `&'a` cov ntawv xa mus.
///   Yog li ntawd, peb txhais nws tsuas yog rau cov muaj zog tshaj yam hom `Immut<'a>`.
/// - Peb tsis tuaj yeem tau txais kev quab yuam los ntawm kev hais `Mut<'a>` rau `Immut<'a>`.
///   Yog li ntawd, peb yuav tsum hais meej hu rau `reborrow` ntawm tus muaj hwj chim loj dua `NodeRef` kom ncav cuag tus txheej txheem zoo li `into_kv`.
///
/// Txhua txoj hauv `NodeRef` uas xa rov qab qee yam siv, ib qho:
/// - Nqa `self` los ntawm tus nqi, thiab rov qab lub neej nqa los ntawm `BorrowType`.
///   Qee zaum, txhawm rau kom siv tus qauv zoo li no, peb yuav tsum hu rau `reborrow_mut`.
/// - Nqa `self` los ntawm kev siv, thiab (implicitly) xa rov qab rau cov ntawv ntawd lub neej, hloov mus rau lub neej nqa los ntawm `BorrowType`.
/// Hais tias txoj kev, lub qiv tub xam nyiaj guarantees uas lub `NodeRef` tshua borrowed li ntev raws li lub rov qab siv yog siv.
///   Cov hau kev txhawb ntxig khoov txoj cai no los ntawm rov qab ua lub pointer nyoos, piv txwv li, siv tsis tas lub neej.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Tus naj npawb ntawm cov qib uas node thiab qib ntawm nplooj yog sib nrug, qhov tsis zoo ntawm cov ntawm qhov tsis tau piav tag nrho los ntawm `Type`, thiab tias cov ntawm nws tus kheej tsis khaws cia.
    /// Peb tsuas yog yuav tsum khaws lub qhov siab ntawm lub hauv paus ntawm lub hauv paus, thiab muab coj los ua lwm qhov ntawm qhov siab ntawm nws.
    /// Yuav tsum yog xoom yog `Type` yog `Leaf` thiab tsis xoom yog `Type` yog `Internal`.
    ///
    ///
    height: usize,
    /// Lub pointer rau daim nplooj los yog nyob ntawm sab hauv.
    /// Lub ntsiab lus ntawm `InternalNode` ua kom paub meej tias tus pointer siv tau txhua txoj kev.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Unpack node reference uas tau ntim li `NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Tshaj tawm cov ntaub ntawv ntawm cov nkees hauv.
    ///
    /// Rov qab los ua cov ptr nyoos kom tsis txhob siv lwm qhov xa mus rau qhov ntawm no.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // KEV RUAJ NTSEG: hom hluav taws xob zoo li qub yog `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Borrows tshwj xeeb nkag mus rau cov ntaub ntawv ntawm sab hauv.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Pom qhov ntev ntawm lub node.Nov yog tus lej ntawm lub ntsiab lossis qhov tseem ceeb.
    /// Tus naj npawb ntawm cov npoo yog `len() + 1`.
    /// Nco ntsoov tias, txawm hais tias muaj kev nyab xeeb, hu rau txoj haujlwm no tuaj yeem muaj qhov tshwm sim ntawm kev siv lub suab tsis sib haum uas tus lej tsis raug cai tau tsim.
    ///
    pub fn len(&self) -> usize {
        // Tseem ceeb, peb tsuas yog nkag mus `len` teb ntawm no.
        // Yog hais tias BorrowType yog marker::ValMut, tej zaum yuav muaj qhov hloov kev hloov xa mus rau qhov tseem ceeb uas peb yuav tsum tsis yog yam tsis ua.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Rov qab rau cov naj npawb ntawm cov qib uas node thiab nplooj sib nrug.
    /// Xoom qhov siab txhais tau tias cov ntawm no yog nplooj nws tus kheej.
    /// Yog tias koj pom cov ntoo nrog lub hauv paus rau saum, tus naj npawb hais tias qhov twg nce ntawm qhov xa tuaj.
    /// Yog tias koj pom cov ntoo nrog nplooj nyob saum, tus naj npawb hais tias siab npaum li cas cov ntoo txuas siab tshaj ntawm qhov ntawm.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Ib ntus siv sijhawm tawm lwm qhov, hloov pauv tsis tau siv mus rau tib lub node.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Cais tawm ntawm nplooj seem ntawm txhua nplooj lossis nplooj ntawm sab hauv.
    ///
    /// Rov qab los ua cov ptr nyoos kom tsis txhob siv lwm qhov xa mus rau qhov ntawm no.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Qhov ntawm yuav tsum siv tau tsawg kawg ntawm LeafNode feem.
        // Qhov no yog tsis yog ib tug reference nyob rau hauv lub NodeRef hom vim hais tias peb tsis paub yog hais tias nws yuav tsum yog nws los qhia.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Pom tus niam/txiv ntawm cov ntawm tam sim no.
    /// Rov qab `Ok(handle)` yog qhov node tam sim no yeej muaj niam txiv, qhov twg `handle` taw qhia mus rau edge ntawm tus niam txiv uas taw rau qhov ntawm tam sim no.
    ///
    /// Rov qab `Err(self)` yog qhov ntawm tam sim no tsis muaj niam thiab txiv, rov muab cov qub `NodeRef`.
    ///
    /// Txoj kev lub npe kwv yees koj daim duab ntoo nrog lub hauv paus ntawm nyob rau sab saum toj.
    ///
    /// `edge.descend().ascend().unwrap()` thiab `node.ascend().unwrap().descend()` yuav tsum ob qho tib si, thaum ua tiav, tsis muaj dab tsi.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Peb yuav tsum siv cov taw tes nyoos rau cov nodes vim tias, yog BorrowType yog marker::ValMut, tej zaum yuav muaj qhov cuam tshuam hloov tau mus rau qhov muaj nuj nqis uas peb yuav tsum tsis ua tsis tiav.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Nco ntsoov tias `self` yuav tsum yog nonempty.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Nco ntsoov tias `self` yuav tsum yog nonempty.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Tshaj tawm cov nplooj ntoo ntawm ib qho nplooj ntoo lossis lub hauv paus ntawm hauv tsob ntoo uas hloov tsis tau.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // KEV RUAJ NTSEG: tsis tuaj yeem tsis muaj qhov hloov pauv rau cov ntoo no tau qiv raws li `Immut`.
        unsafe { &*ptr }
    }

    /// Qiv tawm saib rau hauv cov yuam sij khaws cia hauv cov ntawm.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Zoo ib yam li `ascend`, tau txais cov lus qhia rau ntawm node niam txiv ntawm, tab sis kuj cuam tshuam qhov tam sim no ntawm tus txheej txheem.
    /// Qhov no yog tsis zoo vim hais tias tam sim no ntawm tseem yuav siv tau txawm ua deallocated.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Unafaf lees paub rau cov neeg sau cov ntaub ntawv zoo li qub uas cov xov no yog `Leaf`.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Unafaf lees paub rau cov neeg sau cov ntaub ntawv zoo li qub uas qhov node yog `Internal`.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Ib ntus siv sijhawm tawm lwm qhov, hloov siv tau mus rau tib lub node.Ua zoo dev tom, raws li hom no txaus ntshai heev, tsam ob zaug vim tias nws yuav tsis tshwm sim txaus ntshai tam sim ntawd.
    ///
    /// Vim tias qhov taw tes hloov tau tuaj yeem nyob ib puag ncig ntawm tsob ntoo, tus pointer xa rov qab tuaj yeem siv tau yooj yim los ua tus thawj pointer dai tuag, tawm ntawm qhov chaw, lossis qhov tsis raug raws li cov cai qiv nyiaj.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) txiav txim siab txuas ntxiv lwm hom kev ntsuas rau `NodeRef` uas txwv tsis pub siv kev qhia txog kev tawm tsam cov lus taw qhia, tiv thaiv kev nyab xeeb no.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Borrows tshwj xeeb nkag rau nplooj ntawm nplooj ntawm lossis nplooj ntawm.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // KEV RUAJ NTSEG: peb tau tshwj xeeb nkag rau hauv tag nrho cov ntawm no.
        unsafe { &mut *ptr }
    }

    /// Muaj kev txwv tshwj xeeb rau kev nkag mus rau nplooj ntawm nplooj ib lossis nplooj ntawm.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // KEV RUAJ NTSEG: peb tau tshwj xeeb nkag rau hauv tag nrho cov ntawm no.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Ua kom muaj kev nkag tau rau lub ntsiab ntawm qhov chaw khaws khoom tseem ceeb.
    ///
    /// # Safety
    /// `index` yog nyob ntawm qhov ciam ntawm 0..CAPACITY
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // KEV RUAJ NTSEG: tus neeg hu yuav tsis tuaj yeem hu rau cov hau kev ntxiv ntawm tus kheej
        // kom txog rau thaum qhov tseem ceeb hlais txo qis, vim peb muaj kev nkag tau tshwj xeeb rau lub neej qiv nyiaj.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Borrows tshwj xeeb nkag mus rau ib qho khoom lossis ib ntu ntawm ntawm ntawm cov nqi khaws cia hauv thaj chaw.
    ///
    /// # Safety
    /// `index` yog nyob ntawm qhov ciam ntawm 0..CAPACITY
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // KEV RUAJ NTSEG: tus neeg hu yuav tsis tuaj yeem hu rau cov hau kev ntxiv ntawm tus kheej
        // kom txog rau thaum tus nqi hlais siv yog poob, raws li peb muaj kev nkag tau tshwj xeeb rau lub neej qiv nyiaj.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Borrows tshwj xeeb nkag mus rau ib qho khoom lossis ib ntu ntawm cov ntawm thaj chaw khaws cia rau edge txheem.
    ///
    /// # Safety
    /// `index` yog hauv qhov ciam ntawm 0..CAPACITY + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // KEV RUAJ NTSEG: tus neeg hu yuav tsis tuaj yeem hu rau cov hau kev ntxiv ntawm tus kheej
        // kom txog rau thaum edge daim ntawv siv txo qis, vim tias peb muaj kev nkag mus rau lub neej qiv.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Cov node muaj ntau dua `idx` pib cov khoom.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Peb tsuas yog tsim tus siv rau ib qho uas peb txaus siab rau, kom tsis txhob muaj qhov tsis paub tab nrog cov ntawv xa mus rau lwm cov ntsiab lus, tshwj xeeb, cov uas tau rov qab mus rau tus neeg hu hauv cov thawj coj.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Peb yuav tsum sib zog rau cov ntsuas kab lus tsis txaus ntseeg vim tias Rust qhov teeb meem #74679.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Borrows tshwj xeeb nkag rau qhov ntev ntawm ntawm.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Teeb ntawm qhov txuas tau txuas rau nws niam txiv edge, tsis muaj qhov tsis muaj tseeb rau lwm qhov xa mus rau ntawm node.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Cais cov hauv paus txuas rau nws niam nws txiv edge.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Ntxiv ib khub tseem ceeb-nqi rau qhov kawg ntawm ntawm.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Txhua qhov khoom xa rov qab los ntawm `range` yog qhov siv tau edge index rau cov ntawm.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Ntxiv tus khub tseem ceeb-tus nqi, thiab edge nce mus rau sab xis ntawm qhov khub ntawd, mus rau qhov kawg ntawm ntawm node.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Kuaj xyuas seb puas muaj node ib qho ntawm `Internal` node lossis `Leaf` ntawm.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Ib qho siv rau cov khub tseem ceeb-nqi lossis edge nyob rau ntawm qhov ntawm.
/// `Node` parameter yuav tsum yog `NodeRef`, thaum `Type` tuaj yeem yog `KV` (sau npe tus kov ntawm tus khub tseem ceeb) lossis `Edge` (kos npe tus kov ntawm edge).
///
/// Nco ntsoov tias txawm `Leaf` nodes tuaj yeem muaj `Edge` leeg.
/// Hloov chaw sawv cev tus taw kev mus rau kis ntawm cov me nyuam, cov no sawv cev rau qhov chaw uas tus me nyuam taw tes yuav mus nyob nruab nrab ntawm cov khoom tseem ceeb.
/// Piv txwv li, nyob rau hauv ib tug node nrog ntev 2, yuav muaj 3 tau edge qhov chaw, ib tug mus rau sab laug ntawm lub node, ib tug nruab nrab ntawm ob khub, thiab ib tug nyob rau ntawm sab xis ntawm lub node.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Peb tsis xav tau tag nrho cov ntsiab lus ntawm `#[derive(Clone)]`, raws li tib lub sijhawm `Node` yuav yog 'Clone`able yog thaum nws yog qhov siv tsis tau thiab yog li `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Retrieves lub node uas muaj edge lossis tus yuam sij-nqi tus khub kov cov ntsiab lus no rau.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Rov qab los rau txoj haujlwm ntawm tus kov no hauv cov node.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Tsim tus tuav tshiab rau cov khub tseem ceeb-nqi hauv `node`.
    /// Tsis zoo vim tias tus neeg hu yuav tsum xyuas kom meej tias `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Yuav yog pej xeem siv ntawm PartialEq, tab sis tsuas yog siv hauv qhov qauv no.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Ib ntus siv sijhawm tawm lwm qhov, tsis tuaj yeem tuav ntawm tib qho chaw.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Peb tsis tuaj yeem siv Handle::new_kv lossis Handle::new_edge vim tias peb tsis paub peb hom
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Qhov tsis muaj tseeb tsis xws hais rau cov neeg suav sau cov ntaub ntawv zoo li qub uas kov cov ntawm yog ib qho `Leaf`.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Ib ntus yuav tawm tawm lwm qhov, kov tau mus rau qhov chaw qub.
    /// Ua zoo dev tom, raws li hom no txaus ntshai heev, tsam ob zaug vim tias nws yuav tsis tshwm sim txaus ntshai tam sim ntawd.
    ///
    ///
    /// Kom paub meej, saib `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Peb tsis tuaj yeem siv Handle::new_kv lossis Handle::new_edge vim tias peb tsis paub peb hom
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Tsim kom muaj tus cwj pwm tshiab rau ib qho edge hauv `node`.
    /// Tsis zoo vim tias tus neeg hu yuav tsum xyuas kom meej tias `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Muab cov edge qhov chaw uas peb xav tau ntxig rau hauv ntawm qhov uas tau ua rau muaj peev xwm, suav qhov tsis nkag siab zoo KV qhov ntsuas ntawm qhov sib cais thiab qhov twg los ua lub ntxig.
///
/// Lub hom phiaj ntawm txoj kev sib cais yog rau nws tus yuam sij thiab muaj txiaj ntsig los xaus rau ntawm kev ua niam txiv;
/// cov yuam sij, qhov tseem ceeb thiab npoo rau sab laug ntawm txoj kev sib cais ua tus me nyuam sab laug;
/// cov yuam sij, qhov tseem ceeb thiab npoo rau sab xis ntawm qhov taw tes cais tau ua tus me nyuam zoo.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Rust qhov teeb meem #74834 sim piav qhia cov kev cai no yam ntxwv.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Ntxig tus khub tseem ceeb tshiab-tus nqi nruab nrab ntawm tus yuam sij-nqi mus rau sab xis thiab sab laug ntawm no edge.
    /// Txoj kev no kwv yees tias muaj txaus ntawm qhov ntawm rau cov khub tshiab kom haum.
    ///
    /// Tus pointer xa rov qab mus rau qhov ntxig tus nqi.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Ntxig tus khub tseem ceeb tshiab-tus nqi nruab nrab ntawm tus yuam sij-nqi mus rau sab xis thiab sab laug ntawm no edge.
    /// Txoj kev no cais cov ntawm yog tias tsis muaj chaw txaus.
    ///
    /// Tus pointer xa rov qab mus rau qhov ntxig tus nqi.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Fixes cov niam txiv pointer thiab Performance index nyob rau hauv tus me nyuam ntawm hais tias qhov no edge mus rau.
    /// Qhov no muaj txiaj ntsig zoo thaum kev xaj ntawm npoo tau hloov pauv,
    fn correct_parent_link(self) {
        // Tsim backpointer tsis muaj invalidating lwm tus neeg hais rau ntawm.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Nkag mus rau tus khub tseem ceeb tshiab-tus nqi thiab edge uas yuav mus rau sab xis ntawm tus khub tshiab ntawm no edge thiab tus khub yuam sij rau sab xis ntawm no edge.
    /// Txoj kev no kwv yees tias muaj txaus ntawm qhov ntawm rau cov khub tshiab kom haum.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Nkag mus rau tus khub tseem ceeb tshiab-tus nqi thiab edge uas yuav mus rau sab xis ntawm tus khub tshiab ntawm no edge thiab tus khub yuam sij rau sab xis ntawm no edge.
    /// Txoj kev no cais cov ntawm yog tias tsis muaj chaw txaus.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Ntxig tus khub tseem ceeb tshiab-tus nqi nruab nrab ntawm tus yuam sij-nqi mus rau sab xis thiab sab laug ntawm no edge.
    /// Txoj kev no sib cais ntawm node yog tias tsis muaj chav txaus, thiab sim ntxig qhov cais tawm ntawm ntu mus rau ntawm leej niam li ntawm tus kheej, kom txog thaum lub hauv paus mus txog.
    ///
    ///
    /// Yog tias qhov txiaj ntsig xa rov qab yog `Fit`, nws tus tuav lub node tuaj yeem yog edge lub node lossis tus poj koob yawm txwv.
    /// Yog tias qhov xa rov qab yog `Split`, `left` daim teb yuav yog lub hauv paus ntawm.
    /// Tus pointer xa rov qab mus rau qhov ntxig tus nqi.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Pom txoj ntawm tau taw qhia rau ntawm no edge.
    ///
    /// Txoj kev lub npe kwv yees koj daim duab ntoo nrog lub hauv paus ntawm nyob rau sab saum toj.
    ///
    /// `edge.descend().ascend().unwrap()` thiab `node.ascend().unwrap().descend()` yuav tsum ob qho tib si, thaum ua tiav, tsis muaj dab tsi.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Peb yuav tsum siv cov taw tes nyoos rau cov nodes vim tias, yog BorrowType yog marker::ValMut, tej zaum yuav muaj qhov cuam tshuam hloov tau mus rau qhov muaj nuj nqis uas peb yuav tsum tsis ua tsis tiav.
        // Tsis muaj qhov txhawj txog kev nkag mus rau qhov siab vim tias qhov nqi ntawd tau theej.
        // Ceevfaj tias, thaum lub npuaj ntawm pob tawg tsis zoo, peb nkag mus rau lub npoo array nrog qhov siv (Rust qhov teeb meem #73987) thiab siv tsis tau lwm yam kev xa mus rau lossis sab hauv lub array, yuav tsum muaj ib puag ncig.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Peb tsis tuaj yeem hu cov cais tus yuam sij thiab tus nqi, vim tias hu rau tus thib ob siv tsis tau cov lus qhia rov qab los ntawm thawj zaug.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Hloov cov tseem ceeb thiab muaj nuj nqis uas tus KV kov hais txog.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Pab kev nqis tes ua ntawm `split` rau ib qho `NodeType` tshwj xeeb, los ntawm kev saib xyuas cov ntaub ntawv nplooj.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Faib cov hauv paus rau hauv peb ntu:
    ///
    /// - Cov nkees raug txiav kom tsuas yog muaj cov yuam sij-nqe mus rau sab laug ntawm tus kov no.
    /// - Tus yuam sij thiab tus nqi taw tes qhia los ntawm no kov tau muab rho tawm.
    /// - Txhua tus yuam sij-nqe ua ke ntawm sab xis ntawm tus kov no tau muab tso rau hauv cov chaw faib tshiab.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Tshem tus khub-tus nqi tseem ceeb tau taw qhia los ntawm tus kov no thiab xa rov qab, nrog rau edge tias tus khub tseem ceeb-tus nqi swb rau hauv.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Faib cov hauv paus rau hauv peb ntu:
    ///
    /// - Cov nkees yog raug txiav kom tsuas yog muaj cov npoo thiab qhov tseem ceeb-nqi ua khub ntawm sab laug ntawm tus tuav no.
    /// - Tus yuam sij thiab tus nqi taw tes qhia los ntawm no kov tau muab rho tawm.
    /// - Tag nrho cov npoo thiab qhov tseem ceeb-nqi ua lag luam rau sab xis ntawm tus kov no tau muab tso rau hauv cov tshiab faib ntawm.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Sawv cev ib ntu qhia rau kev ntsuas thiab ua qhov kev nqis tes ua haujlwm nyob ib puag ncig sab hauv tus nqi.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Xaiv cov lus sib npaug uas cuam tshuam nrog ntawm qhov ntawm ib tus menyuam, yog li ntawm KV tam sim ntawd mus rau sab laug lossis sab xis rau ntawm niam txiv ntawm.
    /// Xa tus `Err` yog tias tsis muaj niam txiv.
    /// Panics yog tias niam txiv khoob.
    ///
    /// Hloov qhov seem rau sab laug, kom pom zoo tshaj yog tias qhov muab ntawm yog qee qhov underfull, lub ntsiab lus ntawm no tsuas yog tias nws muaj cov ntsiab lus tsawg dua nws sab laug kwv tij thiab tshaj li nws cov kwv tij txoj cai, yog tias lawv muaj.
    /// Ua li ntawd, kev sib koom tes nrog cov kwv tij laug sab nraub qaum yog nrawm dua, vim peb tsuas yog yuav tsum tau tsiv ntawm n lub N lub ntsiab, tsis txhob hloov lawv mus rau sab xis thiab txav ntau dua N cov ntsiab lus nyob hauv ntej.
    /// Nyiag los ntawm cov kwv tij sab laug kuj tseem nyob nrawm dua, vim peb tsuas yog xav hloov node N ntawm sab rau sab xis, hloov chaw tsawg kawg ntawm Nus sib ceg cov ntsiab lus mus rau sab laug.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Rov qab los yog kev sib koom ua ke yog ua tau, piv txwv li, seb puas muaj chaw txaus hauv lub nkees los ua ke rau hauv nruab nrab KV nrog ob leeg ntawm cov me nyuam nyob ib sab.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Ua lub merge thiab cia qhov kev txiav txim siab txiav txim siab dab tsi rov qab los.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // KEV RUAJ NTSEG: qhov siab ntawm cov ntshav tau muab tso ua ke yog ib qho hauv qab qhov siab
                // ntawm ntawm ntawm no edge, yog li saum toj no xoom, yog li lawv nyob sab hauv.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Ua ke ua ke ntawm niam txiv tus yuam sij tus khub thiab ob qho tib si ntawm tus me nyuam nyob ib sab rau ntawm sab laug ntawm tus me nyuam thiab rov los ua niam txiv ib qho ntawm.
    ///
    ///
    /// Panics tsuas yog peb `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Ua ke ua ke ntawm niam txiv tus khub-qhov tseem ceeb-tus nqi thiab ob qho tib si ntawm cov menyuam nyob ib sab rau ntawm sab laug ntawm tus me nyuam thiab xa rov qab rau ntawm tus me nyuam.
    ///
    ///
    /// Panics tsuas yog peb `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Merges niam txiv tseem ceeb-nqi khub thiab ob uas nyob ib sab tus me nyuam ntshav mus rau hauv rau sab laug tus me nyuam ntawm thiab rov qab lub edge kov nyob rau hauv tus me nyuam ntawd ntawm qhov chaw uas tus tracked tus me nyuam edge twb tuaj,
    ///
    ///
    /// Panics tsuas yog peb `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Tshem tawm tus khub tseem ceeb-tawm ntawm tus menyuam sab laug thiab muab tso rau hauv qhov tseem ceeb-tus nqi khaws cia ntawm niam txiv, thaum thawb tus niam txiv qub nqi tseem ceeb-rau hauv tus menyuam sab xis.
    ///
    /// Rov qab ib tug kov rau edge hauv txoj cai menyuam yaus sib haum rau qhov twg tus thawj edge sau tseg los ntawm `track_right_edge_idx` tas.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Tshem tawm tus khub tseem ceeb-tawm ntawm tus menyuam sab xis thiab muab tso rau hauv qhov chaw khaws khoom tseem ceeb ntawm niam txiv, thaum thawb tus niam txiv qub nqi tseem ceeb rau tus menyuam sab laug.
    ///
    /// Xa ib qho kov rau edge hauv tus menyuam sab laug uas tau teev tseg los ntawm `track_left_edge_idx`, uas tsis tau txav mus rau.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Qhov no ua nyiag zoo ib yam li `steal_left` tab sis nyiag muaj ntau lub ntsiab lus ib zaug.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Nco ntsoov tias peb tuaj yeem nyiag kev nyab xeeb.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Tsiv cov ntaub ntawv nplooj.
            {
                // Ua kom muaj chav hauv nyiag hauv cov menyuam yaus txoj cai.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Txav khoom los ntawm tus menyuam sab laug mus rau sab xis.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Txav mus rau sab laug feem ntau raug nyiag lawm niam txiv.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Txav mus rau niam txiv tus khub tseem ceeb-rau tus menyuam sab xis.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Ua kom muaj chaw hauv xov nyiag.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Nyiag npoo.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// Cov cim clone ntawm `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Nco ntsoov tias peb tuaj yeem nyiag kev nyab xeeb.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Tsiv cov ntaub ntawv nplooj.
            {
                // Txav txoj cai-uas raug nyiag ntau khub rau niam txiv.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Txav mus rau niam txiv tus khub tseem ceeb-rau tus menyuam sab laug.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Txav mus rau ntsiab los ntawm txoj cai tus me nyuam mus rau sab laug ib.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Sau qhov khoob uas cov khoom raug nyiag los siv.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Nyiag npoo.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Sau qhov uas tsis nyiam siv nyiag khoom.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Tshem tawm cov ntaub ntawv zoo li qub lees tias cov ntawm no yog `Leaf` ntawm.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Tuskheej tej zoo li qub ntaub ntawv asserting hais tias qhov no ntawm no yog ib qho `Internal` ntawm.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Xyuas seb puas muaj ntawm pob hauv qab yog `Internal` node lossis `Leaf` ntawm.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Txav cov tsiaj ntawv tom qab `self` los ntawm ib qho node mus rau lwm tus.`right` yuav tsum khoob.
    /// Thawj edge ntawm `right` tseem tsis hloov pauv.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Cov txiaj ntsig ntawm kev nkag mus, thaum cov nem xav tau kom nthuav dav dhau nws lub peev xwm.
pub struct SplitResult<'a, K, V, NodeType> {
    // Hloov node nyob rau hauv cov ntoo uas twb muaj nrog cov ntsiab lus thiab cov npoo uas zwm rau sab laug ntawm `kv`.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Qee tus yuam sij thiab tus nqi sib cais tawm, kom muab tso rau lwm qhov.
    pub kv: (K, V),
    // Cov cuab yeej, tsis kaw, cov ntawm tshiab nrog cov khoom thiab npoo uas zwm rau txoj cai `kv`.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Seb ntawm chiv keeb ntawm no qiv hom cia traversing mus rau lwm cov ntshav nyob rau hauv cov ntoo.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Traversal tsis xav tau, nws tshwm sim siv cov txiaj ntsig ntawm `borrow_mut`.
        // Los ntawm kev ua kom lub cev tsis zoo, thiab tsuas yog tsim cov ntawv xa mus tshiab rau cov hauv paus hniav, peb paub tias txhua qhov siv ntawm `Owned` hom yog rau lub hauv paus.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Ntxig tus nqi rau hauv ib qho hlais ntawm kev pib cov ntsiab lus taug ua ib los ntawm cov khoom cim tsis muaj txheej txheem.
///
/// # Safety
/// Cov nqaj muaj ntau dua `idx` cov khoom.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Tshem tawm thiab muab rov qab rau tus nqi los ntawm cov hlais ntawm txhua qhov pib txheej txheem, tawm hauv qab ntawm ib qho tsis siv neeg lub ntsiab.
///
///
/// # Safety
/// Cov nqaj muaj ntau dua `idx` cov khoom.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Hloov cov khoom hauv ib qho `distance` haujlwm rau sab laug.
///
/// # Safety
/// Cov hlov muaj tsawg kawg yog `distance` cov khoom.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Hloov cov khoom hauv ib qho ntu `distance` haujlwm rau sab xis.
///
/// # Safety
/// Cov hlov muaj tsawg kawg yog `distance` cov khoom.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Txav tag nrho cov nqi ntawm ib qho ntawm kev pib lub ntsiab lus mus rau ib ntu ntawm cov khoom tsis zoo, tawm hauv qab `src` raws li txhua qhov tsis muaj kev xav tau.
///
/// Ua haujlwm zoo li `dst.copy_from_slice(src)` tab sis tsis xav tau `T` los ua `Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;