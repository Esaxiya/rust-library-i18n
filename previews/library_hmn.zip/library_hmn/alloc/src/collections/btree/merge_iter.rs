use core::cmp::Ordering;
use core::fmt::{self, Debug};
use core::iter::FusedIterator;

/// Qhov tseem ceeb ntawm tus txhuam hluav taws xob uas sib koom ua ke tsim tawm ntawm ob qho kev nce siab kom sib xws, piv txwv li ib qho kev sib koom siab lossis ib qho sib txawv.
///
pub struct MergeIterInner<I: Iterator> {
    a: I,
    b: I,
    peeked: Option<Peeked<I>>,
}

/// Lub rooj ntev dua sai dua qhov qhwv ob tus ntsuas hluav taws xob hauv ib qho Peekable, tej zaum vim tias peb tuaj yeem them taus los ua kom FusedIterator ua txhua yam.
///
#[derive(Clone, Debug)]
enum Peeked<I: Iterator> {
    A(I::Item),
    B(I::Item),
}

impl<I: Iterator> Clone for MergeIterInner<I>
where
    I: Clone,
    I::Item: Clone,
{
    fn clone(&self) -> Self {
        Self { a: self.a.clone(), b: self.b.clone(), peeked: self.peeked.clone() }
    }
}

impl<I: Iterator> Debug for MergeIterInner<I>
where
    I: Debug,
    I::Item: Debug,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("MergeIterInner").field(&self.a).field(&self.b).field(&self.peeked).finish()
    }
}

impl<I: Iterator> MergeIterInner<I> {
    /// Tsim cov tub ntxhais tshiab rau tus ua haujlwm sib txuas ua ke ntawm cov khub.
    pub fn new(a: I, b: I) -> Self {
        MergeIterInner { a, b, peeked: None }
    }

    /// Rov qab los rau khub tom ntej ntawm cov khoom xa los ntawm khub ntawm qhov chaw tau muab tso ua ke.
    /// Yog tias ob qho kev xaiv thim rov qab muaj tus nqi, tus nqi ntawd yog sib npaug thiab tshwm sim hauv ob qho chaw.
    /// Yog tias ib qho ntawm cov kev xaiv xa rov qab muaj ib qho nqi, tus nqi ntawd tsis tshwm sim hauv lwm qhov chaw (lossis cov khoom siv tsis nruj me ntsis nce).
    ///
    /// Yog tias tsis muaj kev xaiv rov qab muaj qhov muaj nuj nqis, qhov laj thawj tau ua tiav thiab cov kev hu xov tooj tom qab yuav rov qab ua khub qub.
    ///
    ///
    pub fn nexts<Cmp: Fn(&I::Item, &I::Item) -> Ordering>(
        &mut self,
        cmp: Cmp,
    ) -> (Option<I::Item>, Option<I::Item>)
    where
        I: FusedIterator,
    {
        let mut a_next;
        let mut b_next;
        match self.peeked.take() {
            Some(Peeked::A(next)) => {
                a_next = Some(next);
                b_next = self.b.next();
            }
            Some(Peeked::B(next)) => {
                b_next = Some(next);
                a_next = self.a.next();
            }
            None => {
                a_next = self.a.next();
                b_next = self.b.next();
            }
        }
        if let (Some(ref a1), Some(ref b1)) = (&a_next, &b_next) {
            match cmp(a1, b1) {
                Ordering::Less => self.peeked = b_next.take().map(Peeked::B),
                Ordering::Greater => self.peeked = a_next.take().map(Peeked::A),
                Ordering::Equal => (),
            }
        }
        (a_next, b_next)
    }

    /// Rov qab los ua khub ntawm cov npoo txuas rau `size_hint` ntawm qhov kawg kev ntsuas pa.
    pub fn lens(&self) -> (usize, usize)
    where
        I: ExactSizeIterator,
    {
        match self.peeked {
            Some(Peeked::A(_)) => (1 + self.a.len(), self.b.len()),
            Some(Peeked::B(_)) => (self.a.len(), 1 + self.b.len()),
            _ => (self.a.len(), self.b.len()),
        }
    }
}