use core::intrinsics;
use core::mem;
use core::ptr;

/// Qhov no hloov cov nqi tom qab `v` cim siv los ntawm kev hu mus rau yam muaj feem cuam tshuam.
///
///
/// Yog tias panic tshwm sim hauv `change` kaw, tag nrho cov txheej txheem yuav raug rho tawm.
#[allow(dead_code)] // ceev raws li kev qhia thiab rau future siv
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Qhov no hloov cov nqi tom qab `v` cim siv los ntawm kev hu mus rau yam muaj nuj nqi, thiab rov qab qhov txiaj ntsig tau raws txoj kev.
///
///
/// Yog tias panic tshwm sim hauv `change` kaw, tag nrho cov txheej txheem yuav raug rho tawm.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}