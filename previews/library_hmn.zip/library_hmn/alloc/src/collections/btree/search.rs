use core::borrow::Borrow;
use core::cmp::Ordering;
use core::ops::{Bound, RangeBounds};

use super::node::{marker, ForceResult::*, Handle, NodeRef};

use SearchBound::*;
use SearchResult::*;

pub enum SearchBound<T> {
    /// Xws li cov ciaj ciam mus nrhiav, ib yam li `Bound::Included(T)`.
    Included(T),
    /// Ib qho tshwj xeeb khi rau saib, ib yam li `Bound::Excluded(T)`.
    Excluded(T),
    /// Qhov tsis muaj kev txwv tsis suav nrog lwm tus, xws li `Bound::Unbounded`.
    AllIncluded,
    /// Kev tsis muaj qhov tshwj tsis yog ciaj ciam.
    AllExcluded,
}

impl<T> SearchBound<T> {
    pub fn from_range(range_bound: Bound<T>) -> Self {
        match range_bound {
            Bound::Included(t) => Included(t),
            Bound::Excluded(t) => Excluded(t),
            Bound::Unbounded => AllIncluded,
        }
    }
}

pub enum SearchResult<BorrowType, K, V, FoundType, GoDownType> {
    Found(Handle<NodeRef<BorrowType, K, V, FoundType>, marker::KV>),
    GoDown(Handle<NodeRef<BorrowType, K, V, GoDownType>, marker::Edge>),
}

pub enum IndexResult {
    KV(usize),
    Edge(usize),
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Ntsia nrog tus yuam sij muab hauv ib (sub) ntoo taws los ntawm nkees, rov ua dua.
    /// Rov qab `Found` nrog qhov kov ntawm cov txuam KV, yog tias muaj.
    /// Txwv tsis pub, rov xa tus `GoDown` nrog kev tuav ntawm nplooj nplooj edge qhov twg tus yuam sij.
    ///
    /// Qhov tshwm sim muaj nuj nqis tsuas yog tias tsob ntoo xaj los ntawm qhov tseem ceeb, zoo li tsob ntoo hauv `BTreeMap` yog.
    ///
    pub fn search_tree<Q: ?Sized>(
        mut self,
        key: &Q,
    ) -> SearchResult<BorrowType, K, V, marker::LeafOrInternal, marker::Leaf>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        loop {
            self = match self.search_node(key) {
                Found(handle) => return Found(handle),
                GoDown(handle) => match handle.force() {
                    Leaf(leaf) => return GoDown(leaf),
                    Internal(internal) => internal.descend(),
                },
            }
        }
    }

    /// Nqis los ze rau ntawm qhov ze ntawm qhov uas edge txuam rau txoj kab qis ntawm txoj kab sib txawv yog qhov txawv ntawm edge txuam rau cov plaub sab saud, piv txwv li, nyob ze ntawm uas muaj tsawg kawg ib tus yuam sij muaj nyob hauv ntau yam.
    ///
    ///
    /// Yog tias pom, xa rov qab `Ok` nrog cov ntawm ntawd, lub khub ntawm edge qhov ntsuas nyob hauv nws delimiting qhov ntau, thiab cov khub sib txuas ntawm kev sib txuas ntxiv mus txuas ntxiv tshawb nyob rau hauv cov menyuam yaus, nyob rau hauv rooj plaub ntawm node nyob sab hauv.
    ///
    /// Yog tias tsis pom, rov xa tus `Err` nrog daim nplooj edge txuam rau tag nrho ntau yam.
    ///
    /// Qhov tshwm sim yog muaj nuj nqis tsuas yog yog tsob ntoo xaj xaj los ntawm tus yuam sij.
    ///
    ///
    ///
    ///
    pub fn search_tree_for_bifurcation<'r, Q: ?Sized, R>(
        mut self,
        range: &'r R,
    ) -> Result<
        (
            NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
            usize,
            usize,
            SearchBound<&'r Q>,
            SearchBound<&'r Q>,
        ),
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>,
    >
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // Inlining cov hloov no yuav tsum raug zam.
        // Peb xav tias cov ciaj ciam tshaj tawm los ntawm `range` tseem nyob li qub, tab sis qhov kev coj ua tsis zoo yuav hloov los ntawm kev hu (#81138).
        let (start, end) = (range.start_bound(), range.end_bound());
        match (start, end) {
            (Bound::Excluded(s), Bound::Excluded(e)) if s == e => {
                panic!("range start and end are equal and excluded in BTreeMap")
            }
            (Bound::Included(s) | Bound::Excluded(s), Bound::Included(e) | Bound::Excluded(e))
                if s > e =>
            {
                panic!("range start is greater than range end in BTreeMap")
            }
            _ => {}
        }
        let mut lower_bound = SearchBound::from_range(start);
        let mut upper_bound = SearchBound::from_range(end);
        loop {
            let (lower_edge_idx, lower_child_bound) = self.find_lower_bound_index(lower_bound);
            let (upper_edge_idx, upper_child_bound) = self.find_upper_bound_index(upper_bound);
            if lower_edge_idx > upper_edge_idx {
                panic!("Ord is ill-defined in BTreeMap range")
            }
            if lower_edge_idx < upper_edge_idx {
                return Ok((
                    self,
                    lower_edge_idx,
                    upper_edge_idx,
                    lower_child_bound,
                    upper_child_bound,
                ));
            }
            let common_edge = unsafe { Handle::new_edge(self, lower_edge_idx) };
            match common_edge.force() {
                Leaf(common_edge) => return Err(common_edge),
                Internal(common_edge) => {
                    self = common_edge.descend();
                    lower_bound = lower_child_bound;
                    upper_bound = upper_child_bound;
                }
            }
        }
    }

    /// Pom lub edge nyob rau ntawm cov nchav xa cov khoom ua txhaum qis dua ntawm ntau yam.
    /// Kuj rov ua qhov qis dua los siv rau kev txuas ntxiv tshawb hauv cov me nyuam txuam nrog, yog `self` yog qhov ntawm sab hauv.
    ///
    ///
    /// Qhov tshwm sim yog muaj nuj nqis tsuas yog yog tsob ntoo xaj xaj los ntawm tus yuam sij.
    pub fn find_lower_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_lower_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }

    /// Clone ntawm `find_lower_bound_edge` rau qhov thaj tsam sab saud.
    pub fn find_upper_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_upper_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Zoo li saib muab tus yuam sij rau hauv, tsis tas yuav rov txheeb.
    /// Rov qab `Found` nrog qhov kov ntawm cov txuam KV, yog tias muaj.
    /// Txwv tsis pub, rov xa tus `GoDown` nrog qhov ua haujlwm ntawm edge qhov twg yuav nrhiav tau tus yuam sij (yog tias node nyob sab hauv) lossis qhov uas tus yuam sij tuaj yeem tso.
    ///
    ///
    /// Qhov tshwm sim muaj nuj nqis tsuas yog tias tsob ntoo xaj los ntawm qhov tseem ceeb, zoo li tsob ntoo hauv `BTreeMap` yog.
    ///
    pub fn search_node<Q: ?Sized>(self, key: &Q) -> SearchResult<BorrowType, K, V, Type, Type>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        match self.find_key_index(key) {
            IndexResult::KV(idx) => Found(unsafe { Handle::new_kv(self, idx) }),
            IndexResult::Edge(idx) => GoDown(unsafe { Handle::new_edge(self, idx) }),
        }
    }

    /// Rov qab los yog KV qhov ntsuas ntawm qhov ntawm qhov tseem ceeb (lossis qhov sib txig sib luag), lossis edge index qhov twg tus yuam sij nyob.
    ///
    ///
    /// Qhov tshwm sim muaj nuj nqis tsuas yog tias tsob ntoo xaj los ntawm qhov tseem ceeb, zoo li tsob ntoo hauv `BTreeMap` yog.
    ///
    fn find_key_index<Q: ?Sized>(&self, key: &Q) -> IndexResult
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        let node = self.reborrow();
        let keys = node.keys();
        for (i, k) in keys.iter().enumerate() {
            match key.cmp(k.borrow()) {
                Ordering::Greater => {}
                Ordering::Equal => return IndexResult::KV(i),
                Ordering::Less => return IndexResult::Edge(i),
            }
        }
        IndexResult::Edge(keys.len())
    }

    /// Pom lub edge qhov cim tseg hauv node delimiting txoj kab qis ntawm ntau yam.
    /// Kuj rov ua qhov qis dua los siv rau kev txuas ntxiv tshawb hauv cov me nyuam txuam nrog, yog `self` yog qhov ntawm sab hauv.
    ///
    ///
    /// Qhov tshwm sim yog muaj nuj nqis tsuas yog yog tsob ntoo xaj xaj los ntawm tus yuam sij.
    fn find_lower_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (0, AllIncluded),
            AllExcluded => (self.len(), AllExcluded),
        }
    }

    /// Clone ntawm `find_lower_bound_index` rau qhov thaj tsam sab saud.
    fn find_upper_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (self.len(), AllIncluded),
            AllExcluded => (0, AllExcluded),
        }
    }
}