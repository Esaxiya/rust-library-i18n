use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Txuas rau tag nrho cov tseem ceeb-tus nqi sib luag los ntawm lub union ntawm ob ascending iterators, nce tus `length` nce mus nce los nyob hauv txoj kev.Qhov tom kawg ua rau nws yooj yim dua rau tus neeg hu kom zam dhau qhov txau thaum poob tes tuav qhov rooj.
    ///
    /// Yog tias ob tus tsim tawm tib tus yuam sij, cov qauv no poob cov khub los ntawm tus rov qab sab laug thiab ntxiv rau khub los ntawm tus tsim txoj cai.
    ///
    /// Yog tias koj xav kom tsob ntoo xaus mus rau qhov kev txiav txim siab kom nruj, zoo li rau `BTreeMap`, ob tus neeg ntsuas yuav tsum tsim cov yuam sij hauv kev txiav txim siab, txhua qhov loj dua txhua tus yuam sij hauv tsob ntoo, suav nrog txhua tus yuam sij twb nyob hauv tsob ntoo thaum nkag.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Peb npaj los sib sau ua ke `left` thiab `right` rau hauv kev tso ua ntu zus raws sijhawm hauv qab.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Lub caij no, peb txua ntoo los ntawm cov kab teeb ntsig ua ntu zus raws sijhawm.
        self.bulk_push(iter, length)
    }

    /// Thawb txhua qhov tseem ceeb-nqi kom kawg ntawm tus ntoo, nce lub `length` sib txawv txav raws txoj kev.
    /// Qhov tom kawg ua rau nws yooj yim dua rau tus neeg hu kom zam dhau ib qho xau tawm thaum tus kav hla dej tawg.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Nkag los ntawm txhua qhov tseem ceeb-tus nqi sib tw, thawb lawv mus rau hauv cov nodes thaum qib.
        for (key, value) in iter {
            // Sim thawb tus yuam sij-nqi rau hauv cov nplooj ntawm nplooj tam sim no.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Tsis muaj qhov chaw seem, nce thiab thawb nyob ntawd.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Pom ib qho ntawm qhov chaw nyob sab laug, thawb ntawm no.
                                open_node = parent;
                                break;
                            } else {
                                // Rov qab mus dua.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Peb yog cov nyob rau saum toj, tsim cov hauv paus hniav tshiab thiab thawb rau ntawd.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Thawb tus yuam sij-nqi thiab txoj cai tshiab.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Txheeb mus rau sab xis-cov nplooj dua.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Nce ntev txhua qhov iteration, kom paub tseeb tias daim ntawv qhia dauv cov ntsiab lus ntxiv txawm hais tias dhau ntawm tus theerator panicks.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Tus tshaj tawm rau kev sib txuam ob qho kev tso ua ntu zus rau hauv ib qho
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Yog tias ob tus yuam sij sib npaug, rov xa tus nqi tseem ceeb los ntawm cov khoom kom raug.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}