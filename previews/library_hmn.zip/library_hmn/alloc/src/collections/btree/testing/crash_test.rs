use crate::fmt::Debug;
use std::cmp::Ordering;
use std::sync::atomic::{AtomicUsize, Ordering::SeqCst};

/// Ib daim qauv qhia txog kev sib tsoo ntawm cov chaw sim uas tau soj ntsuam cov xwm txheej tshwj xeeb.
/// Qee qhov teeb meem yuav raug teeb tsa mus rau panic ntawm qee kis.
/// Cov xwm txheej yog `clone`, `drop` lossis qee qhov tsis paub npe `query`.
///
/// Kev tshuaj xyuas kev sib tsoo yog dummies tau paub thiab xaj los ntawm tus id, yog li lawv tuaj yeem siv los ua yuam sij hauv BTreeMap.
/// Qhov kev siv lub hom phiaj siv tsis cia siab rau txhua yam uas tau txhais hauv crate, sib nrug los ntawm `Debug` trait.
///
#[derive(Debug)]
pub struct CrashTestDummy {
    id: usize,
    cloned: AtomicUsize,
    dropped: AtomicUsize,
    queried: AtomicUsize,
}

impl CrashTestDummy {
    /// Tsim kev sib tsoo tsoo dummy tsim.Lub `id` txiav txim siab qhov kev txiav txim thiab sib luag ntawm kev ua haujlwm.
    pub fn new(id: usize) -> CrashTestDummy {
        CrashTestDummy {
            id,
            cloned: AtomicUsize::new(0),
            dropped: AtomicUsize::new(0),
            queried: AtomicUsize::new(0),
        }
    }

    /// Tsim ib qho piv txwv ntawm qhov kev xeem sib xeem tsoo uas sau yam xwm txheej nws tau ntsib thiab xaiv panics.
    ///
    pub fn spawn(&self, panic: Panic) -> Instance<'_> {
        Instance { origin: self, panic }
    }

    /// Rov qab ua li cas pes tsawg zaus ntawm chav dummy tau muab teev tseg.
    pub fn cloned(&self) -> usize {
        self.cloned.load(SeqCst)
    }

    /// Rov qab ua li cas pes tsawg zaus ntawm dummy tau muab tso cia.
    pub fn dropped(&self) -> usize {
        self.dropped.load(SeqCst)
    }

    /// Rov qab ntau npaum li cas zaus ntawm cov dummy tau muaj lawv `query` tus tswv cuab hu ua.
    pub fn queried(&self) -> usize {
        self.queried.load(SeqCst)
    }
}

#[derive(Debug)]
pub struct Instance<'a> {
    origin: &'a CrashTestDummy,
    panic: Panic,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum Panic {
    Never,
    InClone,
    InDrop,
    InQuery,
}

impl Instance<'_> {
    pub fn id(&self) -> usize {
        self.origin.id
    }

    /// Qee cov lus nug tsis qhia npe, qhov txiaj ntsig ntawm uas tau muab rau tas lawm.
    pub fn query<R>(&self, result: R) -> R {
        self.origin.queried.fetch_add(1, SeqCst);
        if self.panic == Panic::InQuery {
            panic!("panic in `query`");
        }
        result
    }
}

impl Clone for Instance<'_> {
    fn clone(&self) -> Self {
        self.origin.cloned.fetch_add(1, SeqCst);
        if self.panic == Panic::InClone {
            panic!("panic in `clone`");
        }
        Self { origin: self.origin, panic: Panic::Never }
    }
}

impl Drop for Instance<'_> {
    fn drop(&mut self) {
        self.origin.dropped.fetch_add(1, SeqCst);
        if self.panic == Panic::InDrop {
            panic!("panic in `drop`");
        }
    }
}

impl PartialOrd for Instance<'_> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.id().partial_cmp(&other.id())
    }
}

impl Ord for Instance<'_> {
    fn cmp(&self, other: &Self) -> Ordering {
        self.id().cmp(&other.id())
    }
}

impl PartialEq for Instance<'_> {
    fn eq(&self, other: &Self) -> bool {
        self.id().eq(&other.id())
    }
}

impl Eq for Instance<'_> {}