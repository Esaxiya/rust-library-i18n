use core::marker::PhantomData;
use core::ptr::NonNull;

/// Qauv rau daim ntawv cog lus ntawm qee qhov siv tshwj xeeb, thaum koj paub tias qhov nyiaj rov qab thiab tag nrho nws cov xeeb leej xeeb ntxwv (piv txwv li, txhua tus taw tes thiab cov ntawv qhia tau los ntawm nws) yuav tsis siv ntxiv rau qee lub sijhawm, tom qab uas koj xav siv thawj qhov kev siv tshwj xeeb dua Cov.
///
///
/// Cov qev tshawb xyuas feem ntau saib xyuas cov kev faib rau qev no rau koj, tab sis qee qhov kev tswjhwm uas ua tiav qhov kev teeb tsa no yog qhov nyuaj heev rau cov compiler ua raws.
/// Ib lub `DormantMutRef` tso cai rau koj los kuaj qiv qiv koj tus kheej, thaum tseem qhia txog nws cov xwm txheej, thiab encapsulating cov nqaij nyoos pointer code xav tau los ua qhov no tsis muaj tus cwj pwm tsis paub tseeb.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Kev ntes tshwj xeeb qiv, thiab tam sim ntawd qiv nws.
    /// Txog rau cov kwv yees, lub neej ntawm kev siv tshiab yog tib yam li lub neej ntawm kev siv thawj, tab sis koj promise siv nws rau lub sijhawm luv.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // KEV RUAJ NTSEG: peb tuav lub qiv thoob plaws 'a ntawm `_marker`, thiab peb nthuav
        // tsuas yog cov ntawv siv, yog li nws yog qhov tshwj xeeb.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Rov qab mus rau lub cev qiv tshwj xeeb thaum ntes.
    ///
    /// # Safety
    ///
    /// Qhov kev thov rov qab yuav tsum tau xaus, piv txwv li, qhov kev xa rov qab los ntawm `new` thiab tag nrho cov taw tes thiab cov ntawv sau los ntawm nws, yuav tsum tsis txhob siv lawm.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // KEV RUAJ NTSEG: peb tus kheej qhov kev nyab xeeb ntawm qhov tsis tau cov lus siv yog dua li nws.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;