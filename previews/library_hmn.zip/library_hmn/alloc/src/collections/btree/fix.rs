use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef, Root};

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Npaj cov khoom hauv qab ntawm cov phiaj xwm los ntawm kev sib koom nrog los sis nyiag los ntawm nkauj muam nraug nus.
    /// Yog hais tias succesful, tiam sis nyob rau tus nqi ntawm shrinking lub niam txiv ntawm, rov qab hais tias shrunk niam txiv ntawm.
    /// Rov qab saib `Err` yog tias node yog lub hauv paus khoob.
    ///
    fn fix_node_through_parent(
        self,
    ) -> Result<Option<NodeRef<marker::Mut<'a>, K, V, marker::Internal>>, Self> {
        let len = self.len();
        if len >= MIN_LEN {
            Ok(None)
        } else {
            match self.choose_parent_kv() {
                Ok(Left(mut left_parent_kv)) => {
                    if left_parent_kv.can_merge() {
                        let parent = left_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        left_parent_kv.bulk_steal_left(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Ok(Right(mut right_parent_kv)) => {
                    if right_parent_kv.can_merge() {
                        let parent = right_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        right_parent_kv.bulk_steal_right(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Err(root) => {
                    if len > 0 {
                        Ok(None)
                    } else {
                        Err(root)
                    }
                }
            }
        }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Cov ceg nce lawm qhov underfull node, thiab yog tias qhov ntawd ua rau nws niam txiv nchav, me me ntawm niam txiv, ntxiv mus.
    /// Rov qab `true` yog tias nws tsau tsob ntoo, `false` yog tias nws tsis tuaj yeem vim tias lub hauv paus nchuav los ua qhov khoob.
    ///
    /// Hom no tsis cia siab tias pog koob yawg koob twb nkag siab lawm thaum nkag teb chaws thiab panics yog tias nws ntsib cov poj koob yawm txwv uas tsis muaj.
    ///
    ///
    ///
    pub fn fix_node_and_affected_ancestors(mut self) -> bool {
        loop {
            match self.fix_node_through_parent() {
                Ok(Some(parent)) => self = parent.forget_type(),
                Ok(None) => return true,
                Err(_) => return false,
            }
        }
    }
}

impl<K, V> Root<K, V> {
    /// Tshem tawm cov qib tsis nyob saum, tab sis khaws ib nplooj khoob yog tias tag nrho tsob ntoo khoob.
    pub fn fix_top(&mut self) {
        while self.height() > 0 && self.len() == 0 {
            self.pop_internal_level();
        }
    }

    /// Cov ntawv khaws cia lossis teeb tsa rau ib qho ntawm cov ceg qis ntawm sab xis ntawm tsob ntoo.
    /// Lwm cov nodes, cov uas tsis yog lub hauv paus los yog tsis tau muaj edge, yuav tsum muaj tsawg kawg MIN_LEN cov ntsiab lus.
    ///
    pub fn fix_right_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().last_kv().fix_right_border_of_right_edge();
            self.fix_top();
        }
    }

    /// Cov cim clone ntawm `fix_right_border`.
    pub fn fix_left_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().first_kv().fix_left_border_of_left_edge();
            self.fix_top();
        }
    }

    /// Txhab tej ceg underfull rau sab ciam teb ntawm tsob ntoo.
    /// Lwm cov nodes, cov uas tsis yog lub hauv paus tsis los yog txoj cai edge, yuav tsum npaj kom muaj li ntawm MIN_LEN cov neeg nyiag.
    ///
    pub fn fix_right_border_of_plentiful(&mut self) {
        let mut cur_node = self.borrow_mut();
        while let Internal(internal) = cur_node.force() {
            // Kuaj yog tias txoj cai-feem ntau tus menyuam yaus hauv qab.
            let mut last_kv = internal.last_kv().consider_for_balancing();
            debug_assert!(last_kv.left_child_len() >= MIN_LEN * 2);
            let right_child_len = last_kv.right_child_len();
            if right_child_len < MIN_LEN {
                // Peb yuav tsum nyiag.
                last_kv.bulk_steal_left(MIN_LEN - right_child_len);
            }

            // Mus txuas ntxiv mus.
            cur_node = last_kv.into_right_child();
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    fn fix_left_border_of_left_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_left_child().first_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }

    fn fix_right_border_of_right_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_right_child().last_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Npaj cov menyuam uas nyob rau sab laug, suav tias yog tus menyuam tsis yog tsis zoo, thiab cov kev cai los ntxiv rau kev muab cov menyuam mus sib ntxiv los tsis ua lub hauv paus.
    ///
    /// Rov tus me nyuam rov los.
    ///
    fn fix_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let left_len = internal_kv.left_child_len();
        debug_assert!(internal_kv.right_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` yuav tsum tsis txhob readjust yog merge tshwm sim rau qib tom ntej.
            let count = (MIN_LEN + 1).saturating_sub(left_len);
            if count > 0 {
                internal_kv.bulk_steal_right(count);
            }
            internal_kv.into_left_child()
        }
    }

    /// Stocks li txoj cai tus me nyuam, piv txwv tias yog sab laug tus me nyuam yog tsis underfull, thiab kev cai ib tug ntxiv caij mus cia phiajcim nws cov me nyuam nyob rau hauv lem tsis ua underfull.
    ///
    /// Rov qab los qhov twg los tus me nyuam thiaj yuav ploj mus.
    ///
    fn fix_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let right_len = internal_kv.right_child_len();
        debug_assert!(internal_kv.left_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` yuav tsum tsis txhob readjust yog merge tshwm sim rau qib tom ntej.
            let count = (MIN_LEN + 1).saturating_sub(right_len);
            if count > 0 {
                internal_kv.bulk_steal_left(count);
            }
            internal_kv.into_right_child()
        }
    }
}