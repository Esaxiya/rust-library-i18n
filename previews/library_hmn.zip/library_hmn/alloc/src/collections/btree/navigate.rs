use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// Lub sij hawm ib ntus siv lwm qhov tawm, hloov pauv tsis sib npaug ntawm tib qho.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Pom qhov txawv nplooj npoo ua kom pom tseeb thaj chaw hauv tsob ntoo.
    /// Rov qab los ib khub ntawm cov leeg sib txawv rau hauv tib tsob ntoo lossis ib khub ntawm kev xaiv khoob.
    ///
    /// # Safety
    ///
    /// Ntshe yog `BorrowType` yog `Immut`, tsis txhob siv cov lej theej tawm mus xyuas tib lub KV ob zaug.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// Sib npaug rau `(root1.first_leaf_edge(), root2.last_leaf_edge())` tab sis ntau txuag.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Pom qhov khub ntawm nplooj npoo npoo delimiting tshwj xeeb ntau yam hauv tsob ntoo.
    ///
    /// Qhov tshwm sim muaj nuj nqis tsuas yog tias tsob ntoo xaj los ntawm qhov tseem ceeb, zoo li tsob ntoo hauv `BTreeMap` yog.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // KEV RUAJ NTSEG: peb hom qiv yuav yog cov tsis txawj tuag.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Pom qhov khub ntawm nplooj npoo npoo delimiting tag nrho ntoo.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// Sib cais cov khoom siv tshwj xeeb rau hauv ib khub ntawm nplooj npoo xa khoom raws cov kab kev cai tswjhwm.
    /// Qhov tshwm sim yog qhov tsis yog tshwj xeeb xa mus rau (some) hloov chaw, uas yuav tsum tau siv kom zoo zoo.
    ///
    /// Qhov tshwm sim muaj nuj nqis tsuas yog tias tsob ntoo xaj los ntawm qhov tseem ceeb, zoo li tsob ntoo hauv `BTreeMap` yog.
    ///
    ///
    /// # Safety
    /// Tsis txhob siv cov lej theej tawm mus xyuas tib lub KV ob zaug.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Sib cais cov khoom siv tshwj xeeb rau hauv ib khub ntawm nplooj npoo delimiting tag nrho ntawm cov ntoo.
    /// Cov txiaj ntsig yog qhov tsis xws li siv tau tso cai rau kev hloov pauv (ntawm qhov muaj nuj nqis xwb), yog li yuav tsum siv nrog saib xyuas.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // Peb theej tawm lub hauv paus NodeRef ntawm no-peb yuav tsis mus saib tib lub KV ob zaug, thiab tsis xaus nrog cov lus sib tshooj nqi dhau.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Sib cais cov khoom siv tshwj xeeb rau hauv ib khub ntawm nplooj npoo delimiting tag nrho ntawm cov ntoo.
    /// Cov txiaj ntsig tau tsis yog sib txawv rau cov neeg siv uas tso cai kev hloov ua kom tsis zoo, yog li yuav tsum siv nrog kev saib xyuas zoo tshaj plaws.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // Peb theej tawm lub hauv paus NodeRef ntawm no-peb yuav tsis nkag mus nws txoj hauv kev uas sib tshooj cov lus qhia tau los ntawm lub hauv paus.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// Muab ib nplooj edge kov, rov [`Result::Ok`] nrog tus kov rau KV uas nyob sib ze ntawm sab xis, uas yog hauv tib qho nplooj ntawm nplooj los yog hauv tus txwv zeej txwv koob.
    ///
    /// Yog tias cov nplooj edge yog zaum kawg hauv cov ntoo, rov [`Result::Err`] nrog lub hauv paus ntawm.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// Muab ib nplooj edge kov, rov [`Result::Ok`] nrog tus kov mus rau KV uas nyob sib ze ntawm sab laug, uas yog nyob ntawm tib nplooj ntawm lossis hauv tus caj ces cov ntawm.
    ///
    /// Yog tias cov nplooj edge yog thawj tus ntawm cov ntoo, rov [`Result::Err`] nrog lub hauv paus ntawm.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Muab sab hauv edge kov, rov [`Result::Ok`] nrog tus kov rau KV uas nyob sib ze ntawm sab xis, uas yog nrog tib qho ntawm sab hauv los yog hauv tus txwv koob tseeg.
    ///
    /// Yog tias sab hauv edge yog qhov kawg hauv tus ntoo, rov [`Result::Err`] nrog lub hauv paus ntawm.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Muab cov nplooj edge kov rau hauv tsob ntoo tuag, rov qab rau nplooj tom ntej edge ntawm sab xis, thiab tus khub tseem ceeb-rau hauv nruab nrab, uas yog nyob hauv tib qho nplooj ntawm nplooj, hauv keeb kwm txwv zeej txwv koob, lossis tsis nyob.
    ///
    ///
    /// Txoj kev no tseem cuam tshuam ib lub node(s) nws tau mus txog qhov kawg ntawm.
    /// Qhov no qhia tau hais tias yog tias tsis muaj ntau tus khub tseem ceeb-nqi tshwm sim, tag nrho cov ntoo seem yuav tau muaj chaw nyob thiab tsis muaj dab tsi rov qab los.
    ///
    /// # Safety
    /// Lub edge yuav tsum tsis txhob muaj yav tas los tau xa rov qab los ntawm counterpart `deallocating_next_back`.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Muab daim nplooj edge kov rau tsob ntoo tuag, rov qab rau nplooj tom ntej edge ntawm sab laug, thiab tus khub tseem ceeb-rau hauv nruab nrab, uas yog nyob hauv tib qho nplooj ntawm nplooj, hauv keeb kwm ntawm txwv zeej txwv koob, lossis tsis nyob.
    ///
    ///
    /// Txoj kev no tseem cuam tshuam ib lub node(s) nws tau mus txog qhov kawg ntawm.
    /// Qhov no qhia tau hais tias yog tias tsis muaj ntau tus khub tseem ceeb-nqi tshwm sim, tag nrho cov ntoo seem yuav tau muaj chaw nyob thiab tsis muaj dab tsi rov qab los.
    ///
    /// # Safety
    /// Lub edge yuav tsum tsis txhob muaj yav tas los tau xa rov qab los ntawm counterpart `deallocating_next`.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Cais ib pawg ntawm nodes los ntawm nplooj mus txog rau lub hauv paus.
    /// Nov yog tib txoj kev los daws qhov seem ntawm cov ntoo tom qab `deallocating_next` thiab `deallocating_next_back` tau nibbling ntawm ob tog ntoo, thiab tau tsoo tib edge.
    /// Raws li nws tau npaj siab tsuas yog hu ua thaum txhua tus yuam sij thiab txiaj ntsig tau rov qab los, tsis muaj kev ntxuav tu ib qho twg ntawm cov yuam sij lossis txiaj ntsig.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Tsiv cov nplooj edge kov rau daim nplooj tom ntej edge thiab rov xa cov ntawv xa mus rau tus yuam sij thiab hauv nruab nrab.
    ///
    ///
    /// # Safety
    /// Yuav tsum muaj lwm KV nyob rau hauv cov kev taw qhia mus ncig.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// Tsiv cov nplooj edge kov rau cov nplooj dhau los edge thiab rov xa cov ntawv xa mus rau tus yuam sij thiab hauv nruab nrab.
    ///
    ///
    /// # Safety
    /// Yuav tsum muaj lwm KV nyob rau hauv cov kev taw qhia mus ncig.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Tsiv cov nplooj edge kov rau daim nplooj tom ntej edge thiab rov xa cov ntawv xa mus rau tus yuam sij thiab hauv nruab nrab.
    ///
    ///
    /// # Safety
    /// Yuav tsum muaj lwm KV nyob rau hauv cov kev taw qhia mus ncig.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // Ua qhov kawg no tau nrawm dua, raws li kev ntsuas.
        kv.into_kv_valmut()
    }

    /// Tsiv cov nplooj edge kov rau cov nplooj dhau los thiab xa rov qab xa mus rau tus yuam sij thiab tus nqi nruab nrab.
    ///
    ///
    /// # Safety
    /// Yuav tsum muaj lwm KV nyob rau hauv cov kev taw qhia mus ncig.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // Ua qhov kawg no tau nrawm dua, raws li kev ntsuas.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Tsiv cov nplooj edge kov rau daim nplooj tom ntej edge thiab rov xa tus yawm sij thiab muaj nqis hauv nruab nrab, sib cog lus rau ib qho ntawm sab laug thaum tawm hauv lub sib haum edge hauv nws niam txiv nkees.
    ///
    /// # Safety
    /// - Yuav tsum muaj lwm KV nyob rau hauv cov kev taw qhia mus ncig.
    /// - Tias KV yav tas los tsis tau rov qab los ntawm counterpart `next_back_unchecked` ntawm txhua daim qauv ntawm cov leeg siv los hla ntoo.
    ///
    /// Tib txoj kev nyab xeeb los mus ua tiav nrog tus kov tshiab yog los piv rau nws, poob nws, hu rau tus qauv no dua rau nws qhov kev nyab xeeb, lossis hu rau counterpart `next_back_unchecked` rau nws qhov kev nyab xeeb.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// Tsiv cov nplooj edge kov rau cov nplooj dhau los edge thiab rov xa tus yawm sij thiab nqi hauv nruab nrab, sib cog lus rau ib qho ntawm sab laug thaum tawm hauv xov edge hauv nws niam txiv nkees.
    ///
    /// # Safety
    /// - Yuav tsum muaj lwm KV nyob rau hauv cov kev taw qhia mus ncig.
    /// - Daim nplooj edge ntawd tsis tau xa rov qab los ntawm counterpart `next_unchecked` ntawm ib daim qauv ntawm cov leeg coj los mus hla ntoo.
    ///
    /// Tib txoj kev nyab xeeb los mus ua tiav nrog tus kov tshiab yog los piv rau nws, poob nws, hu rau tus qauv no dua rau nws qhov kev nyab xeeb, lossis hu rau counterpart `next_unchecked` rau nws qhov kev nyab xeeb.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Rov qab rau sab kawg nkaus nplooj nplooj edge hauv los yog hauv qab ntawm, hauv lwm txoj lus, edge koj xav tau ua ntej thaum mus tom ntej (lossis kawg thaum navigating rov qab).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// Rov qab rau sab nplooj siab tshaj plaws edge rau hauv los yog hauv qab ntawm, hauv lwm txoj lus, edge koj xav tau kawg thaum mus tom ntej (lossis ua ntej thaum mus ncig rov qab).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Mus ntsib cov nplooj cag thiab cov KVs nyob sab hauv los ntawm cov yuam sij nce, thiab tseem mus saib cov nig sab hauv tag nrho hauv qhov kev txiav txim siab ua ntej, txhais tau tias cov nog sab hauv ua ntej lawv cov KVs thiab lawv cov menyuam.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// Laij seb muaj pes tsawg qhov khoom hauv ib (sub) ntoo.
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// Rov cov nplooj edge ze rau KV rau kev xa mus tom ntej.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// Rov cov nplooj edge ze tshaj rau KV rau kev rov qab siv nkoj.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}