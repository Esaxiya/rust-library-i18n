//! Daim ob-txuas nrog rau cov nodes.
//!
//! Lub `LinkedList` tso cai thawb thiab tawm tsam thaum kawg ntawm lub sijhawm tsis tu ncua.
//!
//! NOTE: Nws yuav luag txhua lub sijhawm zoo siv [`Vec`] lossis [`VecDeque`] vim tias cov khoom siv ntim quav yog feem ntau tau nrawm dua, nco tau zoo dua, thiab ua kom zoo dua ntawm CPU cache.
//!
//!
//! [`Vec`]: crate::vec::Vec
//! [`VecDeque`]: super::vec_deque::VecDeque
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::Ordering;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator};
use core::marker::PhantomData;
use core::mem;
use core::ptr::NonNull;

use super::SpecExtend;
use crate::boxed::Box;

#[cfg(test)]
mod tests;

/// Daim ob-txuas nrog rau cov nodes.
///
/// Lub `LinkedList` tso cai thawb thiab tawm tsam thaum kawg ntawm lub sijhawm tsis tu ncua.
///
/// NOTE: Nws yuav luag txhua lub sijhawm zoo siv `Vec` lossis `VecDeque` vim tias cov khoom siv ntim quav yog feem ntau tau nrawm dua, nco tau zoo dua, thiab ua kom zoo dua ntawm CPU cache.
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "LinkedList")]
pub struct LinkedList<T> {
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
    marker: PhantomData<Box<Node<T>>>,
}

struct Node<T> {
    next: Option<NonNull<Node<T>>>,
    prev: Option<NonNull<Node<T>>>,
    element: T,
}

/// Tus ntsuas pa hla cov khoom ntawm `LinkedList`.
///
/// Cov `struct` no yog tsim los ntawm [`LinkedList::iter()`].
/// Saib nws cov ntawv pov thawj ntxiv.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
    marker: PhantomData<&'a Node<T>>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.len).finish()
    }
}

// FIXME(#26925) Tshem tawm hauv kev pom zoo ntawm `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { ..*self }
    }
}

/// Ib qho hloov pauv tau hla cov khoom ntawm ib qho `LinkedList`.
///
/// Cov `struct` no yog tsim los ntawm [`LinkedList::iter_mut()`].
/// Saib nws cov ntawv pov thawj ntxiv.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IterMut<'a, T: 'a> {
    // Peb ua *tsis* tau tshaj tawm tus kheej tag nrho cov npe nyob ntawm no, cov ntawv xa mus rau node's `element` tau raug tso tawm los ntawm tus kav!Yog li ceev faj thaum siv qhov no;cov hau kev hauv kev hu ua yuav tsum paub txog tias tuaj yeem muaj cov tes taw qhia txog `element`.
    //
    //
    list: &'a mut LinkedList<T>,
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IterMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IterMut").field(&self.list).field(&self.len).finish()
    }
}

/// Tus ua tswv ntiag tug dhau cov ntsiab lus ntawm `LinkedList`.
///
/// Cov `struct` no yog tsim los ntawm [`into_iter`] tus qauv ntawm [`LinkedList`] (muab los ntawm `IntoIterator` trait).
/// Saib nws cov ntawv pov thawj ntxiv.
///
/// [`into_iter`]: LinkedList::into_iter
#[derive(Clone)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<T> {
    list: LinkedList<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.list).finish()
    }
}

impl<T> Node<T> {
    fn new(element: T) -> Self {
        Node { next: None, prev: None, element }
    }

    fn into_element(self: Box<Self>) -> T {
        self.element
    }
}

// tus kheej txoj kev
impl<T> LinkedList<T> {
    /// Ntxiv cov lej muab rau sab xub ntiag.
    #[inline]
    fn push_front_node(&mut self, mut node: Box<Node<T>>) {
        // Txoj kev no tau saib xyuas kom tsis txhob tsim cov ntawv xa mus rau ib cov nodes tag nrho, kom muaj qhov siv tau ntawm cov lus taw qhia mus rau `element`.
        //
        unsafe {
            node.next = self.head;
            node.prev = None;
            let node = Some(Box::leak(node).into());

            match self.head {
                None => self.tail = node,
                // Tsim tsis qhov tshiab hloov (unique!) kev xa ntawv sib tshooj `element`.
                Some(head) => (*head.as_ptr()).prev = node,
            }

            self.head = node;
            self.len += 1;
        }
    }

    /// Tshem tawm thiab rov qab node ntawm daim ntawv.
    #[inline]
    fn pop_front_node(&mut self) -> Option<Box<Node<T>>> {
        // Txoj kev no tau saib xyuas kom tsis txhob tsim cov ntawv xa mus rau ib cov nodes tag nrho, kom muaj qhov siv tau ntawm cov lus taw qhia mus rau `element`.
        //
        self.head.map(|node| unsafe {
            let node = Box::from_raw(node.as_ptr());
            self.head = node.next;

            match self.head {
                None => self.tail = None,
                // Tsim tsis qhov tshiab hloov (unique!) kev xa ntawv sib tshooj `element`.
                Some(head) => (*head.as_ptr()).prev = None,
            }

            self.len -= 1;
            node
        })
    }

    /// Ntxiv cov lej muab rau sab nraum qab.
    #[inline]
    fn push_back_node(&mut self, mut node: Box<Node<T>>) {
        // Txoj kev no tau saib xyuas kom tsis txhob tsim cov ntawv xa mus rau ib cov nodes tag nrho, kom muaj qhov siv tau ntawm cov lus taw qhia mus rau `element`.
        //
        unsafe {
            node.next = None;
            node.prev = self.tail;
            let node = Some(Box::leak(node).into());

            match self.tail {
                None => self.head = node,
                // Tsim tsis qhov tshiab hloov (unique!) kev xa ntawv sib tshooj `element`.
                Some(tail) => (*tail.as_ptr()).next = node,
            }

            self.tail = node;
            self.len += 1;
        }
    }

    /// Tshem tawm thiab rov qab qib ntawm qhov rov tom qab.
    #[inline]
    fn pop_back_node(&mut self) -> Option<Box<Node<T>>> {
        // Txoj kev no tau saib xyuas kom tsis txhob tsim cov ntawv xa mus rau ib cov nodes tag nrho, kom muaj qhov siv tau ntawm cov lus taw qhia mus rau `element`.
        //
        self.tail.map(|node| unsafe {
            let node = Box::from_raw(node.as_ptr());
            self.tail = node.prev;

            match self.tail {
                None => self.head = None,
                // Tsim tsis qhov tshiab hloov (unique!) kev xa ntawv sib tshooj `element`.
                Some(tail) => (*tail.as_ptr()).next = None,
            }

            self.len -= 1;
            node
        })
    }

    /// Txuas cov ntawv uas tau hais tseg ntawm daim npe tam sim no.
    ///
    /// Ceeb Toom: qhov no yuav tsis xyuas tias cov muab tau teev rau cov npe tam sim no.
    ///
    /// Txoj kev no yuav tsum saib xyuas kom tsis txhob tsim cov ntawv xa mus rau `element`, kom paub qhov tseeb ntawm cov neeg hais tsis tau.
    ///
    #[inline]
    unsafe fn unlink_node(&mut self, mut node: NonNull<Node<T>>) {
        let node = unsafe { node.as_mut() }; // qhov no yog peb tam sim no, peb tuaj yeem tsim qhov &mut.

        // Tsim tsis qhov tshiab hloov (unique!) kev xa ntawv sib tshooj `element`.
        match node.prev {
            Some(prev) => unsafe { (*prev.as_ptr()).next = node.next },
            // node no yog node head
            None => self.head = node.next,
        };

        match node.next {
            Some(next) => unsafe { (*next.as_ptr()).prev = node.prev },
            // lub node no yog Tail node
            None => self.tail = node.prev,
        };

        self.len -= 1;
    }

    /// Splices ib cov series ntawm cov nodes ntawm ob cov ntshav uas twb muaj lawm.
    ///
    /// Lus Ceeb Toom: qhov no yuav tsis txheeb xyuas tias cov ntawm muab rau ntawm ob daim ntawv teev npe uas twb muaj lawm.
    #[inline]
    unsafe fn splice_nodes(
        &mut self,
        existing_prev: Option<NonNull<Node<T>>>,
        existing_next: Option<NonNull<Node<T>>>,
        mut splice_start: NonNull<Node<T>>,
        mut splice_end: NonNull<Node<T>>,
        splice_length: usize,
    ) {
        // Txoj kev no tau saib xyuas kom tsis txhob tsim ntau yam kev hloov pauv rau cov nodes tib lub sijhawm, kom tswj kev siv tau ntawm cov lus taw qhia mus rau `element`.
        //
        if let Some(mut existing_prev) = existing_prev {
            unsafe {
                existing_prev.as_mut().next = Some(splice_start);
            }
        } else {
            self.head = Some(splice_start);
        }
        if let Some(mut existing_next) = existing_next {
            unsafe {
                existing_next.as_mut().prev = Some(splice_end);
            }
        } else {
            self.tail = Some(splice_end);
        }
        unsafe {
            splice_start.as_mut().prev = existing_prev;
            splice_end.as_mut().next = existing_next;
        }

        self.len += splice_length;
    }

    /// Txiav tag nrho cov nkees los ntawm cov kab ntawv txuas nrog ua cov nodes.
    #[inline]
    fn detach_all_nodes(mut self) -> Option<(NonNull<Node<T>>, NonNull<Node<T>>, usize)> {
        let head = self.head.take();
        let tail = self.tail.take();
        let len = mem::replace(&mut self.len, 0);
        if let Some(head) = head {
            let tail = tail.unwrap_or_else(|| unsafe { core::hint::unreachable_unchecked() });
            Some((head, tail, len))
        } else {
            None
        }
    }

    #[inline]
    unsafe fn split_off_before_node(
        &mut self,
        split_node: Option<NonNull<Node<T>>>,
        at: usize,
    ) -> Self {
        // Cov cais nkees yog cov node tshiab lub taub hau ntawm ntu thib ob
        if let Some(mut split_node) = split_node {
            let first_part_head;
            let first_part_tail;
            unsafe {
                first_part_tail = split_node.as_mut().prev.take();
            }
            if let Some(mut tail) = first_part_tail {
                unsafe {
                    tail.as_mut().next = None;
                }
                first_part_head = self.head;
            } else {
                first_part_head = None;
            }

            let first_part = LinkedList {
                head: first_part_head,
                tail: first_part_tail,
                len: at,
                marker: PhantomData,
            };

            // Kho lub taub hau ptr ntawm ntu thib ob
            self.head = Some(split_node);
            self.len = self.len - at;

            first_part
        } else {
            mem::replace(self, LinkedList::new())
        }
    }

    #[inline]
    unsafe fn split_off_after_node(
        &mut self,
        split_node: Option<NonNull<Node<T>>>,
        at: usize,
    ) -> Self {
        // Cov faib tawm yog qhov tawm ntawm tus Tsov tus tw tshiab ntawm thawj ntu thiab yog tus tswv ntawm lub taub hau ntawm feem thib ob.
        //
        if let Some(mut split_node) = split_node {
            let second_part_head;
            let second_part_tail;
            unsafe {
                second_part_head = split_node.as_mut().next.take();
            }
            if let Some(mut head) = second_part_head {
                unsafe {
                    head.as_mut().prev = None;
                }
                second_part_tail = self.tail;
            } else {
                second_part_tail = None;
            }

            let second_part = LinkedList {
                head: second_part_head,
                tail: second_part_tail,
                len: self.len - at,
                marker: PhantomData,
            };

            // Kho qhov Tsov tus tw ptr ntawm thawj ntu
            self.tail = Some(split_node);
            self.len = at;

            second_part
        } else {
            mem::replace(self, LinkedList::new())
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for LinkedList<T> {
    /// Tsim cov khoob `LinkedList<T>`.
    #[inline]
    fn default() -> Self {
        Self::new()
    }
}

impl<T> LinkedList<T> {
    /// Tsim cov khoob `LinkedList`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let list: LinkedList<u32> = LinkedList::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_linked_list_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        LinkedList { head: None, tail: None, len: 0, marker: PhantomData }
    }

    /// Tsiv tag nrho cov ntsiab lus los ntawm `other` mus rau qhov kawg ntawm daim ntawv.
    ///
    /// Qhov no siv tag nrho cov nodes los ntawm `other` thiab txav mus rau hauv `self`.
    /// Tom qab cov haujlwm no, `other` dhau los khoob.
    ///
    /// Txoj haujlwm no yuav tsum suav hauv *O*(1) sijhawm thiab *O*(1) nco.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list1 = LinkedList::new();
    /// list1.push_back('a');
    ///
    /// let mut list2 = LinkedList::new();
    /// list2.push_back('b');
    /// list2.push_back('c');
    ///
    /// list1.append(&mut list2);
    ///
    /// let mut iter = list1.iter();
    /// assert_eq!(iter.next(), Some(&'a'));
    /// assert_eq!(iter.next(), Some(&'b'));
    /// assert_eq!(iter.next(), Some(&'c'));
    /// assert!(iter.next().is_none());
    ///
    /// assert!(list2.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn append(&mut self, other: &mut Self) {
        match self.tail {
            None => mem::swap(self, other),
            Some(mut tail) => {
                // `as_mut` zoo nyob ntawm no vim tias peb muaj kev nkag mus rau tas nrho ob qho npe.
                //
                if let Some(mut other_head) = other.head.take() {
                    unsafe {
                        tail.as_mut().next = Some(other_head);
                        other_head.as_mut().prev = Some(tail);
                    }

                    self.tail = other.tail.take();
                    self.len += mem::replace(&mut other.len, 0);
                }
            }
        }
    }

    /// Tsiv tag nrho cov ntsiab lus los ntawm `other` mus rau qhov pib ntawm daim ntawv.
    #[unstable(feature = "linked_list_prepend", issue = "none")]
    pub fn prepend(&mut self, other: &mut Self) {
        match self.head {
            None => mem::swap(self, other),
            Some(mut head) => {
                // `as_mut` zoo nyob ntawm no vim tias peb muaj kev nkag mus rau tas nrho ob qho npe.
                //
                if let Some(mut other_tail) = other.tail.take() {
                    unsafe {
                        head.as_mut().prev = Some(other_tail);
                        other_tail.as_mut().next = Some(head);
                    }

                    self.head = other.head.take();
                    self.len += mem::replace(&mut other.len, 0);
                }
            }
        }
    }

    /// Muab rau pem hauv ntej iterator.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// let mut iter = list.iter();
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { head: self.head, tail: self.tail, len: self.len, marker: PhantomData }
    }

    /// Muab cov xa mus tom ntej nrog kev xa rov qab ua ke.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// for element in list.iter_mut() {
    ///     *element += 10;
    /// }
    ///
    /// let mut iter = list.iter();
    /// assert_eq!(iter.next(), Some(&10));
    /// assert_eq!(iter.next(), Some(&11));
    /// assert_eq!(iter.next(), Some(&12));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { head: self.head, tail: self.tail, len: self.len, list: self }
    }

    /// Muab cov ntawv taw qhia ntawm lub hauv ntej.
    ///
    /// Tus cursor yog taw rau "ghost" qhov tsis yog lub npe yog daim ntawv khoob.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_front(&self) -> Cursor<'_, T> {
        Cursor { index: 0, current: self.head, list: self }
    }

    /// Muab cov ntawv qhia cov ncauj lus nrog cov haujlwm kho ntawm cov ua ntej.
    ///
    /// Tus cursor yog taw rau "ghost" qhov tsis yog lub npe yog daim ntawv khoob.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_front_mut(&mut self) -> CursorMut<'_, T> {
        CursorMut { index: 0, current: self.head, list: self }
    }

    /// Muab cov khoom taw qhia ntawm cov tom qab thaum caij.
    ///
    /// Tus cursor yog taw rau "ghost" qhov tsis yog lub npe yog daim ntawv khoob.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_back(&self) -> Cursor<'_, T> {
        Cursor { index: self.len.checked_sub(1).unwrap_or(0), current: self.tail, list: self }
    }

    /// Muab cov ntawv qhia cov ncauj lus nrog kev hloov kho ua haujlwm ntawm cov khoom tom qab.
    ///
    /// Tus cursor yog taw rau "ghost" qhov tsis yog lub npe yog daim ntawv khoob.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_back_mut(&mut self) -> CursorMut<'_, T> {
        CursorMut { index: self.len.checked_sub(1).unwrap_or(0), current: self.tail, list: self }
    }

    /// Rov qab `true` yog `LinkedList` yog npliag.
    ///
    /// Txoj haujlwm no yuav tsum suav hauv *O*(1) sijhawm.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert!(dl.is_empty());
    ///
    /// dl.push_front("foo");
    /// assert!(!dl.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.head.is_none()
    }

    /// Rov qab qhov ntev ntawm `LinkedList`.
    ///
    /// Txoj haujlwm no yuav tsum suav hauv *O*(1) sijhawm.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// assert_eq!(dl.len(), 1);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.len(), 2);
    ///
    /// dl.push_back(3);
    /// assert_eq!(dl.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Tshem tawm tag nrho cov ntsiab lus ntawm `LinkedList`.
    ///
    /// Qhov no lub lag luam yuav tsum laij nyob rau hauv *O*(*n*) lub sij hawm.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// dl.push_front(1);
    /// assert_eq!(dl.len(), 2);
    /// assert_eq!(dl.front(), Some(&1));
    ///
    /// dl.clear();
    /// assert_eq!(dl.len(), 0);
    /// assert_eq!(dl.front(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        *self = Self::new();
    }

    /// Rov qab `true` yog `LinkedList` muaj cov khoom sib npaug nrog tus nqi muab.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// assert_eq!(list.contains(&0), true);
    /// assert_eq!(list.contains(&10), false);
    /// ```
    #[stable(feature = "linked_list_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        self.iter().any(|e| e == x)
    }

    /// Muab cov ntaub ntawv pov thawj rau cov khoom siv ua ntej, lossis `None` yog tias cov ntawv tsis muaj.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.front(), None);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front(), Some(&1));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        unsafe { self.head.as_ref().map(|node| &node.as_ref().element) }
    }

    /// Muab qhov siv tau hloov mus rau qhov ua ntej, lossis `None` yog qhov sau tsis tau.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.front(), None);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front(), Some(&1));
    ///
    /// match dl.front_mut() {
    ///     None => {},
    ///     Some(x) => *x = 5,
    /// }
    /// assert_eq!(dl.front(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        unsafe { self.head.as_mut().map(|node| &mut node.as_mut().element) }
    }

    /// Muab cov ntawv pov thawj rau cov khoom tom qab, lossis `None` yog tias cov ntawv tsis muaj.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.back(), None);
    ///
    /// dl.push_back(1);
    /// assert_eq!(dl.back(), Some(&1));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        unsafe { self.tail.as_ref().map(|node| &node.as_ref().element) }
    }

    /// Muab qhov siv tau hloov mus rau qhov rov tom qab, lossis `None` yog qhov sau tsis tau.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.back(), None);
    ///
    /// dl.push_back(1);
    /// assert_eq!(dl.back(), Some(&1));
    ///
    /// match dl.back_mut() {
    ///     None => {},
    ///     Some(x) => *x = 5,
    /// }
    /// assert_eq!(dl.back(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        unsafe { self.tail.as_mut().map(|node| &mut node.as_mut().element) }
    }

    /// Ntxiv ib qho khoom ua ntej hauv cov npe.
    ///
    /// Txoj haujlwm no yuav tsum suav hauv *O*(1) sijhawm.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// assert_eq!(dl.front().unwrap(), &2);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front().unwrap(), &1);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, elt: T) {
        self.push_front_node(box Node::new(elt));
    }

    /// Tshem tawm thawj lub ntsiab thiab xa rov qab nws, lossis `None` yog tias cov ntawv tsis muaj.
    ///
    ///
    /// Txoj haujlwm no yuav tsum suav hauv *O*(1) sijhawm.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// assert_eq!(d.pop_front(), None);
    ///
    /// d.push_front(1);
    /// d.push_front(3);
    /// assert_eq!(d.pop_front(), Some(3));
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        self.pop_front_node().map(Node::into_element)
    }

    /// Tso cov khoom rau sab nraum qab ntawm cov npe.
    ///
    /// Txoj haujlwm no yuav tsum suav hauv *O*(1) sijhawm.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// d.push_back(1);
    /// d.push_back(3);
    /// assert_eq!(3, *d.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, elt: T) {
        self.push_back_node(box Node::new(elt));
    }

    /// Tshem tawm cov khoom kawg ntawm cov npe thiab rov xa nws, lossis `None` yog tias nws khoob.
    ///
    ///
    /// Txoj haujlwm no yuav tsum suav hauv *O*(1) sijhawm.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// assert_eq!(d.pop_back(), None);
    /// d.push_back(1);
    /// d.push_back(3);
    /// assert_eq!(d.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        self.pop_back_node().map(Node::into_element)
    }

    /// Sib faib cov npe ua ob ntawm cov taw qhia.
    /// Rov qab txhua yam tom qab muab qhia, suav nrog qhov ntsuas.
    ///
    /// Qhov no lub lag luam yuav tsum laij nyob rau hauv *O*(*n*) lub sij hawm.
    ///
    /// # Panics
    ///
    /// Panics yog `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    ///
    /// d.push_front(1);
    /// d.push_front(2);
    /// d.push_front(3);
    ///
    /// let mut split = d.split_off(2);
    ///
    /// assert_eq!(split.pop_front(), Some(1));
    /// assert_eq!(split.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn split_off(&mut self, at: usize) -> LinkedList<T> {
        let len = self.len();
        assert!(at <= len, "Cannot split off at a nonexistent index");
        if at == 0 {
            return mem::take(self);
        } else if at == len {
            return Self::new();
        }

        // Hauv qab no, peb nkag mus rau ntawm 'i-1`th ntawm, los ntawm qhov pib lossis thaum kawg, nyob ntawm seb qhov twg yuav nrawm dua.
        //
        let split_node = if at - 1 <= len - 1 - (at - 1) {
            let mut iter = self.iter_mut();
            // tsis txhob hla siv .skip() (uas tsim tus qauv tshiab), peb hla manually yog li peb tuaj yeem nkag mus rau lub taub hau teb yam tsis siv raws cov ntsiab lus ntawm kev hla
            //
            //
            for _ in 0..at - 1 {
                iter.next();
            }
            iter.head
        } else {
            // zoo dua pib txij qhov kawg
            let mut iter = self.iter_mut();
            for _ in 0..len - 1 - (at - 1) {
                iter.next_back();
            }
            iter.tail
        };
        unsafe { self.split_off_after_node(split_node, at) }
    }

    /// Tshem tawm ntawm lub caij ntawm qhov muab teev thiab rov xa rov qab.
    ///
    /// Qhov no lub lag luam yuav tsum laij nyob rau hauv *O*(*n*) lub sij hawm.
    ///
    /// # Panics
    /// Panics yog ntawm>=len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(linked_list_remove)]
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    ///
    /// d.push_front(1);
    /// d.push_front(2);
    /// d.push_front(3);
    ///
    /// assert_eq!(d.remove(1), 2);
    /// assert_eq!(d.remove(0), 3);
    /// assert_eq!(d.remove(0), 1);
    /// ```
    #[unstable(feature = "linked_list_remove", issue = "69210")]
    pub fn remove(&mut self, at: usize) -> T {
        let len = self.len();
        assert!(at < len, "Cannot remove at an index outside of the list bounds");

        // Hauv qab no, peb kho raws qhov ntawm ntawm qhov ntsuas, ib qho los ntawm qhov pib lossis thaum kawg, nyob ntawm seb qhov twg yuav nrawm dua.
        //
        let offset_from_end = len - at - 1;
        if at <= offset_from_end {
            let mut cursor = self.cursor_front_mut();
            for _ in 0..at {
                cursor.move_next();
            }
            cursor.remove_current().unwrap()
        } else {
            let mut cursor = self.cursor_back_mut();
            for _ in 0..offset_from_end {
                cursor.move_prev();
            }
            cursor.remove_current().unwrap()
        }
    }

    /// Tsim tus ntsuas hluav taws xob uas siv kaw kom txiav txim siab yog tias ib qho khoom siv yuav tsum tau muab tshem tawm.
    ///
    /// Yog tias qhov kaw rov qab yog qhov tseeb, tom qab lub ntsiab lus raug tshem tawm thiab npaj tawm.
    /// Yog tias qhov xwm txheej kaw rov qab tsis muaj tseeb, lub hauv paus yuav nyob rau hauv cov npe thiab yuav tsis tawm los ntawm tus kav.
    ///
    /// Nco ntsoov tias `drain_filter` cia koj hloov txhua lub keeb hauv lub lim dej, tsis hais koj yuav xaiv los khaws lossis tshem nws.
    ///
    ///
    /// # Examples
    ///
    /// Sib cais cov npe rau evens thiab txawv, rov siv daim ntawv teev npe:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// use std::collections::LinkedList;
    ///
    /// let mut numbers: LinkedList<u32> = LinkedList::new();
    /// numbers.extend(&[1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15]);
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<LinkedList<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens.into_iter().collect::<Vec<_>>(), vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds.into_iter().collect::<Vec<_>>(), vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F>
    where
        F: FnMut(&mut T) -> bool,
    {
        // zam kev teeb meem qiv nyiaj.
        let it = self.head;
        let old_len = self.len;

        DrainFilter { list: self, it, pred: filter, idx: 0, old_len }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for LinkedList<T> {
    fn drop(&mut self) {
        struct DropGuard<'a, T>(&'a mut LinkedList<T>);

        impl<'a, T> Drop for DropGuard<'a, T> {
            fn drop(&mut self) {
                // Ua txuas tib lub voj uas peb ua hauv qab no.Qhov no tsuas yog sau thaum lub caij tus puas tsuaj.
                // Yog tias ib qho ntxiv panics qhov no yuav rho me me.
                while self.0.pop_front_node().is_some() {}
            }
        }

        while let Some(node) = self.pop_front_node() {
            let guard = DropGuard(self);
            drop(node);
            mem::forget(guard);
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        if self.len == 0 {
            None
        } else {
            self.head.map(|node| unsafe {
                // Xav tau lub neej tsis xwm yeem kom tau txais 'a
                let node = &*node.as_ptr();
                self.len -= 1;
                self.head = node.next;
                &node.element
            })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.len, Some(self.len))
    }

    #[inline]
    fn last(mut self) -> Option<&'a T> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        if self.len == 0 {
            None
        } else {
            self.tail.map(|node| unsafe {
                // Xav tau lub neej tsis xwm yeem kom tau txais 'a
                let node = &*node.as_ptr();
                self.len -= 1;
                self.tail = node.prev;
                &node.element
            })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for IterMut<'a, T> {
    type Item = &'a mut T;

    #[inline]
    fn next(&mut self) -> Option<&'a mut T> {
        if self.len == 0 {
            None
        } else {
            self.head.map(|node| unsafe {
                // Xav tau lub neej tsis xwm yeem kom tau txais 'a
                let node = &mut *node.as_ptr();
                self.len -= 1;
                self.head = node.next;
                &mut node.element
            })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.len, Some(self.len))
    }

    #[inline]
    fn last(mut self) -> Option<&'a mut T> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for IterMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut T> {
        if self.len == 0 {
            None
        } else {
            self.tail.map(|node| unsafe {
                // Xav tau lub neej tsis xwm yeem kom tau txais 'a
                let node = &mut *node.as_ptr();
                self.len -= 1;
                self.tail = node.prev;
                &mut node.element
            })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IterMut<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IterMut<'_, T> {}

/// Tus foom tus tshaj ib tus `LinkedList`.
///
/// Ib lub `Cursor` zoo li tus tsim, tshwj tsis yog tias nws tuaj yeem nrhiav rov qab-thiab-los.
///
/// Cursors ib txwm so ntawm ob lub ntsiab lus hauv cov npe, thiab qhia ua txoj hauv kev sib puag ncig lub voj.
/// Txhawm rau kom haum qhov no, muaj "ghost" tsis yog khoom siv uas yields `None` nruab nrab ntawm lub taub hau thiab tw ntawm daim ntawv.
///
///
/// Thaum tsim tau, cov cim tsa tau pib thaum xub thawj ntawm daim ntawv, lossis "ghost" tsis yog-lub npe yog tias cov ntawv sau tsis muaj.
#[unstable(feature = "linked_list_cursors", issue = "58533")]
pub struct Cursor<'a, T: 'a> {
    index: usize,
    current: Option<NonNull<Node<T>>>,
    list: &'a LinkedList<T>,
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T> Clone for Cursor<'_, T> {
    fn clone(&self) -> Self {
        let Cursor { index, current, list } = *self;
        Cursor { index, current, list }
    }
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T: fmt::Debug> fmt::Debug for Cursor<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Cursor").field(&self.list).field(&self.index()).finish()
    }
}

/// Tus cursor dhau tus `LinkedList` nrog cov haujlwm ua haujlwm.
///
/// Ib lub `Cursor` zoo li tus tsim, tshwj tsis yog tias nws tuaj yeem nrhiav dawb rov qab los-thiab, thiab tuaj yeem sib pauv tau daim ntawv teev npe thaum muaj kev tawm tsam.
/// Qhov no yog vim hais tias lub neej ntawm nws cov ntawv thov qhia tau muab khi rau nws tus kheej lub neej, siv cov npe hauv qab xwb.
/// Qhov no txhais tau hais tias tus tiv thaiv tsis tuaj yeem xa tawm ntau yam hauv ib zaug.
///
/// Cursors ib txwm so ntawm ob lub ntsiab lus hauv cov npe, thiab qhia ua txoj hauv kev sib puag ncig lub voj.
/// Txhawm rau kom haum qhov no, muaj "ghost" tsis yog khoom siv uas yields `None` nruab nrab ntawm lub taub hau thiab tw ntawm daim ntawv.
///
///
#[unstable(feature = "linked_list_cursors", issue = "58533")]
pub struct CursorMut<'a, T: 'a> {
    index: usize,
    current: Option<NonNull<Node<T>>>,
    list: &'a mut LinkedList<T>,
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T: fmt::Debug> fmt::Debug for CursorMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("CursorMut").field(&self.list).field(&self.index()).finish()
    }
}

impl<'a, T> Cursor<'a, T> {
    /// Rov qab muab tus cwj mem ntsuas chaw li nyob rau hauv `LinkedList`.
    ///
    /// Qhov no rov `None` yog tias tus ntsuas tus lej tam sim no taw rau "ghost" qhov tsis yog.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn index(&self) -> Option<usize> {
        let _ = self.current?;
        Some(self.index)
    }

    /// Txav tus cursor rau lub caij txuas ntxiv ntawm `LinkedList`.
    ///
    /// Yog tias tus cursor tau taw rau "ghost" non-element ces qhov no yuav txav nws mus rau thawj lub ntsiab ntawm `LinkedList`.
    /// Yog tias nws tau taw rau lub caij kawg ntawm `LinkedList` ces qhov no yuav hloov mus rau "ghost" non-element.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_next(&mut self) {
        match self.current.take() {
            // Peb tsis muaj lub sijhawm tam sim no;tus cursor tau zaum ntawm qhov chaw pib Pib Tom ntej no yuav tsum yog tus tuav lub npe
            //
            None => {
                self.current = self.list.head;
                self.index = 0;
            }
            // Peb tau muaj qhov khoom ua ntej, yog li cia nws mus rau nws qhov tom ntej
            Some(current) => unsafe {
                self.current = current.as_ref().next;
                self.index += 1;
            },
        }
    }

    /// Tsiv tus cursor rau lub caij qub ntawm `LinkedList`.
    ///
    /// Yog tias tus cursor tau taw rau "ghost" non-element ces qhov no yuav txav nws mus rau qhov kawg ntawm `LinkedList`.
    /// Yog tias nws tau taw rau thawj lub ntsiab ntawm `LinkedList` ces qhov no yuav hloov mus rau "ghost" non-element.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_prev(&mut self) {
        match self.current.take() {
            // Tam sim no tsis muaj.Peb tau pib ntawm daim pib.Paib Tsis muaj thiab dhia mus txog qhov kawg.
            None => {
                self.current = self.list.tail;
                self.index = self.list.len().checked_sub(1).unwrap_or(0);
            }
            // Muaj ib tug prev.Tshaj tawm nws thiab mus rau qhov khoom qub dhau los.
            Some(current) => unsafe {
                self.current = current.as_ref().prev;
                self.index = self.index.checked_sub(1).unwrap_or_else(|| self.list.len());
            },
        }
    }

    /// Rov qab xa mus rau cov khoom uas tus cursor taw tes tam sim no.
    ///
    /// Qhov no rov `None` yog tias tus ntsuas tus lej tam sim no taw rau "ghost" qhov tsis yog.
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn current(&self) -> Option<&'a T> {
        unsafe { self.current.map(|current| &(*current.as_ptr()).element) }
    }

    /// Rov qab xa mus rau cov ntsiab lus tom ntej.
    ///
    /// Yog tias tus cursor tau taw rau "ghost" non-element ces qhov no rov qab rau thawj lub ntsiab ntawm `LinkedList`.
    /// Yog tias nws tau taw rau lub caij kawg ntawm `LinkedList` ces qhov no rov `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_next(&self) -> Option<&'a T> {
        unsafe {
            let next = match self.current {
                None => self.list.head,
                Some(current) => current.as_ref().next,
            };
            next.map(|next| &(*next.as_ptr()).element)
        }
    }

    /// Rov qab xa mus rau cov khoom siv yav dhau los.
    ///
    /// Yog tias tus cursor tau taw rau "ghost" tsis yog-lub caij no ces rov qab qhov kawg ntawm `LinkedList`.
    /// Yog tias nws tau taw rau thawj lub ntsiab ntawm `LinkedList` ces qhov no rov `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_prev(&self) -> Option<&'a T> {
        unsafe {
            let prev = match self.current {
                None => self.list.tail,
                Some(current) => current.as_ref().prev,
            };
            prev.map(|prev| &(*prev.as_ptr()).element)
        }
    }
}

impl<'a, T> CursorMut<'a, T> {
    /// Rov qab muab tus cwj mem ntsuas chaw li nyob rau hauv `LinkedList`.
    ///
    /// Qhov no rov `None` yog tias tus ntsuas tus lej tam sim no taw rau "ghost" qhov tsis yog.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn index(&self) -> Option<usize> {
        let _ = self.current?;
        Some(self.index)
    }

    /// Txav tus cursor rau lub caij txuas ntxiv ntawm `LinkedList`.
    ///
    /// Yog tias tus cursor tau taw rau "ghost" non-element ces qhov no yuav txav nws mus rau thawj lub ntsiab ntawm `LinkedList`.
    /// Yog tias nws tau taw rau lub caij kawg ntawm `LinkedList` ces qhov no yuav hloov mus rau "ghost" non-element.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_next(&mut self) {
        match self.current.take() {
            // Peb tsis muaj lub sijhawm tam sim no;tus cursor tau zaum ntawm qhov chaw pib Pib Tom ntej no yuav tsum yog tus tuav lub npe
            //
            None => {
                self.current = self.list.head;
                self.index = 0;
            }
            // Peb tau muaj qhov khoom ua ntej, yog li cia nws mus rau nws qhov tom ntej
            Some(current) => unsafe {
                self.current = current.as_ref().next;
                self.index += 1;
            },
        }
    }

    /// Tsiv tus cursor rau lub caij qub ntawm `LinkedList`.
    ///
    /// Yog tias tus cursor tau taw rau "ghost" non-element ces qhov no yuav txav nws mus rau qhov kawg ntawm `LinkedList`.
    /// Yog tias nws tau taw rau thawj lub ntsiab ntawm `LinkedList` ces qhov no yuav hloov mus rau "ghost" non-element.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_prev(&mut self) {
        match self.current.take() {
            // Tam sim no tsis muaj.Peb tau pib ntawm daim pib.Paib Tsis muaj thiab dhia mus txog qhov kawg.
            None => {
                self.current = self.list.tail;
                self.index = self.list.len().checked_sub(1).unwrap_or(0);
            }
            // Muaj ib tug prev.Tshaj tawm nws thiab mus rau qhov khoom qub dhau los.
            Some(current) => unsafe {
                self.current = current.as_ref().prev;
                self.index = self.index.checked_sub(1).unwrap_or_else(|| self.list.len());
            },
        }
    }

    /// Rov qab xa mus rau cov khoom uas tus cursor taw tes tam sim no.
    ///
    /// Qhov no rov `None` yog tias tus ntsuas tus lej tam sim no taw rau "ghost" qhov tsis yog.
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn current(&mut self) -> Option<&mut T> {
        unsafe { self.current.map(|current| &mut (*current.as_ptr()).element) }
    }

    /// Rov qab xa mus rau cov ntsiab lus tom ntej.
    ///
    /// Yog tias tus cursor tau taw rau "ghost" non-element ces qhov no rov qab rau thawj lub ntsiab ntawm `LinkedList`.
    /// Yog tias nws tau taw rau lub caij kawg ntawm `LinkedList` ces qhov no rov `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_next(&mut self) -> Option<&mut T> {
        unsafe {
            let next = match self.current {
                None => self.list.head,
                Some(current) => current.as_ref().next,
            };
            next.map(|next| &mut (*next.as_ptr()).element)
        }
    }

    /// Rov qab xa mus rau cov khoom siv yav dhau los.
    ///
    /// Yog tias tus cursor tau taw rau "ghost" tsis yog-lub caij no ces rov qab qhov kawg ntawm `LinkedList`.
    /// Yog tias nws tau taw rau thawj lub ntsiab ntawm `LinkedList` ces qhov no rov `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_prev(&mut self) -> Option<&mut T> {
        unsafe {
            let prev = match self.current {
                None => self.list.tail,
                Some(current) => current.as_ref().prev,
            };
            prev.map(|prev| &mut (*prev.as_ptr()).element)
        }
    }

    /// Rov qab nyeem daim ntawv uas tsuas siv tus taw tes rau tam sim no.
    ///
    /// Lub neej ntawm `Cursor` xa rov qab yog ua txhua yam rau `CursorMut`, uas txhais tau tias nws tsis tuaj yeem tawm ntawm `CursorMut` thiab tias `CursorMut` khov rau lub neej ntawm `Cursor`.
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn as_cursor(&self) -> Cursor<'_, T> {
        Cursor { list: self.list, current: self.current, index: self.index }
    }
}

// Tam sim no lub npe editing haujlwm

impl<'a, T> CursorMut<'a, T> {
    /// Tso cov khoom tshiab rau hauv `LinkedList` tom qab tam sim no ib qho.
    ///
    /// Yog tias tus cursor tau taw rau ntawm "ghost" tsis yog-lub caij ces cov khoom siv tshiab tau muab tso rau sab pem hauv ntej ntawm `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn insert_after(&mut self, item: T) {
        unsafe {
            let spliced_node = Box::leak(Box::new(Node::new(item))).into();
            let node_next = match self.current {
                None => self.list.head,
                Some(node) => node.as_ref().next,
            };
            self.list.splice_nodes(self.current, node_next, spliced_node, spliced_node, 1);
            if self.current.is_none() {
                // Tus "ghost" tsis yog lub ntsiab lus hloov tau hloov pauv.
                self.index = self.list.len;
            }
        }
    }

    /// Tso cov khoom tshiab rau hauv `LinkedList` ua ntej qhov tam sim no ib qho.
    ///
    /// Yog tias tus cursor tau taw rau ntawm "ghost" tsis yog-lub caij ces cov khoom tshiab muab tso rau tom kawg ntawm `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn insert_before(&mut self, item: T) {
        unsafe {
            let spliced_node = Box::leak(Box::new(Node::new(item))).into();
            let node_prev = match self.current {
                None => self.list.tail,
                Some(node) => node.as_ref().prev,
            };
            self.list.splice_nodes(node_prev, self.current, spliced_node, spliced_node, 1);
            self.index += 1;
        }
    }

    /// Tshem tawm cov khoom tam sim no los ntawm `LinkedList`.
    ///
    /// Lub caij uas tau muab tshem tawm yog xa rov qab, thiab lub cursor yog tsiv mus rau taw tes rau lub tom ntej no lub caij nyob rau hauv lub `LinkedList`.
    ///
    ///
    /// Yog tias tus cursor tam sim no taw rau "ghost" tsis yog-lub caij ces tsis muaj lub hauv paus tawm thiab `None` xa rov qab.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn remove_current(&mut self) -> Option<T> {
        let unlinked_node = self.current?;
        unsafe {
            self.current = unlinked_node.as_ref().next;
            self.list.unlink_node(unlinked_node);
            let unlinked_node = Box::from_raw(unlinked_node.as_ptr());
            Some(unlinked_node.element)
        }
    }

    /// Tshem tawm cov khoom tam sim no los ntawm `LinkedList` yam tsis muaj cuam tshuam nrog cov npe ntawm.
    ///
    /// Tus node uas tau muab tshem tawm tau rov qab los ua tus tshiab `LinkedList` uas muaj cov ntawm no xwb.
    /// Lub cim tsaib tau txav mus rau taw tes rau cov khoom txuas ntxiv hauv `LinkedList` tam sim no.
    ///
    /// Yog tias tus cursor tam sim no taw rau "ghost" tsis yog-lub caij ces tsis muaj lub hauv paus tawm thiab `None` xa rov qab.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn remove_current_as_list(&mut self) -> Option<LinkedList<T>> {
        let mut unlinked_node = self.current?;
        unsafe {
            self.current = unlinked_node.as_ref().next;
            self.list.unlink_node(unlinked_node);

            unlinked_node.as_mut().prev = None;
            unlinked_node.as_mut().next = None;
            Some(LinkedList {
                head: Some(unlinked_node),
                tail: Some(unlinked_node),
                len: 1,
                marker: PhantomData,
            })
        }
    }

    /// Inserts lub ntsiab los ntawm `LinkedList` X muab tom qab tam sim no ib qho.
    ///
    /// Yog tias tus ntsuas tus taw tes ntawm "ghost" tsis yog lub hauv paus tom qab ntawd ces cov khoom tshiab tau muab tso rau thaum pib ntawm `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn splice_after(&mut self, list: LinkedList<T>) {
        unsafe {
            let (splice_head, splice_tail, splice_len) = match list.detach_all_nodes() {
                Some(parts) => parts,
                _ => return,
            };
            let node_next = match self.current {
                None => self.list.head,
                Some(node) => node.as_ref().next,
            };
            self.list.splice_nodes(self.current, node_next, splice_head, splice_tail, splice_len);
            if self.current.is_none() {
                // Tus "ghost" tsis yog lub ntsiab lus hloov tau hloov pauv.
                self.index = self.list.len;
            }
        }
    }

    /// Inserts lub ntsiab ntawm qhov muab `LinkedList` ua ntej ib qho tam sim no.
    ///
    /// Yog tias tus cursor tau taw rau ntawm "ghost" tsis yog-lub caij ces cov khoom tshiab tau muab tso rau tom kawg ntawm `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn splice_before(&mut self, list: LinkedList<T>) {
        unsafe {
            let (splice_head, splice_tail, splice_len) = match list.detach_all_nodes() {
                Some(parts) => parts,
                _ => return,
            };
            let node_prev = match self.current {
                None => self.list.tail,
                Some(node) => node.as_ref().prev,
            };
            self.list.splice_nodes(node_prev, self.current, splice_head, splice_tail, splice_len);
            self.index += splice_len;
        }
    }

    /// Sib faib cov npe ua ob zaug tom qab lub khoom tam sim no.
    /// Qhov no yuav rov qab ua cov npe tshiab uas muaj txhua yam tom qab daim ntawv kab ntsig, nrog rau cov npe sau cia txhua yam ua ntej.
    ///
    ///
    /// Yog tias tus cursor tau taw rau ntawm "ghost" tsis yog khoom siv ces cov ntsiab lus ntawm `LinkedList` hloov chaw.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn split_after(&mut self) -> LinkedList<T> {
        let split_off_idx = if self.index == self.list.len { 0 } else { self.index + 1 };
        if self.index == self.list.len {
            // Tus "ghost" tsis yog lub ntsiab lus tau hloov mus rau 0.
            self.index = 0;
        }
        unsafe { self.list.split_off_after_node(self.current, split_off_idx) }
    }

    /// Sib faib cov npe ua ob zaug ua ntej cov khoom tam sim no.
    /// Qhov no yuav rov qab ua cov npe tshiab uas muaj txhua yam ua ntej tus cursor, nrog rau cov npe thawj ua txhua yam tom qab.
    ///
    ///
    /// Yog tias tus cursor tau taw rau ntawm "ghost" tsis yog khoom siv ces cov ntsiab lus ntawm `LinkedList` hloov chaw.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn split_before(&mut self) -> LinkedList<T> {
        let split_off_idx = self.index;
        self.index = 0;
        unsafe { self.list.split_off_before_node(self.current, split_off_idx) }
    }
}

/// Tus tsim cov tsim tawm los ntawm kev hu rau `drain_filter` ntawm LinkedList.
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub struct DrainFilter<'a, T: 'a, F: 'a>
where
    F: FnMut(&mut T) -> bool,
{
    list: &'a mut LinkedList<T>,
    it: Option<NonNull<Node<T>>>,
    pred: F,
    idx: usize,
    old_len: usize,
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F> Iterator for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        while let Some(mut node) = self.it {
            unsafe {
                self.it = node.as_ref().next;
                self.idx += 1;

                if (self.pred)(&mut node.as_mut().element) {
                    // `unlink_node` tsis ua li cas nrog kev rov hais lus `element`.
                    self.list.unlink_node(node);
                    return Some(Box::from_raw(node.as_ptr()).element);
                }
            }
        }

        None
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F> Drop for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T, F>(&'r mut DrainFilter<'a, T, F>)
        where
            F: FnMut(&mut T) -> bool;

        impl<'r, 'a, T, F> Drop for DropGuard<'r, 'a, T, F>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                self.0.for_each(drop);
            }
        }

        while let Some(item) = self.next() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T: fmt::Debug, F> fmt::Debug for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DrainFilter").field(&self.list).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.list.pop_front()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.list.len, Some(self.list.len))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.list.pop_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for LinkedList<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Self {
        let mut list = Self::new();
        list.extend(iter);
        list
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for LinkedList<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Kov daim ntawv mus rau hauv ib qho iterator yielding ntsiab los ntawm tus nqi.
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { list: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a LinkedList<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut LinkedList<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Extend<T> for LinkedList<T> {
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, elem: T) {
        self.push_back(elem);
    }
}

impl<I: IntoIterator> SpecExtend<I> for LinkedList<I::Item> {
    default fn spec_extend(&mut self, iter: I) {
        iter.into_iter().for_each(move |elt| self.push_back(elt));
    }
}

impl<T> SpecExtend<LinkedList<T>> for LinkedList<T> {
    fn spec_extend(&mut self, ref mut other: LinkedList<T>) {
        self.append(other);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for LinkedList<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &'a T) {
        self.push_back(elem);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq> PartialEq for LinkedList<T> {
    fn eq(&self, other: &Self) -> bool {
        self.len() == other.len() && self.iter().eq(other)
    }

    fn ne(&self, other: &Self) -> bool {
        self.len() != other.len() || self.iter().ne(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq> Eq for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd> PartialOrd for LinkedList<T> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.iter().partial_cmp(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Ord for LinkedList<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.iter().cmp(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for LinkedList<T> {
    fn clone(&self) -> Self {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        let mut iter_other = other.iter();
        if self.len() > other.len() {
            self.split_off(other.len());
        }
        for (elem, elem_other) in self.iter_mut().zip(&mut iter_other) {
            elem.clone_from(elem_other);
        }
        if !iter_other.is_empty() {
            self.extend(iter_other.cloned());
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for LinkedList<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash> Hash for LinkedList<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        for elt in self {
            elt.hash(state);
        }
    }
}

// Xyuas kom meej tias `LinkedList` thiab nws tsuas yog nyeem cov cav taws xob yogarariant nyob rau hauv lawv cov hom tsis suav.
#[allow(dead_code)]
fn assert_covariance() {
    fn a<'a>(x: LinkedList<&'static str>) -> LinkedList<&'a str> {
        x
    }
    fn b<'i, 'a>(x: Iter<'i, &'static str>) -> Iter<'i, &'a str> {
        x
    }
    fn c<'a>(x: IntoIter<&'static str>) -> IntoIter<&'a str> {
        x
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Send for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for IterMut<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for IterMut<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Send for Cursor<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Sync for Cursor<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Send> Send for CursorMut<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Sync for CursorMut<'_, T> {}