//! Ob chav xaus plaub xaus ua tiav nrog lub nplhaib loj hlob tsis tuaj yeem.
//!
//! Cov kab ntawv no muaj *O*(1) amortized inserts thiab tshem tawm los ntawm ob qho kawg ntawm cov thawv.
//! Nws tseem muaj *O*(1) indexing zoo li vector.
//! Cov khoom muaj nyob hauv tsis tas yuav tsum theej tawm, thiab cov kab ntawv yuav xa tau yog tias hom khoom xa tuaj.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{repeat_with, FromIterator};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop};
use core::ops::{Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice;

use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;
use crate::vec::Vec;

#[macro_use]
mod macros;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter_mut::IterMut;

mod iter_mut;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter::Iter;

mod iter;

use self::pair_slices::PairSlices;

mod pair_slices;

use self::ring_slices::RingSlices;

mod ring_slices;

#[cfg(test)]
mod tests;

const INITIAL_CAPACITY: usize = 7; // 2 ^ 3, 1
const MINIMUM_CAPACITY: usize = 1; // 2, 1

const MAXIMUM_ZST_CAPACITY: usize = 1 << (core::mem::size_of::<usize>() * 8 - 1); // Cov peev xwm loj tshaj plaws ntawm ob

/// Ob chav xaus plaub xaus ua tiav nrog lub nplhaib loj hlob tsis tuaj yeem.
///
/// "default" kev siv ntawm hom no ua ib kab yog siv [`push_back`] ntxiv rau cov kab, thiab [`pop_front`] tshem tawm ntawm cov kab.
///
/// [`extend`] thiab [`append`] thawb mus rau sab nraub qaum hauv txoj kev no, thiab nws hla dua `VecDeque` mus rau pem hauv ntej mus rau nram qab.
///
/// Txij li `VecDeque` yog lub nplhaib tsis, nws cov ntsiab lus tsis yog qhov sib kis tau zoo hauv kev nco.
/// Yog tias koj xav nkag mus rau cov khoom ua ib thooj, xws li kev ua kom muaj txiaj ntsig zoo, koj tuaj yeem siv [`make_contiguous`].
/// Nws rotates `VecDeque` kom nws cov ntsiab lus tsis qhwv, thiab rov qab tuaj yeem hloov tau los rau cov kab tam sim no sib txuas sib txuas.
///
/// [`push_back`]: VecDeque::push_back
/// [`pop_front`]: VecDeque::pop_front
/// [`extend`]: VecDeque::extend
/// [`append`]: VecDeque::append
/// [`make_contiguous`]: VecDeque::make_contiguous
///
///
///
#[cfg_attr(not(test), rustc_diagnostic_item = "vecdeque_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct VecDeque<T> {
    // tus tw thiab taub hau yog taw tes rau cov tsis.
    // Tus Tsov tus tw ib txwm taw rau thawj ntu uas yuav nyeem tau, Lub taub hau ib txwm taw rau qhov chaw yuav tsum sau cov ntaub ntawv.
    //
    // Yog hais tias tus tw==lub taub hau tsis yog.Qhov ntev ntawm tus ntiv nplhaib tawm yog txhais tias qhov kev ncua deb ntawm ob.
    //
    tail: usize,
    head: usize,
    buf: RawVec<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for VecDeque<T> {
    fn clone(&self) -> VecDeque<T> {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        self.truncate(other.len());

        let mut iter = PairSlices::from(self, other);
        while let Some((dst, src)) = iter.next() {
            dst.clone_from_slice(&src);
        }

        if iter.has_remainder() {
            for remainder in iter.remainder() {
                self.extend(remainder.iter().cloned());
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for VecDeque<T> {
    fn drop(&mut self) {
        /// Khiav lub destructor rau tag nrho cov khoom hauv hlais thaum nws poob qis (nquag lossis thaum tsis tuaj yeem).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        let (front, back) = self.as_mut_slices();
        unsafe {
            let _back_dropper = Dropper(back);
            // siv poob rau [T]
            ptr::drop_in_place(front);
        }
        // RawVec saib xyuas kev ua haujlwm
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for VecDeque<T> {
    /// Tsim cov khoob `VecDeque<T>`.
    #[inline]
    fn default() -> VecDeque<T> {
        VecDeque::new()
    }
}

impl<T> VecDeque<T> {
    /// Marginally yooj yim dua
    #[inline]
    fn ptr(&self) -> *mut T {
        self.buf.ptr()
    }

    /// Marginally yooj yim dua
    #[inline]
    fn cap(&self) -> usize {
        if mem::size_of::<T>() == 0 {
            // Txog xoom hom loj, peb ib txwm nyob ntawm qhov muaj peev xwm tshaj plaws
            MAXIMUM_ZST_CAPACITY
        } else {
            self.buf.capacity()
        }
    }

    /// Tig ptr rau hauv ib nplais
    #[inline]
    unsafe fn buffer_as_slice(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.ptr(), self.cap()) }
    }

    /// Tig ptr rau hauv ib qho ua haujlwm nyias
    #[inline]
    unsafe fn buffer_as_mut_slice(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.ptr(), self.cap()) }
    }

    /// Tsiv ib qho tawm ntawm qhov tsis xwm yeem
    #[inline]
    unsafe fn buffer_read(&mut self, off: usize) -> T {
        unsafe { ptr::read(self.ptr().add(off)) }
    }

    /// Sau ib qho kev los mus rau hauv qhov tsis, tsiv nws.
    #[inline]
    unsafe fn buffer_write(&mut self, off: usize, value: T) {
        unsafe {
            ptr::write(self.ptr().add(off), value);
        }
    }

    /// Rov qab `true` yog tias tsis yog ntawm qhov muaj peev xwm tag nrho.
    #[inline]
    fn is_full(&self) -> bool {
        self.cap() - self.len() == 1
    }

    /// Rov qab mus rau qhov ntsuas nyob rau hauv lub hauv paus tsis rau lub muab cov ntsiab lus ntsiab lus Performance index.
    ///
    #[inline]
    fn wrap_index(&self, idx: usize) -> usize {
        wrap_index(idx, self.cap())
    }

    /// Rov qab saib qhov cim cia rau hauv lub hauv paus tsis rau qhov muab cov ntsiab lus ntsuas + ntxiv rau.
    ///
    #[inline]
    fn wrap_add(&self, idx: usize, addend: usize) -> usize {
        wrap_index(idx.wrapping_add(addend), self.cap())
    }

    /// Rov qab rau qhov ntsuas hauv qhov tsis pib rau qhov muab cov ntsiab lus ntsiab lus sib piv, tawm.
    ///
    #[inline]
    fn wrap_sub(&self, idx: usize, subtrahend: usize) -> usize {
        wrap_index(idx.wrapping_sub(subtrahend), self.cap())
    }

    /// Luam ib daim thaiv sib txuas ntawm lub cim kev cim ntev ntev los ntawm src rau dst
    #[inline]
    unsafe fn copy(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Luam ib daim thaiv sib txuas ntawm lub cim kev cim ntev ntev los ntawm src rau dst
    #[inline]
    unsafe fn copy_nonoverlapping(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy_nonoverlapping(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Luam tawm hauv lub pob uas ntim khoom ntawm lub cim xeeb ntev ntev los ntawm src rau dest.
    /// (abs(dst - src) + len) yuav tsum tsis muaj qhov loj dua cap() (Yuav tsum muaj qhov tsawg tshaj ib qho kev sib txuas ntawm thaj tsam ntawm src thiab dest).
    ///
    unsafe fn wrap_copy(&self, dst: usize, src: usize, len: usize) {
        #[allow(dead_code)]
        fn diff(a: usize, b: usize) -> usize {
            if a <= b { b - a } else { a - b }
        }
        debug_assert!(
            cmp::min(diff(dst, src), self.cap() - diff(dst, src)) + len <= self.cap(),
            "wrc dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );

        if src == dst || len == 0 {
            return;
        }

        let dst_after_src = self.wrap_sub(dst, src) < len;

        let src_pre_wrap_len = self.cap() - src;
        let dst_pre_wrap_len = self.cap() - dst;
        let src_wraps = src_pre_wrap_len < len;
        let dst_wraps = dst_pre_wrap_len < len;

        match (dst_after_src, src_wraps, dst_wraps) {
            (_, false, false) => {
                // src tsis qhwv, dst tsis qhwv
                //
                //        S.Cov.Cov.
                // 1 [_ _ A A B B C C _]
                // 2 [_ _ A A A A B B _] D.
                // .
                // .
                unsafe {
                    self.copy(dst, src, len);
                }
            }
            (false, false, true) => {
                // dst ua ntej src, src tsis qhwv, dst wraps
                //
                //
                //    S.Cov.Cov.
                // 1 [A A B B _ _ _ C C]
                // 2 [A A B B _ _ _ A A]
                // 3 [B B B B _ _ _ A A] .. D.
                //
                unsafe {
                    self.copy(dst, src, dst_pre_wrap_len);
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                }
            }
            (true, false, true) => {
                // src ua ntej dst, src tsis qhwv, dst wraps
                //
                //
                //              S.Cov.Cov.
                // 1 [C C _ _ _ A A B B]
                // 2 [B B _ _ _ A A B B]
                // 3 [B B _ _ _ A A A A] .. D.
                //
                unsafe {
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
            (false, true, false) => {
                // dst ua ntej src, src qhwv, dst tsis qhwv
                //
                //
                //    .. S.
                // 1 [C C _ _ _ A A B B]
                // 2 [C C _ _ _ B B B B]
                // 3 [C C _ _ _ B B C C] D.Cov.Cov.
                //
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                }
            }
            (true, true, false) => {
                // src ua ntej dst, src qhwv, dst tsis qhwv
                //
                //
                //    .. S.
                // 1 [A A B B _ _ _ C C]
                // 2 [A A A A _ _ _ C C]
                // 3 [C C A A _ _ _ C C] D.Cov.Cov.
                //
                unsafe {
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                    self.copy(dst, src, src_pre_wrap_len);
                }
            }
            (false, true, true) => {
                // dst ua ntej src, src qhwv, dst wraps
                //
                //
                //    Cov... S.
                // 1 [A B C D _ E F G H]
                // 2 [A B C D _ E G H H]
                // 3 [A B C D _ E G H A]
                // 4 [B C C D _ E G H A] .. D.Cov.
                //
                debug_assert!(dst_pre_wrap_len > src_pre_wrap_len);
                let delta = dst_pre_wrap_len - src_pre_wrap_len;
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, delta);
                    self.copy(0, delta, len - dst_pre_wrap_len);
                }
            }
            (true, true, true) => {
                // src ua ntej dst, src qhwv, dst wraps
                //
                //
                //    .. S.Cov.
                // 1 [A B C D _ E F G H]
                // 2 [A A B D _ E F G H]
                // 3 [H A B D _ E F G H]
                // 4 [H A B D _ E F F G]... D.
                //
                debug_assert!(src_pre_wrap_len > dst_pre_wrap_len);
                let delta = src_pre_wrap_len - dst_pre_wrap_len;
                unsafe {
                    self.copy(delta, 0, len - src_pre_wrap_len);
                    self.copy(0, self.cap() - delta, delta);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
        }
    }

    /// Frobs lub taub hau thiab tw ntu ib ncig los daws qhov tseeb uas peb nyuam qhuav kho tau.
    /// Tsis zoo vim tias nws ntseeg qub_capacity.
    #[inline]
    unsafe fn handle_capacity_increase(&mut self, old_capacity: usize) {
        let new_capacity = self.cap();

        // Txav cov ntu sib txuas ntawm cov nplhaib ntu tsis TH
        //
        //   [o o o o o o o . ]
        //    THA [o o o o o o o . . . . . . . . . ] HT
        //   [o o . o o o o o ]
        //          THB [.Cov.Cov.ooooooo.Cov.Cov.Cov.Cov.Cov.
        //          ] HT
        //   [o o o o o . o o ]
        //              HTC [o o o o o . . . . . . . . . o o ]
        //
        //
        //
        //

        if self.tail <= self.head {
            // Ib Nop
            //
        } else if self.head < old_capacity - self.tail {
            // B
            unsafe {
                self.copy_nonoverlapping(old_capacity, 0, self.head);
            }
            self.head += old_capacity;
            debug_assert!(self.head > self.tail);
        } else {
            // C
            let new_tail = new_capacity - (old_capacity - self.tail);
            unsafe {
                self.copy_nonoverlapping(new_tail, self.tail, old_capacity - self.tail);
            }
            self.tail = new_tail;
            debug_assert!(self.head < self.tail);
        }
        debug_assert!(self.head < self.cap());
        debug_assert!(self.tail < self.cap());
        debug_assert!(self.cap().count_ones() == 1);
    }
}

impl<T> VecDeque<T> {
    /// Tsim cov khoob `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::new();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> VecDeque<T> {
        VecDeque::with_capacity(INITIAL_CAPACITY)
    }

    /// Tsim cov khoob `VecDeque` nrog qhov chaw rau tsawg kawg `capacity` cov ntsiab lus.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::with_capacity(10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> VecDeque<T> {
        // Lus hauv no teb +1 txij li tus ringbuffer ib txwm tawm ib qho chaw tas
        let cap = cmp::max(capacity + 1, MINIMUM_CAPACITY + 1).next_power_of_two();
        assert!(cap > capacity, "capacity overflow");

        VecDeque { tail: 0, head: 0, buf: RawVec::with_capacity(cap) }
    }

    /// Muab cov ntawv pov thawj rau cov khoom ntawm ntu muab.
    ///
    /// Caij ntawm Performance index 0 yog rau pem hauv ntej ntawm kab.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf.get(1), Some(&4));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self, index: usize) -> Option<&T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&*self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Muab cov lus qhia uas hloov tau mus rau qhov raug ntawm tus muab ntsuas.
    ///
    /// Caij ntawm Performance index 0 yog rau pem hauv ntej ntawm kab.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// if let Some(elem) = buf.get_mut(1) {
    ///     *elem = 7;
    /// }
    ///
    /// assert_eq!(buf[1], 7);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut(&mut self, index: usize) -> Option<&mut T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&mut *self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Sib pauv cov ntsiab ntawm qhov taw qhia `i` thiab `j`.
    ///
    /// `i` thiab `j` kuj yuav sib npaug.
    ///
    /// Caij ntawm Performance index 0 yog rau pem hauv ntej ntawm kab.
    ///
    /// # Panics
    ///
    /// Panics yog tias qhov Performance index tsis ua raws li cov cai.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf, [3, 4, 5]);
    /// buf.swap(0, 2);
    /// assert_eq!(buf, [5, 4, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap(&mut self, i: usize, j: usize) {
        assert!(i < self.len());
        assert!(j < self.len());
        let ri = self.wrap_add(self.tail, i);
        let rj = self.wrap_add(self.tail, j);
        unsafe { ptr::swap(self.ptr().add(ri), self.ptr().add(rj)) }
    }

    /// Rov qab tus naj npawb ntawm cov khoom uas lub `VecDeque` tuaj yeem tuav tau yam tsis muaj kev txav tawm.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let buf: VecDeque<i32> = VecDeque::with_capacity(10);
    /// assert!(buf.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.cap() - 1
    }

    /// Qha qhov tsawg kawg nkaus muaj peev xwm rau raws nraim `additional` ntau cov ntsiab lus kom muab tso rau hauv `VecDeque` muab.
    /// Tsis muaj dab tsi yog tias lub peev xwm twb txaus lawm.
    ///
    /// Nco ntsoov tias tus neeg faib yuav muab qhov chaw sau ntau dua li nws thov.
    /// Yog li ntawd lub peev xwm tsis tuaj yeem cia siab rau qhov ua tau zoo me me.
    /// Xum [`reserve`] yog tias future kev nkag siab yuav tsum.
    ///
    /// # Panics
    ///
    /// Panics yog qhov muaj peev xwm tshiab hla `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve_exact(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    ///
    /// [`reserve`]: VecDeque::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.reserve(additional);
    }

    /// Txwv cov peev xwm yam tsawg kawg `additional` ntau cov khoom kom tau muab tso rau hauv `VecDeque` muab.
    /// Txoj kev sau khoom yuav tseg tau chaw sau ntau ntxiv kom tsis txhob tsiv tawm.
    ///
    /// # Panics
    ///
    /// Panics yog qhov muaj peev xwm tshiab hla `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .expect("capacity overflow");

        if new_cap > old_cap {
            self.buf.reserve_exact(used_cap, new_cap - used_cap);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
    }

    /// Sim khaws cia qhov tsawg kawg nkaus muaj peev xwm rau raws nraim `additional` ntau cov ntsiab yuav tsum muab tso rau hauv `VecDeque<T>` muab.
    ///
    /// Tom qab hu `try_reserve_exact`, lub peev xwm yuav loj dua lossis sib npaug rau `self.len() + additional`.
    /// Tsis muaj dab tsi yog tias lub peev xwm twb txaus lawm.
    ///
    /// Nco ntsoov tias tus neeg faib yuav muab qhov chaw sau ntau dua li nws thov.
    /// Yog li ntawd, lub peev xwm tsis tuaj yeem cia siab rau qhov yuav tsum tau muaj tsawg.
    /// Xum `reserve` yog tias future kev nkag siab yuav tsum.
    ///
    /// # Errors
    ///
    /// Yog tias lub peev xwm hla dhau `usize`, lossis tus neeg muab cov ntawv ceeb toom qhia tsis ua haujlwm, ces ib qho yuam kev rov qab.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Npaj ua ntej lub cim xeeb, tawm yog tias peb ua tsis tau
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Tam sim no peb paub qhov no tsis tuaj yeem OOM(Out-Of-Memory) li ntawm peb txoj haujlwm nyuaj
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // nyuaj heev
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.try_reserve(additional)
    }

    /// Sim khaws cov peev xwm tsawg rau `additional` ntau cov khoom kom raug tso rau hauv `VecDeque<T>` muab.
    /// Txoj kev sau khoom yuav tseg tau chaw sau ntau ntxiv kom tsis txhob tsiv tawm.
    /// Tom qab hu `try_reserve`, lub peev xwm yuav loj dua lossis sib npaug rau `self.len() + additional`.
    /// Tsis muaj dab tsi yog tias muaj peev xwm yog twb txaus.
    ///
    /// # Errors
    ///
    /// Yog tias lub peev xwm hla dhau `usize`, lossis tus neeg muab cov ntawv ceeb toom qhia tsis ua haujlwm, ces ib qho yuam kev rov qab.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Npaj ua ntej lub cim xeeb, tawm yog tias peb ua tsis tau
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Tam sim no peb paub qhov no tsis tuaj yeem OOM li ntawm peb cov ua haujlwm nyuaj
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // nyuaj heev
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .ok_or(TryReserveError::CapacityOverflow)?;

        if new_cap > old_cap {
            self.buf.try_reserve_exact(used_cap, new_cap - used_cap)?;
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
        Ok(())
    }

    /// Shrinks lub peev xwm ntawm `VecDeque` ntau li ntau tau.
    ///
    /// Nws yuav poob qis kom ze li sai tau rau qhov ntev tab sis tus neeg faib tseem yuav tseem ceeb rau `VecDeque` tias muaj chaw rau ob peb ntxiv cov khoom.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to_fit();
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn shrink_to_fit(&mut self) {
        self.shrink_to(0);
    }

    /// Shrinks lub peev xwm ntawm lub `VecDeque` nrog qis khi.
    ///
    /// Lub peev xwm yuav nyob tsawg kawg ntawm qhov ntev raws li qhov ntev thiab qhov khoom xa tuaj.
    ///
    ///
    /// Yog tias lub peev xwm tam sim no tsawg dua li qhov kev txwv qis, qhov no yog tsis muaj op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to(6);
    /// assert!(buf.capacity() >= 6);
    /// buf.shrink_to(0);
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        let min_capacity = cmp::min(min_capacity, self.capacity());
        // Peb tsis tas yuav txhawj txog ib qho txeej uas tsis yog `self.len()` thiab `self.capacity()` tuaj yeem yog `usize::MAX`.
        // Lus hauv no teb +1 li tus ringbuffer ib txwm tawm ib qhov chaw tas.
        let target_cap = cmp::max(cmp::max(min_capacity, self.len()) + 1, MINIMUM_CAPACITY + 1)
            .next_power_of_two();

        if target_cap < self.cap() {
            // Muaj peb qho kev txaus siab:
            //   Tag nrho cov ntsiab lus tawm ntawm cov kab uas xav tau Cov Ntsiab Lus yog sib kis, thiab lub taub hau tawm ntawm qhov chaw uas xav tau Cov ntsiab lus tsis sib xws, thiab tus Tsov tus tw tawm ntawm cov kab uas xav tau
            //
            //
            // Txhua lub sijhawm, cov haujlwm ua haujlwm tsis muaj kev cuam tshuam.
            //
            // Qhia tias cov khoom hauv lub taub hau yuav tsum txav mus.
            //
            let head_outside = self.head == 0 || self.head >= target_cap;
            // Txav cov khoom tawm los ntawm cov kab uas xav tau (txoj haujlwm tom qab target_cap)
            if self.tail >= target_cap && head_outside {
                // TH
                //   [. . . . . . . . o o o o o o o . ]
                //    TH
                //   [o o o o o o o . ]
                unsafe {
                    self.copy_nonoverlapping(0, self.tail, self.len());
                }
                self.head = self.len();
                self.tail = 0;
            } else if self.tail != 0 && self.tail < target_cap && head_outside {
                // TH
                //   [. . . o o o o o o o . . . . . . ]
                //        H T
                //   [o o . o o o o o ]
                let len = self.wrap_sub(self.head, target_cap);
                unsafe {
                    self.copy_nonoverlapping(0, target_cap, len);
                }
                self.head = len;
                debug_assert!(self.head < self.tail);
            } else if self.tail >= target_cap {
                // HT
                //   [o o o o o . . . . . . . . . o o ]
                //              H T
                //   [o o o o o . o o ]
                debug_assert!(self.wrap_sub(self.head, 1) < target_cap);
                let len = self.cap() - self.tail;
                let new_tail = target_cap - len;
                unsafe {
                    self.copy_nonoverlapping(new_tail, self.tail, len);
                }
                self.tail = new_tail;
                debug_assert!(self.head < self.tail);
            }

            self.buf.shrink_to_fit(target_cap);

            debug_assert!(self.head < self.cap());
            debug_assert!(self.tail < self.cap());
            debug_assert!(self.cap().count_ones() == 1);
        }
    }

    /// Ua kom luv luv lub `VecDeque`, khaws thawj `len` lub ntsiab lus thiab xa cov seem.
    ///
    ///
    /// Yog hais tias `len` yog ntau dua qhov 'VecDeque` tus tam sim no ntev, qhov no muaj tsis ntxim.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    /// buf.truncate(1);
    /// assert_eq!(buf, [5]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn truncate(&mut self, len: usize) {
        /// Khiav lub destructor rau tag nrho cov khoom hauv hlais thaum nws poob qis (nquag lossis thaum tsis tuaj yeem).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        // Muaj kev nyab xeeb vim:
        //
        // * Ib qho hlais dhau rau `drop_in_place` siv tau;rooj plaub thib ob tau `len <= front.len()` thiab rov qab los ntawm `len > self.len()` kom `begin <= back.len()` hauv thawj kis
        //
        // * Lub taub hau ntawm VecDeque tau tsiv mus ua ntej hu `drop_in_place`, yog li tsis muaj nqis nqis ob zaug yog `drop_in_place` panics
        //
        //
        unsafe {
            if len > self.len() {
                return;
            }
            let num_dropped = self.len() - len;
            let (front, back) = self.as_mut_slices();
            if len > front.len() {
                let begin = len - front.len();
                let drop_back = back.get_unchecked_mut(begin..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);
                ptr::drop_in_place(drop_back);
            } else {
                let drop_back = back as *mut _;
                let drop_front = front.get_unchecked_mut(len..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);

                // Nco ntsoov tias qhov thib ob ib nrab nqis txawm tias thaum lub caij destructor hauv thawj ib panics.
                //
                let _back_dropper = Dropper(&mut *drop_back);
                ptr::drop_in_place(drop_front);
            }
        }
    }

    /// Rov qab los rau pem hauv ntej-rau-rov qab iterator.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// let b: &[_] = &[&5, &3, &4];
    /// let c: Vec<&i32> = buf.iter().collect();
    /// assert_eq!(&c[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { tail: self.tail, head: self.head, ring: unsafe { self.buffer_as_slice() } }
    }

    /// Rov qab los rau pem hauv ntej-rau-rov qab tus ntsuas rov qab uas xa rov tuaj yeem hloov tau.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// for num in buf.iter_mut() {
    ///     *num = *num - 2;
    /// }
    /// let b: &[_] = &[&mut 3, &mut 1, &mut 2];
    /// assert_eq!(&buf.iter_mut().collect::<Vec<&mut i32>>()[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        // KEV RUAJ NTSEG: Sab hauv `IterMut` qhov chaw tsis muaj xwm txheej yog tsim los vim tus
        // `ring` peb tsim yog dereferencable hlais mus tas lub neej '_.
        IterMut {
            tail: self.tail,
            head: self.head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// Rov ib tug khub ntawm slices uas muaj, nyob rau hauv kev txiav txim, tus txheem ntawm lub `VecDeque`.
    ///
    /// Yog tias [`make_contiguous`] yav dhau los hu ua, txhua lub ntsiab ntawm `VecDeque` yuav nyob hauv thawj daim thiab daim thib ob yuav tas.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    /// vector.push_back(2);
    ///
    /// assert_eq!(vector.as_slices(), (&[0, 1, 2][..], &[][..]));
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// assert_eq!(vector.as_slices(), (&[9, 10][..], &[0, 1, 2][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_slices(&self) -> (&[T], &[T]) {
        unsafe {
            let buf = self.buffer_as_slice();
            RingSlices::ring_slices(buf, self.head, self.tail)
        }
    }

    /// Rov ib tug khub ntawm slices uas muaj, nyob rau hauv kev txiav txim, tus txheem ntawm lub `VecDeque`.
    ///
    /// Yog tias [`make_contiguous`] yav dhau los hu ua, txhua lub ntsiab ntawm `VecDeque` yuav nyob hauv thawj daim thiab daim thib ob yuav tas.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// vector.as_mut_slices().0[0] = 42;
    /// vector.as_mut_slices().1[0] = 24;
    /// assert_eq!(vector.as_slices(), (&[42, 10][..], &[24, 1][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_mut_slices(&mut self) -> (&mut [T], &mut [T]) {
        unsafe {
            let head = self.head;
            let tail = self.tail;
            let buf = self.buffer_as_mut_slice();
            RingSlices::ring_slices(buf, head, tail)
        }
    }

    /// Rov qab tus naj npawb ntawm cov hauv `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert_eq!(v.len(), 0);
    /// v.push_back(1);
    /// assert_eq!(v.len(), 1);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        count(self.tail, self.head, self.cap())
    }

    /// Rov qab `true` yog `VecDeque` yog npliag.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert!(v.is_empty());
    /// v.push_front(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.tail == self.head
    }

    fn range_tail_head<R>(&self, range: R) -> (usize, usize)
    where
        R: RangeBounds<usize>,
    {
        let Range { start, end } = slice::range(range, ..self.len());
        let tail = self.wrap_add(self.tail, start);
        let head = self.wrap_add(self.tail, end);
        (tail, head)
    }

    /// Tsim cov kab xo uas npog cov kab hauv cheeb tsam `VecDeque`.
    ///
    /// # Panics
    ///
    /// Panics yog tias qhov pib pib loj tshaj qhov taw tes kawg lossis yog tias qhov xaus taw tes ntau dua qhov ntev ntawm vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let range = v.range(2..).copied().collect::<VecDeque<_>>();
    /// assert_eq!(range, [3]);
    ///
    /// // Ib daim ntau ntau npog tag nrho cov ncauj lus
    /// let all = v.range(..);
    /// assert_eq!(all.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range<R>(&self, range: R) -> Iter<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);
        Iter {
            tail,
            head,
            // Cov siv sib qhia peb muaj hauv &self yog khaws cia hauv '_ ntawm Iter.
            ring: unsafe { self.buffer_as_slice() },
        }
    }

    /// Tsim cov kab xo uas npog cov kab kev hloov pauv tshwj xeeb hauv `VecDeque`.
    ///
    /// # Panics
    ///
    /// Panics yog tias qhov pib pib loj tshaj qhov taw tes kawg lossis yog tias qhov xaus taw tes ntau dua qhov ntev ntawm vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// for v in v.range_mut(2..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![1, 2, 6]);
    ///
    /// // Ib daim ntau ntau npog tag nrho cov ncauj lus
    /// for v in v.range_mut(..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![2, 4, 12]);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range_mut<R>(&mut self, range: R) -> IterMut<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);

        // KEV RUAJ NTSEG: Sab hauv `IterMut` qhov chaw tsis muaj xwm txheej yog tsim los vim tus
        // `ring` peb tsim yog dereferencable hlais mus tas lub neej '_.
        IterMut {
            tail,
            head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// Tsim cov kav dej tawm uas tshem cov kab kev cai hauv `VecDeque` thiab yields cov khoom tshem tawm.
    ///
    /// Nco tseg 1: Lub caij thaj chaw raug tshem tawm txawm hais tias tus kav tsuas tsis haus kom txog thaum kawg.
    ///
    /// Nco ntsoov 2: Nws yog ib unspecified yuav ua li cas muaj ntau yam ntsiab raug muab tshem tawm los ntawm lub deque, yog hais tias tus `Drain` tus nqi yog tsis poob, tab sis lub qiv nws tuas tag (piv txwv li, vim `mem::forget`).
    ///
    ///
    /// # Panics
    ///
    /// Panics yog tias qhov pib pib loj tshaj qhov taw tes kawg lossis yog tias qhov xaus taw tes ntau dua qhov ntev ntawm vector.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let drained = v.drain(2..).collect::<VecDeque<_>>();
    /// assert_eq!(drained, [3]);
    /// assert_eq!(v, [1, 2]);
    ///
    /// // Ib daim ntawv qhia txog ntau yam tshem txhua yam
    /// v.drain(..);
    /// assert!(v.is_empty());
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T>
    where
        R: RangeBounds<usize>,
    {
        // Kev nyab xeeb nco
        //
        // Thaum lub Drain yog thawj zaug tsim, qhov deque los ntawm lub sijhawm luv luv kom paub tseeb tias tsis muaj kev xav tau lossis tsiv-los ntawm cov khoom tawm tau nkag mus txhua yog tias Drain lub destructor yeej tsis tau khiav.
        //
        //
        // Drain yuav ptr::read tawm qhov tseem ceeb rau tshem tawm.
        // Thaum ua tiav, cov ntaub ntawv seem yuav raug theej tawm rov qab los npog lub qhov, thiab head/tail qhov tseem ceeb yuav raug muab txig rov qab.
        //
        //
        //
        let (drain_tail, drain_head) = self.range_tail_head(range);

        // Lub deque lub ntsiab tau faib ua peb ntu:
        // * self.tail  -> drain_tail
        // * drain_tail-> drain_head
        // * drain_head-> self.head
        //
        // T= self.tail;H= self.head;t=drain_tail;h=drain_head
        //
        // Peb cia drain_tail li self.head, thiab drain_head thiab self.head li after_tail thiab after_head feem rau cov Drain.
        // Qhov no kuj tseem ua rau qhov muaj txiaj ntsig zoo xws li yog tias Drain yog qhov xau, peb tau hnov qab txog qhov hloov pauv ntawm qhov muaj txiaj ntsig tom qab pib ntawm drain.
        //
        //
        //        T H H
        // [. . . o o x x o o . . .]
        //
        //
        //
        let head = self.head;

        // "forget" hais txog cov txiaj ntsig tom qab pib drain kom txog rau thaum drain tiav thiab Drain destructor tau khiav.
        //
        self.head = drain_tail;

        Drain {
            deque: NonNull::from(&mut *self),
            after_tail: drain_head,
            after_head: head,
            iter: Iter {
                tail: drain_tail,
                head: drain_head,
                // Tseem ceeb, peb tsuas yog tsim cov ntawv qhia raug xa los ntawm `self` ntawm no thiab nyeem los ntawm nws.
                // Peb tsis sau ntawv rau `self` thiab tsis thim cov lus hais rau lwm tus siv.
                // Yog li no lub pointer nyoos peb tsim los saum toj no, rau `deque`, tseem siv tau.
                ring: unsafe { self.buffer_as_slice() },
            },
        }
    }

    /// Clears `VecDeque`, tshem tawm txhua qhov tseem ceeb.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// v.push_back(1);
    /// v.clear();
    /// assert!(v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn clear(&mut self) {
        self.truncate(0);
    }

    /// Rov `true` yog hais tias tus `VecDeque` muaj ib lub caij sib npaug mus rau lub muab tus nqi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector: VecDeque<u32> = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// assert_eq!(vector.contains(&1), true);
    /// assert_eq!(vector.contains(&10), false);
    /// ```
    #[stable(feature = "vec_deque_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        let (a, b) = self.as_slices();
        a.contains(x) || b.contains(x)
    }

    /// Muab cov khoom pov thawj rau cov khoom tom ntej, lossis `None` yog tias `VecDeque` yog qhov khoob.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.front(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        self.get(0)
    }

    /// Muab qhov siv tau hloov mus rau qhov ua ntej, lossis `None` yog tias `VecDeque` yog qhov khoob.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front_mut(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.front_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.front(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        self.get_mut(0)
    }

    /// Muab cov ntawv pov thawj rau cov khoom tom qab, lossis `None` yog tias `VecDeque` yog qhov khoob.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.back(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        self.get(self.len().wrapping_sub(1))
    }

    /// Muab qhov siv tau hloov mus rau qhov rov tom qab, lossis `None` yog tias `VecDeque` yog qhov khoob.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.back_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.back(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        self.get_mut(self.len().wrapping_sub(1))
    }

    /// Tshem tawm thawj lub ntsiab thiab xa rov tuaj, lossis `None` yog tias `VecDeque` yog qhov khoob.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_back(1);
    /// d.push_back(2);
    ///
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), Some(2));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            let tail = self.tail;
            self.tail = self.wrap_add(self.tail, 1);
            unsafe { Some(self.buffer_read(tail)) }
        }
    }

    /// Tshem tawm lub ntsiab kawg los ntawm `VecDeque` thiab rov muab nws, lossis `None` yog tias nws khoob.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.pop_back(), None);
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(buf.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            self.head = self.wrap_sub(self.head, 1);
            let head = self.head;
            unsafe { Some(self.buffer_read(head)) }
        }
    }

    /// Tshaj tawm lub hauv paus rau `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_front(1);
    /// d.push_front(2);
    /// assert_eq!(d.front(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        self.tail = self.wrap_sub(self.tail, 1);
        let tail = self.tail;
        unsafe {
            self.buffer_write(tail, value);
        }
    }

    /// Ntxig rau cov khoom nruab nrab rau sab nraum qab ntawm `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(3, *buf.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        let head = self.head;
        self.head = self.wrap_add(self.head, 1);
        unsafe { self.buffer_write(head, value) }
    }

    #[inline]
    fn is_contiguous(&self) -> bool {
        // FIXME: Puas tsim nyog peb xav `head == 0` los txhais
        // uas `self` sib kis?
        self.tail <= self.head
    }

    /// Tshem tawm qhov khoom tawm los ntawm txhua qhov chaw hauv `VecDeque` thiab rov xa rov qab, hloov nws nrog thawj lub ntsiab lus.
    ///
    ///
    /// Qhov no tsis tiv thaiv kev xaj, tab sis yog *O*(1).
    ///
    /// Rov qab `None` yog `index` tawm ntawm qhov tsis muaj ciam.
    ///
    /// Caij ntawm Performance index 0 yog rau pem hauv ntej ntawm kab.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_front(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_front(2), Some(3));
    /// assert_eq!(buf, [2, 1]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_front(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length && index != 0 {
            self.swap(index, 0);
        } else if index >= length {
            return None;
        }
        self.pop_front()
    }

    /// Tshem tawm qhov khoom tawm los ntawm txhua qhov chaw hauv `VecDeque` thiab rov xa rov qab, hloov nws nrog lub caij kawg.
    ///
    ///
    /// Qhov no tsis tiv thaiv kev xaj, tab sis yog *O*(1).
    ///
    /// Rov qab `None` yog `index` tawm ntawm qhov tsis muaj ciam.
    ///
    /// Caij ntawm Performance index 0 yog rau pem hauv ntej ntawm kab.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_back(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_back(0), Some(1));
    /// assert_eq!(buf, [3, 2]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_back(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length - 1 {
            self.swap(index, length - 1);
        } else if index >= length {
            return None;
        }
        self.pop_back()
    }

    /// Ntxig rau ib qho khoom ntawm `index` nyob rau hauv `VecDeque`, hloov tag nrho cov kab nrog qhov ntsuas loj dua lossis sib npaug rau `index` ntawm sab nraub qaum.
    ///
    ///
    /// Caij ntawm Performance index 0 yog rau pem hauv ntej ntawm kab.
    ///
    /// # Panics
    ///
    /// Panics yog tias `index` yog ntau dua `VecDeque` qhov ntev
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vec_deque = VecDeque::new();
    /// vec_deque.push_back('a');
    /// vec_deque.push_back('b');
    /// vec_deque.push_back('c');
    /// assert_eq!(vec_deque, &['a', 'b', 'c']);
    ///
    /// vec_deque.insert(1, 'd');
    /// assert_eq!(vec_deque, &['a', 'd', 'b', 'c']);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn insert(&mut self, index: usize, value: T) {
        assert!(index <= self.len(), "index out of bounds");
        if self.is_full() {
            self.grow();
        }

        // Txav mus rau qhov tsawg kawg ntawm cov khoom hauv lub nplhaib sib dhos thiab ntxig rau yam khoom raug muab
        //
        // Yuav luag txhua qhov len/2, 1 lub ntsiab lus yuav raug hloov mus. O(min(n, n-i))
        //
        // Muaj peb lub ntsiab:
        //  Hais yog sib kis
        //      - rooj plaub tshwj xeeb thaum tus Tsov tus tw yog 0 Cov ntsiab lus tsis tau ua dua thiab tus ntxig nkag rau hauv ntu ntu Tus ntsiab yog tsis cuam tshuam thiab lub tso tawm yog nyob rau hauv lub taub hau ntu.
        //
        //
        // Rau txhua tus ntawm muaj ob ntxiv:
        //  Nkag los ze zog rau tus Tsov tus tw Ntxiv ze dua rau taub hau
        //
        // Qhov tseem ceeb: H, self.head
        //      T, self.tail o, Siv tau rau lub caij I, Teeb lub cim A, Lub ntsiab lus uas yuav tsum yog tom qab kev nkag ntawm M, Qhia txog lub ntsiab tau raug rhais
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) if index == 0 => {
                // push_front
                //
                //       TIH
                //      [A oooooo.Cov.Cov.Cov.Cov.Cov.Cov.
                //      .
                //      .]
                //
                //                       HT
                //      [A o o o o o o o . . . . . I]

                self.tail = self.wrap_sub(self.tail, 1);
            }
            (true, true, _) => {
                unsafe {
                    // sib dhos, ntxig kom ze rau tus Tsov tus tw:
                    //
                    //             TIH
                    //      [. . . o o A o o o o . . . . . .]
                    //
                    //           TH
                    //      [. . o o I A o o o o . . . . . .]
                    //           M M
                    //
                    // sib dhos, ntxig kom ze rau tus Tsov tus tw thiab Tail yog 0:
                    //
                    //
                    //       TIH
                    //      [o o A o o o o . . . . . . . . .]
                    //
                    //                       HT
                    //      [o I A o o o o o . . . . . . . o]
                    //       HLI

                    let new_tail = self.wrap_sub(self.tail, 1);

                    self.copy(new_tail, self.tail, 1);
                    // Twb tau hloov tus Tsov tus tw, yog li peb tsuas luam `index - 1` cov khoom.
                    self.copy(self.tail, self.tail + 1, index - 1);

                    self.tail = new_tail;
                }
            }
            (true, false, _) => {
                unsafe {
                    // sib dhos, ntxig rau ze rau taub hau:
                    //
                    //             TIH
                    //      [. . . o o o o A o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o I A o o . . . . .]
                    //                       HLUB

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head = self.wrap_add(self.head, 1);
                }
            }
            (false, true, true) => {
                unsafe {
                    // tsis tuaj yeem, ntxig kom ze rau tus Tsov tus tw, tus tw ntu:
                    //
                    //                   HTI
                    //      [o o o o o o . . . . . o o A o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . o o I A o o]
                    //                           M M

                    self.copy(self.tail - 1, self.tail, index);
                    self.tail -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // tsis tuaj yeem, ntxig kom ze rau taub hau, tw ntu:
                    //
                    //           HTI
                    //      [o o . . . . . . . o o o o o A o]
                    //
                    //             HT
                    //      [o o o . . . . . . o o o o o I A]
                    //       MMMM

                    // luam tawm cov ntsiab lus txuas mus rau lub taub hau tshiab
                    self.copy(1, 0, self.head);

                    // luam cov ntsiab lus kawg rau hauv qhov khoob nyob hauv qab ntawm tsis
                    self.copy(0, self.cap() - 1, 1);

                    // txav cov ntsiab lus los ntawm idx los xaus rau pem hauv ntej tsis suav nrog ^ caij
                    self.copy(idx + 1, idx, self.cap() - 1 - idx);

                    self.head += 1;
                }
            }
            (false, true, false) if idx == 0 => {
                unsafe {
                    // tsis tuaj yeem, ntxig yog kom ze rau tus Tsov tus tw, lub taub hau ntu, thiab yog ntawm tus qhab nia nyob hauv qhov tsis nyob hauv:
                    //
                    //
                    //       IHT
                    //      [A o o o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [A o o o o o o o o o . . o o o I]
                    //                               HLUB

                    // luam tawm cov ntsiab lus mus rau tus Tsov tus tw tshiab
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // luam cov ntsiab lus kawg rau hauv qhov khoob nyob hauv qab ntawm tsis
                    self.copy(self.cap() - 1, 0, 1);

                    self.tail -= 1;
                }
            }
            (false, true, false) => {
                unsafe {
                    // tsis tuaj yeem, ntxig kom ze rau tus Tsov tus tw, lub taub hau ntu:
                    //
                    //             IHT
                    //      [o o o A o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o I A o o o o o o . . o o o o]
                    //       MMMMMM

                    // luam tawm cov ntsiab lus mus rau tus Tsov tus tw tshiab
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // luam cov ntsiab lus kawg rau hauv qhov khoob nyob hauv qab ntawm tsis
                    self.copy(self.cap() - 1, 0, 1);

                    // txav cov ntsiab lus los ntawm idx-1 kom xaus rau pem hauv ntej tsis suav nrog ^ khoom
                    self.copy(0, 1, idx - 1);

                    self.tail -= 1;
                }
            }
            (false, false, false) => {
                unsafe {
                    // tsis tuaj yeem, ntxig kom ze rau taub hau, ntu taub hau:
                    //
                    //               IHT
                    //      [o o o o A o o . . . . . . o o o]
                    //
                    //                     HT
                    //      [o o o o I A o o . . . . . o o o]
                    //                 HLUB

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head += 1;
                }
            }
        }

        // tus Tsov tus tw tej zaum yuav raug hloov kom yog li peb yuav tsum rov cim dua
        let new_idx = self.wrap_add(self.tail, index);
        unsafe {
            self.buffer_write(new_idx, value);
        }
    }

    /// Tshem tawm thiab rov qab cov khoom ntawm `index` los ntawm `VecDeque`.
    /// Saib qhov twg kawg los ze dua rau ntawm qhov chaw raug tshem tawm yuav raug txav mus ua chav tsev, thiab txhua qhov cuam tshuam yuav hloov mus rau txoj haujlwm tshiab.
    ///
    /// Rov qab `None` yog `index` tawm ntawm qhov tsis muaj ciam.
    ///
    /// Caij ntawm Performance index 0 yog rau pem hauv ntej ntawm kab.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.remove(1), Some(2));
    /// assert_eq!(buf, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> Option<T> {
        if self.is_empty() || self.len() <= index {
            return None;
        }

        // Muaj peb lub ntsiab:
        //  Hais yog contiguous hais yog discontiguous thiab cov kev tshem tawm yog nyob rau hauv tus Tsov tus tw seem hais yog discontiguous thiab cov kev tshem tawm yog nyob rau hauv lub taub hau seem
        //
        //      - rooj plaub tshwj xeeb thaum cov khoom sib txuas ntawm cov thev naus laus zis, tab sis self.head =0
        //
        // Rau txhua tus ntawm muaj ob ntxiv:
        //  Nkag los ze zog rau tus Tsov tus tw Ntxiv ze dua rau taub hau
        //
        // Qhov tseem ceeb: H, self.head
        //      T, self.tail o, Qhov tseem ceeb x, Element cim rau kev tshem tawm R, Qhia lub ntsiab lus uas tau muab tshem tawm M, Qhia tias lub caij tau hloov
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let elem = unsafe { Some(self.buffer_read(idx)) };

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) => {
                unsafe {
                    // sib dhos, tshem kom ze dua rau tus Tsov tus tw:
                    //
                    //             TRH
                    //      [. . . o o x o o o o . . . . . .]
                    //
                    //               TH
                    //      [. . . . o o o o o o . . . . . .]
                    //               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail += 1;
                }
            }
            (true, false, _) => {
                unsafe {
                    // sib dhos, tshem mus kom ze rau taub hau:
                    //
                    //             TRH
                    //      [. . . o o o o x o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o o o . . . . . . .]
                    //                     M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, true, true) => {
                unsafe {
                    // tsis tuaj yeem, tshem tawm kom ze dua rau tus Tsov tus tw, tus tw ntu:
                    //
                    //                   HTR
                    //      [o o o o o o . . . . . o o x o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . o o o o]
                    //                               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
            (false, false, false) => {
                unsafe {
                    // qhov tsis sib xws, tshem mus kom ze rau taub hau, ntu taub hau:
                    //
                    //               RHT
                    //      [o o o o x o o . . . . . . o o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . . o o o]
                    //               M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // qhov tsis sib xws, tshem kom ze rau taub hau, Tail seem:
                    //
                    //             HTR
                    //      [o o o . . . . . . o o o o o x o]
                    //
                    //           HT
                    //      [o o . . . . . . . o o o o o o o]
                    //       MMMM
                    //
                    // los yog quasi-discontiguous, tshem tawm tom ntej no rau lub taub hau, tus Tsov tus tw seem:
                    //
                    //       HTR
                    //      [. . . . . . . . . o o o o o x o]
                    //
                    //                         TH
                    //      [. . . . . . . . . o o o o o o .]
                    //                                   M

                    // kos duab hauv cov khoom ntu
                    self.copy(idx, idx + 1, self.cap() - idx - 1);

                    // Kev tiv thaiv txeej.
                    if self.head != 0 {
                        // luam thawj lub ntsiab rau hauv qhov khoob
                        self.copy(self.cap() - 1, 0, 1);

                        // txav cov khoom hauv taub hau ntu rov qab
                        self.copy(0, 1, self.head - 1);
                    }

                    self.head = self.wrap_sub(self.head, 1);
                }
            }
            (false, true, false) => {
                unsafe {
                    // tsis tuaj yeem, tshem tawm kom ze rau tus Tsov tus tw, lub taub hau seem:
                    //
                    //           RHT
                    //      [o o x o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o o o o o o o o o . . . . o o]
                    //       MMMMM

                    // kos nyob rau hauv cov ntsiab mus txog idx
                    self.copy(1, 0, idx);

                    // luam lub caij kawg rau hauv qhov khoob
                    self.copy(0, self.cap() - 1, 1);

                    // txav ntsiab los ntawm tus Tsov tus tw mus xaus rau pem hauv ntej, tsis suav lub xeem ib
                    self.copy(self.tail + 1, self.tail, self.cap() - self.tail - 1);

                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
        }

        elem
    }

    /// Splits lub `VecDeque` rau hauv ob tug rau lub muab index.
    ///
    /// Rov muab cov Xauv Xaj Xauv tshiab khiv.
    /// `self` muaj cov ntsiab lus `[0, at)`, thiab xa rov qab `VecDeque` muaj cov ntsiab `[at, len)`.
    ///
    /// Nco ntsoov tias lub peev xwm ntawm `self` tsis hloov.
    ///
    /// Caij ntawm Performance index 0 yog rau pem hauv ntej ntawm kab.
    ///
    /// # Panics
    ///
    /// Panics yog `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let buf2 = buf.split_off(1);
    /// assert_eq!(buf, [1]);
    /// assert_eq!(buf2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self {
        let len = self.len();
        assert!(at <= len, "`at` out of bounds");

        let other_len = len - at;
        let mut other = VecDeque::with_capacity(other_len);

        unsafe {
            let (first_half, second_half) = self.as_slices();

            let first_len = first_half.len();
            let second_len = second_half.len();
            if at < first_len {
                // `at` lus dag hauv thawj ib nrab.
                let amount_in_first = first_len - at;

                ptr::copy_nonoverlapping(first_half.as_ptr().add(at), other.ptr(), amount_in_first);

                // tsuas yog noj tag nrho ntawm lub thib ob ib nrab.
                ptr::copy_nonoverlapping(
                    second_half.as_ptr(),
                    other.ptr().add(amount_in_first),
                    second_len,
                );
            } else {
                // `at` lus dag hauv ib nrab xyoo thib ob, xav tau qhov muaj feem ntawm cov ntsiab peb hla dhau hauv thawj ib nrab.
                //
                let offset = at - first_len;
                let amount_in_second = second_len - offset;
                ptr::copy_nonoverlapping(
                    second_half.as_ptr().add(offset),
                    other.ptr(),
                    amount_in_second,
                );
            }
        }

        // Kev tu kom huv si rau thaum xaus ntawm tus buffers
        self.head = self.wrap_sub(self.head, other_len);
        other.head = other.wrap_index(other_len);

        other
    }

    /// Tsiv tag nrho cov ntsiab lus ntawm `other` rau hauv `self`, tawm hauv `other` qhov khoob.
    ///
    /// # Panics
    ///
    /// Panics yog tias cov xov tooj tshiab ntawm cov khoom siv hauv tus kheej hla ib tus `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2].into_iter().collect();
    /// let mut buf2: VecDeque<_> = vec![3, 4].into_iter().collect();
    /// buf.append(&mut buf2);
    /// assert_eq!(buf, [1, 2, 3, 4]);
    /// assert_eq!(buf2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        // naiveve impl
        self.extend(other.drain(..));
    }

    /// Cov ntsiab lus tsuas yog cov khoom uas tau teev tseg los ntawm predicate.
    ///
    /// Hauv lwm lo lus, tshem tag nrho cov ntsiab `e` xws tias `f(&e)` rov tsis raug.
    /// Qhov txheej txheem no ua haujlwm hauv chaw, mus xyuas txhua ntu ib zaug ib zaug hauv thawj daim ntawv xaj, thiab khaws cov kev txiav txim ntawm cov ntsiab lus khaws cia.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..5);
    /// buf.retain(|&x| x % 2 == 0);
    /// assert_eq!(buf, [2, 4]);
    /// ```
    ///
    /// Qhov kev txiav txim pes tsawg yuav muaj txiaj ntsig zoo rau kev taug qab cov xeev sab nraud, zoo li ntsuas.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..6);
    ///
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// buf.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(buf, [2, 3, 5]);
    /// ```
    #[stable(feature = "vec_deque_retain", since = "1.4.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let len = self.len();
        let mut del = 0;
        for i in 0..len {
            if !f(&self[i]) {
                del += 1;
            } else if del > 0 {
                self.swap(i - del, i);
            }
        }
        if del > 0 {
            self.truncate(len - del);
        }
    }

    // Qhov no tej zaum panic lossis rho me nyuam
    #[inline(never)]
    fn grow(&mut self) {
        if self.is_full() {
            let old_cap = self.cap();
            // Muab ob npaug rau tsis loj.
            self.buf.reserve_exact(old_cap, old_cap);
            assert!(self.cap() == old_cap * 2);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
            debug_assert!(!self.is_full());
        }
    }

    /// Hloov kho `VecDeque`-hauv-chaw kom `len()` yog sib npaug rau `new_len`, tog twg los ntawm tshem cov khoom ntxiv los ntawm sab nraub qaum lossis los ntawm cov ntsiab lus txuas ntxiv uas tsim los ntawm kev hu `generator` rau sab nraum qab.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize_with(5, Default::default);
    /// assert_eq!(buf, [5, 10, 15, 0, 0]);
    ///
    /// buf.resize_with(2, || unreachable!());
    /// assert_eq!(buf, [5, 10]);
    ///
    /// let mut state = 100;
    /// buf.resize_with(5, || { state += 1; state });
    /// assert_eq!(buf, [5, 10, 101, 102, 103]);
    /// ```
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with(&mut self, new_len: usize, generator: impl FnMut() -> T) {
        let len = self.len();

        if new_len > len {
            self.extend(repeat_with(generator).take(new_len - len))
        } else {
            self.truncate(new_len);
        }
    }

    /// Rearranges sab hauv cia ntawm no deque yog li nws yog ib qho kev sib kis, uas tom qab ntawd xa rov qab.
    ///
    /// Txoj kev no tsis faib thiab tsis hloov pauv qhov kev txiav txim ntawm cov khoom tso.Raws li nws rov tig hlais ib qho hloov tau, qhov no tuaj yeem siv los kho lub deque.
    ///
    /// Thaum cov khoom muab sab hauv yog sib kis, [`as_slices`] thiab [`as_mut_slices`] txoj kev yuav xa rov qab tag nrho cov ntsiab lus ntawm `VecDeque` hauv ib qho kev hlais.
    ///
    ///
    /// [`as_slices`]: VecDeque::as_slices
    /// [`as_mut_slices`]: VecDeque::as_mut_slices
    ///
    /// # Examples
    ///
    /// Tshawb cov ntsiab lus ntawm deque.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// // sorting rau deque
    /// buf.make_contiguous().sort();
    /// assert_eq!(buf.as_slices(), (&[1, 2, 3] as &[_], &[] as &[_]));
    ///
    /// // txheeb nws txoj kev ua pev
    /// buf.make_contiguous().sort_by(|a, b| b.cmp(a));
    /// assert_eq!(buf.as_slices(), (&[3, 2, 1] as &[_], &[] as &[_]));
    /// ```
    ///
    /// Tau txais kev nkag mus rau cov ntu sib kis.
    ///
    /// ```rust
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// buf.make_contiguous();
    /// if let (slice, &[]) = buf.as_slices() {
    ///     // tam sim no peb tuaj yeem paub tseeb tias `slice` muaj tag nrho cov ntsiab lus ntawm deque, thaum tseem muaj kev nkag mus tsis tau rau `buf`.
    /////
    ///     assert_eq!(buf.len(), slice.len());
    ///     assert_eq!(slice, &[3, 2, 1] as &[_]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "deque_make_contiguous", since = "1.48.0")]
    pub fn make_contiguous(&mut self) -> &mut [T] {
        if self.is_contiguous() {
            let tail = self.tail;
            let head = self.head;
            return unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 };
        }

        let buf = self.buf.ptr();
        let cap = self.cap();
        let len = self.len();

        let free = self.tail - self.head;
        let tail_len = cap - self.tail;

        if free >= tail_len {
            // muaj chaw txaus txaus los theej tus Tsov tus tw hauv ib qho mus, qhov no txhais tau tias peb xub hloov lub taub hau rov qab, thiab tom qab ntawd luam tus Tsov tus tw mus rau qhov tseeb.
            //
            //
            // los ntawm: DEFGH .... ABC
            // rau: ABCDEFGH ....
            //
            unsafe {
                ptr::copy(buf, buf.add(tail_len), self.head);
                // ...DEFGH.ABC
                ptr::copy_nonoverlapping(buf.add(self.tail), buf, tail_len);
                // ABCDEFGH....

                self.tail = 0;
                self.head = len;
            }
        } else if free > self.head {
            // FIXME: Tam sim no peb tsis xav txog .... ABCDEFGH
            // yuav tsum sib cav vim tias `head` yuav `0` nyob rau hauv no.
            // Thaum peb tej zaum xav hloov qhov no nws tsis tseem ceeb raws li ob peb qhov chaw cia siab tias `is_contiguous` txhais tau tias peb tuaj yeem cia li siv `buf[tail..head]`.
            //
            //

            // muaj chaw txaus txaus los theej lub taub hau hauv ib qho mus, qhov no txhais tau tias peb xub hloov tus Tsov tus tw forwards, thiab tom qab ntawd luam lub taub hau rau qhov tseeb.
            //
            //
            // los ntawm: FGH .... ABCDE
            // rau: ... ABCDEFGH.
            //
            unsafe {
                ptr::copy(buf.add(self.tail), buf.add(self.head), tail_len);
                // FGHABCDE....
                ptr::copy_nonoverlapping(buf, buf.add(self.head + tail_len), self.head);
                // ...ABCDEFGH.

                self.tail = self.head;
                self.head = self.wrap_add(self.tail, len);
            }
        } else {
            // dawb yog me dua li ob lub taub hau thiab tus tw, qhov no txhais tau tias peb yuav tsum maj mam "swap" tus Tsov tus tw thiab taub hau.
            //
            //
            // los ntawm: EFGHI ... ABCD lossis HIJK.ABCDEFG
            // mus rau: ABCDEFGHI ... los yog ABCDEFGHIJK.
            let mut left_edge: usize = 0;
            let mut right_edge: usize = self.tail;
            unsafe {
                // Cov teeb meem dav dav zoo li no GHIJKLM ... ABCDEF, ua ntej txhua qhov sib hloov ABCDEFM ... GHIJKL, tom qab 1 hla kev hloov hauv ABCDEFGHIJM ... KL, sib pauv kom txog rau sab laug edge mus txog rau lub tsev muag khoom temp
                //                  - ces pib dua lub algorithm nrog ib tug tshiab (smaller) khw Tej zaum cov temp cia yog mus txog thaum txoj cai edge yog nyob rau thaum xaus ntawm lub tsis, qhov no txhais tau tias peb twb ntaus txoj cai kev txiav txim nrog tsawg swaps!
                //
                // E.g
                // EF..ABCD ABCDEF .., tom qab plaub leeg tsuas pauv peb tau tiav
                //
                //
                //
                //
                //
                while left_edge < len && right_edge != cap {
                    let mut right_offset = 0;
                    for i in left_edge..right_edge {
                        right_offset = (i - left_edge) % (cap - right_edge);
                        let src: isize = (right_edge + right_offset) as isize;
                        ptr::swap(buf.add(i), buf.offset(src));
                    }
                    let n_ops = right_edge - left_edge;
                    left_edge += n_ops;
                    right_edge += right_offset + 1;
                }

                self.tail = 0;
                self.head = len;
            }
        }

        let tail = self.tail;
        let head = self.head;
        unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 }
    }

    /// Rotates cov kab ob npaug xaus `mid` chaw rau sab laug.
    ///
    /// Equivalently,
    /// - Tig yam khoom `mid` rau hauv thawj txoj haujlwm.
    /// - Pops thawj `mid` khoom thiab thawb mus rau thaum kawg.
    /// - Rot `len() - mid` chaw rau sab xis.
    ///
    /// # Panics
    ///
    /// Yog `mid` loj dua `len()`.
    /// Nco ntsoov tias `mid == len()` puas _not_ panic thiab yog qhov tsis muaj op.
    ///
    /// # Complexity
    ///
    /// Siv sijhawm `*O*(min(mid, len() - mid))` lub sijhawm thiab tsis muaj chaw seem.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_left(3);
    /// assert_eq!(buf, [3, 4, 5, 6, 7, 8, 9, 0, 1, 2]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(i * 3 % 10, buf[0]);
    ///     buf.rotate_left(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        if mid <= k {
            unsafe { self.rotate_left_inner(mid) }
        } else {
            unsafe { self.rotate_right_inner(k) }
        }
    }

    /// Rotates cov kab ob npaug xaus `k` chaw rau sab xis.
    ///
    /// Equivalently,
    /// - Tig thawj qhov khoom ua ntej rau hauv txoj haujlwm `k`.
    /// - Pops `k` cov khoom kawg thiab thawb mus rau sab xub ntiag.
    /// - Rot `len() - k` chaw rau sab laug.
    ///
    /// # Panics
    ///
    /// Yog `k` loj dua `len()`.
    /// Nco ntsoov tias `k == len()` puas _not_ panic thiab yog qhov tsis muaj op.
    ///
    /// # Complexity
    ///
    /// Siv sijhawm `*O*(min(k, len() - k))` lub sijhawm thiab tsis muaj chaw seem.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_right(3);
    /// assert_eq!(buf, [7, 8, 9, 0, 1, 2, 3, 4, 5, 6]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(0, buf[i * 3 % 10]);
    ///     buf.rotate_right(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        if k <= mid {
            unsafe { self.rotate_right_inner(k) }
        } else {
            unsafe { self.rotate_left_inner(mid) }
        }
    }

    // KEV RUAJ NTSEG: ob txoj hauv kev hauv qab no yuav tsum kom ntau npaum li cas ntawm kev sib hloov
    // yuav tsawg dua li ib nrab ntawm qhov ntev ntawm deque.
    //
    // `wrap_copy` xav kom `min(x, cap() - x) + copy_len <= cap()`, tab sis tshaj `min` yeej tsis tau ntau dua li ib nrab ntawm qhov muaj peev xwm, tsis hais txog x, yog li nws muaj suab hu rau ntawm no vim peb hu nrog qee yam tsawg dua li ib nrab ntawm qhov ntev, uas tsis yog ib nrab siab tshaj qhov muaj peev xwm.
    //
    //
    //

    unsafe fn rotate_left_inner(&mut self, mid: usize) {
        debug_assert!(mid * 2 <= self.len());
        unsafe {
            self.wrap_copy(self.head, self.tail, mid);
        }
        self.head = self.wrap_add(self.head, mid);
        self.tail = self.wrap_add(self.tail, mid);
    }

    unsafe fn rotate_right_inner(&mut self, k: usize) {
        debug_assert!(k * 2 <= self.len());
        self.head = self.wrap_sub(self.head, k);
        self.tail = self.wrap_sub(self.tail, k);
        unsafe {
            self.wrap_copy(self.tail, self.head, k);
        }
    }

    /// Binary tshawb tshawb qhov txheeb cais `VecDeque` rau cov khoom tseem ceeb.
    ///
    /// Yog tias pom tus nqi ces [`Result::Ok`] xa rov qab, uas muaj cov ntsuas ntawm cov khoom txuam.
    /// Yog tias muaj ntau qhov sib luag, tom qab ntawd ib qho ntawm cov ntais ntawv yuav raug xa rov qab.
    /// Yog hais tias tus nqi tsis tau pom ces [`Result::Err`] xa rov qab, muaj cov khoom ntsuas uas qhov khoom sib piv tau muab tso thaum tswj qhov kev txiav txim txheeb.
    ///
    ///
    /// # Examples
    ///
    /// Zoo li hauv plaub ntu.
    /// Thawj qhov yog pom, nrog rau qhov kev txiav txim siab tsis xws dua;qhov thib ob thiab peb tsis pom;cov plaub yuav phim txhua txoj hauj lwm nyob rau hauv `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search(&13),  Ok(9));
    /// assert_eq!(deque.binary_search(&4),   Err(7));
    /// assert_eq!(deque.binary_search(&100), Err(13));
    /// let r = deque.binary_search(&1);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    /// Yog tias koj xav ntxig ib qho khoom rau X sorted `VecDeque`, thaum tswj kev txiav txim kom muaj:
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let mut deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    /// let num = 42;
    /// let idx = deque.binary_search(&num).unwrap_or_else(|x| x);
    /// deque.insert(idx, num);
    /// assert_eq!(deque, &[0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|e| e.cmp(x))
    }

    /// Binary tshawb cov tshawb no `VecDeque` nrog kev sib piv cov haujlwm.
    ///
    /// Kev sib piv ua haujlwm yuav tsum siv cov kev txiav txim uas muaj feem nrog qhov kev txiav txim ntawm cov hauv qab `VecDeque`, rov qab cov txheej txheem xaj uas qhia seb nws qhov kev sib cav yog `Less`, `Equal` lossis `Greater` dua li lub hom phiaj.
    ///
    ///
    /// Yog tias pom tus nqi ces [`Result::Ok`] xa rov qab, uas muaj cov ntsuas ntawm cov khoom txuam.Yog tias muaj ntau qhov sib luag, tom qab ntawd ib qho ntawm cov ntais ntawv yuav raug xa rov qab.
    /// Yog hais tias tus nqi tsis tau pom ces [`Result::Err`] xa rov qab, muaj cov khoom ntsuas uas qhov khoom sib piv tau muab tso thaum tswj qhov kev txiav txim txheeb.
    ///
    /// # Examples
    ///
    /// Zoo li hauv plaub ntu.Thawj qhov yog pom, nrog rau qhov kev txiav txim siab tsis xws dua;qhov thib ob thiab peb tsis pom;plaub kuj tuaj yeem phim rau txhua txoj hauj lwm hauv `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&13)),  Ok(9));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&4)),   Err(7));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&100)), Err(13));
    /// let r = deque.binary_search_by(|x| x.cmp(&1));
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let (front, back) = self.as_slices();

        if let Some(Ordering::Less | Ordering::Equal) = back.first().map(|elem| f(elem)) {
            back.binary_search_by(f).map(|idx| idx + front.len()).map_err(|idx| idx + front.len())
        } else {
            front.binary_search_by(f)
        }
    }

    /// Binary tshawb tawm cov sorted `VecDeque` nrog qhov tseem ceeb ua haujlwm rho tawm.
    ///
    /// Xav tias cov `VecDeque` tau txheeb los ntawm tus yuam sij, piv txwv li nrog [`make_contiguous().sort_by_key()`](#method.make_contiguous) siv tib qho tseem ceeb rho tawm haujlwm.
    ///
    ///
    /// Yog tias pom tus nqi ces [`Result::Ok`] xa rov qab, uas muaj cov ntsuas ntawm cov khoom txuam.
    /// Yog tias muaj ntau qhov sib luag, tom qab ntawd ib qho ntawm cov ntais ntawv yuav raug xa rov qab.
    /// Yog hais tias tus nqi tsis tau pom ces [`Result::Err`] xa rov qab, muaj cov khoom ntsuas uas qhov khoom sib piv tau muab tso thaum tswj qhov kev txiav txim txheeb.
    ///
    /// # Examples
    ///
    /// Zoo li hauv plaub ntu hauv ib kuav ntawm cov khub txheeb los ntawm lawv cov ntsiab lus thib ob.
    /// Thawj qhov yog pom, nrog rau qhov kev txiav txim siab tsis xws dua;qhov thib ob thiab peb tsis pom;cov plaub yuav phim txhua txoj hauj lwm nyob rau hauv `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![(0, 0), (2, 1), (4, 1), (5, 1),
    ///          (3, 1), (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)].into();
    ///
    /// assert_eq!(deque.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(deque.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(deque.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = deque.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }
}

impl<T: Clone> VecDeque<T> {
    /// Modifies lub `VecDeque` nyob rau hauv-qhov chaw yog li ntawd `len()` yog sib npaug zos rau new_len, tog twg los yog tshem tshaj ntsiab los ntawm rov qab los yog los ntawm appending clones ntawm `value` rau tom qab.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize(2, 0);
    /// assert_eq!(buf, [5, 10]);
    ///
    /// buf.resize(5, 20);
    /// assert_eq!(buf, [5, 10, 20, 20, 20]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        self.resize_with(new_len, || value.clone());
    }
}

/// Rov qab mus rau qhov ntsuas nyob rau hauv lub hauv paus tsis rau lub muab cov ntsiab lus ntsiab lus Performance index.
#[inline]
fn wrap_index(index: usize, size: usize) -> usize {
    // loj ib txwm yog lub zog 2
    debug_assert!(size.is_power_of_two());
    index & (size - 1)
}

/// Laij cov naj npawb ntawm cov khoom uas tseem tshuav yuav nyeem hauv lub ntas twm twm
#[inline]
fn count(tail: usize, head: usize, size: usize) -> usize {
    // loj ib txwm yog lub zog 2
    (head.wrapping_sub(tail)) & (size - 1)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialEq> PartialEq for VecDeque<A> {
    fn eq(&self, other: &VecDeque<A>) -> bool {
        if self.len() != other.len() {
            return false;
        }
        let (sa, sb) = self.as_slices();
        let (oa, ob) = other.as_slices();
        if sa.len() == oa.len() {
            sa == oa && sb == ob
        } else if sa.len() < oa.len() {
            // Nco ntsoov faib tau rau hauv peb ntu, piv txwv: tus kheej: [a b c|d e f] lwm: [0 1 2 3|4 5] ntej=3, nruab nrab=1, [a b c] == [0 1 2]&&[d] == [3]&&[e f] == [4 5]
            //
            //
            //
            //
            let front = sa.len();
            let mid = oa.len() - front;

            let (oa_front, oa_mid) = oa.split_at(front);
            let (sb_mid, sb_back) = sb.split_at(mid);
            debug_assert_eq!(sa.len(), oa_front.len());
            debug_assert_eq!(sb_mid.len(), oa_mid.len());
            debug_assert_eq!(sb_back.len(), ob.len());
            sa == oa_front && sb_mid == oa_mid && sb_back == ob
        } else {
            let front = oa.len();
            let mid = sa.len() - front;

            let (sa_front, sa_mid) = sa.split_at(front);
            let (ob_mid, ob_back) = ob.split_at(mid);
            debug_assert_eq!(sa_front.len(), oa.len());
            debug_assert_eq!(sa_mid.len(), ob_mid.len());
            debug_assert_eq!(sb.len(), ob_back.len());
            sa_front == oa && sa_mid == ob_mid && sb == ob_back
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Eq> Eq for VecDeque<A> {}

__impl_slice_eq1! { [] VecDeque<A>, Vec<B>, }
__impl_slice_eq1! { [] VecDeque<A>, &[B], }
__impl_slice_eq1! { [] VecDeque<A>, &mut [B], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, [B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &[B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &mut [B; N], }

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialOrd> PartialOrd for VecDeque<A> {
    fn partial_cmp(&self, other: &VecDeque<A>) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Ord> Ord for VecDeque<A> {
    #[inline]
    fn cmp(&self, other: &VecDeque<A>) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Hash> Hash for VecDeque<A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        // Nws tsis tuaj yeem siv Hash::hash_slice ntawm cov nplais rov qab los ntawm as_slices txoj kev raws li lawv qhov ntev tuaj yeem sib txawv hauv lwm yam deques zoo ib yam.
        //
        //
        // Hasher tsuas yog lees paub sib txig sib luag rau tib qho kev hu xov tooj rau nws cov hau kev.
        //
        //
        self.iter().for_each(|elem| elem.hash(state));
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Index<usize> for VecDeque<A> {
    type Output = A;

    #[inline]
    fn index(&self, index: usize) -> &A {
        self.get(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> IndexMut<usize> for VecDeque<A> {
    #[inline]
    fn index_mut(&mut self, index: usize) -> &mut A {
        self.get_mut(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> FromIterator<A> for VecDeque<A> {
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> VecDeque<A> {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();
        let mut deq = VecDeque::with_capacity(lower);
        deq.extend(iterator);
        deq
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for VecDeque<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Txheeb `VecDeque` mus rau hauv pem hauv ntej-rau-rov qab tso tus kheej yielding cov ntsiab lus los ntawm cov nqi.
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a VecDeque<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut VecDeque<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Extend<A> for VecDeque<A> {
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T) {
        // Txoj haujlwm no yuav tsum yog kev coj ncaj ncees ntawm:
        //
        //      rau yam khoom nyob rau hauv iter.into_iter() {
        //          self.push_back(item);
        //      }
        let mut iter = iter.into_iter();
        while let Some(element) = iter.next() {
            if self.len() == self.capacity() {
                let (lower, _) = iter.size_hint();
                self.reserve(lower.saturating_add(1));
            }

            let head = self.head;
            self.head = self.wrap_add(self.head, 1);
            unsafe {
                self.buffer_write(head, element);
            }
        }
    }

    #[inline]
    fn extend_one(&mut self, elem: A) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for VecDeque<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &T) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for VecDeque<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<Vec<T>> for VecDeque<T> {
    /// Tig lub [`Vec<T>`] rau hauv [`VecDeque<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Qhov no zam txoj kev tsiv mus nyob qhov twg ua tau, tab sis cov xwm txheej rau qhov ntawd yog qhov nruj, thiab yuav hloov pauv, thiab yog li tsis txhob cia siab rau tshwj tsis yog tias `Vec<T>` tau los ntawm `From<VecDeque<T>>` thiab tsis tau pauv chaw.
    ///
    ///
    fn from(mut other: Vec<T>) -> Self {
        let len = other.len();
        if mem::size_of::<T>() == 0 {
            // Tsis muaj kev faib tawm rau ZSTs txhawj xeeb txog kev muaj peev xwm, tab sis `VecDeque` tsis tuaj yeem lis ntev npaum li `Vec`.
            //
            assert!(len < MAXIMUM_ZST_CAPACITY, "capacity overflow");
        } else {
            // Peb yuav tsum xaiv qhov loj me yog tias qhov peev xwm tsis yog lub zog ntawm ob, me me lossis tsis muaj tsawg kawg ib qhov chaw pub dawb.
            // Peb ua qhov no thaum nws tseem nyob hauv `Vec` yog li cov khoom yuav poob rau ntawm panic.
            //
            let min_cap = cmp::max(MINIMUM_CAPACITY, len) + 1;
            let cap = cmp::max(min_cap, other.capacity()).next_power_of_two();
            if other.capacity() != cap {
                other.reserve_exact(cap - len);
            }
        }

        unsafe {
            let (other_buf, len, capacity) = other.into_raw_parts();
            let buf = RawVec::from_raw_parts(other_buf, capacity);
            VecDeque { tail: 0, head: len, buf }
        }
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<VecDeque<T>> for Vec<T> {
    /// Tig ib [`VecDeque<T>`] rau hauv ib lub [`Vec<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Qhov no yeej tsis tas yuav rov faib dua, tab sis yuav tsum ua *O*(*n*) cov ntaub ntawv txav yog tias tsis ncig ua tsis tau tshwm sim thaum pib ntawm qhov kev faib.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// // Tus no yog *O*(1).
    /// let deque: VecDeque<_> = (1..5).collect();
    /// let ptr = deque.as_slices().0.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    ///
    /// // Qhov no ib qho yuav tsum muaj cov ntaub ntawv rov faib dua tshiab.
    /// let mut deque: VecDeque<_> = (1..5).collect();
    /// deque.push_front(9);
    /// deque.push_front(8);
    /// let ptr = deque.as_slices().1.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [8, 9, 1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    /// ```
    fn from(mut other: VecDeque<T>) -> Self {
        other.make_contiguous();

        unsafe {
            let other = ManuallyDrop::new(other);
            let buf = other.buf.ptr();
            let len = other.len();
            let cap = other.cap();

            if other.tail != 0 {
                ptr::copy(buf.add(other.tail), buf, len);
            }
            Vec::from_raw_parts(buf, len, cap)
        }
    }
}