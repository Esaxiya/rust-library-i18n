//! Ib qhov tseem ceeb tshaj plaws yog siv nrog binary heap.
//!
//! Tso tau ntxig thiab tso plhuav loj tshaj plaws muaj *O*(log(*n*)) lub sijhawm siv.
//! Txheeb xyuas cov khoom loj tshaj plaws yog *O*(1).Hloov vector mus rau binary heap tuaj yeem ua tiav rau hauv-chaw, thiab muaj *O*(*n*) cov nyom.
//! Ib qho binary heap kuj tseem tuaj yeem hloov mus rau qhov chaw txheeb vector-nyob rau hauv-chaw, kom nws siv rau ib qho *O*(*n*\*log(* n*)) hauv-qhov chaw heapsort).
//!
//! # Examples
//!
//! Nov yog qhov piv txwv loj dua uas siv [Dijkstra's algorithm][dijkstra] los daws qhov [shortest path problem][sssp] ntawm [directed graph][dir_graph].
//!
//! Nws qhia tau hais tias yuav siv [`BinaryHeap`] nrog hom kev cai.
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // Qhov tseem ceeb tshaj yog nyob ntawm `Ord`.
//! // Tshaj tawm kev siv trait yog li cov kab dhau los ua min-heap es tsis txhob muaj lub siab-heap.
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // Daim ntawv ceeb toom tias peb ntxeev cov xaj ntawm cov nqi.
//!         // Yog tias txoj hlua khi peb piv rau ntau txoj haujlwm, cov kauj ruam no yog qhov tsim nyog los ua kom muaj kev coj ua ntawm `PartialEq` thiab `Ord` xwm yeem.
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` yuav tsum muab los siv thiab.
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // Txhua lub node yog sawv cev raws li `usize`, rau kev coj ua luv luv.
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // Dijkstra's txoj kev luv tshaj plaws algorithm.
//!
//! // Pib ntawm `start` thiab siv `dist` los teev cov luv luv tam sim no rau txhua tus ntawm.Qhov kev siv no tsis muaj kev nco nco zoo npaum li qhov nws yuav tawm nem nyob rau hauv cov queue.
//! //
//! // Nws kuj tseem siv `usize::MAX` raws li tus nqi xa khoom, rau kev coj ua kom yooj yim.
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // dist [node]=qhov luv tshaj tam sim no ntawm `start` txog `node`
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // Peb nyob ntawm `start`, nrog tus nqi pes tsawg
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // Tshawb xyuas cov kab hauv av nrog cov txo nqi qis ua ntej (min-heap)
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // Xaiv tau peb tuaj yeem txuas ntxiv mus nrhiav txhua txoj kev luv tshaj plaws
//!         if position == goal { return Some(cost); }
//!
//!         // Ib qho tseem ceeb raws li peb tau twb pom txoj kev zoo dua
//!         if cost > dist[position] { continue; }
//!
//!         // Rau txhua cov node peb tuaj yeem mus txog, pom yog tias peb tuaj yeem nrhiav txoj hauv kev nrog tus nqi qis mus los ntawm cov ntawm no
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // Yog tias ntxiv, ntxiv nws mus rau cov kab hauv av thiab txuas ntxiv
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // So kom txaus, peb tau tam sim no pom txoj kev zoo dua
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // Lub hom phiaj tsis ncav cuag
//!     None
//! }
//!
//! fn main() {
//!     // Nov yog cov duab qhia qhov peb yuav siv.
//!     // Cov lej ntawm xov tooj sib raug rau cov xeev sib txawv, thiab edge tes taw hnyav li piv txwv tus nqi ntawm kev txav ntawm ib tus ntawm mus rau lwm qhov.
//!     //
//!     // Nco ntsoov tias cov npoo muaj ib-txoj kev.
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          v 1 2 |2
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10 ||
//!     //                   +---------------+
//!     //
//!     // Lub teeb yuav sawv cev ua cov chaw nyob sib xyaw uas txhua qhov ntsuas, sib thooj rau ntawm tus nqi ntawm, muaj cov npe teev tawm.
//!     // Xaiv rau nws cov efficiency.
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // Nawb 0
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // Ntawm 1
//!         vec![Edge { node: 3, cost: 2 }],
//!         // Ntawm 2
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // Nyob ntawm 3
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // Nwm 4
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// Ib qhov tseem ceeb tshaj plaws yog siv nrog binary heap.
///
/// Qhov no yuav ua qhov siab-kawg.
///
/// Nws yog cov ntawv yuam kev rau ib qho khoom yuav raug hloov kho nyob rau hauv ib txoj hauv kev uas cov khoom raug xa mus txheeb ze rau lwm yam khoom, raws li tau txiav txim los ntawm `Ord` trait, hloov pauv thaum nws nyob hauv lub heap.
///
/// Qhov no ib txwm ua tau los ntawm `Cell`, `RefCell`, lub xeev thoob ntiaj teb, I/O, lossis tus lej tsis nyab xeeb.
/// Tus cwj pwm uas ua los ntawm cov kev ua yuam kev no tsis muaj qhov cim tseg, tab sis yuav tsis ua rau kev coj ua tsis muaj kev txwv.
/// Qhov no tuaj yeem suav nrog panics, cov txiaj ntsig tsis raug, cov kev rho tawm, cim xaim, thiab qhov tsis txiav.
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // Hom kev tso cai cia peb tshem tawm qhov kos npe yam tsis meej (uas yuav yog `BinaryHeap<i32>` hauv qhov ua piv txwv).
/////
/// let mut heap = BinaryHeap::new();
///
/// // Peb tuaj yeem siv peek los saib cov nqe txuas ntxiv hauv qhov heap.
/// // Hauv qhov no, tsis muaj khoom nyob rau hauv muaj tsis tau yog li peb tau txais Tsis muaj.
/// assert_eq!(heap.peek(), None);
///
/// // Cia peb ntxiv qee cov qhab nia ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // Tam sim no peek qhia qhov khoom tseem ceeb tshaj plaws nyob hauv heap.
/// assert_eq!(heap.peek(), Some(&5));
///
/// // Peb tuaj yeem tshawb xyuas qhov ntev ntawm heap.
/// assert_eq!(heap.len(), 3);
///
/// // Peb tuaj yeem iterate dhau cov khoom hauv heap, txawm hais tias lawv tau rov qab rau hauv kev txiav txim siab random.
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // Yog tias peb hloov cov qhab nias no, lawv yuav tsum tau rov los raws seem.
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // Peb tuaj yeem tshem cov pob taws ntawm cov khoom seem.
/// heap.clear();
///
/// // Cov kab ntawv tam sim no yuav tsum khoob.
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// Tog twg los `std::cmp::Reverse` lossis kev cai `Ord` siv yuav siv tau los ua `BinaryHeap` ntawm min-heap.
/// Qhov no ua rau `heap.pop()` rov qab qhov tsawg tshaj plaws hloov tus nqi loj tshaj.
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // Qhwv cov nuj nqis hauv `Reverse`
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // Yog tias peb tau cov qhab nia tam sim no, lawv yuav tsum rov qab los rau hauv kev rov qab xaj.
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # Lub sijhawm tsis yooj yim
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// Tus nqi rau `push` yog qhov kev tsim nqi;cov qauv ntaub ntawv muab rau kev tsom xam ntau dua.
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// Tus qauv txhim kho qhwv cov lus pom hloov tau rau cov khoom loj tshaj plaws ntawm ib qho `BinaryHeap`.
///
///
/// Cov `struct` no yog tsim los ntawm [`peek_mut`] tus qauv ntawm [`BinaryHeap`].
/// Saib nws cov ntawv pov thawj ntxiv.
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // KEV RUAJ NTSEG: PeekMut tsuas yog ceev nrawm rau tsis yog qhov khoob.
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // SAFE: PeekMut tsuas yog ceev nrawm rau tsis yog qhov khoob
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // SAFE: PeekMut tsuas yog ceev nrawm rau tsis yog qhov khoob
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// Tshem tawm cov nqi peeked los ntawm heap thiab rov xa rov qab.
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// Tsim cov khoob `BinaryHeap<T>`.
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// Tsim cov khoob `BinaryHeap` ua qhov tseem ceeb-theap.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// Tsim tawm khoob `BinaryHeap` nrog kev muaj peev xwm tshwj xeeb.
    /// Qhov no npaj ua ntej lub cim xeeb txaus rau `capacity` cov ntsiab lus, kom lub `BinaryHeap` tsis tas yuav tsum tau hloov chaw kom txog rau thaum nws muaj tsawg kawg ntawm ntau qhov tseem ceeb.
    ///
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// Rov ib mutable kev siv rau tus loj tshaj yam khoom nyob rau hauv lub binary heap, los yog `None` yog hais tias nws yog tas.
    ///
    /// Note: Yog tias tus nqi `PeekMut` raug xeb, lub heap yuav nyob rau hauv lub xeev tsis sib haum.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # Lub sijhawm tsis yooj yim
    ///
    /// Yog tias cov khoom tau hloov kho tom qab qhov xwm txheej tsis zoo tshaj plaws yog lub sijhawm *O*(log(*n*)), txwv tsis pub nws yog *O*(1).
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// Tshem tawm cov khoom loj tshaj los ntawm binary heap thiab rov muab nws, lossis `None` yog tias khoob.
    ///
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # Lub sijhawm tsis yooj yim
    ///
    /// Cov teeb meem phem tshaj ntawm `pop` ntawm ib pawg uas muaj *n* cov ntsiab lus yog *O*(log(*n*)).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // KEV RUAJ NTSEG: !self.is_empty() txhais tau tias self.len()> 0
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// Thawb tawm ib qho khoom mus rau hauv binary heap.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # Lub sijhawm tsis yooj yim
    ///
    /// Tus nqi xav tau ntawm `push`, thaj tsam li txhua qhov kev txiav txim siab ntawm cov khoom tau raug thawb, thiab dhau ntawm tus naj npawb txaus pushes, yog *O*(1).
    ///
    /// Qhov no yog qhov tseem ceeb tshaj tus nqi metric thaum thawb cov khoom uas yog *tsis* twb nyob hauv ib qho qauv txheeb.
    ///
    /// Lub sijhawm ua haujlwm tsis yooj yim yog tias cov khoom thawb lub zog kom ntau thiab nce ntxiv.
    /// Hauv qhov xwm txheej phem tshaj plaws, cov khoom raug thawb hauv cov txheej txheem txiav txim siab thiab tus nqi amortized ib lub laub yog *O*(log(*n*)) tiv thaiv cov kab mob uas muaj *n* cov ntsiab lus.
    ///
    /// Qhov tsis zoo tshaj plaws tus nqi ntawm * **hu rau `push` yog* O *(* n *).Qhov teeb meem tsis zoo tshwm sim thaum lub peev xwm sab lim thiab xav tau daim ntawv resize.
    /// Tus nqi loj dua tau raug txiav tawm hauv cov nuj nqis dhau los.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // KEV RUAJ NTSEG: Vim tias peb thawb khoom tshiab nws txhais tau tias
        //  old_len= self.len(), 1 <self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    /// Consumes `BinaryHeap` thiab xa rov qab vector hauv kev txiav txim (ascending) kev txiav txim.
    ///
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // KEV RUAJ NTSEG: `end` mus ntawm `self.len() - 1` rau 1 (ob leeg suav nrog),
            //  yog li nws yog ib txwm muaj kev siv tau rau kev nkag mus.
            //  Nws muaj kev nyab xeeb rau nkag rau qhov ntsuas 0 (piv txwv li `ptr`), vim tias
            //  1 <=kawg <self.len(), uas txhais tau tias self.len()>=2.
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // KEV RUAJ NTSEG: `end` mus ntawm `self.len() - 1` rau 1 (ob leeg suav nrog) yog li:
            //  0 <1 <=kawg <= self.len(), 1 <self.len() Qhov twg txhais tau 0 <kawg thiab xaus <self.len().
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // Qhov kev coj ua ntawm sift_up thiab sift_down siv cov blocks tsis zoo kom txav ib qho khoom tawm ntawm vector (tawm tom qab lub qhov), hloov mus rau lwm tus thiab txav lub caij tshem tawm rov qab mus rau vector ntawm qhov chaw kawg ntawm lub qhov.
    //
    // `Hole` hom yog siv los sawv cev rau qhov no, thiab paub tseeb tias lub qhov ntim puv rov qab thaum kawg ntawm nws txoj kev nthuav dav, txawm nyob ntawm panic.
    // Siv lub qhov me me txo qhov tsis xwm yeem piv rau kev siv sib hloov, uas yuav koom tes ntau dua ob zaug.
    //
    //
    //
    //

    /// # Safety
    ///
    /// Tus hu tuaj yuav tsum lav tias `pos < self.len()`.
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // Coj tawm tus nqi ntawm `pos` thiab tsim lub qhov.
        // KEV RUAJ NTSEG: Tus hu tuaj yeem lav tias pos <self.len()
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // KEV RUAJ NTSEG: hole.pos()> pib>=0, uas txhais tau tias hole.pos()> 0
            //  thiab yog li hole.pos(), 1 tsis tuaj yeem nkag mus.
            //  Qhov no tuaj yeem lav tus niam txiv <hole.pos() kom nws yog qhov siv tau thiab kuj!= hole.pos().
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // KEV RUAJ NTSEG: Tib yam li saum toj no
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// Nqa cov khoom ntawm `pos` thiab txav nws hauv cov pawg, thaum nws cov me nyuam loj dua.
    ///
    ///
    /// # Safety
    ///
    /// Tus hu tuaj yuav tsum lav tias `pos < end <= self.len()`.
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // KEV RUAJ NTSEG: Tus hu tuaj yeem lav tias pos <kawg <= self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Ntxees tsis muaj: tus menyuam==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // piv nrog qhov ntau dua ntawm ob tug menyuam yaus Kev Nyab Xeeb: tus me nyuam <kawg, 1 <self.len() thiab tus menyuam + 1 <kawg <= self.len(), yog li lawv siv tau qhia txog kev ntsuas.
            //
            //  menyuam==2 *hole.pos() + 1!= hole.pos() thiab menyuam + 1==2* hole.pos() + 2!= hole.pos().
            // FIXME: 2 *hole.pos() + 1 lossis 2* hole.pos() + 2 tuaj yeem dhau yog T yog ZST
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // yog tias peb twb nyob hauv kev txiav txim, nres.
            // KEV RUAJ NTSEG: tus me nyuam tam sim no yog tus menyuam laus lossis tus menyuam qub + 1
            //  Peb twb muab pov thawj tias ob leeg yog <self.len() thiab!= hole.pos()
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // KEV RUAJ NTSEG: tib yam li saum toj no.
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // KEV RUAJ NTSEG: &&luv luv Circuit Court, uas txhais tau tias hauv
        //  ob qho xwm txheej nws tau pom tseeb tias tus menyuam==xaus, 1 <self.len().
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // KEV RUAJ NTSEG: tus me nyuam twb dhau los ua ib qho kev ntsuas tau raug thiab
            //  menyuam==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// Tus hu tuaj yuav tsum lav tias `pos < self.len()`.
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // KEV RUAJ NTSEG: pos <len yog lav los ntawm tus neeg hu thiab
        //  pom tseeb len= self.len() <= self.len().
        unsafe { self.sift_down_range(pos, len) };
    }

    /// Nqa ib qho khoom ntawm `pos` thiab txav nws txhua txoj hauv kev hauv lub pob taws, tom qab ntawd txav nws nce mus rau nws txoj haujlwm.
    ///
    ///
    /// Note: Qhov no nrawm dua thaum cov khoom paub tias yuav loj/yuav tsum tau ze rau hauv qab.
    ///
    /// # Safety
    ///
    /// Tus hu tuaj yuav tsum lav tias `pos < self.len()`.
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // KEV RUAJ NTSEG: Tus hu tuaj yeem lav tias pos <self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Ntxees tsis muaj: tus menyuam==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // KEV RUAJ NTSEG: tus me nyuam <kawg, 1 <self.len() thiab
            //  tus menyuam + 1 <kawg <= self.len(), yog li lawv siv tau qhia txog kev siv cim.
            //  menyuam==2 *hole.pos() + 1!= hole.pos() thiab menyuam + 1==2* hole.pos() + 2!= hole.pos().
            //
            // FIXME: 2 *hole.pos() + 1 lossis 2* hole.pos() + 2 tuaj yeem dhau yog T yog ZST
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // KEV RUAJ NTSEG: Tib yam li saum toj no
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // KEV RUAJ NTSEG: tus me nyuam==kawg, 1 <self.len(), yog li nws yog qhov ntsuas tau
            //  thiab menyuam==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // KEV RUAJ NTSEG: pos yog qhov chaw hauv lub qhov thiab twb tau muab pov thawj
        //  los muab qhov ntsuas siv tau.
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // KEV RUAJ NTSEG: n pib los ntawm self.len()/2 thiab nqis mus rau 0.
            //  Qhov tsuas yog thaum! (N <self.len()) yog tias self.len() ==0, tab sis nws tau txiav txim tawm los ntawm lub voj kev mob.
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// Tsiv tag nrho cov ntsiab lus ntawm `other` rau hauv `self`, tawm hauv `other` qhov khoob.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` siv O(len1 + len2) kev ua haujlwm thiab kwv yees li 2 *(len1 + len2) kev sib piv hauv qhov phem tshaj plaws thaum `extend` siv O(len2* log(len1)) kev khiav haujlwm thiab kwv yees li 1 *len2* log_2(len1) kev sib piv hauv qhov phem tshaj, suav tias yog len1>= len2.
        // Rau cov qhov loj dua, qhov hla qhov taw tes tsis ua raws li cov laj thawj no thiab tau txiav txim siab tseeb.
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// Rov qab los them tus ntsuas uas khaws cov khoom hauv heap kev txiav txim.
    /// Cov khoom ua kom tshem tawm tau muab tshem tawm los ntawm thawj qhov heap.
    /// Cov khoom seem yuav raug muab tshem tawm ntawm kev tso tawm hauv qhov kev txiav txim hauv heap.
    ///
    /// Note:
    /// * `.drain_sorted()` yog *O*(*n*\*log(* n*)); npaum li qeeb qeeb dua `.drain()`.
    ///   Koj yuav tsum siv tom kawg rau feem ntau.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // tshem tawm tag nrho cov hauv hauv heap kev txiav txim
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// Cov ntsiab lus tsuas yog cov khoom uas tau teev tseg los ntawm predicate.
    ///
    /// Hauv lwm lo lus, tshem tag nrho cov ntsiab `e` xws tias `f(&e)` rov `false`.
    /// Cov ntsiab lus yog tuaj xyuas hauv unsorted (thiab tsis hais meej) kev txiav txim.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // tsuas yog khaws cia tus lej
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// Rov qab los rau tus ntsuas hluav taws xob mus xyuas txhua qhov tseem ceeb hauv qab vector, hauv kev txiav txim siab.
    ///
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Sau 1, 2, 3, 4 hauv kev txiav txim siab
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// Rov qab los them tus ntsuas uas khaws cov khoom hauv heap kev txiav txim.
    /// Cov qauv no noj cov thawj heap.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// Xa rov qab cov khoom loj tshaj hauv binary heap, lossis `None` yog tias nws khoob.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # Lub sijhawm tsis yooj yim
    ///
    /// Nqi yog *O*(1) hauv qhov xwm txheej phem tshaj.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// Rov qab rau cov naj npawb ntawm cov khoom binary heap tuaj yeem tuav tau yam tsis muaj qhov chaw.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// Qha qhov tsawg kawg nkaus muaj peev xwm rau raws nraim `additional` ntau cov ntsiab lus kom muab tso rau hauv `BinaryHeap` muab.
    /// Tsis muaj dab tsi yog tias lub peev xwm twb txaus lawm.
    ///
    /// Nco ntsoov tias tus neeg faib yuav muab qhov chaw sau ntau dua li nws thov.
    /// Yog li ntawd lub peev xwm tsis tuaj yeem cia siab rau qhov ua tau zoo me me.
    /// Xum [`reserve`] yog tias future kev nkag siab yuav tsum.
    ///
    /// # Panics
    ///
    /// Panics yog qhov muaj peev xwm tshiab hla `usize`.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// Txwv cov peev xwm yam tsawg kawg `additional` ntau cov khoom yuav tsum tau muab tso rau hauv `BinaryHeap`.
    /// Txoj kev sau khoom yuav tseg tau chaw sau ntau ntxiv kom tsis txhob tsiv tawm.
    ///
    /// # Panics
    ///
    /// Panics yog qhov muaj peev xwm tshiab hla `usize`.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// Muab cov khoom seem pov tseg kom ntau li ntau tau.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// Pov tseg muaj peev xwm nrog cov khoom siv qis dua.
    ///
    /// Lub peev xwm yuav nyob tsawg kawg ntawm qhov ntev raws li qhov ntev thiab qhov khoom xa tuaj.
    ///
    ///
    /// Yog tias lub peev xwm tam sim no tsawg dua li qhov kev txwv qis, qhov no yog tsis muaj op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// Siv `BinaryHeap` thiab xa rov qab lub hauv paus vector nyob rau hauv kev txiav txim siab yam tsis txaus ntseeg.
    ///
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // Yuav luam tawm nyob rau hauv qee qhov kev txiav txim
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// Rov qab qhov ntev ntawm binary heap.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// Tshawb xyuas yog tias binary heap khoob.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Clears binary heap, rov ua dua ib qho ntsuas dua cov ntsiab lus raug tshem tawm.
    ///
    /// Cov ntsiab lus raug tshem tawm hauv qhov kev txiav txim siab tsis txaus siab.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// Dhuav txhua yam khoom ntawm qhov binary heap.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// Qhov sawv cev rau ib lub qhov nyob ntawm daim hlais piv txwv li, qhov ntsuas tsis muaj txiaj ntsig (vim tias nws tau txav los ntawm los yog theej tawm).
///
/// Hauv kev poob, `Hole` yuav rov ua dua daim hlais los ntawm sau lub qhov rau txoj haujlwm nrog tus nqi uas xub pib tawm.
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// Tsim tus tshiab `Hole` ntawm qhov ntsuas `pos`.
    ///
    /// Tsis zoo vim tias daim duab yuav tsum yog nyob hauv cov ntaub ntawv hlais.
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // SAFE: pos yuav tsum nyob sab hauv hlais
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// Rov qab xa cov ntawv pov thawj rau cov khoom tau muab tshem tawm.
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// Rov qab xa mus rau cov khoom hauv `index`.
    ///
    /// Tsis zoo vim tias qhov ntsuas yuav tsum nyob hauv cov ntaub ntawv hlais thiab tsis sib npaug ntawm pos.
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// Txav qhov mus rau qhov chaw nyob tshiab
    ///
    /// Tsis zoo vim tias qhov ntsuas yuav tsum nyob hauv cov ntaub ntawv hlais thiab tsis sib npaug ntawm pos.
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // sau rau lub qhov dua
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// Tus ntsuas pa hla cov khoom ntawm `BinaryHeap`.
///
/// Cov `struct` no yog tsim los ntawm [`BinaryHeap::iter()`].
/// Saib nws cov ntawv pov thawj ntxiv.
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) Tshem tawm hauv kev pom zoo ntawm `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// Tus ua tswv ntiag tug dhau cov ntsiab lus ntawm `BinaryHeap`.
///
/// Cov `struct` no yog tsim los ntawm [`BinaryHeap::into_iter()`] (muab los ntawm `IntoIterator` trait).
/// Saib nws cov ntawv pov thawj ntxiv.
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// Ua kua nqus dej txhuam dua cov ntsiab lus ntawm `BinaryHeap`.
///
/// Cov `struct` no yog tsim los ntawm [`BinaryHeap::drain()`].
/// Saib nws cov ntawv pov thawj ntxiv.
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// Ua kua nqus dej txhuam dua cov ntsiab lus ntawm `BinaryHeap`.
///
/// Cov `struct` no yog tsim los ntawm [`BinaryHeap::drain_sorted()`].
/// Saib nws cov ntawv pov thawj ntxiv.
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// Tshem tawm cov ntsiab lus hauv heap.
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// Hloov tus `Vec<T>` rau hauv `BinaryHeap<T>`.
    ///
    /// Qhov kev hloov dua siab tshiab no tshwm sim nyob rau hauv-chaw, thiab muaj lub sijhawm *O*(*n*) lub sijhawm muaj teeb meem.
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// Hloov tus `BinaryHeap<T>` rau hauv `Vec<T>`.
    ///
    /// Qhov kev hloov dua siab tshiab no tsis tas yuav tsum muaj ntaub ntawv txav lossis faib chaw, thiab muaj lub sijhawm tsis yooj yim.
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Tsim tus neeg siv khoom noj haus, uas yog, ib qho uas txav txhua tus nqi tawm ntawm lub binary heap nyob rau hauv kev txiav txim siab yam tsis txaus ntseeg.
    /// Yuav siv tsis tau cov binary heap tom qab hu rau qhov no.
    ///
    /// # Examples
    ///
    /// Kev siv theem pib:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Sau 1, 2, 3, 4 hauv kev txiav txim siab
    /// for x in heap.into_iter() {
    ///     // x muaj hom i32, tsis yog &i32
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}