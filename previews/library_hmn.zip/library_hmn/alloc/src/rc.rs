//! Ib-txog-lus-siv-suav cov kis.'Rc' sawv rau 'Reference
//! Counted'.
//!
//! Hom [`Rc<T>`][`Rc`] muab cov tswv cuab sib koom ua ke ntawm tus nqi ntawm hom `T`, faib hauv cov heap.
//! Tso [`clone`][clone] ntawm [`Rc`] tsim cov pointer tshiab rau tib qho kev faib tawm hauv cov pawg.
//! Thaum tus [`Rc`] kawg ntawm tus taw qhia rau qhov muab faib yog rhuav tshem, tus nqi khaws cia hauv qhov kev faib ntawd (feem ntau hu ua "inner value") kuj tseem nqis.
//!
//! Cov ntawv qhia kev koom ua ke hauv Rust tsis pom zoo hloov los ntawm lub neej yav dhau los, thiab [`Rc`] tsis muaj kev zam: koj tsis tuaj yeem feem ntau muab ib qho lus piav qhia nyob hauv ib qho [`Rc`].
//! Yog tias koj xav tau kev sib hloov, tso [`Cell`] lossis [`RefCell`] sab hauv [`Rc`];saib [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] siv txoj kev suav cov tsis yog atomic suav.
//! Qhov no txhais tau hais tias nyiaj siv ua haujlwm qis heev, tab sis [`Rc`] tsis tuaj yeem xa ntawm cov xov, thiab yog li [`Rc`] tsis siv [`Send`][send].
//! Raws li ib tug tshwm sim, lub Rust compiler yuav xyuas *compile lub sij hawm* tias koj tsis xa ['Rc`] s ntawm threads.
//! Yog tias koj xav tau ntau cov xov, atomic reference suav, siv [`sync::Arc`][arc].
//!
//! Txoj kev [`downgrade`][downgrade] tuaj yeem siv los tsim txoj kev tsis yog tus tswv [`Weak`] tus pointer.
//! Tus kab [`Weak`] tuaj yeem yog [`hloov kho '][txhim kho] d mus rau [`Rc`], tab sis qhov no yuav xa rov qab [`None`] yog tias tus nqi khaws cia hauv qhov kev faib tawm twb tau nqis lawm.
//! Hauv lwm lo lus, `Weak` tus taw tes tsis khaws tus nqi hauv qhov kev faib ciaj sia;Txawm li cas los, lawv *tsis* kom lub qee (lub thaub qab khw rau lub puab tus nqi) ciaj sia.
//!
//! Ib lub voj voog nyob nruab nrab ntawm [`Rc`] pointers yuav tsis raug ua haujlwm ib txwm siv.
//! Vim li no, [`Weak`] yog siv los tawg cov voj voog.
//! Piv txwv li, ib tsob ntoo tuaj yeem muaj zog [`Rc`] cov lus taw qhia los ntawm niam txiv caj rau me nyuam, thiab [`Weak`] cov lus taw qhia los ntawm cov menyuam yaus rov qab mus rau lawv niam lawv txiv.
//!
//! `Rc<T>` cia li txiav tawm rau `T` (dhau ntawm [`Deref`] trait), yog li koj tuaj yeem hu `T` cov hau kev ntawm tus nqi ntawm hom [`Rc<T>`][`Rc`].
//! Txhawm rau zam lub npe clashes nrog `T` txoj kev, cov hau kev ntawm [`Rc<T>`][`Rc`] nws tus kheej muaj feem cuam tshuam kev ua haujlwm, hu ua siv [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>Kev siv kev ua tiav ntawm traits zoo li `Clone` kuj tseem yuav raug hu ua siv cov khoom ntim uas tsim nyog.
//! Qee cov neeg nyiam siv cov ntawv uas tsim nyog ua tiav, thaum lwm tus neeg nyiam siv tus qauv-hu ua syntax.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Txoj kev-hu ua syntax
//! let rc2 = rc.clone();
//! // Tag nrho tsim nyog syntax
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] tsis pib-dereference rau `T`, vim hais tias lub puab nqi tej zaum yuav tau twb tau poob.
//!
//! # Cloning ntaub ntawv
//!
//! Tsim kev siv cov ntaub ntawv tshiab rau tib qho kev faib tawm raws li kev siv tam sim no suav cov pointer yog ua tiav siv `Clone` trait siv rau [`Rc<T>`][`Rc`] thiab [`Weak<T>`][`Weak`].
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Ob syntaxes hauv qab no yog sib npaug.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // ib tug thiab b ob taw tes rau cov tib nco qhov chaw raws li foo.
//! ```
//!
//! Cov `Rc::clone(&from)` syntax yog cov ruam tshaj plaws vim nws conveys qhia meej ntxiv cov ntsiab lus ntawm cov code.
//! Hauv qhov piv txwv saum toj no, cov syntax no ua kom pom tau yooj yim tias qhov chaws no yog tsim cov ntawv pov thawj tshiab es tsis txhob theej tag nrho cov ntsiab lus ntawm foo.
//!
//! # Examples
//!
//! Xav txog ib qho xwm txheej twg qhov txheej txheej ntawm 'Gadget`s yog tswv ntawm `Owner` X muab.
//! Peb xav kom muaj peb qhov 'Gadget' kis rau lawv `Owner`.Peb tsis tuaj yeem ua qhov no nrog cov tswv cuab tshwj xeeb, vim tias ntau dua ib lub gadget yuav yog tib qho `Owner`.
//! [`Rc`] tso cai rau peb kom muab ib qho `Owner` ntawm ntau yam ntawm 'Gadget`s, thiab muaj `Owner` nyob twj ywm kom ntev li ntev tau ib qho `Gadget` cov ntsiab lus ntawm nws.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... lwm teb
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... lwm teb
//! }
//!
//! fn main() {
//!     // Tsim kom muaj kev siv suav-suav `Owner`.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Tsim cov 'Gadget `s rau `gadget_owner`.
//!     // Cloning `Rc<Owner>` muab peb tus pointer tshiab rau tib lub `Owner` kev faib tawm, nce ntxiv kev siv suav suav hauv cov txheej txheem.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Muab pov tseg ntawm peb qhov sib txawv ntawm zos `gadget_owner`.
//!     drop(gadget_owner);
//!
//!     // Txawm hais tias poob qis dua `gadget_owner`, peb tseem muaj peev xwm luam tawm lub npe `Owner` ntawm `Gadget`s.
//!     // Qhov no yog vim peb tsuas tau tso ib qho `Rc<Owner>` nkaus xwb, tsis yog `Owner` nws taw rau.
//!     // Raws li ntev raws li muaj lwm yam `Rc<Owner>` taw nyob rau tib lub `Owner` faib, nws yuav nyob twj ywm nyob.
//!     // Daim teb qhov projection `gadget1.owner.name` ua haujlwm vim `Rc<Owner>` xa khoom rau `Owner`.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // Qhov kawg ntawm txoj haujlwm, `gadget1` thiab `gadget2` raug rhuav tshem, thiab nrog lawv suav suav cov lus kawg rau peb `Owner`.
//!     // Gadget txiv neej tam sim no puas lawm thiab.
//!     //
//! }
//! ```
//!
//! Yog tias peb cov kev xav tau hloov, thiab peb tseem xav tau los kom dhau ntawm `Owner` rau `Gadget`, peb yuav khiav teeb meem.
//! Tus [`Rc`] pointer los ntawm `Owner` rau `Gadget` qhia txog lub voj voog.
//! Qhov no txhais tau tias lawv qhov kev suav txog suav tsis tuaj yeem ncav cuag 0, thiab kev faib nyiaj yuav tsis raug rhuav tshem:
//! lub cim xeeb los.Txhawm rau kom tau txais ib puag ncig qhov no, peb tuaj yeem siv [`Weak`] cov lus qhia.
//!
//! Rust tiag tiag ua rau nws nyuaj me ntsis los tsim cov voj no ua ntej.Txhawm rau mus nrog ob qho txiaj ntsig uas taw rau ib leeg, ib qho ntawm lawv yuav tsum sib pauv.
//! Qhov no nyuaj vim tias [`Rc`] tswj kev nco txog kev nyab xeeb los ntawm tsuas yog muab cov ntawv xa mus qhia rau tus nqi nws muab, thiab cov no tsis tso cai rau kev hloov pauv ncaj qha.
//! Peb yuav tsum qhwv qhov ntawm tus nqi uas peb xav ua kom hloov mus rau hauv ib tus [`RefCell`], uas muab *sab hauv kev sib hloov*: ib txoj hauv kev kom ua tiav mutability los ntawm kev sib qhia siv.
//! [`RefCell`] tswj hwm Rust kev qiv qiv thaum lub sijhawm siv sijhawm.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... lwm teb
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... lwm teb
//! }
//!
//! fn main() {
//!     // Tsim kom muaj kev siv suav-suav `Owner`.
//!     // Nco ntsoov tias peb tau muab tso rau tus tswv ntawm lub vector ntawm `Gadget`s sab hauv `RefCell` kom peb tuaj yeem hloov nws los ntawm kev siv sib qhia.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Tsim cov 'Gadget `s rau `gadget_owner`, zoo li ua ntej.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Ntxiv rau ntawm 'Gadget`s rau lawv `Owner`.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` dynamic qiv xaus ntawm no.
//!     }
//!
//!     // Taug qab ntawm peb lub 'Gadget', luam tawm lawv cov ntsiab lus tawm.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` yog `Weak<Gadget>`.
//!         // Txij li `Weak` cov neeg taw qhia tsis tuaj yeem lav qhov kev faib tawm tseem muaj, peb yuav tsum hu rau `upgrade`, uas rov `Option<Rc<Gadget>>` X.
//!         //
//!         //
//!         // Hauv qhov no peb paub tias cov kev faib tawm tseem muaj, yog li peb tsuas yog `unwrap` tus `Option`.
//!         // Hauv cov haujlwm nyuaj dua, koj yuav xav tau kev ua txhaum tsis haum rau `None` X qhov tshwm sim.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // Thaum kawg ntawm txoj haujlwm, `gadget_owner`, `gadget1`, thiab `gadget2` pov tseg.
//!     // Muaj tam sim no tsis muaj zog (`Rc`) pointers rau lub gadgets, yog li lawv raug rhuav tshem.
//!     // Qhov no zeroes qhov kev siv suav rau ntawm Tus Neeg Cuam Tshuam, yog li nws thiaj li raug pov tseg ib yam nkaus.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Qhov no yog repr(C) rau future-cov ntaub ntawv pov thawj tiv thaiv tsis tau cov teb-reordering, uas yuav cuam tshuam nrog lwm yam kev nyab xeeb [into|from]_raw() ntawm transmutable sab hauv hom.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Ib-txog xov-siv-suav cov pointer.'Rc' sawv rau 'Reference
/// Counted'.
///
/// Saib rau [module-level documentation](./index.html) kom paub meej ntxiv.
///
/// Cov txheej txheem xam nrog ntawm `Rc` yog tag nrho cov haujlwm cuam tshuam, uas txhais tau tias koj yuav tsum hu lawv li e.g., [`Rc::get_mut(&mut value)`][get_mut] hloov `value.get_mut()`.
/// Qhov no zam kev tsis sib haum xeeb nrog cov hau kev ntawm hom sab hauv `T`.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Qhov tsis muaj teeb meem no tau tsis muaj teeb meem vim tias thaum Rc no tseem muaj txoj sia nyob peb tau lees tias qhov ntsuas ntawm sab hauv yog qhov siv tau.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Tsim dua tshiab `Rc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Muaj ib qho piv txwv tsis muaj zog ntawm tus pointer uas muaj los ntawm txhua tus muaj zog taw qhia, uas ua kom paub tseeb tias lub zog destructor tsis muaj kev faib nyiaj thaum lub zog destructor khiav, txawm tias lub pointer tsis muaj zog yog cia hauv lub zog.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Tsim tus tshiab `Rc<T>` siv qhov tsis muaj zog siv rau nws tus kheej.
    /// Sim ua kom hloov kho qhov tsis muaj zog ua ntej cov nuj nqi xa rov qab no yuav ua rau tus nqi `None`.
    ///
    /// Txawm li cas los xij, cov ntawv tsis muaj zog yuav raug cloned dawb thiab khaws cia rau siv tom qab.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... ntau daim teb
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Ua lub puab nyob rau hauv lub xeev "uninitialized" nrog ib qho tsis muaj zog siv.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Nws yog qhov tseem ceeb peb tsis txhob tso txoj kev ua tswv cuab ntawm tus pointer uas tsis muaj zog, los yog lwm yam lub cim xeeb yuav raug tso tawm thaum lub sijhawm `data_fn` rov los.
        // Yog tias peb xav hla dhau cov tswv cuab, peb tuaj yeem tsim qhov taw qhia tsis muaj zog ntxiv rau peb tus kheej, tab sis qhov no yuav ua rau muaj qhov hloov tshiab ntxiv rau cov ntaub ntawv tsis muaj zog suav uas yuav tsis tsim nyog.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Cov ntaub ntawv muaj zog yuav tsum sib koom ua ke siv tus kheej sib qhia siv tsis tau, yog li tsis txhob khiav lub destructor rau peb cov laus tsis muaj zog siv.
        //
        mem::forget(weak);
        strong
    }

    /// Ua dua tshiab `Rc` nrog cov ntsiab lus tsis tsim nyog.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Xa pib:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Ua dua tshiab `Rc` nrog cov ntsiab lus tsis tsim nyog, nrog lub cim xeeb tau sau nrog `0` bytes.
    ///
    ///
    /// Saib [`MaybeUninit::zeroed`][zeroed] piv txwv txog kev siv kom raug thiab tsis raug ntawm hom no.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Tsim kho `Rc<T>` tshiab, rov qab los ua ib qho yuam kev yog qhov kev faib tawm tsis ua tiav
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Muaj ib qho piv txwv tsis muaj zog ntawm tus pointer uas muaj los ntawm txhua tus muaj zog taw qhia, uas ua kom paub tseeb tias lub zog destructor tsis muaj kev faib nyiaj thaum lub zog destructor khiav, txawm tias lub pointer tsis muaj zog yog cia hauv lub zog.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Ua dua tshiab `Rc` nrog cov txheej txheem tsis muaj qhov cim tseg, rov ua yuam kev yog tias qhov kev faib tawm tsis ua tiav
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Xa pib:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Ua lub `Rc` tshiab nrog cov txheej txheem tsis muaj qhov cim cia, nrog lub cim xeeb tau sau nrog `0` bytes, rov ua yuam kev yog tias qhov kev faib tawm tsis
    ///
    ///
    /// Saib [`MaybeUninit::zeroed`][zeroed] piv txwv txog kev siv kom raug thiab tsis raug ntawm hom no.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Tsim dua tshiab `Pin<Rc<T>>`.
    /// Yog tias `T` tsis siv `Unpin`, ces `value` yuav pinned hauv lub cim xeeb thiab tsis tuaj yeem txav mus.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Rov qab rau sab hauv tus nqi, yog `Rc` muaj raws nraim ib qho siv muaj zog.
    ///
    /// Txwv tsis pub, ib qho [`Err`] xa rov qab nrog tib `Rc` uas tau dhau mus.
    ///
    ///
    /// Qhov no yuav ua tiav txawm tias muaj cov ntaub ntawv tsis muaj zog txaus.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // luam cov khoom uas nyob hauv

                // Qhia rau Weaks tias lawv tsis tuaj yeem raug txhawb nqa los ntawm kev ua kom poob qis ntawm cov muaj zog suav, thiab tom qab ntawd tshem tawm cov xaj xaj "strong weak" thaum uas tseem tuav cov pov thawj uas poob los ntawm kev siv cov ntaub Weak cuav.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Teeb tsa lub zog tshiab-suav cov hlais nrog cov ntsiab lus tsis txaus.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Xa pib:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Ua lub zog tshiab-suav cov hlais nrog cov ntsiab lus tsis zoo, nrog lub cim xeeb tau sau nrog `0` bytes.
    ///
    ///
    /// Saib [`MaybeUninit::zeroed`][zeroed] piv txwv txog kev siv kom raug thiab tsis raug ntawm hom no.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Hloov pauv mus rau `Rc<T>`.
    ///
    /// # Safety
    ///
    /// Ib yam li [`MaybeUninit::assume_init`], nws yog los ntawm tus neeg hu kom lav tias lub puab sab hauv tus nqi tiag tiag yog nyob rau hauv lub xeev pib.
    ///
    /// Hu rau qhov no thaum cov ntsiab lus tseem tsis tau pib siab ua rau muaj kev coj cwj pwm tsis txaus ntseeg tam sim ntawd.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Xa pib:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Hloov pauv mus rau `Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// Ib yam li [`MaybeUninit::assume_init`], nws yog los ntawm tus neeg hu kom lav tias lub puab sab hauv tus nqi tiag tiag yog nyob rau hauv lub xeev pib.
    ///
    /// Hu rau qhov no thaum cov ntsiab lus tseem tsis tau pib siab ua rau muaj kev coj cwj pwm tsis txaus ntseeg tam sim ntawd.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Xa pib:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Xaj cov `Rc`, rov qab tuaj qhwv lub pointer.
    ///
    /// Kom tsis txhob muaj ib tug cim xeeb los lub pointer yuav tsum hloov dua siab tshiab rov qab mus rau ib tug `Rc` siv [`Rc::from_raw`][from_raw].
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Muab cov poom nqaij nyoos rau cov ntaub ntawv.
    ///
    /// Cov suav tsis muaj kev cuam tshuam rau txhua txoj kev thiab `Rc` tsis siv.
    /// Tus pointer siv tau rau ntev li ntev tau muaj muaj zog suav hauv `Rc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // KEV RUAJ NTSEG: Qhov no tsis tuaj yeem mus txog Deref::deref lossis Rc::inner vim tias
        // qhov no yuav tsum khaws raw/mut qhov tseeb xws li ntawd
        // `get_mut` tuaj yeem sau los ntawm tus pointer tom qab Rc zoo tu qab los ntawm `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Ua tus `Rc<T>` los ntawm lub pointer nyoos.
    ///
    /// Lub pointer nyoos yuav tsum tau yav tas los rov qab los ntawm kev hu mus rau [`Rc<U>::into_raw`][into_raw] qhov twg `U` yuav tsum muaj qhov loj me thiab ua raws li `T`.
    /// Qhov no yog trivially muaj tseeb yog tias `U` yog `T`.
    /// Nco ntsoov tias yog `U` tsis yog `T` tab sis muaj tib qho loj thiab kev sib thooj, qhov no yeej ib txwm nyiam transmuting xa ntawm ntau hom.
    /// Saib [`mem::transmute`][transmute] rau cov lus qhia ntau ntxiv txog dab tsi txwv txiav siv nyob rau hauv cov ntaub ntawv no.
    ///
    /// Tus neeg siv ntawm `from_raw` yuav tsum ua kom muaj nuj nqi tshwj xeeb ntawm `T` tsuas yog poob qis ib zaug.
    ///
    /// Txoj haujlwm no tsis zoo vim tias kev siv tsis raug yuav ua rau lub cim xeeb tsis zoo, txawm tias `Rc<T>` rov qab los yeej tsis nkag.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Hloov rov qab mus rau ib qho `Rc` kom tsis txhob xau.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Ib qho txuas ntxiv hu rau `Rc::from_raw(x_ptr)` yuav yog qhov tsis nco qab.
    /// }
    ///
    /// // Lub cim xeeb raug tso tawm thaum `x` tawm ntawm qhov tsis muaj peev xwm saum toj, yog li `x_ptr` tam sim no dai tuag!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Rov qab qhov offset kom pom cov RcBox qub.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Tsim cov tshiab [`Weak`] pointer rau cov kev faib no.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Nco ntsoov tias peb tsis tsim txoj phuam Weak
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Tau tus xov tooj ntawm [`Weak`] pointers rau qhov no faib.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Tau cov naj npawb ntawm cov muaj zog (`Rc`) taw qhia rau cov kev faib no.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Rov qab `true` yog tias tsis muaj lwm yam `Rc` lossis [`Weak`] taw qhia rau qhov kev faib no.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Rov qab los siv cov lus qhia hloov mus rau `Rc` X muab, yog tias tsis muaj lwm yam `Rc` lossis [`Weak`] taw rau cov kev faib khoom tib yam.
    ///
    ///
    /// Rov qab [`None`] txwv tsis pub, vim tias nws tsis muaj kev nyab xeeb rau kev hloov pauv ntawm tus nqi sib koom.
    ///
    /// Kuj pom [`make_mut`][make_mut], uas yuav [`clone`][clone] tus nqi sab hauv thaum muaj lwm tus taw tes.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Rov qab los siv cov lus qhia hloov mus rau hauv `Rc` tau muab, tsis muaj daim tshev.
    ///
    /// Saib [`get_mut`], uas muaj kev nyab xeeb thiab ua cov tshev tsim nyog.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Lwm yam `Rc` lossis [`Weak`] taw tes rau qhov muab faib rau tib qho yuav tsum tsis muaj kev txiav txim rau lub sijhawm rov qab qiv.
    ///
    /// Qhov no yog tsis txaus ntseeg yog tias tsis muaj cov taw qhia nyob ntawd, piv txwv li tam sim ntawd tom qab `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Peb xyuam xim rau *tsis* tsim qhov siv suav sau rau "count" daim teb, vim qhov no yuav cuam tshuam nrog kev nkag mus rau cov lus qhia siv suav (piv txwv li
        // los ntawm `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Rov qab `true` yog tias ob lub 'Rc` taw rau tib qhov kev faib tawm (hauv cov leeg zoo li [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Ua rau siv tau kev hloov pauv mus rau qhov muab `Rc`.
    ///
    /// Yog tias muaj lwm yam `Rc` taw rau cov kev faib nyiaj qub, tom qab ntawd `make_mut` yuav [`clone`] tus nqi sab hauv rau cov kev faib tawm tshiab kom ntseeg tau cov tswv cuab zoo.
    /// Qhov no tseem hais tau ua clone-on-sau.
    ///
    /// Yog tias tsis muaj lwm yam `Rc` cov lus taw qhia rau cov kev faib no, tom qab no [`Weak`] cov neeg taw qhia rau cov kev faib tawm no yuav raug muab cais tawm.
    ///
    /// Saib [`get_mut`], uas yuav swb es tsis txhob ua cloning.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Yuav tsis clone dab tsi
    /// let mut other_data = Rc::clone(&data);    // Yuav tsis clone sab hauv cov ntaub ntawv
    /// *Rc::make_mut(&mut data) += 1;        // Clones cov ntaub ntawv sab hauv
    /// *Rc::make_mut(&mut data) += 1;        // Yuav tsis clone dab tsi
    /// *Rc::make_mut(&mut other_data) *= 2;  // Yuav tsis clone dab tsi
    ///
    /// // Tam sim no `data` thiab `other_data` taw tes rau cov kev faib khoom sib txawv.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] Cov ntsiab lus yuav raug rho tawm:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Tau clone cov ntaub ntawv, muaj lwm yam Rcs.
            // Pre-faib nco cia sau cov cloned nqi ncaj qha.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Yuav cia li nyiag cov ntaub ntawv, txhua qhov tseem tshuav yog Weaks
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Tshem tawm tsis tuaj yeem tsis muaj zog-tsis muaj zog (tsis xav tau kev sib tsoo Lub Dag Lub Zog ntawm no-peb paub lwm yam Weaks tuaj yeem ntxuav rau peb)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Qhov no unsafety yog ok vim hais tias peb nyob nraum guaranteed hais tias cov pointer rov qab yog tus *xwb* pointer uas yuav puas tau raug xa rov qab mus T.
        // Peb suav suav tau lees tias yog 1 nyob rau ntawm lub sijhawm no, thiab peb xav kom `Rc<T>` nws tus kheej yog `mut`, yog li peb rov qab tsuas yog siv tau txog kev faib tawm.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Sim downcast lub `Rc<dyn Any>` mus rau ib tug qhob hom.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Caw ib qho `RcBox<T>` nrog qhov chaw txaus rau ib qho ntxiv hauv-qhov tsis muaj nuj nqis sab hauv uas tus nqi muaj cov kev teeb tsa.
    ///
    /// Txoj haujlwm `mem_to_rcbox` yog hu nrog cov ntaub ntawv taw qhia thiab yuav tsum rov qab rov qab a (muaj feem rog)-pauv qhia rau lub `RcBox<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Laij teeb txheeb siv cov nqi muab.
        // Yav dhau los, kab lus tau muab xam rau qhov hais tawm `&*(ptr as* const RcBox<T>)`, tab sis qhov no tau tsim cov ntawv siv tsis raug (saib #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Faib ib lub `RcBox<T>` nrog qhov chaw txaus rau qhov muaj peev xwm-ntxig rau sab hauv uas tus nqi muaj cov kev teeb tsa, rov qab ua yuam kev yog qhov kev faib tsis tiav.
    ///
    ///
    /// Txoj haujlwm `mem_to_rcbox` yog hu nrog cov ntaub ntawv taw qhia thiab yuav tsum rov qab rov qab a (muaj feem rog)-pauv qhia rau lub `RcBox<T>`.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Laij teeb txheeb siv cov nqi muab.
        // Yav dhau los, kab lus tau muab xam rau qhov hais tawm `&*(ptr as* const RcBox<T>)`, tab sis qhov no tau tsim cov ntawv siv tsis raug (saib #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Faib rau ntawm kem.
        let ptr = allocate(layout)?;

        // Pib lub RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Allocates ib qho `RcBox<T>` nrog qhov chaw txaus rau qhov tsis muaj nuj nqis nyob sab hauv
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Faib rau cov `RcBox<T>` siv lub txiaj ntsig.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Luam tus nqi li bytes
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Pub dawb rau kev faib yam tsis poob nws cov ntawv
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Allocates ib qho `RcBox<[T]>` nrog qhov ntev.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Luam tawm cov ntsiab lus los ntawm hlais mus rau hauv cov nyuam qhuav tseg Rc <\[T\]>
    ///
    /// Tsis zoo vim tias tus neeg hu yuav tsum yog tus tswv cuab lossis khi `T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Ua ib qho `Rc<[T]>` los ntawm tus kav hluav taws xob uas paub tias muaj qee yam loj me.
    ///
    /// Tus cwj pwm yog undefined yuav tsum qhov luaj li cas yuav tsis ncaj ncees lawm.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Panic zov thaum cloning T ntsiab.
        // Thaum muaj panic, cov ntsiab lus uas tau muab sau rau hauv RcBox tshiab yuav raug muab tso tseg, tom qab ntawd txoj kev nco ploj.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Tus taw tes rau thawj ntu
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Txhua yam meej.Nco tus ceev xwm kom nws tsis pub dawb RcBox tshiab.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Kev Tshwj Xeeb trait siv rau `From<&[T]>`.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Dhuav cov `Rc`.
    ///
    /// Qhov no yuav ua rau kom cov suav suav daws muaj zog.
    /// Yog tias qhov kev siv muaj zog suav suav tau nce mus txog xoom ces tsuas yog lwm tus xa mus (yog tias muaj) yog [`Weak`], yog li peb `drop` tus nqi sab hauv.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Tsis luam tawm txhua yam
    /// drop(foo2);   // Luam "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // txov cov khoom nyob hauv
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // tshem tawm cov piv txwv "strong weak" tam sim no uas peb tau rhuav tshem cov ntsiab lus.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Ua ib clone ntawm `Rc` pointer.
    ///
    /// Qhov no tsim lwm tus pointer rau tib qho kev faib tawm, nce ntau zog suav suav.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Tsim tshiab `Rc<T>`, nrog `Default` tus nqi rau `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Hack kom tso cai tshwj xeeb ntawm `Eq` txawm `Eq` muaj ib txoj kev.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Peb tau ua qhov kev tshwj xeeb ntawm no, thiab tsis yog qhov zoo dua ntxiv rau ntawm `&T`, vim tias nws yuav txwv tsis pub ntxiv ib qho nqi rau txhua qhov kev sib txig sib luag ntawm cov nyiaj rov qab.
/// Peb suav hais tias `Rc`s siv rau kev khaws cov txiaj ntsig loj, uas qeeb rau clone, tab sis kuj hnyav rau kuaj xyuas kev sib luag, ua rau tus nqi no them yooj yim dua.
///
/// Nws kuj tseem muaj dua ob lub `Rc` clones, taw tes mus rau tus nqi ib yam, tshaj ob `&T`.
///
/// Peb tsuas ua qhov no thaum `T: Eq` ua `PartialEq` tej zaum yuav tsis ncaj ncees irreflexive.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Kev sib luag rau ob `Rc`s.
    ///
    /// Ob `Rc` yog qhov sib npaug yog tias lawv sab hauv muaj nuj nqis sib npaug, txawm tias lawv khaws cia hauv kev sib txawv.
    ///
    /// Yog tias `T` tseem siv tau `Eq` (cuam tshuam nrog kev hloov pauv ntawm kev sib luag), ob `Rc` uas taw rau tib cov kev faib tawm ib txwm muaj sib npaug.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Tsis sib xws rau ob `Rc`s.
    ///
    /// Ob Qhov "Rc`s tsis sib xws yog tias lawv sab hauv tsis muaj qhov sib npaug.
    ///
    /// Yog `T` tseem siv `Eq` (cuam tshuam nrog kev hloov pauv ntawm kev sib luag), ob `Rc` uas taw rau tib cov kev faib yeej tsis txawv.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Qhov sib piv ib nrab rau ob `Rc`s.
    ///
    /// Ob qho sib piv los ntawm kev hu xov tooj `partial_cmp()` ntawm lawv tus nqi sab hauv.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Tsawg dua-piv rau ob `Rc`s.
    ///
    /// Ob qho sib piv los ntawm kev hu xov tooj `<` ntawm lawv tus nqi sab hauv.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// 'Tsawg dua los sis sib npaug rau' sib piv rau ob `Rc`s.
    ///
    /// Lub ob yog muab piv los ntawm kev hu mus rau `<=` rau lawv puab qhov tseem ceeb.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Ntau dua-piv rau ob `Rc`s.
    ///
    /// Ob qho sib piv los ntawm kev hu xov tooj `>` ntawm lawv tus nqi sab hauv.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// 'Zoo tshaj los yog sib npaug rau' sib piv rau ob `Rc`s.
    ///
    /// Ob qho sib piv los ntawm kev hu xov tooj `>=` ntawm lawv tus nqi sab hauv.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Piv rau ob `Rc`s.
    ///
    /// Ob qho sib piv los ntawm kev hu xov tooj `cmp()` ntawm lawv tus nqi sab hauv.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Faib ib daim ntawv suav-suav suav thiab sau nws los ntawm cloning `v` cov khoom.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Faib ib tug siv-suav hlua hlais thiab luam `v` rau hauv nws.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Faib ib tug siv-suav hlua hlais thiab luam `v` rau hauv nws.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Txav mus rau hauv lub thawv ntawv mus rau qhov tshiab, kev siv suav daws, kev faib tawm.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Teem ib qho pov tseg-suav cov pov npav thiab txav `v` cov khoom rau hauv nws.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Tso cai rau Vec tso nws qhov kev nco, tab sis tsis rhuav tshem nws cov ntsiab lus
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Siv txhua lub caij hauv `Iterator` thiab sau nws rau hauv `Rc<[T]>`.
    ///
    /// # Cov yam ntxwv ua haujlwm
    ///
    /// ## Rooj plaub no
    ///
    /// Hauv qhov xwm txheej dav dav, sau rau hauv `Rc<[T]>` yog ua tiav los ntawm kev sau thawj zaug rau hauv `Vec<T>`.Ntawd yog, thaum sau ntawv hauv qab no:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// qhov no coj zoo li yog peb sau:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Thawj txheej kev faib tawm muaj tshwm sim ntawm no.
    ///     .into(); // Qhov thib ob kev faib nyiaj rau `Rc<[T]>` tshwm sim ntawm no.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Qhov no yuav faib ob peb zaug raws li qhov xav tau rau kev tsim lub `Vec<T>` thiab tom qab ntawd nws yuav faib nyiaj ib zaug rau tig `Vec<T>` rau hauv `Rc<[T]>`.
    ///
    ///
    /// ## Iterators ntawm paub ntev
    ///
    /// Thaum koj `Iterator` siv `TrustedLen` thiab yog qhov loj me, ib qho kev faib nyiaj yuav ua rau `Rc<[T]>`.Piv txwv li:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Tsuas yog ib txoj kev faib nyiaj muaj tshwm sim ntawm no.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Kev Tshwj Xeeb trait siv rau kev sau rau `Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Nov yog rooj plaub rau `TrustedLen` tus tuav.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // KEV RUAJ NTSEG: Peb yuav tsum xyuas kom meej tias tus ntsuas hluav taws xob muaj qhov ntev thiab peb muaj.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Poob rov qab rau kev coj ua.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` yog ib qho version ntawm [`Rc`] uas tuav qhov tsis yog tus kheej siv rau kev tswj hwm kev faib tawm.Cov nyiaj yog nkag los ntawm kev hu mus rau [`upgrade`] rau lub `Weak` pointer, uas rov ib tug ['Option`]' <'[' Rc`] '<T>> `.
///
/// Txij li thaum ib tug `Weak` siv tsis suav ntawm cov tswv cuab, nws yuav tiv thaiv tsis tau tus nqi muab cia rau hauv lub qee los poob, thiab `Weak` nws tus kheej ua rau tsis muaj guarantees txog tus nqi tseem ua tam sim no.
/// Yog li nws yuav xa rov qab [`None`] thaum [`upgrade`] d.
/// Nco ntsoov li cas los xij uas `Weak` siv *ua* tiv thaiv qhov kev faib nws tus kheej (lub khw muag khoom rov qab) los ntawm kev sib nkag siab.
///
/// Ib tus `Weak` pointer yog qhov muaj txiaj ntsig zoo rau kev khaws cia ib ntus mus rau kev faib tawm tswj hwm los ntawm [`Rc`] yam tsis muaj kev tiv thaiv nws sab hauv los ntawm kev poob qis.
/// Nws kuj tseem siv los tiv thaiv cov ntawv pov thawj ncig ntawm [`Rc`] cov lus taw qhia, txij li kev sib raug tus kheej tsis muaj cai yuav tsis tso cia [`Rc`] los tso tseg.
/// Piv txwv li, ib tsob ntoo tuaj yeem muaj zog [`Rc`] cov lus taw qhia los ntawm niam txiv caj rau me nyuam, thiab `Weak` cov lus taw qhia los ntawm cov menyuam yaus rov qab mus rau lawv niam lawv txiv.
///
/// Txoj kev uas nquag tau txais `Weak` pointer yog hu rau [`Rc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Qhov no yog `NonNull` kom tso cai rau qhov loj ntawm cov hom no hauv cov chaw enums, tab sis nws tsis tas yuav siv lub pointer siv tau.
    //
    // `Weak::new` teeb no rau `usize::MAX` kom nws tsis tas yuav faib qhov chaw ntawm qhov heap.
    // Tias'stsis muaj nqis ib lub pointer tiag tiag yuav puas tau vim tias RcBox muaj qhov sib txuam tsawg kawg 2.
    // Qhov no tsuas yog ua tau thaum `T: Sized`;unsized `T` yeej tsis dai tuag.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Ua dua tshiab `Weak<T>` tshiab, tsis muaj kev faib txhua lub cim xeeb.
    /// Hu [`upgrade`] ntawm tus nqi xa rov qab ib txwm muab [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Hom kev pab rau tus txheejtxheem qhov siv suav nrog tsis tau ua cov lus hais txog cov ntaub ntawv.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Rov qab pom lub pointer nyoos rau lub nruas `T` taw rau ntawm no `Weak<T>`.
    ///
    /// Tus taw qhia yog siv tau tsuas yog muaj qee cov ntaub ntawv muaj zog.
    /// Tus pointer tej zaum yuav dai siav, unaligned lossis txawm [`null`] txwv tsis pub.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Ob qho tib si taw rau tib qho khoom tawm
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Lub zog ntawm no ua kom nws nyob zoo, yog li peb tseem tuaj yeem nkag mus rau qhov khoom.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Tab sis tsis muaj ntau.
    /// // Peb tuaj yeem ua weak.as_ptr(), tab sis kev nkag mus rau lub pointer yuav ua rau kev coj tus cwj pwm uas tsis tau xaiv.
    /// // assert_eq! ("nyob zoo", kev nyab xeeb {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Yog tias tus pointer dai tuag, peb rov qab xa cov ntawv xa ncaj qha.
            // Qhov no tsis tuaj yeem yog qhov chaw nyob ntawm payload, vim cov payload tsawg kawg raws li RcBox (usize).
            ptr as *const T
        } else {
            // KEV RUAJ NTSEG: yog is_dangling rov ua cuav, ces tus pointer tsis suav nrog.
            // Lub payload yuav tso tawm ntawm lub sijhawm no, thiab peb yuav tsum tswj hwm qhov tseeb, yog li siv cov pointer raw cov ntaub ntawv rau.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Consumes `Weak<T>` thiab hloov mus rau hauv lub pointer nyoos.
    ///
    /// Qhov no hloov pauv cov poom uas tsis muaj zog mus rau hauv lub pointer nyoos, thaum tseem khaws cia cov tswv cuab ntawm ib qho kev siv tsis muaj zog (qhov tsis muaj zog suav tsis yog hloov los ntawm kev ua haujlwm no).
    /// Nws tuaj yeem tig rov qab rau hauv `Weak<T>` nrog [`from_raw`].
    ///
    /// Tib qho kev txwv ntawm kev nkag mus rau lub hom phiaj ntawm tus pointer li nrog [`as_ptr`] siv.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Hloov tus pointer nyoos yav tas los tsim los ntawm [`into_raw`] rov qab mus rau `Weak<T>`.
    ///
    /// Qhov no tuaj yeem siv kom muaj kev nyab xeeb tau txais kev siv dag zog (los ntawm kev hu rau [`upgrade`] tom qab) lossis los daws qhov tsis muaj zog suav los ntawm kev xa mus rau `Weak<T>`.
    ///
    /// Nws yuav tsum ua tswv cuab ntawm ib qho tsis muaj zog siv (tshwj tsis yog cov taw tes tsim los ntawm [`new`], vim tias cov no tsis muaj dab tsi; tus qauv tseem ua haujlwm rau lawv).
    ///
    /// # Safety
    ///
    /// Tus pointer yuav tsum tau tshwm sim los ntawm [`into_raw`] thiab yuav tsum tseem muaj lub peev xwm tsis muaj zog siv.
    ///
    /// Nws raug tso cai rau qhov muaj zog suav ua 0 thaum lub sijhawm ntawm hu qhov no.
    /// Txawm li cas los xij, qhov no tau ua tswv cuab ntawm ib qho tsis muaj zog tam sim no sawv cev tam li tus pointer nyoos (qhov tsis muaj zog suav tsis tau hloov los ntawm kev ua haujlwm no) thiab yog li nws yuav tsum tau txuas nrog nrog kev hu dhau los rau [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Txo kev ua kom suav daws tsis muaj zog.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Saib Weak::as_ptr rau cov ntsiab lus hais txog yuav ua li cas lub tswv yim pointer muab tau los.

        let ptr = if is_dangling(ptr as *mut T) {
            // Qhov no yog qhov phuam tsis muaj zog.
            ptr as *mut RcBox<T>
        } else {
            // Txwv tsis pub, peb tau lees tias tus pointer tuaj ntawm qhov tsis muaj tseeb Weak.
            // KEV RUAJ NTSEG: data_offset muaj kev nyab xeeb rau kev hu, raws li ptr hais txog qhov tiag (muaj feem tau nqis) T.
            let offset = unsafe { data_offset(ptr) };
            // Yog li, peb tig rov qab qhov kev txhaum tshem kom tau tag nrho RcBox.
            // KEV RUAJ NTSEG: tus pointer originated los ntawm Weak, yog li qhov kev txwv no yog kev nyab xeeb.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // TXUJ CI: tam sim no peb tau rov qab tau tus thawj Weak pointer, yog li tuaj yeem tsim qhov Weak.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Kev rau siab hloov mus rau `Weak` tus pointer rau ib qho [`Rc`], ncua kev poob qis ntawm tus nqi sab hauv yog tias muaj kev vam meej.
    ///
    ///
    /// Rov qab [`None`] yog tias tus nqi sab hauv txij li tau nqis tawm.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Ua kom puas tag nrho cov muaj zog pointers.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Tau txais cov naj npawb ntawm qhov muaj zog (`Rc`) taw tes taw rau qhov kev faib no.
    ///
    /// Yog tias `self` raug tsim los siv [`Weak::new`], qhov no yuav xa rov qab 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Tau txais cov lej ntawm `Weak` taw tes rau qhov kev faib no.
    ///
    /// Yog tias tsis muaj cov taw tes muaj zog, qhov no yuav rov qab xoom.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // rho tawm cov tsis muaj zog ptr
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Rov qab `None` thaum tus pointer dai tuag thiab tsis muaj kev faib nyiaj `RcBox`, (piv txwv li, thaum `Weak` no tau tsim los ntawm `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Peb xyuam xim rau *tsis* tsim qhov siv suav sau rau "data" daim teb, vim hais tias daim teb yuav raug sib hloov hauv lub sijhawm (piv txwv li, yog tias `Rc` kawg poob, cov ntaub ntawv sau yuav muab tso rau hauv-chaw).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Rov qab `true` yog tias ob qho "Weak" taw qhia rau tib qho kev faib tawm (zoo ib yam li [`ptr::eq`]), lossis yog tias ob qho tib si tsis taw tes rau qee qhov kev faib tawm (vim tias lawv tau tsim nrog `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Vim tias qhov sib piv cov lus taw qhia nws txhais tau tias `Weak::new()` yuav sib npaug, txawm tias lawv tsis taw tes rau ib qho kev faib.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Sib piv `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Dhuav cov `Weak` lub pointer.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Tsis luam tawm txhua yam
    /// drop(foo);        // Luam "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // qhov suav tsis muaj zog pib thaum 1, thiab yuav tsuas yog mus rau xoom yog tias txhua tus taw tes muaj zog tau ploj lawm.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Ua ib qho clone ntawm `Weak` lub pointer uas taw rau cov kev faib tawm tib yam.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Ua lub `Weak<T>` tshiab, faib cov cim xeeb rau `T` yam tsis muaj pib ua.
    /// Hu [`upgrade`] ntawm tus nqi xa rov qab ib txwm muab [`None`].
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Peb tau soj ntsuam_tau nyob ntawm no txhawm rau mem::forget yam xyuam xim.Nyob rau hauv kev
// yog tias koj mem::forget Rcs (lossis Weaks), qhov rov suav dua tuaj yeem dhau, thiab tom qab ntawd koj tuaj yeem tso cov nyiaj dawb thaum koj tseem muaj Rcs (lossis Weaks) nyob.
//
// Peb tshem tawm vim tias qhov no yog qhov kev tshwm sim tsis zoo uas peb tsis quav ntsej txog dab tsi tshwm sim-tsis muaj qhov kev pab cuam tiag tiag yuav tsum tau muaj qhov no.
//
// Qhov no yuav tsum muaj nyiaj siv ua haujlwm negligible vim tias koj tsis tas yuav clone cov no ntau hauv Rust ua tsaug rau cov tswv cuab thiab cov txav-semantics.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Peb xav rho menyuam ntawm txeej dua li tsis xa tus nqi.
        // Qhov suav suav suav yuav tsis yog thaum xoom thaum qhov no hu ua;
        // txawm li cas los xij, peb ntxig rau ib qho abort ntawm no los hint LLVM ntawm kev txwv tsis pub ua kom zoo dua.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Peb xav rho menyuam ntawm txeej dua li tsis xa tus nqi.
        // Qhov suav suav suav yuav tsis yog thaum xoom thaum qhov no hu ua;
        // txawm li cas los xij, peb ntxig rau ib qho abort ntawm no los hint LLVM ntawm kev txwv tsis pub ua kom zoo dua.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Tau txais cov nqi txo nyob rau hauv ib qho `RcBox` rau lub payload qab tus pointer.
///
/// # Safety
///
/// Tus taw qhia yuav tsum taw mus rau (thiab muaj cov metadata siv tau rau) qhov piv txwv yav dhau los ntawm T, tab sis T tso cai kom tso tawm.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Dlhos tus nqi tsis txaus mus rau qhov kawg ntawm RcBox.
    // Vim tias RcBox yog repr(C), nws yuav nco ntsoov ua daim teb kawg hauv cim xeeb.
    // KEV RUAJ NTSEG: vim tias tsuas yog hom tsis tau paub tab yog hlais, trait khoom,
    // thiab cov hom txawv, cov tswv yim kev nyab xeeb tam sim no txaus kom txaus siab cov kev xav tau ntawm align_of_val_raw;qhov no yog kev nthuav dav siv ntawm cov lus uas yuav tsis cuam tshuam nrog sab nraud std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}