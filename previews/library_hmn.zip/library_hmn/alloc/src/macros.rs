/// Tsim ib tug [`Vec`] muaj cov nqe lus.
///
/// `vec!` tso cai rau 'Vec` yuav tau txhais nrog tib syntax li cov kab zauv.
/// Nws muaj ob daim ntawv ntawm cov loj heev no:
///
/// - Tsim tus [`Vec`] uas muaj cov npe muab cov ntsiab lus:
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - Tsim tus [`Vec`] los ntawm qhov muab thiab loj:
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// Nco ntsoov tias tsis zoo li array kab zauv no syntax txhawb tag nrho cov ntsiab uas siv [`Clone`] thiab tus naj npawb ntawm cov ntsiab tsis yuav tsum tau ib tug tas mus li.
///
/// Qhov no yuav siv `clone` theej tawm ib qho kev qhia, yog li ib qho yuav tsum tau ceev faj siv qhov no nrog cov hom muaj qhov tsis sib xws `Clone`.
/// Piv txwv, `vec![Rc::new(1);5] `yuav tsim vector ntawm tsib cov ntawv xa mus rau tib lub thawv hauv tus lej, tsis yog tsib nqe lus taw qhia txog ntawm nws tus kheej hauv lub thawv sib npaug.
///
///
/// Tsis tas li ntawd, nco ntsoov tias `vec![expr; 0]` pub, thiab tsim cov khoob vector.
/// Qhov no tseem yuav soj ntsuam `expr`, txawm li cas los xij, thiab tam sim ntawd tso qhov txiaj ntsig tsim, yog li nco ntsoov txog cov kev mob tshwm sim.
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): nrog cfg(test) qhov txais tau `[T]::into_vec` tus qauv, uas yuav tsum muaj rau cov ntsiab lus loj heev no, tsis muaj.
// Hloov siv `slice::into_vec` kev ua haujlwm uas tsuas yog muaj nrog cfg(test) NB pom slice::hack module hauv slice.rs rau cov ntaub ntawv ntau
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// Tsim cov `String` siv kev txhais cov runtime kab zauv.
///
/// Thawj qhov sib cav uas `format!` tau txais yog hom kab ntawv.Qhov no yuav tsum muaj txoj hlua sau cia.Lub zog ntawm txoj hlua ua qauv yog nyob rau hauv lub `{}} s uas muaj.
///
/// Cov kev txwv ntxiv tau dhau mus rau `format!` hloov lub `{}` s nyob rau hauv txoj hlua rau hauv kev txiav txim muab tshwj tsis yog muaj npe lossis qhov tsis raug siv;saib [`std::fmt`] rau cov lus qhia ntxiv.
///
///
/// Ib qho siv rau `format!` yog concatenation thiab interpolation ntawm cov hlua.
/// Cov kev txiav txim siab tib yam yog siv nrog [`print!`] thiab [`write!`] macros, nyob ntawm cov phiaj xwm tig mus ntawm txoj hlua.
///
/// Txhawm rau kom hloov ib tus nqi rau txoj hlua, siv txoj kev [`to_string`].Qhov no yuav siv [`Display`] formatting trait.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` panics yog tias kev tsim qauv trait rov ua yuam kev.
/// Qhov no qhia tau tias qhov ua tsis raug vim txij `fmt::Write for String` yeej tsis rov ua qhov yuam kev ib qho ntawm nws tus kheej.
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// Yuam kom AST node rau qhov kev qhia los txhim kho kev kuaj mob hauv txoj hauj lwm qauv.
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}