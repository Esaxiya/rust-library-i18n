// Teem qhov ntev ntawm lub vec thaum `SetLenOnDrop` tus nqi mus tsis tau.
//
// Lub tswv yim yog: Qhov ntev daim teb hauv SetLenOnDrop yog lub hauv zos sib txawv uas cov optimizer yuav pom tsis suav nrog txhua lub khw muag khoom los ntawm Vec cov ntaub ntawv taw qhia.
// Qhov no yog qhov ua haujlwm rau alias tsom teeb meem #32155
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}