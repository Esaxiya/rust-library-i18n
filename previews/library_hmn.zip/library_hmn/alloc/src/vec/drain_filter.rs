use crate::alloc::{Allocator, Global};
use core::ptr::{self};
use core::slice::{self};

use super::Vec;

/// Tus ntsuas hluav taws xob uas siv kaw kaw kom txiav txim siab yog tias ib qho khoom yuav tsum tau muab tshem tawm.
///
/// Qhov no struct yog tsim los ntawm [`Vec::drain_filter`].
/// Saib nws cov ntawv pov thawj ntxiv.
///
/// # Example
///
/// ```
/// #![feature(drain_filter)]
///
/// let mut v = vec![0, 1, 2];
/// let iter: std::vec::DrainFilter<_, _> = v.drain_filter(|x| *x % 2 == 0);
/// ```
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
#[derive(Debug)]
pub struct DrainFilter<
    'a,
    T,
    F,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> where
    F: FnMut(&mut T) -> bool,
{
    pub(super) vec: &'a mut Vec<T, A>,
    /// Qhov ntsuas ntawm cov khoom uas yuav raug tshuaj xyuas los ntawm kev hu xov tooj tom ntej mus rau `next`.
    pub(super) idx: usize,
    /// Tus naj npawb ntawm cov khoom uas tau haus (removed) li tam sim no.
    pub(super) del: usize,
    /// Tus thawj ntev ntawm `vec` ua ntej tso dej.
    pub(super) old_len: usize,
    /// Qhov kev ntsuam xyuas lim predicate.
    pub(super) pred: F,
    /// Ib tus chij uas qhia panic tau tshwm sim hauv qhov kev lim dej lim ua ntej.
    /// Qhov no yog siv los ua cov hint hauv kev nqis tes siv los tiv thaiv kev noj cov khoom seem ntawm `DrainFilter`.
    /// Ib qho khoom twg tsis suav yuav tau rov qab rau hauv `vec`, tab sis tsis muaj cov khoom txuas ntxiv yuav raug nqis lossis kuaj los ntawm lim lim.
    ///
    ///
    pub(super) panic_flag: bool,
}

impl<T, F, A: Allocator> DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    /// Rov qab xa mus rau cov hauv paus hauv paus kev faib nyiaj.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.vec.allocator()
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Iterator for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        unsafe {
            while self.idx < self.old_len {
                let i = self.idx;
                let v = slice::from_raw_parts_mut(self.vec.as_mut_ptr(), self.old_len);
                self.panic_flag = true;
                let drained = (self.pred)(&mut v[i]);
                self.panic_flag = false;
                // Hloov kho qhov ntsuas *tom qab* lub hau twv hu ua.
                // Yog tias qhov ntsuas tau raug hloov kho ua ntej thiab qhov twv ua ntej panics, lub hauv paus ntawm qhov ntsuas no yuav raug xau.
                //
                self.idx += 1;
                if drained {
                    self.del += 1;
                    return Some(ptr::read(&v[i]));
                } else if self.del > 0 {
                    let del = self.del;
                    let src: *const T = &v[i];
                    let dst: *mut T = &mut v[i - del];
                    ptr::copy_nonoverlapping(src, dst, 1);
                }
            }
            None
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Drop for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct BackshiftOnDrop<'a, 'b, T, F, A: Allocator>
        where
            F: FnMut(&mut T) -> bool,
        {
            drain: &'b mut DrainFilter<'a, T, F, A>,
        }

        impl<'a, 'b, T, F, A: Allocator> Drop for BackshiftOnDrop<'a, 'b, T, F, A>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                unsafe {
                    if self.drain.idx < self.drain.old_len && self.drain.del > 0 {
                        // Qhov no yog ib tug zoo nkauj messed up lub xeev, thiab tsis muaj ib tiag tiag ib qho obviously zoo tshaj plaws ua.
                        // Peb tsis xav kom mob siab rau ua `pred`, yog li peb tsuas rov qab ua txhua yam tsis tau hais thiab qhia vec tias lawv tseem muaj.
                        //
                        // Lub nraub qaum yog qhov yuav tsum tau tiv thaiv ob-poob ntawm qhov kawg tau ua tiav dej ua ntej panic nyob rau hauv kev twv.
                        //
                        //
                        let ptr = self.drain.vec.as_mut_ptr();
                        let src = ptr.add(self.drain.idx);
                        let dst = src.sub(self.drain.del);
                        let tail_len = self.drain.old_len - self.drain.idx;
                        src.copy_to(dst, tail_len);
                    }
                    self.drain.vec.set_len(self.drain.old_len - self.drain.del);
                }
            }
        }

        let backshift = BackshiftOnDrop { drain: self };

        // Sim kom tsis txhob haus ib qho twg ntxiv yog tias lim tau lim tias tseem tsis tau siv.
        // Peb yuav tau rov ua ibqho cov ntsiab lus tsis hais seb peb puas tau muaj xwm txheej lossis yog tias tau noj ntawm no panics.
        //
        if !backshift.drain.panic_flag {
            backshift.drain.for_each(drop);
        }
    }
}