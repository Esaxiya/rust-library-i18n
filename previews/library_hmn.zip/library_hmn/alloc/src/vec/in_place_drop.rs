use core::ptr::{self};
use core::slice::{self};

// Qhov kev pabcuam rau kev-nyob rau hauv-chaw iteration uas xa mus rau lo lus uas peb hlais ntawm iteration, piv txwv li lub taub hau.
// Lub hauv paus hlais (tus Tsov tus tw) tau nqis los ntawm IntoIter.
pub(super) struct InPlaceDrop<T> {
    pub(super) inner: *mut T,
    pub(super) dst: *mut T,
}

impl<T> InPlaceDrop<T> {
    fn len(&self) -> usize {
        unsafe { self.dst.offset_from(self.inner) as usize }
    }
}

impl<T> Drop for InPlaceDrop<T> {
    #[inline]
    fn drop(&mut self) {
        unsafe {
            ptr::drop_in_place(slice::from_raw_parts_mut(self.inner, self.len()));
        }
    }
}