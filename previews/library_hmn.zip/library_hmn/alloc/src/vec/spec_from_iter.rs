use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Kev Tshwj Xeeb trait siv rau Vec::from_iter
///
/// ## Daim duab sawv cev ntawm cov pawg:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Ib tug ntau cov ntaub ntawv yog dua ib tug vector rau hauv ib tug muaj nuj nqi uas tam sim ntawd rov sau rau hauv ib lub vector.
        // Peb tuaj yeem luv luv qhov no yog tias IntoIter tsis tau nce qib txhua.
        // Thaum nws tau advanced Peb kuj rov qab siv lub lub cim xeeb thiab tsiv mus nyob rau cov ntaub ntawv rau pem hauv ntej.
        // Tab sis peb tsuas yog ua li ntawd thaum lub Vec tawm yuav tsis muaj ntau lub peev xwm tsis tsim dua qhov tsim nws los ntawm cov kev ua haujlwm los ntawm qhov chaw ua haujlwm tsis tseem ceeb.
        //
        // Uas muaj kev txwv yog tsis nruj me ntsis tsim nyog raws li Vec lub qee tus cwj pwm yog txhob txwm unspecified.
        // Tab sis nws yog xaiv txhag cia.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // yuav tsum delegate rau spec_extend() txij thaum extend() nws tus kheej delegates mus spec_from rau npliag Vecs
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Qhov no siv `iterator.as_slice().to_vec()` txij li spec_extend yuav tsum muaj ntau kauj ruam ntxiv rau lub laj thawj txog qhov kawg qhov peev xwm + ntev thiab yog li ua ntau yam haujlwm.
// `to_vec()` ncaj qha faib qhov nyiaj kom raug thiab puv nws nkaus.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): nrog cfg(test) qhov txais tau `[T]::to_vec` txoj kev, uas yuav tsum muaj rau cov qauv ntsiab lus no, tsis muaj.
    // Hloov siv `slice::to_vec` kev ua haujlwm uas tsuas yog muaj nrog cfg(test) NB pom slice::hack module hauv slice.rs rau cov ntaub ntawv ntau
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}