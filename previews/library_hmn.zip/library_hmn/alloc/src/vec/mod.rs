//! Cov chaw sib kis tsis tuaj yeem nthuav dav nrog hom heap-faib lus, sau ntawv `Vec<T>`.
//!
//! Vectors muaj `O(1)` indexing, amortized `O(1)` thawb (mus rau qhov kawg) thiab `O(1)` pop (los ntawm qhov kawg).
//!
//!
//! Vectors xyuas kom lawv tsis txhob faib ntau tshaj `isize::MAX` bytes.
//!
//! # Examples
//!
//! Koj tuaj yeem qhia meej tsim [`Vec`] nrog [`Vec::new`]:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... lossis los ntawm kev siv lub [`vec!`] loj heev:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // kaum zeroes
//! ```
//!
//! Koj tuaj yeem [`push`] qhov tseem ceeb mus rau qhov kawg ntawm vector (uas yuav loj hlob vector raws li xav tau):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! Popping muaj txiaj ntsig ua haujlwm nyob rau ntau qhov qub:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors kuj tseem pab txhawb nqa kev ntsuas dhau (los ntawm [`Index`] thiab [`IndexMut`] traits):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// Qhov sib kis ntawm cov kab sib kis tau yooj yim, sau ua `Vec<T>` thiab hais ua 'vector'.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// [`vec!`] macro yog muab los ua kev pib yooj yim dua:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// Nws kuj tseem tuaj yeem pib txhua ntu ntawm `Vec<T>` nrog tus nqi.
/// Qhov no yuav ua tau zoo dua li kev ua tiav cov kev faib thiab pib hauv cov kauj ruam cais, tshwj xeeb tshaj yog thaum pib ua vector ntawm cov zeros:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // Cov nram qab no yog sib npaug, tab sis muaj qeeb qeeb:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// Yog xav paub ntxiv, saib [Capacity and Reallocation](#capacity-and-reallocation).
///
/// Siv `Vec<T>` ua cov khoom siv ruaj khov:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // Luam Ntawv 3, 2, 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// `Vec` hom tso cai rau nkag mus saib qhov tseem ceeb los ntawm kev ntsuas, vim nws ua raws li [`Index`] trait.Ib qho piv txwv yuav qhia tau meej dua:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // nws yuav tso saib '2'
/// ```
///
/// Txawm li cas los xij ceev faj: yog tias koj sim nkag mus rau qhov ntsuas uas tsis yog `Vec`, koj lub software yuav panic!Koj tsis tuaj yeem ua qhov no:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// Siv [`get`] thiab [`get_mut`] yog tias koj xav kuaj xyuas seb tus lej puas nyob hauv `Vec`.
///
/// # Slicing
///
/// Ib lub `Vec` tuaj yeem hloov ua lwm yam.Ntawm qhov tod tes, hlais tsuas yog nyeem cov khoom nkaus xwb.
/// Yuav kom tau txais [slice][prim@slice], siv [`&`].Piv txwv:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... thiab yog txhua yam!
/// // koj tuaj yeem ua nws li no:
/// let u: &[usize] = &v;
/// // los yog zoo li no:
/// let u: &[_] = &v;
/// ```
///
/// Hauv Rust, nws yog qhov pom ntau dua kom dhau cov nplais yog kev sib cav es tsis yog vectors thaum koj tsuas yog xav muab kev nkag mus nyeem.Tib yam mus rau [`String`] thiab [`&str`].
///
/// # Lub peev xwm thiab qhov chaw ua haujlwm tiag
///
/// Lub peev xwm ntawm vector yog qhov chaw siv rau txhua qhov future uas yuav muab ntxiv rau vector.Qhov no yog tsis yuav tsum tau meej pem nrog tus *ntev* ntawm ib tug vector, uas qhia txog cov naj npawb ntawm cov sij ntsiab nyob rau hauv lub vector.
/// Yog tias vector qhov ntev tshaj li lub peev xwm, nws lub peev xwm yuav cia li nce, tab sis nws cov ntsiab lus yuav tsum tau hloov chaw.
///
/// Piv txwv li, vector nrog lub peev xwm 10 thiab ntev 0 yuav yog qhov khoob vector nrog qhov chaw rau 10 ntau dua.Thawb 10 lossis tsawg dua cov ntsiab lus mus rau vector yuav tsis hloov nws lub peev xwm lossis ua rau qhov chaw hloov pauv.
/// Txawm li cas los xij, yog vector qhov ntev tau nce mus rau 11, nws yuav tsum tau hloov chaw, uas tuaj yeem qeeb.Vim li no, nws yog pom zoo kom siv [`Vec::with_capacity`] thaum twg ua tau qhia kom meej yuav ua li cas loj lub vector yuav tsum tau txais.
///
/// # Guarantees
///
/// Vim tias nws qhov xwm pheej tsis txaus ntseeg, `Vec` ua rau muaj kev lees paub ntau txog nws tus qauv.Qhov no ua kom paub meej tias nws qis-nyiaj siv ua haujlwm ntau li ntau tau hauv qhov xwm txheej dav dav, thiab tuaj yeem kho tau txoj hauv kev txheej thaum ub los ntawm qhov chaws tsis zoo.Nco ntsoov tias cov kev lees paub no xa mus rau ib qho tsis tsim nyog `Vec<T>`.
/// Yog tias ntxiv cov kev txwv tsis pub txuas ntxiv (piv txwv li, los txhawb nqa cov neeg lis haujlwm hauv kev cai), kev hla dhau lawv tus qauv yuav hloov tus cwj pwm.
///
/// Feem ntau cov hauv paus, `Vec` yog thiab ib txwm yuav yog (lub pointer, muaj peev xwm, ntev).Tsis muaj ntxiv, tsis muaj tsawg dua.Qhov kev txiav txim ntawm cov liaj teb tsis tau qhia meej, thiab koj yuav tsum siv cov hauv kev tsim nyog los hloov cov no.
/// Tus taw qhia yuav tsis muaj ib yam dab tsi, yog li hom no tsis muaj dab tsi-siv tau-xaiv.
///
/// Txawm li cas los xij, lub pointer tsis tuaj yeem taw tes rau qhov cim xeeb.
/// Tshwj xeeb, yog tias koj txua `Vec` nrog lub peev xwm 0 ntawm [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`], lossis los ntawm kev hu rau [`shrink_to_fit`] ntawm qhov khoob Vec, nws yuav tsis faib lub cim xeeb.Ib yam li ntawd, yog tias koj cia zero-sized hom hauv ib `Vec`, nws yuav tsis faib chaw rau lawv.
/// *Nco ntsoov tias qhov no `Vec` yuav tsis qhia [`capacity`] ntawm 0*.
/// `Vec` yuav faib tau yog thiab tsuas yog tias [`mem: : size_of::<T>`]`() * capacity()> 0`.
/// Feem ntau, `Vec` cov ntsiab lus faib tau yooj yim heev-yog tias koj npaj siab yuav faib lub cim xeeb siv ib tus `Vec` thiab siv nws rau lwm yam (dhau mus rau qhov tsis yog code, lossis tsim koj tus kheej kev nco-rov sau), nco ntsoov mus daws cov kev nco no thaum siv `from_raw_parts` kom rov zoo `Vec` thiab mam li tso nws.
///
/// Yog tias `Vec`*tau* faib lub cim xeeb, tom qab ntawd lub cim xeeb nws taw rau yog nyob ntawm lub pob taws (raws li sau tseg los ntawm tus neeg siv Rust tau teeb tsa los siv ua ntej), thiab nws tus taw tes taw rau [`len`] pib, sib txuas nrog cov khoom hauv qhov kev txiav txim (koj xav tau dab tsi saib yog tias koj quab yuam nws mus rau ib qho), tom qab ntawd [`peev xwm]],, [[len`] qhov tawm qhov ua tsis tau zoo, muaj cov khoom sib kis.
///
///
/// A vector muaj cov khoom `'a'` thiab `'b'` nrog lub peev xwm 4 tuaj yeem pom raws li hauv qab no.Sab saum toj kawg nkaus yog `Vec` tus qauv, nws muaj tus taw qhia rau lub taub hau ntawm kev faib ua hauv cov pawg, ntev thiab muaj peev xwm.
/// Qhov hauv qab yog qhov kev faib nyob rau ntawm pob, qhov cim xeeb tsis haum.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** sawv cev lub cim xeeb uas tsis yog qhov pib, saib [`MaybeUninit`].
/// - Note: lub ABI tsis ruaj khov thiab `Vec` ua rau tsis muaj kev lees paub txog nws lub cim xeeb txheej (suav nrog kev txiav txim ntawm daim teb).
///
/// `Vec` yuav tsis ua ib tus "small optimization" qhov twg cov khoom siv tau muab tso rau ntawm pawg rau ob qho laj thawj:
///
/// * Nws yuav ua rau nws nyuaj rau kev tsis nyab xeeb cov cai los kho tus `Vec` kom raug.Cov ntsiab lus ntawm `Vec` yuav tsis muaj chaw nyob ruaj khov yog tias nws tsuas yog tsiv, thiab nws yuav nyuaj rau txiav txim siab yog tias ib qho `Vec` tiag tiag tau faib lub cim xeeb.
///
/// * Nws yuav rau txim rau kis cov ntaub ntawv dav dav, tshwm sim ntxiv branch rau txhua qhov kev nkag.
///
/// `Vec` yuav tsis cia li txiav nws tus kheej, txawm tias khoob kiag li.Qhov no saib kuas tsis muaj ruaj faib nyiaj los yog deallocations tshwm sim.Emptying ib qho `Vec` thiab tom qab ntawd txhaws nws rov qab mus rau qub [`len`] yuav tsum tsis tshwm sim hu rau tus neeg siv nyiaj.Yog tias koj xav tso tawm kev nco siv tsis raug, siv [`shrink_to_fit`] lossis [`shrink_to`].
///
/// [`push`] thiab [`insert`] yuav tsis rov (faib) yog tias lub peev xwm txaus.[`push`] thiab [`insert`]*yuav*(re) faib yog tias [`len`] `==` [`muaj peev xwm`].Hais tias yog, tus qhia muaj peev xwm yog ib qho tseeb, thiab muaj peev xwm yuav cia siab rau.Nws tuaj yeem siv tau rau manually dawb lub cim xeeb faib los ntawm ib qho `Vec` yog qhov xav tau.
/// Tej txoj kev tso ntxig tau *yuav* chaw nyob, txawm tias tsis tsim nyog.
///
/// `Vec` tsis tuaj yeem lav ib qho kev lag luam tshwj xeeb thaum txhim kho thaum ua tiav, lossis thaum [`reserve`] hu.Lub tswv yim tam sim no yog qhov pib yooj yim thiab nws tuaj yeem ua pov thawj xav siv qhov tsis muaj txiaj ntsig kev loj hlob.Xijpeem siv dab tsi yuav tau lees tias *O*(1) amortized [`push`].
///
/// `vec![x; n]`, `vec![a, b, c, d]`, thiab [`Vec::with_capacity(n)`][`Vec::with_capacity`], yuav tag nrho ua ib `Vec` nrog raws nraim thov muaj peev xwm.
/// Yog tias [`len`] `==` [`muaj peev xwm`], (zoo ib yam li [`vec!`] macro), tom qab ntawd ib qho `Vec<T>` tuaj yeem hloov mus rau thiab los ntawm [`Box<[T]>`][owned slice] yam tsis muaj kev hloov chaw lossis txav cov khoom.
///
/// `Vec` yuav tsis tau overwrite tej ntaub ntawv uas yog muab tshem tawm los ntawm nws, tab sis kuj yuav tsis tau khaws cia nws.Nws uninitialized nco yog kos qhov chaw uas tej zaum nws yuav siv li cas los xij nws xav.Nws yuav feem ntau tsuas yog ua dab tsi yog qhov ua tau zoo tshaj los yog lwm qhov yooj yim rau kev coj ua.Tsis txhob cia siab rau cov ntaub ntawv muab tshem tawm kom lwv tawm rau lub hom phiaj ruaj ntseg.
/// Txawm hais tias koj poob tus `Vec`, nws tsis yuav tsuas rov qab siv dua lwm tus `Vec`.
/// Txawm hais tias koj xoom ib lub `Vec` lub cim xeeb ua ntej, qhov ntawd yuav tsis tuaj yeem tshwm sim vim tias qhov optimizer tsis xav txog qhov no tshwm sim uas yuav tsum tau tshwj tseg.
/// Muaj yog ib cov ntaub ntawv uas peb yuav tsis lov, txawm li cas los: siv `unsafe` code rau sau rau tshaj peev xwm, thiab ces ua qhov ntev kom phim, yog ib txwm siv tau.
///
/// Tam sim no, `Vec` tsis tuaj yeem lav qhov kev txiav txim hauv cov ntsiab lus nqig.
/// Qhov kev txiav txim tau hloov pauv yav dhau los thiab tuaj yeem hloov pauv ntxiv.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// Txoj kev xam qhovkev
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// Tsim dua tshiab, khoob `Vec<T>`.
    ///
    /// Lub vector yuav tsis faib kom txog thaum cov khoom thawb mus rau nws.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// Ua dua tshiab, khoob `Vec<T>` nrog qhov muaj peev xwm tshwj tseg.
    ///
    /// Tus vector yuav tuaj yeem tuav tau `capacity` cov ntsiab lus yam tsis muaj kev cuam tshuam tiag.
    /// Yog tias `capacity` yog 0, vector yuav tsis faib.
    ///
    /// Nws yog ib qho tseem ceeb kom nco ntsoov tias txawm hais tias tus xa rov qab vector muaj *muaj peev xwm* teev, vector yuav muaj qhov xoom *ntev*.
    ///
    /// Txhawm rau piav qhia qhov sib txawv ntawm qhov ntev thiab kev muaj peev xwm, saib *[Peev Xwm thiab qhov chaw tsim nyog]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // Lub vector muaj tsis muaj cov khoom, txawm tias nws muaj peev xwm rau ntau
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Txhua yam no yog ua tiav yam tsis muaj chaw cia ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... tab sis qhov no yuav ua rau vector xa rov qab
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Tsim ib qho `Vec<T>` ncaj qha los ntawm cov khoom nyoos ntawm lwm vector.
    ///
    /// # Safety
    ///
    /// Qhov no yog qhov tsis nyab xeeb, vim muaj pes tsawg tus invariants tsis txheeb:
    ///
    /// * `ptr` xav kom tau muaj kev faib ua yav dhau los ntawm [`String`]/`Vec<T>`(tsawg, nws yeej yuav tsis raug yog tias nws tsis yog).
    /// * `T` xav kom muaj qhov loj me thiab ua raws li qhov `ptr` tau faib nrog.
    ///   (`T` muaj kev nruj nruj tsawg tsis txaus, qhov sib ncag tiag tiag yuav tsum sib npaug kom tau raws li cov kev xav tau [`dealloc`] uas lub cim xeeb yuav tsum tau faib thiab sib cais nrog cov txheej txheem tib yam.)
    ///
    /// * `length` xav kom tsawg dua lossis sib luag rau `capacity`.
    /// * `capacity` xav tau lub peev xwm uas tus pointer tau faib nrog.
    ///
    /// Ua txhaum cov no yuav ua teeb meem xws li ua kom tsis ncaj lub chaw muab cov ntaub ntawv sab hauv.Piv txwv li nws yog **tsis yog** muaj kev ruaj ntseg los tsim lub `Vec<u8>` los ntawm tus taw qhia mus rau C `char` array nrog qhov ntev `size_t`.
    /// Nws kuj tsis nyab xeeb los txhim tsa ib qho los ntawm `Vec<u16>` thiab nws qhov ntev, vim hais tias cov neeg faib khoom zov txog kev sib ncag, thiab ob hom no muaj ntau qhov sib txawv.
    /// Tus tsis tau faib rau cov sib ncag 2 (rau `u16`), tab sis tom qab tig nws mus rau hauv `Vec<u8>` nws yuav muaj kev cuam tshuam nrog kev sib dhos 1.
    ///
    /// Cov tswv cuab ntawm `ptr` tau zoo hloov mus rau `Vec<T>` uas tom qab ntawd hloov chaw, xa tawm lossis hloov cov ntsiab lus ntawm lub cim xeeb taw qhia los ntawm tus pointer ntawm yuav.
    /// Nco ntsoov tias tsis muaj dab tsi ntxiv siv lub pointer tom qab hu rau txoj haujlwm no.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME hloov tshiab no thaum vec_into_raw_parts stabilized.
    ///     // Tiv thaiv kom tsis txhob ua haujlwm `v`'s destructor yog li peb tau ua tiav kev tswj hwm ntawm kev faib khoom.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Rub tawm cov ntawv tseem ceeb ntau yam ntawm `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // Overwrite nco nrog 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Muab txhua yam tso rov qab ua ke rau hauv Vec
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Constructs ib tug tshiab, nchuav tag `Vec<T, A>`.
    ///
    /// Lub vector yuav tsis faib kom txog thaum cov khoom thawb mus rau nws.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// Ua lub tsev tshiab, khoob `Vec<T, A>` nrog cov muaj peev xwm tshwj xeeb nrog cov muab siv tshwj xeeb.
    ///
    /// Tus vector yuav tuaj yeem tuav tau `capacity` cov ntsiab lus yam tsis muaj kev cuam tshuam tiag.
    /// Yog tias `capacity` yog 0, vector yuav tsis faib.
    ///
    /// Nws yog ib qho tseem ceeb kom nco ntsoov tias txawm hais tias tus xa rov qab vector muaj *muaj peev xwm* teev, vector yuav muaj qhov xoom *ntev*.
    ///
    /// Txhawm rau piav qhia qhov sib txawv ntawm qhov ntev thiab kev muaj peev xwm, saib *[Peev Xwm thiab qhov chaw tsim nyog]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // Lub vector muaj tsis muaj cov khoom, txawm tias nws muaj peev xwm rau ntau
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Txhua yam no yog ua tiav yam tsis muaj chaw cia ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... tab sis qhov no yuav ua rau vector xa rov qab
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// Tsim ib tug `Vec<T, A>` ncaj qha los ntawm cov nqaij nyoos Cheebtsam ntawm lwm vector.
    ///
    /// # Safety
    ///
    /// Qhov no yog qhov tsis nyab xeeb, vim muaj pes tsawg tus invariants tsis txheeb:
    ///
    /// * `ptr` xav kom tau muaj kev faib ua yav dhau los ntawm [`String`]/`Vec<T>`(tsawg, nws yeej yuav tsis raug yog tias nws tsis yog).
    /// * `T` xav kom muaj qhov loj me thiab ua raws li qhov `ptr` tau faib nrog.
    ///   (`T` muaj kev nruj nruj tsawg tsis txaus, qhov sib ncag tiag tiag yuav tsum sib npaug kom tau raws li cov kev xav tau [`dealloc`] uas lub cim xeeb yuav tsum tau faib thiab sib cais nrog cov txheej txheem tib yam.)
    ///
    /// * `length` xav kom tsawg dua lossis sib luag rau `capacity`.
    /// * `capacity` xav tau lub peev xwm uas tus pointer tau faib nrog.
    ///
    /// Ua txhaum cov no yuav ua teeb meem xws li ua kom tsis ncaj lub chaw muab cov ntaub ntawv sab hauv.Piv txwv li nws yog **tsis yog** muaj kev ruaj ntseg los tsim lub `Vec<u8>` los ntawm tus taw qhia mus rau C `char` array nrog qhov ntev `size_t`.
    /// Nws kuj tsis nyab xeeb los txhim tsa ib qho los ntawm `Vec<u16>` thiab nws qhov ntev, vim hais tias cov neeg faib khoom zov txog kev sib ncag, thiab ob hom no muaj ntau qhov sib txawv.
    /// Tus tsis tau faib rau cov sib ncag 2 (rau `u16`), tab sis tom qab tig nws mus rau hauv `Vec<u8>` nws yuav muaj kev cuam tshuam nrog kev sib dhos 1.
    ///
    /// Cov tswv cuab ntawm `ptr` tau zoo hloov mus rau `Vec<T>` uas tom qab ntawd hloov chaw, xa tawm lossis hloov cov ntsiab lus ntawm lub cim xeeb taw qhia los ntawm tus pointer ntawm yuav.
    /// Nco ntsoov tias tsis muaj dab tsi ntxiv siv lub pointer tom qab hu rau txoj haujlwm no.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME hloov tshiab no thaum vec_into_raw_parts stabilized.
    ///     // Tiv thaiv kom tsis txhob ua haujlwm `v`'s destructor yog li peb tau ua tiav kev tswj hwm ntawm kev faib khoom.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Rub tawm cov ntawv tseem ceeb ntau yam ntawm `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // Overwrite nco nrog 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Muab txhua yam tso rov qab ua ke rau hauv Vec
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// Decomposes ib `Vec<T>` rau hauv nws cov nqaij nyoos Cheebtsam.
    ///
    /// Rov qab los ntawm lub pointer nyoos rau cov ntaub ntawv hauv qab, qhov ntev ntawm vector (hauv cov khoom), thiab muaj peev xwm ntawm cov ntaub ntawv (hauv cov khoom).
    /// Cov no yog cov tib nqe lus nyob rau hauv qhov kev txiav txim raws li cov nqe lus rau [`from_raw_parts`].
    ///
    /// Tom qab hu rau txoj haujlwm no, tus hu yog lub luag haujlwm rau lub cim xeeb yav dhau los tswj hwm los ntawm `Vec`.
    /// Tib txoj kev los ua qhov no yog hloov tus pointer nyoos, ntev, thiab lub peev xwm rov qab mus rau hauv `Vec` nrog [`from_raw_parts`] ua haujlwm, cia tus destructor ua qhov tu.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // Tam sim no peb tuaj yeem hloov pauv cov Cheebtsam, xws li transmuting lub pointer nyoos rau hom ntau yam.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// Decomposes ib `Vec<T>` rau hauv nws cov nqaij nyoos Cheebtsam.
    ///
    /// Rov qab los ntawm lub pointer nyoos rau cov ntaub ntawv hauv qab, qhov ntev ntawm vector (hauv cov khoom), lub peev xwm ntawm cov ntaub ntawv (hauv cov khoom), thiab cov kev faib tawm.
    /// Cov no yog tib cov lus sib cav hauv tib qho txheej txheem uas muaj kev sib cav rau [`from_raw_parts_in`].
    ///
    /// Tom qab hu rau txoj haujlwm no, tus hu yog lub luag haujlwm rau lub cim xeeb yav dhau los tswj hwm los ntawm `Vec`.
    /// Tib txoj kev los ua qhov no yog hloov tus pointer nyoos, ntev, thiab lub peev xwm rov qab mus rau hauv `Vec` nrog [`from_raw_parts_in`] ua haujlwm, cia tus destructor ua qhov tu.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // Tam sim no peb tuaj yeem hloov pauv cov Cheebtsam, xws li transmuting lub pointer nyoos rau hom ntau yam.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// Rov tus xov tooj ntawm cov ntsiab lub vector yuav tuav tsis reallocating.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// Txwv cov peev xwm yam tsawg kawg `additional` ntau cov khoom kom tau muab tso rau hauv `Vec<T>` muab.
    /// Txoj kev sau khoom yuav tseg tau chaw sau ntau ntxiv kom tsis txhob tsiv tawm.
    /// Tom qab hu `reserve`, lub peev xwm yuav loj dua lossis sib npaug rau `self.len() + additional`.
    /// Tsis muaj dab tsi yog tias muaj peev xwm yog twb txaus.
    ///
    /// # Panics
    ///
    /// Panics yog qhov muaj peev xwm tshiab tshaj `isize::MAX` bytes.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// Qha qhov tsawg kawg nkaus muaj peev xwm rau raws nraim `additional` ntau cov ntsiab lus kom muab tso rau hauv `Vec<T>` muab.
    ///
    /// Tom qab hu `reserve_exact`, lub peev xwm yuav loj dua lossis sib npaug rau `self.len() + additional`.
    /// Tsis muaj dab tsi yog tias lub peev xwm twb txaus lawm.
    ///
    /// Nco ntsoov tias tus neeg faib yuav muab qhov chaw sau ntau dua li nws thov.
    /// Yog li ntawd, lub peev xwm tsis tuaj yeem cia siab rau qhov yuav tsum tau muaj tsawg.
    /// Xum `reserve` yog tias future kev nkag siab yuav tsum.
    ///
    /// # Panics
    ///
    /// Panics yog qhov muaj peev xwm tshiab hla `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// Sim khaws cov peev xwm tsawg rau `additional` ntau cov khoom kom raug tso rau hauv `Vec<T>` muab.
    /// Txoj kev sau khoom yuav tseg tau chaw sau ntau ntxiv kom tsis txhob tsiv tawm.
    /// Tom qab hu `try_reserve`, lub peev xwm yuav loj dua lossis sib npaug rau `self.len() + additional`.
    /// Tsis muaj dab tsi yog tias muaj peev xwm yog twb txaus.
    ///
    /// # Errors
    ///
    /// Yog hais tias lub peev xwm overflows, los yog lub allocator qhia ib tug tsis ua hauj lwm, ces ib qho yuam kev rov qab.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Npaj ua ntej lub cim xeeb, tawm yog tias peb ua tsis tau
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Tam sim no peb paub qhov no tsis tuaj yeem OOM li ntawm peb cov ua haujlwm nyuaj
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // nyuaj heev
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// Sim khaws cia qhov tsawg kawg nkaus muaj peev xwm rau raws nraim `additional` ntsiab kom muab tso rau hauv muab `Vec<T>`.
    /// Tom qab hu `try_reserve_exact`, lub peev xwm yuav loj dua lossis sib npaug rau `self.len() + additional` yog tias nws rov `Ok(())`.
    ///
    /// Tsis muaj dab tsi yog tias lub peev xwm twb txaus lawm.
    ///
    /// Nco ntsoov tias tus neeg faib yuav muab qhov chaw sau ntau dua li nws thov.
    /// Yog li ntawd, lub peev xwm tsis tuaj yeem cia siab rau qhov yuav tsum tau muaj tsawg.
    /// Xum `reserve` yog tias future kev nkag siab yuav tsum.
    ///
    /// # Errors
    ///
    /// Yog hais tias lub peev xwm overflows, los yog lub allocator qhia ib tug tsis ua hauj lwm, ces ib qho yuam kev rov qab.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Npaj ua ntej lub cim xeeb, tawm yog tias peb ua tsis tau
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Tam sim no peb paub qhov no tsis tuaj yeem OOM li ntawm peb cov ua haujlwm nyuaj
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // nyuaj heev
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// Ntsws lub peev xwm ntawm vector ntau li ntau tau.
    ///
    /// Nws yuav poob qis kom ze li sai tau rau qhov ntev tab sis tus neeg faib nyiaj kuj tseem yuav qhia rau vector tias muaj chaw rau ob peb ntxiv cov khoom.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // Lub peev xwm yeej tsis tsawg tshaj li qhov ntev, thiab tsis muaj dab tsi los ua thaum lawv sib npaug, yog li peb tuaj yeem zam qhov panic rooj plaub hauv `RawVec::shrink_to_fit` tsuas yog hu nws nrog lub peev xwm loj dua.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// Shrinks lub peev xwm ntawm vector nrog qis khi.
    ///
    /// Lub peev xwm yuav nyob tsawg kawg ntawm qhov ntev raws li qhov ntev thiab qhov khoom xa tuaj.
    ///
    ///
    /// Yog tias lub peev xwm tam sim no tsawg dua li qhov kev txwv qis, qhov no yog tsis muaj op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// Hloov siab rau vector mus rau [`Box<[T]>`][owned slice].
    ///
    /// Nco ntsoov tias qhov no yuav poob qis dua qhov muaj peev xwm.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// Muaj peev xwm tshaj qhov raug tshem tawm:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// Shortens lub vector, kom cov thawj `len` ntsiab thiab xa me nyuam rov tus so.
    ///
    /// Yog hais tias `len` yog ntau dua qhov vector tus tam sim no ntev, qhov no muaj tsis ntxim.
    ///
    /// [`drain`] tus qauv tuaj yeem yoog `truncate`, tab sis ua rau cov khoom seem xa rov qab es tsis txhob poob.
    ///
    ///
    /// Nco ntsoov tias hom no tsis muaj kev cuam tshuam rau cov peev txheej uas tau faib vector.
    ///
    /// # Examples
    ///
    /// Txiav tsib lub ntsiab vector rau ob lub ntsiab:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// Tsis muaj qhov txiav tawm thaum lub `len` loj dua vector qhov ntev:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// Txiav thaum `len == 0` qhov sib npaug hu rau [`clear`] tus qauv.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // Qhov no muaj kev nyab xeeb vim hais tias:
        //
        // * cov hlais dhau mus rau `drop_in_place` siv tau;lub `len > self.len` cov ntaub ntawv txhob tsim muaj ib qho invalid hlais, thiab
        // * `len` ntawm vector yog lub zog qis ua ntej hu rau `drop_in_place`, xws li tias tsis muaj nqi yuav raug tshem tawm ob zaug hauv rooj plaub `drop_in_place` tau mus rau panic ib zaug (yog tias nws panics ob zaug, qhov kev zov me nyuam cuam tshuam).
        //
        //
        //
        unsafe {
            // Note: Nws txhob txwm tias qhov no yog `>` thiab tsis `>=`.
            //       Hloov nws mus rau `>=` muaj qhov cuam tshuam tsis zoo hauv qee kis.
            //       Saib #78884 rau ntxiv.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// Extract tus hlais uas muaj tag nrho vector.
    ///
    /// Sib npaug rau `&s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Muab rho tawm tuaj yeem sib hlais tau ntawm tag nrho vector.
    ///
    /// Sib npaug rau `&mut s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Rov qab los ua ib lub npov pauv nyoos rau vector lub ntas ntim.
    ///
    /// Tus hu tuaj yuav tsum xyuas kom meej tias vector outlives tus pointer txoj haujlwm no rov qab los, lossis lwm yam nws yuav xaus mus rau taw taw rau khib nyiab.
    /// Hloov kho vector tej zaum yuav ua rau nws tsis tuaj yeem hloov kho, uas tseem yuav ua rau txhua tus taw tes rau nws siv tsis tau.
    ///
    /// Tus hu yuav tsum kuj ua kom paub meej tias lub cim xeeb lub pointer (non-transitively) cov ntsiab lus rau yog tsis tau sau rau (tshwj tsis yog sab hauv `UnsafeCell`) siv tus pointer no lossis txhua tus pointer muab los ntawm nws.
    /// Yog hais tias koj xav tau rau mutate tus txheem ntawm lub hlais, siv [`as_mut_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // Peb ntxoov ntxoo cov txheej txheem ntawm tib lub npe kom tsis txhob mus dhau `deref`, uas tsim cov ntaub ntawv siv nruab nrab.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Rov ib tug tsis zoo mutable pointer mus rau lub vector tus tsis.
    ///
    /// Tus hu tuaj yuav tsum xyuas kom meej tias vector outlives tus pointer txoj haujlwm no rov qab los, lossis lwm yam nws yuav xaus mus rau taw taw rau khib nyiab.
    ///
    /// Hloov kho vector tej zaum yuav ua rau nws tsis tuaj yeem hloov kho, uas tseem yuav ua rau txhua tus taw tes rau nws siv tsis tau.
    ///
    /// # Examples
    ///
    /// ```
    /// // Faib vector loj txaus rau 4 ntsiab.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Pib cov ntsiab ntawm cov pointer nyoo sau, tom qab ntawd teev ntev.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // Peb ntxoov ntxoo cov txheej txheem ntawm tib lub npe kom tsis txhob mus dhau `deref_mut`, uas tsim cov ntaub ntawv siv nruab nrab.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Rov qab xa mus rau cov hauv paus hauv paus kev faib nyiaj.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// Yaum qhov ntev ntawm vector rau `new_len`.
    ///
    /// Qhov no yog kev ua haujlwm qis-tsawg uas ua rau tsis muaj ib qho kev muaj peev xwm ntawm cov tau txais hom.
    /// Nquag hloov qhov ntev ntawm vector tau ua tiav siv ib txoj haujlwm nyab xeeb, xws li [`truncate`], [`resize`], [`extend`], lossis [`clear`].
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` yuav tsum tsawg dua los sis sib npaug [`capacity()`].
    /// - Cov ntsiab lus ntawm `old_len..new_len` yuav tsum tau pib.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// Hom no tuaj yeem pab tau rau cov xwm txheej uas vector ua haujlwm tsis ua haujlwm rau lwm qhov chaws, tshwj xeeb tshaj yog FFI:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // Nov tsuas yog cov pob txha tsawg kawg rau cov doc piv txwv;
    /// # // tsis txhob siv qhov no yog qhov chaw pib rau lub tsev qiv ntawv tiag tiag.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // Nyob rau daim FFI txoj kev ntawv, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // KEV RUAJ NTSEG: Thaum `deflateGetDictionary` rov `Z_OK`, nws tuav tias:
    ///     // 1. `dict_length` tau pib txheej txheem.
    ///     // 2.
    ///     // `dict_length` <=lub peev xwm (32_768) uas ua rau `set_len` nyab xeeb hu.
    ///     unsafe {
    ///         // Ua rau FFI hu ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... thiab hloov qhov ntev mus rau dab tsi tau pib ua tiav.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// Thaum cov piv txwv nram qab no yog lub suab, muaj lub cim xeeb xau txij thaum sab hauv vectors tsis tau tso tawm ua ntej `set_len` hu:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` qhov khoob yog li tsis muaj cov ntsiab lus xav tau los ua qhov pib.
    /// // 2. `0 <= capacity` ib txwm tuav xijpeem `capacity` yog.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// Feem ntau, ntawm no, ib tug yuav siv [`clear`] es tsis txhob kom raug poob lub txheem thiab li tsis los nco.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// Tshem tawm qhov khoom xa tawm ntawm vector thiab rov xa nws.
    ///
    /// Lub caij tshem tawm yog hloov los ntawm lub caij kawg ntawm lub vector.
    ///
    /// Qhov no tsis muaj khaws cia xaj, tab sis yog O(1).
    ///
    /// # Panics
    ///
    /// Panics yog `index` tawm ntawm qhov tsis muaj ciam.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // Peb hloov tus kheej [Performance index] nrog lub caij kawg.
            // Nco ntsoov tias yog cov ciam teb dhau los ua tiav qhov yuav tsum muaj lub caij kawg (uas tuaj yeem yog tus kheej [Performance index] nws tus kheej).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// Ntxig rau ib qho khoom ntawm txoj haujlwm `index` tsis pub dhau lub vector, hloov xa tag nrho cov ntsiab lus tom qab nws mus rau sab xis.
    ///
    ///
    /// # Panics
    ///
    /// Panics yog `index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // chaw rau lub caij tshiab
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // infallible Lub chaw tso cov nqi tshiab
            //
            {
                let p = self.as_mut_ptr().add(index);
                // Hloov txhua yam kom dhau qhov chaw.
                // (Ua ntxiv rau qhov 'Performance`th ntu rau hauv ob qho chaw sib law liag.)
                ptr::copy(p, p.offset(1), len - index);
                // Sau rau hauv, sau dua thawj daim qauv ntawm qhov ntsuas 'ntawm.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// Tshem tawm thiab xa cov khoom rov qab los ntawm txoj hauj lwm `index` hauv vector, hloov tag nrho cov ntsiab lus tom qab nws mus rau sab laug.
    ///
    ///
    /// # Panics
    ///
    /// Panics yog `index` tawm ntawm qhov tsis muaj ciam.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // qhov chaw peb noj los ntawm.
                let ptr = self.as_mut_ptr().add(index);
                // luam tawm nws, unsafely muaj daim ntawv theej ntawm tus nqi ntawm cov pawg thiab hauv vector tib lub sijhawm.
                //
                ret = ptr::read(ptr);

                // Hloov txhua yam hauv kev sau kom pom qhov chaw ntawd.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// Cov ntsiab lus tsuas yog cov khoom uas tau teev tseg los ntawm predicate.
    ///
    /// Hauv lwm lo lus, tshem tag nrho cov ntsiab `e` xws tias `f(&e)` rov `false`.
    /// Qhov txheej txheem no ua haujlwm hauv chaw, mus xyuas txhua ntu ib zaug ib zaug hauv thawj daim ntawv xaj, thiab khaws cov kev txiav txim ntawm cov ntsiab lus khaws cia.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// Vim tias cov khoom tau ntsib qhov tseeb ib zaug hauv thawj daim ntawv txiav txim, lub xeev sab nraud yuav raug siv los txiav txim siab saib cov khoom twg.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // Tsis txhob muab ob npaug rau nco yog tias txoj kev nco khwb yog tsis tseg, vim tej zaum peb yuav ua ib co qhov thaum lub sij hawm tus txheej txheem.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-txheej txheem len-> |^-txuas ntxiv mus xyuas
        //                  | <-deleted cnt-> |
        //      | <-original_len-> |Cia: Cov ntsiab lus uas predicate rov rau qhov tseeb ntawm.
        //
        // Tag Nrho: Tsiv los yog nqis lub qhov.
        // Unchecked: Unchecked cov ntsiab lus siv tau.
        //
        // Cov neeg zov me nyuam poob qis no yuav raug caw thaum predicate lossis `drop` ntawm cov khoom ntxeem tau.
        // Nws hloov cov khoom tsis kuaj xyuas kom npog lub qhov thiab `set_len` rau qhov ntev.
        // Nyob rau hauv tus neeg mob thaum predicate thiab `drop` yeej tsis panick, nws yuav tau optimized tawm.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // KEV RUAJ NTSEG: Yuav tsum muaj cov khoom thauj uas tsis kuaj xyuas kom siv tau txij li peb ib txwm tsis chwv lawv.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // KEV RUAJ NTSEG: Tom qab sau qhov, tag nrho cov khoom yog nyob hauv qhov cim xeeb.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // KEV RUAJ NTSEG: Cov caij tsis raug kuaj xyuas yuav tsum siv tau.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // Ua ntej kom ntxov kom tsis txhob poob qis dua yog tias `drop_in_place` panicked.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // KEV RUAJ NTSEG: Peb yeej tsis kov no caij dua tom qab poob.
                unsafe { ptr::drop_in_place(cur) };
                // Peb twb tau tshaj tawm lub txee.
                continue;
            }
            if g.deleted_cnt > 0 {
                // KEV RUAJ NTSEG: `deleted_cnt`> 0, yog li lub qhov qhov yuav tsum tsis sib tshooj nrog tam sim no lub caij.
                // Peb siv daim qauv rau txav, thiab tsis txhob kov cov khoom no dua.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // Txhua yam khoom ua tiav.Qhov no tuaj yeem tsim kho kom zoo rau `set_len` los ntawm LLVM.
        drop(g);
    }

    /// Tshem tawm tag nrho, tiam sis cov thawj ntawm sib law liag hais nyob rau hauv lub vector uas thiaj yuav tib qhov tseem ceeb.
    ///
    ///
    /// Yog hais tias lub vector yog txheeb, qhov no tshem tawm tag nrho duplicates.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// Tshem tag nrho tab sis thawj zaug ntawm cov ntsiab lus sib law liag hauv vector satisfying txoj kev sib txig sib luag.
    ///
    /// Lub `same_bucket` muaj nuj nqi yog xa mus ua pov thawj rau ob lub ntsiab los ntawm vector thiab yuav tsum txiav txim siab yog tias cov khoom sib piv sib npaug.
    /// Cov ntsiab lus dhau los hauv kev rov qab kev txiav txim los ntawm lawv cov kev txiav txim hauv cov hlais, yog li `same_bucket(a, b)` rov `true`, `a` tshem tawm.
    ///
    ///
    /// Yog hais tias lub vector yog txheeb, qhov no tshem tawm tag nrho duplicates.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// Tshaj tawm lub ntsiab rau sab nraum qab ntawm kev sau.
    ///
    /// # Panics
    ///
    /// Panics yog qhov muaj peev xwm tshiab tshaj `isize::MAX` bytes.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // Qhov no yuav panic lossis rho tawm yog tias peb yuav faib> isize::MAX bytes lossis yog tias qhov ntev nce yuav tshaj rau cov hom xoom.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// Tshem tawm lub ntsiab kawg los ntawm vector thiab rov muab nws, lossis [`None`] yog tias tsis muaj dab tsi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// Tsiv tag nrho cov ntsiab lus ntawm `other` rau hauv `Self`, tawm hauv `other` qhov khoob.
    ///
    /// # Panics
    ///
    /// Panics yog tias tus naj npawb ntawm cov khoom hauv vector dhau tus nqi `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// Tso cov ntsiab rau `Self` los ntawm lwm yam tsis.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// Tsim cov kav dej tawm uas tshem cov kab hauv vector thiab yields cov khoom tshem tawm.
    ///
    /// Thaum tus ntsuas pa **yog** poob qis, txhua yam hauv qhov ntau yog tshem tawm ntawm vector, txawm hais tias tus ntsuas tsuas tsis tau noj tag nrho.
    /// Yog tias tus ntsuas hluav taws xob **tsis yog** tshem tawm (nrog [`mem::forget`] piv txwv), nws yog qhov tsis paub tseeb tias muaj pes tsawg lub ntsiab lus tshem tawm.
    ///
    /// # Panics
    ///
    /// Panics yog tias qhov pib pib loj tshaj qhov taw tes kawg lossis yog tias qhov xaus taw tes ntau dua qhov ntev ntawm vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // Ib daim ntawv qhia txog ntau yam clears vector
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Kev nyab xeeb nco
        //
        // Thaum lub Drain yog thawj tsim, nws shortens qhov ntev ntawm lub qhov vector kom paub tseeb tias tsis muaj uninitialized los yog tsiv-los ntawm cov ntsiab no puas siv tau nyob rau hauv tag nrho cov yog hais tias tus Drain lub destructor yeej tsis tau txais khiav.
        //
        //
        // Drain yuav ptr::read tawm qhov tseem ceeb rau tshem tawm.
        // Thaum ua tiav, tshuav tus Tsov tus tw ntawm daim vec tau theej rov qab los npog lub qhov, thiab vector qhov ntev tau rov ua qhov ntev tshiab.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // teeb self.vec ntev lub pib, kom muaj kev nyab xeeb nyob rau hauv rooj plaub Drain yog qhov xau
            self.set_len(start);
            // Siv cov ntawv qiv hauv IterMut los qhia txog kev qiv qiv tus cwj pwm ntawm tag nrho Drain tus ntsuas (zoo li &mut T).
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// Ua kom huv vector, tshem tag nrho cov nqi.
    ///
    /// Nco ntsoov tias hom no tsis muaj kev cuam tshuam rau cov peev txheej uas tau faib vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// Rov qab tus naj npawb ntawm cov khoom hauv vector, kuj tseem hu ua nws 'length'.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Rov qab `true` yog tias vector tsis muaj cov ntsiab lus.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Caws cov khoom sib sau ua ob qho ntawm qhov ntsuas.
    ///
    /// Rov qab tau ZXvector0Z tshiab tso rau cov khoom hauv thaj tsam `[at, len)`.
    /// Tom qab hu, tus thawj vector yuav sab laug muaj cov khoom `[0, at)` nrog nws lub peev xwm yav dhau los tsis hloov.
    ///
    ///
    /// # Panics
    ///
    /// Panics yog `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // Tus vector tshiab tuaj yeem coj tus thawj tsis thiab zam daim ntawv theej
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // Tsis zoo chaw `set_len` thiab luam khoom rau `other`.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// Resizes `Vec`-hauv-chaw kom `len` sib npaug rau `new_len`.
    ///
    /// Yog tias `new_len` loj dua `len`, `Vec` txuas ntxiv los ntawm qhov sib txawv, nrog txhua qhov ntxiv ntxiv ntim nrog qhov txiaj ntsig ntawm hu xov tooj kaw `f`.
    ///
    /// Tus nqi xa rov qab los ntawm `f` yuav xaus rau qhov `Vec` hauv qhov kev txiav txim uas lawv tau tsim tawm.
    ///
    /// Yog tias `new_len` tsawg dua `len`, `Vec` tsuas yog siv sijhawm luv luv.
    ///
    /// Txoj kev no siv lub kaw los tsim cov txiaj ntsig tshiab ntawm txhua lub laub.Yog tias koj xav [`Clone`] qhov muab tus nqi, siv [`Vec::resize`].
    /// Yog tias koj xav siv [`Default`] trait los tsim kom muaj nuj nqis, koj tuaj yeem dhau [`Default::default`] li kev sib cav zaum ob.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// Noj thiab txia lub `Vec`, rov qab ib tug mutable kev siv rau tus txheem, `&'a mut [T]`.
    /// Nco ntsoov tias hom `T` yuav tsum outlive tus xaiv lub neej `'a`.
    /// Yog tias hom tau tsuas yog cov ntawv pov thawj zoo li qub, lossis tsis muaj hlo li, ces qhov no yuav raug xaiv los ua `'static`.
    ///
    /// Txoj haujlwm no zoo ib yam li [`leak`][Box::leak] muaj nuj nqi ntawm [`Box`] tsuas yog tsis muaj txoj hauv kev los ua kom rov muaj lub cim xeeb xau.
    ///
    ///
    /// Txoj haujlwm no yog qhov tseem ceeb rau cov ntaub ntawv uas nyob rau qhov seem ntawm qhov kev pab cuam lub neej.
    /// Xa qhov xa rov qab yuav ua rau lub cim xeeb xau.
    ///
    /// # Examples
    ///
    /// Kev siv yooj yim:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// Rov qab los ntxiv cov khoom seem seem ntawm vector uas yog ib qho ntawm `MaybeUninit<T>`.
    ///
    /// Cov rov qab hlais yuav siv tau los sau cov vector uas muaj ntaub ntawv (xws li
    /// los ntawm nyeem ntawm cov ntaub ntawv) ua ntej khij cov ntaub ntawv raws li kev pib siv tus txheej txheem [`set_len`].
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // Faib vector loj txaus rau 10 ntsiab.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // Sau rau thawj 3 yam.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // Kos rau thawj 3 yam ntawm vector li tab tom pib.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // Qhov no yog tsis siv nyob rau hauv cov nqe lus ntawm `split_at_spare_mut`, los mus tiv thaiv invalidation ntawm pointers rau cov tsis.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// Rov qab vector cov ntsiab lus raws li xaj ntawm `T`, nrog rau cov khoom seem seem ntawm vector ua ib qho ntawm `MaybeUninit<T>`.
    ///
    /// Cov rov qab spare peev xwm hlais yuav siv tau los sau cov vector uas muaj ntaub ntawv (xws li los ntawm kev nyeem ntawm ib cov ntaub ntawv) ua ntej npav cov ntaub ntawv raws li initialized siv cov [`set_len`] txoj kev.
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// Nco ntsoov tias qhov no yog qib API qis, uas yuav tsum tau siv nrog saib xyuas rau lub hom phiaj txhim kho.
    /// Yog tias koj xav txuas cov ntaub ntawv ntxiv rau `Vec` koj tuaj yeem siv [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] lossis [`resize_with`], nyob ntawm koj cov kev xav tau.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // Tseg chaw ntxiv loj rau 10 yam.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // Sau rau 4 yam tom ntej no.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // Kos rau 4 lub ntsiab ntawm vector li tab tom pib.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - len yog kav liam thiab yog li tsis hloov
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// Kev Nyab Xeeb: Hloov rov qab .2 (&mut usize) yog suav hais tias yog tib yam li hu `.set_len(_)`.
    ///
    /// Txoj kev no yog siv kom muaj qhov tshwj xeeb rau txhua qhov vec ib zaug hauv `extend_from_within`.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` yog lav tias siv tau rau `len` lub ntsiab
        // - `spare_ptr` yog taw ib lub caij dhau los tsis, yog li nws tsis tshaj nrog `initialized`
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// Resizes `Vec`-hauv-chaw kom `len` sib npaug rau `new_len`.
    ///
    /// Yog tias `new_len` loj dua `len`, `Vec` txuas ntxiv los ntawm qhov sib txawv, nrog txhua qhov ntxiv ntxiv ntim nrog `value`.
    ///
    /// Yog tias `new_len` tsawg dua `len`, `Vec` tsuas yog siv sijhawm luv luv.
    ///
    /// Cov qauv no xav kom `T` siv [`Clone`], thiaj li tuaj yeem ua rau clone tus nqi dhau los.
    /// Yog tias koj xav tau qhov hloov tau yooj yim (lossis xav kom cia siab rau [`Default`] hloov [`Clone`]), siv [`Vec::resize_with`].
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// Clones thiab ntxiv rau txhua qhov hauv ib qho me me rau `Vec`.
    ///
    /// Iterates tshaj qhov hlais `other`, clones txhua qhov chaw, thiab tom qab ntawd ces ntxiv nws rau qhov `Vec`.
    /// Lub `other` vector yog hloov pauv hauv kev txiav txim.
    ///
    /// Nco ntsoov tias txoj haujlwm no zoo ib yam li [`extend`] tshwj tsis yog tias nws tshwj xeeb los ua haujlwm nrog hlais hloov.
    ///
    /// Yog hais tias thiab thaum twg Rust tau txais specialization no muaj nuj nqi yuav tsum deprecated (tab sis tseem muaj).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// Luam tawm cov ntsiab lus los ntawm `src` ntau kawg mus txog rau vector.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` guarantees tias qhov ntau muab rau siv tau rau kev ntsuas tus kheej
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// Qhov no code generalizes `extend_with_{element,default}`.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Tshaj tawm vector los ntawm `n` qhov tseem ceeb, siv lub tshuab hluav taws xob.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // Siv SetLenOnDrop ua haujlwm ncig kab laum nyob qhov twg compiler tej zaum yuav tsis paub txog lub khw mus txog `ptr` dhau self.set_len() tsis muaj npe.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Sau tag nrho cov ntsiab lus tshwj tsis yog kawg
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // Nce qhov ntev hauv txhua kauj ruam hauv rooj plaub next() panics
                local_len.increment_len(1);
            }

            if n > 0 {
                // Peb tuaj yeem sau cov khoom kawg kom ncaj ncaj yam tsis xav tau yam tsis xav tau
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // len teem los ntawm tus saib xyuas raws
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// Tuskheej sib law liag rov hais nyob rau hauv lub vector raws li lub [`PartialEq`] trait siv.
    ///
    ///
    /// Yog hais tias lub vector yog txheeb, qhov no tshem tawm tag nrho duplicates.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Cov txheej txheem sab hauv thiab cov haujlwm
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` yuav tsum tau siv tau nws
    /// - `self.capacity() - self.len()` yuav tsum yog `>= src.len()`
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - len yog nce tsuas yog tom qab pib cov khoom
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - cov neeg hu rau guaratees tias src yog qhov siv tau
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - Lub caij nyoog nyuam qhuav pib nrog `MaybeUninit::write`, yog li nws tau mus nce qib len
            // - len tau nce ntxiv tom qab txhua ntu los tiv thaiv kev xau (saib qhov teeb meem #82533)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - hem xov tooj guaratees tias `src` yog qhov siv tau ntsuas
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - Ob lub ntsiab lus raug tsim los ntawm cov cim sib txawv (`&mut [_]`) yog li lawv siv tau thiab tsis txhob sib tshooj.
            //
            // - Cov ntsiab lus yog: Luam tawm kom nws thiaj li tuaj yeem theej lawv, tsis tas ua dab tsi nrog cov khoom qub
            // - `count` yog sib npaug ntawm len ntawm `source`, yog li cov ntawv siv tau rau `count` nyeem
            // - `.reserve(count)` tuaj yeem lav tias `spare.len() >= count` yog li spare yuav siv tau rau `count` sau
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - Cov khoom tseem nyuam qhuav pib los ntawm `copy_nonoverlapping`
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Common trait implementations rau Vec
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): nrog cfg(test) qhov txais tau `[T]::to_vec` txoj kev, uas yuav tsum muaj rau cov qauv ntsiab lus no, tsis muaj.
    // Hloov siv `slice::to_vec` kev ua haujlwm uas tsuas yog muaj nrog cfg(test) NB pom slice::hack module hauv slice.rs rau cov ntaub ntawv ntau
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // muab txhua yam uas yuav tsis tau muab sau cia
        self.truncate(other.len());

        // self.len <= other.len vim qhov muaj qhov txwv qhov saum toj no, yog li cov hlais ntawm no ib txwm nyob hauv-ciam teb.
        //
        let (init, tail) = other.split_at(self.len());

        // rov qab siv lub cim muaj nuj nqi allocations/resources.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// Tsim ib tug siv iterator, uas yog, ib tug uas tsiv txhua nqi tawm ntawm lub vector (los ntawm pib xaus).
    /// Lub vector yuav siv tsis tau tom qab hu no.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s muaj hom hlua, tsis &String
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // txoj kev tawm uas ntau SpecFrom/SpecExtend kev nqis tes ua tus sawv cev thaum lawv tsis muaj kev txhim kho ntxiv thov
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // Nov yog qhov xwm txheej rau tus ua haujlwm thoob plaws.
        //
        // Txoj haujlwm no yuav tsum yog kev coj ncaj ncees ntawm:
        //
        //      rau yam khoom hauv iterator {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // NB tsis tuaj yeem thim vim peb yuav tau faib qhov chaw nyob
                self.set_len(len + 1);
            }
        }
    }

    /// Tsim ib tug splicing iterator uas tau ntau xyoo lub teev ntau yam nyob rau hauv lub vector nrog qhov muab `replace_with` iterator thiab yields cov raug tshem tawm yam khoom.
    ///
    /// `replace_with` tsis tas yuav muaj qhov ntev tib yam li `range`.
    ///
    /// `range` yog muab tshem tawm txawm hais tias tus kws ntsuas tsis tau noj mus txog thaum kawg.
    ///
    /// Nws tsis paub meej pes tsawg lub ntsiab lus raug tshem tawm ntawm vector yog tias tus nqi `Splice` tau xauj.
    ///
    /// Cov lus qhia tus ntsuas kub `replace_with` tsuas yog siv thaum `Splice` tus nqi.
    ///
    /// Qhov no yog qhov zoo tshaj yog tias:
    ///
    /// * Tus Tsov tus tw (hais nyob rau hauv lub vector tom qab `range`) yog npliag,
    /// * lossis `replace_with` yields tsawg dua lossis sib npaug ntawm ntau dua li 'ntau yam' ntev
    /// * lossis qhov nqes qis ntawm nws `size_hint()` yog qhov tseeb.
    ///
    /// Txwv tsis pub, ib ntus vector tau faib thiab tus Tsov tus tw pauv ob zaug.
    ///
    /// # Panics
    ///
    /// Panics yog tias qhov pib pib loj tshaj qhov taw tes kawg lossis yog tias qhov xaus taw tes ntau dua qhov ntev ntawm vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// Tsim tus ntsuas hluav taws xob uas siv kaw kom txiav txim siab yog tias ib qho khoom siv yuav tsum tau muab tshem tawm.
    ///
    /// Yog tias qhov kaw rov qab yog qhov tseeb, tom qab lub ntsiab lus raug tshem tawm thiab npaj tawm.
    /// Yog tias qhov kev kaw rov qab ua tsis raug, lub keeb yuav nyob hauv vector thiab yuav tsis muaj txiaj ntsig los ntawm tus ntsuas pa.
    ///
    /// Siv tus qauv no sib npaug rau cov cai hauv qab no:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // koj qhov chaws nyob ntawm no
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// Tab sis `drain_filter` yog qhov yooj yim siv.
    /// `drain_filter` kuj tseem muaj txiaj ntsig ntau dua, vim tias nws tuaj yeem rov qab tau cov ntsiab lus ntawm qhov sib dhos hauv qhov loj.
    ///
    /// Nco ntsoov tias `drain_filter` kuj tseem cia koj hloov txhua lub keeb hauv lub lim, tsis hais seb koj puas yuav khaws lossis tshem nws.
    ///
    ///
    /// # Examples
    ///
    /// Caws ib qho array rau hauv evens thiab txawv, rov siv daim ntawv faib thawj:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Khwb tiv thaiv peb kom peb xau tawm (cov dej xau)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Nthuav kev siv uas luam cov ntsiab lus tawm ntawm cov ntawv xa mus ua ntej thawb lawv mus rau Vec.
///
/// Qhov kev siv no yog tshwj xeeb rau cov nplais hlais, qhov chaw uas nws siv [`copy_from_slice`] los txuas ntxiv rau cov hlais tag nrho ib zaug.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// Pauv kev sib piv ntawm vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// Kev coj ua ntawm vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // siv poob rau [T] siv lub hlais nyoos xa mus rau cov ntsiab lus ntawm vector ua qhov tsim nyog qis tshaj yam;
            //
            // yuav tsis txhob nug ntawm validity nyob rau hauv tej yam mob
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec saib xyuas kev ua haujlwm
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// Tsim cov khoob `Vec<T>`.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: xeem rub tawm hauv libstd, uas ua rau muaj qhov yuam kev ntawm no
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: xeem rub tawm hauv libstd, uas ua rau muaj qhov yuam kev ntawm no
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// Tau txais tag nrho cov ntsiab lus ntawm `Vec<T>` raws li ib qho kev ntsuas, yog tias nws qhov loj raws nraim cov ntawm qhov tau thov.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// Yog tias qhov ntev tsis phim, cov lus nkag rov qab hauv `Err`:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// Yog tias koj nyob nraum zoo nrog nyuam qhuav tau txais kev ua ntej ntawm `Vec<T>`, koj tuaj yeem hu [`.truncate(N)`](Vec::truncate) ua ntej.
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // KEV RUAJ NTSEG: `.set_len(0)` yog lub suab tas li.
        unsafe { vec.set_len(0) };

        // KEV RUAJ NTSEG: Ib tus `Vec` tus pointer yog ib txwm sis thooj li, thiab
        // Cov kev hloov pauv lub hauv paus xav tau yog tib yam li cov khoom.
        // Peb tau kuaj xyuas ua ntej uas peb muaj khoom txaus.
        // Cov khoom yuav tsis poob ob npaug raws li `set_len` qhia `Vec` tsis tas tso lawv.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}