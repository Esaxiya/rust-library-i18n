use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Specialization marker sau ib iterator pipeline rau hauv ib lub Vec thaum reusing qhov nyiaj, piv txwv li
/// ua kom tiav cov raj xa dej hauv qhov chaw.
///
/// SourceIter niam txiv trait yog qhov tsim nyog rau lub luag haujlwm tshwj xeeb kom nkag mus rau cov kev faib uas yuav tsum tau rov siv dua.
/// Tab sis nws tsis txaus rau qhov tshwj xeeb yuav siv tau.
/// Saib ntxiv ciam teb ntawm qhov chaw.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// Lub std-nrog SourceIter/InPlaceIterable traits tsuas siv los ntawm chains ntawm Adapter <Adapter<Adapter<IntoIter>>> (txhua tus los ntawm core/std).
// Cov ciaj ciam txuas ntxiv ntawm cov kev ua tiav adapter (tshaj `impl<I: Trait> Trait for Adapter<I>`) tsuas yog nyob ntawm lwm tus traits twb tau cim raws li kev ua haujlwm tshwj xeeb traits (Daim Ntawv, TrustedRandomAccess, FusedIterator).
//
// I.e. Lub cim khij tsis nyob ntawm lub neej ntawm cov neeg siv khoom-hom.Modulo lub Copy qhov, uas ob peb lwm specializations twb nyob ntawm seb.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Ib qho uas xav tau ntxiv uas tsis tuaj yeem piav qhia los ntawm trait bounds.Peb cia siab rau const eval hloov:
        // a) tsis muaj ZSTs li yuav muaj tsis muaj nyiaj rov qab siv thiab pointer xam yuav panic b) loj match li yuav tsum tau los ntawm Alloc daim ntawv cog lus c) alignments phim li yuav tsum tau los ntawm daim ntawv cog lus Alloc
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // rov qab los rau cov kev siv ntau yam
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // siv sim-khawm txij li
        // - nws vectorizes zoo dua rau qee qhov ntsuas hluav taws xob
        // - Tsis zoo li feem ntau hauv iteration txoj kev, nws tsuas yog siv &mut tus kheej
        // - nws cia peb xov tus sau pointer los ntawm nws cov innards thiab tau txais nws rov kawg
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // iteration succeeded, tsis txhob poob lub taub hau
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // xyuas yog tias SourceIter daim ntawv cog lus tau txhim kho tsis txaus siab: yog tias lawv tsis yog peb yuav tsis txawm tias ua nws mus txog qhov no
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // tshawb xyuas InPlaceIterable daim ntawv cog lus.Qhov no tsuas ua tau yog tias tus tsim teeb tsa lub hauv paus taw qhia txhua lub sijhawm.
        // Yog tias nws siv kev kuaj xyuas tsis raug kuaj ntawm TrustedRandomAccess ces lub hauv paus pointer yuav nyob hauv nws txoj haujlwm pib thiab peb tsis tuaj yeem siv nws raws li siv
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // tso cov nqe uas tseem tshuav nyob ntawm tus Tsov tus tw keeb kwm tab sis tiv thaiv qhov poob ntawm txoj kev faib nws tus kheej ib zaug IntoIter mus tsis muaj peev xwm yog tias poob panics ces peb kuj xau cov ntsiab lus sau rau hauv dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // lub InPlaceIterable ntawv cog lus yuav tsis muaj tseeb precisely no txij li thaum try_fold muaj ib tug tsuas yog siv mus rau qhov chaw pointer txhua yam peb ua yog daim tshev yog hais tias nws tseem nyob rau hauv ntau yam
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}