use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // Sau qhov kev ntsuas ntawm kev sib xyaw ntawm cov neeg sab nraud thiab `RawVec` yog qhov muaj qhov tsis yooj yim vim tias `RawVec` API tsis qhia txog cov kev faib tawm hauv lub koom haum, yog li peb tsis tuaj yeem kuaj pom tias muaj dab tsi tshwm sim thaum cov neeg faib khoom tau sab dhau (dhau ntawm kev tshawb pom panic).
    //
    //
    // Hloov chaw, qhov no tsuas yog kuaj xyuas tias cov `RawVec` cov hau kev ua tsawg kawg tau mus los ntawm Allocator API thaum nws muaj chaw cia.
    //
    //
    //
    //
    //

    // Tus neeg ruam siv cov roj hauv nws tus kheej ua ntej kev npaj yuav pib poob.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (ua rau muaj qhov hloov chaw tiag tiag, yog li siv 50 + 150=200 units ntawm cov roj)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // Ua ntej, `reserve` faib li `reserve_exact`.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 yog ntau tshaj ob npaug ntawm 7, yog li `reserve` yuav tsum ua haujlwm zoo li `reserve_exact`.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 yog tsawg dua li ib nrab ntawm 12, yog li `reserve` yuav tsum loj hlob tshaj tawm.
        // Thaum lub sijhawm sau cov ntawv ntsuas kev loj hlob qhov ntsuas no yog 2, yog li lub peev xwm tshiab yog 24, txawm li cas los xij, kev loj hlob ntawm 1.5 yog OK dhau lawm.
        //
        // Li no `>= 18` hauv kev lees paub.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}