//! Lub alloc Prelude
//!
//! Lub hom phiaj ntawm cov qauv no yog txhawm rau txo cov kev xa khoom ntawm cov khoom siv uas nquag siv ntawm `alloc` crate los ntawm kev ntxiv cov khoom ntshuam nkag mus rau sab saum toj ntawm cov modules:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;