#![stable(feature = "rust1", since = "1.0.0")]

//! Xov-yas siv-suav cov lus taw qhia.
//!
//! Saib cov ntaub ntawv [`Arc<T>`][Arc] rau cov ntaub ntawv ntau ntxiv.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// Qhov muag muag ntawm qhov xa tus nqi xa mus rau `Arc` X.
///
/// Mus dhau qhov kev txwv no yuav rho koj txoj haujlwm (txawm tias tsis tas yuav) ntawm _exactly_ `MAX_REFCOUNT + 1` cov ntawv xa mus.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer tsis txhawb nqa cov laj kab cim xeeb.
// Txhawm rau kom tsis txhob muaj cov lus qhia tsis zoo nyob hauv Arc/Weak siv siv atomic loads rau synchronization hloov.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Xov-zoo siv-suav cov pointer.'Arc' sawv rau 'Atomically Xaj Suav Suav'.
///
/// Hom `Arc<T>` muab cov tswv cuab sib koom ua ke ntawm tus nqi ntawm hom `T`, faib hauv cov heap.Kev hais tawm [`clone`][clone] ntawm `Arc` tsim cov khoom tshiab `Arc`, uas taw qhia rau tib cov kev faib tawm ntawm lub pob taws yog qhov chaw `Arc`, thaum nce kev siv suav suav.
/// Thaum tus `Arc` kawg ntawm tus taw qhia rau qhov muab faib yog rhuav tshem, tus nqi khaws cia hauv qhov kev faib ntawd (feem ntau hu ua "inner value") kuj tseem nqis.
///
/// Cov ntawv qhia ua ke hauv Rust tsis pom zoo hloov chaw los ntawm lub neej yav dhau los, thiab `Arc` tsis muaj kev zam: koj tsis tuaj yeem feem ntau muab ib qho lus piav qhia rau qee yam hauv `Arc`.Yog hais tias koj xav tau rau mutate los ntawm ib tug `Arc`, siv [`Mutex`][mutex], [`RwLock`][rwlock], los yog ib tug ntawm cov [`Atomic`][atomic] hom.
///
/// ## Xov Kev Nyab Xeeb
///
/// Tsis zoo li [`Rc<T>`], `Arc<T>` siv atomic operations rau nws kev suav suav.Qhov no txhais tau hais tias nws yog xov-kev nyab xeeb.Lub disadvantage yog tias atomic ua hauj lwm yog kim kim dua zoo tib yam nco accesses.Yog hais tias koj tsis sib koom siv-suav nyiaj ntawm threads, muab siv [`Rc<T>`] rau sab nyiaj siv ua haujlwm.
/// [`Rc<T>`] yog qhov kev nyab xeeb vim tsis zoo, vim tias qhov compiler yuav ntes txhua qhov kev sim xa ib qho [`Rc<T>`] ntawm cov xov.
/// Txawm li cas los xij, lub tsev nyeem ntawv yuav xaiv `Arc<T>` txhawm rau ua kom cov neeg siv khoom qiv hauv tsev muaj kev hloov dua tshiab.
///
/// `Arc<T>` yuav siv [`Send`] thiab [`Sync`] ntev li ntev tau `T` ua raws [`Send`] thiab [`Sync`].
/// Vim li cas thiaj tsis tau koj tso lub hom xov-kev nyab xeeb `T` hauv `Arc<T>` kom nws xov-nyab xeeb?Qhov no tej zaum qhov tawm tsam me ntsis thaum xub thawj: tom qab txhua, tsis yog qhov tseem ceeb ntawm `Arc<T>` xov kev nyab xeeb?Qhov tseem ceeb yog qhov no: `Arc<T>` ua rau nws xov muaj kev nyab xeeb kom muaj ntau tus tswv ntawm tib cov ntaub ntawv, tab sis nws tsis ntxiv xov kev nyab xeeb rau nws cov ntaub ntawv.
///
/// Xav txog 'Arc <' ['RefCell<T>`]`> `.
/// [`RefCell<T>`] tsis yog [`Sync`], thiab yog `Arc<T>` ib txwm [`Send`], `Arc <` [`RefCell<T>']'> 'Yuav zoo li.
/// Tab sis tom qab ntawd peb yuav muaj teeb meem:
/// [`RefCell<T>`] tsis yog xov zoo;nws yuav khiav ntawm lub txais count siv uas tsis yog-atomic operations.
///
/// Nyob rau hauv lub kawg, qhov no txhais tau hais tias tej zaum koj yuav xav tau rau pair `Arc<T>` nrog ib co tsi [`std::sync`] hom, feem ntau yog [`Mutex<T>`][mutex].
///
/// ## Txhawm rau kis nrog `Weak`
///
/// Lub [`downgrade`][downgrade] txoj kev yuav siv tau los ua ib tug uas tsis yog-owning [`Weak`] pointer.Ib tug [`Weak`] pointer tau yuav ['upgrade`][txawj tej yam ntxiv] d mus rau ib qho `Arc`, tab sis qhov no yuav rov qab [`None`] hais tias tus nqi muab cia rau hauv lub qee twb tau poob.
/// Hauv lwm lo lus, `Weak` tus taw tes tsis khaws tus nqi hauv qhov kev faib ciaj sia;Txawm li cas los, lawv *tsis* kom lub qee (lub thaub qab khw rau tus nqi) ciaj sia.
///
/// Ib tug voj voog ntawm `Arc` pointers yuav tsis raug deallocated.
/// Vim li no, [`Weak`] yog siv los tawg cov voj voog.Piv txwv li, ib tsob ntoo tuaj yeem muaj zog `Arc` cov lus taw qhia los ntawm niam txiv caj rau me nyuam, thiab [`Weak`] cov lus taw qhia los ntawm cov menyuam yaus rov qab mus rau lawv niam lawv txiv.
///
/// # Cloning ntaub ntawv
///
/// Tsim cov ntawv qhia tshiab los ntawm ib qho kev siv tau suav-suav pointer yog ua tiav siv `Clone` trait siv rau [`Arc<T>`][Arc] thiab [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Ob syntaxes hauv qab no yog sib npaug.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b, thiab foo yog txhua Arcs uas taw rau tib qhov chaw cim xeeb
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` txiav dereferences rau `T` (dhau ntawm [`Deref`][deref] trait), yog li koj tuaj yeem hu `T` cov hau kev ntawm tus nqi ntawm hom `Arc<T>`.Txhawm rau zam lub npe clashes nrog `T` txoj kev, cov hau kev ntawm `Arc<T>` nws tus kheej yog cov haujlwm txuam nrog, hu ua siv [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `Arc<T>`Qhov kev siv ntawm traits zoo li `Clone` kuj tseem yuav raug hu ua siv cov khoom hluav taws xob tsim nyog.
/// Qee cov neeg nyiam siv cov ntawv uas tsim nyog ua tiav, thaum lwm tus neeg nyiam siv tus qauv-hu ua syntax.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Txoj kev-hu ua syntax
/// let arc2 = arc.clone();
/// // Tag nrho tsim nyog syntax
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] tsis pib-dereference rau `T`, vim hais tias lub puab nqi tej zaum yuav tau twb tau poob.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Sib qhia qee cov ntaub ntawv tsis tuaj yeem ntawm cov xov:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Nco ntsoov tias peb **tsis** khiav cov kev ntsuam xyuas no.
// Cov windows cov neeg tsim khoom tau txais kev tsis txaus siab super yog tias ib txoj xov hais tawm txoj xov tseem ceeb thiab tom qab ntawd tawm ntawm tib lub sijhawm (ib yam dab tsi raug kaw) yog li peb tsuas zam qhov no nkaus los ntawm tsis khiav cov kev sim no.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Sib koom ib [`AtomicUsize`] mutable:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Saib tus [`rc` documentation][rc_examples] rau cov piv txwv ntxiv ntawm kev suav suav dav dav.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` yog ib qho version ntawm [`Arc`] uas tuav qhov tsis yog tus kheej siv rau kev tswj hwm kev faib tawm.
/// Cov kev faib tawm yog nkag los ntawm kev hu rau [`upgrade`] ntawm `Weak` tus pointer, uas rov ua tus [`Xaiv`] `<` [`Arc`] `<T>>`.
///
/// Txij li thaum ib tug `Weak` siv tsis suav ntawm cov tswv cuab, nws yuav tiv thaiv tsis tau tus nqi muab cia rau hauv lub qee los poob, thiab `Weak` nws tus kheej ua rau tsis muaj guarantees txog tus nqi tseem ua tam sim no.
///
/// Yog li nws yuav xa rov qab [`None`] thaum [`upgrade`] d.
/// Nco ntsoov li cas los xij uas `Weak` siv *ua* tiv thaiv qhov kev faib nws tus kheej (lub khw muag khoom rov qab) los ntawm kev sib nkag siab.
///
/// Ib tus `Weak` pointer yog qhov muaj txiaj ntsig zoo rau kev khaws cia ib ntus mus rau kev faib tawm tswj hwm los ntawm [`Arc`] yam tsis muaj kev tiv thaiv nws sab hauv los ntawm kev poob qis.
/// Nws kuj tseem siv los tiv thaiv cov ntawv pov thawj ncig ntawm [`Arc`] cov lus taw qhia, txij li kev sib raug tus kheej tsis muaj cai yuav tsis tso cia [`Arc`] los tso tseg.
/// Piv txwv li, ib tsob ntoo tuaj yeem muaj zog [`Arc`] cov lus taw qhia los ntawm niam txiv caj rau me nyuam, thiab `Weak` cov lus taw qhia los ntawm cov menyuam yaus rov qab mus rau lawv niam lawv txiv.
///
/// Txoj kev uas nquag tau txais `Weak` pointer yog hu rau [`Arc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Qhov no yog `NonNull` kom tso cai rau qhov loj ntawm cov hom no hauv cov chaw enums, tab sis nws tsis tas yuav siv lub pointer siv tau.
    //
    // `Weak::new` teeb no rau `usize::MAX` kom nws tsis tas yuav faib qhov chaw ntawm qhov heap.
    // Tias'stsis muaj nqis ib lub pointer tiag tiag yuav puas tau vim tias RcBox muaj qhov sib txuam tsawg kawg 2.
    // Qhov no tsuas yog ua tau thaum `T: Sized`;unsized `T` yeej tsis dai tuag.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Qhov no yog repr(C) rau future-cov ntaub ntawv pov thawj tiv thaiv tsis tau cov teb-reordering, uas yuav cuam tshuam nrog lwm yam kev nyab xeeb [into|from]_raw() ntawm transmutable sab hauv hom.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // tus nqi usize::MAX ua raws li cov ntawv xa mus rau ib ntus "locking" lub peev xwm los txhim kho cov taw tes tsis muaj zog lossis txo qis kev ua kom muaj zog;qhov no yog siv kom tsis txhob muaj kev sib tw hauv `make_mut` thiab `get_mut`.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Tsim dua tshiab `Arc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Pib tus pointer tsis muaj zog suav ua 1 uas yog tus pointer tsis muaj zog uas tau tuav los ntawm txhua tus muaj zog taw qhia (kinda), saib std/rc.rs rau cov ntaub ntawv ntxiv
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Tsim tus tshiab `Arc<T>` siv qhov tsis muaj zog siv rau nws tus kheej.
    /// Sim ua kom hloov kho qhov tsis muaj zog ua ntej cov nuj nqi xa rov qab no yuav ua rau tus nqi `None`.
    /// Txawm li cas los xij, cov ntawv tsis muaj zog yuav raug cloned dawb thiab khaws cia rau siv tom qab.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Ua lub puab nyob rau hauv lub xeev "uninitialized" nrog ib qho tsis muaj zog siv.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Nws yog qhov tseem ceeb peb tsis txhob tso txoj kev ua tswv cuab ntawm tus pointer uas tsis muaj zog, los yog lwm yam lub cim xeeb yuav raug tso tawm thaum lub sijhawm `data_fn` rov los.
        // Yog tias peb xav hla dhau cov tswv cuab, peb tuaj yeem tsim qhov taw qhia tsis muaj zog ntxiv rau peb tus kheej, tab sis qhov no yuav ua rau muaj qhov hloov tshiab ntxiv rau cov ntaub ntawv tsis muaj zog suav uas yuav tsis tsim nyog.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Tam sim no peb tuaj yeem tsim kho qhov pib muaj nuj nqi sab hauv thiab tig peb lub zog tsis muaj zog siv rau hauv kev siv muaj zog.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Sau ntawv saum toj no rau hauv cov ntaub ntawv sau yuav tsum tau pom rau txhua qhov xov uas pom qhov tsis muaj-xoom muaj zog suav.
            // Yog li ntawd peb xav tau tsawg kawg "Release" xaj kom thiaj li sib xyaw nrog `compare_exchange_weak` hauv `Weak::upgrade`.
            //
            // "Acquire" kev xaj tsis tas yuav los.
            // Thaum xav txog qhov ua tau coj tus cwj pwm ntawm `data_fn` peb tsuas yog yuav tsum saib seb nws yuav ua li cas nrog kev siv rau qhov tsis yog hloov kho `Weak`:
            //
            // - Nws tau *clone* lub `Weak`, ua cov uas qaug zog siv suav.
            // - Nws tuaj yeem ua tiav cov xais ntawd, txo qis kev siv suav tsis muaj zog (tab sis yeej tsis tau rau xoom).
            //
            // Cov kev mob tshwm sim no tsis cuam tshuam rau peb nyob rau txhua txoj kev, thiab tsis muaj lwm yam kev mob tshwm sim nrog txoj cai nyab xeeb nkaus xwb.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Cov ntaub ntawv muaj zog yuav tsum sib koom ua ke siv tus kheej sib qhia siv tsis tau, yog li tsis txhob khiav lub destructor rau peb cov laus tsis muaj zog siv.
        //
        mem::forget(weak);
        strong
    }

    /// Ua dua tshiab `Arc` nrog cov ntsiab lus tsis tsim nyog.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Xa pib:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Ua dua tshiab `Arc` nrog cov ntsiab lus tsis tsim nyog, nrog lub cim xeeb tau sau nrog `0` bytes.
    ///
    ///
    /// Saib [`MaybeUninit::zeroed`][zeroed] piv txwv txog kev siv kom raug thiab tsis raug ntawm hom no.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Tsim dua tshiab `Pin<Arc<T>>`.
    /// Yog tias `T` tsis siv `Unpin`, ces `data` yuav pinned hauv lub cim xeeb thiab tsis tuaj yeem txav mus.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Tsim kho `Arc<T>` tshiab, rov qab los ua ib qho yuam kev yog qhov kev faib tsis tau.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Pib tus pointer tsis muaj zog suav ua 1 uas yog tus pointer tsis muaj zog uas tau tuav los ntawm txhua tus muaj zog taw qhia (kinda), saib std/rc.rs rau cov ntaub ntawv ntxiv
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Ua lub `Arc` tshiab nrog cov txheej txheem tsis muaj qhov cim cia, rov qab los ua ib qho yuam kev yog qhov kev faib tawm tsis ua tiav.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Xa pib:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Ua lub `Arc` tshiab nrog cov txheej txheem tsis muaj qhov cim cia, nrog lub cim xeeb tau sau nrog `0` bytes, rov ua yuam kev yog tias kev faib tawm tsis ua haujlwm.
    ///
    ///
    /// Saib [`MaybeUninit::zeroed`][zeroed] piv txwv txog kev siv kom raug thiab tsis raug ntawm hom no.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Rov qab rau sab hauv tus nqi, yog `Arc` muaj raws nraim ib qho siv muaj zog.
    ///
    /// Txwv tsis pub, ib qho [`Err`] xa rov qab nrog tib `Arc` uas tau dhau mus.
    ///
    ///
    /// Qhov no yuav ua tiav txawm tias muaj cov ntaub ntawv tsis muaj zog txaus.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Ua ib qho qaug zog pointer los ntxuav cov implicit tsis muaj zog-tsis muaj kev siv
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Constructs ib tug tshiab atomically siv-suav hlais nrog uninitialized txheem.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Xa pib:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Constructs ib tug tshiab atomically siv-suav hlais nrog uninitialized txheem, nrog lub cim xeeb puv npo nrog `0` bytes.
    ///
    ///
    /// Saib [`MaybeUninit::zeroed`][zeroed] piv txwv txog kev siv kom raug thiab tsis raug ntawm hom no.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Hloov pauv mus rau `Arc<T>`.
    ///
    /// # Safety
    ///
    /// Ib yam li [`MaybeUninit::assume_init`], nws yog los ntawm tus neeg hu kom lav tias lub puab sab hauv tus nqi tiag tiag yog nyob rau hauv lub xeev pib.
    ///
    /// Hu rau qhov no thaum cov ntsiab lus tseem tsis tau pib siab ua rau muaj kev coj cwj pwm tsis txaus ntseeg tam sim ntawd.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Xa pib:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Hloov siab los ntseeg `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// Ib yam li [`MaybeUninit::assume_init`], nws yog los ntawm tus neeg hu kom lav tias lub puab sab hauv tus nqi tiag tiag yog nyob rau hauv lub xeev pib.
    ///
    /// Hu rau qhov no thaum cov ntsiab lus tseem tsis tau pib siab ua rau muaj kev coj cwj pwm tsis txaus ntseeg tam sim ntawd.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Xa pib:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Xaj cov `Arc`, rov qab tuaj qhwv lub pointer.
    ///
    /// Txhawm rau kom tsis txhob muaj lub cim xeeb xaim ntawm lub pointer yuav tsum hloov mus rau `Arc` siv [`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Muab cov poom nqaij nyoos rau cov ntaub ntawv.
    ///
    /// Cov suav tsis muaj kev cuam tshuam rau txhua txoj kev thiab `Arc` tsis siv.
    /// Tus pointer siv tau rau ntev li ntev tau muaj muaj zog suav hauv `Arc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // KEV RUAJ NTSEG: Qhov no tsis tuaj yeem mus txog Deref::deref lossis RcBoxPtr::inner vim tias
        // qhov no yuav tsum khaws raw/mut qhov tseeb xws li ntawd
        // `get_mut` tuaj yeem sau los ntawm tus pointer tom qab Rc zoo tu qab los ntawm `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Ua tus `Arc<T>` los ntawm lub pointer nyoos.
    ///
    /// Lub pointer nyoos yuav tsum tau yav tas los rov qab los ntawm kev hu mus rau [`Arc<U>::into_raw`][into_raw] qhov twg `U` yuav tsum muaj qhov loj me thiab ua raws li `T`.
    /// Qhov no yog trivially muaj tseeb yog tias `U` yog `T`.
    /// Nco ntsoov tias yog `U` tsis yog `T` tab sis muaj tib qho loj thiab kev sib thooj, qhov no yeej ib txwm nyiam transmuting xa ntawm ntau hom.
    /// Saib [`mem::transmute`][transmute] rau cov lus qhia ntau ntxiv txog dab tsi txwv txiav siv nyob rau hauv cov ntaub ntawv no.
    ///
    /// Tus neeg siv ntawm `from_raw` yuav tsum ua kom muaj nuj nqi tshwj xeeb ntawm `T` tsuas yog poob qis ib zaug.
    ///
    /// Txoj haujlwm no tsis zoo vim tias kev siv tsis raug yuav ua rau lub cim xeeb tsis zoo, txawm tias `Arc<T>` rov qab los yeej tsis nkag.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Hloov rov qab mus rau ib qho `Arc` kom tsis txhob xau.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Ib qho txuas ntxiv hu rau `Arc::from_raw(x_ptr)` yuav yog qhov tsis nco qab.
    /// }
    ///
    /// // Lub cim xeeb raug tso tawm thaum `x` tawm ntawm qhov tsis muaj peev xwm saum toj, yog li `x_ptr` tam sim no dai tuag!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Rov qab qhov offset kom pom cov thawj ArcInner.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Tsim cov tshiab [`Weak`] pointer rau cov kev faib no.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Qhov So Tau Zoo no tau OK vim tias peb tau kuaj tus nqi hauv CAS hauv qab no.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // tshuaj xyuas yog tias cov txee tsis muaj zog yog tam sim no "locked";yog tsim, kiv.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: cov cai no tam sim no tsis quav ntsej qhov uas yuav hla dhau
            // rau hauv usize::MAX;feem ntau ob qho Rc thiab Arc yuav tsum tau kho kom thiaj li sib zog nrog kev phwj.
            //

            // Tsis zoo li nrog Clone(), peb xav tau qhov no los ua Kev Nyeem Ntawv kom los synchronize nrog cov ntawv sau los ntawm `is_unique`, yog li ntawd cov xwm txheej ua ntej qhov kev sau ntawv tau tshwm sim ua ntej nyeem no.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Nco ntsoov tias peb tsis tsim txoj phuam Weak
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Tau tus xov tooj ntawm [`Weak`] pointers rau qhov no faib.
    ///
    /// # Safety
    ///
    /// Qhov no txoj kev los ntawm nws tus kheej muaj kev ruaj ntseg, tab sis siv nws kom yuav tsum tau ceej faj ntxiv.
    /// Lwm xov yuav hloov cov uas qaug zog count ntawm tej lub sij hawm, xws li muaj feem ntawm kev hu mus rau hom no thiab acting nyob rau hauv cov kev tshwm sim.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Qhov kev lees paub no yog kev txiav txim siab vim tias peb tsis tau sib koom `Arc` lossis `Weak` ntawm cov xov.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Yog tias tus lej tsis muaj zog tam sim no raug kaw, tus nqi ntawm suav yog 0 ua ntej coj lub ntsuas phoo.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Tau tus xov tooj ntawm muaj zog (`Arc`) pointers rau qhov no faib.
    ///
    /// # Safety
    ///
    /// Qhov no txoj kev los ntawm nws tus kheej muaj kev ruaj ntseg, tab sis siv nws kom yuav tsum tau ceej faj ntxiv.
    /// Lwm xov yuav tau hloov lub muaj zog count ntawm tej lub sij hawm, xws li muaj feem ntawm kev hu mus rau hom no thiab acting nyob rau hauv cov kev tshwm sim.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Qhov kev lees paub no yog kev txiav txim siab vim tias peb tsis tau qhia tawm `Arc` ntawm cov xov.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Ntxiv rau qhov muaj zog suav suav nyob rau ntawm `Arc<T>` txuam nrog muab pointer los ntawm ib qho.
    ///
    /// # Safety
    ///
    /// Tus pointer yuav tsum tau txais los ntawm `Arc::into_raw`, thiab cov piv txwv `Arc` yuav tsum siv tau (piv txwv li
    /// qhov muaj zog suav yuav tsum yog tsawg kawg 1) rau sijhawm ntawm hom no.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Qhov kev lees paub no yog kev txiav txim siab vim tias peb tsis tau qhia tawm `Arc` ntawm cov xov.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Khaws Arc, tab sis tsis txhob kov cov nyiaj them rov qab los ntawm qhwv hauv ManuallyDrop
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Tam sim no nce refcount, tab sis tsis txhob tso cov refcount tshiab yog
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Txo kev siv zog suav suav ntawm `Arc<T>` txuam nrog muab pointer los ntawm ib qho.
    ///
    /// # Safety
    ///
    /// Tus pointer yuav tsum tau txais los ntawm `Arc::into_raw`, thiab cov piv txwv `Arc` yuav tsum siv tau (piv txwv li
    /// lub muaj zog count yuav tsum muaj tsawg kawg yog 1) thaum invoking no.
    /// Txoj kev no tuaj yeem siv los tso tawm qhov kawg `Arc` thiab thaub qab cia, tab sis **yuav tsum tsis txhob** hu ua tom qab `Arc` kawg tawm.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Cov kev lees paub yog kev txiav txim siab vim tias peb tsis tau qhia tawm `Arc` ntawm cov xov.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Qhov no unsafety yog ok vim hais tias thaum no arc yog ciaj sia peb nyob nraum guaranteed hais tias lub puab pointer yog siv tau.
        // Tsis tas li ntawd, peb paub tias tus qauv `ArcInner` nws tus kheej yog `Sync` vim tias cov ntaub ntawv sab hauv yog `Sync` ib yam nkaus, yog li peb nyob nraum ok qiv tawm ib qho tsis muaj dab tsi pauv rau cov ntsiab lus no.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Tsis-inlined ib feem ntawm `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Ua cov ntaub ntawv rhuav tshem lub sijhawm no, txawm hais tias peb yuav tsis pub dawb lub thawv faib rau nws tus kheej (tseem yuav muaj cov taw tes tsis muaj zog nyob ib puag ncig).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Tso cov qaug zog suav ua ke los ntawm txhua cov ntaub ntawv muaj zog
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Rov qab `true` yog tias ob lub Arc` taw rau tib qhov kev faib tawm (hauv cov leeg zoo li [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Allocates ib qho `ArcInner<T>` nrog qhov chaw txaus rau ib qho ntxiv nyob rau sab hauv uas tus nqi muaj cov kev teeb tsa.
    ///
    /// Txoj haujlwm `mem_to_arcinner` yog hu nrog cov ntaub ntawv taw qhia thiab yuav tsum rov qab rov qab a (muaj feem rog)-pauv qhia rau lub `ArcInner<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Laij teeb txheeb siv cov nqi muab.
        // Yav dhau los, kab lus tau muab xam rau qhov hais tawm `&*(ptr as* const ArcInner<T>)`, tab sis qhov no tau tsim cov ntawv siv tsis raug (saib #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Faib ib lub `ArcInner<T>` nrog qhov chaw txaus rau qhov muaj peev xwm-ntxig rau sab hauv uas tus nqi muaj cov kev teeb tsa, rov qab ua yuam kev yog qhov kev faib tsis tiav.
    ///
    ///
    /// Txoj haujlwm `mem_to_arcinner` yog hu nrog cov ntaub ntawv taw qhia thiab yuav tsum rov qab rov qab a (muaj feem rog)-pauv qhia rau lub `ArcInner<T>`.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Laij teeb txheeb siv cov nqi muab.
        // Yav dhau los, kab lus tau muab xam rau qhov hais tawm `&*(ptr as* const ArcInner<T>)`, tab sis qhov no tau tsim cov ntawv siv tsis raug (saib #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Pib ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Allocates ib qho `ArcInner<T>` nrog qhov chaw txaus rau qhov tsis muaj nuj nqis nyob sab hauv.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Faib rau cov `ArcInner<T>` siv lub txiaj ntsig.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Luam tus nqi li bytes
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Pub dawb rau kev faib yam tsis poob nws cov ntawv
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Allocates ib qho `ArcInner<[T]>` nrog qhov ntev.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Luam tawm cov ntsiab lus los ntawm hlais mus rau hauv cov chaw nyuam qhuav faib Arc <\[T\]>
    ///
    /// Tsis zoo vim tias tus neeg hu yuav tsum yog tus tswv cuab lossis khi `T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Ua ib qho `Arc<[T]>` los ntawm tus kav hluav taws xob uas paub tias muaj qee yam loj me.
    ///
    /// Tus cwj pwm yog undefined yuav tsum qhov luaj li cas yuav tsis ncaj ncees lawm.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Panic zov thaum cloning T ntsiab.
        // Thaum muaj panic, cov ntsiab lus uas tau muab sau rau hauv ArcInner tshiab yuav raug muab tso tseg, tom qab ntawd txoj kev nco ploj.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Tus taw tes rau thawj ntu
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Txhua yam meej.Nco tus ceev xwm kom nws tsis pub dawb ArcInner tshiab.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Kev Tshwj Xeeb trait siv rau `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Ua ib clone ntawm `Arc` pointer.
    ///
    /// Qhov no tsim lwm tus pointer rau tib qho kev faib tawm, nce ntau zog suav suav.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Siv ib qho kev txiav txim zoo yog qhov zoo ntawm no, raws li kev paub txog ntawm qhov kev xa khoom qub txwv tsis pub lwm txoj xov los ntawm kev xa khoom tsis raug.
        //
        // Raws li tau piav qhia hauv [Boost documentation][1], Ua rau kev siv cov lus sib txuas ntxiv tuaj yeem ua nrog nco_order_relaxed: Cov lus qhia tshiab rau ib qho khoom tuaj yeem tsuas yog tsim los ntawm ib qho kev siv uas twb muaj lawm, thiab dhau ib qho kev siv uas twb muaj lawm los ntawm ib txog xov mus rau lwm qhov yuav tsum tau muab ib qho uas yuav tsum tau synchronization.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Txawm li cas los xij peb yuav tsum tau pov hwm tawm tsam cov nyiaj them rov qab loj heev thaum qee tus neeg yog `mem: : tsis hnov qab Arcs.
        // Yog tias peb tsis ua qhov kev suav no tuaj yeem cuam tshuam dhau thiab cov siv yuav siv-tom qab pub dawb.
        // Peb racily saturate rau `isize::MAX` ntawm qhov kev xav tias tsis muaj ~2 billion xov ntxiv cov kev siv suav suav ib zaug.
        //
        // Qhov branch no yuav tsis raug coj los siv rau hauv ib txoj hauv kev muaj tiag.
        //
        // Peb rho tawm vim hais tias xws li cov kev pab cuam yog incredibly tsis zoo, thiab peb tsis quav ntsej los txhawb nws.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Ua ib tug mutable siv rau hauv lub muab `Arc`.
    ///
    /// Yog tias muaj lwm yam `Arc` lossis [`Weak`] taw rau cov kev faib nyiaj qub, tom qab ntawd `make_mut` yuav tsim kom muaj kev faib nyiaj tshiab thiab thov kom [`clone`][clone] ntawm tus nqi sab hauv kom paub meej txog cov tswv cuab.
    /// Qhov no tseem hais tau ua clone-on-sau.
    ///
    /// Nco ntsoov tias qhov no txawv ntawm kev coj cwj pwm ntawm [`Rc::make_mut`] uas cuam tshuam ib qho seem tshuav `Weak` pom.
    ///
    /// Saib [`get_mut`][get_mut], uas yuav swb es tsis txhob ua cloning.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Yuav tsis clone dab tsi
    /// let mut other_data = Arc::clone(&data); // Yuav tsis clone sab hauv cov ntaub ntawv
    /// *Arc::make_mut(&mut data) += 1;         // Clones cov ntaub ntawv sab hauv
    /// *Arc::make_mut(&mut data) += 1;         // Yuav tsis clone dab tsi
    /// *Arc::make_mut(&mut other_data) *= 2;   // Yuav tsis clone dab tsi
    ///
    /// // Tam sim no `data` thiab `other_data` taw tes rau cov kev faib khoom sib txawv.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Nco ntsoov tias peb tuav ob leeg siv zog thiab siv cov ntaub ntawv tsis muaj zog.
        // Yog li, tso peb muaj zog siv xwb yuav tsis yog, los ntawm nws tus kheej, ua rau lub cim xeeb yuav tsum tau deallocated.
        //
        // Siv Txais Tau los xyuas kom meej tias peb pom cov ntawv sau rau `weak` uas tau tshwm sim ua ntej kev tso tawm sau (piv txwv li, txo qis) rau `strong`.
        // Txij li thaum peb tuav tus lej tsis muaj zog, tsis muaj caij nyoog ArcInner nws tus kheej yuav tuaj yeem ua lag luam.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Lwm qhov muaj zog pointer muaj, yog li peb yuav tsum clone.
            // Pre-faib nco cia sau cov cloned nqi ncaj qha.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // So kom txaus nyob rau hauv qhov saum toj no vim tias qhov no yog lub hauv paus kev ua kom tau zoo: peb ib txwm sib tw nrog cov taw tes tsis muaj zog raug nqis.
            // Cov xwm txheej tsis zoo, peb xaus rau txoj kev siv Arc tshiab yam tsis tas yuav ua.
            //

            // Peb tshem tawm lub zog kawg, tab sis muaj ntxiv tsis muaj zog ntxiv nyob rau.
            // Peb mam li txav cov ntsiab lus rau Arc tshiab, thiab invalidate rau lwm yam tsis muaj zog refs.
            //

            // Nco ntsoov tias nws tsis tuaj yeem nyeem cov `weak` kom tawm usize::MAX (piv txwv li, xauv), vim tias qhov suav tsis muaj zog tsuas yog tuaj yeem kaw los ntawm cov xov nrog qhov muaj zog siv.
            //
            //

            // Ua kom zoo peb tus kheej implicit tsis muaj zog pointer, kom nws tuaj yeem ntxuav ArcInner raws li xav tau.
            //
            let _weak = Weak { ptr: this.ptr };

            // Yuav cia li nyiag cov ntaub ntawv, txhua qhov tseem tshuav yog Weaks
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Peb yog tib tug siv ntawm yam;thawv rov qab rau lub zog ref suav.
            //
            this.inner().strong.store(1, Release);
        }

        // Ib yam li `get_mut()`, qhov tsis muaj teeb meem tsis ua li cas vim yog peb siv tau pib nrog, los yog dhau los ua ib qho rau ntawm cov ntsiab lus.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Rov qab los siv cov lus qhia hloov mus rau `Arc` X muab, yog tias tsis muaj lwm yam `Arc` lossis [`Weak`] taw rau cov kev faib khoom tib yam.
    ///
    ///
    /// Rov qab [`None`] txwv tsis pub, vim tias nws tsis muaj kev nyab xeeb rau kev hloov pauv ntawm tus nqi sib koom.
    ///
    /// Kuj pom [`make_mut`][make_mut], uas yuav [`clone`][clone] tus nqi sab hauv thaum muaj lwm tus taw tes.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Qhov no unsafety yog ok vim hais tias peb nyob nraum guaranteed hais tias cov pointer rov qab yog tus *xwb* pointer uas yuav puas tau raug xa rov qab mus T.
            // Peb siv count yuav lav yuav tsum 1 ntawm no taw tes, thiab peb yuav tsum tau Arc nws tus kheej yuav tsum tau `mut`, li ntawd, peb nyob nraum rov qab los tsuas tau siv rau lub puab cov ntaub ntawv.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Rov qab los siv cov lus qhia hloov mus rau hauv `Arc` tau muab, tsis muaj daim tshev.
    ///
    /// Saib [`get_mut`], uas muaj kev nyab xeeb thiab ua cov tshev tsim nyog.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Lwm yam `Arc` lossis [`Weak`] taw tes rau qhov muab faib rau tib qho yuav tsum tsis muaj kev txiav txim rau lub sijhawm rov qab qiv.
    ///
    /// Qhov no yog trivially rau hauv rooj plaub yog tias tsis muaj xws pointers nyob, piv txwv li tam sim ntawd tom qab `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Peb xyuam xim rau *tsis* tsim qhov siv suav nrog "count" teb, vim qhov no yuav alias nrog cov khoom nkag mus rau hauv kev siv suav (piv txwv li
        // los ntawm `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Txheeb xyuas seb qhov no yog qhov siv tshwj xeeb (suav nrog refs tsis muaj zog) rau cov ntaub ntawv hauv qab.
    ///
    ///
    /// Nco ntsoov tias qhov no yuav tsum txhav tas qhov tsis muaj zog suav suav.
    fn is_unique(&mut self) -> bool {
        // xauv lub pointer tsis muaj zog suav yog tias peb pom tias yog tus neeg siv tsis muaj zog tiv thaiv pointer.
        //
        // Cov ntawv yuav tom ntawm no tau saib xyuas qhov tshwm sim-ua ntej kev sib raug zoo nrog kev sau ntawv rau `strong` (tshwj xeeb hauv `Weak::upgrade`) ua ntej kev txo qis ntawm `weak` suav (ntawm `Weak::drop`, uas siv tawm).
        // Yog hais tias hloov kho tsis muaj zog tiv thaiv lub zog tsis tau tso tseg, CAS ntawm no yuav swb ces peb tsis quav ntsej los synchronize.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Qhov no yuav tsum yog ib qho `Acquire` los sib sau ua ke nrog qhov txo qis ntawm `strong` txee hauv `drop`-kev nkag mus tsuas yog tshwm sim thaum twg tab sis kawg siv tau raug xa tawm.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Cov ntawv tso tawm ntawm no synchronizes nrog cov nyeem hauv `downgrade`, zoo tiv thaiv kev nyeem ntawv saum toj ntawm `strong` los ntawm kev tshwm sim tom qab qhov sau.
            //
            //
            self.inner().weak.store(1, Release); // tso lub ntsuas phoo
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Ncos lub `Arc`.
    ///
    /// Qhov no yuav ua rau kom cov suav suav daws muaj zog.
    /// Yog tias qhov kev siv muaj zog suav suav tau nce mus txog xoom ces tsuas yog lwm tus xa mus (yog tias muaj) yog [`Weak`], yog li peb `drop` tus nqi sab hauv.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Tsis luam tawm txhua yam
    /// drop(foo2);   // Luam "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Vim tias `fetch_sub` twb atomic, peb tsis tas yuav synchronize nrog lwm txoj xov tshwj tsis yog tias peb yuav rho tawm cov khoom.
        // Cov tib zaj no siv rau hauv qab `fetch_sub` mus rau `weak` suav.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Qhov laj kab no yog xav tau los tiv thaiv kev rov ua ntsuas ntawm kev siv cov ntaub ntawv thiab cov ntaub ntawv txiav.
        // Vim tias nws tau cim `Release`, qhov zuj zus lawm ntawm qhov kev siv suav suav synchronizes nrog lub laj kab `Acquire` no.
        // Qhov no txhais tau tias kev siv cov ntaub ntawv tshwm sim ua ntej txo cov kev siv suav, uas tau tshwm sim ua ntej lub laj kab no, uas tau tshwm sim ua ntej kev tshem tawm cov ntaub ntawv.
        //
        // Raws li tau piav qhia hauv [Boost documentation][1],
        //
        // > Nws yog ib qho tseem ceeb uas yuav tau tswj txoj kev nkag mus tau rau yam khoom hauv ib qho
        // > xov (los ntawm ib tug uas twb muaj lawm siv) rau *tshwm sim ua ntej* lwv
        // > tus kwv nyob txawv xov.Qhov no ua tiav los ntawm kev ua haujlwm "release"
        // > lag luam tom qab xa ntawv siv (ib qho kev nkag mus rau cov khoom
        // > los ntawm cov ntawv pov thawj no yuav tsum tau pom tshwm sim ua ntej), thiab ib
        // > "acquire" lag luam ua ntej yuav rho tawm cov khoom.
        //
        // Hauv kev tshwj xeeb, thaum cov ntsiab lus ntawm Arc feem ntau tsis txawj hloov, nws muaj peev xwm muaj sab hauv sau ntawv rau ib yam dab tsi zoo li Mutex<T>Cov.
        // Txij li ib lub Mutex tsis tau dhau los thaum nws raug tshem tawm, peb tsis tuaj yeem cia siab rau nws cov synchronization logic ua sau hauv xov Ib qho pom rau lub destructor khiav hauv xov B.
        //
        //
        // Tseem nco ntsoov tias Acquire laj kab ntawm no tej zaum yuav raug hloov nrog Acquire load, uas tuaj yeem txhim kho kev ua tau zoo hauv cov xwm txheej nyuaj.Saib [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Nkag mus rau downcast `Arc<dyn Any + Send + Sync>` rau ib hom qhob.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Ua dua tshiab `Weak<T>` tshiab, tsis muaj kev faib txhua lub cim xeeb.
    /// Hu [`upgrade`] ntawm tus nqi xa rov qab ib txwm muab [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Hom kev pab rau tus txheejtxheem qhov siv suav nrog tsis tau ua cov lus hais txog cov ntaub ntawv.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Rov qab pom lub pointer nyoos rau lub nruas `T` taw rau ntawm no `Weak<T>`.
    ///
    /// Tus taw qhia yog siv tau tsuas yog muaj qee cov ntaub ntawv muaj zog.
    /// Tus pointer tej zaum yuav dai siav, unaligned lossis txawm [`null`] txwv tsis pub.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Ob qho tib si taw rau tib qho khoom tawm
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Lub zog ntawm no ua kom nws nyob zoo, yog li peb tseem tuaj yeem nkag mus rau qhov khoom.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Tab sis tsis muaj ntau.
    /// // Peb tuaj yeem ua weak.as_ptr(), tab sis kev nkag mus rau lub pointer yuav ua rau kev coj tus cwj pwm uas tsis tau xaiv.
    /// // assert_eq! ("nyob zoo", kev nyab xeeb {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Yog tias tus pointer dai tuag, peb rov qab xa cov ntawv xa ncaj qha.
            // Qhov no tsis tuaj yeem yog qhov chaw nyob ntawm payload, vim tias qhov payload tsawg kawg raws li ArcInner (usize).
            ptr as *const T
        } else {
            // KEV RUAJ NTSEG: yog is_dangling rov ua cuav, ces tus pointer tsis suav nrog.
            // Lub payload yuav tso tawm ntawm lub sijhawm no, thiab peb yuav tsum tswj hwm qhov tseeb, yog li siv cov pointer raw cov ntaub ntawv rau.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Consumes `Weak<T>` thiab hloov mus rau hauv lub pointer nyoos.
    ///
    /// Qhov no hloov pauv cov poom uas tsis muaj zog mus rau hauv lub pointer nyoos, thaum tseem khaws cia cov tswv cuab ntawm ib qho kev siv tsis muaj zog (qhov tsis muaj zog suav tsis yog hloov los ntawm kev ua haujlwm no).
    /// Nws tuaj yeem tig rov qab rau hauv `Weak<T>` nrog [`from_raw`].
    ///
    /// Tib qho kev txwv ntawm kev nkag mus rau lub hom phiaj ntawm tus pointer li nrog [`as_ptr`] siv.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Hloov tus pointer nyoos yav tas los tsim los ntawm [`into_raw`] rov qab mus rau `Weak<T>`.
    ///
    /// Qhov no tuaj yeem siv kom muaj kev nyab xeeb tau txais kev siv dag zog (los ntawm kev hu rau [`upgrade`] tom qab) lossis los daws qhov tsis muaj zog suav los ntawm kev xa mus rau `Weak<T>`.
    ///
    /// Nws yuav tsum ua tswv cuab ntawm ib qho tsis muaj zog siv (tshwj tsis yog cov taw tes tsim los ntawm [`new`], vim tias cov no tsis muaj dab tsi; tus qauv tseem ua haujlwm rau lawv).
    ///
    /// # Safety
    ///
    /// Tus pointer yuav tsum tau tshwm sim los ntawm [`into_raw`] thiab yuav tsum tseem muaj lub peev xwm tsis muaj zog siv.
    ///
    /// Nws raug tso cai rau qhov muaj zog suav ua 0 thaum lub sijhawm ntawm hu qhov no.
    /// Txawm li cas los xij, qhov no tau ua tswv cuab ntawm ib qho tsis muaj zog tam sim no sawv cev tam li tus pointer nyoos (qhov tsis muaj zog suav tsis tau hloov los ntawm kev ua haujlwm no) thiab yog li nws yuav tsum tau txuas nrog nrog kev hu dhau los rau [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Txo kev ua kom suav daws tsis muaj zog.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Saib Weak::as_ptr rau cov ntsiab lus hais txog yuav ua li cas lub tswv yim pointer muab tau los.

        let ptr = if is_dangling(ptr as *mut T) {
            // Qhov no yog qhov phuam tsis muaj zog.
            ptr as *mut ArcInner<T>
        } else {
            // Txwv tsis pub, peb tau lees tias tus pointer tuaj ntawm qhov tsis muaj tseeb Weak.
            // KEV RUAJ NTSEG: data_offset muaj kev nyab xeeb rau kev hu, raws li ptr hais txog qhov tiag (muaj feem tau nqis) T.
            let offset = unsafe { data_offset(ptr) };
            // Yog li, peb tig rov qab qhov kev txhaum tshem kom tau tag nrho RcBox.
            // KEV RUAJ NTSEG: tus pointer originated los ntawm Weak, yog li qhov kev txwv no yog kev nyab xeeb.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // TXUJ CI: tam sim no peb tau rov qab tau tus thawj Weak pointer, yog li tuaj yeem tsim qhov Weak.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Kev rau siab hloov mus rau `Weak` tus pointer rau ib qho [`Arc`], ncua kev poob qis ntawm tus nqi sab hauv yog tias muaj kev vam meej.
    ///
    ///
    /// Rov qab [`None`] yog tias tus nqi sab hauv txij li tau nqis tawm.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Ua kom puas tag nrho cov muaj zog pointers.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Peb siv CAS lub voj los ntxiv rau cov muaj zog suav hloov chaw ntawm ib qho fetch_add vim tias txoj haujlwm no yuav tsum tsis txhob coj tus lej suav suav txij li xoom txog ib qho.
        //
        //
        let inner = self.inner()?;

        // So kom txaus vim hais tias ib qho kev sau ntawm 0 uas peb tuaj yeem saib cov nplooj nyob hauv qhov chaw tas mus li (yog li "stale" nyeem ntawm 0 yog qhov zoo), thiab lwm yam nqi tau lees paub los ntawm CAS hauv qab no.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Saib cov lus hauv `Arc::clone` vim li cas peb thiaj ua qhov no (rau `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // So yog zoo rau lub tsis ua hauj lwm cov ntaub ntawv vim hais tias peb tsis muaj kev cia siab txog lub tshiab lub xeev.
            // Tau txais yog qhov tsim nyog rau qhov kev ua tiav tiav tau ua tiav ntawm `Arc::new_cyclic`, thaum tus nqi sab hauv tuaj yeem pib tau tom qab `Weak` cov ntawv xa tau twb tau tsim.
            // Hauv qhov xwm txheej ntawd, peb xav tias yuav saib qhov pib siab qhov tseem ceeb.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // thov khij saum toj saud
                Err(old) => n = old,
            }
        }
    }

    /// Tau txais cov naj npawb ntawm qhov muaj zog (`Arc`) taw tes taw rau qhov kev faib no.
    ///
    /// Yog tias `self` raug tsim los siv [`Weak::new`], qhov no yuav xa rov qab 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Tau txais kev kwv yees ntawm tus naj npawb ntawm `Weak` taw tes taw rau qhov kev faib no.
    ///
    /// Yog tias `self` tau tsim los siv [`Weak::new`], lossis yog tias tsis muaj cov taw qhia muaj zog, qhov no yuav rov qab los 0.
    ///
    /// # Accuracy
    ///
    /// Vim tias cov ntsiab lus siv, cov nqi xa rov qab tuaj yeem tawm los ntawm 1 hauv ib qho kev qhia thaum twg lwm cov xov tau tswj xyuas qhov twg 'Arc`s lossis`Weak`s taw qhia rau tib cov kev faib tawm.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Txij li thaum peb pom tias yog yam tsawg kawg yog ib tug muaj zog pointer tom qab nyeem ntawv cov tsis muaj zog suav, peb paub hais tias tus implicit tsis muaj zog siv (tam sim no thaum twg muaj tej muaj zog ua tim khawv ciaj sia) yog tseem nyob ib ncig ntawm thaum peb pom tus tsis muaj zog suav, thiab muaj peev xwm yog li ntawd yam xyuam xim rho nws.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Rov qab `None` thaum tus pointer dai tuag thiab tsis muaj kev faib nyiaj `ArcInner`, (piv txwv li, thaum `Weak` no tau tsim los ntawm `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Peb xyuam xim rau *tsis* tsim qhov siv suav sau rau "data" daim teb, vim hais tias daim teb yuav raug sib hloov hauv lub sijhawm (piv txwv li, yog tias `Arc` kawg poob, cov ntaub ntawv sau yuav muab tso rau hauv-chaw).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Rov qab `true` yog tias ob qho "Weak" taw qhia rau tib qho kev faib tawm (zoo ib yam li [`ptr::eq`]), lossis yog tias ob qho tib si tsis taw tes rau qee qhov kev faib tawm (vim tias lawv tau tsim nrog `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Vim tias qhov sib piv cov lus taw qhia nws txhais tau tias `Weak::new()` yuav sib npaug, txawm tias lawv tsis taw tes rau ib qho kev faib.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Sib piv `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Ua ib qho clone ntawm `Weak` lub pointer uas taw rau cov kev faib tawm tib yam.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Saib cov lus hauv Arc::clone() vim li cas qhov no xoob.
        // Qhov no tuaj yeem siv fetch_add (uas tsis quav ntsej lub ntsuas phoo) vim tias qhov tsis muaj zog tsuas yog muab xauv qhov twg *tsis muaj lwm yam* cov taw tes tsis muaj zog hauv lub neej.
        //
        // (Yog li peb tsis tuaj yeem khiav cov cai no nyob rau kis ntawd).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Saib cov lus hauv Arc::clone() vim li cas peb thiaj ua qhov no (rau mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Ua dua tshiab `Weak<T>` tshiab, yam tsis muaj qhov cim xeeb.
    /// Hu [`upgrade`] ntawm tus nqi xa rov qab ib txwm muab [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Dhuav cov `Weak` lub pointer.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Tsis luam tawm txhua yam
    /// drop(foo);        // Luam "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Yog tias peb pom tias peb yog tus ntsuas kub tsis muaj zog kawg, ces nws lub sijhawm los cuam tshuam cov ntaub ntawv tag nrho.Pom kev sib tham hauv Arc::drop() txog cov kev txiav txim nco cia
        //
        // Nws yog tsis tsim nyog mus xyuas rau lub xauv lub xeev no, vim hais tias cov tsis muaj zog count yuav tsuas yuav muab xauv yog hais tias muaj precisely ib zog nyob, lub ntsiab lus uas nco yuav tsuas tom qab khiav RAU uas seem tsis muaj zog nyob, uas muaj peev xwm tsuas tshwm sim tom qab lub xauv yog tso tawm.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Peb tau ua qhov kev tshwj xeeb ntawm no, thiab tsis yog qhov zoo dua ntxiv rau ntawm `&T`, vim tias nws yuav txwv tsis pub ntxiv ib qho nqi rau txhua qhov kev sib txig sib luag ntawm cov nyiaj rov qab.
/// Peb hais tsis xav hais tias 'Arc`s yog siv los khaws cov loj tseem ceeb, uas yog qeeb clone, tab sis kuj hnyav mus xyuas rau koob pheej ntawm lawv, ua no nqi kom them tau yooj yim dua.
///
/// Nws kuj tseem muaj dua ob lub `Arc` clones, taw tes mus rau tus nqi ib yam, tshaj ob `&T`.
///
/// Peb tsuas ua qhov no thaum `T: Eq` ua `PartialEq` tej zaum yuav tsis ncaj ncees irreflexive.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Kev sib luag rau ob `Arc`s.
    ///
    /// Ob tug 'Arc`s yog muaj sib npaug yog hais tias lawv puab qhov tseem ceeb yog muaj sib npaug, txawm yog hais tias lawv yog muab nyob rau hauv txawv kev faib nyiaj.
    ///
    /// Yog tias `T` tseem siv `Eq` (cuam tshuam nrog kev hloov pauv ntawm kev sib luag), ob tus Arc` uas taw rau cov kev faib tawm ib txwm muaj sib npaug.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Tsis sib xws rau ob `Arc`s.
    ///
    /// Ob Qhov "Arc" tsis zoo sib xws yog tias lawv sab hauv tsis sib xws.
    ///
    /// Yog `T` tseem coj `Eq` (cuam tshuam nrog kev hloov kho ntawm kev sib luag), ob lub Arc` uas taw rau tib tus nqi yeej tsis txawv.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Kev sib piv me me rau ob ntu 'Arc`s.
    ///
    /// Ob qho sib piv los ntawm kev hu xov tooj `partial_cmp()` ntawm lawv tus nqi sab hauv.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Tsawg-piv rau ob qhov Arc `.
    ///
    /// Ob qho sib piv los ntawm kev hu xov tooj `<` ntawm lawv tus nqi sab hauv.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// 'Tsawg dua los sis sib npaug rau' sib piv rau ob `Arc`s.
    ///
    /// Lub ob yog muab piv los ntawm kev hu mus rau `<=` rau lawv puab qhov tseem ceeb.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Ntau dua-piv rau ob qhov Arc `.
    ///
    /// Ob qho sib piv los ntawm kev hu xov tooj `>` ntawm lawv tus nqi sab hauv.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// 'Zoo tshaj los sis zoo ib yam rau' sib piv rau ob `Arc`s.
    ///
    /// Ob qho sib piv los ntawm kev hu xov tooj `>=` ntawm lawv tus nqi sab hauv.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Piv rau ob `Arc`s.
    ///
    /// Ob qho sib piv los ntawm kev hu xov tooj `cmp()` ntawm lawv tus nqi sab hauv.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Tsim tshiab `Arc<T>`, nrog `Default` tus nqi rau `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Faib ib daim ntawv suav-suav suav thiab sau nws los ntawm cloning `v` cov khoom.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Teem ib qho siv suav-suav `str` thiab luam `v` rau nws.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Teem ib qho siv suav-suav `str` thiab luam `v` rau nws.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Txav mus rau ntawm lub npov uas tsis kam tawm mus rau qhov chaw tshiab, xam-suav kev sib cais.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Teem ib qho pov tseg-suav cov pov npav thiab txav `v` cov khoom rau hauv nws.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Tso cai rau Vec tso nws qhov kev nco, tab sis tsis rhuav tshem nws cov ntsiab lus
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Siv txhua lub caij hauv `Iterator` thiab sau nws rau hauv `Arc<[T]>`.
    ///
    /// # Cov yam ntxwv ua haujlwm
    ///
    /// ## Rooj plaub no
    ///
    /// Hauv qhov xwm txheej dav dav, sau rau hauv `Arc<[T]>` yog ua tiav los ntawm kev sau thawj zaug rau hauv `Vec<T>`.Ntawd yog, thaum sau ntawv hauv qab no:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// qhov no coj zoo li yog peb sau:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Thawj txheej kev faib tawm muaj tshwm sim ntawm no.
    ///     .into(); // Qhov thib ob kev faib nyiaj rau `Arc<[T]>` tshwm sim ntawm no.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Qhov no yuav faib ob peb zaug raws li qhov xav tau rau kev tsim lub `Vec<T>` thiab tom qab ntawd nws yuav faib nyiaj ib zaug rau tig `Vec<T>` rau hauv `Arc<[T]>`.
    ///
    ///
    /// ## Iterators ntawm paub ntev
    ///
    /// Thaum koj `Iterator` siv `TrustedLen` thiab yog qhov loj me, ib qho kev faib nyiaj yuav ua rau `Arc<[T]>`.Piv txwv li:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Tsuas yog ib txoj kev faib nyiaj muaj tshwm sim ntawm no.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Kev Tshwj Xeeb trait siv rau kev sau rau `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Nov yog rooj plaub rau `TrustedLen` tus tuav.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // KEV RUAJ NTSEG: Peb yuav tsum xyuas kom meej tias tus ntsuas hluav taws xob muaj qhov ntev thiab peb muaj.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Poob rov qab rau kev coj ua.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Tau txais cov nqi txo nyob rau hauv ib qho `ArcInner` rau lub payload qab tus pointer.
///
/// # Safety
///
/// Tus taw qhia yuav tsum taw mus rau (thiab muaj cov metadata siv tau rau) qhov piv txwv yav dhau los ntawm T, tab sis T tso cai kom tso tawm.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Dlhos lub unsized nqi mus rau thaum xaus ntawm lub ArcInner.
    // Vim tias RcBox yog repr(C), nws yuav nco ntsoov ua daim teb kawg hauv cim xeeb.
    // KEV RUAJ NTSEG: vim tias tsuas yog hom tsis tau paub tab yog hlais, trait khoom,
    // thiab cov hom txawv, cov tswv yim kev nyab xeeb tam sim no txaus kom txaus siab cov kev xav tau ntawm align_of_val_raw;qhov no yog kev nthuav dav siv ntawm cov lus uas yuav tsis cuam tshuam nrog sab nraud std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}