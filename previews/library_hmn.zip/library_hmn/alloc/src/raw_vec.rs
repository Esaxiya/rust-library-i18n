#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Cov ntsiab lus ntawm cov cim xeeb tshiab yog qhov tsis txaus ntseeg.
    Uninitialized,
    /// Lub cim xeeb tshiab tuaj yeem lav tau xoom.
    Zeroed,
}

/// Kev siv hluav taws xob tsawg rau ntau dua kev lav phib xaub kev faib tawm, kev faib tawm tshiab, thiab kev tawm tsam tsis haum ntawm lub cim xeeb ntawm lub heap yam tsis tas yuav txhawj xeeb txog txhua qhov teeb meem tsis koom nrog.
///
/// Hom no zoo heev rau kev tsim koj tus kheej cov qauv ntaub ntawv zoo li Vec thiab VecDeque.
/// Hauv particular:
///
/// * Ua rau `Unique::dangling()` ntawm hom xoom.
/// * Cov khoom tsim `Unique::dangling()` ntawm xoom ntev-faib.
/// * Txhob pub coj dawb `Unique::dangling()`.
/// * Kev ntes txhua qhov hla ntawm hauv cov peev txheej (txhawb nqa lawv rau "capacity overflow" panics).
/// * Cov ntawv tiv thaiv tiv thaiv 32-ntsis tshuab faib ntau dua isize::MAX bytes.
/// * Tiv thaiv tiv thaiv xos koj ntev.
/// * Hu rau `handle_alloc_error` rau cov nyiaj faib tawm.
/// * Muaj `ptr::Unique` thiab yog li ua rau cov neeg siv nrog txhua cov txiaj ntsig ntsig txog.
/// * Siv cov nyiaj rov qab los ntawm tus neeg faib khoom rau siv cov peev txheej loj tshaj plaws.
///
/// Hom no tsis nyob rau hauv lawm los tshawb xyuas lub cim xeeb uas nws tswj hwm.Thaum poob nws *yuav* tso nws txoj kev nco tseg, tab sis nws *yuav tsis* sim poob nws cov ntsiab lus.
/// Nws yog nyob ntawm tus neeg siv ntawm `RawVec` los lis cov khoom tiag tiag *khaws cia* sab hauv ntawm `RawVec`.
///
/// Nco ntsoov tias qhov tshaj ntawm cov xoom ib txwm siv yog ib txwm tsis kawg, yog li `capacity()` ib txwm rov `usize::MAX`.
/// Qhov no txhais tau tias koj yuav tsum tau ceev faj thaum puag ncig cov hom no nrog ib tus `Box<[T]>`, txij li `capacity()` yuav tsis tawm qhov ntev.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Qhov no tshwm sim vim `#[unstable]` `const fn` tsis xav tau ua raws `min_const_fn` thiab yog li lawv tsis tuaj yeem raug hu ua hauv 'min_const_fn `s ib qho.
    ///
    /// Yog tias koj hloov `RawVec<T>::new` lossis kev tso siab rau, thov saib xyuas kom tsis txhob qhia txhua yam uas yuav ua txhaum `min_const_fn`.
    ///
    /// NOTE: Peb tuaj yeem zam qhov kev hack no thiab tshawb xyuas kev cuam tshuam nrog qee `#[rustc_force_min_const_fn]` tus cwj pwm uas yuav tsum muaj kev sib txuas nrog `min_const_fn` tab sis tsis tas yuav cia hu nws hauv `stable(...) const fn`/tus neeg siv code tsis ua rau `foo` thaum `#[rustc_const_unstable(feature = "foo", issue = "01234")]` tam sim no.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Tsim kom tau qhov loj tshaj plaws uas tau muaj `RawVec` (nyob ntawm qhov system heap) yam tsis muaj kev faib.
    /// Yog tias `T` muaj qhov loj me, ces qhov no ua rau `RawVec` nrog lub peev xwm `0`.
    /// Yog `T` yog qhov ntsuas xoom, tom qab ntawd nws ua rau `RawVec` nrog lub peev xwm `usize::MAX`.
    /// Siv rau kev nqis tes qeeb.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Tsim ib qho `RawVec` (nyob rau hauv qhov system heap) nrog qhov muaj peev xwm thiab kev cia ua qhov sib txawv rau ib qho `[T; capacity]`.
    /// Qhov no yog sib npaug rau hu rau `RawVec::new` thaum `capacity` yog `0` lossis `T` yog xoom.
    /// Nco ntsoov tias yog `T` yog xoom-qhov loj qhov no txhais tau tias koj yuav *tsis* tau txais `RawVec` nrog qhov muaj peev xwm thov.
    ///
    /// # Panics
    ///
    /// Panics yog qhov thov muaj peev xwm tshaj `isize::MAX` bytes.
    ///
    /// # Aborts
    ///
    /// Tuav ntawm OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Zoo li `with_capacity`, tab sis lav cov tsis yog xoom.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Rov ntsuas tus `RawVec` los ntawm lub pointer thiab muaj peev xwm.
    ///
    /// # Safety
    ///
    /// `ptr` yuav tsum tau faib (nyob rau hauv qhov system heap), thiab nrog muab `capacity`.
    /// Lub `capacity` tsis pub dhau `isize::MAX` rau cov hom loj.(tsuas yog txhawj xeeb ntawm 32-ntsis system).
    /// ZST vectors tej zaum yuav muaj txog li `usize::MAX`.
    /// Yog tias `ptr` thiab `capacity` los ntawm `RawVec`, ces qhov no yog qhov lav.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Me Vecs yog cov ruam.Hla mus rau:
    // - 8 yog tias qhov khoom me ib qho yog 1, vim tias ib cov neeg siv heap yuav zoo los thov tsawg dua 8 bytes rau tsawg kawg yog 8 bytes.
    //
    // - 4 yog tias cov khoom muaj ntsis-loj (<=1 KiB).
    // - 1 txwv tsis pub, kom tsis txhob nkim qhov chaw ntau dhau rau Vecs luv heev.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Zoo li `new`, tab sis parameterized dhau ntawm kev xaiv ntawm kev faib khoom rau `RawVec` xa rov qab.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` txhais tau tias "unallocated".hom ua xoom yog tsis quav ntsej.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Zoo li `with_capacity`, tab sis parameterized dhau ntawm kev xaiv ntawm kev faib khoom rau `RawVec` xa rov qab.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Zoo li `with_capacity_zeroed`, tab sis parameterized dhau ntawm kev xaiv ntawm kev faib khoom rau `RawVec` xa rov qab.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Hloov tus `Box<[T]>` rau hauv `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Hloov pauv tag nrho tsis mus rau `Box<[MaybeUninit<T>]>` nrog cov teev `len`.
    ///
    /// Nco ntsoov tias qhov no yuav raug tsim kho ib qho `cap` hloov uas tau ua.(Saib cov lus qhia ntawm yam rau cov ntsiab lus.)
    ///
    /// # Safety
    ///
    /// * `len` yuav tsum muaj ntau dua los yog zoo ib yam li qhov tau thov tam sim no, thiab
    /// * `len` yuav tsum tsawg dua los sis sib npaug `self.capacity()`.
    ///
    /// Nco ntsoov, tias qhov kev thov muaj peev xwm thiab `self.capacity()` tuaj yeem sib txawv, raws li tus neeg faib yuav tshem tawm thiab xa rov qab lub cim xeeb ntau dua li thov.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Kev kuaj huv-kuaj ib nrab ntawm qhov yuav tsum tau muaj kev nyab xeeb (peb tsis tuaj yeem kuaj lwm ib nrab).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Peb zam `unwrap_or_else` ntawm no vim tias nws bloats tus nqi ntawm LLVM IR generated.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Rov qab txiav txim siab `RawVec` los ntawm tus pointer, muaj peev xwm, thiab cov nyiaj siv.
    ///
    /// # Safety
    ///
    /// `ptr` yuav tsum tau faib (ntawm tus neeg muab kev pabcuam `alloc`), thiab nrog rau `capacity` muab.
    /// Lub `capacity` tsis pub dhau `isize::MAX` rau cov hom loj.
    /// (tsuas yog txhawj xeeb ntawm 32-ntsis system).
    /// ZST vectors tej zaum yuav muaj txog li `usize::MAX`.
    /// Yog tias `ptr` thiab `capacity` los ntawm `RawVec` tsim ntawm `alloc`, ces qhov no yog qhov lav.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Nqa khoom noj khoom haus nyoos kom pib rau kev faib.
    /// Nco ntsoov tias qhov no yog `Unique::dangling()` yog `capacity == 0` lossis `T` yog xoom.
    /// Hauv rooj plaub qub, koj yuav tsum xyuam xim.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Tau lub peev xwm ntawm cov nyiaj.
    ///
    /// Qhov no yuav ib txwm yog `usize::MAX` yog `T` yog xoom-xoom.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Rov qab los koom qhia rau tus neeg faib cov thaub qab no `RawVec`.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Peb muaj cov kev faib nyiaj ntawm lub cim xeeb, yog li peb tuaj yeem hla dhau cov tshev tuaj yeem kom tau txais peb cov qauv tam sim no.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Nco ntsoov tias qhov tsis zoo muaj tsawg kawg qhov chaw txaus los tuav `len + additional` cov ntsiab lus.
    /// Yog tias nws tsis muaj peev xwm txaus, yuav hloov chaw txaus ntxiv ntxiv rau qhov chaw tsis muaj chaw txaus kom tau txais amortized *O*(1) tus cwj pwm.
    ///
    /// Yuav txwv tus cwj pwm no yog tias nws yuav tsis tsim nyog ua nws tus kheej rau panic.
    ///
    /// Yog tias `len` siab tshaj `self.capacity()`, qhov no tuaj yeem swb rau qhov chaw uas thov tiag.
    /// Qhov no tsis yog qhov tsis zoo, tab sis tus lej tsis raug cai *koj* sau uas cuam tshuam rau kev coj ua ntawm txoj haujlwm no tuaj yeem tsoo.
    ///
    /// Qhov no yog zoo tagnrho rau kev siv ib tug loj-laub lag luam zoo li `extend`.
    ///
    /// # Panics
    ///
    /// Panics yog qhov muaj peev xwm tshiab tshaj `isize::MAX` bytes.
    ///
    /// # Aborts
    ///
    /// Tuav ntawm OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // zeem cia yuav muaj aborted lossis ntxhov siab yog tias lub len dhau `isize::MAX` yog li qhov no muaj kev ruaj ntseg ua tam sim no.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// Tib yam li `reserve`, tab sis rov qab rau ntawm qhov yuam kev tsis yog ntawm kev yias lossis txiav.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Nco ntsoov tias qhov tsis zoo muaj tsawg kawg qhov chaw txaus los tuav `len + additional` cov ntsiab lus.
    /// Yog hais tias nws tsis tau, yuav reallocate tsawg kawg npaum li cas tsim nyog ntawm kev nco.
    /// Feem ntau qhov no yuav yog qhov tseeb ntawm lub cim xeeb tsim nyog, tab sis hauv txoj cai tus neeg pub dawb pub rov qab ntau dua li qhov peb thov.
    ///
    ///
    /// Yog tias `len` siab tshaj `self.capacity()`, qhov no tuaj yeem swb rau qhov chaw uas thov tiag.
    /// Qhov no tsis yog qhov tsis zoo, tab sis tus lej tsis raug cai *koj* sau uas cuam tshuam rau kev coj ua ntawm txoj haujlwm no tuaj yeem tsoo.
    ///
    /// # Panics
    ///
    /// Panics yog qhov muaj peev xwm tshiab tshaj `isize::MAX` bytes.
    ///
    /// # Aborts
    ///
    /// Tuav ntawm OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// Cov tib yam li `reserve_exact`, tab sis rov qab los rau uas tsis es tsis txhob ntawm panicking los yog aborting.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Shrinks qhov kev nqes cia rau cov nyiaj teev.
    /// Yog hais tias tus nqi muab yog 0, tiag ua kiag li lag luam tawm.
    ///
    /// # Panics
    ///
    /// Panics yog tias tus nqi muab yog *loj dua* dhau lub peev xwm tam sim no.
    ///
    /// # Aborts
    ///
    /// Tuav ntawm OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Rov qab yog tias tus tsis xav tau loj hlob kom tau raws li qhov xav tau ntxiv.
    /// Mas siv los ua inlining cia-hu tau yam tsis muaj inlining `grow`.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Hom no feem ntau yog instantiated ntau zaus.Yog li peb xav kom nws tsawg li sai tau, txhawm rau txhim kho cov sijhawm sib piv.
    // Tab sis peb kuj tseem xav kom ntau npaum li ntawm nws cov ntawv los ua kev suav kom ntau li ntau tau, ua kom txoj cai tsim tawm sai dua.
    // Yog li no, cov txheej txheem no tau ua tib zoo sau kom txhua tus lej uas nyob ntawm `T` yog nyob hauv nws, thaum ntau ntawm cov cai tsis cia siab rau `T` qhov ua tau yog nyob hauv cov haujlwm uas tsis yog-tshaj dhau `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Qhov no yog tau los ntawm kev hu cov ntsiab lus.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Txij li peb xa rov qab muaj peev xwm ntawm `usize::MAX` thaum `elem_size` yog
            // 0, mus txog nov txhais tau tias cov `RawVec` dhau kev dhau.
            return Err(CapacityOverflow);
        }

        // Tsis muaj dab tsi peb yuav yeej li cas txog cov tshev, sadly.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Qhov no tuaj yeem lav cia muaj kev nthuav dav.
        // Lub doubling tsis tuaj yeem dhau vim `cap <= isize::MAX` thiab hom `cap` yog `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` yog tsis-tus qauv tshaj `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Cov kev txwv ntawm cov qauv no muaj ntau npaum li cov uas nyob ntawm `grow_amortized`, tab sis hom no feem ntau instantiated tsawg feem ntau yog li nws tsis tshua tseem ceeb.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Txij li peb xa rov qab muaj peev xwm ntawm `usize::MAX` thaum hom loj
            // 0, mus txog nov txhais tau tias cov `RawVec` dhau kev dhau.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` yog tsis-tus qauv tshaj `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Txoj haujlwm no sab nraud `RawVec` los txo qis sijhawm.Saib qhov lus pom saum toj no `RawVec::grow_amortized` rau cov ntsiab lus.
// (Lub `A` tsis tseem ceeb, vim hais tias muaj pes tsawg tus `A` yam pom nyob rau hauv kev coj ua yog tsawg dua li tus naj npawb ntawm `T` hom.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Kos rau qhov yuam kev no mus txo qhov luaj li cas ntawm `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Cov tseb nyiaj txiag soj ntsuam rau kev sib txig sib luag
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Pom zoo lub cim xeeb uas yog tus `RawVec`*tsis tau* ua kom poob nws cov ntawv.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Central kev ua haujlwm rau kev tuav yuam kev.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Peb yuav tsum lav cov hauv qab no:
// * Peb tsis tau faib cov `> isize::MAX` byte-loj cov khoom.
// * Peb tsis overflow `usize::MAX` thiab yeej faib me me heev.
//
// Ntawm 64-ntsis peb tsuas yog yuav tsum tau kuaj xyuas rau txeej txij li sim los faib `> isize::MAX` bytes yuav muaj tseeb swb.
// Ntawm 32-ntsis thiab 16-ntsis peb yuav tsum tau ntxiv ib qho tshwj xeeb ntxiv rau qhov no yog qhov peb tab tom khiav ntawm lub platform uas tuaj yeem siv tag nrho 4GB hauv qhov chaw siv, piv txwv li, PAE lossis x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Ib qho ua haujlwm tseem ceeb rau kev tshaj qhia lub peev xwm hla dhau.
// Qhov no yuav xyuas kom meej tias cov code tsim muaj feem cuam tshuam nrog cov panics yog tsawg heev li tsuas yog muaj ib qho chaw uas panics es tsis yog ib qho thoob thoob plaws qhov qauv.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}