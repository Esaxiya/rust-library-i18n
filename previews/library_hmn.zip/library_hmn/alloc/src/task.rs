#![stable(feature = "wake_trait", since = "1.51.0")]
//! Hom thiab Traits rau kev ua haujlwm nrog asynchronous paub tab.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Qhov kev siv ntawm waking ib txoj hauj lwm rau ib tug neeg tua.
///
/// Qhov no trait yuav siv tau los ua ib tug [`Waker`].
/// Ib executor yuav txhais tau ib qho kev siv ntawm no trait, thiab siv los mus tsim ib tug Waker yuav kis tau mus rau hauv lub paub tab uas tseg rau hais tias executor.
///
/// trait no yog qhov nco-nyab xeeb thiab ergonomic lwm txoj hauv kev tsim [`RawWaker`] X.
/// Nws txhawb nqa cov qauv tsim uas ua rau hauv cov ntaub ntawv siv los txog kev sawv los ua ib txoj haujlwm khaws cia rau hauv ib qho [`Arc`].
/// Ib txhia executors (tshwj xeeb tshaj yog cov neeg rau kos systems) yuav siv tsis tau qhov no API, uas yog vim li cas [`RawWaker`] tshwm sim raws li ib tug lwm txoj rau cov neeg systems.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Ib tug yooj yim `block_on` nuj nqi uas yuav siv sij hawm ib tug future thiab sau nws kom tiav nyob rau tam sim xov.
///
/// **Note:** Qhov kev piv txwv no suav kev paub qhov tseeb rau kev yooj yim.
/// Txhawm rau txhawm rau tiv thaiv kev tuag, kev tsim tawm-qib kev ua yeeb yam tseem yuav xav kom muaj kev hu xov tooj rau nruab nrab rau `thread::unpark` nrog rau cov kev thov zes.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Ib tus kws ntim xov uas tsim txoj xov tam sim no thaum hu.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Khiav ib future kom tiav nyob rau tam sim xov.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Pin future yog li nws tuaj yeem xaiv.
///     let mut fut = Box::pin(fut);
///
///     // Tsim cov ntsiab lus teb tshiab kom dhau mus rau future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Khiav future kom tiav.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Tsa no ua hauj lwm.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Tsa no ua hauj lwm tsis muaj siv cov waker.
    ///
    /// Yog hais tias ib tug executor txhawb ib tug cheaper txoj kev uas yuav sawv tsis muaj siv cov waker, nws yuav tsum override no.
    /// Los ntawm lub neej ntawd, nws clones tus [`Arc`] thiab hu [`wake`] ntawm tus clone.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // KEV RUAJ NTSEG: Qhov no muaj kev nyab xeeb vim tias tus kws ua khoom noj khoom haus muaj kev nyab xeeb
        // ib tug RawWaker los ntawm Arc<W>Cov.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Qhov no private muaj nuj nqi rau constructing ib RawWaker yog siv, es tsis
// inlining no mus rau hauv lub `From<Arc<W>> for RawWaker` impl, los xyuas kom meej tias cov kev nyab xeeb ntawm `From<Arc<W>> for Waker` tsis yog nyob ntawm seb qhov tseeb trait dispatch, es tsis txhob ob impls hu no muaj nuj nqi ncaj qha thiab ntsees.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Ntxiv rau cov kev siv suav ntawm arc rau nws.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Tsa los ntawm tus nqi, txav Arc rau hauv Wake::wake haujlwm
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Sawv los ntawm kev siv, qhwv tus neeg hnav lub xov hauv ManuallyDrop kom tsis txhob poob
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Txo kev suav suav ntawm Arc ntawm kev poob qis
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}