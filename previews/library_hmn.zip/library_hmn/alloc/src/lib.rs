//! # Rust lub tsev khaws ntawv thiab kev khaws cov ntawv loj
//!
//! Cov tsev qiv ntawv no muab cov taw tes ntse thiab sau ntawv rau kev tswj cov kab ke muaj txiaj ntsig.
//!
//! Cov tsev qiv ntawv no, zoo li libcore, feem ntau tsis tas yuav siv ncaj qha vim nws cov ntsiab lus rov muab xa tawm hauv [`std` crate](../std/index.html).
//! Crates uas siv `#![no_std]` attribute txawm li cas los xij yuav feem ntau tsis vam khom `std`, yog li lawv xav siv crate hloov no.
//!
//! ## Lub thawv muaj nuj nqis
//!
//! [`Box`] lub hom yog tus ntse yam pointer.Tsuas muaj ib tus tswv ntawm [`Box`], thiab tus tswv tuaj yeem txiav txim siab hloov pauv cov ntsiab lus, uas nyob ntawm qhov heap.
//!
//! Hom no tuaj yeem xa ntawm cov xov yooj yim raws li qhov loj ntawm `Box` tus nqi yog tib yam li ntawm tus pointer.
//! Cov ntaub ntawv zoo li ntoo yog feem ntau ua nrog cov thawv vim txhua tus ntawm feem ntau muaj tsuas yog ib tus tswv, niam txiv.
//!
//! ## Kev suav suav cov ntsiab lus
//!
//! [`Rc`] hom yog non-threadsafe siv-suav cov pointer hom npaj rau kev sib nco tsis pub dhau ib txoj xov.
//! Tus [`Rc`] pointer qhwv ib hom, `T`, thiab tsuas yog tso cai nkag mus `&T`, ib qho kev siv sib qhia.
//!
//! Hom no yog qhov muaj txiaj ntsig thaum muaj kev sib xyaw nrog kev sib xyaw (xws li siv [`Box`]) yog qhov txwv ib yam rau ib daim ntawv thov, thiab feem ntau ua khub nrog [`Cell`] lossis [`RefCell`] hom kom thiaj hloov tau.
//!
//!
//! ## Atomically siv suav cov lus taw qhia
//!
//! [`Arc`] hom yog xov paj sib xws ntawm [`Rc`] hom.Nws muab tag nrho cov kev ua haujlwm ntawm [`Rc`], tshwj tsis yog nws yuav tsum tau muaj cov hom `T` sib faib tau.
//! Txuas ntxiv, [`Arc<T>`][`Arc`] nws tus kheej xa tau thaum [`Rc<T>`][`Rc`] tsis yog.
//!
//! Cov hom no tso cai rau kev nkag mus rau cov ntaub ntawv muaj nyob rau hauv, thiab feem ntau yog ua ke nrog synchronization primitives xws li mutexes kom tso cai rau kev hloov pauv ntawm cov khoom siv sib koom.
//!
//! ## Collections
//!
//! Kev nqis tes ua ntawm cov ntaub ntawv hais txog hom phiaj dav dav feem ntau tau txhais hauv lub tsev qiv ntawv no.Lawv rov raug xa rov qab los ntawm [standard collections library](../std/collections/index.html).
//!
//! ## Heap cuam tshuam
//!
//! Lub [`alloc`](alloc/index.html) module txiav txim siab qhov qis-qis interface rau lub ntiaj teb kev faib cov qauv qub.Nws tseem tsis sib haum nrog libc allocator API.
//!
//! [`Arc`]: sync
//! [`Box`]: boxed
//! [`Cell`]: core::cell
//! [`Rc`]: rc
//! [`RefCell`]: core::cell
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(unused_attributes)]
#![stable(feature = "alloc", since = "1.36.0")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(allow(unused_variables), deny(warnings)))
)]
#![no_std]
#![needs_allocator]
#![warn(deprecated_in_future)]
#![warn(missing_docs)]
#![warn(missing_debug_implementations)]
#![allow(explicit_outlives_requirements)]
#![deny(unsafe_op_in_unsafe_fn)]
#![feature(rustc_allow_const_fn_unstable)]
#![cfg_attr(not(test), feature(generator_trait))]
#![cfg_attr(test, feature(test))]
#![cfg_attr(test, feature(new_uninit))]
#![feature(allocator_api)]
#![feature(vec_extend_from_within)]
#![feature(array_chunks)]
#![feature(array_methods)]
#![feature(array_windows)]
#![feature(allow_internal_unstable)]
#![feature(arbitrary_self_types)]
#![feature(async_stream)]
#![feature(box_patterns)]
#![feature(box_syntax)]
#![feature(cfg_sanitize)]
#![feature(cfg_target_has_atomic)]
#![feature(coerce_unsized)]
#![feature(const_btree_new)]
#![feature(const_fn)]
#![feature(cow_is_borrowed)]
#![feature(const_cow_is_borrowed)]
#![feature(destructuring_assignment)]
#![feature(dispatch_from_dyn)]
#![feature(core_intrinsics)]
#![feature(dropck_eyepatch)]
#![feature(exact_size_is_empty)]
#![feature(exclusive_range_pattern)]
#![feature(extend_one)]
#![feature(fmt_internals)]
#![feature(fn_traits)]
#![feature(fundamental)]
#![feature(inplace_iteration)]
#![feature(int_bits_const)]
// Technically, qhov no yog kab laum nyob hauv rustdoc: rustdoc pom cov ntaub ntawv ntawm `#[lang = slice_alloc]` block yog rau `&[T]`, uas tseem muaj cov ntaub ntawv siv cov yam ntxwv no hauv `core`, thiab tau chim tias lub qhov rooj tsis qhib.
// Qhov tseeb, nws yuav tsis xyuas rau lub rooj vag nta rau docs los ntawm lwm crates, tab sis vim tias qhov no tsuas tuaj yeem tshwm rau cov khoom lang, nws tsis zoo li tsim nyog kho.
//
//
#![feature(intra_doc_pointers)]
#![feature(lang_items)]
#![feature(layout_for_ptr)]
#![feature(maybe_uninit_ref)]
#![feature(negative_impls)]
#![feature(never_type)]
#![feature(nll)]
#![feature(nonnull_slice_from_raw_parts)]
#![feature(auto_traits)]
#![feature(option_result_unwrap_unchecked)]
#![feature(or_patterns)]
#![feature(pattern)]
#![feature(ptr_internals)]
#![feature(rustc_attrs)]
#![feature(receiver_trait)]
#![feature(min_specialization)]
#![feature(set_ptr_value)]
#![feature(slice_ptr_get)]
#![feature(slice_ptr_len)]
#![feature(slice_range)]
#![feature(staged_api)]
#![feature(str_internals)]
#![feature(trusted_len)]
#![feature(unboxed_closures)]
#![feature(unicode_internals)]
#![cfg_attr(bootstrap, feature(unsafe_block_in_unsafe_fn))]
#![feature(unsize)]
#![feature(unsized_fn_params)]
#![feature(allocator_internals)]
#![feature(slice_partition_dedup)]
#![feature(maybe_uninit_extra, maybe_uninit_slice, maybe_uninit_uninit_array)]
#![feature(alloc_layout_extra)]
#![feature(trusted_random_access)]
#![feature(try_trait)]
#![cfg_attr(bootstrap, feature(type_alias_impl_trait))]
#![cfg_attr(not(bootstrap), feature(min_type_alias_impl_trait))]
#![feature(associated_type_bounds)]
#![feature(slice_group_by)]
#![feature(decl_macro)]
// Tso cai kuaj cov tsev qiv ntawv no

#[cfg(test)]
#[macro_use]
extern crate std;
#[cfg(test)]
extern crate test;

// Module nrog macros sab hauv uas siv los ntawm lwm cov qauv (yuav tsum tau suav ua ntej lwm cov qauv).
#[macro_use]
mod macros;

// Heaps tau muab rau cov phiaj xwm qib qis kev faib tawm

pub mod alloc;

// Cov hom khoom qub uas siv heaps saum toj no

// Yuav tsum tau zwm rau qhov xwm txheej txiav txim siab qhov mod los ntawm `boxed.rs` kom tsis txhob theej tawm cov khoom lang-thaum lub tsev nyob hauv kev sim cfg;tab sis kuj yuav tsum tso cai code muaj `use boxed::Box;` ntawv tshaj tawm.
//
//
#[cfg(not(test))]
pub mod boxed;
#[cfg(test)]
mod boxed {
    pub use std::boxed::Box;
}
pub mod borrow;
pub mod collections;
pub mod fmt;
pub mod prelude;
pub mod raw_vec;
pub mod rc;
pub mod slice;
pub mod str;
pub mod string;
#[cfg(target_has_atomic = "ptr")]
pub mod sync;
#[cfg(target_has_atomic = "ptr")]
pub mod task;
#[cfg(test)]
mod tests;
pub mod vec;

#[doc(hidden)]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
pub mod __export {
    pub use core::format_args;
}