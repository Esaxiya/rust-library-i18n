//! Nco rau cov qib APIs

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // Cov no yog cov cim khawv koob kom hu rau lub chaw pabcuam hauv ntiaj teb.rustc ua kom lawv hu rau `__rg_alloc` thiab lwm yam.
    // yog tias muaj `#[global_allocator]` attribute (qhov chaws nthuav dav uas ntaus cim loj heev ua rau cov haujlwm ntawd), lossis hu rau kev pib ua haujlwm hauv libstd (`__rdl_alloc` thiab lwm yam)
    //
    // hauv `library/std/src/alloc.rs`) txwv tsis pub.
    // rustc fork ntawm LLVM kuj tshwj xeeb-cov haujlwm ntawm cov npe muaj nuj nqi no txhawm rau ua kom zoo rau lawv xws li `malloc`, `realloc`, thiab `free`, feem.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// Lub ntiaj teb no cim xeeb faib.
///
/// Cov hom no coj los saib xyuas [`Allocator`] trait los ntawm kev xa xov tooj mus rau tus neeg muab kev pab sau npe nrog `#[global_allocator]` tus cwj pwm yog tias muaj ib qho, lossis `std` crate lub neej ntawd.
///
///
/// Note: thaum hom no tsis ruaj khov, cov haujlwm uas nws muab tau tuaj yeem nkag los ntawm [free functions in `alloc`](self#functions).
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// Faib chaw nco nrog lub ntiaj teb kev faib khoom.
///
/// Qhov kev ua haujlwm no xa mus rau [`GlobalAlloc::alloc`] tus qauv ntawm cov neeg suav sau npe nrog `#[global_allocator]` tus cwj pwm yog tias muaj ib qho, lossis `std` crate lub neej ntawd.
///
///
/// Lub luag haujlwm no xav kom tau txiav txim siab saib xyuas `alloc` tus qauv ntawm [`Global`] hom thaum nws thiab [`Allocator`] trait ua ruaj khov.
///
/// # Safety
///
/// Saib [`GlobalAlloc::alloc`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// Faib lub cim xeeb nrog cov neeg muab nyiaj thoob ntiaj teb.
///
/// Qhov kev ua haujlwm no xa mus rau [`GlobalAlloc::dealloc`] tus qauv ntawm cov neeg suav sau npe nrog `#[global_allocator]` tus cwj pwm yog tias muaj ib qho, lossis `std` crate lub neej ntawd.
///
///
/// Lub luag haujlwm no xav kom tau txiav txim siab saib xyuas `dealloc` tus qauv ntawm [`Global`] hom thaum nws thiab [`Allocator`] trait ua ruaj khov.
///
/// # Safety
///
/// Saib [`GlobalAlloc::dealloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// Faib chaw nco nrog lub ntiaj teb kev faib khoom.
///
/// Qhov kev ua haujlwm no xa mus rau [`GlobalAlloc::realloc`] tus qauv ntawm cov neeg suav sau npe nrog `#[global_allocator]` tus cwj pwm yog tias muaj ib qho, lossis `std` crate lub neej ntawd.
///
///
/// Lub luag haujlwm no xav kom tau txiav txim siab saib xyuas `realloc` tus qauv ntawm [`Global`] hom thaum nws thiab [`Allocator`] trait ua ruaj khov.
///
/// # Safety
///
/// Saib [`GlobalAlloc::realloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// Faib cov xoom-pib kev nco nrog lub ntiaj teb kev faib khoom.
///
/// Qhov kev ua haujlwm no xa mus rau [`GlobalAlloc::alloc_zeroed`] tus qauv ntawm cov neeg suav sau npe nrog `#[global_allocator]` tus cwj pwm yog tias muaj ib qho, lossis `std` crate lub neej ntawd.
///
///
/// Lub luag haujlwm no xav kom tau txiav txim siab saib xyuas `alloc_zeroed` tus qauv ntawm [`Global`] hom thaum nws thiab [`Allocator`] trait ua ruaj khov.
///
/// # Safety
///
/// Saib [`GlobalAlloc::alloc_zeroed`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // KEV RUAJ NTSEG: `layout` tsis yog xoom hauv qhov loj me,
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // KEV RUAJ NTSEG: Tib yam li `Allocator::grow`
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // KEV RUAJ NTSEG: `new_size` tsis yog xoom li `old_size` ntau dua los yog sib npaug ntawm `new_size`
            // raws li kev xav tau ntawm kev nyab xeeb.Lwm cov xwm txheej yuav tsum tau tswj hwm tus neeg hu
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` tej zaum kuaj rau `new_size >= old_layout.size()` lossis qee yam zoo sib xws.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // KEV RUAJ NTSEG: vim `new_layout.size()` yuav tsum muaj ntau dua lossis sib npaug `old_size`,
            // ob qho tib si qub thiab lub cim xeeb tshiab tseem siv tau rau kev nyeem thiab sau rau `old_size` bytes.
            // Tsis tas li, vim tias cov nyiaj faib qub tsis tau cuam tshuam, nws tsis tuaj yeem sib tshooj `new_ptr`.
            // Yog li, kev hu mus rau `copy_nonoverlapping` muaj kev ruaj ntseg.
            // Daim ntawv cog lus kev nyab xeeb rau `dealloc` yuav tsum muaj kev cia siab los ntawm tus neeg hu tuaj.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // KEV RUAJ NTSEG: `layout` tsis yog xoom hauv qhov loj me,
            // lwm cov xwm txheej yuav tsum tau tsa los ntawm tus neeg hu
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // TXUJ CI: txhua qhov xwm txheej yuav tsum raug tswj hwm los ntawm tus neeg hu xov tooj
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // TXUJ CI: txhua qhov xwm txheej yuav tsum raug tswj hwm los ntawm tus neeg hu xov tooj
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // TXUJ CI: cov xwm txheej yuav tsum raug tswj hwm los ntawm tus neeg hu
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // KEV RUAJ NTSEG: `new_size` tsis yog xoom.Lwm cov xwm txheej yuav tsum tau tswj hwm tus neeg hu
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` tej zaum kuaj rau `new_size <= old_layout.size()` lossis qee yam zoo sib xws.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // KEV RUAJ NTSEG: vim `new_size` yuav tsum me dua lossis sib npaug `old_layout.size()`,
            // ob qho tib si qub thiab lub cim xeeb tshiab tseem siv tau rau kev nyeem thiab sau rau `new_size` bytes.
            // Tsis tas li, vim tias cov nyiaj faib qub tsis tau cuam tshuam, nws tsis tuaj yeem sib tshooj `new_ptr`.
            // Yog li, kev hu mus rau `copy_nonoverlapping` muaj kev ruaj ntseg.
            // Daim ntawv cog lus kev nyab xeeb rau `dealloc` yuav tsum muaj kev cia siab los ntawm tus neeg hu tuaj.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// Tus faib nyiaj rau cov kis tshwj xeeb.
// Txoj haujlwm no yuav tsum tsis txhob poob siab.Yog tias nws ua li ntawd, MIR codegen yuav swb.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// Qhov kos npe no yuav tsum yog tib yam li `Box`, txwv tsis pub ICE yuav tshwm sim.
// Thaum ib qho tshwj xeeb txuas rau `Box` ntxiv (zoo li `A: Allocator`), qhov no yuav tsum tau txuas ntxiv ntawm no ib yam nkaus.
// Piv txwv li yog `Box` hloov mus rau `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)`, txoj haujlwm no yuav tsum tau hloov mus rau `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)` thiab.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # Kev tshem tawm tus yuam kev

extern "Rust" {
    // Qhov no yog lub cim khawv koob kom hu rau lub ntiaj teb faib kev daws teeb meem.
    // rustc tsim nws kom hu `__rg_oom` yog tias muaj `#[alloc_error_handler]`, lossis hu rau kev pib ua haujlwm hauv qab (`__rdl_oom`) txwv tsis pub.
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// Tawg ntawm lub cim xeeb kev ua yuam kev lossis tsis ua haujlwm.
///
/// Cov neeg hu xov tooj ntawm lub cim xeeb nco APIs uas xav rho tawm kev suav hauv kev teb rau qhov kev faib yuam kev raug txhawb kom hu rau txoj haujlwm no, es tsis hu ncaj qha `panic!` lossis zoo sib xws.
///
///
/// Lub neej qub kev coj ua ntawm txoj haujlwm no yog los luam cov lus rau tus qauv kev ua yuam kev thiab ua tiav cov txheej txheem.
/// Nws tuaj yeem hloov nrog [`set_alloc_error_hook`] thiab [`take_alloc_error_hook`].
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// Rau kev faib cov xeem `std::alloc::handle_alloc_error` tuaj yeem siv ncaj qha.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // hu ua ntawm generated `__rust_alloc_error_handler`

    // yog tias tsis muaj `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // yog tias muaj `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// Ua haujlwm tshwj xeeb rau cov pob zeb rau kev faib ua ntej, kev tsis muaj peev xwm nco tau.
/// Siv `Box::clone` thiab `Rc`/`Arc::make_mut`.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Tau muab faib *ua ntej* yuav tso cai rau qhov kev ua kom zoo tsim cov nqi cloned nyob rau hauv-chaw, hla hauv zos thiab txav chaw.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Peb tuaj yeem tuaj yeem luam nyob-hauv-chaw, yam tsis tau cuam tshuam nrog ib tus nqi hauv nroog.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}