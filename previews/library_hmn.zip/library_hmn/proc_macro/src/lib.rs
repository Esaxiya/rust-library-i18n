//! Ib tug kev pab txhawb nqa cov tsev qiv ntawv rau macro sau phau ntawv thaum defining tshiab macros.
//!
//! Qhov no tsev qiv ntawv, yog muab los ntawm tus txheej txheem tis, muab lub hom consumed nyob rau hauv lub interfaces ntawm procedurally txhais macro txhais cov ntsiab lus xws li muaj nuj nqi zoo li macros `#[proc_macro]`, macro cwj pwm `#[proc_macro_attribute]` thiab kev cai neeg attributes`#[proc_macro_derive] '.
//!
//!
//! Saib [the book] rau ntxiv.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Kev txiav txim siab seb puas yog proc_macro tau ua kom nkag mus rau cov kev pab cuam uas tau muaj tam sim no.
///
/// Lub proc_macro crate yog tsuas yog npaj rau kev siv hauv qhov kev siv ntawm cov txheej txheem kev macros.Tag nrho cov kev khiav dej num nyob rau hauv no crate panic yog invoked los ntawm sab nraum ntawm ib tug txheej txheem macro, xws li los ntawm ib tug muaj tsab ntawv los yog tsev kuaj los yog dog dig Rust binary.
///
/// Nrog xav txog Rust cov tsev qiv ntawv uas yog tsim los txhawb ob macro thiab uas tsis yog-macro siv tus neeg mob, `proc_macro::is_available()` muab ib tug uas tsis yog-panicking txoj kev mus ntes seb tus infrastructure yuav tsum tau siv cov API ntawm proc_macro yog presently muaj.
/// Rov qab los yog muaj tseeb yog tias tso tawm sab hauv ntawm tus txheej txheem loj, tsis muaj tseeb yog tias tau los ntawm lwm qhov binary.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// Lub ntsiab yam yog muab los ntawm no crate, cov sawv cev ib tug paub daws teeb kwj ntawm cov tokens, los yog, ntau yeej, ib tug sib lawv liag ntawm token ntoo.
/// Cov hom muab interfaces rau iterating hla cov token ntoo thiab, conversely, sau tus naj npawb ntawm token ntoo mus rau hauv ib kwj.
///
///
/// Qhov no yog ob lub tswv yim thiab tso zis ntawm `#[proc_macro]`, `#[proc_macro_attribute]` thiab `#[proc_macro_derive]` txhais cov ntsiab lus.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Yuam kev rov qab los ntawm `TokenStream::from_str`.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Rov ib qho kev npliag `TokenStream` muaj tsis muaj token ntoo.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Tshawb xyuas yog tias `TokenStream` no khoob.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Kev sim tsoo txoj hlua rau tokens thiab parse cov tokens mus rau token cov kwj deg.
/// Tuaj yeem poob rau qee qhov laj thawj, piv txwv li, yog hais tias txoj hlua muaj qhov tsis muaj qhov tseem ceeb los yog cov cim tsis muaj nyob hauv hom lus.
///
/// Txhua tokens hauv cov dej ntws parsed tau `Span::call_site()` dav.
///
/// NOTE: ib co uas tsis yuav ua rau panics es tsis txhob ntawm rov qab los `LexError`.Peb muaj txoj cai los mus hloov cov uas tsis mus rau hauv 'LexError`s tom qab.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, tus choj tsuas yog muab `to_string`, siv `fmt::Display` raws nws (qhov thim rov qab ntawm kev sib raug zoo li ib txwm ntawm ob).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Prints lub token kwj raws li ib txoj hlua uas yog yuav tsum tau losslessly convertible rov qab mus rau hauv lub tib token kwj (modulo spans), tsuas yog rau tejzaum nws 'TokenTree: : Group`s nrog `Delimiter::None` delimiters thiab tsis zoo numeric literals.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Luam tawm token nyob rau hauv ib daim ntawv yooj yim rau kev debugging.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Tsim token kwj muaj ib qho token ntoo.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Sau ib tug xov tooj ntawm token ntoo mus rau hauv ib tug nkaus xwb kwj.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// Ib tug "flattening" lag luam rau token ntws, sau token ntoo los ntawm ntau yam token ntws mus rau hauv ib tug nkaus xwb kwj.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Siv qhov ua tiav tau zoo if/when tau.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Pej xeem siv cov ntsiab lus rau `TokenStream` hom, xws li ntsuas khoom.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// Tus ntsuas pa hla 'TokenStream's' TokenTree`.
    /// Lub iteration yog "shallow", xws li, cov iterator tsis recurse rau hauv delimited pawg, thiab rov qab tag nrho cov pab pawg raws li token ntoo.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` lees txais kev ua txhaum tokens thiab nthuav mus rau `TokenStream` piav qhia txog cov tswv yim.
/// Piv txwv li, `quote!(a + b)` yuav tsim ib tug qhia, uas, thaum soj ntsuam, constructs lub `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Unquoting yog ua li cas nrog `$`, thiab ua hauj lwm los ntawm kev noj ib tom ntej no ident li cov unquoted lub sij hawm.
/// Txhawm rau hais `$` nws tus kheej, siv `$$`.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// Ib cheeb tsam ntawm qhov chaws, nrog cov ntaub ntawv nthuav macro.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Tsim cov `Diagnostic` tshiab nrog muab `message` ntawm kev nthuav dav `self`.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Ib tug ntsua kev uas daws nyob rau macro txhais site.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// Lub luv ntawm lub invocation ntawm tus txheej txheem tam sim no loj heev.
    /// Cov cim tsim nrog qhov kev ncua no yuav raug daws zoo ib yam li lawv tau sau ncaj qha rau ntawm qhov chaw hu xov tooj hu chaw (hu-huv qhov chaw huv) thiab lwm tus lej ntawm qhov chaw hu xov tooj loj yuav tuaj yeem xa mus rau lawv tib yam.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// Ib qho kev nthuav dav uas sawv cev rau `macro_rules` kev tu cev, thiab qee zaum daws nyob ntawm qhov chaw txhais cov ntsiab lus (cov hloov hauv zos, cov ntawv sau, `$crate`) thiab qee zaum ntawm qhov chaw hu macro (txhua yam ntxiv).
    ///
    /// Lub nrug qhov chaw raug coj tawm los ntawm tus hu-lub tsev kawm ntawv.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// Tus thawj cov ntaub ntawv mus rau hauv no ncua ntsiab lus.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// Lub `Span` rau lub tokens nyob rau hauv lub yav dhau los macro expansion ntawm uas `self` twb generated los ntawm, yog tias muaj.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// Cov luv rau lub keeb kwm qhov chaws uas `self` twb generated los ntawm.
    /// Yog hais tias qhov no `Span` twb tsis generated los ntawm lwm macro expansions ces rov qab los tus nqi yog tib yam li `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Tau lub pib line/column nyob rau hauv lub qhov chaw ua ntaub ntawv thov rau qhov no luv.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Tau txais qhov xaus line/column hauv cov ntawv xa mus rau cov no nrug.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Tsim ib tug tshiab saib ntsoov txog encompassing `self` thiab `other`.
    ///
    /// Rov qab los `None` yog `self` thiab `other` yog los ntawm txawv cov ntaub ntawv.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Tsim ib tug tshiab saib ntsoov txog nrog rau cov tib line/column ntaub ntawv raws li `self` tab sis hais tias lawm cov cim li tab sis yog nws nyob rau `other`.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Tsim ib tug tshiab saib ntsoov txog nrog tib lub npe daws teeb meem cwj pwm raws li `self` tab sis nrog lub line/column cov ntaub ntawv ntawm `other`.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Muab piv rau kev soj ntsuam seb lawv puas sib npaug.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Rov qab los rau cov kab ntawv hauv qab ib ncua.
    /// Qhov no khaws cia tus thawj qhov chaws, nrog rau thaj chaw thiab lus.
    /// Nws tsuas yog rov qab ua qhov tshwm sim yog tias qhov kawg sib raug rau qhov tiag qhov chaws.
    ///
    /// Note: Lub observable tshwm sim ntawm ib tug macro yuav tsum tau tsuas vam khom rau tus tokens thiab tsis nyob rau hauv no qhov twg los cov ntawv nyeem.
    ///
    /// Qhov txiaj ntsig ntawm txoj haujlwm no yog kev siv zog zoo tshaj plaws los siv rau kev kuaj mob tsuas yog.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Luam tawm qhov luv hauv daim foos yooj yim rau kev debugging.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Ib txoj kab-kem khub sawv cev rau lub caij pib los yog qhov xaus ntawm ib tug `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// 1-cim kab nyob rau hauv cov ntaub ntawv cov ntaub ntawv uas pib loj lossis xaus (inclusive).
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// Tus 0-indexed sab (hauv UTF-8 cov cim) nyob rau hauv cov ntaub ntawv cov ntaub ntawv ntawm cov kev ncua pib lossis xaus (inclusive).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Cov ntaub ntawv los ntawm kev muab `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Tau txoj kev mus rau qhov no qhov twg los ua ntaub ntawv thov.
    ///
    /// ### Note
    /// Yog hais tias qhov chaws ncua cuam tshuam nrog no `SourceFile` tau tsim los ntawm ib qho sab nraud loj heev, qhov loj heev, qhov no yuav tsis yog txoj hauv kev ntawm cov filesystem.
    /// Siv [`is_real`] los kuaj.
    ///
    /// Tsis tas li ntawd nco tias txawm yog tias `is_real` rov `true`, yog `--remap-path-prefix` twb dhau rau qhov hais kom ua kab, txoj kev raws li muab tej zaum yuav tsis tau yuav siv tau.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Rov `true` yog qhov ua ntaub ntawv thov yog ib tug tiag tiag qhov chaw ua ntaub ntawv thov, thiab tsis generated los ntawm ib tug sab nraud macro lub expansion.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Qhov no yog lub hack kom txog thaum intercrate spans raug siv thiab peb tuaj yeem muaj cov ntaub ntawv muaj qhov tseeb rau spans generated hauv macros sab nraud.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// Ib tug tib token los yog ib tug delimited ib theem zuj zus ntawm token ntoo (xws li, `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// Ib tug token kwj surrounded los ntawm bracket delimiters.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Ib qho paub ua cim.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Ib qho cim ntu ((+ + `, `,`, `$`, thiab lwm yam).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// Ib tug literal cim (`'a'`), txoj hlua (`"hello"`), tooj (`2.3`), etc.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Rov qab los saib qhov dav ntawm tsob ntoo no, xa mus rau `span` tus qauv ntawm qhov muaj token lossis kwj qeeb.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Kho lub ntsiag to rau *tsuas yog token*.
    ///
    /// Nco ntsoov tias yog tias token no yog `Group` ces hom no yuav tsis hloov kho qhov kev ncua ntawm txhua qhov ntawm sab hauv tokens, qhov no yuav tsuas yog faib rau `set_span` tus qauv ntawm txhua qhov sib txawv.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// Prints token tsob ntoo nyob rau hauv ib daim ntawv yooj yim rau debugging.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Txhua yam ntawm cov muaj lub npe nyob rau hauv lub struct hom nyob rau hauv lub derived debug, yog li ntawd tsis txhob thab nrog ib tug txheej ntxiv txog kev indirection
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, tus choj tsuas yog muab `to_string`, siv `fmt::Display` raws nws (qhov thim rov qab ntawm kev sib raug zoo li ib txwm ntawm ob).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Luam tawm token ntoo ua ib txoj hlua uas xav tias yuav ploj mus yam tsis hloov rov qab mus rau hauv tib lub ntoo token (modulo spans), tsuas yog muaj peev xwm `TokenTree: : Pawg` nrog `Delimiter::None` delimiters thiab cov lej tsis zoo.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Ib tus delimited token dej.
///
/// Ib tug `Group` hauv muaj ib tug `TokenStream` uas yog surrounded los ntawm 'Delimiter`s.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Piav qhia qhov ua ntu zus ntawm token ntoo raug ncua.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// Ib implicit delimiter, uas tej zaum yuav, piv txwv li, tshwm sim nyob ib ncig ntawm tokens los ntawm ib tug "macro variable" `$var`.
    /// Nws yog ib qho tseem ceeb ntawm kev tiv thaiv tus neeg teb xov tooj ua ntej hauv kis xws li `$var * 3` qhov twg `$var` yog `1 + 2`.
    /// Kev tsis ncaj ntawm qhov tsis tuaj yeem tsis muaj txoj sia nyob puag ncig ntawm token ntws los ntawm txoj hlua.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Tsim cov `Group` tshiab nrog rau tus muab cov delimiter thiab token ntws.
    ///
    /// Qhov no constructor yuav teem lub luv rau pab pawg neeg no mus `Span::call_site()`.
    /// Txhawm rau hloov txoj kev luv luv koj tuaj yeem siv `set_span` tus qauv hauv qab no.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Rov qab rau cov khoom txiav ntawm `Group` no
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Rov qab `TokenStream` ntawm tokens uas yog qeeb hauv `Group` X no.
    ///
    /// Nco ntsoov tias lub rov qab token kwj tsis muaj xws li cov delimiter rov qab saum toj no.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Rov qab los qhib kev ncua rau cov cwj ciam Zim token, hla tag nrho `Group`.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Rov lub luv taw tes rau cov lus qhib delimiter ntawm no pab pawg neeg.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Rov qab los lub luv taw tes rau tus kaw delimiter ntawm no pab pawg neeg.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Kho lub ntsiag to rau qhov no `Pab pawg neeg 'lub delimiters, tab sis tsis yog nws tokens.
    ///
    /// Qhov no txoj kev yuav **tsis** teem lub luv ntawm tag nrho cov sab hauv tokens tsim los ntawm pab pawg neeg no, tab sis, theej nws yuav tsuas muab lub luv ntawm lub delimiter tokens nyob rau theem ntawm cov `Group`.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, tus choj tsuas yog muab `to_string`, siv `fmt::Display` raws nws (qhov thim rov qab ntawm kev sib raug zoo li ib txwm ntawm ob).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Prints cov pab pawg neeg raws li ib txoj hlua uas yuav tsum tau losslessly convertible rov qab mus rau hauv lub tib pab pawg (modulo spans), tsuas yog rau tejzaum nws 'TokenTree: : Group`s nrog `Delimiter::None` delimiters.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// Ib qho `Punct` yog ib cov cim nkaus xwb xws li `+`, `-` lossis `#`.
///
/// Ntau tus neeg ua haujlwm zoo ib yam li `+=` yog sawv cev raws li ob qho piv txwv ntawm `Punct` nrog cov ntawv sib txawv ntawm `Spacing` xa rov qab.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Seb ib qho `Punct` tau ua raws tam sim ntawd los ntawm lwm tus `Punct` lossis ua raws lwm token lossis whitespace.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// xws li, `+` yog `Alone` nyob rau hauv `+ =`, `+ident` los yog `+()`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// xws li, `+` yog `Joint` nyob rau hauv `+=` los yog `'#`.
    /// Tsis tas li ntawd, ib qho lus hais `'` tuaj yeem koom nrog nrog cov cim sau los ua lub neej ntev `'ident`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Tsim tus tshiab `Punct` los ntawm qhov muab lub cim thiab nrug.
    /// Lub `ch` sib cav yuav tsum muaj ib tug siv tau punctuation cim tso cai los ntawm cov lus, txwv tsis pub cov kev ua yuav panic.
    ///
    /// Cov rov qab `Punct` yuav muaj lub neej ntawd saib ntsoov txog ntawm `Span::call_site()` uas yuav tsum tau ntxiv configured nrog lub `set_span` txoj kev hauv qab no.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Rov qhov muaj nqis ntawm no cim cim raws li `char`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Rov qab los lub yov ntawm no cim cim, cim tias seb thaum seb nws yog tam sim ntawd raws li los ntawm lwm `Punct` nyob rau hauv lub token kwj, yog li lawv muaj peev xwm uas yuav ua ke rau hauv ib lub multi-cim neeg teb xov tooj (`Joint`), los yog nws yog ua raws li los ntawm ib co lwm yam token los yog whitespace (`Alone`) li cov neeg teb xov tooj muaj yeej tas lawm.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Rov qab los tso lub luv rau cov cim no.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Kho lub ntsab rau cov cim no.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, tus choj tsuas yog muab `to_string`, siv `fmt::Display` raws nws (qhov thim rov qab ntawm kev sib raug zoo li ib txwm ntawm ob).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Luam tawm cov cim sau ntawv raws li cov hlua uas yuav tsum muaj kev ploj zoo li qub hloov mus ua lwm tus neeg.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// Ib qho cim qhia (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Tsim ib tug tshiab `Ident` nrog qhov muab `string` li zoo raws li lub teev `span`.
    /// Lub `string` sib cav yuav tsum muaj ib tug siv tau qhia tso cai los ntawm cov lus (xws li keywords, xws li `self` los yog `fn`).Txwv tsis pub, txoj haujlwm yuav panic.
    ///
    /// Nco ntsoov tias `span`, tam sim no nyob rau hauv rustc, configures tus tu cov ntaub ntawv rau qhov no qhia tau.
    ///
    /// Raws li ntawm lub sij hawm no `Span::call_site()` ntsees opts-nyob rau hauv los "call-site" tu ntsiab lus uas identifiers tsim nrog rau qhov no luv yuav tsum daws raws li yog hais tias lawv tau sau ncaj qha mus rau qhov chaw ntawm lub macro hu, thiab lwm yam code ntawm cov macro hu qhov chaw yuav tsum tau xa mus rau lawv thiab.
    ///
    ///
    /// Tom qab kev nthuav dav xws li `Span::def_site()` yuav tso cai kom nkag mus "definition-site" kev tu cev lub ntsiab lus tias cov cim qhia tau tsim nrog qhov kev ncua no yuav raug daws nyob rau ntawm qhov chaw ntawm cov ntsiab lus txhais thiab lwm cov cai ntawm qhov chaw macro hu yuav tsis tuaj yeem xa mus rau lawv.
    ///
    /// Vim tam sim no tseem ceeb ntawm kev tu cev no constructor, tsis zoo li lwm tokens, yuav tsum tau ib tug `Span` yuav tsum tau teev nyob rau hauv kev tsim kho.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// Tib yam li `Ident::new`, tab sis tsim ib tug nyoos qhia (`r#ident`).
    /// `string` kev sib cav yog qhov ua pov thawj tseem ceeb tau tso cai los ntawm hom lus (suav nrog cov ntsiab lus, piv txwv li `fn`).
    /// Cov ntsiab lus tseem ceeb uas yuav siv tau nyob rau hauv kab ntu (xws li
    /// `self`, 'Super`) yog tsis txaus siab, thiab yuav ua rau ib tug panic.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Rov qab tau qhov kev ncua luv ntawm `Ident` no, nkag mus rau txhua txoj hlua rov qab los ntawm [`to_string`](Self::to_string).
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Configures tus ncua ntawm no `Ident`, tejzaum nws hloov nws cov kev tu cev lub ntsiab lus teb.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, tus choj tsuas yog muab `to_string`, siv `fmt::Display` raws nws (qhov thim rov qab ntawm kev sib raug zoo li ib txwm ntawm ob).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Luam tawm tus neeg paub tias yog txoj hlua uas yuav tsum muaj kev ploj zuj zus rov qab mus ua lub cim qub.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// Txoj hlua tiag tiag (`"hello"`), byte hlua (`b"hello"`), cim (`'a'`), byte cim (`b'a'`), tus lej sib ntxiv lossis ntab ntus cov naj npawb nrog lossis tsis txuas (`1`, `1u8`, `2.3`, `2.3f32`).
///
/// Boolean cov ntawv nyeem zoo ib yam li `true` thiab `false` tsis yog nyob ntawm no, lawv yog 'Ident `.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Tsim cov ntawv rau tus lej tom qab pib tshiab nrog tus nqi teev.
        ///
        /// Qhov no muaj nuj nqi yuav tsim ib tug integer li `1u32` qhov twg lub integer nqi teev yog thawj ib feem ntawm lub token thiab cov ib yog tseem suffixed kawg.
        /// Literals tsim los ntawm cov zauv negative tej zaum yuav tsis ciaj sia round-trips los ntawm `TokenStream` los yog cov hlua thiab tej zaum yuav tawg mus rau hauv ob tokens (`-` thiab zoo literal).
        ///
        ///
        /// Literals tsim los ntawm cov qauv no muaj cov `Span::call_site()` ncua los ntawm neej ntawd hais, uas yuav tsum tau teeb nrog lub `set_span` txoj kev hauv qab no.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Tsim kom muaj tus lej unsuffixed tus lej tshiab nrog tus nqi teev.
        ///
        /// Txoj haujlwm no yuav tsim ib qho lej zoo ib yam li `1` qhov twg tus lej tus lej teev yog thawj ntu ntawm token.
        /// Tsis muaj cov ntawv teev lus dab tsi nyob ntawm no token, lub ntsiab lus tias kev nkag siab zoo li `Literal::i8_unsuffixed(1)` yog sib npaug rau `Literal::u32_unsuffixed(1)`.
        /// Cov lus dag tsim los ntawm cov zauv tsis zoo yuav tsis ciaj sia nyob rau rountrips los ntawm `TokenStream` lossis cov hlua thiab yuav tawg ua ob tokens (`-` thiab qhov tseeb zoo).
        ///
        ///
        /// Literals tsim los ntawm cov qauv no muaj cov `Span::call_site()` ncua los ntawm neej ntawd hais, uas yuav tsum tau teeb nrog lub `set_span` txoj kev hauv qab no.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Tsim ib qho tshiab unsuffixed ntab-kis lus.
    ///
    /// Qhov no constructor yog zoo li cov uas zoo li `Literal::i8_unsuffixed` qhov twg lub float tus nqi yog tawm txim liab ncaj qha mus rau hauv lub token tab sis tsis muaj suffix yog siv, ces nws tej zaum yuav inferred los ua ib tug `f64` tom qab nyob rau hauv lub compiler.
    ///
    /// Cov lus dag tsim los ntawm cov zauv tsis zoo yuav tsis ciaj sia nyob rau rountrips los ntawm `TokenStream` lossis cov hlua thiab yuav tawg ua ob tokens (`-` thiab qhov tseeb zoo).
    ///
    /// # Panics
    ///
    /// Txoj haujlwm no yuav tsum tau hais tias ntab ntab tsis muaj qhov txawv, piv txwv li yog tias nws yog infinity lossis NaN txoj haujlwm no yuav panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Tsim ib cov ntawv cim xaus lus tshiab-xaus.
    ///
    /// Tus kws tsim qauv no yuav tsim cov lus sau zoo li `1.0f32` qhov twg tus nqi teev yog ua ntej ntu ntawm token thiab `f32` yog cov ntawv tom qab ntawm token.
    /// Qhov token yuav zoo li no yuav tsum yog `f32` hauv lub compiler.
    /// Cov lus dag tsim los ntawm cov zauv tsis zoo yuav tsis ciaj sia nyob rau rountrips los ntawm `TokenStream` lossis cov hlua thiab yuav tawg ua ob tokens (`-` thiab qhov tseeb zoo).
    ///
    ///
    /// # Panics
    ///
    /// Txoj haujlwm no yuav tsum tau hais tias ntab ntab tsis muaj qhov txawv, piv txwv li yog tias nws yog infinity lossis NaN txoj haujlwm no yuav panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Tsim ib qho tshiab unsuffixed ntab-kis lus.
    ///
    /// Qhov no constructor yog zoo li cov uas zoo li `Literal::i8_unsuffixed` qhov twg lub float tus nqi yog tawm txim liab ncaj qha mus rau hauv lub token tab sis tsis muaj suffix yog siv, ces nws tej zaum yuav inferred los ua ib tug `f64` tom qab nyob rau hauv lub compiler.
    ///
    /// Cov lus dag tsim los ntawm cov zauv tsis zoo yuav tsis ciaj sia nyob rau rountrips los ntawm `TokenStream` lossis cov hlua thiab yuav tawg ua ob tokens (`-` thiab qhov tseeb zoo).
    ///
    /// # Panics
    ///
    /// Txoj haujlwm no yuav tsum tau hais tias ntab ntab tsis muaj qhov txawv, piv txwv li yog tias nws yog infinity lossis NaN txoj haujlwm no yuav panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Tsim ib cov ntawv cim xaus lus tshiab-xaus.
    ///
    /// Tus kws tsim qauv no yuav tsim cov lus sau zoo li `1.0f64` qhov twg tus nqi teev yog qhov ua ntej ntawm token thiab `f64` yog cov ntawv tom qab ntawm token.
    /// Qhov token yuav zoo li no yuav tsum yog `f64` hauv lub compiler.
    /// Cov lus dag tsim los ntawm cov zauv tsis zoo yuav tsis ciaj sia nyob rau rountrips los ntawm `TokenStream` lossis cov hlua thiab yuav tawg ua ob tokens (`-` thiab qhov tseeb zoo).
    ///
    ///
    /// # Panics
    ///
    /// Txoj haujlwm no yuav tsum tau hais tias ntab ntab tsis muaj qhov txawv, piv txwv li yog tias nws yog infinity lossis NaN txoj haujlwm no yuav panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// Txoj hlua ncaj ncees.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Cim xeeb ceem.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Byte txoj hlua ib ntus.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Rov lub luv encompassing no literal.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Configures lub siab txuam rau qhov no leej twg.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Rov ib `Span` uas yog ib tug subset ntawm `self.span()` muaj tsuas qhov bytes nyob rau hauv ntau yam `range`.
    /// Rov qab `None` yog tias qhov xav tau-yuav txiav kom nruj yog sab nraud qhov ciam ntawm `self`.
    ///
    // FIXME(SergioBenitez): xyuas tias cov byte ntau pib thiab xaus ntawm ib tug UTF-8 ciam ntawm lub hauv paus.
    // txwv tsis pub, nws muaj peev xwm pom tias panic yuav tshwm sim lwm qhov thaum cov ntawv luam tawm.
    // FIXME(SergioBenitez): muaj yog tsis muaj txoj kev rau cov neeg siv paub dab tsi `self.span()` tau maps rau, yog li no txoj kev yuav tam sim no tsuas yog hu ua blindly.
    // Piv txwv li, `to_string()` rau lub cim 'c' rov "'\u{63}'";muaj yog tsis muaj txoj kev rau cov neeg siv kom paub seb tus twg los ntawv nyeem yog 'c' los yog hais tias nws yog '\u{63}'.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) ib yam dab tsi zoo li rau `Option::cloned`, tab sis rau `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, tus choj tsuas yog muab `to_string`, siv `fmt::Display` raws nws (qhov thim rov qab ntawm kev sib raug zoo li ib txwm ntawm ob).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Luam tawm qhov sau cia raws li ib txoj hlua uas yuav tsum muaj kev hloov pauv zoo li rov qab mus ua qhov qub (tshwj tsis yog rau kev suav sib npaug rau ntab ntab cov ntawv nyeem).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Soj ntsuam kev nkag mus rau ib puag ncig cov hloov pauv.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Khaws ib qho kev hloov pauv ib puag ncig thiab ntxiv rau nws los tsim cov ntaub ntawv kev vam khom.
    /// Tsim cov kev ua haujlwm ntawm cov compiler yuav paub tias qhov sib txawv tau nkag thaum lub sijhawm ua ke, thiab yuav muaj peev xwm rov tsim dua thaum tus nqi ntawm cov kev hloov pauv ntawd.
    ///
    /// Dhau li ntawm kev vam khom rau kev ua raws li txoj haujlwm no yuav tsum yog sib npaug rau `env::var` los ntawm lub tsev qiv ntawv txheem, tshwj tsis yog kev sib cav yuav tsum yog UTF-8.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}