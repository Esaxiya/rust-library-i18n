//! `Cell` variant rau (scoped) existential lifetimes.

use std::cell::Cell;
use std::mem;
use std::ops::{Deref, DerefMut};

/// Hom lambda thov, nrog lub neej.
#[allow(unused_lifetimes)]
pub trait ApplyL<'a> {
    type Out;
}

/// Hom lambda noj ib lub neej, piv txwv li, `Lifetime -> Type`.
pub trait LambdaL: for<'a> ApplyL<'a> {}

impl<T: for<'a> ApplyL<'a>> LambdaL for T {}

// HACK(eddyb) ua hauj lwm nyob ib ncig ntawm projection txwv nrog ib tug newtype FIXME(#52812) hloov nrog `&'a mut <T as ApplyL<'b>>::Out`
//
pub struct RefMutL<'a, 'b, T: LambdaL>(&'a mut <T as ApplyL<'b>>::Out);

impl<'a, 'b, T: LambdaL> Deref for RefMutL<'a, 'b, T> {
    type Target = <T as ApplyL<'b>>::Out;
    fn deref(&self) -> &Self::Target {
        self.0
    }
}

impl<'a, 'b, T: LambdaL> DerefMut for RefMutL<'a, 'b, T> {
    fn deref_mut(&mut self) -> &mut Self::Target {
        self.0
    }
}

pub struct ScopedCell<T: LambdaL>(Cell<<T as ApplyL<'static>>::Out>);

impl<T: LambdaL> ScopedCell<T> {
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new(value: <T as ApplyL<'static>>::Out) -> Self {
        ScopedCell(Cell::new(value))
    }

    /// Teeb tus nqi hauv `self` rau `replacement` thaum khiav `f`, uas tau txais tus nqi qub, sib ntxiv.
    /// Cov laus tus nqi yuav tsum tau rov qab tom qab `f` nyob, txawm los ntawm panic, xws li kev hloov kho tau mus rau nws los ntawm `f`.
    ///
    ///
    pub fn replace<'a, R>(
        &self,
        replacement: <T as ApplyL<'a>>::Out,
        f: impl for<'b, 'c> FnOnce(RefMutL<'b, 'c, T>) -> R,
    ) -> R {
        /// Cov xov paj xov uas xyuas kom meej tias lub xov tooj ib txwm tau sau (nrog lub xeev qub, kev hloov pauv tau los ntawm `f`), txawm tias `f` tau ntxhov siab.
        ///
        ///
        struct PutBackOnDrop<'a, T: LambdaL> {
            cell: &'a ScopedCell<T>,
            value: Option<<T as ApplyL<'static>>::Out>,
        }

        impl<'a, T: LambdaL> Drop for PutBackOnDrop<'a, T> {
            fn drop(&mut self) {
                self.cell.0.set(self.value.take().unwrap());
            }
        }

        let mut put_back_on_drop = PutBackOnDrop {
            cell: self,
            value: Some(self.0.replace(unsafe {
                let erased = mem::transmute_copy(&replacement);
                mem::forget(replacement);
                erased
            })),
        };

        f(RefMutL(put_back_on_drop.value.as_mut().unwrap()))
    }

    /// Poob lawm tus nqi nyob rau hauv `self` rau `value` thaum khiav `f`.
    pub fn set<R>(&self, value: <T as ApplyL<'_>>::Out, f: impl FnOnce() -> R) -> R {
        self.replace(value, |_| f())
    }
}