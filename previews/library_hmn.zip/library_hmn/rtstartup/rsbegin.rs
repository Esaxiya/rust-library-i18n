// rsbegin.o thiab rsend.o yog cov hu ua "compiler runtime startup objects".
// Lawv muaj cov cai uas xav tau los txhim kho qhov kev tsim ua ntawm cov xa khoom.
//
// Thaum ib tug executable los yog dylib duab no yog txuas, tag nrho cov neeg siv cov cai thiab cov tsev qiv ntawv yog "sandwiched" ntawm no ob yam twj paj nruas ntaub ntawv, yog li code los yog cov ntaub ntawv los ntawm rsbegin.o ua thawj nyob rau hauv lub duas paub seem ntawm daim duab, whereas code thiab cov ntaub ntawv los ntawm rsend.o ua tus kawg sawv daws yuav.
// Cov nyhuv no tuaj yeem siv los tso cim thaum pib lossis tom qhov kawg ntawm ntu, ntxiv rau ntxig rau txhua lub taub hau lossis hauv qab taw.
//
// Nco ntsoov tias lub sij module nkag kis yog nyob rau hauv lub C runtime startup kwv (feem ntau yog hu ua `crtX.o`), uas ces thov initialization callbacks ntawm lwm yam runtime Cheebtsam (sau npe ntawm tsis tau lwm tshwj xeeb duab seem).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Cim pib ntawm pawg teeb tsa seem cov lus qhia
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Kos rau qhov chaw rau unwinder nrog phau ntawv cia.
    // Qhov no txhais tau tias yog `struct object` hauv $ GCC/unwind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Tsim info registration/deregistration hnub.
    // Saib cov docs ntawm libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // sau npe unwind info ntawm module pib
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // unregister ntawm kev kaw
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW-tshwj xeeb init/uninit kev sau npe ib txwm muaj
    pub mod mingw_init {
        // MinGW cov khoom pib (crt0.o/dllcrt0.o) yuav thov cov neeg ua haujlwm thoob ntiaj teb hauv .ctors thiab .dtors pib ntawm kev pib thiab tawm.
        // Nyob rau hauv cov ntaub ntawv ntawm DLLs, qhov no yog ua li cas thaum lub DLL yog loaded thiab mos txwv.
        //
        // Lub Linker yuav txheeb cov seem, uas saib kuas tias peb callbacks yog nyob rau ntawm qhov kawg ntawm daim ntawv.
        // Txij li cov kws tsim kho tau khiav hauv kev rov qab txiav txim, qhov no ua kom peb cov xa rov qab yog thawj zaug thiab tom qab kawg tua.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: C initialization callbacks
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: C kev thov rov qab
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}