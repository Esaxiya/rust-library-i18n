//! Pustaka dukungan untuk penulis makro saat menentukan makro baru.
//!
//! Pustaka ini, disediakan oleh distribusi standar, menyediakan tipe yang dipakai dalam antarmuka definisi makro yang ditentukan secara prosedural seperti makro mirip fungsi `#[proc_macro]`, atribut makro `#[proc_macro_attribute]` dan atribut turunan kustom`#[proc_macro_derive]`.
//!
//!
//! Lihat [the book] untuk lebih lanjut.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Menentukan apakah proc_macro telah dibuat dapat diakses oleh program yang sedang berjalan.
///
/// Proc_macro crate hanya dimaksudkan untuk digunakan di dalam implementasi makro prosedural.Semua fungsi di crate panic ini jika dipanggil dari luar makro prosedural, seperti dari skrip build atau pengujian unit atau biner Rust biasa.
///
/// Dengan pertimbangan pustaka Rust yang dirancang untuk mendukung kasus penggunaan makro dan non-makro, `proc_macro::is_available()` menyediakan cara non-panik untuk mendeteksi apakah infrastruktur yang diperlukan untuk menggunakan API proc_macro saat ini tersedia.
/// Mengembalikan nilai benar jika dipanggil dari dalam makro prosedural, salah jika dipanggil dari biner lain.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// Jenis utama yang disediakan oleh crate ini, mewakili aliran abstrak tokens, atau, lebih khusus lagi, urutan pohon token.
/// Jenis ini menyediakan antarmuka untuk melakukan iterasi pada pohon token tersebut dan, sebaliknya, mengumpulkan sejumlah pohon token ke dalam satu aliran.
///
///
/// Ini adalah masukan dan keluaran dari definisi `#[proc_macro]`, `#[proc_macro_attribute]` dan `#[proc_macro_derive]`.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Kesalahan kembali dari `TokenStream::from_str`.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Mengembalikan `TokenStream` kosong yang tidak berisi pohon token.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Periksa apakah `TokenStream` ini kosong.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Mencoba memecah string menjadi tokens dan mengurai tokens tersebut menjadi aliran token.
/// Mungkin gagal karena sejumlah alasan, misalnya, jika string berisi pemisah yang tidak seimbang atau karakter yang tidak ada dalam bahasa tersebut.
///
/// Semua tokens dalam aliran yang diurai mendapatkan rentang `Span::call_site()`.
///
/// NOTE: beberapa kesalahan dapat menyebabkan panics bukannya mengembalikan `LexError`.Kami berhak untuk mengubah kesalahan ini menjadi `LexError`s nanti.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, jembatan hanya menyediakan `to_string`, mengimplementasikan `fmt::Display` berdasarkan itu (kebalikan dari hubungan biasa antara keduanya).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Mencetak aliran token sebagai string yang seharusnya dapat dikonversi kembali ke aliran token yang sama (modulo spans) yang sama, kecuali untuk kemungkinan `TokenTree: : Group` dengan pembatas `Delimiter::None` dan literal numerik negatif.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Mencetak token dalam bentuk yang nyaman untuk debugging.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Membuat aliran token yang berisi pohon token tunggal.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Mengumpulkan sejumlah pohon token menjadi satu aliran.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// Operasi "flattening" pada aliran token, mengumpulkan pohon token dari beberapa aliran token ke dalam aliran tunggal.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Gunakan implementasi if/when yang dioptimalkan mungkin.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Detail implementasi publik untuk tipe `TokenStream`, seperti iterator.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// Sebuah iterator di atas `TokenTree`s`TokenStream`.
    /// Iterasinya adalah "shallow", misalnya, iterator tidak berulang menjadi grup yang dipisahkan, dan mengembalikan seluruh grup sebagai pohon token.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` menerima tokens sewenang-wenang dan berkembang menjadi `TokenStream` yang mendeskripsikan input.
/// Misalnya, `quote!(a + b)` akan menghasilkan ekspresi, yang, ketika dievaluasi, membuat `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Pembatalan kutipan dilakukan dengan `$`, dan bekerja dengan mengambil satu ident berikutnya sebagai istilah tanpa tanda kutip.
/// Untuk mengutip `$` itu sendiri, gunakan `$$`.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// Kawasan kode sumber, bersama dengan informasi perluasan makro.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Membuat `Diagnostic` baru dengan `message` yang diberikan pada rentang `self`.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Rentang yang diselesaikan di situs definisi makro.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// Rentang pemanggilan makro prosedural saat ini.
    /// Pengenal yang dibuat dengan rentang ini akan diselesaikan seolah-olah ditulis langsung di lokasi panggilan makro (kebersihan situs panggilan) dan kode lain di situs panggilan makro akan dapat merujuknya juga.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// Rentang yang mewakili kebersihan `macro_rules`, dan terkadang diselesaikan di situs definisi makro (variabel lokal, label, `$crate`) dan terkadang di situs panggilan makro (yang lainnya).
    ///
    /// Lokasi span diambil dari situs panggilan.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// File sumber asli yang menjadi tujuan rentang ini.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// `Span` untuk tokens dalam ekspansi makro sebelumnya tempat `self` dibuat, jika ada.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// Rentang untuk kode sumber asal tempat `self` dibuat.
    /// Jika `Span` ini tidak dibuat dari perluasan makro lain, maka nilai kembaliannya sama dengan `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Mendapatkan line/column awal di file sumber untuk rentang ini.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Mendapat akhiran line/column di file sumber untuk rentang ini.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Membuat rentang baru yang mencakup `self` dan `other`.
    ///
    /// Mengembalikan `None` jika `self` dan `other` berasal dari file yang berbeda.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Membuat rentang baru dengan informasi line/column yang sama seperti `self` tetapi itu menyelesaikan simbol seolah-olah berada di `other`.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Membuat rentang baru dengan perilaku resolusi nama yang sama seperti `self` tetapi dengan informasi line/column dari `other`.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Bandingkan dengan span untuk melihat apakah keduanya sama.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Mengembalikan teks sumber di belakang span.
    /// Ini mempertahankan kode sumber asli, termasuk spasi dan komentar.
    /// Ini hanya mengembalikan hasil jika span sesuai dengan kode sumber sebenarnya.
    ///
    /// Note: Hasil makro yang dapat diamati sebaiknya hanya mengandalkan tokens dan bukan teks sumber ini.
    ///
    /// Hasil dari fungsi ini adalah upaya terbaik untuk digunakan hanya untuk diagnostik.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Mencetak span dalam bentuk yang sesuai untuk debugging.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Pasangan baris-kolom yang mewakili awal atau akhir `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// Baris 1 diindeks di file sumber tempat rentang dimulai atau diakhiri (inclusive).
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// Kolom 0-indeks (dalam karakter UTF-8) di file sumber tempat rentang dimulai atau diakhiri (inclusive).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// File sumber dari `Span` tertentu.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Mendapatkan jalur ke file sumber ini.
    ///
    /// ### Note
    /// Jika rentang kode yang terkait dengan `SourceFile` ini dibuat oleh makro eksternal, makro ini, ini mungkin bukan jalur sebenarnya pada sistem file.
    /// Gunakan [`is_real`] untuk memeriksa.
    ///
    /// Perhatikan juga bahwa meskipun `is_real` mengembalikan `true`, jika `--remap-path-prefix` diteruskan pada baris perintah, jalur yang diberikan mungkin tidak benar-benar valid.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Mengembalikan `true` jika file sumber ini adalah file sumber nyata, dan tidak dibuat oleh perluasan makro eksternal.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Ini adalah peretasan sampai rentang intercrate diimplementasikan dan kami dapat memiliki file sumber nyata untuk span yang dibuat di makro eksternal.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// token tunggal atau urutan pohon token yang dibatasi (misalnya, `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// Aliran token yang dikelilingi oleh pembatas tanda kurung.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Pengenal.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Satu karakter tanda baca (`+`, `,`, `$`, dll.).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// Karakter literal (`'a'`), string (`"hello"`), angka (`2.3`), dll.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Mengembalikan rentang pohon ini, mendelegasikan ke metode `span` dari token yang terkandung atau aliran yang dibatasi.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Mengonfigurasi rentang *hanya untuk token* ini.
    ///
    /// Perhatikan bahwa jika token ini adalah `Group` maka metode ini tidak akan mengonfigurasi rentang setiap tokens internal, ini hanya akan mendelegasikan ke metode `set_span` untuk setiap varian.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// Mencetak pohon token dalam bentuk yang sesuai untuk debugging.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Masing-masing memiliki nama dalam tipe struct di debug turunan, jadi jangan repot-repot dengan lapisan tambahan tipuan
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, jembatan hanya menyediakan `to_string`, mengimplementasikan `fmt::Display` berdasarkan itu (kebalikan dari hubungan biasa antara keduanya).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Mencetak pohon token sebagai string yang seharusnya dapat dikonversi kembali ke pohon token yang sama (modulo spans) yang sama, kecuali untuk kemungkinan `TokenTree: : Group`s dengan pembatas `Delimiter::None` dan literal numerik negatif.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Aliran token yang dibatasi.
///
/// `Group` secara internal berisi `TokenStream` yang dikelilingi oleh `Pembatas`.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Menjelaskan bagaimana urutan pohon token dibatasi.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// Pembatas implisit, yang mungkin, misalnya, muncul di sekitar tokens yang berasal dari "macro variable" `$var`.
    /// Penting untuk menjaga prioritas operator dalam kasus seperti `$var * 3` di mana `$var` adalah `1 + 2`.
    /// Pembatas implisit mungkin tidak bertahan bolak-balik dari streaming token melalui string.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Membuat `Group` baru dengan pembatas yang diberikan dan streaming token.
    ///
    /// Konstruktor ini akan menyetel rentang untuk grup ini ke `Span::call_site()`.
    /// Untuk mengubah span dapat menggunakan metode `set_span` di bawah ini.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Menampilkan pembatas `Group` ini
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Mengembalikan `TokenStream` dari tokens yang dibatasi dalam `Group` ini.
    ///
    /// Perhatikan bahwa aliran token yang dikembalikan tidak menyertakan pembatas yang ditampilkan di atas.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Mengembalikan rentang untuk pembatas aliran token ini, yang mencakup seluruh `Group`.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Mengembalikan rentang yang menunjuk ke pembatas pembuka grup ini.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Mengembalikan rentang yang menunjuk ke pembatas penutup grup ini.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Mengonfigurasi rentang untuk pembatas `Grup` ini, tetapi bukan tokens internalnya.
    ///
    /// Metode ini **tidak** akan mengatur rentang semua tokens internal yang direntang oleh grup ini, melainkan hanya akan menyetel rentang pembatas tokens pada level `Group`.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, jembatan hanya menyediakan `to_string`, mengimplementasikan `fmt::Display` berdasarkan itu (kebalikan dari hubungan biasa antara keduanya).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Mencetak grup sebagai string yang harus dapat dikonversi kembali ke grup yang sama (modulo spans) tanpa kerugian, kecuali untuk kemungkinan `TokenTree: : Group`s dengan pembatas `Delimiter::None`.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// `Punct` adalah karakter tanda baca tunggal seperti `+`, `-`, atau `#`.
///
/// Operator multi-karakter seperti `+=` direpresentasikan sebagai dua instance `Punct` dengan bentuk berbeda dari `Spacing` yang dikembalikan.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Apakah `Punct` diikuti segera oleh `Punct` lain atau diikuti oleh token atau spasi lain.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// misal, `+` adalah `Alone` di `+ =`, `+ident` atau `+()`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// misal, `+` adalah `Joint` di `+=` atau `'#`.
    /// Selain itu, kutipan tunggal `'` dapat digabungkan dengan pengenal untuk membentuk masa hidup `'ident`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Membuat `Punct` baru dari karakter dan spasi yang diberikan.
    /// Argumen `ch` harus berupa karakter tanda baca yang valid yang diizinkan oleh bahasa, jika tidak, fungsinya akan panic.
    ///
    /// `Punct` yang dikembalikan akan memiliki rentang default `Span::call_site()` yang selanjutnya dapat dikonfigurasi dengan metode `set_span` di bawah ini.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Mengembalikan nilai karakter tanda baca ini sebagai `char`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Mengembalikan spasi dari karakter tanda baca ini, yang menunjukkan apakah itu segera diikuti oleh `Punct` lain di aliran token, sehingga mereka berpotensi dapat digabungkan menjadi operator multi-karakter (`Joint`), atau diikuti oleh beberapa token lain atau spasi (`Alone`) sehingga operator pasti memiliki berakhir.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Mengembalikan rentang untuk karakter tanda baca ini.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Konfigurasikan rentang untuk karakter tanda baca ini.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, jembatan hanya menyediakan `to_string`, mengimplementasikan `fmt::Display` berdasarkan itu (kebalikan dari hubungan biasa antara keduanya).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Mencetak karakter tanda baca sebagai string yang harus dapat diubah tanpa kehilangan kembali menjadi karakter yang sama.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// Pengenal (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Membuat `Ident` baru dengan `string` yang diberikan serta `span` yang ditentukan.
    /// Argumen `string` harus berupa pengenal valid yang diizinkan oleh bahasa (termasuk kata kunci, misalnya `self` atau `fn`).Jika tidak, fungsinya akan panic.
    ///
    /// Perhatikan bahwa `span`, saat ini di rustc, mengkonfigurasi informasi kebersihan untuk pengenal ini.
    ///
    /// Mulai saat ini `Span::call_site()` secara eksplisit memilih untuk menggunakan "call-site" hygiene yang berarti bahwa pengenal yang dibuat dengan rentang ini akan diselesaikan seolah-olah ditulis langsung di lokasi panggilan makro, dan kode lain di situs panggilan makro akan dapat merujuk ke mereka juga.
    ///
    ///
    /// Rentang selanjutnya seperti `Span::def_site()` akan memungkinkan untuk ikut serta dalam kebersihan "definition-site" yang berarti bahwa pengenal yang dibuat dengan rentang ini akan diselesaikan di lokasi definisi makro dan kode lain di situs panggilan makro tidak akan dapat merujuknya.
    ///
    /// Karena pentingnya kebersihan saat ini, konstruktor ini, tidak seperti tokens lainnya, memerlukan `Span` untuk ditentukan pada konstruksi.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// Sama seperti `Ident::new`, tetapi membuat pengenal mentah (`r#ident`).
    /// Argumen `string` adalah pengenal valid yang diizinkan oleh bahasa (termasuk kata kunci, misalnya `fn`).
    /// Kata kunci yang dapat digunakan di segmen jalur (mis
    /// `self`, `super`) tidak didukung, dan akan menyebabkan panic.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Mengembalikan rentang `Ident` ini, yang mencakup seluruh string yang dikembalikan oleh [`to_string`](Self::to_string).
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Mengonfigurasi rentang `Ident` ini, mungkin mengubah konteks kebersihannya.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, jembatan hanya menyediakan `to_string`, mengimplementasikan `fmt::Display` berdasarkan itu (kebalikan dari hubungan biasa antara keduanya).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Mencetak pengenal sebagai string yang seharusnya dapat diubah kembali tanpa kerugian menjadi pengenal yang sama.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// String literal (`"hello"`), string byte (`b"hello"`), karakter (`'a'`), karakter byte (`b'a'`), bilangan bulat atau floating point dengan atau tanpa sufiks (`1`, `1u8`, `2.3`, `2.3f32`).
///
/// Literal Boolean seperti `true` dan `false` tidak termasuk di sini, mereka adalah `Ident`s.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Membuat literal integer akhiran baru dengan nilai yang ditentukan.
        ///
        /// Fungsi ini akan membuat bilangan bulat seperti `1u32` di mana nilai bilangan bulat yang ditentukan adalah bagian pertama dari token dan integral juga diakhiri di akhir.
        /// Literal yang dibuat dari bilangan negatif mungkin tidak bertahan bolak-balik melalui `TokenStream` atau string dan dapat dipecah menjadi dua tokens (`-` dan literal positif).
        ///
        ///
        /// Literal yang dibuat melalui metode ini memiliki rentang `Span::call_site()` secara default, yang dapat dikonfigurasi dengan metode `set_span` di bawah ini.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Membuat literal bilangan bulat tidak bercampur baru dengan nilai yang ditentukan.
        ///
        /// Fungsi ini akan membuat integer seperti `1` dimana nilai integer yang ditentukan adalah bagian pertama dari token.
        /// Tidak ada sufiks yang ditentukan pada token ini, yang berarti bahwa pemanggilan seperti `Literal::i8_unsuffixed(1)` setara dengan `Literal::u32_unsuffixed(1)`.
        /// Literal yang dibuat dari bilangan negatif mungkin tidak dapat bertahan dalam putaran melalui `TokenStream` atau string dan dapat dipecah menjadi dua tokens (`-` dan literal positif).
        ///
        ///
        /// Literal yang dibuat melalui metode ini memiliki rentang `Span::call_site()` secara default, yang dapat dikonfigurasi dengan metode `set_span` di bawah ini.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Membuat literal floating-point baru yang tidak bercampur.
    ///
    /// Konstruktor ini mirip dengan `Literal::i8_unsuffixed` di mana nilai float dipancarkan langsung ke token tetapi tidak ada sufiks yang digunakan, jadi mungkin disimpulkan menjadi `f64` nanti di kompiler.
    ///
    /// Literal yang dibuat dari bilangan negatif mungkin tidak dapat bertahan dalam putaran melalui `TokenStream` atau string dan dapat dipecah menjadi dua tokens (`-` dan literal positif).
    ///
    /// # Panics
    ///
    /// Fungsi ini mengharuskan float yang ditentukan terbatas, misalnya jika tak terhingga atau NaN, fungsi ini akan panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Membuat literal floating-point sufiks baru.
    ///
    /// Konstruktor ini akan membuat literal seperti `1.0f32` di mana nilai yang ditentukan adalah bagian sebelumnya dari token dan `f32` adalah akhiran dari token.
    /// token ini akan selalu disimpulkan sebagai `f32` dalam kompilator.
    /// Literal yang dibuat dari bilangan negatif mungkin tidak dapat bertahan dalam putaran melalui `TokenStream` atau string dan dapat dipecah menjadi dua tokens (`-` dan literal positif).
    ///
    ///
    /// # Panics
    ///
    /// Fungsi ini mengharuskan float yang ditentukan terbatas, misalnya jika tak terhingga atau NaN, fungsi ini akan panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Membuat literal floating-point baru yang tidak bercampur.
    ///
    /// Konstruktor ini mirip dengan `Literal::i8_unsuffixed` di mana nilai float dipancarkan langsung ke token tetapi tidak ada sufiks yang digunakan, jadi mungkin disimpulkan menjadi `f64` nanti di kompiler.
    ///
    /// Literal yang dibuat dari bilangan negatif mungkin tidak dapat bertahan dalam putaran melalui `TokenStream` atau string dan dapat dipecah menjadi dua tokens (`-` dan literal positif).
    ///
    /// # Panics
    ///
    /// Fungsi ini mengharuskan float yang ditentukan terbatas, misalnya jika tak terhingga atau NaN, fungsi ini akan panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Membuat literal floating-point sufiks baru.
    ///
    /// Konstruktor ini akan membuat literal seperti `1.0f64` di mana nilai yang ditentukan adalah bagian sebelumnya dari token dan `f64` adalah akhiran dari token.
    /// token ini akan selalu disimpulkan sebagai `f64` dalam kompilator.
    /// Literal yang dibuat dari bilangan negatif mungkin tidak dapat bertahan dalam putaran melalui `TokenStream` atau string dan dapat dipecah menjadi dua tokens (`-` dan literal positif).
    ///
    ///
    /// # Panics
    ///
    /// Fungsi ini mengharuskan float yang ditentukan terbatas, misalnya jika tak terhingga atau NaN, fungsi ini akan panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// String literal.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Karakter literal.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// String byte literal.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Mengembalikan rentang yang mencakup literal ini.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Mengonfigurasi rentang yang terkait untuk literal ini.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Mengembalikan `Span` yang merupakan subset dari `self.span()` yang hanya berisi byte sumber dalam rentang `range`.
    /// Mengembalikan `None` jika rentang yang akan dipangkas berada di luar batas `self`.
    ///
    // FIXME(SergioBenitez): periksa apakah kisaran byte dimulai dan diakhiri pada batas UTF-8 dari sumber.
    // jika tidak, kemungkinan panic akan muncul di tempat lain saat teks sumber dicetak.
    // FIXME(SergioBenitez): tidak ada cara bagi pengguna untuk mengetahui apa yang sebenarnya dipetakan `self.span()`, jadi metode ini saat ini hanya dapat dipanggil secara membabi buta.
    // Misalnya, `to_string()` untuk karakter 'c' mengembalikan "'\u{63}'";tidak ada cara bagi pengguna untuk mengetahui apakah teks sumber adalah 'c' atau '\u{63}'.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) sesuatu yang mirip dengan `Option::cloned`, tetapi untuk `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, jembatan hanya menyediakan `to_string`, mengimplementasikan `fmt::Display` berdasarkan itu (kebalikan dari hubungan biasa antara keduanya).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Mencetak literal sebagai string yang harus dapat dikonversi tanpa kerugian kembali ke literal yang sama (kecuali untuk kemungkinan pembulatan untuk literal floating point).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Akses dilacak ke variabel lingkungan.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Ambil variabel lingkungan dan tambahkan untuk membuat info dependensi.
    /// Sistem build yang menjalankan compiler akan mengetahui bahwa variabel telah diakses selama kompilasi, dan akan dapat menjalankan kembali build saat nilai variabel tersebut berubah.
    ///
    /// Selain pelacakan ketergantungan, fungsi ini harus setara dengan `env::var` dari pustaka standar, kecuali argumennya harus UTF-8.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}