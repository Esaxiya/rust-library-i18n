//! Pointer penghitungan referensi berulir tunggal.'Rc' adalah singkatan dari 'Referensi
//! Counted'.
//!
//! Tipe [`Rc<T>`][`Rc`] memberikan kepemilikan bersama dari nilai tipe `T`, yang dialokasikan di heap.
//! Memanggil [`clone`][clone] di [`Rc`] menghasilkan penunjuk baru ke alokasi yang sama di heap.
//! Ketika penunjuk [`Rc`] terakhir ke alokasi tertentu dihancurkan, nilai yang disimpan dalam alokasi itu (sering disebut sebagai "inner value") juga dihapus.
//!
//! Referensi bersama di Rust melarang mutasi secara default, dan [`Rc`] tidak terkecuali: Anda biasanya tidak dapat memperoleh referensi yang bisa berubah ke sesuatu di dalam [`Rc`].
//! Jika Anda membutuhkan perubahan, letakkan [`Cell`] atau [`RefCell`] di dalam [`Rc`];lihat [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] menggunakan penghitungan referensi non-atom.
//! Ini berarti bahwa overhead sangat rendah, tetapi [`Rc`] tidak dapat dikirim di antara utas, dan akibatnya [`Rc`] tidak mengimplementasikan [`Send`][send].
//! Akibatnya, kompilator Rust akan memeriksa *pada waktu kompilasi* bahwa Anda tidak mengirim [`Rc`] di antara utas.
//! Jika Anda memerlukan penghitungan referensi atom multi-utas, gunakan [`sync::Arc`][arc].
//!
//! Metode [`downgrade`][downgrade] dapat digunakan untuk membuat penunjuk [`Weak`] yang tidak memiliki.
//! Penunjuk [`Weak`] dapat berupa [`upgrade`][upgrade] d ke [`Rc`], tetapi ini akan mengembalikan [`None`] jika nilai yang disimpan dalam alokasi telah dihapus.
//! Dengan kata lain, pointer `Weak` tidak menjaga nilai di dalam alokasi tetap hidup;namun, mereka *melakukan* menjaga alokasi (penyimpanan pendukung untuk nilai dalam) tetap hidup.
//!
//! Siklus antara pointer [`Rc`] tidak akan pernah dibatalkan alokasinya.
//! Untuk alasan ini, [`Weak`] digunakan untuk memutus siklus.
//! Misalnya, sebuah pohon dapat memiliki penunjuk [`Rc`] yang kuat dari simpul induk ke anak, dan penunjuk [`Weak`] dari anak kembali ke induknya.
//!
//! `Rc<T>` secara otomatis merujuk ke `T` (melalui [`Deref`] trait), sehingga Anda dapat memanggil metode `T` pada nilai tipe [`Rc<T>`][`Rc`].
//! Untuk menghindari bentrokan nama dengan metode `T`, metode [`Rc<T>`][`Rc`] itu sendiri adalah fungsi terkait, yang dipanggil menggunakan [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>Implementasi traits seperti `Clone` juga dapat dipanggil menggunakan sintaks yang memenuhi syarat.
//! Beberapa orang lebih suka menggunakan sintaks yang memenuhi syarat, sementara yang lain lebih suka menggunakan sintaks metode-panggilan.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Sintaks metode-panggilan
//! let rc2 = rc.clone();
//! // Sintaks yang sepenuhnya memenuhi syarat
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] tidak melakukan dereferensi otomatis ke `T`, karena nilai bagian dalam mungkin telah dijatuhkan.
//!
//! # Referensi kloning
//!
//! Membuat referensi baru ke alokasi yang sama seperti referensi terhitung pointer yang ada dilakukan menggunakan `Clone` trait yang diimplementasikan untuk [`Rc<T>`][`Rc`] dan [`Weak<T>`][`Weak`].
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Kedua sintaks di bawah ini setara.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a dan b keduanya menunjuk ke lokasi memori yang sama dengan foo.
//! ```
//!
//! Sintaks `Rc::clone(&from)` adalah yang paling idiomatis karena menyampaikan arti kode secara lebih eksplisit.
//! Dalam contoh di atas, sintaksis ini mempermudah untuk melihat bahwa kode ini membuat referensi baru daripada menyalin seluruh konten foo.
//!
//! # Examples
//!
//! Pertimbangkan skenario di mana sekumpulan `Gadget` dimiliki oleh `Owner` tertentu.
//! Kami ingin agar `Gadget` mengarah ke `Owner` mereka.Kami tidak dapat melakukan ini dengan kepemilikan unik, karena lebih dari satu gadget mungkin memiliki `Owner` yang sama.
//! [`Rc`] memungkinkan kami untuk berbagi `Owner` di antara beberapa `Gadget`, dan tetap mengalokasikan `Owner` selama `Gadget` menunjuknya.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... bidang lain
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... bidang lain
//! }
//!
//! fn main() {
//!     // Buat `Owner` yang dihitung referensi.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Buat `Gadget`s milik `gadget_owner`.
//!     // Mengkloning `Rc<Owner>` memberi kita penunjuk baru ke alokasi `Owner` yang sama, menambah jumlah referensi dalam prosesnya.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Buang variabel lokal kami `gadget_owner`.
//!     drop(gadget_owner);
//!
//!     // Meskipun menghapus `gadget_owner`, kami masih dapat mencetak nama `Owner` dari `Gadget`s.
//!     // Ini karena kami hanya menjatuhkan satu `Rc<Owner>`, bukan `Owner` yang ditunjukkannya.
//!     // Selama ada `Rc<Owner>` lain yang menunjuk pada alokasi `Owner` yang sama, itu akan tetap aktif.
//!     // Proyeksi lapangan `gadget1.owner.name` berfungsi karena `Rc<Owner>` secara otomatis merujuk ke `Owner`.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // Di akhir fungsi, `gadget1` dan `gadget2` dihancurkan, dan bersama mereka dihitung referensi terakhir ke `Owner` kami.
//!     // Gadget Man sekarang dihancurkan juga.
//!     //
//! }
//! ```
//!
//! Jika persyaratan kami berubah, dan kami juga harus dapat melintasi dari `Owner` ke `Gadget`, kami akan mengalami masalah.
//! Sebuah pointer [`Rc`] dari `Owner` ke `Gadget` memperkenalkan sebuah siklus.
//! Artinya, jumlah referensi mereka tidak akan pernah bisa mencapai 0, dan alokasi tidak akan pernah dimusnahkan:
//! kebocoran memori.Untuk menyiasati ini, kita dapat menggunakan pointer [`Weak`].
//!
//! Rust sebenarnya membuatnya agak sulit untuk menghasilkan loop ini di tempat pertama.Untuk mendapatkan dua nilai yang saling menunjuk, salah satunya harus bisa berubah.
//! Ini sulit karena [`Rc`] memberlakukan keamanan memori dengan hanya memberikan referensi bersama ke nilai yang dibungkusnya, dan ini tidak mengizinkan mutasi langsung.
//! Kita perlu membungkus bagian dari nilai yang ingin kita mutasi dalam [`RefCell`], yang menyediakan *mutabilitas interior*: metode untuk mencapai mutabilitas melalui referensi bersama.
//! [`RefCell`] memberlakukan aturan peminjaman Rust pada saat runtime.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... bidang lain
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... bidang lain
//! }
//!
//! fn main() {
//!     // Buat `Owner` yang dihitung referensi.
//!     // Perhatikan bahwa kita telah meletakkan vector `Pemilik` dari`Gadget` di dalam `RefCell` sehingga kita dapat memutasinya melalui referensi bersama.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Buat `Gadget`s milik `gadget_owner`, seperti sebelumnya.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Tambahkan `Gadget` ke `Owner` mereka.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` pinjaman dinamis berakhir di sini.
//!     }
//!
//!     // Ulangi `Gadget` kami, cetak detailnya.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` adalah `Weak<Gadget>`.
//!         // Karena pointer `Weak` tidak dapat menjamin alokasi masih ada, kita perlu memanggil `upgrade`, yang mengembalikan `Option<Rc<Gadget>>`.
//!         //
//!         //
//!         // Dalam hal ini kita tahu alokasinya masih ada, jadi kita cukup `unwrap` `Option`.
//!         // Dalam program yang lebih rumit, Anda mungkin memerlukan penanganan kesalahan yang baik untuk hasil `None`.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // Di akhir fungsi, `gadget_owner`, `gadget1`, dan `gadget2` dihancurkan.
//!     // Sekarang tidak ada penunjuk (`Rc`) yang kuat ke gadget, jadi mereka dihancurkan.
//!     // Ini nol jumlah referensi di Gadget Man, jadi dia akan dihancurkan juga.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Ini adalah bukti repr(C) hingga future terhadap kemungkinan pengubahan urutan lapangan, yang akan mengganggu [into|from]_raw() yang aman dari jenis bagian dalam yang dapat diubah.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Pointer penghitung referensi berulir tunggal.'Rc' adalah singkatan dari 'Referensi
/// Counted'.
///
/// Lihat [module-level documentation](./index.html) untuk lebih jelasnya.
///
/// Metode inheren `Rc` adalah semua fungsi terkait, yang berarti Anda harus memanggilnya sebagai contoh, [`Rc::get_mut(&mut value)`][get_mut], bukan `value.get_mut()`.
/// Ini menghindari konflik dengan metode tipe dalam `T`.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Ketidakamanan ini tidak apa-apa karena saat Rc ini hidup, kami dijamin bahwa penunjuk bagian dalam valid.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Membuat `Rc<T>` baru.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Ada penunjuk lemah implisit yang dimiliki oleh semua penunjuk kuat, yang memastikan bahwa perusak lemah tidak pernah membebaskan alokasi saat perusak kuat sedang berjalan, bahkan jika penunjuk lemah disimpan di dalam penunjuk yang kuat.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Membuat `Rc<T>` baru menggunakan referensi yang lemah ke dirinya sendiri.
    /// Mencoba meningkatkan referensi lemah sebelum fungsi ini kembali akan menghasilkan nilai `None`.
    ///
    /// Namun, referensi yang lemah dapat dikloning secara bebas dan disimpan untuk digunakan di lain waktu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... lebih banyak bidang
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Bangun bagian dalam dalam status "uninitialized" dengan satu referensi lemah.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Penting bagi kita untuk tidak melepaskan kepemilikan penunjuk yang lemah, atau memori mungkin dibebaskan pada saat `data_fn` kembali.
        // Jika kami benar-benar ingin meneruskan kepemilikan, kami dapat membuat penunjuk lemah tambahan untuk diri kami sendiri, tetapi ini akan menghasilkan pembaruan tambahan pada jumlah referensi lemah yang mungkin tidak diperlukan jika tidak.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Referensi yang kuat harus secara kolektif memiliki referensi lemah bersama, jadi jangan jalankan destruktor untuk referensi lemah lama kita.
        //
        mem::forget(weak);
        strong
    }

    /// Membuat `Rc` baru dengan konten yang tidak diinisialisasi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Inisialisasi yang ditangguhkan:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Membuat `Rc` baru dengan konten yang tidak diinisialisasi, dengan memori yang diisi dengan byte `0`.
    ///
    ///
    /// Lihat [`MaybeUninit::zeroed`][zeroed] untuk contoh penggunaan yang benar dan salah dari metode ini.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Membuat `Rc<T>` baru, mengembalikan kesalahan jika alokasi gagal
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Ada penunjuk lemah implisit yang dimiliki oleh semua penunjuk kuat, yang memastikan bahwa perusak lemah tidak pernah membebaskan alokasi saat perusak kuat sedang berjalan, bahkan jika penunjuk lemah disimpan di dalam penunjuk yang kuat.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Membuat `Rc` baru dengan konten yang tidak diinisialisasi, mengembalikan kesalahan jika alokasi gagal
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Inisialisasi yang ditangguhkan:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Membuat `Rc` baru dengan konten yang tidak diinisialisasi, dengan memori diisi dengan byte `0`, mengembalikan kesalahan jika alokasi gagal
    ///
    ///
    /// Lihat [`MaybeUninit::zeroed`][zeroed] untuk contoh penggunaan yang benar dan salah dari metode ini.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Membuat `Pin<Rc<T>>` baru.
    /// Jika `T` tidak mengimplementasikan `Unpin`, maka `value` akan disematkan di memori dan tidak dapat dipindahkan.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Mengembalikan nilai dalam, jika `Rc` memiliki tepat satu referensi yang kuat.
    ///
    /// Jika tidak, [`Err`] akan dikembalikan dengan `Rc` yang sama yang diteruskan.
    ///
    ///
    /// Ini akan berhasil bahkan jika ada referensi lemah yang menonjol.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // salin objek yang ada

                // Tunjukkan pada Weaks bahwa mereka tidak dapat dipromosikan dengan mengurangi jumlah strong, lalu hapus pointer "strong weak" implisit sambil juga menangani logika drop dengan hanya membuat Weak palsu.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Membuat potongan baru yang dihitung referensi dengan konten yang tidak diinisialisasi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Inisialisasi yang ditangguhkan:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Membuat potongan baru yang dihitung referensi dengan konten yang tidak diinisialisasi, dengan memori yang diisi dengan byte `0`.
    ///
    ///
    /// Lihat [`MaybeUninit::zeroed`][zeroed] untuk contoh penggunaan yang benar dan salah dari metode ini.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Mengonversi ke `Rc<T>`.
    ///
    /// # Safety
    ///
    /// Seperti halnya [`MaybeUninit::assume_init`], terserah pemanggil untuk menjamin bahwa nilai batin benar-benar dalam keadaan diinisialisasi.
    ///
    /// Memanggil ini ketika konten belum sepenuhnya diinisialisasi menyebabkan perilaku tidak terdefinisi langsung.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Inisialisasi yang ditangguhkan:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Mengonversi ke `Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// Seperti halnya [`MaybeUninit::assume_init`], terserah pemanggil untuk menjamin bahwa nilai batin benar-benar dalam keadaan diinisialisasi.
    ///
    /// Memanggil ini ketika konten belum sepenuhnya diinisialisasi menyebabkan perilaku tidak terdefinisi langsung.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Inisialisasi yang ditangguhkan:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Mengkonsumsi `Rc`, mengembalikan penunjuk yang dibungkus.
    ///
    /// Untuk menghindari kebocoran memori, pointer harus diubah kembali ke `Rc` menggunakan [`Rc::from_raw`][from_raw].
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Memberikan penunjuk mentah ke data.
    ///
    /// Penghitungan tidak terpengaruh dengan cara apa pun dan `Rc` tidak dikonsumsi.
    /// Pointer valid selama ada hitungan kuat di `Rc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // KEAMANAN: Ini tidak dapat melalui Deref::deref atau Rc::inner karena
        // ini diperlukan untuk mempertahankan asalnya raw/mut sedemikian rupa, misalnya
        // `get_mut` dapat menulis melalui penunjuk setelah Rc dipulihkan melalui `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Membuat `Rc<T>` dari pointer mentah.
    ///
    /// Penunjuk mentah sebelumnya harus dikembalikan oleh panggilan ke [`Rc<U>::into_raw`][into_raw] di mana `U` harus memiliki ukuran dan kesejajaran yang sama dengan `T`.
    /// Hal ini benar jika `U` adalah `T`.
    /// Perhatikan bahwa jika `U` bukan `T` tetapi memiliki ukuran dan kesejajaran yang sama, ini pada dasarnya seperti mentransmutasikan referensi dari berbagai jenis.
    /// Lihat [`mem::transmute`][transmute] untuk informasi lebih lanjut tentang batasan apa yang berlaku dalam kasus ini.
    ///
    /// Pengguna `from_raw` harus memastikan nilai tertentu dari `T` hanya dijatuhkan sekali.
    ///
    /// Fungsi ini tidak aman karena penggunaan yang tidak benar dapat menyebabkan ketidakamanan memori, bahkan jika `Rc<T>` yang dikembalikan tidak pernah diakses.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Ubah kembali ke `Rc` untuk mencegah kebocoran.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Panggilan lebih lanjut ke `Rc::from_raw(x_ptr)` akan tidak aman dari memori.
    /// }
    ///
    /// // Memori dibebaskan ketika `x` keluar dari ruang lingkup di atas, jadi `x_ptr` sekarang menggantung!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Balikkan offset untuk menemukan RcBox asli.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Membuat penunjuk [`Weak`] baru untuk alokasi ini.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Pastikan kita tidak membuat Lemah menjuntai
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Mendapat jumlah pointer [`Weak`] untuk alokasi ini.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Mendapat jumlah petunjuk (`Rc`) yang kuat untuk alokasi ini.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Mengembalikan `true` jika tidak ada petunjuk `Rc` atau [`Weak`] lain ke alokasi ini.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Mengembalikan referensi yang bisa berubah ke `Rc` tertentu, jika tidak ada pointer `Rc` atau [`Weak`] lain ke alokasi yang sama.
    ///
    ///
    /// Mengembalikan [`None`] sebaliknya, karena tidak aman untuk mengubah nilai bersama.
    ///
    /// Lihat juga [`make_mut`][make_mut], yang akan [`clone`][clone] nilai bagian dalam bila ada petunjuk lain.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Mengembalikan referensi yang bisa berubah ke `Rc` tertentu, tanpa centang apa pun.
    ///
    /// Lihat juga [`get_mut`], yang aman dan melakukan pemeriksaan yang sesuai.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Pointer `Rc` atau [`Weak`] lainnya ke alokasi yang sama tidak boleh dirujuk selama durasi pengembalian pinjaman.
    ///
    /// Ini adalah kasus sepele jika tidak ada petunjuk seperti itu, misalnya segera setelah `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Kami berhati-hati untuk *tidak* membuat referensi yang mencakup bidang "count", karena ini akan bertentangan dengan akses ke jumlah referensi (mis.
        // oleh `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Mengembalikan `true` jika dua `Rc` menunjuk ke alokasi yang sama (dengan nada yang mirip dengan [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Membuat referensi yang bisa berubah menjadi `Rc` yang diberikan.
    ///
    /// Jika ada penunjuk `Rc` lain ke alokasi yang sama, maka `make_mut` akan [`clone`] nilai dalam ke alokasi baru untuk memastikan kepemilikan unik.
    /// Ini juga disebut sebagai clone-on-write.
    ///
    /// Jika tidak ada penunjuk `Rc` lain untuk alokasi ini, maka penunjuk [`Weak`] ke alokasi ini akan dipisahkan.
    ///
    /// Lihat juga [`get_mut`], yang akan gagal daripada mengkloning.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Tidak akan mengkloning apa pun
    /// let mut other_data = Rc::clone(&data);    // Tidak akan mengkloning data dalam
    /// *Rc::make_mut(&mut data) += 1;        // Mengkloning data dalam
    /// *Rc::make_mut(&mut data) += 1;        // Tidak akan mengkloning apa pun
    /// *Rc::make_mut(&mut other_data) *= 2;  // Tidak akan mengkloning apa pun
    ///
    /// // Sekarang `data` dan `other_data` menunjuk ke alokasi yang berbeda.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] petunjuk akan dipisahkan:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Harus mengkloning data, ada Rcs lainnya.
            // Alokasikan memori sebelumnya untuk memungkinkan penulisan nilai kloning secara langsung.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Bisa saja mencuri data, yang tersisa hanyalah Weaks
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Hapus ref implisit kuat-lemah (tidak perlu membuat Lemah palsu di sini-kita tahu Lemah lain dapat membersihkan untuk kita)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Ketidakamanan ini tidak masalah karena kami dijamin bahwa pointer yang dikembalikan adalah *satu-satunya* pointer yang akan pernah dikembalikan ke T.
        // Jumlah referensi kami dijamin menjadi 1 pada saat ini, dan kami mengharuskan `Rc<T>` itu sendiri menjadi `mut`, jadi kami mengembalikan satu-satunya referensi yang mungkin untuk alokasi tersebut.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Cobalah untuk menurunkan `Rc<dyn Any>` ke tipe beton.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Mengalokasikan `RcBox<T>` dengan ruang yang cukup untuk nilai dalam yang mungkin tidak berukuran di mana nilai tersebut memiliki tata letak yang disediakan.
    ///
    /// Fungsi `mem_to_rcbox` dipanggil dengan penunjuk data dan harus mengembalikan sebuah (berpotensi gemuk)-pointer untuk `RcBox<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Hitung tata letak menggunakan tata letak nilai yang diberikan.
        // Sebelumnya, tata letak dihitung pada ekspresi `&*(ptr as* const RcBox<T>)`, tetapi ini menciptakan referensi yang tidak selaras (lihat #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Mengalokasikan `RcBox<T>` dengan ruang yang cukup untuk nilai dalam yang mungkin berukuran di mana nilai memiliki tata letak yang disediakan, mengembalikan kesalahan jika alokasi gagal.
    ///
    ///
    /// Fungsi `mem_to_rcbox` dipanggil dengan penunjuk data dan harus mengembalikan sebuah (berpotensi gemuk)-pointer untuk `RcBox<T>`.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Hitung tata letak menggunakan tata letak nilai yang diberikan.
        // Sebelumnya, tata letak dihitung pada ekspresi `&*(ptr as* const RcBox<T>)`, tetapi ini menciptakan referensi yang tidak selaras (lihat #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Alokasikan untuk tata letak.
        let ptr = allocate(layout)?;

        // Inisialisasi RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Mengalokasikan `RcBox<T>` dengan ruang yang cukup untuk nilai dalam yang tidak berukuran
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Alokasikan untuk `RcBox<T>` menggunakan nilai yang diberikan.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Salin nilai sebagai byte
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Bebaskan alokasi tanpa menjatuhkan isinya
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Mengalokasikan `RcBox<[T]>` dengan panjang yang diberikan.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Salin elemen dari potongan ke Rc yang baru dialokasikan <\[T\]>
    ///
    /// Tidak aman karena penelepon harus mengambil kepemilikan atau mengikat `T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Membuat `Rc<[T]>` dari iterator yang diketahui berukuran tertentu.
    ///
    /// Perilaku tidak ditentukan jika ukurannya salah.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Panic menjaga saat mengkloning elemen T.
        // Jika terjadi panic, elemen yang telah ditulis ke RcBox baru akan dibuang, lalu memori dibebaskan.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Pointer ke elemen pertama
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Semua jelas.Lupakan pelindung sehingga tidak membebaskan RcBox baru.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Spesialisasi trait digunakan untuk `From<&[T]>`.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Menjatuhkan `Rc`.
    ///
    /// Ini akan mengurangi jumlah referensi yang kuat.
    /// Jika jumlah referensi yang kuat mencapai nol maka satu-satunya referensi lain (jika ada) adalah [`Weak`], jadi kami `drop` nilai dalamnya.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Tidak mencetak apa pun
    /// drop(foo2);   // Mencetak "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // hancurkan objek yang terkandung
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // hapus penunjuk "strong weak" implisit sekarang setelah kita menghancurkan isinya.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Membuat tiruan dari penunjuk `Rc`.
    ///
    /// Ini membuat penunjuk lain ke alokasi yang sama, meningkatkan jumlah referensi yang kuat.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Membuat `Rc<T>` baru, dengan nilai `Default` untuk `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Retas untuk mengizinkan spesialisasi pada `Eq` meskipun `Eq` memiliki metode.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Kami melakukan spesialisasi ini di sini, dan bukan sebagai pengoptimalan yang lebih umum pada `&T`, karena jika tidak akan menambah biaya untuk semua pemeriksaan kesetaraan pada referensi.
/// Kami berasumsi bahwa `Rc` digunakan untuk menyimpan nilai yang besar, yang lambat untuk dikloning, tetapi juga berat untuk memeriksa kesetaraan, menyebabkan biaya ini terbayar dengan lebih mudah.
///
/// Ini juga lebih cenderung memiliki dua klon `Rc`, yang mengarah ke nilai yang sama, daripada dua `&T`.
///
/// Kami hanya dapat melakukan ini jika `T: Eq` sebagai `PartialEq` mungkin sengaja dibuat tidak refleksif.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Kesetaraan untuk dua `Rc`.
    ///
    /// Dua `Rc` sama jika nilai dalamnya sama, meskipun disimpan dalam alokasi yang berbeda.
    ///
    /// Jika `T` juga mengimplementasikan `Eq` (menyiratkan refleksivitas persamaan), dua `Rc` yang mengarah ke alokasi yang sama selalu sama.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Ketimpangan untuk dua `Rc`.
    ///
    /// Dua `Rc` tidak sama jika nilai dalamnya tidak sama.
    ///
    /// Jika `T` juga mengimplementasikan `Eq` (menyiratkan refleksivitas kesetaraan), dua `Rc` yang mengarah ke alokasi yang sama tidak pernah tidak sama.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Perbandingan parsial untuk dua `Rc`.
    ///
    /// Keduanya dibandingkan dengan memanggil `partial_cmp()` pada nilai dalamnya.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Kurang dari perbandingan untuk dua `Rc`.
    ///
    /// Keduanya dibandingkan dengan memanggil `<` pada nilai dalamnya.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// Perbandingan 'Kurang dari atau sama dengan' untuk dua `Rc`.
    ///
    /// Keduanya dibandingkan dengan memanggil `<=` pada nilai dalamnya.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Lebih besar dari perbandingan untuk dua `Rc`.
    ///
    /// Keduanya dibandingkan dengan memanggil `>` pada nilai dalamnya.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// Perbandingan 'Lebih dari atau sama dengan' untuk dua `Rc`.
    ///
    /// Keduanya dibandingkan dengan memanggil `>=` pada nilai dalamnya.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Perbandingan untuk dua `Rc`.
    ///
    /// Keduanya dibandingkan dengan memanggil `cmp()` pada nilai dalamnya.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Alokasikan potongan yang dihitung referensi dan isi dengan menggandakan item `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Alokasikan potongan string yang dihitung referensi dan salin `v` ke dalamnya.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Alokasikan potongan string yang dihitung referensi dan salin `v` ke dalamnya.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Pindahkan objek dalam kotak ke alokasi baru, referensi dihitung.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Alokasikan potongan yang dihitung referensi dan pindahkan item `v` ke dalamnya.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Izinkan Vec untuk membebaskan memorinya, tetapi tidak menghancurkan isinya
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Mengambil setiap elemen di `Iterator` dan mengumpulkannya menjadi `Rc<[T]>`.
    ///
    /// # Karakteristik kinerja
    ///
    /// ## Kasus umum
    ///
    /// Dalam kasus umum, pengumpulan ke `Rc<[T]>` dilakukan dengan mengumpulkan ke `Vec<T>` terlebih dahulu.Artinya, saat menulis yang berikut:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// ini berperilaku seolah-olah kita menulis:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Kumpulan alokasi pertama terjadi di sini.
    ///     .into(); // Alokasi kedua untuk `Rc<[T]>` terjadi di sini.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Ini akan mengalokasikan sebanyak yang diperlukan untuk membangun `Vec<T>` dan kemudian akan mengalokasikan satu kali untuk mengubah `Vec<T>` menjadi `Rc<[T]>`.
    ///
    ///
    /// ## Iterator dengan panjang yang diketahui
    ///
    /// Jika `Iterator` Anda mengimplementasikan `TrustedLen` dan memiliki ukuran yang tepat, alokasi tunggal akan dibuat untuk `Rc<[T]>`.Sebagai contoh:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Hanya satu alokasi terjadi di sini.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Spesialisasi trait digunakan untuk mengumpulkan ke `Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Ini adalah kasus untuk iterator `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // KEAMANAN: Kami perlu memastikan bahwa iterator memiliki panjang yang tepat dan kami memilikinya.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Kembali ke implementasi normal.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` adalah versi [`Rc`] yang menyimpan referensi non-kepemilikan ke alokasi terkelola.Alokasi diakses dengan memanggil [`upgrade`] pada penunjuk `Weak`, yang mengembalikan [`Option`]`<`[`Rc`] `<T>>`.
///
/// Karena referensi `Weak` tidak diperhitungkan sebagai kepemilikan, hal ini tidak akan mencegah penurunan nilai yang disimpan dalam alokasi, dan `Weak` sendiri tidak menjamin tentang nilai yang masih ada.
/// Oleh karena itu, ia dapat mengembalikan [`None`] saat [`upgrade`] d.
/// Namun perlu diperhatikan bahwa referensi `Weak`*tidak* mencegah alokasi itu sendiri (penyimpanan pendukung) untuk dibatalkan alokasinya.
///
/// Pointer `Weak` berguna untuk menyimpan referensi sementara ke alokasi yang dikelola oleh [`Rc`] tanpa mencegah penurunan nilai dalamnya.
/// Ini juga digunakan untuk mencegah referensi melingkar antara pointer [`Rc`], karena referensi yang saling memiliki tidak akan pernah mengizinkan [`Rc`] untuk dibuang.
/// Misalnya, sebuah pohon dapat memiliki penunjuk [`Rc`] yang kuat dari simpul induk ke anak, dan penunjuk `Weak` dari anak kembali ke induknya.
///
/// Cara umum untuk mendapatkan pointer `Weak` adalah dengan memanggil [`Rc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Ini adalah `NonNull` untuk memungkinkan pengoptimalan ukuran jenis ini dalam enum, tetapi ini belum tentu merupakan penunjuk yang valid.
    //
    // `Weak::new` set ini ke `usize::MAX` sehingga tidak perlu mengalokasikan ruang di heap.
    // Itu bukan nilai yang akan dimiliki pointer nyata karena RcBox memiliki penyelarasan setidaknya 2.
    // Ini hanya mungkin jika `T: Sized`;`T` berukuran tidak pernah menjuntai.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Membuat `Weak<T>` baru, tanpa mengalokasikan memori apa pun.
    /// Memanggil [`upgrade`] dengan nilai pengembalian selalu memberikan [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Jenis pembantu untuk mengizinkan akses ke jumlah referensi tanpa membuat pernyataan apa pun tentang bidang data.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Mengembalikan pointer mentah ke objek `T` yang ditunjuk oleh `Weak<T>` ini.
    ///
    /// Penunjuk hanya valid jika ada beberapa referensi yang kuat.
    /// Penunjuk mungkin menjuntai, tidak sejajar atau bahkan [`null`] sebaliknya.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Keduanya menunjuk ke objek yang sama
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Yang kuat di sini membuatnya tetap hidup, jadi kita masih bisa mengakses objeknya.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Tapi tidak lagi.
    /// // Kita bisa melakukan weak.as_ptr(), tetapi mengakses pointer akan menyebabkan perilaku tidak terdefinisi.
    /// // assert_eq! ("halo", tidak aman {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Jika penunjuk menjuntai, kami mengembalikan sentinel secara langsung.
            // Ini tidak bisa menjadi alamat payload yang valid, karena payload setidaknya selaras dengan RcBox (usize).
            ptr as *const T
        } else {
            // KEAMANAN: jika is_dangling mengembalikan false, maka penunjuk tidak dapat dibedakan.
            // Payload mungkin turun pada saat ini, dan kita harus mempertahankan asalnya, jadi gunakan manipulasi pointer mentah.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Mengkonsumsi `Weak<T>` dan mengubahnya menjadi penunjuk mentah.
    ///
    /// Ini mengubah penunjuk lemah menjadi penunjuk mentah, sambil tetap mempertahankan kepemilikan satu referensi lemah (jumlah lemah tidak diubah oleh operasi ini).
    /// Itu dapat diubah kembali menjadi `Weak<T>` dengan [`from_raw`].
    ///
    /// Pembatasan yang sama untuk mengakses target pointer seperti pada [`as_ptr`] berlaku.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Mengonversi penunjuk mentah yang sebelumnya dibuat oleh [`into_raw`] kembali menjadi `Weak<T>`.
    ///
    /// Ini dapat digunakan untuk mendapatkan referensi yang kuat secara aman (dengan menelepon [`upgrade`] nanti) atau untuk membatalkan alokasi jumlah lemah dengan membatalkan `Weak<T>`.
    ///
    /// Ini mengambil kepemilikan dari satu referensi yang lemah (dengan pengecualian pointer yang dibuat oleh [`new`], karena ini tidak memiliki apa pun; metode masih berfungsi pada mereka).
    ///
    /// # Safety
    ///
    /// Pointer harus berasal dari [`into_raw`] dan masih memiliki potensi referensi yang lemah.
    ///
    /// Jumlah kuat diperbolehkan menjadi 0 pada saat memanggil ini.
    /// Namun demikian, ini mengambil kepemilikan satu referensi lemah yang saat ini direpresentasikan sebagai penunjuk mentah (jumlah lemah tidak diubah oleh operasi ini) dan oleh karena itu harus dipasangkan dengan panggilan sebelumnya ke [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Kurangi jumlah lemah terakhir.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Lihat Weak::as_ptr untuk konteks tentang bagaimana pointer input diturunkan.

        let ptr = if is_dangling(ptr as *mut T) {
            // Ini adalah Weak yang menjuntai.
            ptr as *mut RcBox<T>
        } else {
            // Jika tidak, kami dijamin penunjuknya berasal dari Lemah yang tidak mengganggu.
            // KEAMANAN: data_offset aman untuk dipanggil, karena ptr mereferensikan T. nyata (berpotensi jatuh).
            let offset = unsafe { data_offset(ptr) };
            // Jadi, kami membalikkan offset untuk mendapatkan seluruh RcBox.
            // SAFETY: pointer berasal dari Weak, jadi offset ini aman.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // KESELAMATAN: kita sekarang telah memulihkan pointer Lemah asli, sehingga dapat membuat Lemah.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Upaya untuk meningkatkan penunjuk `Weak` ke [`Rc`], menunda penurunan nilai dalam jika berhasil.
    ///
    ///
    /// Mengembalikan [`None`] jika nilai bagian dalam telah dijatuhkan.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Hancurkan semua petunjuk kuat.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Mendapat jumlah penunjuk (`Rc`) kuat yang menunjuk ke alokasi ini.
    ///
    /// Jika `self` dibuat menggunakan [`Weak::new`], ini akan menghasilkan 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Mendapat jumlah penunjuk `Weak` yang menunjuk ke alokasi ini.
    ///
    /// Jika tidak ada petunjuk kuat yang tersisa, ini akan mengembalikan nol.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // kurangi ptr lemah implisit
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Mengembalikan `None` saat penunjuk menjuntai dan tidak ada `RcBox` yang dialokasikan, (yaitu, saat `Weak` ini dibuat oleh `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Kami berhati-hati untuk *tidak* membuat referensi yang mencakup bidang "data", karena bidang tersebut mungkin bermutasi secara bersamaan (misalnya, jika `Rc` terakhir dijatuhkan, bidang data akan dibuang di tempat).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Mengembalikan `true` jika dua `Weak` menunjuk ke alokasi yang sama (mirip dengan [`ptr::eq`]), atau jika keduanya tidak menunjuk ke alokasi apa pun (karena keduanya dibuat dengan `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Karena ini membandingkan pointer, itu berarti `Weak::new()` akan sama satu sama lain, meskipun mereka tidak menunjuk ke alokasi apa pun.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Membandingkan `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Menurunkan penunjuk `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Tidak mencetak apa pun
    /// drop(foo);        // Mencetak "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // hitungan lemah dimulai dari 1, dan hanya akan menjadi nol jika semua petunjuk kuat telah menghilang.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Membuat tiruan dari penunjuk `Weak` yang menunjuk ke alokasi yang sama.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Membuat `Weak<T>` baru, mengalokasikan memori untuk `T` tanpa memulainya.
    /// Memanggil [`upgrade`] dengan nilai pengembalian selalu memberikan [`None`].
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Kami check_add di sini untuk menangani mem::forget dengan aman.Khususnya
// jika Anda mem::forget Rcs (atau Weaks), ref-count dapat meluap, dan kemudian Anda dapat membebaskan alokasi saat Rcs (atau Weaks) yang masih ada.
//
// Kami membatalkan karena ini adalah skenario yang merosot sehingga kami tidak peduli tentang apa yang terjadi-tidak boleh ada program nyata yang mengalami ini.
//
// Ini seharusnya memiliki overhead yang dapat diabaikan karena Anda sebenarnya tidak perlu mengkloning sebanyak ini di Rust berkat kepemilikan dan gerakan semantik.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Kami ingin membatalkan overflow daripada menjatuhkan nilainya.
        // Jumlah referensi tidak akan pernah nol saat ini dipanggil;
        // namun demikian, kami memasukkan abort di sini untuk mengisyaratkan LLVM pada pengoptimalan yang terlewat.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Kami ingin membatalkan overflow daripada menjatuhkan nilainya.
        // Jumlah referensi tidak akan pernah nol saat ini dipanggil;
        // namun demikian, kami memasukkan abort di sini untuk mengisyaratkan LLVM pada pengoptimalan yang terlewat.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Dapatkan offset dalam `RcBox` untuk muatan di belakang pointer.
///
/// # Safety
///
/// Penunjuk harus menunjuk ke (dan memiliki metadata yang valid untuk) turunan T yang sebelumnya valid, tetapi T diizinkan untuk dihapus.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Sejajarkan nilai yang tidak ukurannya ke akhir RcBox.
    // Karena RcBox adalah repr(C), RcBox akan selalu menjadi field terakhir dalam memori.
    // KEAMANAN: karena satu-satunya jenis berukuran besar yang mungkin adalah irisan, objek trait,
    // dan tipe eksternal, persyaratan keamanan input saat ini cukup untuk memenuhi persyaratan align_of_val_raw;ini adalah detail implementasi dari bahasa yang mungkin tidak dapat diandalkan di luar std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}