//! Utilitas untuk memformat dan mencetak `String`s.
//!
//! Modul ini berisi dukungan waktu proses untuk ekstensi sintaks [`format!`].
//! Makro ini diimplementasikan di compiler untuk mengirimkan panggilan ke modul ini untuk memformat argumen pada waktu proses menjadi string.
//!
//! # Usage
//!
//! Makro [`format!`] dimaksudkan agar familiar bagi mereka yang berasal dari fungsi `printf`/`fprintf` C atau fungsi `str.format` Python.
//!
//! Beberapa contoh ekstensi [`format!`] adalah:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" dengan nol di depan
//! ```
//!
//! Dari sini, Anda dapat melihat bahwa argumen pertama adalah string format.Diperlukan oleh kompilator untuk ini menjadi string literal;itu tidak bisa menjadi variabel yang diteruskan (untuk melakukan pemeriksaan validitas).
//! Kompilator kemudian akan mengurai string format dan menentukan apakah daftar argumen yang diberikan cocok untuk diteruskan ke string format ini.
//!
//! Untuk mengonversi satu nilai menjadi string, gunakan metode [`to_string`].Ini akan menggunakan format [`Display`] trait.
//!
//! ## Parameter posisi
//!
//! Setiap argumen pemformatan diizinkan untuk menentukan argumen nilai mana yang direferensikan, dan jika dihilangkan maka dianggap "the next argument".
//! Misalnya, format string `{} {} {}` akan menggunakan tiga parameter, dan akan diformat dalam urutan yang sama seperti yang diberikan.
//! Namun, format string `{2} {1} {0}` akan memformat argumen dalam urutan terbalik.
//!
//! Hal-hal bisa menjadi sedikit rumit setelah Anda mulai mencampurkan dua jenis penentu posisi.Penentu "next argument" dapat dianggap sebagai iterator atas argumen.
//! Setiap kali penentu "next argument" terlihat, iterator akan maju.Ini mengarah pada perilaku seperti ini:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! Iterator internal atas argumen belum dimajukan pada saat `{}` pertama terlihat, jadi ia mencetak argumen pertama.Kemudian setelah mencapai `{}` kedua, iterator telah maju ke argumen kedua.
//! Pada dasarnya, parameter yang secara eksplisit menamai argumennya tidak memengaruhi parameter yang tidak menyebutkan argumen dalam istilah penentu posisi.
//!
//! String format diperlukan untuk menggunakan semua argumennya, jika tidak maka itu adalah kesalahan waktu kompilasi.Anda dapat merujuk ke argumen yang sama lebih dari sekali dalam format string.
//!
//! ## Parameter bernama
//!
//! Rust sendiri tidak memiliki parameter bernama yang setara dengan Python untuk suatu fungsi, tetapi makro [`format!`] adalah ekstensi sintaks yang memungkinkannya untuk memanfaatkan parameter bernama.
//! Parameter bernama terdaftar di akhir daftar argumen dan memiliki sintaks:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Misalnya, ekspresi [`format!`] berikut semua menggunakan argumen bernama:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Tidak valid untuk meletakkan parameter posisi (yang tidak memiliki nama) setelah argumen yang memiliki nama.Seperti halnya parameter posisi, tidak valid untuk memberikan parameter bernama yang tidak digunakan oleh string format.
//!
//! # Parameter Pemformatan
//!
//! Setiap argumen yang sedang diformat dapat diubah dengan sejumlah parameter pemformatan (sesuai dengan `format_spec` di [the syntax](#syntax)). Parameter ini memengaruhi representasi string dari apa yang sedang diformat.
//!
//! ## Width
//!
//! ```
//! // Semua ini mencetak "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Ini adalah parameter untuk "minimum width" yang harus digunakan oleh format.
//! Jika string nilai tidak mengisi banyak karakter ini, maka padding yang ditentukan oleh fill/alignment akan digunakan untuk mengambil ruang yang diperlukan (lihat di bawah).
//!
//! Nilai untuk lebar juga dapat diberikan sebagai [`usize`] dalam daftar parameter dengan menambahkan `$` postfix, yang menunjukkan bahwa argumen kedua adalah [`usize`] yang menentukan lebar.
//!
//! Merujuk ke argumen dengan sintaks dolar tidak memengaruhi penghitung "next argument", jadi biasanya ide yang baik untuk merujuk ke argumen berdasarkan posisi, atau menggunakan argumen bernama.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! Karakter isian opsional dan perataan disediakan secara normal bersama dengan parameter [`width`](#width).Ini harus ditentukan sebelum `width`, tepat setelah `:`.
//! Ini menunjukkan bahwa jika nilai yang diformat lebih kecil dari `width`, beberapa karakter tambahan akan dicetak di sekitarnya.
//! Pengisian tersedia dalam varian berikut untuk berbagai penyelarasan:
//!
//! * `[fill]<` - argumen diratakan kiri di kolom `width`
//! * `[fill]^` - argumen diratakan tengah di kolom `width`
//! * `[fill]>` - argumen diratakan ke kanan di kolom `width`
//!
//! [fill/alignment](#fillalignment) default untuk non-numerik adalah spasi dan rata kiri.Default untuk pemformat numerik juga merupakan karakter spasi tetapi dengan perataan kanan.
//! Jika tanda `0` (lihat di bawah) ditentukan untuk numerik, maka karakter isian implisitnya adalah `0`.
//!
//! Perhatikan bahwa penyelarasan mungkin tidak diterapkan oleh beberapa jenis.Secara khusus, ini umumnya tidak diterapkan untuk `Debug` trait.
//! Cara yang baik untuk memastikan padding diterapkan adalah dengan memformat input Anda, lalu masukkan string yang dihasilkan ini untuk mendapatkan output Anda:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Halo Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Ini semua adalah tanda yang mengubah perilaku pemformat.
//!
//! * `+` - Ini ditujukan untuk tipe numerik dan menunjukkan bahwa tanda harus selalu dicetak.Tanda positif tidak pernah dicetak secara default, dan tanda negatif hanya dicetak secara default untuk `Signed` trait.
//! Bendera ini menunjukkan bahwa tanda yang benar (`+` atau `-`) harus selalu dicetak.
//! * `-` - Saat ini tidak digunakan
//! * `#` - Bendera ini menunjukkan bahwa bentuk pencetakan "alternate" harus digunakan.Bentuk alternatifnya adalah:
//!     * `#?` - cukup cetak format [`Debug`]
//!     * `#x` - mendahului argumen dengan `0x`
//!     * `#X` - mendahului argumen dengan `0x`
//!     * `#b` - mendahului argumen dengan `0b`
//!     * `#o` - mendahului argumen dengan `0o`
//! * `0` - Ini digunakan untuk menunjukkan untuk format integer bahwa padding ke `width` harus dilakukan dengan karakter `0` serta waspada terhadap tanda.
//! Format seperti `{:08}` akan menghasilkan `00000001` untuk bilangan bulat `1`, sedangkan format yang sama akan menghasilkan `-0000001` untuk bilangan bulat `-1`.
//! Perhatikan bahwa versi negatif memiliki satu nol lebih sedikit dari versi positif.
//!         Perhatikan bahwa padding nol selalu ditempatkan setelah tanda (jika ada) dan sebelum angka.Saat digunakan bersama dengan tanda `#`, aturan serupa berlaku: padding nol dimasukkan setelah awalan tetapi sebelum angka.
//!         Awalan termasuk dalam lebar total.
//!
//! ## Precision
//!
//! Untuk tipe non-numerik, ini dapat dianggap sebagai "maximum width".
//! Jika string yang dihasilkan lebih panjang dari lebar ini, maka string tersebut akan dipotong menjadi banyak karakter ini dan nilai yang dipotong tersebut dipancarkan dengan `fill`, `alignment`, dan `width` yang sesuai jika parameter tersebut disetel.
//!
//! Untuk tipe integral, ini diabaikan.
//!
//! Untuk tipe floating-point, ini menunjukkan berapa digit setelah koma desimal yang harus dicetak.
//!
//! Ada tiga cara yang mungkin untuk menentukan `precision` yang diinginkan:
//!
//! 1. Integer `.N`:
//!
//!    integer `N` itu sendiri adalah presisi.
//!
//! 2. Bilangan bulat atau nama diikuti dengan tanda dolar `.N$`:
//!
//!    gunakan format *argumen*`N` (yang harus berupa `usize`) sebagai presisi.
//!
//! 3. Tanda bintang `.*`:
//!
//!    `.*` berarti bahwa `{...}` ini dikaitkan dengan input format *dua* daripada satu: input pertama memegang presisi `usize`, dan input kedua menyimpan nilai untuk dicetak.
//!    Perhatikan bahwa dalam kasus ini, jika seseorang menggunakan format string `{<arg>:<spec>.*}`, maka bagian `<arg>` merujuk ke* nilai * untuk dicetak, dan `precision` harus dimasukkan sebelum `<arg>` dimasukkan.
//!
//! Misalnya, panggilan berikut ini semuanya mencetak hal yang sama `Hello x is 0.01000`:
//!
//! ```
//! // Halo {arg 0 ("x")} adalah {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Halo {arg 1 ("x")} adalah {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Halo {arg 0 ("x")} adalah {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Halo {next arg ("x")} adalah {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Halo {next arg ("x")} adalah {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Halo {next arg ("x")} adalah {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Sementara ini:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! mencetak tiga hal yang sangat berbeda:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! Dalam beberapa bahasa pemrograman, perilaku fungsi pemformatan string bergantung pada pengaturan lokal sistem operasi.
//! Fungsi format yang disediakan oleh pustaka standar Rust tidak memiliki konsep lokal apa pun dan akan memberikan hasil yang sama pada semua sistem terlepas dari konfigurasi pengguna.
//!
//! Misalnya, kode berikut akan selalu mencetak `1.5` meskipun lokal sistem menggunakan pemisah desimal selain titik.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! Karakter literal `{` dan `}` dapat dimasukkan dalam string dengan mengawalinya dengan karakter yang sama.Misalnya, karakter `{` di-escape dengan `{{` dan karakter `}` di-escape dengan `}}`.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Untuk meringkas, di sini Anda dapat menemukan tata bahasa lengkap dari string format.
//! Sintaks untuk bahasa pemformatan yang digunakan diambil dari bahasa lain, jadi tidak boleh terlalu asing.Argumen diformat dengan sintaks mirip Python, artinya argumen dikelilingi oleh `{}`, bukan `%` seperti C.
//! Tata bahasa sebenarnya untuk sintaks pemformatan adalah:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! Dalam tata bahasa di atas, `text` tidak boleh berisi karakter `'{'` atau `'}'`.
//!
//! # Memformat traits
//!
//! Saat meminta argumen diformat dengan tipe tertentu, Anda sebenarnya meminta argumen yang dianggap berasal dari trait tertentu.
//! Hal ini memungkinkan beberapa tipe aktual untuk diformat melalui `{:x}` (seperti [`i8`] dan [`isize`]).Jenis pemetaan saat ini ke traits adalah:
//!
//! * *tidak ada* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` ⇒ [`Debug`] dengan bilangan bulat heksadesimal huruf kecil
//! * `X?` ⇒ [`Debug`] dengan bilangan bulat heksadesimal huruf besar
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! Artinya, semua jenis argumen yang mengimplementasikan [`fmt::Binary`][`Binary`] trait kemudian dapat diformat dengan `{:b}`.Implementasi disediakan untuk traits ini untuk sejumlah tipe primitif oleh pustaka standar juga.
//!
//! Jika tidak ada format yang ditentukan (seperti di `{}` atau `{:6}`), maka format trait yang digunakan adalah [`Display`] trait.
//!
//! Saat menerapkan format trait untuk tipe Anda sendiri, Anda harus menerapkan metode tanda tangan:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // tipe khusus kami
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Jenis Anda akan diteruskan sebagai `self` dengan referensi, kemudian fungsi tersebut harus mengeluarkan keluaran ke aliran `f.buf`.Terserah setiap implementasi format trait untuk mematuhi parameter pemformatan yang diminta dengan benar.
//! Nilai parameter ini akan dicantumkan di bidang struktur [`Formatter`].Untuk membantu ini, struct [`Formatter`] juga menyediakan beberapa metode pembantu.
//!
//! Selain itu, nilai yang dikembalikan dari fungsi ini adalah [`fmt::Result`] yang merupakan alias tipe [`Result`]`<(),`[`std: : fmt::Error`] `>`.
//! Implementasi pemformatan harus memastikan bahwa mereka menyebarkan kesalahan dari [`Formatter`] (misalnya, saat memanggil [`write!`]).
//! Namun, mereka tidak boleh mengembalikan kesalahan secara palsu.
//! Artinya, implementasi pemformatan harus dan hanya dapat mengembalikan kesalahan jika [`Formatter`] yang diteruskan mengembalikan kesalahan.
//! Ini karena, bertentangan dengan apa yang mungkin disarankan oleh tanda tangan fungsi, pemformatan string adalah operasi yang sempurna.
//! Fungsi ini hanya mengembalikan hasil karena menulis ke aliran yang mendasari mungkin gagal dan harus menyediakan cara untuk menyebarkan fakta bahwa telah terjadi kesalahan pada tumpukan.
//!
//! Contoh penerapan pemformatan traits akan terlihat seperti ini:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // Nilai `f` mengimplementasikan `Write` trait, itulah yang tertulis!makro sedang menunggu.
//!         // Perhatikan bahwa pemformatan ini mengabaikan berbagai tanda yang disediakan untuk memformat string.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // traits yang berbeda memungkinkan berbagai bentuk keluaran dari suatu jenis.
//! // Arti dari format ini adalah untuk mencetak besarnya vector.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Hormati bendera pemformatan dengan menggunakan metode pembantu `pad_integral` pada objek Formatter.
//!         // Lihat dokumentasi metode untuk detailnya, dan fungsi `pad` dapat digunakan untuk mengisi string.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` vs `fmt::Debug`
//!
//! Kedua pemformatan traits ini memiliki tujuan yang berbeda:
//!
//! - [`fmt::Display`][`Display`] implementasi menegaskan bahwa tipe tersebut dapat direpresentasikan dengan tepat sebagai string UTF-8 setiap saat.**Tidak** diharapkan bahwa semua jenis menerapkan [`Display`] trait.
//! - [`fmt::Debug`][`Debug`] implementasi harus diterapkan untuk **semua** tipe publik.
//!   Keluaran biasanya akan mewakili keadaan internal seiman mungkin.
//!   Tujuan dari [`Debug`] trait adalah untuk memfasilitasi debugging kode Rust.Dalam kebanyakan kasus, menggunakan `#[derive(Debug)]` sudah cukup dan direkomendasikan.
//!
//! Beberapa contoh keluaran dari kedua traits:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Makro terkait
//!
//! Ada sejumlah makro terkait di keluarga [`format!`].Yang saat ini diimplementasikan adalah:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Ini dan [`writeln!`] adalah dua makro yang digunakan untuk memancarkan string format ke aliran tertentu.Ini digunakan untuk mencegah alokasi perantara dari string format dan sebagai gantinya langsung menulis output.
//! Di balik terpal, fungsi ini sebenarnya menjalankan fungsi [`write_fmt`] yang ditentukan pada [`std::io::Write`] trait.
//! Contoh penggunaannya adalah:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Ini dan [`println!`] memancarkan outputnya ke stdout.Sama halnya dengan makro [`write!`], tujuan makro ini adalah untuk menghindari alokasi perantara saat mencetak keluaran.Contoh penggunaannya adalah:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! Makro [`eprint!`] dan [`eprintln!`] identik dengan [`print!`] dan [`println!`], kecuali keduanya mengeluarkan output ke stderr.
//!
//! ### `format_args!`
//!
//! Ini adalah makro aneh yang digunakan untuk mengirimkan objek buram dengan aman yang mendeskripsikan format string.Objek ini tidak memerlukan alokasi heap apa pun untuk dibuat, dan hanya mereferensikan informasi di tumpukan.
//! Di balik terpal, semua makro terkait diimplementasikan dalam hal ini.
//! Pertama, beberapa contoh penggunaan adalah:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! Hasil makro [`format_args!`] adalah nilai tipe [`fmt::Arguments`].
//! Struktur ini kemudian dapat diteruskan ke fungsi [`write`] dan [`format`] di dalam modul ini untuk memproses format string.
//! Tujuan dari makro ini adalah untuk lebih jauh mencegah alokasi perantara saat menangani string pemformatan.
//!
//! Misalnya, perpustakaan logging dapat menggunakan sintaks pemformatan standar, tetapi secara internal akan meneruskan struktur ini sampai ditentukan ke mana keluaran harus dituju.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// Fungsi `format` mengambil struct [`Arguments`] dan mengembalikan string berformat yang dihasilkan.
///
///
/// Instance [`Arguments`] dapat dibuat dengan makro [`format_args!`].
///
/// # Examples
///
/// Penggunaan dasar:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Harap dicatat bahwa menggunakan [`format!`] mungkin lebih disukai.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}