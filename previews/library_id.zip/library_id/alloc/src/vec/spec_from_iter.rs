use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Spesialisasi trait digunakan untuk Vec::from_iter
///
/// ## Grafik delegasi:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Kasus yang umum terjadi adalah melewatkan vector ke dalam fungsi yang segera terkumpul kembali menjadi vector.
        // Kita dapat melakukan short circuit ini jika IntoIter belum dimajukan sama sekali.
        // Bila sudah maju Kita juga bisa menggunakan kembali memori dan memindahkan data ke depan.
        // Tetapi kami hanya melakukannya ketika Vec yang dihasilkan tidak memiliki lebih banyak kapasitas yang tidak terpakai daripada membuatnya melalui implementasi FromIterator generik.
        //
        // Batasan itu tidak sepenuhnya diperlukan karena perilaku alokasi Vec sengaja tidak ditentukan.
        // Tapi itu adalah pilihan konservatif.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // harus mendelegasikan ke spec_extend() karena extend() sendiri mendelegasikan ke spec_from untuk Vec kosong
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Ini menggunakan `iterator.as_slice().to_vec()` karena spec_extend harus mengambil lebih banyak langkah untuk mempertimbangkan kapasitas akhir + panjang dan dengan demikian melakukan lebih banyak pekerjaan.
// `to_vec()` mengalokasikan secara langsung jumlah yang benar dan mengisinya dengan tepat.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): dengan cfg(test) metode `[T]::to_vec` inheren, yang diperlukan untuk definisi metode ini, tidak tersedia.
    // Sebagai gantinya gunakan fungsi `slice::to_vec` yang hanya tersedia dengan cfg(test) NB lihat modul slice::hack di slice.rs untuk informasi lebih lanjut
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}