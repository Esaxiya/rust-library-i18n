// Tetapkan panjang vec saat nilai `SetLenOnDrop` keluar dari ruang lingkup.
//
// Idenya adalah: Field panjang di SetLenOnDrop adalah variabel lokal yang tidak akan dilihat oleh pengoptimal alias dengan penyimpanan apa pun melalui penunjuk data Vec.
// Ini adalah solusi untuk masalah analisis alias #32155
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}