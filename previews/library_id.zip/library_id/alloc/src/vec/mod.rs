//! Jenis array yang dapat diperbesar dengan konten yang dialokasikan heap, ditulis `Vec<T>`.
//!
//! Vectors memiliki pengindeksan `O(1)`, mendorong `O(1)` diamortisasi (ke akhir) dan `O(1)` pop (dari akhir).
//!
//!
//! Vectors memastikan mereka tidak pernah mengalokasikan lebih dari `isize::MAX` byte.
//!
//! # Examples
//!
//! Anda dapat secara eksplisit membuat [`Vec`] dengan [`Vec::new`]:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... atau dengan menggunakan makro [`vec!`]:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // sepuluh nol
//! ```
//!
//! Anda dapat [`push`] nilai ke ujung vector (yang akan menumbuhkan vector sesuai kebutuhan):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! Nilai popping bekerja dengan cara yang hampir sama:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors juga mendukung pengindeksan (melalui [`Index`] dan [`IndexMut`] traits):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// Jenis array yang dapat diperbesar, ditulis sebagai `Vec<T>` dan diucapkan 'vector'.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// Makro [`vec!`] disediakan untuk membuat inisialisasi lebih nyaman:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// Itu juga dapat menginisialisasi setiap elemen `Vec<T>` dengan nilai yang diberikan.
/// Ini mungkin lebih efisien daripada melakukan alokasi dan inisialisasi dalam langkah-langkah terpisah, terutama saat menginisialisasi vector nol:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // Berikut ini adalah padanan, tetapi berpotensi lebih lambat:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// Untuk informasi lebih lanjut, lihat [Capacity and Reallocation](#capacity-and-reallocation).
///
/// Gunakan `Vec<T>` sebagai tumpukan yang efisien:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // Mencetak 3, 2, 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// Jenis `Vec` memungkinkan untuk mengakses nilai berdasarkan indeks, karena ini mengimplementasikan [`Index`] trait.Contoh akan lebih eksplisit:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // itu akan menampilkan '2'
/// ```
///
/// Namun hati-hati: jika Anda mencoba mengakses indeks yang tidak ada di `Vec`, perangkat lunak Anda akan panic!Anda tidak dapat melakukan ini:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// Gunakan [`get`] dan [`get_mut`] jika Anda ingin memeriksa apakah indeks ada di `Vec`.
///
/// # Slicing
///
/// `Vec` bisa berubah.Di sisi lain, irisan adalah objek hanya-baca.
/// Untuk mendapatkan [slice][prim@slice], gunakan [`&`].Contoh:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... dan itu saja!
/// // Anda juga bisa melakukannya seperti ini:
/// let u: &[usize] = &v;
/// // atau seperti ini:
/// let u: &[_] = &v;
/// ```
///
/// Di Rust, lebih umum meneruskan slice sebagai argumen daripada vectors saat Anda hanya ingin memberikan akses baca.Hal yang sama berlaku untuk [`String`] dan [`&str`].
///
/// # Kapasitas dan realokasi
///
/// Kapasitas vector adalah jumlah ruang yang dialokasikan untuk setiap elemen future yang akan ditambahkan ke vector.Jangan bingung dengan *panjang* dari vector, yang menentukan jumlah elemen aktual dalam vector.
/// Jika panjang vector melebihi kapasitasnya, kapasitasnya akan bertambah secara otomatis, tetapi elemennya harus dialokasikan kembali.
///
/// Misalnya, vector dengan kapasitas 10 dan panjang 0 akan menjadi vector kosong dengan ruang untuk 10 elemen lagi.Mendorong 10 elemen atau kurang ke vector tidak akan mengubah kapasitasnya atau menyebabkan realokasi.
/// Namun, jika panjang vector ditingkatkan menjadi 11, itu harus dialokasikan kembali, yang bisa lambat.Untuk alasan ini, disarankan untuk menggunakan [`Vec::with_capacity`] jika memungkinkan untuk menentukan seberapa besar yang diharapkan vector.
///
/// # Guarantees
///
/// Karena sifatnya yang sangat fundamental, `Vec` memberikan banyak jaminan tentang desainnya.Hal ini memastikan bahwa biaya overhead serendah mungkin dalam kasus umum, dan dapat dimanipulasi dengan benar dengan cara yang primitif oleh kode yang tidak aman.Perhatikan bahwa jaminan ini mengacu pada `Vec<T>` yang tidak memenuhi syarat.
/// Jika parameter tipe tambahan ditambahkan (misalnya, untuk mendukung pengalokasi khusus), mengganti standarnya dapat mengubah perilakunya.
///
/// Pada dasarnya, `Vec` adalah dan akan selalu menjadi triplet (penunjuk, kapasitas, panjang).Tidak lebih, tidak kurang.Urutan bidang ini sama sekali tidak ditentukan, dan Anda harus menggunakan metode yang sesuai untuk mengubahnya.
/// Pointer tidak akan pernah null, jadi tipe ini dioptimalkan untuk null-pointer.
///
/// Namun, penunjuk mungkin tidak benar-benar menunjuk ke memori yang dialokasikan.
/// Khususnya, jika Anda membuat `Vec` dengan kapasitas 0 melalui [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`], atau dengan memanggil [`shrink_to_fit`] pada Vec kosong, memori tidak akan dialokasikan.Demikian pula, jika Anda menyimpan tipe berukuran nol di dalam `Vec`, itu tidak akan mengalokasikan ruang untuk mereka.
/// *Perhatikan bahwa dalam kasus ini `Vec` mungkin tidak melaporkan [`capacity`] dari 0*.
/// `Vec` akan mengalokasikan jika dan hanya jika [`mem: : size_of::<T>`]`() * capacity()> 0`.
/// Secara umum, detail alokasi `Vec` sangat halus-jika Anda bermaksud mengalokasikan memori menggunakan `Vec` dan menggunakannya untuk hal lain (baik untuk meneruskan ke kode yang tidak aman, atau untuk membangun koleksi Anda yang didukung memori), pastikan untuk membatalkan alokasi memori ini dengan menggunakan `from_raw_parts` untuk memulihkan `Vec` dan kemudian menjatuhkannya.
///
/// Jika `Vec`*memiliki* mengalokasikan memori, maka memori yang ditunjuknya ada di heap (sebagaimana ditentukan oleh pengalokasi Rust dikonfigurasi untuk digunakan secara default), dan penunjuknya menunjuk ke [`len`] yang diinisialisasi, elemen yang berdekatan secara berurutan (apa yang Anda inginkan lihat apakah Anda memaksanya menjadi sepotong), diikuti oleh [`capacity`]`,`[`len`] yang secara logis tidak diinisialisasi, elemen yang berdekatan.
///
///
/// Sebuah vector yang berisi elemen `'a'` dan `'b'` dengan kapasitas 4 dapat divisualisasikan seperti di bawah ini.Bagian atas adalah struct `Vec`, ini berisi penunjuk ke kepala alokasi di heap, panjang dan kapasitas.
/// Bagian bawah adalah alokasi pada heap, blok memori yang berdekatan.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** mewakili memori yang belum diinisialisasi, lihat [`MaybeUninit`].
/// - Note: ABI tidak stabil dan `Vec` tidak menjamin tata letak memorinya (termasuk urutan bidang).
///
/// `Vec` tidak akan pernah melakukan "small optimization" di mana elemen sebenarnya disimpan di tumpukan karena dua alasan:
///
/// * Ini akan mempersulit kode yang tidak aman untuk memanipulasi `Vec` dengan benar.Isi dari `Vec` tidak akan memiliki alamat yang stabil jika hanya dipindahkan, dan akan lebih sulit untuk menentukan apakah `Vec` benar-benar mengalokasikan memori.
///
/// * Ini akan menghukum kasus umum, menimbulkan branch tambahan pada setiap akses.
///
/// `Vec` tidak akan otomatis menyusut sendiri, meskipun kosong sama sekali.Ini memastikan tidak ada alokasi atau deallocations yang tidak perlu terjadi.Mengosongkan `Vec` dan kemudian mengisinya kembali ke [`len`] yang sama tidak akan menimbulkan panggilan ke pengalokasi.Jika Anda ingin mengosongkan memori yang tidak digunakan, gunakan [`shrink_to_fit`] atau [`shrink_to`].
///
/// [`push`] dan [`insert`] tidak akan pernah mengalokasikan (kembali) jika kapasitas yang dilaporkan mencukupi.[`push`] dan [`insert`]*akan*(kembali) mengalokasikan jika [`len`]`==`[`capacity`].Artinya, kapasitas yang dilaporkan benar-benar akurat, dan bisa diandalkan.Ia bahkan dapat digunakan untuk membebaskan memori yang dialokasikan oleh `Vec` secara manual jika diinginkan.
/// Metode penyisipan massal *mungkin* dialokasikan kembali, meskipun tidak diperlukan.
///
/// `Vec` tidak menjamin strategi pertumbuhan tertentu saat melakukan realokasi saat penuh, atau saat [`reserve`] dipanggil.Strategi saat ini adalah dasar dan mungkin perlu menggunakan faktor pertumbuhan yang tidak konstan.Apapun strategi yang digunakan tentu saja akan menjamin *O*(1) diamortisasi [`push`].
///
/// `vec![x; n]`, `vec![a, b, c, d]`, dan [`Vec::with_capacity(n)`][`Vec::with_capacity`], semuanya akan menghasilkan `Vec` dengan kapasitas yang sama persis dengan yang diminta.
/// Jika [`len`]`==`[`capacity`], (seperti kasus makro [`vec!`]), maka `Vec<T>` dapat dikonversi ke dan dari [`Box<[T]>`][owned slice] tanpa mengalokasikan ulang atau memindahkan elemen.
///
/// `Vec` tidak akan secara khusus menimpa data apa pun yang dihapus darinya, tetapi juga tidak akan secara khusus menyimpannya.Memori yang tidak diinisialisasi adalah ruang awal yang dapat digunakan sesuka hati.Ini umumnya hanya akan melakukan apa pun yang paling efisien atau mudah diterapkan.Jangan mengandalkan data yang dihapus untuk dihapus demi tujuan keamanan.
/// Bahkan jika Anda menjatuhkan `Vec`, buffernya dapat digunakan kembali oleh `Vec` lain.
/// Meskipun Anda membidik memori `Vec` terlebih dahulu, itu mungkin tidak benar-benar terjadi karena pengoptimal tidak menganggap ini sebagai efek samping yang harus dipertahankan.
/// Namun, ada satu kasus yang tidak akan kami pecahkan: menggunakan kode `unsafe` untuk menulis ke kapasitas berlebih, dan kemudian menambah panjang untuk mencocokkan, selalu valid.
///
/// Saat ini, `Vec` tidak menjamin urutan pelepasan elemen.
/// Urutan telah berubah di masa lalu dan dapat berubah lagi.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// Metode yang melekat
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// Membuat `Vec<T>` baru yang kosong.
    ///
    /// vector tidak akan mengalokasikan sampai elemen didorong ke atasnya.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// Membuat `Vec<T>` baru dan kosong dengan kapasitas yang ditentukan.
    ///
    /// vector akan dapat menampung elemen `capacity` dengan tepat tanpa mengalokasikan ulang.
    /// Jika `capacity` adalah 0, vector tidak akan mengalokasikan.
    ///
    /// Penting untuk dicatat bahwa meskipun vector yang dikembalikan memiliki *kapasitas* yang ditentukan, vector akan memiliki panjang *nol*.
    ///
    /// Untuk penjelasan tentang perbedaan antara panjang dan kapasitas, lihat *[Kapasitas dan realokasi]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // vector tidak berisi item, meskipun memiliki kapasitas lebih
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Ini semua dilakukan tanpa mengalokasikan kembali ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... tetapi ini dapat membuat vector dialokasikan kembali
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Membuat `Vec<T>` langsung dari komponen mentah vector lain.
    ///
    /// # Safety
    ///
    /// Ini sangat tidak aman, karena jumlah invarian yang tidak diperiksa:
    ///
    /// * `ptr` sebelumnya harus dialokasikan melalui [`String`]/`Vec<T>`` (setidaknya, itu sangat mungkin salah jika tidak).
    /// * `T` harus memiliki ukuran dan kesejajaran yang sama dengan yang dialokasikan pada `ptr`.
    ///   (`T` memiliki perataan yang kurang ketat saja tidak cukup, perataan benar-benar harus sama untuk memenuhi persyaratan [`dealloc`] bahwa memori harus dialokasikan dan dialokasikan dengan tata letak yang sama.)
    ///
    /// * `length` harus kurang dari atau sama dengan `capacity`.
    /// * `capacity` perlu kapasitas yang dialokasikan dengan penunjuk.
    ///
    /// Melanggar ini dapat menyebabkan masalah seperti merusak struktur data internal pengalokasi.Misalnya,**tidak** aman untuk membuat `Vec<u8>` dari pointer ke array C `char` dengan panjang `size_t`.
    /// Juga tidak aman untuk membangun satu dari `Vec<u16>` dan panjangnya, karena pengalokasi peduli tentang penyelarasan, dan kedua jenis ini memiliki perataan yang berbeda.
    /// Buffer dialokasikan dengan alignment 2 (untuk `u16`), tapi setelah mengubahnya menjadi `Vec<u8>` akan dialokasikan dengan alignment 1.
    ///
    /// Kepemilikan `ptr` secara efektif ditransfer ke `Vec<T>` yang kemudian dapat membatalkan alokasi, mengalokasikan kembali atau mengubah konten memori yang ditunjukkan oleh penunjuk sesuka hati.
    /// Pastikan tidak ada orang lain yang menggunakan penunjuk setelah memanggil fungsi ini.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME Perbarui ini ketika vec_into_raw_parts distabilkan.
    ///     // Cegah menjalankan destruktor `v` sehingga kita dapat mengontrol alokasi sepenuhnya.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Tarik berbagai informasi penting tentang `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // Timpa memori dengan 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Kembalikan semuanya menjadi Vec
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Membuat `Vec<T, A>` baru yang kosong.
    ///
    /// vector tidak akan mengalokasikan sampai elemen didorong ke atasnya.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// Membuat `Vec<T, A>` baru dan kosong dengan kapasitas yang ditentukan dengan pengalokasi yang disediakan.
    ///
    /// vector akan dapat menampung elemen `capacity` dengan tepat tanpa mengalokasikan ulang.
    /// Jika `capacity` adalah 0, vector tidak akan mengalokasikan.
    ///
    /// Penting untuk dicatat bahwa meskipun vector yang dikembalikan memiliki *kapasitas* yang ditentukan, vector akan memiliki panjang *nol*.
    ///
    /// Untuk penjelasan tentang perbedaan antara panjang dan kapasitas, lihat *[Kapasitas dan realokasi]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // vector tidak berisi item, meskipun memiliki kapasitas lebih
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Ini semua dilakukan tanpa mengalokasikan kembali ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... tetapi ini dapat membuat vector dialokasikan kembali
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// Membuat `Vec<T, A>` langsung dari komponen mentah vector lain.
    ///
    /// # Safety
    ///
    /// Ini sangat tidak aman, karena jumlah invarian yang tidak diperiksa:
    ///
    /// * `ptr` sebelumnya harus dialokasikan melalui [`String`]/`Vec<T>`` (setidaknya, itu sangat mungkin salah jika tidak).
    /// * `T` harus memiliki ukuran dan kesejajaran yang sama dengan yang dialokasikan pada `ptr`.
    ///   (`T` memiliki perataan yang kurang ketat saja tidak cukup, perataan benar-benar harus sama untuk memenuhi persyaratan [`dealloc`] bahwa memori harus dialokasikan dan dialokasikan dengan tata letak yang sama.)
    ///
    /// * `length` harus kurang dari atau sama dengan `capacity`.
    /// * `capacity` perlu kapasitas yang dialokasikan dengan penunjuk.
    ///
    /// Melanggar ini dapat menyebabkan masalah seperti merusak struktur data internal pengalokasi.Misalnya,**tidak** aman untuk membuat `Vec<u8>` dari pointer ke array C `char` dengan panjang `size_t`.
    /// Juga tidak aman untuk membangun satu dari `Vec<u16>` dan panjangnya, karena pengalokasi peduli tentang penyelarasan, dan kedua jenis ini memiliki perataan yang berbeda.
    /// Buffer dialokasikan dengan alignment 2 (untuk `u16`), tapi setelah mengubahnya menjadi `Vec<u8>` akan dialokasikan dengan alignment 1.
    ///
    /// Kepemilikan `ptr` secara efektif ditransfer ke `Vec<T>` yang kemudian dapat membatalkan alokasi, mengalokasikan kembali atau mengubah konten memori yang ditunjukkan oleh penunjuk sesuka hati.
    /// Pastikan tidak ada orang lain yang menggunakan penunjuk setelah memanggil fungsi ini.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME Perbarui ini ketika vec_into_raw_parts distabilkan.
    ///     // Cegah menjalankan destruktor `v` sehingga kita dapat mengontrol alokasi sepenuhnya.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Tarik berbagai informasi penting tentang `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // Timpa memori dengan 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Kembalikan semuanya menjadi Vec
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// Menguraikan `Vec<T>` menjadi komponen mentahnya.
    ///
    /// Mengembalikan pointer mentah ke data yang mendasarinya, panjang vector (dalam elemen), dan kapasitas data yang dialokasikan (dalam elemen).
    /// Ini adalah argumen yang sama dalam urutan yang sama dengan argumen ke [`from_raw_parts`].
    ///
    /// Setelah memanggil fungsi ini, pemanggil bertanggung jawab atas memori yang sebelumnya dikelola oleh `Vec`.
    /// Satu-satunya cara untuk melakukan ini adalah dengan mengubah penunjuk mentah, panjang, dan kapasitas kembali menjadi `Vec` dengan fungsi [`from_raw_parts`], yang memungkinkan destruktor untuk melakukan pembersihan.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // Kami sekarang dapat membuat perubahan pada komponen, seperti mentransmutasikan pointer mentah ke tipe yang kompatibel.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// Menguraikan `Vec<T>` menjadi komponen mentahnya.
    ///
    /// Mengembalikan pointer mentah ke data pokok, panjang vector (dalam elemen), kapasitas data yang dialokasikan (dalam elemen), dan pengalokasi.
    /// Ini adalah argumen yang sama dalam urutan yang sama dengan argumen ke [`from_raw_parts_in`].
    ///
    /// Setelah memanggil fungsi ini, pemanggil bertanggung jawab atas memori yang sebelumnya dikelola oleh `Vec`.
    /// Satu-satunya cara untuk melakukan ini adalah dengan mengubah penunjuk mentah, panjang, dan kapasitas kembali menjadi `Vec` dengan fungsi [`from_raw_parts_in`], yang memungkinkan destruktor untuk melakukan pembersihan.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // Kami sekarang dapat membuat perubahan pada komponen, seperti mentransmutasikan pointer mentah ke tipe yang kompatibel.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// Mengembalikan jumlah elemen yang dapat ditampung vector tanpa dialokasikan kembali.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// Mencadangkan kapasitas untuk setidaknya `additional` lebih banyak elemen untuk dimasukkan ke dalam `Vec<T>` tertentu.
    /// Koleksi mungkin memiliki lebih banyak ruang untuk menghindari realokasi yang sering.
    /// Setelah memanggil `reserve`, kapasitas akan lebih besar dari atau sama dengan `self.len() + additional`.
    /// Tidak melakukan apa-apa jika kapasitas sudah mencukupi.
    ///
    /// # Panics
    ///
    /// Panics jika kapasitas baru melebihi `isize::MAX` byte.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// Mencadangkan kapasitas minimum untuk `additional` lebih banyak elemen yang akan disisipkan ke `Vec<T>` tertentu.
    ///
    /// Setelah memanggil `reserve_exact`, kapasitas akan lebih besar dari atau sama dengan `self.len() + additional`.
    /// Tidak melakukan apa-apa jika kapasitasnya sudah mencukupi.
    ///
    /// Perhatikan bahwa pengalokasi mungkin memberi koleksi lebih banyak ruang daripada yang diminta.
    /// Oleh karena itu, kapasitas tidak bisa diandalkan untuk menjadi sangat minim.
    /// Pilih `reserve` jika penyisipan future diharapkan.
    ///
    /// # Panics
    ///
    /// Panics jika kapasitas baru melebihi `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// Mencoba mencadangkan kapasitas untuk setidaknya `additional` lebih banyak elemen untuk dimasukkan ke dalam `Vec<T>` yang diberikan.
    /// Koleksi mungkin memiliki lebih banyak ruang untuk menghindari realokasi yang sering.
    /// Setelah memanggil `try_reserve`, kapasitas akan lebih besar dari atau sama dengan `self.len() + additional`.
    /// Tidak melakukan apa-apa jika kapasitas sudah mencukupi.
    ///
    /// # Errors
    ///
    /// Jika kapasitas meluap, atau pengalokasi melaporkan kegagalan, maka kesalahan dikembalikan.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Pra-pesan memori, keluar jika kita tidak bisa
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Sekarang kami tahu ini tidak bisa OOM di tengah pekerjaan kompleks kami
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // sangat rumit
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// Mencoba mencadangkan kapasitas minimum untuk tepat `additional` elemen yang akan dimasukkan ke dalam `Vec<T>` yang diberikan.
    /// Setelah memanggil `try_reserve_exact`, kapasitas akan lebih besar dari atau sama dengan `self.len() + additional` jika mengembalikan `Ok(())`.
    ///
    /// Tidak melakukan apa-apa jika kapasitasnya sudah mencukupi.
    ///
    /// Perhatikan bahwa pengalokasi mungkin memberi koleksi lebih banyak ruang daripada yang diminta.
    /// Oleh karena itu, kapasitas tidak bisa diandalkan untuk menjadi sangat minim.
    /// Pilih `reserve` jika penyisipan future diharapkan.
    ///
    /// # Errors
    ///
    /// Jika kapasitas meluap, atau pengalokasi melaporkan kegagalan, maka kesalahan dikembalikan.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Pra-pesan memori, keluar jika kita tidak bisa
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Sekarang kami tahu ini tidak bisa OOM di tengah pekerjaan kompleks kami
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // sangat rumit
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// Kecilkan kapasitas vector sebanyak mungkin.
    ///
    /// Ini akan turun sedekat mungkin dengan panjangnya tetapi pengalokasi mungkin masih memberi tahu vector bahwa ada ruang untuk beberapa elemen lagi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // Kapasitasnya tidak pernah kurang dari panjangnya, dan tidak ada yang bisa dilakukan jika keduanya sama, jadi kita dapat menghindari casing panic di `RawVec::shrink_to_fit` hanya dengan memanggilnya dengan kapasitas yang lebih besar.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// Menyusut kapasitas vector dengan batas bawah.
    ///
    /// Kapasitas akan tetap setidaknya sebesar panjang dan nilai yang diberikan.
    ///
    ///
    /// Jika kapasitas saat ini kurang dari batas bawah, ini adalah no-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// Mengubah vector menjadi [`Box<[T]>`][owned slice].
    ///
    /// Perhatikan bahwa ini akan menurunkan kapasitas berlebih.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// Setiap kelebihan kapasitas dihilangkan:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// Persingkat vector, pertahankan elemen `len` pertama dan hapus sisanya.
    ///
    /// Jika `len` lebih besar dari panjang vector saat ini, ini tidak berpengaruh.
    ///
    /// Metode [`drain`] dapat meniru `truncate`, tetapi menyebabkan elemen berlebih dikembalikan, bukan dibuang.
    ///
    ///
    /// Perhatikan bahwa metode ini tidak berpengaruh pada kapasitas yang dialokasikan dari vector.
    ///
    /// # Examples
    ///
    /// Memotong lima elemen vector menjadi dua elemen:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// Tidak ada pemotongan yang terjadi jika `len` lebih besar dari panjang vector saat ini:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// Memotong saat `len == 0` setara dengan memanggil metode [`clear`].
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // Ini aman karena:
        //
        // * potongan yang diteruskan ke `drop_in_place` valid;kasus `len > self.len` menghindari pembuatan potongan yang tidak valid, dan
        // * `len` dari vector menyusut sebelum memanggil `drop_in_place`, sehingga tidak ada nilai yang akan dijatuhkan dua kali jika `drop_in_place` ke panic sekali (jika panics dua kali, program dibatalkan).
        //
        //
        //
        unsafe {
            // Note: Ini disengaja bahwa ini adalah `>` dan bukan `>=`.
            //       Mengubahnya ke `>=` memiliki implikasi kinerja negatif dalam beberapa kasus.
            //       Lihat #78884 untuk lebih lanjut.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// Mengekstrak potongan yang berisi seluruh vector.
    ///
    /// Setara dengan `&s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Mengekstrak bagian yang bisa berubah dari seluruh vector.
    ///
    /// Setara dengan `&mut s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Mengembalikan pointer mentah ke buffer vector.
    ///
    /// Pemanggil harus memastikan bahwa vector hidup lebih lama dari pointer yang dikembalikan fungsi ini, atau akan berakhir dengan mengarah ke sampah.
    /// Memodifikasi vector dapat menyebabkan buffernya dialokasikan kembali, yang juga akan membuat petunjuk apa pun ke sana menjadi tidak valid.
    ///
    /// Pemanggil juga harus memastikan bahwa memori yang ditunjuk oleh penunjuk (non-transitively) tidak pernah ditulis (kecuali di dalam `UnsafeCell`) menggunakan penunjuk ini atau penunjuk apa pun yang diturunkan darinya.
    /// Jika Anda perlu mengubah konten potongan, gunakan [`as_mut_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // Kami membayangi metode irisan dengan nama yang sama untuk menghindari melalui `deref`, yang membuat referensi perantara.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Mengembalikan penunjuk yang tidak dapat diubah yang tidak aman ke buffer vector.
    ///
    /// Pemanggil harus memastikan bahwa vector hidup lebih lama dari pointer yang dikembalikan fungsi ini, atau akan berakhir dengan mengarah ke sampah.
    ///
    /// Memodifikasi vector dapat menyebabkan buffernya dialokasikan kembali, yang juga akan membuat petunjuk apa pun ke sana menjadi tidak valid.
    ///
    /// # Examples
    ///
    /// ```
    /// // Alokasikan vector cukup besar untuk 4 elemen.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Inisialisasi elemen melalui penulisan pointer mentah, lalu setel panjangnya.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // Kami membayangi metode irisan dengan nama yang sama untuk menghindari melalui `deref_mut`, yang membuat referensi perantara.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Mengembalikan referensi ke pengalokasi pokok.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// Memaksakan panjang vector ke `new_len`.
    ///
    /// Ini adalah operasi tingkat rendah yang tidak mempertahankan invarian normal dari tipe tersebut.
    /// Biasanya mengubah panjang vector dilakukan dengan menggunakan salah satu operasi yang aman, seperti [`truncate`], [`resize`], [`extend`], atau [`clear`].
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` harus kurang dari atau sama dengan [`capacity()`].
    /// - Elemen di `old_len..new_len` harus diinisialisasi.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// Metode ini dapat berguna untuk situasi di mana vector berfungsi sebagai buffer untuk kode lain, terutama melalui FFI:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // Ini hanyalah kerangka minimal untuk contoh dokumen;
    /// # // jangan gunakan ini sebagai titik awal untuk perpustakaan nyata.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // Sesuai dengan dokumen metode FFI, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // KEAMANAN: Ketika `deflateGetDictionary` mengembalikan `Z_OK`, ia menyatakan bahwa:
    ///     // 1. `dict_length` elemen diinisialisasi.
    ///     // 2.
    ///     // `dict_length` <=kapasitas (32_768) yang membuat `set_len` aman untuk ditelepon.
    ///     unsafe {
    ///         // Lakukan panggilan FFI ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... dan perbarui panjang yang diinisialisasi.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// Sementara contoh berikut adalah suara, ada kebocoran memori karena vectors bagian dalam tidak dibebaskan sebelum panggilan `set_len`:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` kosong sehingga tidak ada elemen yang perlu diinisialisasi.
    /// // 2. `0 <= capacity` selalu memegang apapun `capacity` itu.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// Biasanya, di sini, seseorang akan menggunakan [`clear`] sebagai gantinya untuk menjatuhkan konten dengan benar dan dengan demikian tidak membocorkan memori.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// Menghapus elemen dari vector dan mengembalikannya.
    ///
    /// Elemen yang dihapus diganti dengan elemen terakhir dari vector.
    ///
    /// Ini tidak mempertahankan pemesanan, tetapi O(1).
    ///
    /// # Panics
    ///
    /// Panics jika `index` di luar batas.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // Kami mengganti self [index] dengan elemen terakhir.
            // Perhatikan bahwa jika pemeriksaan batas di atas berhasil, harus ada elemen terakhir (yang bisa menjadi sendiri [indeks] itu sendiri).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// Menyisipkan elemen pada posisi `index` dalam vector, menggeser semua elemen setelahnya ke kanan.
    ///
    ///
    /// # Panics
    ///
    /// Panics jika `index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // ruang untuk elemen baru
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // infallible Tempat untuk memberikan nilai baru
            //
            {
                let p = self.as_mut_ptr().add(index);
                // Geser semuanya untuk memberi ruang.
                // (Menduplikasi elemen `index` menjadi dua tempat yang berurutan.)
                ptr::copy(p, p.offset(1), len - index);
                // Tuliskan, timpa salinan pertama dari elemen `index`.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// Menghapus dan mengembalikan elemen pada posisi `index` dalam vector, menggeser semua elemen setelahnya ke kiri.
    ///
    ///
    /// # Panics
    ///
    /// Panics jika `index` di luar batas.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // tempat kami mengambil.
                let ptr = self.as_mut_ptr().add(index);
                // salin, tidak aman memiliki salinan nilai di stack dan di vector pada saat yang bersamaan.
                //
                ret = ptr::read(ptr);

                // Geser semuanya ke bawah untuk mengisi tempat itu.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// Mempertahankan hanya elemen yang ditentukan oleh predikat.
    ///
    /// Dengan kata lain, hapus semua elemen `e` sehingga `f(&e)` mengembalikan `false`.
    /// Metode ini beroperasi di tempat, mengunjungi setiap elemen tepat satu kali dalam urutan aslinya, dan mempertahankan urutan elemen yang dipertahankan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// Karena elemen dikunjungi tepat sekali dalam urutan aslinya, status eksternal dapat digunakan untuk memutuskan elemen mana yang akan dipertahankan.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // Hindari double drop jika drop guard tidak dijalankan, karena kami mungkin membuat beberapa lubang selama proses tersebut.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-diproses len-> |^-di sebelah untuk memeriksa
        //                  | <-dihapus cnt-> |
        //      | <-original_len-> |Disimpan: Elemen yang predikatnya mengembalikan nilai true.
        //
        // Lubang: Slot elemen yang dipindahkan atau dijatuhkan.
        // Tidak dicentang: Elemen valid tidak dicentang.
        //
        // Penjaga drop ini akan dipanggil ketika predikat atau elemen `drop` panik.
        // Ini menggeser elemen yang tidak dicentang untuk menutupi lubang dan `set_len` ke panjang yang benar.
        // Jika predikat dan `drop` tidak pernah panik, itu akan dioptimalkan.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // KEAMANAN: Item yang tidak dicentang harus valid karena kami tidak pernah menyentuhnya.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // KEAMANAN: Setelah mengisi lubang, semua item berada dalam memori yang berdekatan.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // KEAMANAN: Elemen yang tidak dicentang harus valid.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // Maju lebih awal untuk menghindari penurunan ganda jika `drop_in_place` panik.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // KEAMANAN: Kami tidak pernah menyentuh elemen ini lagi setelah dijatuhkan.
                unsafe { ptr::drop_in_place(cur) };
                // Kami sudah memajukan penghitung.
                continue;
            }
            if g.deleted_cnt > 0 {
                // SAFETY: `deleted_cnt`> 0, jadi slot lubang tidak boleh tumpang tindih dengan elemen arus.
                // Kami menggunakan salinan untuk memindahkan, dan tidak pernah menyentuh elemen ini lagi.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // Semua item diproses.Ini dapat dioptimalkan ke `set_len` oleh LLVM.
        drop(g);
    }

    /// Menghapus semua kecuali yang pertama dari elemen berurutan di vector yang menyelesaikan kunci yang sama.
    ///
    ///
    /// Jika vector diurutkan, ini akan menghapus semua duplikat.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// Menghapus semua kecuali yang pertama dari elemen berurutan di vector memenuhi hubungan kesetaraan yang diberikan.
    ///
    /// Fungsi `same_bucket` memberikan referensi ke dua elemen dari vector dan harus menentukan apakah perbandingan elemen tersebut sama.
    /// Elemen diteruskan dalam urutan berlawanan dari urutannya dalam potongan, jadi jika `same_bucket(a, b)` mengembalikan `true`, `a` akan dihapus.
    ///
    ///
    /// Jika vector diurutkan, ini akan menghapus semua duplikat.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// Menambahkan elemen ke belakang koleksi.
    ///
    /// # Panics
    ///
    /// Panics jika kapasitas baru melebihi `isize::MAX` byte.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // Ini akan panic atau batal jika kita akan mengalokasikan> isize::MAX byte atau jika penambahan panjang akan meluap untuk tipe berukuran nol.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// Menghapus elemen terakhir dari vector dan mengembalikannya, atau [`None`] jika kosong.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// Memindahkan semua elemen `other` ke `Self`, membiarkan `other` kosong.
    ///
    /// # Panics
    ///
    /// Panics jika jumlah elemen di vector melebihi `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// Menambahkan elemen ke `Self` dari buffer lain.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// Membuat iterator pengurasan yang menghapus kisaran tertentu di vector dan menghasilkan item yang dihapus.
    ///
    /// Jika iterator ** dijatuhkan, semua elemen dalam rentang tersebut akan dihapus dari vector, meskipun iterator tidak digunakan sepenuhnya.
    /// Jika iterator **tidak** dijatuhkan (dengan [`mem::forget`] misalnya), tidak ditentukan berapa banyak elemen yang dihapus.
    ///
    /// # Panics
    ///
    /// Panics jika titik awal lebih besar dari titik akhir atau jika titik akhir lebih besar dari panjang vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // Jangkauan penuh membersihkan vector
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Keamanan memori
        //
        // Saat Drain pertama kali dibuat, ia memperpendek panjang sumber vector untuk memastikan tidak ada elemen yang tidak diinisialisasi atau dipindahkan yang dapat diakses sama sekali jika destruktor Drain tidak pernah berjalan.
        //
        //
        // Drain akan mengeluarkan ptr::read dari nilai yang akan dihapus.
        // Setelah selesai, sisa ekor vec disalin kembali untuk menutupi lubang, dan panjang vector dikembalikan ke panjang yang baru.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // setel panjang self.vec untuk memulai, agar aman jika Drain bocor
            self.set_len(start);
            // Gunakan peminjaman di IterMut untuk menunjukkan perilaku peminjaman seluruh iterator Drain (seperti &mut T).
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// Menghapus vector, menghapus semua nilai.
    ///
    /// Perhatikan bahwa metode ini tidak berpengaruh pada kapasitas yang dialokasikan dari vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// Mengembalikan jumlah elemen di vector, juga disebut sebagai 'length'-nya.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Mengembalikan `true` jika vector tidak berisi elemen.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Membagi koleksi menjadi dua pada indeks yang diberikan.
    ///
    /// Mengembalikan vector yang baru dialokasikan yang berisi elemen dalam rentang `[at, len)`.
    /// Setelah panggilan, vector asli akan dibiarkan berisi elemen `[0, at)` dengan kapasitas sebelumnya tidak berubah.
    ///
    ///
    /// # Panics
    ///
    /// Panics jika `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // vector baru dapat mengambil alih buffer asli dan menghindari penyalinan
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // `set_len` tidak aman dan salin item ke `other`.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// Mengubah ukuran `Vec` di tempat sehingga `len` sama dengan `new_len`.
    ///
    /// Jika `new_len` lebih besar dari `len`, `Vec` diperpanjang selisihnya, dengan setiap slot tambahan diisi dengan hasil panggilan penutupan `f`.
    ///
    /// Nilai yang dikembalikan dari `f` akan berakhir di `Vec` sesuai urutan pembuatannya.
    ///
    /// Jika `new_len` lebih kecil dari `len`, `Vec` akan dipotong begitu saja.
    ///
    /// Metode ini menggunakan closure untuk membuat nilai baru di setiap push.Jika Anda lebih suka [`Clone`] nilai tertentu, gunakan [`Vec::resize`].
    /// Jika Anda ingin menggunakan [`Default`] trait untuk menghasilkan nilai, Anda dapat meneruskan [`Default::default`] sebagai argumen kedua.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// Mengkonsumsi dan membocorkan `Vec`, mengembalikan referensi yang bisa berubah ke konten, `&'a mut [T]`.
    /// Perhatikan bahwa tipe `T` harus hidup lebih lama dari `'a` seumur hidup yang dipilih.
    /// Jika tipe hanya memiliki referensi statis, atau tidak sama sekali, maka ini dapat dipilih menjadi `'static`.
    ///
    /// Fungsi ini mirip dengan fungsi [`leak`][Box::leak] pada [`Box`] kecuali bahwa tidak ada cara untuk memulihkan memori yang bocor.
    ///
    ///
    /// Fungsi ini terutama berguna untuk data yang digunakan selama sisa masa pakai program.
    /// Menghapus referensi yang dikembalikan akan menyebabkan kebocoran memori.
    ///
    /// # Examples
    ///
    /// Penggunaan sederhana:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// Mengembalikan sisa kapasitas cadangan dari vector sebagai bagian dari `MaybeUninit<T>`.
    ///
    /// Irisan yang dikembalikan dapat digunakan untuk mengisi vector dengan data (mis
    /// dengan membaca dari file) sebelum menandai data sebagai diinisialisasi menggunakan metode [`set_len`].
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // Alokasikan vector cukup besar untuk 10 elemen.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // Isi 3 elemen pertama.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // Tandai 3 elemen pertama dari vector sebagai yang sedang diinisialisasi.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // Metode ini tidak diimplementasikan dalam `split_at_spare_mut`, untuk mencegah pembatalan pointer ke buffer.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// Mengembalikan konten vector sebagai bagian dari `T`, bersama dengan kapasitas cadangan yang tersisa dari vector sebagai bagian dari `MaybeUninit<T>`.
    ///
    /// Potongan kapasitas cadangan yang dikembalikan dapat digunakan untuk mengisi vector dengan data (misalnya dengan membaca dari file) sebelum menandai data sebagai yang diinisialisasi menggunakan metode [`set_len`].
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// Perhatikan bahwa ini adalah API tingkat rendah, yang harus digunakan dengan hati-hati untuk tujuan pengoptimalan.
    /// Jika Anda perlu menambahkan data ke `Vec`, Anda dapat menggunakan [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`], atau [`resize_with`], bergantung pada kebutuhan Anda.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // Cadangan ruang tambahan yang cukup besar untuk 10 elemen.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // Isi 4 elemen berikutnya.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // Tandai 4 elemen vector sebagai yang sedang diinisialisasi.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - len diabaikan dan tidak pernah diubah
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// Keamanan: mengubah kembali .2 (&mut usize) dianggap sama dengan memanggil `.set_len(_)`.
    ///
    /// Metode ini digunakan untuk memiliki akses unik ke semua bagian vec sekaligus di `extend_from_within`.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` dijamin valid untuk elemen `len`
        // - `spare_ptr` menunjuk satu elemen melewati buffer, sehingga tidak tumpang tindih dengan `initialized`
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// Mengubah ukuran `Vec` di tempat sehingga `len` sama dengan `new_len`.
    ///
    /// Jika `new_len` lebih besar dari `len`, `Vec` diperpanjang selisihnya, dengan setiap slot tambahan diisi dengan `value`.
    ///
    /// Jika `new_len` lebih kecil dari `len`, `Vec` akan dipotong begitu saja.
    ///
    /// Metode ini membutuhkan `T` untuk mengimplementasikan [`Clone`], agar dapat menggandakan nilai yang diteruskan.
    /// Jika Anda membutuhkan lebih banyak fleksibilitas (atau ingin mengandalkan [`Default`] daripada [`Clone`]), gunakan [`Vec::resize_with`].
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// Mengkloning dan menambahkan semua elemen dalam satu potongan ke `Vec`.
    ///
    /// Iterasi di atas irisan `other`, klon setiap elemen, lalu tambahkan ke `Vec` ini.
    /// `other` vector dilintasi secara berurutan.
    ///
    /// Perhatikan bahwa fungsi ini sama dengan [`extend`] kecuali yang dikhususkan untuk bekerja dengan irisan sebagai gantinya.
    ///
    /// Jika dan saat Rust mendapatkan spesialisasi, fungsi ini kemungkinan besar tidak akan digunakan lagi (tetapi masih tersedia).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// Menyalin elemen dari rentang `src` hingga akhir vector.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` menjamin bahwa kisaran yang diberikan valid untuk mengindeks diri sendiri
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// Kode ini menggeneralisasi `extend_with_{element,default}`.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Perluas nilai vector sebesar `n`, menggunakan generator yang diberikan.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // Gunakan SetLenOnDrop untuk mengatasi bug di mana kompilator mungkin tidak menyadari penyimpanan melalui `ptr` melalui self.set_len() tidak alias.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Tulis semua elemen kecuali yang terakhir
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // Tambah panjang di setiap langkah untuk next() panics
                local_len.increment_len(1);
            }

            if n > 0 {
                // Kita dapat menulis elemen terakhir secara langsung tanpa perlu melakukan kloning
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // len ditetapkan oleh pelindung teropong
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// Menghapus elemen berulang yang berurutan di vector sesuai dengan implementasi [`PartialEq`] trait.
    ///
    ///
    /// Jika vector diurutkan, ini akan menghapus semua duplikat.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Metode dan fungsi internal
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` harus indeks yang valid
    /// - `self.capacity() - self.len()` harus `>= src.len()`
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - len ditingkatkan hanya setelah menginisialisasi elemen
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - pemanggil menjamin bahwa src adalah indeks yang valid
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - Elemen baru saja diinisialisasi dengan `MaybeUninit::write`, jadi tidak masalah untuk meningkatkan len
            // - len dinaikkan setelah setiap elemen untuk mencegah kebocoran (lihat masalah #82533)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - penelepon menjamin bahwa `src` adalah indeks yang valid
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - Kedua pointer dibuat dari referensi slice unik (`&mut [_]`) sehingga valid dan tidak tumpang tindih.
            //
            // - Elemennya adalah: Salin jadi tidak masalah untuk menyalinnya, tanpa melakukan apa pun dengan nilai aslinya
            // - `count` sama dengan len `source`, jadi sumber valid untuk pembacaan `count`
            // - `.reserve(count)` menjamin bahwa `spare.len() >= count` jadi cadangan berlaku untuk menulis `count`
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - Elemen-elemen tersebut baru saja diinisialisasi oleh `copy_nonoverlapping`
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Implementasi trait umum untuk Vec
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): dengan cfg(test) metode `[T]::to_vec` inheren, yang diperlukan untuk definisi metode ini, tidak tersedia.
    // Sebagai gantinya gunakan fungsi `slice::to_vec` yang hanya tersedia dengan cfg(test) NB lihat modul slice::hack di slice.rs untuk informasi lebih lanjut
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // jatuhkan apapun yang tidak akan ditimpa
        self.truncate(other.len());

        // self.len <= other.len karena pemotongan di atas, jadi irisan di sini selalu berada dalam batas.
        //
        let (init, tail) = other.split_at(self.len());

        // menggunakan kembali nilai yang terkandung allocations/resources.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// Membuat iterator yang memakan, yaitu, yang memindahkan setiap nilai dari vector (dari awal hingga akhir).
    /// vector tidak dapat digunakan setelah memanggil ini.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s memiliki tipe String, bukan &String
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // leaf metode yang didelegasikan oleh berbagai implementasi SpecFrom/SpecExtend saat tidak ada pengoptimalan lebih lanjut untuk diterapkan
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // Ini adalah kasus untuk iterator umum.
        //
        // Fungsi ini harus setara dengan moral:
        //
        //      untuk item di iterator {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // NB tidak dapat meluap karena kami harus mengalokasikan ruang alamat
                self.set_len(len + 1);
            }
        }
    }

    /// Membuat iterator penyambungan yang menggantikan rentang yang ditentukan di vector dengan iterator `replace_with` yang diberikan dan menghasilkan item yang dihapus.
    ///
    /// `replace_with` tidak harus sama panjangnya dengan `range`.
    ///
    /// `range` dihapus meskipun iterator tidak dipakai sampai akhir.
    ///
    /// Tidak ditentukan berapa banyak elemen yang dihapus dari vector jika nilai `Splice` bocor.
    ///
    /// Iterator input `replace_with` hanya digunakan saat nilai `Splice` dijatuhkan.
    ///
    /// Ini optimal jika:
    ///
    /// * Ekor (elemen di vector setelah `range`) kosong,
    /// * atau `replace_with` menghasilkan elemen yang lebih sedikit atau sama dari panjang `rentang`
    /// * atau batas bawah `size_hint()`-nya tepat.
    ///
    /// Jika tidak, vector sementara dialokasikan dan ekor dipindahkan dua kali.
    ///
    /// # Panics
    ///
    /// Panics jika titik awal lebih besar dari titik akhir atau jika titik akhir lebih besar dari panjang vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// Membuat iterator yang menggunakan closure untuk menentukan apakah elemen harus dibuang.
    ///
    /// Jika closure mengembalikan nilai true, maka elemen tersebut akan dihapus dan dihasilkan.
    /// Jika closure mengembalikan false, elemen akan tetap berada di vector dan tidak akan dihasilkan oleh iterator.
    ///
    /// Menggunakan metode ini sama dengan kode berikut:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // kode Anda di sini
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// Tapi `drain_filter` lebih mudah digunakan.
    /// `drain_filter` juga lebih efisien, karena dapat menggeser mundur elemen array secara massal.
    ///
    /// Perhatikan bahwa `drain_filter` juga memungkinkan Anda memutasi setiap elemen dalam penutupan filter, terlepas dari apakah Anda memilih untuk menyimpan atau menghapusnya.
    ///
    ///
    /// # Examples
    ///
    /// Membagi array menjadi genap dan ganjil, menggunakan kembali alokasi awal:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Menjaga agar kami tidak bocor (amplifikasi kebocoran)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Perluas implementasi yang menyalin elemen dari referensi sebelum mendorongnya ke Vec.
///
/// Implementasi ini dikhususkan untuk iterator slice, yang menggunakan [`copy_from_slice`] untuk menambahkan seluruh slice sekaligus.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// Menerapkan perbandingan vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// Menerapkan pemesanan vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // gunakan drop untuk [T] gunakan potongan mentah untuk merujuk ke elemen vector sebagai tipe yang diperlukan terlemah;
            //
            // dapat menghindari pertanyaan validitas dalam kasus tertentu
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec menangani deallocation
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// Membuat `Vec<T>` kosong.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: test menarik libstd, yang menyebabkan error di sini
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: test menarik libstd, yang menyebabkan error di sini
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// Mendapatkan seluruh konten `Vec<T>` sebagai larik, jika ukurannya sama persis dengan larik yang diminta.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// Jika panjangnya tidak cocok, masukan kembali dalam `Err`:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// Jika Anda baik-baik saja dengan hanya mendapatkan awalan `Vec<T>`, Anda dapat menghubungi [`.truncate(N)`](Vec::truncate) terlebih dahulu.
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // KEAMANAN: `.set_len(0)` selalu bersuara.
        unsafe { vec.set_len(0) };

        // KEAMANAN: Penunjuk `Vec` selalu sejajar dengan benar, dan
        // keselarasan yang dibutuhkan array sama dengan item.
        // Kami memeriksa sebelumnya bahwa kami memiliki item yang cukup.
        // Item tidak akan jatuh dua kali karena `set_len` memberi tahu `Vec` untuk tidak menjatuhkannya juga.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}