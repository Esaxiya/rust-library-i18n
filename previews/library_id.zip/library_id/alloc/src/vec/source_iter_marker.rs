use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Penanda spesialisasi untuk mengumpulkan pipeline iterator menjadi Vec sambil menggunakan kembali alokasi sumber, mis
/// mengeksekusi pipeline di tempatnya.
///
/// Induk SourceIter trait diperlukan untuk fungsi yang mengkhususkan untuk mengakses alokasi yang akan digunakan kembali.
/// Tetapi itu tidak cukup agar spesialisasi menjadi valid.
/// Lihat batasan tambahan pada impl.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// std-internal SourceIter/InPlaceIterable traits hanya diimplementasikan dengan rangkaian Adaptor <Adapter<Adapter<IntoIter>>> (semua dimiliki oleh core/std).
// Batasan tambahan pada implementasi adaptor (di luar `impl<I: Trait> Trait for Adapter<I>`) hanya bergantung pada traits lain yang telah ditandai sebagai spesialisasi traits (Salin, TrustedRandomAccess, FusedIterator).
//
// I.e. marker tidak bergantung pada masa pakai jenis yang disediakan pengguna.Modulo the Copy hole, yang bergantung pada beberapa spesialisasi lainnya.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Persyaratan tambahan yang tidak dapat diungkapkan melalui trait bounds.Kami mengandalkan const eval sebagai gantinya:
        // a) tidak ada ZST karena tidak akan ada alokasi untuk digunakan kembali dan aritmatika pointer akan panic b) ukuran cocok seperti yang disyaratkan oleh kontrak Alloc c) keselarasan sesuai seperti yang dipersyaratkan oleh kontrak Alloc
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // fallback ke implementasi yang lebih umum
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // gunakan coba lipat sejak
        // - itu melakukan vektorisasi lebih baik untuk beberapa adaptor iterator
        // - tidak seperti kebanyakan metode iterasi internal, ini hanya membutuhkan &mut sendiri
        // - itu memungkinkan kita memasukkan penunjuk tulis melalui bagian dalam dan mendapatkannya kembali pada akhirnya
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // iterasi berhasil, jangan putus asa
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // periksa apakah kontrak SourceIter ditegakkan peringatan: jika tidak, kami bahkan mungkin tidak mencapai titik ini
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // centang kontrak InPlaceIterable.Ini hanya mungkin jika iterator memajukan penunjuk sumber sama sekali.
        // Jika menggunakan akses yang tidak dicentang melalui TrustedRandomAccess maka penunjuk sumber akan tetap di posisi awalnya dan kami tidak dapat menggunakannya sebagai referensi
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // jatuhkan nilai yang tersisa di bagian belakang sumber tetapi cegah penurunan alokasi itu sendiri setelah IntoIter keluar dari ruang lingkup jika menjatuhkan panics maka kami juga membocorkan elemen apa pun yang dikumpulkan ke dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // kontrak InPlaceIterable tidak dapat diverifikasi secara tepat di sini karena try_fold memiliki referensi eksklusif ke penunjuk sumber yang dapat kita lakukan adalah memeriksa apakah masih dalam jangkauan
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}