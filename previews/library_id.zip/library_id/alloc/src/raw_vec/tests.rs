use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // Menulis pengujian integrasi antara pengalokasi pihak ketiga dan `RawVec` sedikit rumit karena `RawVec` API tidak mengekspos metode alokasi yang salah, jadi kami tidak dapat memeriksa apa yang terjadi ketika pengalokasi habis (selain mendeteksi panic).
    //
    //
    // Sebagai gantinya, ini hanya memeriksa bahwa metode `RawVec` setidaknya melalui Allocator API saat menyimpan penyimpanan.
    //
    //
    //
    //
    //

    // Pengalokasi bodoh yang mengonsumsi bahan bakar dalam jumlah tetap sebelum upaya alokasi mulai gagal.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (menyebabkan realokasi, sehingga menggunakan 50 + 150=200 unit bahan bakar)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // Pertama, `reserve` mengalokasikan seperti `reserve_exact`.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 lebih dari dua kali lipat dari 7, jadi `reserve` seharusnya bekerja seperti `reserve_exact`.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 kurang dari setengah dari 12, jadi `reserve` harus tumbuh secara eksponensial.
        // Pada saat penulisan pengujian ini faktor pertumbuhan adalah 2, jadi kapasitas baru adalah 24, namun faktor pertumbuhan 1.5 juga OK.
        //
        // Makanya `>= 18` di tegaskan.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}