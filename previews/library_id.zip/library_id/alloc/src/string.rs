//! String berenkode UTF-8 yang dapat dikembangkan.
//!
//! Modul ini berisi tipe [`String`], [`ToString`] trait untuk mengkonversi ke string, dan beberapa tipe kesalahan yang mungkin terjadi karena bekerja dengan [`String`] s.
//!
//!
//! # Examples
//!
//! Ada beberapa cara untuk membuat [`String`] baru dari string literal:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! Anda dapat membuat [`String`] baru dari yang sudah ada dengan menggabungkan dengan
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! Jika Anda memiliki vector dengan UTF-8 byte yang valid, Anda dapat membuat [`String`] darinya.Anda juga bisa melakukan kebalikannya.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // Kami tahu byte ini valid, jadi kami akan menggunakan `unwrap()`.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// String berenkode UTF-8 yang dapat dikembangkan.
///
/// Jenis `String` adalah jenis string paling umum yang memiliki kepemilikan atas konten string.Ini memiliki hubungan dekat dengan mitra pinjamannya, [`str`] primitif.
///
/// # Examples
///
/// Anda dapat membuat `String` dari [a literal string][`str`] dengan [`String::from`]:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// Anda dapat menambahkan [`char`] ke `String` dengan metode [`push`], dan menambahkan [`&str`] dengan metode [`push_str`]:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// Jika Anda memiliki vector dari UTF-8 byte, Anda dapat membuat `String` darinya dengan metode [`from_utf8`]:
///
/// ```
/// // beberapa byte, dalam vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Kami tahu byte ini valid, jadi kami akan menggunakan `unwrap()`.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// `String` selalu UTF-8 valid.Ini memiliki beberapa implikasi, yang pertama adalah jika Anda memerlukan string non-UTF-8, pertimbangkan [`OsString`].Ini serupa, tetapi tanpa kendala UTF-8.Implikasi kedua adalah Anda tidak dapat mengindeks ke `String`:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// Pengindeksan dimaksudkan sebagai operasi waktu-konstan, tetapi pengkodean UTF-8 tidak memungkinkan kita melakukan ini.Selain itu, tidak jelas hal seperti apa yang harus dikembalikan oleh indeks: byte, titik kode, atau cluster grafeme.
/// Metode [`bytes`] dan [`chars`] masing-masing mengembalikan iterator pada dua metode pertama.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// `String` mengimplementasikan [`Deref`] `<Target=str>`, dan karenanya mewarisi semua metode [`str`].Selain itu, ini berarti Anda dapat meneruskan `String` ke fungsi yang menggunakan [`&str`] dengan menggunakan ampersand (`&`):
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// Ini akan membuat [`&str`] dari `String` dan meneruskannya. Konversi ini sangat murah, dan secara umum, fungsi akan menerima [`&str`] sebagai argumen kecuali mereka memerlukan `String` karena alasan tertentu.
///
/// Dalam kasus tertentu Rust tidak memiliki cukup informasi untuk melakukan konversi ini, yang dikenal sebagai pemaksaan [`Deref`].Dalam contoh berikut, potongan string [`&'a str`][`&str`] mengimplementasikan trait `TraitExample`, dan fungsi `example_func` mengambil apa pun yang mengimplementasikan trait.
/// Dalam hal ini Rust perlu membuat dua konversi implisit, yang tidak dapat dilakukan oleh Rust.
/// Oleh karena itu, contoh berikut tidak dapat dikompilasi.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// Ada dua opsi yang bisa digunakan.Yang pertama adalah mengubah baris `example_func(&example_string);` menjadi `example_func(example_string.as_str());`, menggunakan metode [`as_str()`] untuk secara eksplisit mengekstrak potongan string yang berisi string tersebut.
/// Cara kedua mengubah `example_func(&example_string);` menjadi `example_func(&*example_string);`.
/// Dalam hal ini kami mendereferensi `String` ke [`str`][`&str`], kemudian mereferensikan [`str`][`&str`] kembali ke [`&str`].
/// Cara kedua lebih idiomatis, namun keduanya bekerja untuk melakukan konversi secara eksplisit daripada mengandalkan konversi implisit.
///
/// # Representation
///
/// `String` terdiri dari tiga komponen: penunjuk ke beberapa byte, panjang, dan kapasitas.Pointer menunjuk ke buffer internal yang digunakan `String` untuk menyimpan datanya.Panjangnya adalah jumlah byte yang saat ini disimpan dalam buffer, dan kapasitasnya adalah ukuran buffer dalam byte.
///
/// Dengan demikian, panjangnya akan selalu kurang dari atau sama dengan kapasitasnya.
///
/// Buffer ini selalu disimpan di heap.
///
/// Anda dapat melihat ini dengan metode [`as_ptr`], [`len`], dan [`capacity`]:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME Perbarui ini ketika vec_into_raw_parts distabilkan.
/// // Cegah menjatuhkan data String secara otomatis
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // cerita memiliki sembilan belas byte
/// assert_eq!(19, len);
///
/// // Kita bisa membangun kembali String dari ptr, len, dan capacity.
/// // Ini semua tidak aman karena kami bertanggung jawab untuk memastikan komponen valid:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// Jika `String` memiliki kapasitas yang cukup, menambahkan elemen ke dalamnya tidak akan dialokasikan kembali.Misalnya, pertimbangkan program ini:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// Ini akan menghasilkan yang berikut:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// Pada awalnya, kami tidak memiliki memori yang dialokasikan sama sekali, tetapi saat kami menambahkan string, itu meningkatkan kapasitasnya dengan tepat.Jika kita menggunakan metode [`with_capacity`] untuk mengalokasikan kapasitas yang benar pada awalnya:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// Kami berakhir dengan hasil yang berbeda:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// Di sini, tidak perlu mengalokasikan lebih banyak memori di dalam loop.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// Nilai kesalahan yang mungkin terjadi saat mengonversi `String` dari UTF-8 byte vector.
///
/// Jenis ini adalah jenis kesalahan untuk metode [`from_utf8`] di [`String`].
/// Ini dirancang sedemikian rupa untuk menghindari realokasi dengan hati-hati: metode [`into_bytes`] akan mengembalikan byte vector yang digunakan dalam upaya konversi.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// Jenis [`Utf8Error`] yang disediakan oleh [`std::str`] menunjukkan kesalahan yang mungkin terjadi saat mengonversi potongan [`u8`] s ke [`&str`].
/// Dalam hal ini, ini analog dengan `FromUtf8Error`, dan Anda bisa mendapatkannya dari `FromUtf8Error` melalui metode [`utf8_error`].
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// Penggunaan dasar:
///
/// ```
/// // beberapa byte tidak valid, di vector
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// Nilai kesalahan yang mungkin terjadi saat mengonversi `String` dari potongan byte UTF-16.
///
/// Jenis ini adalah jenis kesalahan untuk metode [`from_utf16`] di [`String`].
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// Penggunaan dasar:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// Membuat `String` kosong baru.
    ///
    /// Mengingat `String` kosong, ini tidak akan mengalokasikan buffer awal apa pun.Meskipun itu berarti bahwa operasi awal ini sangat murah, namun dapat menyebabkan alokasi yang berlebihan di kemudian hari saat Anda menambahkan data.
    ///
    /// Jika Anda memiliki gambaran tentang berapa banyak data yang akan disimpan `String`, pertimbangkan metode [`with_capacity`] untuk mencegah alokasi ulang yang berlebihan.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// Membuat `String` kosong baru dengan kapasitas tertentu.
    ///
    /// `String` memiliki buffer internal untuk menyimpan datanya.
    /// Kapasitas adalah panjang buffer tersebut, dan dapat ditanyai dengan metode [`capacity`].
    /// Metode ini membuat `String` kosong, tetapi dengan buffer awal yang dapat menampung `capacity` byte.
    /// Ini berguna ketika Anda mungkin menambahkan banyak data ke `String`, mengurangi jumlah realokasi yang perlu dilakukan.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// Jika kapasitas yang diberikan adalah `0`, tidak akan ada alokasi yang terjadi, dan metode ini identik dengan metode [`new`].
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // String tidak berisi karakter, meskipun memiliki kapasitas lebih
    /// assert_eq!(s.len(), 0);
    ///
    /// // Ini semua dilakukan tanpa mengalokasikan kembali ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... tapi ini dapat membuat string dialokasikan kembali
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): dengan cfg(test) metode `[T]::to_vec` inheren, yang diperlukan untuk definisi metode ini, tidak tersedia.
    // Karena kami tidak memerlukan metode ini untuk tujuan pengujian, saya hanya akan menghentikannya NB melihat modul slice::hack di slice.rs untuk informasi lebih lanjut
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// Mengonversi vector byte menjadi `String`.
    ///
    /// String ([`String`]) terbuat dari byte ([`u8`]), dan vector byte ([`Vec<u8>`]) terbuat dari byte, jadi fungsi ini mengkonversi di antara keduanya.
    /// Tidak semua potongan byte adalah `String` yang valid, namun: `String` mensyaratkan bahwa itu adalah UTF-8 yang valid.
    /// `from_utf8()` memeriksa untuk memastikan bahwa byte UTF-8 valid, dan kemudian melakukan konversi.
    ///
    /// Jika Anda yakin bahwa potongan byte adalah UTF-8 yang valid, dan Anda tidak ingin mengeluarkan biaya tambahan dari pemeriksaan validitas, ada versi tidak aman dari fungsi ini, [`from_utf8_unchecked`], yang memiliki perilaku yang sama tetapi melewati pemeriksaan.
    ///
    ///
    /// Metode ini akan berhati-hati untuk tidak menyalin vector, demi efisiensi.
    ///
    /// Jika Anda membutuhkan [`&str`] dan bukan `String`, pertimbangkan [`str::from_utf8`].
    ///
    /// Kebalikan dari metode ini adalah [`into_bytes`].
    ///
    /// # Errors
    ///
    /// Mengembalikan [`Err`] jika potongannya bukan UTF-8 dengan deskripsi mengapa byte yang diberikan bukan UTF-8.vector tempat Anda pindah juga disertakan.
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// // beberapa byte, dalam vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // Kami tahu byte ini valid, jadi kami akan menggunakan `unwrap()`.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Byte salah:
    ///
    /// ```
    /// // beberapa byte tidak valid, di vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// Lihat dokumen untuk [`FromUtf8Error`] untuk detail lebih lanjut tentang apa yang dapat Anda lakukan dengan kesalahan ini.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// Mengonversi potongan byte menjadi string, termasuk karakter yang tidak valid.
    ///
    /// String terbuat dari byte ([`u8`]), dan sepotong byte ([`&[u8]`][byteslice]) terbuat dari byte, jadi fungsi ini mengkonversi di antara keduanya.Tidak semua potongan byte adalah string yang valid, namun: string harus berupa UTF-8 yang valid.
    /// Selama konversi ini, `from_utf8_lossy()` akan mengganti urutan UTF-8 yang tidak valid dengan [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD], yang terlihat seperti ini:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// Jika Anda yakin bahwa potongan byte adalah UTF-8 yang valid, dan Anda tidak ingin menimbulkan overhead konversi, ada versi tidak aman dari fungsi ini, [`from_utf8_unchecked`], yang memiliki perilaku yang sama tetapi melewatkan pemeriksaan.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// Fungsi ini mengembalikan [`Cow<'a, str>`].Jika potongan byte kita UTF-8 tidak valid, maka kita perlu memasukkan karakter pengganti, yang akan mengubah ukuran string, dan karenanya, membutuhkan `String`.
    /// Tapi kalau UTF-8 sudah valid, kita tidak butuh alokasi baru.
    /// Jenis pengembalian ini memungkinkan kita menangani kedua kasus.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// // beberapa byte, dalam vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Byte salah:
    ///
    /// ```
    /// // beberapa byte tidak valid
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// Dekode vector `v` berenkode UTF-16 menjadi `String`, menampilkan [`Err`] jika `v` berisi data yang tidak valid.
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // Ini tidak dilakukan melalui collect: : <Result<_, _>> () untuk alasan performa.
        // FIXME: fungsinya bisa disederhanakan lagi saat #48994 ditutup.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// Dekode potongan `v` berenkode UTF-16 menjadi `String`, menggantikan data yang tidak valid dengan [the replacement character (`U+FFFD`)][U+FFFD].
    ///
    /// Tidak seperti [`from_utf8_lossy`] yang mengembalikan [`Cow<'a, str>`], `from_utf16_lossy` mengembalikan `String` karena konversi UTF-16 ke UTF-8 memerlukan alokasi memori.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// Menguraikan `String` menjadi komponen mentahnya.
    ///
    /// Mengembalikan pointer mentah ke data pokok, panjang string (dalam byte), dan kapasitas data yang dialokasikan (dalam byte).
    /// Ini adalah argumen yang sama dalam urutan yang sama dengan argumen ke [`from_raw_parts`].
    ///
    /// Setelah memanggil fungsi ini, pemanggil bertanggung jawab atas memori yang sebelumnya dikelola oleh `String`.
    /// Satu-satunya cara untuk melakukan ini adalah dengan mengubah penunjuk mentah, panjang, dan kapasitas kembali menjadi `String` dengan fungsi [`from_raw_parts`], yang memungkinkan destruktor untuk melakukan pembersihan.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// Membuat `String` baru dari panjang, kapasitas, dan penunjuk.
    ///
    /// # Safety
    ///
    /// Ini sangat tidak aman, karena jumlah invarian yang tidak diperiksa:
    ///
    /// * Memori di `buf` sebelumnya harus telah dialokasikan oleh pengalokasi yang sama yang digunakan perpustakaan standar, dengan penyelarasan yang diperlukan tepat 1.
    /// * `length` harus kurang dari atau sama dengan `capacity`.
    /// * `capacity` harus memiliki nilai yang benar.
    /// * Byte `length` pertama di `buf` harus UTF-8 yang valid.
    ///
    /// Melanggar ini dapat menyebabkan masalah seperti merusak struktur data internal pengalokasi.
    ///
    /// Kepemilikan `buf` secara efektif ditransfer ke `String` yang kemudian dapat membatalkan alokasi, mengalokasikan kembali atau mengubah konten memori yang ditunjukkan oleh penunjuk sesuka hati.
    /// Pastikan tidak ada orang lain yang menggunakan penunjuk setelah memanggil fungsi ini.
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME Perbarui ini ketika vec_into_raw_parts distabilkan.
    ///     // Cegah menjatuhkan data String secara otomatis
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// Mengonversi vector byte ke `String` tanpa memeriksa bahwa string berisi UTF-8 yang valid.
    ///
    /// Lihat versi aman, [`from_utf8`], untuk lebih jelasnya.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// Fungsi ini tidak aman karena tidak memeriksa bahwa byte yang diteruskan ke sana adalah UTF-8 yang valid.
    /// Jika batasan ini dilanggar, ini dapat menyebabkan masalah ketidakamanan memori dengan pengguna future dari `String`, karena pustaka standar lainnya mengasumsikan bahwa `String` adalah UTF-8 yang valid.
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// // beberapa byte, dalam vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// Mengonversi `String` menjadi vector byte.
    ///
    /// Ini menghabiskan `String`, jadi kami tidak perlu menyalin isinya.
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// Mengekstrak potongan string yang berisi seluruh `String`.
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// Mengonversi `String` menjadi potongan string yang bisa diubah.
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// Menambahkan potongan string tertentu ke akhir `String` ini.
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// Mengembalikan kapasitas `String` ini, dalam byte.
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// Pastikan bahwa kapasitas `String` ini setidaknya `additional` byte lebih besar dari panjangnya.
    ///
    /// Kapasitas dapat ditingkatkan lebih dari `additional` byte jika diinginkan, untuk mencegah realokasi yang sering.
    ///
    ///
    /// Jika Anda tidak menginginkan perilaku "at least" ini, lihat metode [`reserve_exact`].
    ///
    /// # Panics
    ///
    /// Panics jika kapasitas baru melebihi [`usize`].
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Ini mungkin tidak benar-benar meningkatkan kapasitas:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s sekarang memiliki panjang 2 dan kapasitas 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Karena kami sudah memiliki 8 kapasitas ekstra, memanggil ini ...
    /// s.reserve(8);
    ///
    /// // ... sebenarnya tidak meningkat.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// Pastikan bahwa kapasitas `String` ini `additional` byte lebih besar dari panjangnya.
    ///
    /// Pertimbangkan untuk menggunakan metode [`reserve`] kecuali Anda benar-benar tahu lebih baik daripada pengalokasi.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics jika kapasitas baru melebihi `usize`.
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Ini mungkin tidak benar-benar meningkatkan kapasitas:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s sekarang memiliki panjang 2 dan kapasitas 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Karena kami sudah memiliki 8 kapasitas ekstra, memanggil ini ...
    /// s.reserve_exact(8);
    ///
    /// // ... sebenarnya tidak meningkat.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// Mencoba mencadangkan kapasitas untuk setidaknya `additional` lebih banyak elemen untuk dimasukkan ke dalam `String` yang diberikan.
    /// Koleksi mungkin memiliki lebih banyak ruang untuk menghindari realokasi yang sering.
    /// Setelah memanggil `reserve`, kapasitas akan lebih besar dari atau sama dengan `self.len() + additional`.
    /// Tidak melakukan apa-apa jika kapasitas sudah mencukupi.
    ///
    /// # Errors
    ///
    /// Jika kapasitas meluap, atau pengalokasi melaporkan kegagalan, maka kesalahan dikembalikan.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Pra-pesan memori, keluar jika kita tidak bisa
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Sekarang kami tahu ini tidak bisa OOM di tengah pekerjaan kompleks kami
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// Mencoba mencadangkan kapasitas minimum untuk tepat `additional` lebih banyak elemen yang akan dimasukkan ke dalam `String` yang diberikan.
    ///
    /// Setelah memanggil `reserve_exact`, kapasitas akan lebih besar dari atau sama dengan `self.len() + additional`.
    /// Tidak melakukan apa-apa jika kapasitasnya sudah mencukupi.
    ///
    /// Perhatikan bahwa pengalokasi mungkin memberi koleksi lebih banyak ruang daripada yang diminta.
    /// Oleh karena itu, kapasitas tidak bisa diandalkan untuk menjadi sangat minim.
    /// Pilih `reserve` jika penyisipan future diharapkan.
    ///
    /// # Errors
    ///
    /// Jika kapasitas meluap, atau pengalokasi melaporkan kegagalan, maka kesalahan dikembalikan.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Pra-pesan memori, keluar jika kita tidak bisa
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Sekarang kami tahu ini tidak bisa OOM di tengah pekerjaan kompleks kami
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// Kecilkan kapasitas `String` ini agar sesuai dengan panjangnya.
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// Mengecilkan kapasitas `String` ini dengan batas bawah.
    ///
    /// Kapasitas akan tetap setidaknya sebesar panjang dan nilai yang diberikan.
    ///
    ///
    /// Jika kapasitas saat ini kurang dari batas bawah, ini adalah no-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// Menambahkan [`char`] yang diberikan ke akhir `String` ini.
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// Mengembalikan potongan byte dari konten `String` ini.
    ///
    /// Kebalikan dari metode ini adalah [`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// Persingkat `String` ini dengan panjang yang ditentukan.
    ///
    /// Jika `new_len` lebih besar dari panjang string saat ini, ini tidak berpengaruh.
    ///
    ///
    /// Perhatikan bahwa metode ini tidak berpengaruh pada kapasitas yang dialokasikan dari string
    ///
    /// # Panics
    ///
    /// Panics jika `new_len` tidak terletak pada batas [`char`].
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// Menghapus karakter terakhir dari buffer string dan mengembalikannya.
    ///
    /// Mengembalikan [`None`] jika `String` ini kosong.
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// Menghapus [`char`] dari `String` ini pada posisi byte dan mengembalikannya.
    ///
    /// Ini adalah operasi *O*(*n*), karena memerlukan penyalinan setiap elemen dalam buffer.
    ///
    /// # Panics
    ///
    /// Panics jika `idx` lebih besar dari atau sama dengan panjang `String`, atau jika tidak terletak pada batas [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// Hapus semua kecocokan pola `pat` di `String`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// Kecocokan akan dideteksi dan dihapus secara berulang, jadi jika pola tumpang tindih, hanya pola pertama yang akan dihapus:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // KEAMANAN: awal dan akhir akan berada pada batas utf8 byte per
        // dokumen Penelusur
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// Mempertahankan hanya karakter yang ditentukan oleh predikat.
    ///
    /// Dengan kata lain, hapus semua karakter `c` sehingga `f(c)` mengembalikan `false`.
    /// Metode ini beroperasi di tempat, mengunjungi setiap karakter tepat satu kali dalam urutan aslinya, dan mempertahankan urutan karakter yang dipertahankan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// Urutan persisnya mungkin berguna untuk melacak status eksternal, seperti indeks.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // Arahkan idx ke karakter berikutnya
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// Menyisipkan karakter ke `String` ini pada posisi byte.
    ///
    /// Ini adalah operasi *O*(*n*) karena memerlukan penyalinan setiap elemen dalam buffer.
    ///
    /// # Panics
    ///
    /// Panics jika `idx` lebih besar dari panjang `String`, atau jika tidak terletak pada batas [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// Menyisipkan potongan string ke `String` ini pada posisi byte.
    ///
    /// Ini adalah operasi *O*(*n*) karena memerlukan penyalinan setiap elemen dalam buffer.
    ///
    /// # Panics
    ///
    /// Panics jika `idx` lebih besar dari panjang `String`, atau jika tidak terletak pada batas [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// Mengembalikan referensi yang bisa berubah ke konten `String` ini.
    ///
    /// # Safety
    ///
    /// Fungsi ini tidak aman karena tidak memeriksa bahwa byte yang diteruskan ke sana adalah UTF-8 yang valid.
    /// Jika batasan ini dilanggar, ini dapat menyebabkan masalah ketidakamanan memori dengan pengguna future dari `String`, karena pustaka standar lainnya mengasumsikan bahwa `String` adalah UTF-8 yang valid.
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// Menampilkan panjang `String` ini, dalam byte, bukan [`char`] atau graphemes.
    /// Dengan kata lain, ini mungkin bukan yang dianggap manusia sebagai panjang benang.
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// Mengembalikan `true` jika `String` ini memiliki panjang nol, dan `false` sebaliknya.
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Membagi string menjadi dua pada indeks byte yang diberikan.
    ///
    /// Mengembalikan `String` yang baru dialokasikan.
    /// `self` berisi byte `[0, at)`, dan `String` yang dikembalikan berisi byte `[at, len)`.
    /// `at` harus berada di batas titik kode UTF-8.
    ///
    /// Perhatikan bahwa kapasitas `self` tidak berubah.
    ///
    /// # Panics
    ///
    /// Panics jika `at` tidak berada pada batas titik kode `UTF-8`, atau jika berada di luar titik kode terakhir dari string tersebut.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// Memotong `String` ini, menghapus semua konten.
    ///
    /// Meskipun ini berarti `String` akan memiliki panjang nol, namun tidak menyentuh kapasitasnya.
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// Membuat iterator pengurasan yang menghapus rentang yang ditentukan di `String` dan menghasilkan `chars` yang dihapus.
    ///
    ///
    /// Note: Rentang elemen dihapus meskipun iterator tidak dipakai sampai akhir.
    ///
    /// # Panics
    ///
    /// Panics jika titik awal atau titik akhir tidak terletak di batas [`char`], atau jika di luar batas.
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Hapus rentang sampai β dari string
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // Sebuah jangkauan penuh membersihkan string
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // Keamanan memori
        //
        // Versi String Drain tidak memiliki masalah keamanan memori seperti versi vector.
        // Datanya hanya berupa byte biasa.
        // Karena penghapusan rentang terjadi di Drop, jika iterator Drain bocor, penghapusan tidak akan terjadi.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // Ambil dua pinjaman simultan.
        // String &mut tidak akan diakses sampai iterasi selesai, di Drop.
        let self_ptr = self as *mut _;
        // KEAMANAN: `slice::range` dan `is_char_boundary` melakukan pemeriksaan batas yang sesuai.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// Menghapus rentang yang ditentukan dalam string, dan menggantinya dengan string yang diberikan.
    /// Panjang string yang diberikan tidak harus sama dengan rentangnya.
    ///
    /// # Panics
    ///
    /// Panics jika titik awal atau titik akhir tidak terletak di batas [`char`], atau jika di luar batas.
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Ganti range sampai β dari string
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // Keamanan memori
        //
        // Replace_range tidak memiliki masalah keamanan memori dari vector Splice.
        // dari versi vector.Datanya hanya berupa byte biasa.

        // PERINGATAN: Sebaris variabel ini akan menjadi (#81138) tidak sehat
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // PERINGATAN: Sebaris variabel ini akan menjadi (#81138) tidak sehat
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // Menggunakan `range` lagi akan menjadi tidak masuk akal (#81138) Kami menganggap batasan yang dilaporkan oleh `range` tetap sama, tetapi implementasi permusuhan dapat berubah antar panggilan
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// Mengubah `String` ini menjadi [`Box`]`<`[`str`] `>`.
    ///
    /// Ini akan menurunkan kapasitas berlebih.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// Menampilkan potongan [`u8`] s byte yang dicoba untuk diubah menjadi `String`.
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// // beberapa byte tidak valid, di vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// Mengembalikan byte yang dicoba untuk diubah menjadi `String`.
    ///
    /// Metode ini dibangun dengan hati-hati untuk menghindari alokasi.
    /// Ini akan memakan kesalahan, memindahkan byte, sehingga salinan byte tidak perlu dibuat.
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// // beberapa byte tidak valid, di vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// Ambil `Utf8Error` untuk mendapatkan detail selengkapnya tentang kegagalan konversi.
    ///
    /// Jenis [`Utf8Error`] yang disediakan oleh [`std::str`] menunjukkan kesalahan yang mungkin terjadi saat mengonversi potongan [`u8`] s ke [`&str`].
    /// Dalam hal ini, ini analog dengan `FromUtf8Error`.
    /// Lihat dokumentasinya untuk detail lebih lanjut tentang menggunakannya.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// // beberapa byte tidak valid, di vector
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // byte pertama tidak valid di sini
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Karena kita melakukan iterasi pada `String`, kita dapat menghindari setidaknya satu alokasi dengan mendapatkan string pertama dari iterator dan menambahkannya ke semua string berikutnya.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Karena kita mengulangi Kontrak Karya, kita dapat (potentially) menghindari setidaknya satu alokasi dengan mendapatkan item pertama dan menambahkan semua item berikutnya ke dalamnya.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// Kenyamanan impl yang didelegasikan ke impl untuk `&str`.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// Membuat `String` kosong.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// Menerapkan operator `+` untuk menggabungkan dua string.
///
/// Ini menghabiskan `String` di sisi kiri dan menggunakan kembali buffernya (menumbuhkannya jika perlu).
/// Ini dilakukan untuk menghindari mengalokasikan `String` baru dan menyalin seluruh konten pada setiap operasi, yang akan menyebabkan waktu berjalan *O*(*n*^ 2) saat membangun string *n*-byte dengan penggabungan berulang.
///
///
/// Tali di sisi kanan hanya dipinjam;isinya disalin ke dalam `String` yang dikembalikan.
///
/// # Examples
///
/// Menggabungkan dua `String` membutuhkan nilai pertama dan meminjam yang kedua:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` dipindahkan dan tidak dapat digunakan lagi di sini.
/// ```
///
/// Jika Anda ingin tetap menggunakan `String` pertama, Anda dapat mengkloningnya dan menambahkannya ke klon:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` masih berlaku disini.
/// ```
///
/// Penggabungan irisan `&str` dapat dilakukan dengan mengubah yang pertama menjadi `String`:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// Menerapkan operator `+=` untuk menambahkan ke `String`.
///
/// Ini memiliki perilaku yang sama dengan metode [`push_str`][String::push_str].
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// Alias tipe untuk [`Infallible`].
///
/// Alias ini ada untuk kompatibilitas mundur, dan mungkin pada akhirnya tidak digunakan lagi.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// A trait untuk mengonversi nilai menjadi `String`.
///
/// trait ini secara otomatis diimplementasikan untuk semua jenis yang mengimplementasikan [`Display`] trait.
/// Karena itu, `ToString` tidak boleh diterapkan secara langsung:
/// [`Display`] harus diterapkan sebagai gantinya, dan Anda mendapatkan implementasi `ToString` secara gratis.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// Mengonversi nilai yang diberikan menjadi `String`.
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// Dalam implementasi ini, metode `to_string` panics jika implementasi `Display` menghasilkan kesalahan.
/// Ini menunjukkan implementasi `Display` yang salah karena `fmt::Write for String` tidak pernah mengembalikan kesalahan itu sendiri.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // Pedoman umum adalah untuk tidak menyebariskan fungsi generik.
    // Namun, menghapus `#[inline]` dari metode ini menyebabkan regresi yang tidak dapat diabaikan.
    // Lihat <https://github.com/rust-lang/rust/pull/74852>, upaya terakhir untuk mencoba menghapusnya.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// Mengubah `&mut str` menjadi `String`.
    ///
    /// Hasilnya dialokasikan di heap.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: test menarik libstd, yang menyebabkan error di sini
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// Mengonversi potongan `str` kotak yang diberikan menjadi `String`.
    /// Patut dicatat bahwa irisan `str` dimiliki.
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// Mengonversi `String` yang diberikan menjadi potongan `str` yang dimiliki.
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// Mengonversi potongan string menjadi varian yang Dipinjam.
    /// Tidak ada alokasi heap yang dilakukan, dan string tidak disalin.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// Mengonversi String menjadi varian Milik.
    /// Tidak ada alokasi heap yang dilakukan, dan string tidak disalin.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// Mengonversi referensi String menjadi varian yang Dipinjam.
    /// Tidak ada alokasi heap yang dilakukan, dan string tidak disalin.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// Mengonversi `String` yang diberikan ke vector `Vec` yang menyimpan nilai tipe `u8`.
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// Sebuah iterator penguras untuk `String`.
///
/// Struct ini dibuat dengan metode [`drain`] di [`String`].
/// Lihat dokumentasinya untuk lebih lanjut.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// Akan digunakan sebagai&'a mut String di destruktor
    string: *mut String,
    /// Mulai dari bagian untuk menghapus
    start: usize,
    /// Akhir bagian untuk dihapus
    end: usize,
    /// Rentang tersisa saat ini untuk dihapus
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Gunakan Vec::drain.
            // "Reaffirm" cek batas untuk menghindari kode panic dimasukkan lagi.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// Mengembalikan sisa (sub) string dari iterator ini sebagai potongan.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: hapus komentar AsRef menyiratkan di bawah ini saat menstabilkan.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// Batalkan komentar saat menstabilkan `string_drain_as_str`.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>untuk Drain <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> untuk Drain <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}