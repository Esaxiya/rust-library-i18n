#![stable(feature = "wake_trait", since = "1.51.0")]
//! Jenis dan Traits untuk bekerja dengan tugas asinkron.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Pelaksanaan membangunkan tugas pada pelaksana.
///
/// trait ini dapat digunakan untuk membuat [`Waker`].
/// Eksekutor dapat menentukan implementasi trait ini, dan menggunakannya untuk membangun Waker untuk meneruskan tugas yang dijalankan pada eksekutor tersebut.
///
/// trait ini adalah alternatif yang aman dari memori dan ergonomis untuk membuat [`RawWaker`].
/// Ini mendukung desain pelaksana umum di mana data yang digunakan untuk membangunkan tugas disimpan dalam [`Arc`].
/// Beberapa pelaksana (terutama yang untuk sistem tertanam) tidak dapat menggunakan API ini, itulah sebabnya [`RawWaker`] ada sebagai alternatif untuk sistem tersebut.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Fungsi dasar `block_on` yang mengambil future dan menjalankannya hingga selesai pada thread saat ini.
///
/// **Note:** Contoh ini memperdagangkan kebenaran untuk kesederhanaan.
/// Untuk mencegah kebuntuan, implementasi tingkat produksi juga perlu menangani panggilan perantara ke `thread::unpark` serta pemanggilan bertingkat.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Seorang waker yang mengaktifkan utas saat ini saat dipanggil.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Jalankan future hingga selesai di utas saat ini.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Sematkan future agar dapat disurvei.
///     let mut fut = Box::pin(fut);
///
///     // Buat konteks baru untuk diteruskan ke future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Jalankan future sampai selesai.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Bangunkan tugas ini.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Bangunkan tugas ini tanpa menghabiskan waker.
    ///
    /// Jika pelaksana mendukung cara yang lebih murah untuk membangunkan tanpa menghabiskan waker, metode ini harus diganti.
    /// Secara default, itu mengkloning [`Arc`] dan memanggil [`wake`] pada klon tersebut.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // KEAMANAN: Ini aman karena raw_waker dibangun dengan aman
        // seorang RawWaker dari Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Fungsi pribadi untuk membangun RawWaker ini digunakan, bukan
// memasukkan ini ke dalam impl `From<Arc<W>> for RawWaker`, untuk memastikan bahwa keamanan `From<Arc<W>> for Waker` tidak bergantung pada pengiriman trait yang benar, sebaliknya keduanya menyiratkan panggilan fungsi ini secara langsung dan eksplisit.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Tingkatkan jumlah referensi busur untuk mengkloningnya.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Bangun berdasarkan nilai, pindahkan Arc ke fungsi Wake::wake
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Bangun dengan referensi, bungkus waker dengan ManuallyDrop agar tidak menjatuhkannya
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Kurangi jumlah referensi Arc saat jatuh
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}