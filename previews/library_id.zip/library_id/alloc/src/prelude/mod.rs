//! Alokasi Prelude
//!
//! Tujuan dari modul ini adalah untuk mengurangi impor item yang biasa digunakan dari `alloc` crate dengan menambahkan impor glob ke bagian atas modul:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;