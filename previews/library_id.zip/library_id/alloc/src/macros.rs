/// Membuat [`Vec`] yang berisi argumen.
///
/// `vec!` memungkinkan `Vec`s untuk didefinisikan dengan sintaks yang sama sebagai ekspresi array.
/// Ada dua bentuk makro ini:
///
/// - Buat [`Vec`] yang berisi daftar elemen tertentu:
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - Buat [`Vec`] dari elemen dan ukuran tertentu:
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// Perhatikan bahwa tidak seperti ekspresi array, sintaks ini mendukung semua elemen yang mengimplementasikan [`Clone`] dan jumlah elemen tidak harus konstan.
///
/// Ini akan menggunakan `clone` untuk menduplikasi ekspresi, jadi orang harus berhati-hati menggunakan ini dengan tipe yang memiliki implementasi `Clone` tidak standar.
/// Misalnya, `vec![Rc::new(1);5] `akan membuat vector dari lima referensi ke nilai bilangan bulat kotak yang sama, bukan lima referensi yang menunjuk ke bilangan bulat kotak secara independen.
///
///
/// Juga, perhatikan bahwa `vec![expr; 0]` diperbolehkan, dan menghasilkan vector kosong.
/// Namun, ini masih akan mengevaluasi `expr`, dan segera menurunkan nilai yang dihasilkan, jadi perhatikan efek sampingnya.
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): dengan cfg(test) metode `[T]::into_vec` inheren, yang diperlukan untuk definisi makro ini, tidak tersedia.
// Sebagai gantinya gunakan fungsi `slice::into_vec` yang hanya tersedia dengan cfg(test) NB lihat modul slice::hack di slice.rs untuk informasi lebih lanjut
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// Membuat `String` menggunakan interpolasi ekspresi runtime.
///
/// Argumen pertama yang diterima `format!` adalah string format.Ini harus berupa string literal.Kekuatan string pemformatan ada di dalam `{}` yang terkandung.
///
/// Parameter tambahan yang diteruskan ke `format!` menggantikan `{}` dalam string pemformatan dalam urutan yang diberikan kecuali parameter bernama atau posisi digunakan;lihat [`std::fmt`] untuk informasi lebih lanjut.
///
///
/// Penggunaan umum untuk `format!` adalah rangkaian dan interpolasi string.
/// Konvensi yang sama digunakan dengan makro [`print!`] dan [`write!`], bergantung pada tujuan string yang diinginkan.
///
/// Untuk mengonversi satu nilai menjadi string, gunakan metode [`to_string`].Ini akan menggunakan format [`Display`] trait.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` panics jika implementasi format trait mengembalikan kesalahan.
/// Ini menunjukkan implementasi yang salah karena `fmt::Write for String` tidak pernah mengembalikan kesalahan itu sendiri.
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// Paksa node AST ke ekspresi untuk meningkatkan diagnostik dalam posisi pola.
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}