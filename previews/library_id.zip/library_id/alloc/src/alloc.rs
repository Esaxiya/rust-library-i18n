//! API alokasi memori

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // Ini adalah simbol ajaib untuk memanggil pengalokasi global.rustc membuat mereka memanggil `__rg_alloc` dll.
    // jika ada atribut `#[global_allocator]` (kode yang memperluas makro atribut itu menghasilkan fungsi-fungsi tersebut), atau untuk memanggil implementasi default di libstd (`__rdl_alloc` dll.
    //
    // di `library/std/src/alloc.rs`) sebaliknya.
    // rustc fork dari LLVM juga menggunakan kasus khusus nama fungsi ini untuk dapat mengoptimalkannya seperti `malloc`, `realloc`, dan `free`.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// Pengalokasi memori global.
///
/// Jenis ini mengimplementasikan [`Allocator`] trait dengan meneruskan panggilan ke pengalokasi yang terdaftar dengan atribut `#[global_allocator]` jika ada, atau default `std` crate.
///
///
/// Note: sementara tipe ini tidak stabil, fungsionalitas yang disediakannya dapat diakses melalui [free functions in `alloc`](self#functions).
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// Alokasikan memori dengan pengalokasi global.
///
/// Fungsi ini meneruskan panggilan ke metode [`GlobalAlloc::alloc`] dari pengalokasi yang terdaftar dengan atribut `#[global_allocator]` jika ada, atau default `std` crate.
///
///
/// Fungsi ini diharapkan tidak digunakan lagi untuk mendukung metode `alloc` dari tipe [`Global`] saat itu dan [`Allocator`] trait menjadi stabil.
///
/// # Safety
///
/// Lihat [`GlobalAlloc::alloc`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// Batalkan alokasi memori dengan pengalokasi global.
///
/// Fungsi ini meneruskan panggilan ke metode [`GlobalAlloc::dealloc`] dari pengalokasi yang terdaftar dengan atribut `#[global_allocator]` jika ada, atau default `std` crate.
///
///
/// Fungsi ini diharapkan tidak digunakan lagi untuk mendukung metode `dealloc` dari tipe [`Global`] saat itu dan [`Allocator`] trait menjadi stabil.
///
/// # Safety
///
/// Lihat [`GlobalAlloc::dealloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// Alokasikan kembali memori dengan pengalokasi global.
///
/// Fungsi ini meneruskan panggilan ke metode [`GlobalAlloc::realloc`] dari pengalokasi yang terdaftar dengan atribut `#[global_allocator]` jika ada, atau default `std` crate.
///
///
/// Fungsi ini diharapkan tidak digunakan lagi untuk mendukung metode `realloc` dari tipe [`Global`] saat itu dan [`Allocator`] trait menjadi stabil.
///
/// # Safety
///
/// Lihat [`GlobalAlloc::realloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// Alokasikan memori yang diinisialisasi nol dengan pengalokasi global.
///
/// Fungsi ini meneruskan panggilan ke metode [`GlobalAlloc::alloc_zeroed`] dari pengalokasi yang terdaftar dengan atribut `#[global_allocator]` jika ada, atau default `std` crate.
///
///
/// Fungsi ini diharapkan tidak digunakan lagi untuk mendukung metode `alloc_zeroed` dari tipe [`Global`] saat itu dan [`Allocator`] trait menjadi stabil.
///
/// # Safety
///
/// Lihat [`GlobalAlloc::alloc_zeroed`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // KEAMANAN: `layout` berukuran bukan nol,
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // SAFETY: Sama seperti `Allocator::grow`
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // KEAMANAN: `new_size` bukan nol karena `old_size` lebih besar dari atau sama dengan `new_size`
            // seperti yang dipersyaratkan oleh kondisi keamanan.Kondisi lain harus ditegakkan oleh penelepon
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` mungkin memeriksa `new_size >= old_layout.size()` atau yang serupa.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // KEAMANAN: karena `new_layout.size()` harus lebih besar dari atau sama dengan `old_size`,
            // baik alokasi memori lama dan baru valid untuk membaca dan menulis untuk byte `old_size`.
            // Selain itu, karena alokasi lama belum dialokasikan, alokasi tersebut tidak dapat tumpang tindih dengan `new_ptr`.
            // Dengan demikian, panggilan ke `copy_nonoverlapping` aman.
            // Kontrak keamanan untuk `dealloc` harus dipegang oleh penelepon.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // KEAMANAN: `layout` berukuran bukan nol,
            // kondisi lain harus ditegakkan oleh pemanggil
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // KEAMANAN: semua kondisi harus ditegakkan oleh penelepon
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // KEAMANAN: semua kondisi harus ditegakkan oleh penelepon
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // KEAMANAN: syarat harus ditegakkan oleh penelepon
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // KEAMANAN: `new_size` bukan nol.Kondisi lain harus ditegakkan oleh penelepon
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` mungkin memeriksa `new_size <= old_layout.size()` atau yang serupa.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // KEAMANAN: karena `new_size` harus lebih kecil dari atau sama dengan `old_layout.size()`,
            // baik alokasi memori lama dan baru valid untuk membaca dan menulis untuk byte `new_size`.
            // Selain itu, karena alokasi lama belum dialokasikan, alokasi tersebut tidak dapat tumpang tindih dengan `new_ptr`.
            // Dengan demikian, panggilan ke `copy_nonoverlapping` aman.
            // Kontrak keamanan untuk `dealloc` harus dipegang oleh penelepon.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// Pengalokasi untuk pointer unik.
// Fungsi ini tidak boleh dilepaskan.Jika ya, codegen MIR akan gagal.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// Tanda tangan ini harus sama dengan `Box`, jika tidak ICE akan terjadi.
// Ketika parameter tambahan ke `Box` ditambahkan (seperti `A: Allocator`), ini juga harus ditambahkan di sini.
// Misalnya jika `Box` diubah menjadi `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)`, fungsi ini juga harus diubah menjadi `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)`.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # Penangan kesalahan alokasi

extern "Rust" {
    // Ini adalah simbol ajaib untuk memanggil penangan kesalahan alokasi global.
    // rustc membuatnya untuk memanggil `__rg_oom` jika ada `#[alloc_error_handler]`, atau untuk memanggil implementasi default di bawah (`__rdl_oom`) sebaliknya.
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// Batalkan kesalahan atau kegagalan alokasi memori.
///
/// Penelepon API alokasi memori yang ingin membatalkan komputasi sebagai respons terhadap kesalahan alokasi didorong untuk memanggil fungsi ini, daripada langsung memanggil `panic!` atau yang serupa.
///
///
/// Perilaku default dari fungsi ini adalah mencetak pesan ke kesalahan standar dan membatalkan proses.
/// Itu bisa diganti dengan [`set_alloc_error_hook`] dan [`take_alloc_error_hook`].
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// Untuk tes alokasi `std::alloc::handle_alloc_error` dapat digunakan secara langsung.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // dipanggil melalui `__rust_alloc_error_handler` yang dihasilkan

    // jika tidak ada `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // jika ada `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// Mengkhususkan klon ke dalam memori yang dialokasikan sebelumnya dan tidak diinisialisasi.
/// Digunakan oleh `Box::clone` dan `Rc`/`Arc::make_mut`.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Setelah mengalokasikan *pertama* memungkinkan pengoptimal untuk membuat nilai kloning di tempat, melewatkan lokal dan pindah.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Kami selalu dapat menyalin di tempat, tanpa pernah melibatkan nilai lokal.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}