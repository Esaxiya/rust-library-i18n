//! Irisan string unicode.
//!
//! *[See also the `str` primitive type](str).*
//!
//! Jenis `&str` adalah salah satu dari dua jenis string utama, yang lainnya adalah `String`.
//! Tidak seperti mitranya `String`, isinya dipinjam.
//!
//! # Penggunaan Dasar
//!
//! Deklarasi string dasar tipe `&str`:
//!
//! ```
//! let hello_world = "Hello, World!";
//! ```
//!
//! Di sini kami telah mendeklarasikan string literal, juga dikenal sebagai potongan string.
//! String literal memiliki masa hidup statis, yang berarti string `hello_world` dijamin valid selama durasi program secara keseluruhan.
//!
//! Kita juga dapat secara eksplisit menentukan masa hidup `hello_world`:
//!
//! ```
//! let hello_world: &'static str = "Hello, world!";
//! ```

#![stable(feature = "rust1", since = "1.0.0")]
// Banyak penggunaan dalam modul ini hanya digunakan dalam konfigurasi pengujian.
// Lebih baik menonaktifkan peringatan unused_imports daripada memperbaikinya.
#![allow(unused_imports)]

use core::borrow::{Borrow, BorrowMut};
use core::iter::FusedIterator;
use core::mem;
use core::ptr;
use core::str::pattern::{DoubleEndedSearcher, Pattern, ReverseSearcher, Searcher};
use core::unicode::conversions;

use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::slice::{Concat, Join, SliceIndex};
use crate::string::String;
use crate::vec::Vec;

#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::pattern;
#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use core::str::EncodeUtf16;
#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use core::str::SplitAsciiWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::SplitWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8, from_utf8_mut, Bytes, CharIndices, Chars};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8_unchecked, from_utf8_unchecked_mut, ParseBoolError};
#[stable(feature = "str_escape", since = "1.34.0")]
pub use core::str::{EscapeDebug, EscapeDefault, EscapeUnicode};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{FromStr, Utf8Error};
#[allow(deprecated)]
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Lines, LinesAny};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{MatchIndices, RMatchIndices};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Matches, RMatches};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplit, Split};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitN, SplitN};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitTerminator, SplitTerminator};

/// Note: `str` di `Concat<str>` tidak ada artinya di sini.
/// Parameter tipe trait ini hanya ada untuk mengaktifkan impl.
#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Concat<str> for [S] {
    type Output = String;

    fn concat(slice: &Self) -> String {
        Join::join(slice, "")
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Join<&str> for [S] {
    type Output = String;

    fn join(slice: &Self, sep: &str) -> String {
        unsafe { String::from_utf8_unchecked(join_generic_copy(slice, sep.as_bytes())) }
    }
}

macro_rules! specialize_for_lengths {
    ($separator:expr, $target:expr, $iter:expr; $($num:expr),*) => {{
        let mut target = $target;
        let iter = $iter;
        let sep_bytes = $separator;
        match $separator.len() {
            $(
                // loop dengan ukuran hardcode berjalan lebih cepat mengkhususkan case dengan panjang separator kecil
                //
                $num => {
                    for s in iter {
                        copy_slice_and_advance!(target, sep_bytes);
                        let content_bytes = s.borrow().as_ref();
                        copy_slice_and_advance!(target, content_bytes);
                    }
                },
            )*
            _ => {
                // fallback ukuran bukan nol sewenang-wenang
                for s in iter {
                    copy_slice_and_advance!(target, sep_bytes);
                    let content_bytes = s.borrow().as_ref();
                    copy_slice_and_advance!(target, content_bytes);
                }
            }
        }
        target
    }}
}

macro_rules! copy_slice_and_advance {
    ($target:expr, $bytes:expr) => {
        let len = $bytes.len();
        let (head, tail) = { $target }.split_at_mut(len);
        head.copy_from_slice($bytes);
        $target = tail;
    };
}

// Implementasi gabungan yang dioptimalkan yang berfungsi untuk kedua Vec<T>(T: Salin) dan vec bagian dalam String Saat ini (2018-05-13) terdapat bug dengan jenis inferensi dan spesialisasi (lihat masalah #36262) Untuk alasan ini SliceConcat<T>tidak dikhususkan untuk T: Copy dan SliceConcat<str>adalah satu-satunya pengguna fungsi ini.
// Itu dibiarkan di tempatnya untuk waktu yang sudah diperbaiki.
//
// batas untuk String-join adalah S: Pinjam<str>dan untuk Vec-join Borrow <[T]> [T] dan str keduanya impl AsRef <[T]> untuk beberapa T
// => s.borrow().as_ref() dan kami selalu memiliki irisan
//
//
//
fn join_generic_copy<B, T, S>(slice: &[S], sep: &[T]) -> Vec<T>
where
    T: Copy,
    B: AsRef<[T]> + ?Sized,
    S: Borrow<B>,
{
    let sep_len = sep.len();
    let mut iter = slice.iter();

    // potongan pertama adalah satu-satunya tanpa pemisah sebelumnya
    let first = match iter.next() {
        Some(first) => first,
        None => return vec![],
    };

    // hitung panjang total yang tepat dari Vec yang digabungkan jika kalkulasi `len` meluap, kita akan panic kita akan tetap kehabisan memori dan sisa fungsi memerlukan seluruh Vec yang dialokasikan sebelumnya untuk keamanan
    //
    //
    //
    let reserved_len = sep_len
        .checked_mul(iter.len())
        .and_then(|n| {
            slice.iter().map(|s| s.borrow().as_ref().len()).try_fold(n, usize::checked_add)
        })
        .expect("attempt to join into collection with len > usize::MAX");

    // siapkan buffer yang tidak diinisialisasi
    let mut result = Vec::with_capacity(reserved_len);
    debug_assert!(result.capacity() >= reserved_len);

    result.extend_from_slice(first.borrow().as_ref());

    unsafe {
        let pos = result.len();
        let target = result.get_unchecked_mut(pos..reserved_len);

        // copy separator dan slice over without bounds check menghasilkan loop dengan offset hardcode untuk pemisah kecil, peningkatan besar mungkin terjadi (~ x2)
        //
        //
        let remain = specialize_for_lengths!(sep, target, iter; 0, 1, 2, 3, 4);

        // Penerapan pinjaman aneh dapat mengembalikan potongan yang berbeda untuk perhitungan panjang dan salinan sebenarnya.
        //
        // Pastikan kami tidak mengekspos byte yang tidak diinisialisasi ke pemanggil.
        let result_len = reserved_len - remain.len();
        result.set_len(result_len);
    }
    result
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Borrow<str> for String {
    #[inline]
    fn borrow(&self) -> &str {
        &self[..]
    }
}

#[stable(feature = "string_borrow_mut", since = "1.36.0")]
impl BorrowMut<str> for String {
    #[inline]
    fn borrow_mut(&mut self) -> &mut str {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ToOwned for str {
    type Owned = String;
    #[inline]
    fn to_owned(&self) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().to_owned()) }
    }

    fn clone_into(&self, target: &mut String) {
        let mut b = mem::take(target).into_bytes();
        self.as_bytes().clone_into(&mut b);
        *target = unsafe { String::from_utf8_unchecked(b) }
    }
}

/// Metode untuk irisan tali.
#[lang = "str_alloc"]
#[cfg(not(test))]
impl str {
    /// Mengubah `Box<str>` menjadi `Box<[u8]>` tanpa menyalin atau mengalokasikan.
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let s = "this is a string";
    /// let boxed_str = s.to_owned().into_boxed_str();
    /// let boxed_bytes = boxed_str.into_boxed_bytes();
    /// assert_eq!(*boxed_bytes, *s.as_bytes());
    /// ```
    #[stable(feature = "str_box_extras", since = "1.20.0")]
    #[inline]
    pub fn into_boxed_bytes(self: Box<str>) -> Box<[u8]> {
        self.into()
    }

    /// Mengganti semua kecocokan pola dengan string lain.
    ///
    /// `replace` membuat [`String`] baru, dan menyalin data dari potongan string ini ke dalamnya.
    /// Saat melakukannya, ia mencoba menemukan kecocokan suatu pola.
    /// Jika ditemukan, itu menggantinya dengan potongan string pengganti.
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let s = "this is old";
    ///
    /// assert_eq!("this is new", s.replace("old", "new"));
    /// ```
    ///
    /// Jika polanya tidak cocok:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replace("cookie monster", "little lamb"));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn replace<'a, P: Pattern<'a>>(&'a self, from: P, to: &str) -> String {
        let mut result = String::new();
        let mut last_end = 0;
        for (start, part) in self.match_indices(from) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Mengganti N kecocokan pertama dari sebuah pola dengan string lain.
    ///
    /// `replacen` membuat [`String`] baru, dan menyalin data dari potongan string ini ke dalamnya.
    /// Saat melakukannya, ia mencoba menemukan kecocokan suatu pola.
    /// Jika ditemukan, ia menggantinya dengan potongan string pengganti paling banyak `count` kali.
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let s = "foo foo 123 foo";
    /// assert_eq!("new new 123 foo", s.replacen("foo", "new", 2));
    /// assert_eq!("faa fao 123 foo", s.replacen('o', "a", 3));
    /// assert_eq!("foo foo new23 foo", s.replacen(char::is_numeric, "new", 1));
    /// ```
    ///
    /// Jika polanya tidak cocok:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replacen("cookie monster", "little lamb", 10));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "str_replacen", since = "1.16.0")]
    pub fn replacen<'a, P: Pattern<'a>>(&'a self, pat: P, to: &str, count: usize) -> String {
        // Harapan untuk mengurangi waktu alokasi ulang
        let mut result = String::with_capacity(32);
        let mut last_end = 0;
        for (start, part) in self.match_indices(pat).take(count) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Menampilkan huruf kecil yang setara dengan potongan string ini, sebagai [`String`] baru.
    ///
    /// 'Lowercase' didefinisikan sesuai dengan ketentuan dari Unicode Derived Core Property `Lowercase`.
    ///
    /// Karena beberapa karakter dapat diperluas menjadi beberapa karakter saat mengubah kapitalisasi, fungsi ini mengembalikan [`String`] daripada mengubah parameter di tempat.
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let s = "HELLO";
    ///
    /// assert_eq!("hello", s.to_lowercase());
    /// ```
    ///
    /// Contoh rumit, dengan sigma:
    ///
    /// ```
    /// let sigma = "Σ";
    ///
    /// assert_eq!("σ", sigma.to_lowercase());
    ///
    /// // tapi di akhir kata, itu ς, bukan σ:
    /// let odysseus = "ὈΔΥΣΣΕΎΣ";
    ///
    /// assert_eq!("ὀδυσσεύς", odysseus.to_lowercase());
    /// ```
    ///
    /// Bahasa tanpa huruf besar/kecil tidak berubah:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_lowercase());
    /// ```
    ///
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_lowercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for (i, c) in self[..].char_indices() {
            if c == 'Σ' {
                // Σ dipetakan ke σ, kecuali di akhir kata yang dipetakan ke ς.
                // Ini adalah satu-satunya (contextual) bersyarat tetapi pemetaan bahasa-independen di `SpecialCasing.txt`, jadi lakukan hard-code daripada memiliki mekanisme "condition" generik.
                //
                // See https://github.com/rust-lang/rust/issues/26035
                //
                map_uppercase_sigma(self, i, &mut s)
            } else {
                match conversions::to_lower(c) {
                    [a, '\0', _] => s.push(a),
                    [a, b, '\0'] => {
                        s.push(a);
                        s.push(b);
                    }
                    [a, b, c] => {
                        s.push(a);
                        s.push(b);
                        s.push(c);
                    }
                }
            }
        }
        return s;

        fn map_uppercase_sigma(from: &str, i: usize, to: &mut String) {
            // See http://www.unicode.org/versions/Unicode7.0.0/ch03.pdf#G33992
            // untuk definisi `Final_Sigma`.
            debug_assert!('Σ'.len_utf8() == 2);
            let is_word_final = case_ignoreable_then_cased(from[..i].chars().rev())
                && !case_ignoreable_then_cased(from[i + 2..].chars());
            to.push_str(if is_word_final { "ς" } else { "σ" });
        }

        fn case_ignoreable_then_cased<I: Iterator<Item = char>>(iter: I) -> bool {
            use core::unicode::{Case_Ignorable, Cased};
            match iter.skip_while(|&c| Case_Ignorable(c)).next() {
                Some(c) => Cased(c),
                None => false,
            }
        }
    }

    /// Mengembalikan ekuivalen huruf besar dari potongan string ini, sebagai [`String`] baru.
    ///
    /// 'Uppercase' didefinisikan sesuai dengan ketentuan dari Unicode Derived Core Property `Uppercase`.
    ///
    /// Karena beberapa karakter dapat diperluas menjadi beberapa karakter saat mengubah kapitalisasi, fungsi ini mengembalikan [`String`] daripada mengubah parameter di tempat.
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let s = "hello";
    ///
    /// assert_eq!("HELLO", s.to_uppercase());
    /// ```
    ///
    /// Skrip tanpa huruf besar/kecil tidak diubah:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_uppercase());
    /// ```
    ///
    /// Satu karakter bisa menjadi banyak:
    ///
    /// ```
    /// let s = "tschüß";
    ///
    /// assert_eq!("TSCHÜSS", s.to_uppercase());
    /// ```
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_uppercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for c in self[..].chars() {
            match conversions::to_upper(c) {
                [a, '\0', _] => s.push(a),
                [a, b, '\0'] => {
                    s.push(a);
                    s.push(b);
                }
                [a, b, c] => {
                    s.push(a);
                    s.push(b);
                    s.push(c);
                }
            }
        }
        s
    }

    /// Mengubah [`Box<str>`] menjadi [`String`] tanpa menyalin atau mengalokasikan.
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let string = String::from("birthday gift");
    /// let boxed_str = string.clone().into_boxed_str();
    ///
    /// assert_eq!(boxed_str.into_string(), string);
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_string(self: Box<str>) -> String {
        let slice = Box::<[u8]>::from(self);
        unsafe { String::from_utf8_unchecked(slice.into_vec()) }
    }

    /// Membuat [`String`] baru dengan mengulang string `n` kali.
    ///
    /// # Panics
    ///
    /// Fungsi ini akan panic jika kapasitas meluap.
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// assert_eq!("abc".repeat(4), String::from("abcabcabcabc"));
    /// ```
    ///
    /// A panic saat meluap:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// "0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_str", since = "1.16.0")]
    pub fn repeat(&self, n: usize) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().repeat(n)) }
    }

    /// Mengembalikan salinan string ini di mana setiap karakter dipetakan ke huruf besar ASCII yang setara.
    ///
    ///
    /// Huruf ASCII 'a' hingga 'z' dipetakan ke 'A' hingga 'Z', tetapi huruf non-ASCII tidak berubah.
    ///
    /// Untuk mengecilkan nilai di tempat, gunakan [`make_ascii_uppercase`].
    ///
    /// Untuk huruf besar karakter ASCII selain karakter non-ASCII, gunakan [`to_uppercase`].
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase`]: str::make_ascii_uppercase
    /// [`to_uppercase`]: #method.to_uppercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_uppercase();
        // make_ascii_uppercase() mempertahankan invarian UTF-8.
        unsafe { String::from_utf8_unchecked(bytes) }
    }

    /// Mengembalikan salinan string ini di mana setiap karakter dipetakan ke huruf kecil ASCII yang setara.
    ///
    ///
    /// Huruf ASCII 'A' hingga 'Z' dipetakan ke 'a' hingga 'z', tetapi huruf non-ASCII tidak berubah.
    ///
    /// Untuk mengecilkan nilai di tempat, gunakan [`make_ascii_lowercase`].
    ///
    /// Untuk huruf kecil karakter ASCII selain karakter non-ASCII, gunakan [`to_lowercase`].
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("grüße, jürgen ❤", s.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase`]: str::make_ascii_lowercase
    /// [`to_lowercase`]: #method.to_lowercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_lowercase();
        // make_ascii_lowercase() mempertahankan invarian UTF-8.
        unsafe { String::from_utf8_unchecked(bytes) }
    }
}

/// Mengonversi potongan byte dalam kotak menjadi potongan string kotak tanpa memeriksa bahwa string tersebut berisi UTF-8 yang valid.
///
///
/// # Examples
///
/// Penggunaan dasar:
///
/// ```
/// let smile_utf8 = Box::new([226, 152, 186]);
/// let smile = unsafe { std::str::from_boxed_utf8_unchecked(smile_utf8) };
///
/// assert_eq!("☺", &*smile);
/// ```
#[stable(feature = "str_box_extras", since = "1.20.0")]
#[inline]
pub unsafe fn from_boxed_utf8_unchecked(v: Box<[u8]>) -> Box<str> {
    unsafe { Box::from_raw(Box::into_raw(v) as *mut str) }
}