use core::marker::PhantomData;
use core::ptr::NonNull;

/// Memodelkan reborrow dari beberapa referensi unik, ketika Anda mengetahui bahwa reborrow dan semua turunannya (yaitu, semua petunjuk dan referensi yang diturunkan darinya) tidak akan digunakan lagi di beberapa titik, setelah itu Anda ingin menggunakan referensi unik asli lagi .
///
///
/// Pemeriksa peminjam biasanya menangani penumpukan pinjaman ini untuk Anda, tetapi beberapa aliran kontrol yang menyelesaikan penumpukan ini terlalu rumit untuk diikuti oleh kompiler.
/// `DormantMutRef` memungkinkan Anda untuk memeriksa peminjaman diri Anda sendiri, sambil tetap mengekspresikan sifat tumpukannya, dan merangkum kode penunjuk mentah yang diperlukan untuk melakukan ini tanpa perilaku yang tidak ditentukan.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Tangkap pinjaman unik, dan segera pinjam kembali.
    /// Untuk kompiler, masa pakai referensi baru sama dengan masa pakai referensi asli, tetapi Anda promise untuk menggunakannya untuk periode yang lebih singkat.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // KEAMANAN: kami menahan pinjaman di seluruh 'a melalui `_marker`, dan kami mengekspos
        // hanya referensi ini, jadi unik.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Kembalikan ke pinjaman unik yang awalnya ditangkap.
    ///
    /// # Safety
    ///
    /// Peminjaman kembali harus telah berakhir, yaitu, referensi yang dikembalikan oleh `new` dan semua petunjuk serta referensi yang diturunkan darinya, tidak boleh digunakan lagi.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // KESELAMATAN: kondisi keselamatan kita sendiri menyiratkan bahwa referensi ini sekali lagi unik.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;