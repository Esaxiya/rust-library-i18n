// Ini merupakan upaya implementasi yang mengikuti cita-cita
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Karena Rust sebenarnya tidak memiliki tipe dependen dan rekursi polimorfik, kami membuat banyak ketidakamanan.
//

// Tujuan utama modul ini adalah untuk menghindari kerumitan dengan memperlakukan pohon sebagai wadah generik (jika berbentuk aneh) dan menghindari berurusan dengan sebagian besar invarian B-Tree.
//
// Dengan demikian, modul ini tidak peduli apakah entri diurutkan, node mana yang bisa underfull, atau bahkan apa arti underfull.Namun, kami mengandalkan beberapa invarian:
//
// - Pohon harus memiliki depth/height yang seragam.Ini berarti bahwa setiap jalur ke daun dari simpul tertentu memiliki panjang yang sama persis.
// - Node dengan panjang `n` memiliki kunci `n`, nilai `n`, dan tepi `n + 1`.
//   Ini menyiratkan bahwa bahkan node kosong memiliki setidaknya satu edge.
//   Untuk node daun, "having an edge" hanya berarti kita dapat mengidentifikasi posisi di node, karena tepi daun kosong dan tidak memerlukan representasi data.
// Dalam simpul internal, edge keduanya mengidentifikasi posisi dan berisi penunjuk ke simpul anak.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// Representasi yang mendasari node daun dan bagian dari representasi node internal.
struct LeafNode<K, V> {
    /// Kami ingin menjadi kovarian di `K` dan `V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Indeks node ini ke dalam array `edges` node induk.
    /// `*node.parent.edges[node.parent_idx]` harus sama dengan `node`.
    /// Ini hanya dijamin akan diinisialisasi jika `parent` bukan null.
    parent_idx: MaybeUninit<u16>,

    /// Jumlah kunci dan nilai yang disimpan node ini.
    len: u16,

    /// Array menyimpan data aktual dari node.
    /// Hanya elemen `len` pertama dari setiap larik yang diinisialisasi dan valid.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Menginisialisasi `LeafNode` baru di tempat.
    unsafe fn init(this: *mut Self) {
        // Sebagai kebijakan umum, kami membiarkan bidang tidak diinisialisasi jika memungkinkan, karena ini seharusnya sedikit lebih cepat dan lebih mudah dilacak di Valgrind.
        //
        unsafe {
            // parent_idx, keys, dan vals adalah MaybeUninit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Membuat kotak `LeafNode` baru.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// Representasi yang mendasari node internal.Seperti pada `LeafNode`, ini harus disembunyikan di belakang`BoxedNode` untuk mencegah hilangnya kunci dan nilai yang tidak diinisialisasi.
/// Setiap pointer ke `InternalNode` dapat langsung dicor ke pointer ke bagian `LeafNode` yang mendasari node, memungkinkan kode untuk bertindak pada node daun dan internal secara umum tanpa harus memeriksa yang mana dari dua pointer yang menunjuk.
///
/// Properti ini diaktifkan dengan penggunaan `repr(C)`.
///
#[repr(C)]
// gdb_providers.py menggunakan nama jenis ini untuk introspeksi.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Pointer ke anak node ini.
    /// `len + 1` dari ini dianggap diinisialisasi dan valid, kecuali bahwa di dekat akhir, sementara pohon dipegang melalui tipe pinjaman `Dying`, beberapa petunjuk ini menjuntai.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Membuat kotak `InternalNode` baru.
    ///
    /// # Safety
    /// Kebalikan dari node internal adalah mereka memiliki setidaknya satu edge yang diinisialisasi dan valid.
    /// Fungsi ini tidak mengatur edge seperti itu.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Kami hanya perlu menginisialisasi data;ujung-ujungnya adalah MaybeUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Pointer terkelola dan bukan null ke sebuah node.Ini bisa berupa penunjuk milik ke `LeafNode<K, V>` atau penunjuk milik ke `InternalNode<K, V>`.
///
/// Namun, `BoxedNode` tidak berisi informasi tentang yang mana dari dua jenis node yang sebenarnya dikandungnya, dan, sebagian karena kurangnya informasi ini, bukanlah tipe yang terpisah dan tidak memiliki destruktor.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Node akar dari pohon yang dimiliki.
///
/// Perhatikan bahwa ini tidak memiliki destruktor, dan harus dibersihkan secara manual.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Mengembalikan pohon milik baru, dengan simpul akarnya sendiri yang awalnya kosong.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` tidak boleh nol.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Bisa meminjam simpul akar yang dimiliki.
    /// Tidak seperti `reborrow_mut`, ini aman karena nilai yang dikembalikan tidak dapat digunakan untuk menghancurkan akar, dan tidak dapat ada referensi lain ke pohon tersebut.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Sedikit saling meminjam dari simpul akar yang dimiliki.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Transisi ireversibel ke referensi yang memungkinkan traversal dan menawarkan metode destruktif dan sedikit hal lainnya.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Menambahkan simpul internal baru dengan satu edge yang menunjuk ke simpul akar sebelumnya, menjadikan simpul baru itu simpul akar, dan mengembalikannya.
    /// Ini meningkatkan tinggi sebesar 1 dan merupakan kebalikan dari `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, kecuali bahwa kami baru saja lupa bahwa kami internal sekarang:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Menghapus simpul akar internal, menggunakan anak pertamanya sebagai simpul akar baru.
    /// Karena ini dimaksudkan hanya untuk dipanggil ketika node root hanya memiliki satu anak, tidak ada pembersihan yang dilakukan pada kunci, nilai, dan turunan lainnya.
    ///
    /// Ini mengurangi tinggi sebesar 1 dan merupakan kebalikan dari `push_internal_level`.
    ///
    /// Membutuhkan akses eksklusif ke objek `Root` tetapi tidak ke node root;
    /// itu tidak akan membatalkan pegangan atau referensi lain ke simpul akar.
    ///
    /// Panics jika tidak ada tingkat internal, yaitu jika simpul akar adalah daun.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // KESELAMATAN: kami menegaskan untuk menjadi internal.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // KEAMANAN: kami meminjam `self` secara eksklusif dan jenis pinjamannya eksklusif.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // KEAMANAN: edge pertama selalu diinisialisasi.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` selalu kovarian dalam `K` dan `V`, meskipun `BorrowType` adalah `Mut`.
// Ini secara teknis salah, tetapi tidak dapat mengakibatkan ketidakamanan karena penggunaan internal `NodeRef` karena kami tetap sepenuhnya generik di atas `K` dan `V`.
//
// Namun, setiap kali tipe publik membungkus `NodeRef`, pastikan ia memiliki varian yang benar.
//
/// Referensi ke node.
///
/// Jenis ini memiliki sejumlah parameter yang mengontrol cara kerjanya:
/// - `BorrowType`: Tipe dummy yang menggambarkan jenis pinjam dan membawa seumur hidup.
///    - Jika ini adalah `Immut<'a>`, `NodeRef` bertindak secara kasar seperti `&'a Node`.
///    - Jika ini adalah `ValMut<'a>`, `NodeRef` bertindak secara kasar seperti `&'a Node` sehubungan dengan kunci dan struktur pohon, tetapi juga memungkinkan banyak referensi yang dapat berubah ke nilai di seluruh pohon untuk hidup berdampingan.
///    - Jika ini adalah `Mut<'a>`, `NodeRef` bertindak secara kasar seperti `&'a mut Node`, meskipun metode penyisipan memungkinkan penunjuk yang dapat berubah ke suatu nilai untuk hidup berdampingan.
///    - Jika ini adalah `Owned`, `NodeRef` bertindak secara kasar seperti `Box<Node>`, tetapi tidak memiliki penghancur, dan harus dibersihkan secara manual.
///    - Jika ini adalah `Dying`, `NodeRef` masih bertindak kasar seperti `Box<Node>`, tetapi memiliki metode untuk menghancurkan pohon sedikit demi sedikit, dan metode biasa, meskipun tidak ditandai sebagai tidak aman untuk dipanggil, dapat memanggil UB jika dipanggil secara tidak benar.
///
///   Karena `NodeRef` memungkinkan navigasi melalui pohon, `BorrowType` secara efektif berlaku untuk keseluruhan pohon, tidak hanya untuk simpul itu sendiri.
/// - `K` dan `V`: Ini adalah jenis kunci dan nilai yang disimpan di node.
/// - `Type`: Ini bisa berupa `Leaf`, `Internal`, atau `LeafOrInternal`.
/// Jika ini adalah `Leaf`, `NodeRef` menunjuk ke simpul daun, saat ini adalah `Internal`, `NodeRef` menunjuk ke simpul internal, dan ketika ini adalah `LeafOrInternal`, `NodeRef` bisa menunjuk ke salah satu jenis simpul.
///   `Type` dinamai `NodeType` jika digunakan di luar `NodeRef`.
///
/// Baik `BorrowType` dan `NodeType` membatasi metode apa yang kami terapkan, untuk mengeksploitasi keamanan tipe statis.Ada batasan dalam cara kami menerapkan batasan tersebut:
/// - Untuk setiap parameter tipe, kita hanya dapat mendefinisikan metode baik secara umum atau untuk satu tipe tertentu.
/// Misalnya, kita tidak dapat mendefinisikan metode seperti `into_kv` secara umum untuk semua `BorrowType`, atau sekali untuk semua tipe yang membawa seumur hidup, karena kita ingin mengembalikan referensi `&'a`.
///   Oleh karena itu, kami mendefinisikannya hanya untuk tipe `Immut<'a>` yang paling tidak bertenaga.
/// - Kita tidak bisa mendapatkan paksaan implisit dari katakanlah `Mut<'a>` ke `Immut<'a>`.
///   Oleh karena itu, kita harus memanggil `reborrow` secara eksplisit pada `NodeRef` yang lebih kuat untuk mencapai metode seperti `into_kv`.
///
/// Semua metode di `NodeRef` yang mengembalikan beberapa jenis referensi, baik:
/// - Ambil `self` menurut nilainya, dan kembalikan masa pakai yang dibawa oleh `BorrowType`.
///   Terkadang, untuk menjalankan metode seperti itu, kita perlu memanggil `reborrow_mut`.
/// - Ambil `self` sebagai referensi, dan (implicitly) mengembalikan masa pakai referensi itu, bukan masa pakai yang dibawa oleh `BorrowType`.
/// Dengan begitu, pemeriksa peminjam menjamin bahwa `NodeRef` tetap dipinjam selama referensi yang dikembalikan digunakan.
///   Metode yang mendukung insert menekuk aturan ini dengan mengembalikan pointer mentah, yaitu referensi tanpa masa pakai.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Jumlah level yang dipisahkan oleh node dan level daun, konstanta node yang tidak dapat sepenuhnya dijelaskan oleh `Type`, dan node itu sendiri tidak disimpan.
    /// Kita hanya perlu menyimpan tinggi dari simpul akar, dan mendapatkan tinggi setiap simpul lainnya darinya.
    /// Harus nol jika `Type` adalah `Leaf` dan bukan nol jika `Type` adalah `Internal`.
    ///
    ///
    height: usize,
    /// Penunjuk ke daun atau simpul internal.
    /// Definisi `InternalNode` memastikan bahwa penunjuk valid dengan cara apa pun.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Buka paket referensi node yang dikemas sebagai `NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Mengekspos data dari node internal.
    ///
    /// Mengembalikan ptr mentah untuk menghindari membuat referensi lain ke node ini tidak valid.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // KEAMANAN: jenis node statis adalah `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Meminjam akses eksklusif ke data node internal.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Menemukan panjang node.Ini adalah jumlah kunci atau nilai.
    /// Jumlah tepi adalah `len() + 1`.
    /// Perhatikan bahwa, meskipun aman, memanggil fungsi ini dapat memiliki efek samping berupa pembatalan referensi yang bisa berubah yang telah dibuat oleh kode tidak aman.
    ///
    pub fn len(&self) -> usize {
        // Yang terpenting, kami hanya mengakses bidang `len` di sini.
        // Jika BorrowType adalah marker::ValMut, mungkin ada referensi mutable yang luar biasa ke nilai yang tidak boleh kita batalkan.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Mengembalikan jumlah level di mana simpul dan daun terpisah.
    /// Tinggi nol berarti simpul adalah daun itu sendiri.
    /// Jika Anda membayangkan pohon dengan akar di atas, angka tersebut menunjukkan ketinggian mana simpul tersebut muncul.
    /// Jika Anda membayangkan pohon dengan daun di atasnya, angka tersebut menunjukkan seberapa tinggi pohon itu menjulur di atas simpul.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Untuk sementara menghapus referensi lain yang tidak dapat diubah ke node yang sama.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Mengekspos bagian daun dari setiap daun atau simpul internal.
    ///
    /// Mengembalikan ptr mentah untuk menghindari membuat referensi lain ke node ini tidak valid.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Node harus valid setidaknya untuk bagian LeafNode.
        // Ini bukan referensi dalam tipe NodeRef karena kami tidak tahu apakah itu harus unik atau dibagikan.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Menemukan induk dari node saat ini.
    /// Mengembalikan `Ok(handle)` jika simpul saat ini benar-benar memiliki induk, di mana `handle` menunjuk ke edge dari induk yang menunjuk ke simpul saat ini.
    ///
    /// Mengembalikan `Err(self)` jika simpul saat ini tidak memiliki induk, mengembalikan `NodeRef` asli.
    ///
    /// Nama metode mengasumsikan Anda menggambarkan pohon dengan simpul akar di atas.
    ///
    /// `edge.descend().ascend().unwrap()` dan `node.ascend().unwrap().descend()` keduanya, setelah sukses, tidak melakukan apa-apa.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Kita perlu menggunakan pointer mentah ke node karena, jika BorrowType adalah marker::ValMut, mungkin ada referensi mutable yang luar biasa ke nilai yang tidak boleh kita batalkan.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Perhatikan bahwa `self` tidak boleh kosong.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Perhatikan bahwa `self` tidak boleh kosong.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Menunjukkan bagian daun dari setiap daun atau simpul internal pada pohon yang tidak dapat diubah.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // KEAMANAN: tidak ada referensi yang bisa berubah ke dalam pohon ini yang dipinjam sebagai `Immut`.
        unsafe { &*ptr }
    }

    /// Meminjam tampilan ke dalam kunci yang disimpan di node.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Mirip dengan `ascend`, mendapatkan referensi ke node induk node, tetapi juga membatalkan alokasi node saat ini dalam proses.
    /// Ini tidak aman karena node saat ini masih dapat diakses meskipun alokasi dibatalkan.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Unsafely menegaskan kepada kompiler informasi statis bahwa node ini adalah `Leaf`.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Unsafely menegaskan kepada kompiler informasi statis bahwa node ini adalah `Internal`.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Untuk sementara mengambil referensi lain yang bisa berubah ke node yang sama.Berhati-hatilah, karena metode ini sangat berbahaya, jadi dua kali lipat karena mungkin tidak langsung terlihat berbahaya.
    ///
    /// Karena penunjuk yang dapat berubah dapat berkeliaran di mana saja di sekitar pohon, penunjuk yang dikembalikan dapat dengan mudah digunakan untuk membuat penunjuk asli menggantung, di luar batas, atau tidak valid di bawah aturan pinjam yang ditumpuk.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) pertimbangkan untuk menambahkan parameter tipe lain ke `NodeRef` yang membatasi penggunaan metode navigasi pada pointer yang dipinjam ulang, mencegah ketidakamanan ini.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Meminjam akses eksklusif ke bagian daun dari setiap daun atau simpul internal.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // KEAMANAN: kami memiliki akses eksklusif ke seluruh node.
        unsafe { &mut *ptr }
    }

    /// Menawarkan akses eksklusif ke bagian daun dari setiap daun atau simpul internal.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // KEAMANAN: kami memiliki akses eksklusif ke seluruh node.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Meminjam akses eksklusif ke elemen area penyimpanan kunci.
    ///
    /// # Safety
    /// `index` berada dalam batas 0..CAPACITY
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // KEAMANAN: penelepon tidak akan dapat memanggil metode lebih lanjut sendiri
        // hingga referensi potongan kunci dihapus, karena kami memiliki akses unik selama masa peminjaman.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Meminjam akses eksklusif ke elemen atau bagian dari area penyimpanan nilai node.
    ///
    /// # Safety
    /// `index` berada dalam batas 0..CAPACITY
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // KEAMANAN: penelepon tidak akan dapat memanggil metode lebih lanjut sendiri
        // hingga referensi potongan nilai dihapus, karena kami memiliki akses unik selama masa peminjaman.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Meminjam akses eksklusif ke elemen atau bagian dari area penyimpanan node untuk konten edge.
    ///
    /// # Safety
    /// `index` berada dalam batas 0..CAPACITY + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // KEAMANAN: penelepon tidak akan dapat memanggil metode lebih lanjut sendiri
        // hingga referensi potongan edge dihapus, karena kami memiliki akses unik selama masa peminjaman.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Node memiliki lebih dari `idx` elemen yang diinisialisasi.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Kami hanya membuat referensi ke satu elemen yang kami minati, untuk menghindari aliasing dengan referensi yang luar biasa ke elemen lain, khususnya, yang dikembalikan ke pemanggil dalam iterasi sebelumnya.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Kita harus memaksa ke pointer array berukuran besar karena Rust mengeluarkan #74679.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Meminjam akses eksklusif ke panjang node.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Menyetel tautan node ke induknya edge, tanpa membatalkan referensi lain ke node tersebut.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Menghapus tautan root ke induknya edge.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Menambahkan pasangan nilai kunci ke akhir node.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Setiap item yang dikembalikan oleh `range` adalah indeks edge yang valid untuk node tersebut.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Menambahkan pasangan nilai kunci, dan edge di sebelah kanan pasangan itu, ke ujung node.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Memeriksa apakah sebuah node adalah node `Internal` atau node `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Referensi ke key-value pair atau edge dalam sebuah node.
/// Parameter `Node` harus `NodeRef`, sedangkan `Type` dapat berupa `KV` (menandakan pegangan pada pasangan nilai kunci) atau `Edge` (menandakan pegangan pada edge).
///
/// Perhatikan bahwa bahkan node `Leaf` dapat memiliki pegangan `Edge`.
/// Alih-alih merepresentasikan pointer ke node turunan, ini mewakili ruang di mana pointer turunan akan ditempatkan di antara pasangan kunci-nilai.
/// Misalnya, dalam node dengan panjang 2, akan ada 3 kemungkinan lokasi edge, satu di kiri node, satu di antara dua pasangan, dan satu di kanan node.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Kita tidak memerlukan keumuman penuh `#[derive(Clone)]`, karena satu-satunya saat `Node` akan menjadi `Kloning` adalah jika ia merupakan referensi yang tidak dapat diubah dan oleh karena itu `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Mengambil node yang berisi edge atau pasangan nilai kunci yang ditunjuk oleh pegangan ini.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Mengembalikan posisi pegangan ini di node.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Membuat pegangan baru untuk pasangan nilai-kunci di `node`.
    /// Tidak aman karena penelepon harus memastikan `idx < node.len()` itu.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Bisa jadi implementasi publik PartialEq, tetapi hanya digunakan dalam modul ini.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Untuk sementara mengambil pegangan lain yang tidak dapat diubah di lokasi yang sama.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Kami tidak dapat menggunakan Handle::new_kv atau Handle::new_edge karena kami tidak tahu tipe kami
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Unsafely menegaskan kepada kompilator informasi statis bahwa node pegangan adalah `Leaf`.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Untuk sementara mengambil pegangan lain yang bisa berubah di lokasi yang sama.
    /// Berhati-hatilah, karena metode ini sangat berbahaya, jadi dua kali lipat karena mungkin tidak langsung terlihat berbahaya.
    ///
    ///
    /// Untuk detailnya, lihat `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Kami tidak dapat menggunakan Handle::new_kv atau Handle::new_edge karena kami tidak tahu tipe kami
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Membuat pegangan baru untuk edge di `node`.
    /// Tidak aman karena penelepon harus memastikan `idx <= node.len()` itu.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Diberikan indeks edge di mana kita ingin memasukkan ke dalam node yang penuh dengan kapasitas, menghitung indeks KV yang masuk akal dari titik terpisah dan di mana harus melakukan penyisipan.
///
/// Tujuan dari titik pisah adalah agar kunci dan nilainya berakhir di simpul induk;
/// kunci, nilai, dan tepi di kiri titik pemisah menjadi anak kiri;
/// kunci, nilai, dan tepi di sebelah kanan titik pemisah menjadi anak yang tepat.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Masalah Rust #74834 mencoba menjelaskan aturan simetris ini.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Menyisipkan pasangan nilai kunci baru antara pasangan nilai kunci di sebelah kanan dan kiri edge ini.
    /// Metode ini mengasumsikan bahwa ada cukup ruang di node agar pas dengan pasangan baru.
    ///
    /// Pointer yang dikembalikan menunjuk ke nilai yang dimasukkan.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Menyisipkan pasangan nilai kunci baru antara pasangan nilai kunci di sebelah kanan dan kiri edge ini.
    /// Metode ini membagi node jika tidak ada cukup ruang.
    ///
    /// Pointer yang dikembalikan menunjuk ke nilai yang dimasukkan.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Memperbaiki penunjuk dan indeks induk di simpul anak yang terhubung ke edge ini.
    /// Ini berguna ketika urutan edge telah diubah,
    fn correct_parent_link(self) {
        // Buat backpointer tanpa membatalkan referensi lain ke node.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Menyisipkan pasangan nilai kunci baru dan edge yang akan berada di sebelah kanan pasangan baru antara edge ini dan pasangan nilai kunci di sebelah kanan edge ini.
    /// Metode ini mengasumsikan bahwa ada cukup ruang di node agar pas dengan pasangan baru.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Menyisipkan pasangan nilai kunci baru dan edge yang akan berada di sebelah kanan pasangan baru antara edge ini dan pasangan nilai kunci di sebelah kanan edge ini.
    /// Metode ini membagi node jika tidak ada cukup ruang.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Menyisipkan pasangan nilai kunci baru antara pasangan nilai kunci di sebelah kanan dan kiri edge ini.
    /// Metode ini membagi node jika tidak ada cukup ruang, dan mencoba memasukkan bagian yang dipisahkan ke node induk secara rekursif, hingga root tercapai.
    ///
    ///
    /// Jika hasil yang dikembalikan adalah `Fit`, node pegangannya dapat berupa node edge ini atau node leluhur.
    /// Jika hasil yang dikembalikan adalah `Split`, bidang `left` akan menjadi simpul akar.
    /// Pointer yang dikembalikan menunjuk ke nilai yang dimasukkan.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Menemukan node yang ditunjuk oleh edge ini.
    ///
    /// Nama metode mengasumsikan Anda menggambarkan pohon dengan simpul akar di atas.
    ///
    /// `edge.descend().ascend().unwrap()` dan `node.ascend().unwrap().descend()` keduanya, setelah sukses, tidak melakukan apa-apa.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Kita perlu menggunakan pointer mentah ke node karena, jika BorrowType adalah marker::ValMut, mungkin ada referensi mutable yang luar biasa ke nilai yang tidak boleh kita batalkan.
        // Tidak perlu khawatir mengakses bidang ketinggian karena nilai itu disalin.
        // Berhati-hatilah bahwa, setelah penunjuk node didereferensi, kita mengakses array edge dengan referensi (Rust issue #73987) dan membatalkan referensi lain ke atau di dalam array, jika ada.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Kita tidak dapat memanggil metode kunci dan nilai yang terpisah, karena memanggil metode kedua membuat referensi yang dikembalikan oleh yang pertama tidak valid.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Ganti kunci dan nilai yang dirujuk pegangan KV.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Membantu implementasi `split` untuk `NodeType` tertentu, dengan menjaga data daun.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Membagi node yang mendasari menjadi tiga bagian:
    ///
    /// - Node dipotong agar hanya berisi pasangan nilai kunci di sebelah kiri pegangan ini.
    /// - Kunci dan nilai yang ditunjukkan oleh pegangan ini diekstrak.
    /// - Semua pasangan nilai kunci di sebelah kanan pegangan ini dimasukkan ke dalam node yang baru dialokasikan.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Menghapus pasangan nilai kunci yang ditunjukkan oleh pegangan ini dan mengembalikannya, bersama dengan edge tempat pasangan nilai kunci diciutkan.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Membagi node yang mendasari menjadi tiga bagian:
    ///
    /// - Node dipotong agar hanya berisi tepi dan pasangan nilai kunci di sebelah kiri pegangan ini.
    /// - Kunci dan nilai yang ditunjukkan oleh pegangan ini diekstrak.
    /// - Semua tepi dan pasangan nilai kunci di sebelah kanan pegangan ini dimasukkan ke dalam node yang baru dialokasikan.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Merepresentasikan sesi untuk mengevaluasi dan melakukan operasi penyeimbangan seputar pasangan kunci-nilai internal.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Memilih konteks penyeimbang yang melibatkan node sebagai anak, sehingga antara KV langsung ke kiri atau ke kanan di node induk.
    /// Mengembalikan `Err` jika tidak ada induk.
    /// Panics jika induknya kosong.
    ///
    /// Lebih memilih sisi kiri, untuk menjadi optimal jika simpul yang diberikan entah bagaimana underfull, yang berarti di sini hanya memiliki elemen yang lebih sedikit daripada saudara kirinya dan daripada saudara kanannya, jika ada.
    /// Dalam hal ini, menggabungkan dengan saudara kiri lebih cepat, karena kita hanya perlu memindahkan elemen N node, daripada menggesernya ke kanan dan memindahkan lebih dari N elemen di depan.
    /// Mencuri dari saudara kiri juga biasanya lebih cepat, karena kita hanya perlu menggeser elemen N node ke kanan, daripada menggeser setidaknya N dari elemen saudara ke kiri.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Mengembalikan apakah penggabungan mungkin dilakukan, yaitu apakah ada cukup ruang dalam node untuk menggabungkan KV pusat dengan kedua node turunan yang berdekatan.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Melakukan penggabungan dan membiarkan penutupan memutuskan apa yang akan dikembalikan.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // SAFETY: tinggi node yang digabungkan adalah satu di bawah tinggi
                // dari simpul edge ini, jadi di atas nol, jadi mereka internal.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Menggabungkan pasangan nilai kunci induk dan kedua simpul anak yang berdekatan ke simpul anak kiri dan mengembalikan simpul induk yang menyusut.
    ///
    ///
    /// Panics kecuali kami `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Menggabungkan pasangan nilai kunci induk dan kedua simpul anak yang berdekatan ke simpul anak kiri dan mengembalikan simpul anak itu.
    ///
    ///
    /// Panics kecuali kami `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Menggabungkan pasangan nilai kunci induk dan kedua simpul anak yang berdekatan ke simpul anak kiri dan mengembalikan pegangan edge di simpul anak itu di mana anak yang dilacak edge berakhir,
    ///
    ///
    /// Panics kecuali kami `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Menghapus pasangan nilai kunci dari anak kiri dan menempatkannya di penyimpanan nilai kunci induk, sambil mendorong pasangan nilai kunci induk yang lama ke anak kanan.
    ///
    /// Mengembalikan pegangan ke edge di turunan kanan yang sesuai dengan tempat berakhirnya edge asli yang ditentukan oleh `track_right_edge_idx`.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Menghapus pasangan nilai kunci dari anak kanan dan menempatkannya di penyimpanan nilai kunci induk, sambil mendorong pasangan nilai kunci induk yang lama ke anak kiri.
    ///
    /// Mengembalikan pegangan ke edge di anak kiri yang ditentukan oleh `track_left_edge_idx`, yang tidak bergerak.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Ini memang mencuri mirip dengan `steal_left` tetapi mencuri banyak elemen sekaligus.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Pastikan kami mencuri dengan aman.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Pindahkan data daun.
            {
                // Beri ruang untuk elemen yang dicuri pada anak yang tepat.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Pindahkan elemen dari anak kiri ke kanan.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Pindahkan pasangan paling kiri yang paling dicuri ke orang tua.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Pindahkan pasangan nilai kunci orang tua ke anak kanan.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Beri ruang untuk tepi yang dicuri.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Curi tepinya.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// Klon simetris `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Pastikan kami mencuri dengan aman.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Pindahkan data daun.
            {
                // Pindahkan pasangan paling kanan yang paling dicuri ke orang tua.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Pindahkan pasangan nilai kunci orang tua ke anak kiri.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Pindahkan elemen dari anak kanan ke kiri.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Isi celah tempat elemen yang dicuri dulu.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Curi tepinya.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Isi celah di tempat bekas tepi yang dicuri.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Menghapus informasi statis yang menyatakan bahwa node ini adalah node `Leaf`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Menghapus informasi statis yang menyatakan bahwa node ini adalah node `Internal`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Memeriksa apakah node yang mendasari adalah node `Internal` atau node `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Pindahkan sufiks setelah `self` dari satu node ke node lainnya.`right` harus kosong.
    /// edge pertama dari `right` tetap tidak berubah.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Hasil penyisipan, ketika sebuah node perlu diperluas melebihi kapasitasnya.
pub struct SplitResult<'a, K, V, NodeType> {
    // Node yang diubah pada pohon yang ada dengan elemen dan tepi yang dimiliki di sebelah kiri `kv`.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Beberapa kunci dan nilai dipisahkan, untuk disisipkan di tempat lain.
    pub kv: (K, V),
    // Node baru yang dimiliki, tidak terpasang, dengan elemen dan edge yang dimiliki oleh kanan `kv`.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Apakah referensi node dari jenis pinjaman ini memungkinkan traverse ke node lain di pohon.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Traversal tidak diperlukan, itu terjadi menggunakan hasil `borrow_mut`.
        // Dengan menonaktifkan traversal, dan hanya membuat referensi baru ke root, kita tahu bahwa setiap referensi tipe `Owned` ditujukan ke node root.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Menyisipkan nilai ke dalam potongan elemen yang diinisialisasi diikuti dengan satu elemen yang tidak diinisialisasi.
///
/// # Safety
/// Irisan memiliki lebih dari elemen `idx`.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Menghapus dan mengembalikan nilai dari potongan semua elemen yang diinisialisasi, meninggalkan satu elemen yang belum diinisialisasi.
///
///
/// # Safety
/// Irisan memiliki lebih dari elemen `idx`.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Menggeser elemen dalam posisi `distance` irisan ke kiri.
///
/// # Safety
/// Potongan memiliki setidaknya elemen `distance`.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Menggeser elemen dalam posisi potongan `distance` ke kanan.
///
/// # Safety
/// Potongan memiliki setidaknya elemen `distance`.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Memindahkan semua nilai dari potongan elemen yang diinisialisasi ke potongan elemen yang tidak diinisialisasi, meninggalkan `src` karena semuanya tidak diinisialisasi.
///
/// Bekerja seperti `dst.copy_from_slice(src)` tetapi tidak membutuhkan `T` untuk menjadi `Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;