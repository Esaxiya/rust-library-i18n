use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Menambahkan semua pasangan nilai kunci dari gabungan dua iterator menaik, dengan menambahkan variabel `length` di sepanjang proses.Yang terakhir memudahkan penelepon untuk menghindari kebocoran saat drop handler panik.
    ///
    /// Jika kedua iterator menghasilkan kunci yang sama, metode ini melepaskan pasangan dari iterator kiri dan menambahkan pasangan dari iterator kanan.
    ///
    /// Jika Anda ingin pohon berakhir dalam urutan menaik ketat, seperti untuk `BTreeMap`, kedua iterator harus menghasilkan kunci dalam urutan menaik ketat, masing-masing lebih besar dari semua kunci di pohon, termasuk kunci apa pun yang sudah ada di pohon saat masuk.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Kami mempersiapkan untuk menggabungkan `left` dan `right` menjadi urutan yang diurutkan dalam waktu linier.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Sementara itu, kami membangun pohon dari urutan yang diurutkan dalam waktu linier.
        self.bulk_push(iter, length)
    }

    /// Mendorong semua pasangan nilai kunci ke ujung pohon, dengan menambahkan variabel `length` di sepanjang proses.
    /// Yang terakhir memudahkan pemanggil untuk menghindari kebocoran saat iterator panik.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Iterasi melalui semua key-value pair, dorong mereka ke dalam node di tingkat yang tepat.
        for (key, value) in iter {
            // Cobalah untuk mendorong pasangan nilai kunci ke simpul daun saat ini.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Tidak ada ruang tersisa, naik dan dorong ke sana.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Menemukan simpul dengan sisa ruang, dorong di sini.
                                open_node = parent;
                                break;
                            } else {
                                // Naik lagi.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Kami berada di atas, buat simpul akar baru dan dorong di sana.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Dorong pasangan nilai kunci dan subpohon kanan baru.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Turun ke daun paling kanan lagi.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Tambah panjang setiap iterasi, untuk memastikan peta melepaskan elemen yang ditambahkan bahkan jika memajukan panick iterator.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Sebuah iterator untuk menggabungkan dua urutan yang diurutkan menjadi satu
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Jika dua kunci sama, mengembalikan pasangan nilai-kunci dari sumber yang benar.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}