use core::borrow::Borrow;
use core::cmp::Ordering;
use core::ops::{Bound, RangeBounds};

use super::node::{marker, ForceResult::*, Handle, NodeRef};

use SearchBound::*;
use SearchResult::*;

pub enum SearchBound<T> {
    /// Sebuah inklusif terikat untuk dicari, seperti `Bound::Included(T)`.
    Included(T),
    /// Suatu hal yang eksklusif untuk dicari, seperti `Bound::Excluded(T)`.
    Excluded(T),
    /// Batas inklusif tanpa syarat, seperti `Bound::Unbounded`.
    AllIncluded,
    /// Batas eksklusif tanpa syarat.
    AllExcluded,
}

impl<T> SearchBound<T> {
    pub fn from_range(range_bound: Bound<T>) -> Self {
        match range_bound {
            Bound::Included(t) => Included(t),
            Bound::Excluded(t) => Excluded(t),
            Bound::Unbounded => AllIncluded,
        }
    }
}

pub enum SearchResult<BorrowType, K, V, FoundType, GoDownType> {
    Found(Handle<NodeRef<BorrowType, K, V, FoundType>, marker::KV>),
    GoDown(Handle<NodeRef<BorrowType, K, V, GoDownType>, marker::Edge>),
}

pub enum IndexResult {
    KV(usize),
    Edge(usize),
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Mencari kunci tertentu dalam pohon (sub) yang dipimpin oleh node, secara rekursif.
    /// Mengembalikan `Found` dengan pegangan KV yang cocok, jika ada.
    /// Jika tidak, kembalikan `GoDown` dengan pegangan daun edge tempat kuncinya berada.
    ///
    /// Hasilnya hanya berarti jika pohon diurutkan berdasarkan kunci, seperti pohon di `BTreeMap`.
    ///
    pub fn search_tree<Q: ?Sized>(
        mut self,
        key: &Q,
    ) -> SearchResult<BorrowType, K, V, marker::LeafOrInternal, marker::Leaf>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        loop {
            self = match self.search_node(key) {
                Found(handle) => return Found(handle),
                GoDown(handle) => match handle.force() {
                    Leaf(leaf) => return GoDown(leaf),
                    Internal(internal) => internal.descend(),
                },
            }
        }
    }

    /// Turun ke node terdekat di mana edge yang cocok dengan batas bawah rentang berbeda dari edge yang cocok dengan batas atas, yaitu, node terdekat yang memiliki setidaknya satu kunci yang terdapat dalam rentang.
    ///
    ///
    /// Jika ditemukan, mengembalikan `Ok` dengan node tersebut, pasangan indeks edge di dalamnya yang membatasi rentang, dan pasangan batas yang sesuai untuk melanjutkan pencarian di node turunan, jika node tersebut internal.
    ///
    /// Jika tidak ditemukan, kembalikan `Err` dengan daun edge yang cocok dengan seluruh rentang.
    ///
    /// Hasilnya hanya bermakna jika pohon diurutkan berdasarkan kunci.
    ///
    ///
    ///
    ///
    pub fn search_tree_for_bifurcation<'r, Q: ?Sized, R>(
        mut self,
        range: &'r R,
    ) -> Result<
        (
            NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
            usize,
            usize,
            SearchBound<&'r Q>,
            SearchBound<&'r Q>,
        ),
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>,
    >
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // Menyebariskan variabel-variabel ini harus dihindari.
        // Kami menganggap batasan yang dilaporkan oleh `range` tetap sama, tetapi implementasi permusuhan dapat berubah di antara panggilan (#81138).
        let (start, end) = (range.start_bound(), range.end_bound());
        match (start, end) {
            (Bound::Excluded(s), Bound::Excluded(e)) if s == e => {
                panic!("range start and end are equal and excluded in BTreeMap")
            }
            (Bound::Included(s) | Bound::Excluded(s), Bound::Included(e) | Bound::Excluded(e))
                if s > e =>
            {
                panic!("range start is greater than range end in BTreeMap")
            }
            _ => {}
        }
        let mut lower_bound = SearchBound::from_range(start);
        let mut upper_bound = SearchBound::from_range(end);
        loop {
            let (lower_edge_idx, lower_child_bound) = self.find_lower_bound_index(lower_bound);
            let (upper_edge_idx, upper_child_bound) = self.find_upper_bound_index(upper_bound);
            if lower_edge_idx > upper_edge_idx {
                panic!("Ord is ill-defined in BTreeMap range")
            }
            if lower_edge_idx < upper_edge_idx {
                return Ok((
                    self,
                    lower_edge_idx,
                    upper_edge_idx,
                    lower_child_bound,
                    upper_child_bound,
                ));
            }
            let common_edge = unsafe { Handle::new_edge(self, lower_edge_idx) };
            match common_edge.force() {
                Leaf(common_edge) => return Err(common_edge),
                Internal(common_edge) => {
                    self = common_edge.descend();
                    lower_bound = lower_child_bound;
                    upper_bound = upper_child_bound;
                }
            }
        }
    }

    /// Menemukan edge di node yang membatasi batas bawah rentang.
    /// Juga mengembalikan batas bawah yang akan digunakan untuk melanjutkan pencarian di simpul anak yang cocok, jika `self` adalah simpul internal.
    ///
    ///
    /// Hasilnya hanya bermakna jika pohon diurutkan berdasarkan kunci.
    pub fn find_lower_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_lower_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }

    /// Klon `find_lower_bound_edge` untuk batas atas.
    pub fn find_upper_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_upper_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Mencari kunci tertentu di node, tanpa rekursi.
    /// Mengembalikan `Found` dengan pegangan KV yang cocok, jika ada.
    /// Jika tidak, kembalikan `GoDown` dengan pegangan edge tempat kunci dapat ditemukan (jika node internal) atau tempat kunci dapat dimasukkan.
    ///
    ///
    /// Hasilnya hanya berarti jika pohon diurutkan berdasarkan kunci, seperti pohon di `BTreeMap`.
    ///
    pub fn search_node<Q: ?Sized>(self, key: &Q) -> SearchResult<BorrowType, K, V, Type, Type>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        match self.find_key_index(key) {
            IndexResult::KV(idx) => Found(unsafe { Handle::new_kv(self, idx) }),
            IndexResult::Edge(idx) => GoDown(unsafe { Handle::new_edge(self, idx) }),
        }
    }

    /// Mengembalikan indeks KV di node tempat kunci (atau yang setara) ada, atau indeks edge tempat kunci tersebut berada.
    ///
    ///
    /// Hasilnya hanya berarti jika pohon diurutkan berdasarkan kunci, seperti pohon di `BTreeMap`.
    ///
    fn find_key_index<Q: ?Sized>(&self, key: &Q) -> IndexResult
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        let node = self.reborrow();
        let keys = node.keys();
        for (i, k) in keys.iter().enumerate() {
            match key.cmp(k.borrow()) {
                Ordering::Greater => {}
                Ordering::Equal => return IndexResult::KV(i),
                Ordering::Less => return IndexResult::Edge(i),
            }
        }
        IndexResult::Edge(keys.len())
    }

    /// Menemukan indeks edge di node yang membatasi batas bawah rentang.
    /// Juga mengembalikan batas bawah yang akan digunakan untuk melanjutkan pencarian di simpul anak yang cocok, jika `self` adalah simpul internal.
    ///
    ///
    /// Hasilnya hanya bermakna jika pohon diurutkan berdasarkan kunci.
    fn find_lower_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (0, AllIncluded),
            AllExcluded => (self.len(), AllExcluded),
        }
    }

    /// Klon `find_lower_bound_index` untuk batas atas.
    fn find_upper_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (self.len(), AllIncluded),
            AllExcluded => (0, AllExcluded),
        }
    }
}