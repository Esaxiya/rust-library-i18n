#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Isi dari memori baru tidak diinisialisasi.
    Uninitialized,
    /// Memori baru dijamin nol.
    Zeroed,
}

/// Utilitas tingkat rendah untuk mengalokasikan, mengalokasikan ulang, dan membatalkan alokasi buffer memori di heap secara lebih ergonomis tanpa harus mengkhawatirkan semua kasus sudut yang terlibat.
///
/// Jenis ini sangat baik untuk membangun struktur data Anda sendiri seperti Vec dan VecDeque.
/// Khususnya:
///
/// * Menghasilkan `Unique::dangling()` pada tipe berukuran nol.
/// * Menghasilkan `Unique::dangling()` pada alokasi panjang-nol.
/// * Hindari membebaskan `Unique::dangling()`.
/// * Menangkap semua luapan dalam komputasi kapasitas (mempromosikannya ke "capacity overflow" panics).
/// * Melindungi dari sistem 32-bit yang mengalokasikan lebih dari isize::MAX byte.
/// * Penjaga agar tidak terlalu panjang.
/// * Memanggil `handle_alloc_error` untuk alokasi yang salah.
/// * Berisi `ptr::Unique` dan dengan demikian memberi pengguna semua manfaat terkait.
/// * Menggunakan kelebihan yang dikembalikan dari pengalokasi untuk menggunakan kapasitas terbesar yang tersedia.
///
/// Jenis ini sama sekali tidak memeriksa memori yang dikelolanya.Ketika dijatuhkan *akan* membebaskan memorinya, tetapi *tidak akan* mencoba menjatuhkan isinya.
/// Terserah pengguna `RawVec` untuk menangani hal-hal yang sebenarnya *disimpan* di dalam `RawVec`.
///
/// Perhatikan bahwa kelebihan tipe berukuran nol selalu tidak terbatas, jadi `capacity()` selalu mengembalikan `usize::MAX`.
/// Ini berarti Anda harus berhati-hati saat melakukan bolak-balik jenis ini dengan `Box<[T]>`, karena `capacity()` tidak akan menghasilkan panjangnya.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Ini ada karena `const fn` `#[unstable]` tidak perlu mengikuti `min_const_fn` sehingga mereka juga tidak dapat dipanggil dalam`min_const_fn`.
    ///
    /// Jika Anda mengubah `RawVec<T>::new` atau dependensi, harap berhati-hati untuk tidak memasukkan apa pun yang benar-benar akan melanggar `min_const_fn`.
    ///
    /// NOTE: Kami dapat menghindari peretasan ini dan memeriksa kesesuaian dengan beberapa atribut `#[rustc_force_min_const_fn]` yang memerlukan kesesuaian dengan `min_const_fn` tetapi tidak selalu mengizinkan pemanggilan dalam `stable(...) const fn`/kode pengguna yang tidak mengaktifkan `foo` saat `#[rustc_const_unstable(feature = "foo", issue = "01234")]` ada.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Membuat `RawVec` sebesar mungkin (pada heap sistem) tanpa mengalokasikan.
    /// Jika `T` berukuran positif, maka ini menjadi `RawVec` dengan kapasitas `0`.
    /// Jika `T` berukuran nol, maka dibuatlah `RawVec` dengan kapasitas `usize::MAX`.
    /// Berguna untuk menerapkan alokasi tertunda.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Membuat `RawVec` (pada tumpukan sistem) dengan kapasitas dan persyaratan penyelarasan yang tepat untuk `[T; capacity]`.
    /// Ini sama dengan memanggil `RawVec::new` jika `capacity` adalah `0` atau `T` berukuran nol.
    /// Perhatikan bahwa jika `T` berukuran nol, ini berarti Anda *tidak* akan mendapatkan `RawVec` dengan kapasitas yang diminta.
    ///
    /// # Panics
    ///
    /// Panics jika kapasitas yang diminta melebihi `isize::MAX` byte.
    ///
    /// # Aborts
    ///
    /// Dibatalkan di OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Seperti `with_capacity`, tetapi menjamin buffer di-zero-kan.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Menyusun ulang `RawVec` dari pointer dan kapasitas.
    ///
    /// # Safety
    ///
    /// `ptr` harus dialokasikan (pada heap sistem), dan dengan `capacity` yang diberikan.
    /// `capacity` tidak dapat melebihi `isize::MAX` untuk tipe ukuran.(hanya perhatian pada sistem 32-bit).
    /// ZST vectors mungkin memiliki kapasitas hingga `usize::MAX`.
    /// Jika `ptr` dan `capacity` berasal dari `RawVec`, maka ini dijamin.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Vec kecil itu bodoh.Lewati ke:
    // - 8 jika ukuran elemen adalah 1, karena pengalokasi heap kemungkinan akan mengumpulkan permintaan kurang dari 8 byte menjadi setidaknya 8 byte.
    //
    // - 4 jika elemen berukuran sedang (<=1 KiB).
    // - 1 jika tidak, untuk menghindari membuang terlalu banyak ruang untuk Vec yang sangat pendek.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Seperti `new`, tetapi parameternya melebihi pilihan pengalokasi untuk `RawVec` yang dikembalikan.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` berarti "unallocated".tipe berukuran nol diabaikan.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Seperti `with_capacity`, tetapi parameternya melebihi pilihan pengalokasi untuk `RawVec` yang dikembalikan.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Seperti `with_capacity_zeroed`, tetapi parameternya melebihi pilihan pengalokasi untuk `RawVec` yang dikembalikan.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Mengubah `Box<[T]>` menjadi `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Mengubah seluruh buffer menjadi `Box<[MaybeUninit<T>]>` dengan `len` yang ditentukan.
    ///
    /// Perhatikan bahwa ini akan dengan benar menyusun kembali setiap perubahan `cap` yang mungkin telah dilakukan.(Lihat deskripsi tipe untuk detailnya.)
    ///
    /// # Safety
    ///
    /// * `len` harus lebih besar dari atau sama dengan kapasitas yang paling baru diminta, dan
    /// * `len` harus kurang dari atau sama dengan `self.capacity()`.
    ///
    /// Perhatikan, bahwa kapasitas yang diminta dan `self.capacity()` dapat berbeda, karena pengalokasi dapat secara keseluruhan mencari dan mengembalikan blok memori yang lebih besar daripada yang diminta.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Sanity-periksa setengah dari persyaratan keamanan (kami tidak dapat memeriksa setengah lainnya).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Kami menghindari `unwrap_or_else` di sini karena akan membengkak jumlah LLVM IR yang dihasilkan.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Menyusun ulang `RawVec` dari pointer, kapasitas, dan pengalokasi.
    ///
    /// # Safety
    ///
    /// `ptr` harus dialokasikan (melalui pengalokasi yang diberikan `alloc`), dan dengan `capacity` yang diberikan.
    /// `capacity` tidak dapat melebihi `isize::MAX` untuk tipe ukuran.
    /// (hanya perhatian pada sistem 32-bit).
    /// ZST vectors mungkin memiliki kapasitas hingga `usize::MAX`.
    /// Jika `ptr` dan `capacity` berasal dari `RawVec` yang dibuat melalui `alloc`, maka ini dijamin.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Mendapat pointer mentah ke awal alokasi.
    /// Perhatikan bahwa ini adalah `Unique::dangling()` jika `capacity == 0` atau `T` berukuran nol.
    /// Dalam kasus pertama, Anda harus berhati-hati.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Mendapat kapasitas alokasi.
    ///
    /// Ini akan selalu menjadi `usize::MAX` jika `T` berukuran nol.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Mengembalikan referensi bersama ke pengalokasi yang mendukung `RawVec` ini.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Kami memiliki potongan memori yang dialokasikan, sehingga kami dapat melewati pemeriksaan runtime untuk mendapatkan tata letak kami saat ini.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Pastikan buffer berisi setidaknya cukup ruang untuk menampung elemen `len + additional`.
    /// Jika belum memiliki kapasitas yang cukup, akan mengalokasikan kembali ruang yang cukup ditambah ruang kendur yang nyaman untuk mendapatkan perilaku *O*(1) yang diamortisasi.
    ///
    /// Akan membatasi perilaku ini jika tidak perlu menyebabkan dirinya sendiri ke panic.
    ///
    /// Jika `len` melebihi `self.capacity()`, ini mungkin gagal untuk mengalokasikan ruang yang diminta.
    /// Ini sebenarnya tidak tidak aman, tetapi kode tidak aman *yang Anda* tulis yang bergantung pada perilaku fungsi ini dapat rusak.
    ///
    /// Ini sangat ideal untuk mengimplementasikan operasi dorong massal seperti `extend`.
    ///
    /// # Panics
    ///
    /// Panics jika kapasitas baru melebihi `isize::MAX` byte.
    ///
    /// # Aborts
    ///
    /// Dibatalkan di OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // cadangan akan dibatalkan atau panik jika len melebihi `isize::MAX` jadi ini aman untuk dilakukan sekarang.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// Sama seperti `reserve`, tetapi mengembalikan kesalahan alih-alih panik atau membatalkan.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Pastikan buffer berisi setidaknya cukup ruang untuk menampung elemen `len + additional`.
    /// Jika belum, akan mengalokasikan kembali jumlah minimum memori yang diperlukan.
    /// Umumnya ini akan menjadi jumlah memori yang diperlukan, tetapi pada prinsipnya pengalokasi bebas untuk memberikan kembali lebih dari yang kami minta.
    ///
    ///
    /// Jika `len` melebihi `self.capacity()`, ini mungkin gagal untuk mengalokasikan ruang yang diminta.
    /// Ini sebenarnya tidak tidak aman, tetapi kode tidak aman *yang Anda* tulis yang bergantung pada perilaku fungsi ini dapat rusak.
    ///
    /// # Panics
    ///
    /// Panics jika kapasitas baru melebihi `isize::MAX` byte.
    ///
    /// # Aborts
    ///
    /// Dibatalkan di OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// Sama seperti `reserve_exact`, tetapi mengembalikan kesalahan alih-alih panik atau membatalkan.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Persempit alokasi ke jumlah yang ditentukan.
    /// Jika jumlah yang diberikan adalah 0, sebenarnya mengalokasikan sepenuhnya.
    ///
    /// # Panics
    ///
    /// Panics jika jumlah yang diberikan *lebih besar* dari kapasitas saat ini.
    ///
    /// # Aborts
    ///
    /// Dibatalkan di OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Mengembalikan jika buffer perlu berkembang untuk memenuhi kapasitas ekstra yang dibutuhkan.
    /// Terutama digunakan untuk membuat panggilan cadangan sebaris tanpa sebariskan `grow`.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Metode ini biasanya dipakai berkali-kali.Jadi kami ingin membuatnya sekecil mungkin, untuk meningkatkan waktu kompilasi.
    // Tetapi kami juga ingin sebanyak mungkin isinya dapat dihitung secara statis, untuk membuat kode yang dihasilkan berjalan lebih cepat.
    // Oleh karena itu, metode ini ditulis dengan hati-hati sehingga semua kode yang bergantung pada `T` ada di dalamnya, sementara sebanyak mungkin kode yang tidak bergantung pada `T` ada dalam fungsi yang tidak umum di atas `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Ini dijamin oleh konteks panggilan.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Karena kami mengembalikan kapasitas `usize::MAX` saat `elem_size` adalah
            // 0, sampai ke sini berarti `RawVec` terlalu penuh.
            return Err(CapacityOverflow);
        }

        // Sayangnya, tidak ada yang benar-benar dapat kami lakukan tentang pemeriksaan ini.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Ini menjamin pertumbuhan eksponensial.
        // Penggandaan tidak dapat meluap karena `cap <= isize::MAX` dan tipe `cap` adalah `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` bersifat non-generik di atas `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Batasan pada metode ini hampir sama dengan yang ada di `grow_amortized`, tetapi metode ini biasanya lebih jarang dipakai sehingga kurang kritis.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Karena kami mengembalikan kapasitas `usize::MAX` saat ukuran jenisnya
            // 0, sampai ke sini berarti `RawVec` terlalu penuh.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` bersifat non-generik di atas `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Fungsi ini di luar `RawVec` untuk meminimalkan waktu kompilasi.Lihat komentar `RawVec::grow_amortized` di atas untuk detailnya.
// (Parameter `A` tidak signifikan, karena jumlah jenis `A` berbeda yang terlihat dalam praktik jauh lebih kecil daripada jumlah jenis `T`.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Periksa kesalahan di sini untuk meminimalkan ukuran `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Pengalokasi memeriksa kesetaraan keselarasan
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Membebaskan memori yang dimiliki oleh `RawVec`*tanpa* mencoba menjatuhkan isinya.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Fungsi sentral untuk penanganan kesalahan cadangan.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Kami perlu menjamin yang berikut:
// * Kami tidak pernah mengalokasikan objek berukuran byte `> isize::MAX`.
// * Kami tidak membanjiri `usize::MAX` dan sebenarnya mengalokasikan terlalu sedikit.
//
// Pada 64-bit kita hanya perlu memeriksa overflow karena mencoba mengalokasikan byte `> isize::MAX` pasti akan gagal.
// Pada 32-bit dan 16-bit kita perlu menambahkan pelindung ekstra untuk ini jika kita menjalankan platform yang dapat menggunakan semua 4GB di ruang pengguna, misalnya, PAE atau x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Satu fungsi pusat yang bertanggung jawab untuk melaporkan kelebihan kapasitas.
// Ini akan memastikan bahwa pembuatan kode yang terkait dengan panics ini minimal karena hanya ada satu lokasi di mana panics daripada banyak di seluruh modul.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}