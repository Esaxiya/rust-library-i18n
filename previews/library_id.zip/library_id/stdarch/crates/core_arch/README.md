`core::arch` - Intrinsik khusus arsitektur pustaka inti Rust
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

Modul `core::arch` mengimplementasikan intrinsik yang bergantung pada arsitektur (misalnya SIMD).

# Usage 

`core::arch` tersedia sebagai bagian dari `libcore` dan diekspor ulang oleh `libstd`.Lebih suka menggunakannya melalui `core::arch` atau `std::arch` daripada melalui crate ini.
Fitur tidak stabil sering tersedia di Rust setiap malam melalui `feature(stdsimd)`.

Menggunakan `core::arch` melalui crate ini membutuhkan Rust setiap malam, dan dapat (dan memang) sering rusak.Satu-satunya kasus di mana Anda harus mempertimbangkan untuk menggunakannya melalui crate ini adalah:

* jika Anda perlu mengkompilasi ulang `core::arch` sendiri, misalnya dengan mengaktifkan fitur target tertentu yang tidak diaktifkan untuk `libcore`/`libstd`.
Note: jika Anda perlu mengkompilasi ulang untuk target non-standar, silakan gunakan `xargo` dan kompilasi ulang `libcore`/`libstd` sebagaimana mestinya daripada menggunakan crate ini.
  
* menggunakan beberapa fitur yang mungkin tidak tersedia bahkan di belakang fitur Rust yang tidak stabil.Kami berusaha meminimalkannya.
Jika Anda perlu menggunakan beberapa fitur ini, buka masalah sehingga kami dapat mengeksposnya di Rust setiap malam dan Anda dapat menggunakannya dari sana.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` didistribusikan terutama di bawah persyaratan lisensi MIT dan Lisensi Apache (Versi 2.0), dengan bagian-bagian yang dicakup oleh berbagai lisensi serupa BSD.

Lihat LICENSE-APACHE, dan LICENSE-MIT untuk detailnya.

# Contribution

Kecuali Anda secara eksplisit menyatakan sebaliknya, kontribusi apa pun yang dengan sengaja dikirimkan untuk dimasukkan ke dalam `core_arch` oleh Anda, sebagaimana didefinisikan dalam lisensi Apache-2.0, akan memiliki lisensi ganda seperti di atas, tanpa syarat atau ketentuan tambahan.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












