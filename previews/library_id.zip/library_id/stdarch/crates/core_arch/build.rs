use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Digunakan untuk memberi tahu anotasi `#[assert_instr]` kami bahwa semua intrinsik simd tersedia untuk menguji codegen mereka, karena beberapa diberi gerbang di belakang `-Ctarget-feature=+unimplemented-simd128` tambahan yang tidak memiliki padanan di `#[target_feature]` sekarang.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}