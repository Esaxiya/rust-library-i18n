# Berkontribusi pada stdarch

`stdarch` crate lebih dari bersedia untuk menerima kontribusi!Pertama, Anda mungkin ingin memeriksa repositori dan memastikan bahwa tes berhasil untuk Anda:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Di mana `<your-target-arch>` adalah triple target seperti yang digunakan oleh `rustup`, misalnya `x86_x64-unknown-linux-gnu` (tanpa `nightly-` sebelumnya atau serupa).
Juga ingat bahwa repositori ini membutuhkan saluran malam Rust!
Tes di atas sebenarnya membutuhkan rust setiap malam untuk menjadi default di sistem Anda, untuk mengatur agar gunakan `rustup default nightly` (dan `rustup default stable` untuk mengembalikan).

Jika salah satu langkah di atas tidak berhasil, [please let us know][new]!

Selanjutnya Anda dapat [find an issue][issues] untuk membantu, kami telah memilih beberapa dengan tag [`help wanted`][help] dan [`impl-period`][impl] yang secara khusus dapat menggunakan beberapa bantuan. 
Anda mungkin paling tertarik dengan [#40][vendor], yang menerapkan semua intrinsik vendor di x86.Masalah itu memiliki beberapa petunjuk bagus tentang dari mana harus memulai!

Jika Anda memiliki pertanyaan umum, silakan ke [join us on gitter][gitter] dan bertanyalah!Jangan ragu untuk melakukan ping ke@BurntSushi atau@alexcrichton jika ada pertanyaan.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Bagaimana menulis contoh untuk stdarch intrinsics

Ada beberapa fitur yang harus diaktifkan agar intrinsik yang diberikan berfungsi dengan baik dan contohnya hanya boleh dijalankan oleh `cargo test --doc` jika fitur tersebut didukung oleh CPU.

Akibatnya, `fn main` default yang dibuat oleh `rustdoc` tidak akan berfungsi (dalam banyak kasus).
Pertimbangkan untuk menggunakan yang berikut ini sebagai panduan untuk memastikan contoh Anda berfungsi seperti yang diharapkan.

```rust
/// # // Kami membutuhkan cfg_target_feature untuk memastikan bahwa contohnya saja
/// # // dijalankan oleh `cargo test --doc` jika CPU mendukung fitur tersebut
/// # #![feature(cfg_target_feature)]
/// # // Kami membutuhkan target_feature agar intrinsik berfungsi
/// # #![feature(target_feature)]
/// #
/// # // rustdoc secara default menggunakan `extern crate stdarch`, tetapi kami membutuhkan file
/// # // `#[macro_use]`
/// # # [macro_use] extern crate stdarch;
/// #
/// # // Fungsi utama sebenarnya
/// # fn main() {
/// #     // Jalankan ini hanya jika `<target feature>` didukung
/// #     jika cfg_feature_enabled! ("<target feature>"){
/// #         // Buat fungsi `worker` yang hanya akan dijalankan jika fitur target
/// #         // didukung dan memastikan bahwa `target_feature` diaktifkan untuk pekerja Anda
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         tidak aman fn worker() {
/// // Tulis contoh Anda di sini.Fitur intrinsik khusus akan bekerja di sini!Liar!
///
/// #         }
///
/// #         { worker(); } tidak aman
/// #     }
/// # }
```

Jika beberapa sintaks di atas tidak terlihat familiar, bagian [Documentation as tests] dari [Rust Book] mendeskripsikan sintaks `rustdoc` dengan cukup baik.
Seperti biasa, silakan ke [join us on gitter][gitter] dan tanyakan kepada kami jika Anda menemui hambatan, dan terima kasih telah membantu meningkatkan dokumentasi `stdarch`!

# Instruksi Pengujian Alternatif

Umumnya disarankan agar Anda menggunakan `ci/run.sh` untuk menjalankan pengujian.
Namun ini mungkin tidak berhasil untuk Anda, misalnya jika Anda menggunakan Windows.

Dalam hal ini, Anda dapat kembali menjalankan `cargo +nightly test` dan `cargo +nightly test --release -p core_arch` untuk menguji pembuatan kode.
Perhatikan bahwa ini membutuhkan toolchain nightly untuk diinstal dan agar `rustc` mengetahui tentang triple target Anda dan CPU-nya.
Secara khusus, Anda perlu menyetel variabel lingkungan `TARGET` seperti yang Anda lakukan untuk `ci/run.sh`.
Selain itu, Anda perlu menyetel `RUSTCFLAGS` (memerlukan `C`) untuk menunjukkan fitur target, mis `RUSTCFLAGS="-C -target-features=+avx2"`.
Anda juga dapat mengatur `-C -target-cpu=native` jika Anda mengembangkan "just" terhadap CPU Anda saat ini.

Berhati-hatilah saat Anda menggunakan instruksi alternatif ini, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], mis
tes generasi instruksi mungkin gagal karena disassembler menamainya berbeda, misalnya
itu mungkin menghasilkan instruksi `vaesenc` daripada `aesenc` meskipun mereka berperilaku sama.
Juga instruksi ini menjalankan tes yang lebih sedikit daripada yang biasanya dilakukan, jadi jangan heran ketika Anda akhirnya melakukan pull-request beberapa kesalahan mungkin muncul untuk tes yang tidak dibahas di sini.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






