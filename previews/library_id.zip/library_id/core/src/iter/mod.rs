//! Iterasi eksternal yang dapat disusun.
//!
//! Jika Anda menemukan diri Anda dengan koleksi dari beberapa jenis, dan perlu melakukan operasi pada elemen koleksi tersebut, Anda akan segera mengalami 'iterators'.
//! Iterator banyak digunakan dalam kode Rust idiomatik, jadi ada baiknya Anda memahaminya.
//!
//! Sebelum menjelaskan lebih lanjut, mari kita bahas tentang bagaimana modul ini disusun:
//!
//! # Organization
//!
//! Modul ini sebagian besar diatur berdasarkan jenis:
//!
//! * [Traits] adalah bagian intinya: traits ini menentukan jenis iterator yang ada dan apa yang dapat Anda lakukan dengannya.Metode traits ini layak digunakan untuk waktu belajar tambahan.
//! * [Functions] menyediakan beberapa cara berguna untuk membuat beberapa iterator dasar.
//! * [Structs] sering kali merupakan jenis kembalian dari berbagai metode pada traits modul ini.Anda biasanya ingin melihat metode yang membuat `struct`, daripada `struct` itu sendiri.
//! Untuk detail selengkapnya tentang alasannya, lihat '[Menerapkan Iterator](#implement-iterator)'.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Itu dia!Mari kita gali iterator.
//!
//! # Iterator
//!
//! Inti dan jiwa dari modul ini adalah [`Iterator`] trait.Inti dari [`Iterator`] terlihat seperti ini:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Sebuah iterator memiliki sebuah metode, [`next`], yang ketika dipanggil, mengembalikan sebuah [`Option`]`<Item>`.
//! [`next`] akan mengembalikan [`Some(Item)`] selama masih ada elemen, dan setelah semuanya habis, akan mengembalikan `None` untuk menunjukkan bahwa iterasi telah selesai.
//! Masing-masing iterator dapat memilih untuk melanjutkan iterasi, sehingga memanggil [`next`] lagi mungkin atau mungkin tidak pada akhirnya mulai mengembalikan [`Some(Item)`] lagi di beberapa titik (misalnya, lihat [`TryIter`]).
//!
//!
//! Definisi lengkap [`Iterator`] menyertakan sejumlah metode lain juga, tetapi mereka adalah metode default, dibangun di atas [`next`], sehingga Anda mendapatkannya secara gratis.
//!
//! Iterator juga dapat disusun, dan biasanya menggabungkan keduanya untuk melakukan bentuk pemrosesan yang lebih kompleks.Lihat bagian [Adapters](#adapters) di bawah untuk lebih jelasnya.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Tiga bentuk iterasi
//!
//! Ada tiga metode umum yang dapat membuat iterator dari koleksi:
//!
//! * `iter()`, yang beriterasi di atas `&T`.
//! * `iter_mut()`, yang beriterasi di atas `&mut T`.
//! * `into_iter()`, yang beriterasi di atas `T`.
//!
//! Berbagai hal di pustaka standar dapat menerapkan satu atau lebih dari ketiganya, jika sesuai.
//!
//! # Menerapkan Iterator
//!
//! Membuat iterator Anda sendiri melibatkan dua langkah: membuat `struct` untuk menahan status iterator, dan kemudian mengimplementasikan [`Iterator`] untuk `struct` tersebut.
//! Inilah sebabnya mengapa ada begitu banyak `struct` dalam modul ini: ada satu untuk setiap iterator dan adaptor iterator.
//!
//! Mari kita buat iterator bernama `Counter` yang dihitung dari `1` ke `5`:
//!
//! ```
//! // Pertama, struct:
//!
//! /// Sebuah iterator yang menghitung dari satu sampai lima
//! struct Counter {
//!     count: usize,
//! }
//!
//! // kami ingin hitungan kami dimulai dari satu, jadi mari tambahkan metode new() untuk membantu.
//! // Ini tidak sepenuhnya diperlukan, tetapi nyaman.
//! // Perhatikan bahwa kita memulai `count` dari nol, kita akan melihat alasannya dalam implementasi `next()`'s di bawah ini.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Kemudian, kami menerapkan `Iterator` untuk `Counter` kami:
//!
//! impl Iterator for Counter {
//!     // kami akan menghitung dengan menggunakan
//!     type Item = usize;
//!
//!     // next() adalah satu-satunya metode yang diperlukan
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Tingkatkan hitungan kami.Inilah mengapa kami memulai dari nol.
//!         self.count += 1;
//!
//!         // Periksa apakah kita sudah selesai menghitung atau belum.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // Dan sekarang kita bisa menggunakannya!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Memanggil [`next`] dengan cara ini menjadi berulang.Rust memiliki konstruksi yang dapat memanggil [`next`] pada iterator Anda, hingga mencapai `None`.Mari kita bahas selanjutnya.
//!
//! Perhatikan juga bahwa `Iterator` menyediakan implementasi default metode seperti `nth` dan `fold` yang memanggil `next` secara internal.
//! Namun, dimungkinkan juga untuk menulis implementasi kustom dari metode seperti `nth` dan `fold` jika iterator dapat menghitungnya dengan lebih efisien tanpa memanggil `next`.
//!
//! # `for` loop dan `IntoIterator`
//!
//! Sintaks loop `for` Rust sebenarnya adalah gula untuk iterator.Berikut contoh dasar `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Ini akan mencetak nomor satu sampai lima, masing-masing pada barisnya sendiri.Tetapi Anda akan melihat sesuatu di sini: kami tidak pernah memanggil apa pun di vector kami untuk menghasilkan iterator.Apa yang memberi?
//!
//! Ada trait di pustaka standar untuk mengubah sesuatu menjadi iterator: [`IntoIterator`].
//! trait ini memiliki satu metode, [`into_iter`], yang mengubah hal yang mengimplementasikan [`IntoIterator`] menjadi iterator.
//! Mari kita lihat loop `for` itu lagi, dan kompilator mengubahnya menjadi:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust menghilangkan gula ini menjadi:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Pertama, kami memanggil `into_iter()` pada nilainya.Kemudian, kami mencocokkan iterator yang kembali, memanggil [`next`] berulang kali hingga kami melihat `None`.
//! Pada titik itu, kami `break` keluar dari loop, dan kami selesai melakukan iterasi.
//!
//! Ada satu hal lagi di sini: pustaka standar berisi implementasi [`IntoIterator`] yang menarik:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Dengan kata lain, semua [`Iterator`] mengimplementasikan [`IntoIterator`], hanya dengan mengembalikan dirinya sendiri.Ini berarti dua hal:
//!
//! 1. Jika Anda menulis [`Iterator`], Anda dapat menggunakannya dengan loop `for`.
//! 2. Jika Anda membuat koleksi, menerapkan [`IntoIterator`] untuknya akan memungkinkan koleksi Anda digunakan dengan loop `for`.
//!
//! # Iterasi dengan referensi
//!
//! Karena [`into_iter()`] mengambil `self` berdasarkan nilai, menggunakan perulangan `for` untuk mengulang koleksi akan menghabiskan koleksi tersebut.Seringkali, Anda mungkin ingin mengulang koleksi tanpa mengonsumsinya.
//! Banyak koleksi menawarkan metode yang menyediakan iterator di atas referensi, secara konvensional disebut `iter()` dan `iter_mut()`:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` masih dimiliki oleh fungsi ini.
//! ```
//!
//! Jika tipe kumpulan `C` menyediakan `iter()`, biasanya juga mengimplementasikan `IntoIterator` untuk `&C`, dengan implementasi yang hanya memanggil `iter()`.
//! Demikian pula, kumpulan `C` yang menyediakan `iter_mut()` umumnya mengimplementasikan `IntoIterator` untuk `&mut C` dengan mendelegasikannya ke `iter_mut()`.Ini memungkinkan penyingkatan yang nyaman:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // sama seperti `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // sama seperti `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Meskipun banyak koleksi menawarkan `iter()`, tidak semua menawarkan `iter_mut()`.
//! Misalnya, mengubah kunci [`HashSet<T>`] atau [`HashMap<K, V>`] dapat membuat koleksi menjadi tidak konsisten jika hash kunci berubah, jadi koleksi ini hanya menawarkan `iter()`.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Fungsi yang menggunakan [`Iterator`] dan mengembalikan [`Iterator`] lain sering disebut 'adaptor iterator', karena merupakan bentuk 'adaptor
//! pattern'.
//!
//! Adaptor iterator umum termasuk [`map`], [`take`], dan [`filter`].
//! Untuk lebih lanjut, lihat dokumentasinya.
//!
//! Jika adaptor iterator panics, iterator akan berada dalam status tidak ditentukan (tetapi aman memori).
//! Status ini juga tidak dijamin akan tetap sama di semua versi Rust, jadi Anda harus menghindari mengandalkan nilai persis yang dikembalikan oleh iterator yang panik.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Iterator (dan iterator [adapters](#adapters))*malas*. Artinya, membuat iterator saja tidak banyak _do_. Tidak ada yang benar-benar terjadi sampai Anda memanggil [`next`].
//! Ini terkadang menjadi sumber kebingungan saat membuat iterator hanya untuk efek sampingnya.
//! Misalnya, metode [`map`] memanggil penutupan pada setiap elemen yang diiterasi:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Ini tidak akan mencetak nilai apa pun, karena kami hanya membuat iterator, daripada menggunakannya.Kompilator akan memperingatkan kita tentang perilaku seperti ini:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Cara idiomatis untuk menulis [`map`] untuk efek sampingnya adalah dengan menggunakan loop `for` atau memanggil metode [`for_each`]:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Cara umum lainnya untuk mengevaluasi iterator adalah dengan menggunakan metode [`collect`] untuk menghasilkan koleksi baru.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Iterator tidak harus terbatas.Sebagai contoh, rentang terbuka adalah iterator tak terbatas:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Biasanya menggunakan adaptor iterator [`take`] untuk mengubah iterator tak terbatas menjadi iterator terbatas:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Ini akan mencetak nomor `0` hingga `4`, masing-masing pada barisnya sendiri.
//!
//! Ingatlah bahwa metode pada iterator tak hingga, bahkan yang hasilnya dapat ditentukan secara matematis dalam waktu yang terbatas, tidak dapat dihentikan.
//! Secara khusus, metode seperti [`min`], yang dalam kasus umum memerlukan traverse setiap elemen di iterator, kemungkinan besar tidak berhasil mengembalikan iterator tak terbatas apa pun.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Oh tidak!Lingkaran tanpa batas!
//! // `ones.min()` menyebabkan putaran tak terbatas, jadi kami tidak akan mencapai titik ini!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;