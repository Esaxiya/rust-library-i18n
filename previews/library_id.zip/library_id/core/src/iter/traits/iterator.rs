// ignore-tidy-filelength File ini hampir secara eksklusif terdiri dari definisi `Iterator`.
// Kami tidak dapat membaginya menjadi beberapa file.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// Antarmuka untuk menangani iterator.
///
/// Ini adalah iterator utama trait.
/// Untuk lebih lanjut tentang konsep iterator secara umum, silakan lihat [module-level documentation].
/// Secara khusus, Anda mungkin ingin tahu cara [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// Jenis elemen yang diiterasi.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Memajukan iterator dan mengembalikan nilai berikutnya.
    ///
    /// Mengembalikan [`None`] saat iterasi selesai.
    /// Implementasi iterator individual dapat memilih untuk melanjutkan iterasi, sehingga memanggil `next()` lagi mungkin atau mungkin tidak pada akhirnya mulai mengembalikan [`Some(Item)`] lagi di beberapa titik.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // Panggilan ke next() mengembalikan nilai berikutnya ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... dan kemudian Tidak ada setelah selesai.
    /// assert_eq!(None, iter.next());
    ///
    /// // Lebih banyak panggilan mungkin atau mungkin tidak mengembalikan `None`.Di sini, mereka akan selalu begitu.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Mengembalikan batas pada sisa panjang iterator.
    ///
    /// Secara khusus, `size_hint()` mengembalikan tupel di mana elemen pertama adalah batas bawah, dan elemen kedua adalah batas atas.
    ///
    /// Paruh kedua tupel yang dikembalikan adalah [`Option`]`<`[`usize`] `>`.
    /// [`None`] di sini berarti tidak ada batas atas yang diketahui, atau batas atas lebih besar dari [`usize`].
    ///
    /// # Catatan implementasi
    ///
    /// Tidak dipaksakan bahwa implementasi iterator menghasilkan jumlah elemen yang dideklarasikan.Sebuah iterator buggy mungkin menghasilkan kurang dari batas bawah atau lebih dari batas atas elemen.
    ///
    /// `size_hint()` terutama dimaksudkan untuk digunakan untuk pengoptimalan seperti menyediakan ruang untuk elemen iterator, tetapi tidak boleh dipercaya, misalnya, menghilangkan pemeriksaan batas dalam kode yang tidak aman.
    /// Implementasi `size_hint()` yang salah seharusnya tidak menyebabkan pelanggaran keamanan memori.
    ///
    /// Oleh karena itu, penerapannya harus memberikan perkiraan yang benar, karena jika tidak maka akan melanggar protokol trait.
    ///
    /// Implementasi default mengembalikan `(0,` [`None`]`)`yang benar untuk iterator mana pun.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// Contoh yang lebih kompleks:
    ///
    /// ```
    /// // Angka genap dari nol sampai sepuluh.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Kami mungkin mengulang dari nol hingga sepuluh kali.
    /// // Mengetahui bahwa lima persisnya tidak akan mungkin tanpa menjalankan filter().
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Mari tambahkan lima angka lagi dengan chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // sekarang kedua batas ditambah lima
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Mengembalikan `None` untuk batas atas:
    ///
    /// ```
    /// // iterator tak terbatas tidak memiliki batas atas dan batas bawah maksimum yang memungkinkan
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Mengkonsumsi iterator, menghitung jumlah iterasi dan mengembalikannya.
    ///
    /// Metode ini akan memanggil [`next`] berulang kali hingga [`None`] ditemukan, mengembalikan berapa kali [`Some`] dilihat.
    /// Perhatikan bahwa [`next`] harus dipanggil setidaknya sekali meskipun iterator tidak memiliki elemen apa pun.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Perilaku Melimpah
    ///
    /// Metode ini tidak melindungi overflow, jadi menghitung elemen iterator dengan lebih dari [`usize::MAX`] elemen akan menghasilkan hasil yang salah atau panics.
    ///
    /// Jika pernyataan debug diaktifkan, panic dijamin.
    ///
    /// # Panics
    ///
    /// Fungsi ini mungkin panic jika iterator memiliki lebih dari [`usize::MAX`] elemen.
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Mengkonsumsi iterator, mengembalikan elemen terakhir.
    ///
    /// Metode ini akan mengevaluasi iterator hingga mengembalikan [`None`].
    /// Saat melakukannya, itu melacak elemen saat ini.
    /// Setelah [`None`] dikembalikan, `last()` akan mengembalikan elemen terakhir yang dilihatnya.
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Memajukan iterator dengan elemen `n`.
    ///
    /// Metode ini dengan bersemangat akan melewati elemen `n` dengan memanggil [`next`] hingga `n` kali hingga [`None`] ditemukan.
    ///
    /// `advance_by(n)` akan mengembalikan [`Ok(())`][Ok] jika iterator berhasil memajukan elemen `n`, atau [`Err(k)`][Err] jika [`None`] ditemukan, di mana `k` adalah jumlah elemen yang dimajukan oleh iterator sebelum kehabisan elemen (mis.
    /// panjang iterator).
    /// Perhatikan bahwa `k` selalu lebih kecil dari `n`.
    ///
    /// Memanggil `advance_by(0)` tidak mengonsumsi elemen apa pun dan selalu mengembalikan [`Ok(())`][Ok].
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // hanya `&4` yang dilewati
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Mengembalikan elemen `n` dari iterator.
    ///
    /// Seperti kebanyakan operasi pengindeksan, hitungan dimulai dari nol, jadi `nth(0)` mengembalikan nilai pertama, `nth(1)` kedua, dan seterusnya.
    ///
    /// Perhatikan bahwa semua elemen sebelumnya, serta elemen yang dikembalikan, akan dipakai dari iterator.
    /// Itu berarti elemen sebelumnya akan dibuang, dan juga memanggil `nth(0)` beberapa kali pada iterator yang sama akan mengembalikan elemen yang berbeda.
    ///
    ///
    /// `nth()` akan mengembalikan [`None`] jika `n` lebih besar dari atau sama dengan panjang iterator.
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Memanggil `nth()` beberapa kali tidak memundurkan iterator:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Mengembalikan `None` jika ada kurang dari `n + 1` elemen:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Membuat iterator yang dimulai pada titik yang sama, tetapi melangkah dengan jumlah yang ditentukan di setiap iterasi.
    ///
    /// Catatan 1: Elemen pertama dari iterator akan selalu dikembalikan, terlepas dari langkah yang diberikan.
    ///
    /// Catatan 2: Waktu penarikan elemen yang diabaikan tidak tetap.
    /// `StepBy` berperilaku seperti urutan `next(), nth(step-1), nth(step-1),…`, tetapi juga bebas berperilaku seperti urutan
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Cara mana yang digunakan dapat berubah untuk beberapa iterator karena alasan kinerja.
    /// Cara kedua akan memajukan iterator lebih awal dan dapat mengonsumsi lebih banyak item.
    ///
    /// `advance_n_and_return_first` setara dengan:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// Metode akan panic jika langkah yang diberikan adalah `0`.
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Mengambil dua iterator dan membuat iterator baru di atas keduanya secara berurutan.
    ///
    /// `chain()` akan mengembalikan iterator baru yang akan mengiterasi nilai-nilai dari iterator pertama terlebih dahulu dan kemudian di atas nilai-nilai dari iterator kedua.
    ///
    /// Dengan kata lain, ini menghubungkan dua iterator bersama, dalam satu rantai.🔗
    ///
    /// [`once`] biasanya digunakan untuk mengadaptasi nilai tunggal ke dalam rantai jenis iterasi lainnya.
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Karena argumen ke `chain()` menggunakan [`IntoIterator`], kita dapat meneruskan apa pun yang dapat diubah menjadi [`Iterator`], bukan hanya [`Iterator`] itu sendiri.
    /// Misalnya, slice (`&[T]`) mengimplementasikan [`IntoIterator`], sehingga dapat diteruskan ke `chain()` secara langsung:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Jika Anda bekerja dengan Windows API, Anda mungkin ingin mengubah [`OsStr`] ke `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// 'Zip up' dua iterator menjadi satu iterator berpasangan.
    ///
    /// `zip()` mengembalikan iterator baru yang akan melakukan iterasi pada dua iterator lainnya, mengembalikan tupel di mana elemen pertama berasal dari iterator pertama, dan elemen kedua berasal dari iterator kedua.
    ///
    ///
    /// Dengan kata lain, ini menggabungkan dua iterator menjadi satu.
    ///
    /// Jika salah satu iterator mengembalikan [`None`], [`next`] dari iterator zip akan mengembalikan [`None`].
    /// Jika iterator pertama mengembalikan [`None`], `zip` akan mengalami korsleting dan `next` tidak akan dipanggil pada iterator kedua.
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Karena argumen ke `zip()` menggunakan [`IntoIterator`], kita dapat meneruskan apa pun yang dapat diubah menjadi [`Iterator`], bukan hanya [`Iterator`] itu sendiri.
    /// Misalnya, slice (`&[T]`) mengimplementasikan [`IntoIterator`], sehingga dapat diteruskan ke `zip()` secara langsung:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` sering digunakan untuk meng-zip iterator tak terbatas ke yang terbatas.
    /// Ini berfungsi karena iterator terbatas pada akhirnya akan mengembalikan [`None`], mengakhiri ritsleting.Membuat zip dengan `(0..)` sangat mirip dengan [`enumerate`]:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Membuat iterator baru yang menempatkan salinan `separator` di antara item yang berdekatan dari iterator asli.
    ///
    /// Jika `separator` tidak mengimplementasikan [`Clone`] atau perlu dihitung setiap saat, gunakan [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // Elemen pertama dari `a`.
    /// assert_eq!(a.next(), Some(&100)); // Pemisah.
    /// assert_eq!(a.next(), Some(&1));   // Elemen berikutnya dari `a`.
    /// assert_eq!(a.next(), Some(&100)); // Pemisah.
    /// assert_eq!(a.next(), Some(&2));   // Elemen terakhir dari `a`.
    /// assert_eq!(a.next(), None);       // Iterator selesai.
    /// ```
    ///
    /// `intersperse` bisa sangat berguna untuk menggabungkan item iterator menggunakan elemen umum:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Membuat iterator baru yang menempatkan item yang dihasilkan oleh `separator` di antara item yang berdekatan dari iterator asli.
    ///
    /// Penutupan akan dipanggil tepat sekali setiap kali item ditempatkan di antara dua item yang berdekatan dari iterator yang mendasari;
    /// khususnya, closure tidak dipanggil jika iterator yang mendasari menghasilkan kurang dari dua item dan setelah item terakhir dihasilkan.
    ///
    ///
    /// Jika item iterator mengimplementasikan [`Clone`], mungkin lebih mudah untuk menggunakan [`intersperse`].
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // Elemen pertama dari `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Pemisah.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // Elemen berikutnya dari `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Pemisah.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // Elemen terakhir dari `v`.
    /// assert_eq!(it.next(), None);               // Iterator selesai.
    /// ```
    ///
    /// `intersperse_with` dapat digunakan dalam situasi di mana pemisah perlu dihitung:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // Closure meminjam konteksnya untuk menghasilkan item.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Mengambil closure dan membuat iterator yang memanggil closure tersebut pada setiap elemen.
    ///
    /// `map()` mengubah satu iterator menjadi yang lain, melalui argumennya:
    /// sesuatu yang mengimplementasikan [`FnMut`].Ini menghasilkan iterator baru yang memanggil closure ini pada setiap elemen dari iterator asli.
    ///
    /// Jika Anda pandai berpikir dalam tipe, Anda dapat memikirkan `map()` seperti ini:
    /// Jika Anda memiliki iterator yang memberi Anda elemen dari beberapa tipe `A`, dan Anda menginginkan iterator dari beberapa tipe `B` lainnya, Anda dapat menggunakan `map()`, meneruskan closure yang mengambil `A` dan mengembalikan `B`.
    ///
    ///
    /// `map()` secara konseptual mirip dengan loop [`for`].Namun, karena `map()` malas, paling baik digunakan saat Anda sudah bekerja dengan iterator lain.
    /// Jika Anda melakukan semacam perulangan untuk efek samping, itu dianggap lebih idiomatis untuk menggunakan [`for`] daripada `map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Jika Anda melakukan semacam efek samping, pilih [`for`] daripada `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // jangan lakukan ini:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // itu bahkan tidak akan mengeksekusi, karena malas.Rust akan memperingatkan Anda tentang ini.
    ///
    /// // Sebagai gantinya, gunakan untuk:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Memanggil penutupan pada setiap elemen iterator.
    ///
    /// Ini sama dengan menggunakan loop [`for`] pada iterator, meskipun `break` dan `continue` tidak dimungkinkan dari penutupan.
    /// Biasanya lebih idiomatis menggunakan loop `for`, tetapi `for_each` mungkin lebih terbaca saat memproses item di akhir rantai iterator yang lebih panjang.
    ///
    /// Dalam beberapa kasus, `for_each` mungkin juga lebih cepat daripada loop, karena akan menggunakan iterasi internal pada adaptor seperti `Chain`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// Untuk contoh sekecil itu, loop `for` mungkin lebih bersih, tetapi `for_each` mungkin lebih baik untuk mempertahankan gaya fungsional dengan iterator yang lebih panjang:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Membuat iterator yang menggunakan closure untuk menentukan apakah sebuah elemen harus dihasilkan.
    ///
    /// Dengan adanya elemen, closure harus mengembalikan `true` atau `false`.Iterator yang dikembalikan hanya akan menghasilkan elemen yang closure-nya mengembalikan nilai true.
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Karena closure yang diteruskan ke `filter()` membutuhkan referensi, dan banyak iterator melakukan iterasi atas referensi, ini mengarah ke situasi yang mungkin membingungkan, di mana tipe closure adalah referensi ganda:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // butuh dua * s!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Merupakan hal yang umum untuk menggunakan destructuring pada argumen untuk menghapusnya:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // berdua dan *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// atau keduanya:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // dua &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// dari lapisan ini.
    ///
    /// Perhatikan bahwa `iter.filter(f).next()` setara dengan `iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Membuat iterator yang memfilter dan memetakan.
    ///
    /// Iterator yang dikembalikan hanya menghasilkan `nilai` di mana closure yang diberikan mengembalikan `Some(value)`.
    ///
    /// `filter_map` dapat digunakan untuk membuat rantai [`filter`] dan [`map`] lebih ringkas.
    /// Contoh di bawah ini menunjukkan bagaimana `map().filter().map()` dapat dipersingkat menjadi satu panggilan ke `filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Berikut contoh yang sama, tetapi dengan [`filter`] dan [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Membuat iterator yang memberikan hitungan iterasi saat ini serta nilai berikutnya.
    ///
    /// Iterator mengembalikan pasangan hasil `(i, val)`, di mana `i` adalah indeks iterasi saat ini dan `val` adalah nilai yang dikembalikan oleh iterator.
    ///
    ///
    /// `enumerate()` tetap dihitung sebagai [`usize`].
    /// Jika Anda ingin menghitung dengan bilangan bulat berukuran berbeda, fungsi [`zip`] menyediakan fungsionalitas serupa.
    ///
    /// # Perilaku Melimpah
    ///
    /// Metode ini tidak melindungi overflow, jadi enumerasi lebih dari elemen [`usize::MAX`] akan menghasilkan hasil yang salah atau panics.
    /// Jika pernyataan debug diaktifkan, panic dijamin.
    ///
    /// # Panics
    ///
    /// Iterator yang dikembalikan mungkin panic jika indeks yang akan dikembalikan akan meluap [`usize`].
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Membuat iterator yang dapat menggunakan [`peek`] untuk melihat elemen iterator berikutnya tanpa memakannya.
    ///
    /// Menambahkan metode [`peek`] ke iterator.Lihat dokumentasinya untuk informasi lebih lanjut.
    ///
    /// Perhatikan bahwa iterator yang mendasari masih maju ketika [`peek`] dipanggil untuk pertama kalinya: Untuk mengambil elemen berikutnya, [`next`] dipanggil pada iterator yang mendasari, karenanya ada efek samping (mis.
    ///
    /// apa pun selain mengambil nilai berikutnya) dari metode [`next`] akan terjadi.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() mari kita lihat future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // kita dapat peek() beberapa kali, iterator tidak akan maju
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // setelah iterator selesai, begitu juga peek()
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Membuat iterator yang elemen [`lewati`] berdasarkan predikat.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` mengambil penutupan sebagai argumen.Ini akan memanggil closure ini pada setiap elemen iterator, dan mengabaikan elemen hingga mengembalikan `false`.
    ///
    /// Setelah `false` dikembalikan, tugas `skip_while()`'s selesai, dan elemen lainnya dihasilkan.
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Karena closure yang diteruskan ke `skip_while()` mengambil referensi, dan banyak iterator melakukan iterasi atas referensi, ini mengarah ke situasi yang mungkin membingungkan, di mana tipe argumen closure adalah referensi ganda:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // butuh dua * s!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Berhenti setelah `false` awal:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // sementara ini akan menjadi salah, karena kami sudah mendapatkan yang salah, skip_while() tidak digunakan lagi
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Membuat iterator yang menghasilkan elemen berdasarkan predikat.
    ///
    /// `take_while()` mengambil penutupan sebagai argumen.Ini akan memanggil closure ini pada setiap elemen iterator, dan menghasilkan elemen saat mengembalikan `true`.
    ///
    /// Setelah `false` dikembalikan, tugas `take_while()`'s selesai, dan elemen lainnya diabaikan.
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Karena closure yang diteruskan ke `take_while()` membutuhkan referensi, dan banyak iterator melakukan iterasi atas referensi, ini mengarah ke situasi yang mungkin membingungkan, di mana tipe closure adalah referensi ganda:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // butuh dua * s!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Berhenti setelah `false` awal:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Kami memiliki lebih banyak elemen yang kurang dari nol, tetapi karena kami sudah mendapatkan yang salah, take_while() tidak digunakan lagi
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Karena `take_while()` perlu melihat nilainya untuk melihat apakah itu harus disertakan atau tidak, menggunakan iterator akan melihat bahwa itu dihapus:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` sudah tidak ada lagi, karena digunakan untuk melihat apakah iterasi harus berhenti, tetapi tidak ditempatkan kembali ke dalam iterator.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Membuat iterator yang menghasilkan elemen berdasarkan predikat dan peta.
    ///
    /// `map_while()` mengambil penutupan sebagai argumen.
    /// Ini akan memanggil closure ini pada setiap elemen iterator, dan menghasilkan elemen saat mengembalikan [`Some(_)`][`Some`].
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Berikut contoh yang sama, tetapi dengan [`take_while`] dan [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Berhenti setelah [`None`] awal:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Kami memiliki lebih banyak elemen yang bisa muat di u32 (4, 5), tetapi `map_while` mengembalikan `None` untuk `-3` (karena `predicate` mengembalikan `None`) dan `collect` berhenti pada `None` pertama yang ditemukan.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Karena `map_while()` perlu melihat nilainya untuk melihat apakah itu harus disertakan atau tidak, menggunakan iterator akan melihat bahwa itu dihapus:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `-3` sudah tidak ada lagi, karena digunakan untuk melihat apakah iterasi harus berhenti, tetapi tidak ditempatkan kembali ke dalam iterator.
    ///
    /// Perhatikan bahwa tidak seperti [`take_while`], iterator ini **tidak** menyatu.
    /// Juga tidak ditentukan apa yang dikembalikan iterator ini setelah [`None`] pertama dikembalikan.
    /// Jika Anda membutuhkan iterator fusi, gunakan [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Membuat iterator yang melewati elemen `n` pertama.
    ///
    /// Setelah dikonsumsi, sisa elemen dihasilkan.
    /// Daripada mengganti metode ini secara langsung, ganti metode `nth`.
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Membuat iterator yang menghasilkan elemen `n` pertamanya.
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` sering digunakan dengan iterator tak terbatas, untuk membuatnya terbatas:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Jika kurang dari elemen `n` tersedia, `take` akan membatasi dirinya sendiri ke ukuran iterator yang mendasarinya:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// Adaptor iterator mirip dengan [`fold`] yang memiliki status internal dan menghasilkan iterator baru.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` mengambil dua argumen: nilai awal yang menyemai keadaan internal, dan penutupan dengan dua argumen, yang pertama menjadi referensi yang bisa berubah ke keadaan internal dan yang kedua adalah elemen iterator.
    ///
    /// Penutupan dapat menetapkan status internal untuk berbagi status antar iterasi.
    ///
    /// Pada iterasi, penutupan akan diterapkan ke setiap elemen iterator dan nilai kembalian dari closure, [`Option`], dihasilkan oleh iterator.
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // setiap iterasi, kita akan mengalikan keadaan dengan elemen
    ///     *state = *state * x;
    ///
    ///     // kemudian, kita akan menghasilkan negasi dari negara
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Membuat iterator yang berfungsi seperti peta, tetapi meratakan struktur bertingkat.
    ///
    /// Adaptor [`map`] sangat berguna, tetapi hanya jika argumen closure menghasilkan nilai.
    /// Jika malah menghasilkan iterator, ada lapisan tambahan tipuan.
    /// `flat_map()` akan menghapus lapisan ekstra ini dengan sendirinya.
    ///
    /// Anda dapat menganggap `flat_map(f)` sebagai padanan semantik dari ping [`map`], kemudian [`flatten`] sebagai `map(f).flatten()`.
    ///
    /// Cara lain untuk berpikir tentang `flat_map()`: closure [`map`] mengembalikan satu item untuk setiap elemen, dan closure `flat_map()`'s mengembalikan iterator untuk setiap elemen.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() mengembalikan sebuah iterator
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Membuat iterator yang meratakan struktur bertingkat.
    ///
    /// Ini berguna ketika Anda memiliki iterator dari iterator atau iterator dari hal-hal yang dapat diubah menjadi iterator dan Anda ingin menghapus satu tingkat tipuan.
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Memetakan dan kemudian meratakan:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() mengembalikan sebuah iterator
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Anda juga dapat menulis ulang ini dalam istilah [`flat_map()`], yang lebih disukai dalam kasus ini karena ini menyampaikan maksud dengan lebih jelas:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() mengembalikan sebuah iterator
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Perataan hanya menghilangkan satu tingkat sarang pada satu waktu:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Di sini kita melihat bahwa `flatten()` tidak melakukan perataan "deep".
    /// Sebagai gantinya, hanya satu tingkat penumpukan yang dihapus.Artinya, jika Anda membuat `flatten()` larik tiga dimensi, hasilnya akan menjadi dua dimensi, bukan satu dimensi.
    /// Untuk mendapatkan struktur satu dimensi, Anda harus `flatten()` lagi.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Membuat iterator yang berakhir setelah [`None`] pertama.
    ///
    /// Setelah iterator mengembalikan [`None`], panggilan future mungkin atau mungkin tidak menghasilkan [`Some(T)`] lagi.
    /// `fuse()` mengadaptasi sebuah iterator, memastikan bahwa setelah [`None`] diberikan, ia akan selalu mengembalikan [`None`] selamanya.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// // sebuah iterator yang bergantian antara Some dan None
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // jika itu genap, Some(i32), yang lain Tidak ada
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // kita bisa melihat iterator kita bolak-balik
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // Namun, setelah kami memadukannya ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // itu akan selalu mengembalikan `None` setelah pertama kali.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Melakukan sesuatu dengan setiap elemen iterator, meneruskan nilainya.
    ///
    /// Saat menggunakan iterator, Anda akan sering merantai beberapa di antaranya.
    /// Saat mengerjakan kode semacam itu, Anda mungkin ingin memeriksa apa yang terjadi di berbagai bagian dalam pipeline.Untuk melakukan itu, masukkan panggilan ke `inspect()`.
    ///
    /// `inspect()` lebih umum digunakan sebagai alat debugging daripada ada di kode akhir Anda, tetapi aplikasi mungkin merasa berguna dalam situasi tertentu ketika kesalahan perlu dicatat sebelum dibuang.
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // urutan iterator ini rumit.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // mari tambahkan beberapa panggilan inspect() untuk menyelidiki apa yang terjadi
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Ini akan mencetak:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Kesalahan pencatatan sebelum membuangnya:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Ini akan mencetak:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Meminjam iterator, bukan mengonsumsinya.
    ///
    /// Ini berguna untuk memungkinkan penerapan adaptor iterator sambil tetap mempertahankan kepemilikan dari iterator aslinya.
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // jika kita mencoba menggunakan iter lagi, itu tidak akan berhasil.
    /// // Baris berikut memberikan "kesalahan: penggunaan nilai yang dipindahkan: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // ayo coba lagi
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // sebagai gantinya, kami menambahkan .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // sekarang ini baik-baik saja:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Mengubah iterator menjadi koleksi.
    ///
    /// `collect()` dapat mengambil apa pun yang dapat diulang, dan mengubahnya menjadi koleksi yang relevan.
    /// Ini adalah salah satu metode yang lebih kuat di pustaka standar, yang digunakan dalam berbagai konteks.
    ///
    /// Pola paling dasar yang menggunakan `collect()` adalah mengubah satu koleksi menjadi koleksi lainnya.
    /// Anda mengambil koleksi, memanggil [`iter`] di atasnya, melakukan banyak transformasi, dan kemudian `collect()` di bagian akhir.
    ///
    /// `collect()` juga dapat membuat contoh jenis yang bukan koleksi khas.
    /// Misalnya, [`String`] dapat dibuat dari [`char`] s, dan iterator item [`Result<T, E>`][`Result`] dapat dikumpulkan ke dalam `Result<Collection<T>, E>`.
    ///
    /// Lihat contoh di bawah untuk lebih lanjut.
    ///
    /// Karena `collect()` sangat umum, ini dapat menyebabkan masalah dengan inferensi tipe.
    /// Karena itu, `collect()` adalah salah satu dari sedikit waktu Anda akan melihat sintaks yang dikenal sebagai 'turbofish': `::<>`.
    /// Ini membantu algoritme inferensi memahami secara spesifik koleksi mana yang Anda coba kumpulkan.
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Perhatikan bahwa kami membutuhkan `: Vec<i32>` di sisi kiri.Ini karena kami dapat mengumpulkan, misalnya, [`VecDeque<T>`] sebagai gantinya:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// Menggunakan 'turbofish' daripada membuat anotasi `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Karena `collect()` hanya peduli tentang apa yang Anda kumpulkan, Anda masih dapat menggunakan petunjuk tipe parsial, `_`, dengan turbofish:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Menggunakan `collect()` untuk membuat [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Jika Anda memiliki daftar [`Hasil<T, E>`][`Result`], Anda dapat menggunakan `collect()` untuk melihat apakah ada yang gagal:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // memberi kami kesalahan pertama
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // memberi kami daftar jawaban
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Menggunakan iterator, membuat dua koleksi darinya.
    ///
    /// Predikat yang diteruskan ke `partition()` dapat mengembalikan `true`, atau `false`.
    /// `partition()` mengembalikan pasangan, semua elemen yang dikembalikan `true`, dan semua elemen yang mengembalikan `false`.
    ///
    ///
    /// Lihat juga [`is_partitioned()`] dan [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Menyusun ulang elemen iterator *di tempat* ini sesuai dengan predikat yang diberikan, sehingga semua yang mengembalikan `true` mendahului semua yang mengembalikan `false`.
    ///
    /// Mengembalikan jumlah elemen `true` yang ditemukan.
    ///
    /// Urutan relatif item yang dipartisi tidak dipertahankan.
    ///
    /// Lihat juga [`is_partitioned()`] dan [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Partisi di tempat antara genap dan ganjil
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: haruskah kita khawatir tentang jumlah yang meluap?Satu-satunya cara untuk memiliki lebih dari
        // `usize::MAX` referensi yang bisa berubah adalah dengan ZST, yang tidak berguna untuk partisi ...

        // Fungsi penutupan "factory" ini ada untuk menghindari sifat umum di `Self`.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Temukan `false` pertama dan tukarkan dengan `true` terakhir.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Memeriksa apakah elemen dari iterator ini dipartisi sesuai dengan predikat yang diberikan, sehingga semua yang mengembalikan `true` mendahului semua yang mengembalikan `false`.
    ///
    ///
    /// Lihat juga [`partition()`] dan [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Entah semua item menguji `true`, atau klausa pertama berhenti di `false` dan kami memeriksa bahwa tidak ada lagi item `true` setelah itu.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// Metode iterator yang menerapkan fungsi selama fungsi tersebut kembali berhasil, menghasilkan satu nilai akhir.
    ///
    /// `try_fold()` mengambil dua argumen: nilai awal, dan penutupan dengan dua argumen: 'accumulator', dan elemen.
    /// Penutupan berhasil dikembalikan, dengan nilai yang harus dimiliki akumulator untuk iterasi berikutnya, atau mengembalikan kegagalan, dengan nilai kesalahan yang disebarkan kembali ke pemanggil segera (short-circuiting).
    ///
    ///
    /// Nilai awal adalah nilai yang akan dimiliki akumulator pada panggilan pertama.Jika penerapan penutupan berhasil terhadap setiap elemen iterator, `try_fold()` mengembalikan akumulator terakhir sebagai berhasil.
    ///
    /// Lipat berguna setiap kali Anda memiliki koleksi sesuatu, dan ingin menghasilkan satu nilai darinya.
    ///
    /// # Catatan untuk Pelaksana
    ///
    /// Beberapa dari metode (forward) lainnya memiliki implementasi default dalam hal ini, jadi cobalah untuk mengimplementasikan ini secara eksplisit jika dapat melakukan sesuatu yang lebih baik daripada implementasi loop `for` default.
    ///
    /// Secara khusus, coba buat panggilan ini `try_fold()` pada bagian internal yang menyusun iterator ini.
    /// Jika beberapa panggilan diperlukan, operator `?` mungkin merasa nyaman untuk merangkai nilai akumulator, tetapi waspadalah terhadap invarian apa pun yang perlu ditegakkan sebelum pengembalian awal tersebut.
    /// Ini adalah metode `&mut self`, jadi iterasi harus dilanjutkan setelah terjadi kesalahan di sini.
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // jumlah yang diperiksa dari semua elemen array
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Jumlah ini meluap saat menambahkan elemen 100
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Karena korsleting, elemen yang tersisa masih tersedia melalui iterator.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Metode iterator yang menerapkan fungsi yang bisa salah ke setiap item di iterator, berhenti di kesalahan pertama dan mengembalikan kesalahan itu.
    ///
    ///
    /// Ini juga dapat dianggap sebagai bentuk yang salah dari [`for_each()`] atau sebagai versi tanpa status dari [`try_fold()`].
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Ini korsleting, jadi item yang tersisa masih di iterator:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Melipat setiap elemen menjadi akumulator dengan menerapkan operasi, mengembalikan hasil akhir.
    ///
    /// `fold()` mengambil dua argumen: nilai awal, dan penutupan dengan dua argumen: 'accumulator', dan elemen.
    /// Closure mengembalikan nilai yang harus dimiliki akumulator untuk iterasi berikutnya.
    ///
    /// Nilai awal adalah nilai yang akan dimiliki akumulator pada panggilan pertama.
    ///
    /// Setelah menerapkan penutupan ini ke setiap elemen iterator, `fold()` mengembalikan akumulator.
    ///
    /// Operasi ini terkadang disebut 'reduce' atau 'inject'.
    ///
    /// Lipat berguna setiap kali Anda memiliki koleksi sesuatu, dan ingin menghasilkan satu nilai darinya.
    ///
    /// Note: `fold()`, dan metode serupa yang melintasi seluruh iterator, mungkin tidak berhenti untuk iterator tak terbatas, bahkan pada traits yang hasilnya dapat ditentukan dalam waktu yang terbatas.
    ///
    /// Note: [`reduce()`] dapat digunakan untuk menggunakan elemen pertama sebagai nilai awal, jika jenis akumulator dan jenis itemnya sama.
    ///
    /// # Catatan untuk Pelaksana
    ///
    /// Beberapa dari metode (forward) lainnya memiliki implementasi default dalam hal ini, jadi cobalah untuk mengimplementasikan ini secara eksplisit jika dapat melakukan sesuatu yang lebih baik daripada implementasi loop `for` default.
    ///
    ///
    /// Secara khusus, coba buat panggilan ini `fold()` pada bagian internal yang menyusun iterator ini.
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // jumlah dari semua elemen array
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Mari kita telusuri setiap langkah iterasi di sini:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// Jadi, hasil akhir kami, `6`.
    ///
    /// Sangat umum bagi orang yang belum sering menggunakan iterator untuk menggunakan loop `for` dengan daftar hal-hal untuk membangun hasil.Itu bisa diubah menjadi `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // untuk loop:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // mereka sama
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Mengurangi elemen menjadi satu, dengan berulang kali menerapkan operasi pengurangan.
    ///
    /// Jika iterator kosong, mengembalikan [`None`];jika tidak, mengembalikan hasil pengurangan.
    ///
    /// Untuk iterator dengan setidaknya satu elemen, ini sama dengan [`fold()`] dengan elemen pertama dari iterator sebagai nilai awal, melipat setiap elemen berikutnya ke dalamnya.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Temukan nilai maksimum:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Menguji apakah setiap elemen iterator cocok dengan sebuah predikat.
    ///
    /// `all()` mengambil penutupan yang mengembalikan `true` atau `false`.Ini menerapkan closure ini ke setiap elemen iterator, dan jika semuanya mengembalikan `true`, begitu pula `all()`.
    /// Jika salah satu dari mereka mengembalikan `false`, ia mengembalikan `false`.
    ///
    /// `all()` korsleting;dengan kata lain, ia akan berhenti memproses segera setelah menemukan `false`, mengingat apa pun yang terjadi, hasilnya juga akan menjadi `false`.
    ///
    ///
    /// Iterator kosong mengembalikan `true`.
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Berhenti di `false` pertama:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // kita masih bisa menggunakan `iter`, karena ada lebih banyak elemen.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Menguji apakah ada elemen iterator yang cocok dengan predikat.
    ///
    /// `any()` mengambil penutupan yang mengembalikan `true` atau `false`.Ini menerapkan penutupan ini ke setiap elemen iterator, dan jika salah satu dari mereka mengembalikan `true`, begitu juga `any()`.
    /// Jika mereka semua mengembalikan `false`, ia mengembalikan `false`.
    ///
    /// `any()` korsleting;dengan kata lain, ia akan berhenti memproses segera setelah menemukan `true`, mengingat apa pun yang terjadi, hasilnya juga akan menjadi `true`.
    ///
    ///
    /// Iterator kosong mengembalikan `false`.
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Berhenti di `true` pertama:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // kita masih bisa menggunakan `iter`, karena ada lebih banyak elemen.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Mencari elemen iterator yang memenuhi predikat.
    ///
    /// `find()` mengambil penutupan yang mengembalikan `true` atau `false`.
    /// Ini menerapkan penutupan ini ke setiap elemen iterator, dan jika ada yang mengembalikan `true`, maka `find()` mengembalikan [`Some(element)`].
    /// Jika mereka semua mengembalikan `false`, ia mengembalikan [`None`].
    ///
    /// `find()` korsleting;dengan kata lain, itu akan berhenti memproses segera setelah penutupan mengembalikan `true`.
    ///
    /// Karena `find()` mengambil referensi, dan banyak iterator melakukan iterasi atas referensi, ini mengarah ke situasi yang mungkin membingungkan di mana argumennya adalah referensi ganda.
    ///
    /// Anda dapat melihat efek ini pada contoh di bawah, dengan `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Berhenti di `true` pertama:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // kita masih bisa menggunakan `iter`, karena ada lebih banyak elemen.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Perhatikan bahwa `iter.find(f)` setara dengan `iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Menerapkan fungsi ke elemen iterator dan mengembalikan hasil non-none pertama.
    ///
    ///
    /// `iter.find_map(f)` setara dengan `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Menerapkan fungsi ke elemen iterator dan mengembalikan hasil benar pertama atau kesalahan pertama.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Mencari elemen dalam iterator, mengembalikan indeksnya.
    ///
    /// `position()` mengambil penutupan yang mengembalikan `true` atau `false`.
    /// Ini menerapkan penutupan ini ke setiap elemen iterator, dan jika salah satu dari mereka mengembalikan `true`, maka `position()` mengembalikan [`Some(index)`].
    /// Jika semuanya mengembalikan `false`, ia mengembalikan [`None`].
    ///
    /// `position()` korsleting;dengan kata lain, ini akan berhenti memproses segera setelah menemukan `true`.
    ///
    /// # Perilaku Melimpah
    ///
    /// Metode ini tidak melindungi overflow, jadi jika ada lebih dari [`usize::MAX`] elemen yang tidak cocok, itu akan menghasilkan hasil yang salah atau panics.
    ///
    /// Jika pernyataan debug diaktifkan, panic dijamin.
    ///
    /// # Panics
    ///
    /// Fungsi ini mungkin panic jika iterator memiliki lebih dari `usize::MAX` elemen yang tidak cocok.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Berhenti di `true` pertama:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // kita masih bisa menggunakan `iter`, karena ada lebih banyak elemen.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Indeks yang dikembalikan bergantung pada status iterator
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Mencari elemen dalam iterator dari kanan, mengembalikan indeksnya.
    ///
    /// `rposition()` mengambil penutupan yang mengembalikan `true` atau `false`.
    /// Ini menerapkan penutupan ini ke setiap elemen iterator, mulai dari akhir, dan jika salah satu dari mereka mengembalikan `true`, maka `rposition()` mengembalikan [`Some(index)`].
    ///
    /// Jika semuanya mengembalikan `false`, ia mengembalikan [`None`].
    ///
    /// `rposition()` korsleting;dengan kata lain, ini akan berhenti memproses segera setelah menemukan `true`.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Berhenti di `true` pertama:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // kita masih bisa menggunakan `iter`, karena ada lebih banyak elemen.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Tidak perlu pemeriksaan luapan di sini, karena `ExactSizeIterator` menyiratkan bahwa jumlah elemen cocok dengan `usize`.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Mengembalikan elemen maksimum dari sebuah iterator.
    ///
    /// Jika beberapa elemen sama-sama maksimum, elemen terakhir dikembalikan.
    /// Jika iterator kosong, [`None`] dikembalikan.
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Mengembalikan elemen minimum dari sebuah iterator.
    ///
    /// Jika beberapa elemen sama-sama minimum, elemen pertama dikembalikan.
    /// Jika iterator kosong, [`None`] dikembalikan.
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Mengembalikan elemen yang memberikan nilai maksimum dari fungsi yang ditentukan.
    ///
    ///
    /// Jika beberapa elemen sama-sama maksimum, elemen terakhir dikembalikan.
    /// Jika iterator kosong, [`None`] dikembalikan.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Mengembalikan elemen yang memberikan nilai maksimum sehubungan dengan fungsi perbandingan yang ditentukan.
    ///
    ///
    /// Jika beberapa elemen sama-sama maksimum, elemen terakhir dikembalikan.
    /// Jika iterator kosong, [`None`] dikembalikan.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Mengembalikan elemen yang memberikan nilai minimum dari fungsi yang ditentukan.
    ///
    ///
    /// Jika beberapa elemen sama-sama minimum, elemen pertama dikembalikan.
    /// Jika iterator kosong, [`None`] dikembalikan.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Mengembalikan elemen yang memberikan nilai minimum sehubungan dengan fungsi perbandingan yang ditentukan.
    ///
    ///
    /// Jika beberapa elemen sama-sama minimum, elemen pertama dikembalikan.
    /// Jika iterator kosong, [`None`] dikembalikan.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Membalik arah iterator.
    ///
    /// Biasanya, iterator melakukan iterasi dari kiri ke kanan.
    /// Setelah menggunakan `rev()`, sebuah iterator akan melakukan iterasi dari kanan ke kiri.
    ///
    /// Ini hanya mungkin jika iterator memiliki akhir, jadi `rev()` hanya bekerja pada [`DoubleEndedIterator`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Mengonversi iterator pasangan menjadi sepasang kontainer.
    ///
    /// `unzip()` menggunakan seluruh iterator berpasangan, menghasilkan dua koleksi: satu dari elemen kiri pasangan, dan satu dari elemen kanan.
    ///
    ///
    /// Fungsi ini, dalam beberapa hal, merupakan kebalikan dari [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Membuat iterator yang menyalin semua elemennya.
    ///
    /// Ini berguna jika Anda memiliki iterator di atas `&T`, tetapi Anda memerlukan iterator di atas `T`.
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // disalin sama dengan .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Membuat iterator yang [`menggandakan`] semua elemennya.
    ///
    /// Ini berguna jika Anda memiliki iterator di atas `&T`, tetapi Anda memerlukan iterator di atas `T`.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // kloning sama dengan .map(|&x| x), untuk bilangan bulat
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Mengulangi iterator tanpa henti.
    ///
    /// Alih-alih berhenti di [`None`], iterator akan memulai lagi, dari awal.Setelah melakukan iterasi lagi, ini akan dimulai dari awal lagi.Dan lagi.
    /// Dan lagi.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Menjumlahkan elemen sebuah iterator.
    ///
    /// Mengambil setiap elemen, menambahkannya, dan mengembalikan hasilnya.
    ///
    /// Sebuah iterator kosong mengembalikan nilai nol dari tipe tersebut.
    ///
    /// # Panics
    ///
    /// Saat memanggil `sum()` dan jenis integer primitif dikembalikan, metode ini akan panic jika komputasi overflow dan pernyataan debug diaktifkan.
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Iterasi di seluruh iterator, mengalikan semua elemen
    ///
    /// Sebuah iterator kosong mengembalikan satu nilai tipe.
    ///
    /// # Panics
    ///
    /// Saat memanggil `product()` dan jenis integer primitif dikembalikan, metode akan panic jika komputasi overflow dan pernyataan debug diaktifkan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) membandingkan elemen [`Iterator`] ini dengan elemen lainnya.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) membandingkan elemen [`Iterator`] ini dengan elemen lainnya sehubungan dengan fungsi perbandingan yang ditentukan.
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) membandingkan elemen [`Iterator`] ini dengan elemen lainnya.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) membandingkan elemen [`Iterator`] ini dengan elemen lainnya sehubungan dengan fungsi perbandingan yang ditentukan.
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Menentukan apakah elemen [`Iterator`] ini sama dengan elemen lainnya.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Menentukan apakah elemen [`Iterator`] ini sama dengan elemen lainnya sehubungan dengan fungsi persamaan yang ditentukan.
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Menentukan apakah elemen [`Iterator`] ini tidak sama dengan elemen lainnya.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Menentukan apakah elemen [`Iterator`] ini [lexicographically](Ord#lexicographical-comparison) lebih kecil dari elemen lainnya.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Menentukan apakah elemen [`Iterator`] ini adalah [lexicographically](Ord#lexicographical-comparison) lebih kecil atau sama dengan elemen lainnya.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Menentukan apakah elemen [`Iterator`] ini adalah [lexicographically](Ord#lexicographical-comparison) lebih besar daripada elemen lainnya.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Menentukan apakah elemen [`Iterator`] ini adalah [lexicographically](Ord#lexicographical-comparison) lebih besar atau sama dengan elemen lainnya.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Memeriksa apakah elemen iterator ini diurutkan.
    ///
    /// Artinya, untuk setiap elemen `a` dan elemen `b` berikutnya, `a <= b` harus dipegang.Jika iterator menghasilkan tepat nol atau satu elemen, `true` dikembalikan.
    ///
    /// Perhatikan bahwa jika `Self::Item` hanya `PartialOrd`, tetapi bukan `Ord`, definisi di atas menyiratkan bahwa fungsi ini mengembalikan `false` jika dua item yang berurutan tidak dapat dibandingkan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Memeriksa apakah elemen iterator ini diurutkan menggunakan fungsi pembanding yang diberikan.
    ///
    /// Alih-alih menggunakan `PartialOrd::partial_cmp`, fungsi ini menggunakan fungsi `compare` yang diberikan untuk menentukan urutan dua elemen.
    /// Selain itu, ini setara dengan [`is_sorted`];lihat dokumentasinya untuk informasi lebih lanjut.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Memeriksa apakah elemen iterator ini diurutkan menggunakan fungsi ekstraksi kunci yang diberikan.
    ///
    /// Alih-alih membandingkan elemen iterator secara langsung, fungsi ini membandingkan kunci dari elemen, seperti yang ditentukan oleh `f`.
    /// Selain itu, ini setara dengan [`is_sorted`];lihat dokumentasinya untuk informasi lebih lanjut.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// Lihat [TrustedRandomAccess]
    // Nama yang tidak biasa adalah untuk menghindari benturan nama dalam resolusi metode, lihat #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}