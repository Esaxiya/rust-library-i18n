/// Sebuah iterator yang mengetahui panjang pastinya.
///
/// Banyak [`Iterator`] tidak tahu berapa kali mereka akan mengulang, tetapi beberapa tahu.
/// Jika iterator mengetahui berapa kali iterasinya, memberikan akses ke informasi tersebut dapat berguna.
/// Misalnya, jika Anda ingin mengulang ke belakang, awal yang baik adalah mengetahui di mana akhirnya.
///
/// Saat menerapkan `ExactSizeIterator`, Anda juga harus menerapkan [`Iterator`].
/// Saat melakukannya, implementasi [`Iterator::size_hint`]*harus* mengembalikan ukuran iterator yang tepat.
///
/// Metode [`len`] memiliki implementasi default, jadi Anda biasanya tidak perlu mengimplementasikannya.
/// Namun, Anda mungkin dapat memberikan implementasi yang lebih berkinerja daripada default, jadi menggantinya dalam kasus ini masuk akal.
///
///
/// Perhatikan bahwa trait ini adalah trait yang aman dan karena itu *tidak* dan *tidak dapat* menjamin bahwa panjang yang dikembalikan benar.
/// Ini berarti kode `unsafe`**tidak boleh** bergantung pada kebenaran [`Iterator::size_hint`].
/// [`TrustedLen`](super::marker::TrustedLen) trait yang tidak stabil dan tidak aman memberikan jaminan tambahan ini.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Penggunaan dasar:
///
/// ```
/// // kisaran terbatas tahu persis berapa kali itu akan berulang
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// Di [module-level docs], kami menerapkan [`Iterator`], `Counter`.
/// Mari terapkan `ExactSizeIterator` untuk itu juga:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Kami dapat dengan mudah menghitung jumlah iterasi yang tersisa.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // Dan sekarang kita bisa menggunakannya!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Mengembalikan panjang persis dari iterator.
    ///
    /// Implementasinya memastikan bahwa iterator akan mengembalikan `len()` lebih banyak kali lipat dari nilai [`Some(T)`], sebelum mengembalikan [`None`].
    ///
    /// Metode ini memiliki implementasi default, jadi Anda biasanya tidak harus mengimplementasikannya secara langsung.
    /// Namun, jika Anda dapat memberikan implementasi yang lebih efisien, Anda dapat melakukannya.
    /// Lihat dokumen [trait-level] sebagai contoh.
    ///
    /// Fungsi ini memiliki jaminan keamanan yang sama dengan fungsi [`Iterator::size_hint`].
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// // kisaran terbatas tahu persis berapa kali itu akan berulang
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Penegasan ini terlalu defensif, tetapi memeriksa ketidakberagaman
        // dijamin oleh trait.
        // Jika trait ini adalah rust-internal, kita dapat menggunakan debug_assert !;assert_eq!akan memeriksa semua implementasi pengguna Rust juga.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Mengembalikan `true` jika iterator kosong.
    ///
    /// Metode ini memiliki implementasi default yang menggunakan [`ExactSizeIterator::len()`], jadi Anda tidak perlu menerapkannya sendiri.
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}