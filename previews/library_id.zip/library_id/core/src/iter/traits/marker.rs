/// Sebuah iterator yang selalu menghasilkan `None` saat habis.
///
/// Memanggil berikutnya pada iterator gabungan yang mengembalikan `None` sekali dijamin akan mengembalikan [`None`] lagi.
/// trait ini harus diimplementasikan oleh semua iterator yang berperilaku seperti ini karena memungkinkan pengoptimalan [`Iterator::fuse()`].
///
///
/// Note: Secara umum, Anda tidak boleh menggunakan `FusedIterator` dalam batasan umum jika Anda membutuhkan iterator yang menyatu.
/// Sebagai gantinya, Anda harus memanggil [`Iterator::fuse()`] di iterator.
/// Jika iterator sudah menyatu, pembungkus [`Fuse`] tambahan akan menjadi tanpa operasi tanpa penalti kinerja.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// Sebuah iterator yang melaporkan panjang akurat menggunakan size_hint.
///
/// Iterator melaporkan petunjuk ukuran yang tepat (batas bawah sama dengan batas atas), atau batas atasnya adalah [`None`].
///
/// Batas atas hanya boleh [`None`] jika panjang iterator sebenarnya lebih besar dari [`usize::MAX`].
/// Dalam kasus tersebut, batas bawah harus [`usize::MAX`], menghasilkan [`Iterator::size_hint()`] dari `(usize::MAX, None)`.
///
/// Iterator harus menghasilkan secara tepat jumlah elemen yang dilaporkan atau menyimpang sebelum mencapai akhir.
///
/// # Safety
///
/// trait ini hanya boleh diterapkan ketika kontrak ditegakkan.
/// Konsumen trait ini harus memeriksa batas atas [`Iterator::size_hint()`]’s.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// Sebuah iterator yang ketika menghasilkan item akan mengambil setidaknya satu elemen dari [`SourceIter`] yang mendasarinya.
///
/// Memanggil metode apa pun yang memajukan iterator, mis
/// [`next()`] atau [`try_fold()`], menjamin bahwa untuk setiap langkah setidaknya satu nilai sumber yang mendasari iterator telah dipindahkan dan hasil dari rantai iterator dapat disisipkan di tempatnya, dengan asumsi batasan struktural sumber memungkinkan penyisipan seperti itu.
///
/// Dengan kata lain trait ini menunjukkan bahwa pipeline iterator dapat dikumpulkan di tempatnya.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}