use crate::{iter::FusedIterator, ops::Try};

/// Sebuah iterator yang berulang tanpa akhir.
///
/// `struct` ini dibuat dengan metode [`cycle`] di [`Iterator`].
/// Lihat dokumentasinya untuk lebih lanjut.
///
/// [`cycle`]: Iterator::cycle
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Cycle<I> {
    orig: I,
    iter: I,
}

impl<I: Clone> Cycle<I> {
    pub(in crate::iter) fn new(iter: I) -> Cycle<I> {
        Cycle { orig: iter.clone(), iter }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> Iterator for Cycle<I>
where
    I: Clone + Iterator,
{
    type Item = <I as Iterator>::Item;

    #[inline]
    fn next(&mut self) -> Option<<I as Iterator>::Item> {
        match self.iter.next() {
            None => {
                self.iter = self.orig.clone();
                self.iter.next()
            }
            y => y,
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        // iterator siklus kosong atau tidak terbatas
        match self.orig.size_hint() {
            sz @ (0, Some(0)) => sz,
            (0, _) => (0, None),
            _ => (usize::MAX, None),
        }
    }

    #[inline]
    fn try_fold<Acc, F, R>(&mut self, mut acc: Acc, mut f: F) -> R
    where
        F: FnMut(Acc, Self::Item) -> R,
        R: Try<Ok = Acc>,
    {
        // iterasi sepenuhnya iterator saat ini.
        // ini diperlukan karena `self.iter` mungkin kosong meskipun `self.orig` tidak
        acc = self.iter.try_fold(acc, &mut f)?;
        self.iter = self.orig.clone();

        // selesaikan satu siklus penuh, dengan melacak apakah iterator yang bersepeda itu kosong atau tidak.
        // kita perlu kembali lebih awal jika iterator kosong untuk mencegah loop tak terbatas
        //
        let mut is_empty = true;
        acc = self.iter.try_fold(acc, |acc, x| {
            is_empty = false;
            f(acc, x)
        })?;

        if is_empty {
            return try { acc };
        }

        loop {
            self.iter = self.orig.clone();
            acc = self.iter.try_fold(acc, &mut f)?;
        }
    }

    // Tidak ada penimpaan `fold`, karena `fold` tidak masuk akal untuk `Cycle`, dan kami tidak dapat melakukan apa pun yang lebih baik selain default.
    //
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I> FusedIterator for Cycle<I> where I: Clone + Iterator {}