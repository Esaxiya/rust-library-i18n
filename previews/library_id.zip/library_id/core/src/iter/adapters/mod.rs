use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// trait ini menyediakan akses transitif ke tahap sumber dalam pipa adaptor interator dalam kondisi itu
/// * sumber iterator `S` sendiri mengimplementasikan `SourceIter<Source = S>`
/// * ada implementasi pendelegasian trait ini untuk setiap adaptor di pipeline antara sumber dan konsumen pipeline.
///
/// Jika sumbernya adalah struct iterator pemilik (biasanya disebut `IntoIter`) maka ini dapat berguna untuk mengkhususkan implementasi [`FromIterator`] atau memulihkan elemen yang tersisa setelah iterator habis sebagian.
///
///
/// Perhatikan bahwa implementasi tidak harus menyediakan akses ke sumber pipeline yang paling dalam.Adaptor perantara stateful mungkin dengan bersemangat mengevaluasi bagian dari pipeline dan mengekspos penyimpanan internalnya sebagai sumber.
///
/// trait tidak aman karena pelaksana harus menjunjung tinggi properti keamanan tambahan.
/// Lihat [`as_inner`] untuk detailnya.
///
/// # Examples
///
/// Mengambil sumber yang dikonsumsi sebagian:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// Tahap sumber dalam pipeline iterator.
    type Source: Iterator;

    /// Ambil sumber pipeline iterator.
    ///
    /// # Safety
    ///
    /// Penerapan harus mengembalikan referensi yang bisa berubah yang sama selama masa pakainya, kecuali diganti oleh pemanggil.
    /// Penelepon hanya dapat mengganti referensi saat mereka menghentikan iterasi dan melepaskan pipeline iterator setelah mengekstrak sumbernya.
    ///
    /// Artinya, adaptor iterator dapat mengandalkan sumber yang tidak berubah selama iterasi, tetapi mereka tidak dapat mengandalkannya dalam implementasi Drop.
    ///
    /// Menerapkan metode ini berarti adaptor melepaskan akses khusus pribadi ke sumbernya dan hanya dapat mengandalkan jaminan yang dibuat berdasarkan jenis metode penerima.
    /// Kurangnya akses terbatas juga mengharuskan adaptor untuk mempertahankan API publik sumber meskipun mereka memiliki akses ke internalnya.
    ///
    /// Penelepon pada gilirannya harus mengharapkan sumber berada dalam keadaan apa pun yang konsisten dengan API publiknya karena adaptor yang berada di antara itu dan sumber memiliki akses yang sama.
    /// Secara khusus, adaptor mungkin menggunakan lebih banyak elemen daripada yang benar-benar diperlukan.
    ///
    /// Tujuan keseluruhan dari persyaratan ini adalah membiarkan konsumen pipa menggunakan
    /// * apa pun yang tersisa di sumber setelah iterasi dihentikan
    /// * memori yang tidak lagi digunakan dengan melanjutkan iterator yang memakannya
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// Adaptor iterator yang menghasilkan keluaran selama iterator yang mendasari menghasilkan nilai `Result::Ok`.
///
///
/// Jika terjadi kesalahan, iterator berhenti dan kesalahan disimpan.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// Proses iterator yang diberikan seolah-olah menghasilkan `T`, bukan `Result<T, _>`.
/// Setiap kesalahan akan menghentikan iterator bagian dalam dan hasil keseluruhan akan menjadi kesalahan.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}