use crate::iter::{adapters::SourceIter, FusedIterator, InPlaceIterable, TrustedLen};
use crate::ops::Try;

/// Sebuah iterator dengan `peek()` yang mengembalikan referensi opsional ke elemen berikutnya.
///
///
/// `struct` ini dibuat dengan metode [`peekable`] di [`Iterator`].
/// Lihat dokumentasinya untuk lebih lanjut.
///
/// [`peekable`]: Iterator::peekable
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Peekable<I: Iterator> {
    iter: I,
    /// Ingat nilai yang diintip, meskipun itu Tidak Ada.
    peeked: Option<Option<I::Item>>,
}

impl<I: Iterator> Peekable<I> {
    pub(in crate::iter) fn new(iter: I) -> Peekable<I> {
        Peekable { iter, peeked: None }
    }
}

// Peekable harus ingat jika Tidak ada yang terlihat di metode `.peek()`.
// Ini memastikan bahwa `.peek();.peek();` atau `.peek();.next();` hanya memajukan iterator yang mendasarinya paling banyak sekali.
// Ini tidak dengan sendirinya membuat iterator menyatu.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> Iterator for Peekable<I> {
    type Item = I::Item;

    #[inline]
    fn next(&mut self) -> Option<I::Item> {
        match self.peeked.take() {
            Some(v) => v,
            None => self.iter.next(),
        }
    }

    #[inline]
    #[rustc_inherit_overflow_checks]
    fn count(mut self) -> usize {
        match self.peeked.take() {
            Some(None) => 0,
            Some(Some(_)) => 1 + self.iter.count(),
            None => self.iter.count(),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        match self.peeked.take() {
            Some(None) => None,
            Some(v @ Some(_)) if n == 0 => v,
            Some(Some(_)) => self.iter.nth(n - 1),
            None => self.iter.nth(n),
        }
    }

    #[inline]
    fn last(mut self) -> Option<I::Item> {
        let peek_opt = match self.peeked.take() {
            Some(None) => return None,
            Some(v) => v,
            None => None,
        };
        self.iter.last().or(peek_opt)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let peek_len = match self.peeked {
            Some(None) => return (0, Some(0)),
            Some(Some(_)) => 1,
            None => 0,
        };
        let (lo, hi) = self.iter.size_hint();
        let lo = lo.saturating_add(peek_len);
        let hi = match hi {
            Some(x) => x.checked_add(peek_len),
            None => None,
        };
        (lo, hi)
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let acc = match self.peeked.take() {
            Some(None) => return try { init },
            Some(Some(v)) => f(init, v)?,
            None => init,
        };
        self.iter.try_fold(acc, f)
    }

    #[inline]
    fn fold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        let acc = match self.peeked {
            Some(None) => return init,
            Some(Some(v)) => fold(init, v),
            None => init,
        };
        self.iter.fold(acc, fold)
    }
}

#[stable(feature = "double_ended_peek_iterator", since = "1.38.0")]
impl<I> DoubleEndedIterator for Peekable<I>
where
    I: DoubleEndedIterator,
{
    #[inline]
    fn next_back(&mut self) -> Option<Self::Item> {
        match self.peeked.as_mut() {
            Some(v @ Some(_)) => self.iter.next_back().or_else(|| v.take()),
            Some(None) => None,
            None => self.iter.next_back(),
        }
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        match self.peeked.take() {
            Some(None) => try { init },
            Some(Some(v)) => match self.iter.try_rfold(init, &mut f).into_result() {
                Ok(acc) => f(acc, v),
                Err(e) => {
                    self.peeked = Some(Some(v));
                    Try::from_error(e)
                }
            },
            None => self.iter.try_rfold(init, f),
        }
    }

    #[inline]
    fn rfold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        match self.peeked {
            Some(None) => init,
            Some(Some(v)) => {
                let acc = self.iter.rfold(init, &mut fold);
                fold(acc, v)
            }
            None => self.iter.rfold(init, fold),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator> ExactSizeIterator for Peekable<I> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator> FusedIterator for Peekable<I> {}

impl<I: Iterator> Peekable<I> {
    /// Mengembalikan referensi ke nilai next() tanpa melanjutkan iterator.
    ///
    /// Seperti [`next`], jika ada nilai, ia dibungkus dalam `Some(T)`.
    /// Tetapi jika iterasi selesai, `None` dikembalikan.
    ///
    /// [`next`]: Iterator::next
    ///
    /// Karena `peek()` mengembalikan referensi, dan banyak iterator melakukan iterasi atas referensi, mungkin ada situasi yang membingungkan di mana nilai yang dikembalikan adalah referensi ganda.
    /// Anda dapat melihat efek ini pada contoh di bawah.
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() mari kita lihat future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // Iterator tidak maju meskipun kita `peek` beberapa kali
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Setelah iterator selesai, begitu juga `peek()`
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&mut self) -> Option<&I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_ref()
    }

    /// Mengembalikan referensi yang bisa berubah ke nilai next() tanpa melanjutkan iterator.
    ///
    /// Seperti [`next`], jika ada nilai, ia dibungkus dalam `Some(T)`.
    /// Tetapi jika iterasi selesai, `None` dikembalikan.
    ///
    /// Karena `peek_mut()` mengembalikan referensi, dan banyak iterator melakukan iterasi atas referensi, mungkin ada situasi yang membingungkan di mana nilai yang dikembalikan adalah referensi ganda.
    /// Anda dapat melihat efek ini pada contoh di bawah.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// #![feature(peekable_peek_mut)]
    /// let mut iter = [1, 2, 3].iter().peekable();
    ///
    /// // Seperti dengan `peek()`, kita dapat melihat ke dalam future tanpa melanjutkan iterator.
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // Intip ke dalam iterator dan setel nilai di belakang referensi yang bisa berubah.
    /// if let Some(p) = iter.peek_mut() {
    ///     assert_eq!(*p, &2);
    ///     *p = &5;
    /// }
    ///
    /// // Nilai yang kita masukkan muncul kembali saat iterator berlanjut.
    /// assert_eq!(iter.collect::<Vec<_>>(), vec![&5, &3]);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "peekable_peek_mut", issue = "78302")]
    pub fn peek_mut(&mut self) -> Option<&mut I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_mut()
    }

    /// Konsumsi dan kembalikan nilai berikutnya dari iterator ini jika kondisinya benar.
    /// Jika `func` mengembalikan `true` untuk nilai berikutnya dari iterator ini, konsumsi dan kembalikan.
    /// Jika tidak, kembalikan `None`.
    /// # Examples
    /// Konsumsi angka jika sama dengan 0.
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // Item pertama dari iterator adalah 0;konsumsilah.
    /// assert_eq!(iter.next_if(|&x| x == 0), Some(0));
    /// // Item berikutnya yang dikembalikan sekarang menjadi 1, jadi `consume` akan mengembalikan `false`.
    /// assert_eq!(iter.next_if(|&x| x == 0), None);
    /// // `next_if` menyimpan nilai item berikutnya jika tidak sama dengan `expected`.
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    ///
    /// Konsumsi angka apa pun yang kurang dari 10.
    ///
    /// ```
    /// let mut iter = (1..20).peekable();
    /// // Konsumsi semua angka kurang dari 10
    /// while iter.next_if(|&x| x < 10).is_some() {}
    /// // Nilai berikutnya yang dikembalikan adalah 10
    /// assert_eq!(iter.next(), Some(10));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if(&mut self, func: impl FnOnce(&I::Item) -> bool) -> Option<I::Item> {
        match self.next() {
            Some(matched) if func(&matched) => Some(matched),
            other => {
                // Karena kami memanggil `self.next()`, kami mengonsumsi `self.peeked`.
                assert!(self.peeked.is_none());
                self.peeked = Some(other);
                None
            }
        }
    }

    /// Konsumsi dan kembalikan item berikutnya jika sama dengan `expected`.
    /// # Example
    /// Konsumsi angka jika sama dengan 0.
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // Item pertama dari iterator adalah 0;konsumsilah.
    /// assert_eq!(iter.next_if_eq(&0), Some(0));
    /// // Item berikutnya yang dikembalikan sekarang menjadi 1, jadi `consume` akan mengembalikan `false`.
    /// assert_eq!(iter.next_if_eq(&0), None);
    /// // `next_if_eq` menyimpan nilai item berikutnya jika tidak sama dengan `expected`.
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if_eq<T>(&mut self, expected: &T) -> Option<I::Item>
    where
        T: ?Sized,
        I::Item: PartialEq<T>,
    {
        self.next_if(|next| next == expected)
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I> TrustedLen for Peekable<I> where I: TrustedLen {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<S: Iterator, I: Iterator> SourceIter for Peekable<I>
where
    I: SourceIter<Source = S>,
{
    type Source = S;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut S {
        // SAFETY: penerusan fungsi tidak aman ke fungsi tidak aman dengan persyaratan yang sama
        unsafe { SourceIter::as_inner(&mut self.iter) }
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I: InPlaceIterable> InPlaceIterable for Peekable<I> {}