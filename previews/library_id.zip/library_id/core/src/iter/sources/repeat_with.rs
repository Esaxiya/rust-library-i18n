use crate::iter::{FusedIterator, TrustedLen};

/// Membuat iterator baru yang mengulangi elemen tipe `A` tanpa henti dengan menerapkan closure yang disediakan, repeater, `F: FnMut() -> A`.
///
/// Fungsi `repeat_with()` memanggil repeater berulang kali.
///
/// Iterator tak terbatas seperti `repeat_with()` sering digunakan dengan adaptor seperti [`Iterator::take()`], untuk membuatnya terbatas.
///
/// Jika jenis elemen dari iterator yang Anda perlukan mengimplementasikan [`Clone`], dan tidak masalah untuk menyimpan elemen sumber dalam memori, Anda sebaiknya menggunakan fungsi [`repeat()`].
///
///
/// Sebuah iterator yang diproduksi oleh `repeat_with()` bukanlah [`DoubleEndedIterator`].
/// Jika Anda memerlukan `repeat_with()` untuk mengembalikan [`DoubleEndedIterator`], buka masalah GitHub yang menjelaskan kasus penggunaan Anda.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Penggunaan dasar:
///
/// ```
/// use std::iter;
///
/// // mari kita asumsikan kita memiliki beberapa nilai dari tipe yang bukan `Clone` atau yang belum ingin ada di memori karena mahal:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // nilai tertentu selamanya:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Menggunakan mutasi dan menjadi terbatas:
///
/// ```rust
/// use std::iter;
///
/// // Dari nol hingga kekuatan ketiga dari dua:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... dan sekarang kita sudah selesai
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// Sebuah iterator yang mengulangi elemen tipe `A` tanpa henti dengan menerapkan penutupan `F: FnMut() -> A` yang disediakan.
///
///
/// `struct` ini dibuat dengan fungsi [`repeat_with()`].
/// Lihat dokumentasinya untuk lebih lanjut.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}