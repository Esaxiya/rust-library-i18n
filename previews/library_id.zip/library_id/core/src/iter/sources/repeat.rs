use crate::iter::{FusedIterator, TrustedLen};

/// Membuat iterator baru yang mengulangi satu elemen tanpa henti.
///
/// Fungsi `repeat()` mengulangi satu nilai berulang kali.
///
/// Iterator tak terbatas seperti `repeat()` sering digunakan dengan adaptor seperti [`Iterator::take()`], untuk membuatnya terbatas.
///
/// Jika jenis elemen iterator yang Anda perlukan tidak mengimplementasikan `Clone`, atau jika Anda tidak ingin menyimpan elemen berulang dalam memori, Anda dapat menggunakan fungsi [`repeat_with()`].
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Penggunaan dasar:
///
/// ```
/// use std::iter;
///
/// // nomor empat 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // yup, masih empat
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Menjadi terbatas dengan [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // contoh terakhir itu terlalu banyak merangkak.Mari kita hanya memiliki empat merangkak.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... dan sekarang kita sudah selesai
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Sebuah iterator yang mengulang sebuah elemen tanpa henti.
///
/// `struct` ini dibuat dengan fungsi [`repeat()`].Lihat dokumentasinya untuk lebih lanjut.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}