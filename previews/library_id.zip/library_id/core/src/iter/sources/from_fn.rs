use crate::fmt;

/// Membuat iterator baru di mana setiap iterasi memanggil closure `F: FnMut() -> Option<T>` yang disediakan.
///
/// Hal ini memungkinkan pembuatan iterator khusus dengan perilaku apa pun tanpa menggunakan sintaks yang lebih panjang untuk membuat tipe khusus dan mengimplementasikan [`Iterator`] trait untuknya.
///
/// Perhatikan bahwa iterator `FromFn` tidak membuat asumsi tentang perilaku penutupan, dan oleh karena itu secara konservatif tidak mengimplementasikan [`FusedIterator`], atau menimpa [`Iterator::size_hint()`] dari `(0, None)` defaultnya.
///
///
/// Closure dapat menggunakan captures dan lingkungannya untuk melacak status di seluruh iterasi.Bergantung pada bagaimana iterator digunakan, ini mungkin memerlukan menentukan kata kunci [`move`] pada penutupan.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Mari kita implementasikan ulang counter iterator dari [module-level documentation]:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Tingkatkan hitungan kami.Inilah mengapa kami memulai dari nol.
///     count += 1;
///
///     // Periksa apakah kita sudah selesai menghitung atau belum.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// Sebuah iterator dimana setiap iterasi memanggil closure `F: FnMut() -> Option<T>` yang disediakan.
///
/// `struct` ini dibuat dengan fungsi [`iter::from_fn()`].
/// Lihat dokumentasinya untuk lebih lanjut.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}