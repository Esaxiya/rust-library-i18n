use crate::iter::{FusedIterator, TrustedLen};

/// Membuat iterator yang dengan malas menghasilkan nilai tepat satu kali dengan memanggil closure yang disediakan.
///
/// Ini biasanya digunakan untuk mengadaptasi generator nilai tunggal menjadi [`chain()`] dari jenis iterasi lainnya.
/// Mungkin Anda memiliki iterator yang mencakup hampir semua hal, tetapi Anda memerlukan casing ekstra khusus.
/// Mungkin Anda memiliki fungsi yang berfungsi pada iterator, tetapi Anda hanya perlu memproses satu nilai.
///
/// Tidak seperti [`once()`], fungsi ini dengan malas akan menghasilkan nilai sesuai permintaan.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Penggunaan dasar:
///
/// ```
/// use std::iter;
///
/// // satu adalah angka paling kesepian
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // hanya satu, hanya itu yang kami dapatkan
/// assert_eq!(None, one.next());
/// ```
///
/// Merangkai bersama dengan iterator lain.
/// Katakanlah kita ingin mengulang setiap file dari direktori `.foo`, tetapi juga file konfigurasi,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // kita perlu mengonversi dari iterator DirEntry-s menjadi iterator PathBufs, jadi kita menggunakan map
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // sekarang, iterator kami hanya untuk file konfigurasi kami
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // menghubungkan kedua iterator menjadi satu iterator besar
/// let files = dirs.chain(config);
///
/// // ini akan memberi kita semua file di .foo serta .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// Sebuah iterator yang menghasilkan satu elemen tipe `A` dengan menerapkan penutupan `F: FnOnce() -> A` yang disediakan.
///
///
/// `struct` ini dibuat dengan fungsi [`once_with()`].
/// Lihat dokumentasinya untuk lebih lanjut.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}