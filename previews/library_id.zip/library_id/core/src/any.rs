//! Modul ini mengimplementasikan `Any` trait, yang memungkinkan pengetikan dinamis jenis `'static` apa pun melalui refleksi waktu proses.
//!
//! `Any` sendiri dapat digunakan untuk mendapatkan `TypeId`, dan memiliki lebih banyak fitur jika digunakan sebagai objek trait.
//! Sebagai `&dyn Any` (objek trait yang dipinjam), ia memiliki metode `is` dan `downcast_ref`, untuk menguji apakah nilai yang terkandung adalah dari tipe tertentu, dan untuk mendapatkan referensi ke nilai dalam sebagai tipe.
//! Sebagai `&mut dyn Any`, ada juga metode `downcast_mut`, untuk mendapatkan referensi yang bisa berubah ke nilai bagian dalam.
//! `Box<dyn Any>` menambahkan metode `downcast`, yang mencoba mengonversi ke `Box<T>`.
//! Lihat dokumentasi [`Box`] untuk detail lengkapnya.
//!
//! Perhatikan bahwa `&dyn Any` terbatas untuk menguji apakah suatu nilai adalah jenis beton yang ditentukan, dan tidak dapat digunakan untuk menguji apakah suatu jenis menerapkan trait.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Pointer cerdas dan `dyn Any`
//!
//! Salah satu perilaku yang perlu diingat saat menggunakan `Any` sebagai objek trait, terutama dengan tipe seperti `Box<dyn Any>` atau `Arc<dyn Any>`, adalah hanya memanggil `.type_id()` pada nilai akan menghasilkan `TypeId` dari *container*, bukan objek trait yang mendasarinya.
//!
//! Hal ini dapat dihindari dengan mengubah smart pointer menjadi `&dyn Any`, yang akan mengembalikan `TypeId` objek.
//! Sebagai contoh:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Anda lebih cenderung menginginkan ini:
//! let actual_id = (&*boxed).type_id();
//! // ... dari ini:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Pertimbangkan situasi di mana kita ingin mengeluarkan nilai yang diteruskan ke suatu fungsi.
//! Kami tahu nilai yang kami kerjakan saat mengimplementasikan Debug, tetapi kami tidak tahu jenis konkretnya.Kami ingin memberikan perlakuan khusus untuk jenis tertentu: dalam hal ini mencetak panjang nilai String sebelum nilainya.
//! Kita tidak mengetahui tipe konkret dari nilai kita pada waktu kompilasi, jadi kita perlu menggunakan refleksi runtime sebagai gantinya.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Fungsi pencatat untuk semua jenis yang mengimplementasikan Debug.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Cobalah untuk mengubah nilai kami menjadi `String`.
//!     // Jika berhasil, kami ingin menampilkan panjang String serta nilainya.
//!     // Jika tidak, itu jenis yang berbeda: cetak saja tanpa hiasan.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Fungsi ini ingin mengeluarkan parameternya sebelum bekerja dengannya.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... melakukan pekerjaan lain
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Semua trait
///////////////////////////////////////////////////////////////////////////////

/// A trait untuk meniru pengetikan dinamis.
///
/// Kebanyakan tipe menerapkan `Any`.Namun, tipe apa pun yang berisi referensi non-`'static` tidak.
/// Lihat [module-level documentation][mod] untuk lebih jelasnya.
///
/// [mod]: crate::any
// trait ini tidak tidak aman, meskipun kami mengandalkan spesifikasi fungsi `type_id` implnya satu-satunya dalam kode yang tidak aman (mis., `downcast`).Biasanya, itu akan menjadi masalah, tetapi karena satu-satunya impl dari `Any` adalah implementasi selimut, tidak ada kode lain yang dapat mengimplementasikan `Any`.
//
// Kami secara masuk akal dapat membuat trait ini tidak aman-ini tidak akan menyebabkan kerusakan, karena kami mengontrol semua penerapan-tetapi kami memilih untuk tidak melakukannya karena keduanya tidak terlalu diperlukan dan dapat membingungkan pengguna tentang perbedaan traits yang tidak aman dan metode yang tidak aman (yaitu, `type_id` masih aman untuk dihubungi, tetapi kami mungkin ingin menunjukkannya dalam dokumentasi).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Mendapat `TypeId` dari `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Metode ekstensi untuk objek Any trait.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Pastikan bahwa hasil dari, misalnya, menyambungkan sebuah utas dapat dicetak dan karenanya digunakan dengan `unwrap`.
// Mungkin pada akhirnya tidak lagi diperlukan jika pengiriman berhasil dengan upcasting.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Mengembalikan `true` jika tipe kotaknya sama dengan `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Dapatkan `TypeId` dari jenis yang digunakan untuk fungsi ini.
        let t = TypeId::of::<T>();

        // Dapatkan `TypeId` dari tipe di objek trait (`self`).
        let concrete = self.type_id();

        // Bandingkan kedua `TypeId` pada persamaan.
        t == concrete
    }

    /// Mengembalikan beberapa referensi ke nilai dalam kotak jika berjenis `T`, atau `None` jika bukan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // KEAMANAN: cukup periksa apakah kami menunjuk ke tipe yang benar, dan kami dapat mengandalkan
            // yang memeriksa keamanan memori karena kami telah menerapkan Any untuk semua jenis;tidak ada impls lain yang dapat ada karena akan bertentangan dengan impl kami.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Mengembalikan beberapa referensi yang bisa berubah ke nilai dalam kotak jika berjenis `T`, atau `None` jika bukan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // KEAMANAN: cukup periksa apakah kami menunjuk ke tipe yang benar, dan kami dapat mengandalkan
            // yang memeriksa keamanan memori karena kami telah menerapkan Any untuk semua jenis;tidak ada impls lain yang dapat ada karena akan bertentangan dengan impl kami.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Meneruskan ke metode yang ditentukan pada tipe `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Meneruskan ke metode yang ditentukan pada tipe `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Meneruskan ke metode yang ditentukan pada tipe `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Meneruskan ke metode yang ditentukan pada tipe `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Meneruskan ke metode yang ditentukan pada tipe `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Meneruskan ke metode yang ditentukan pada tipe `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID dan metodenya
///////////////////////////////////////////////////////////////////////////////

/// `TypeId` mewakili pengenal unik global untuk suatu jenis.
///
/// Setiap `TypeId` adalah objek buram yang tidak memungkinkan pemeriksaan apa yang ada di dalamnya tetapi memungkinkan operasi dasar seperti kloning, perbandingan, pencetakan, dan pertunjukan.
///
///
/// A `TypeId` saat ini hanya tersedia untuk jenis yang dianggap berasal dari `'static`, tetapi batasan ini dapat dihapus di future.
///
/// Meskipun `TypeId` mengimplementasikan `Hash`, `PartialOrd`, dan `Ord`, perlu diperhatikan bahwa hash dan urutan akan bervariasi antara rilis Rust.
/// Berhati-hatilah dalam mengandalkan mereka di dalam kode Anda!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Mengembalikan `TypeId` dari jenis yang digunakan oleh fungsi generik ini.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Mengembalikan nama tipe sebagai potongan string.
///
/// # Note
///
/// Ini ditujukan untuk penggunaan diagnostik.
/// Isi dan format persis dari string yang dikembalikan tidak ditentukan, selain menjadi deskripsi jenis upaya terbaik.
/// Misalnya, di antara string yang mungkin dikembalikan `type_name::<Option<String>>()` adalah `"Option<String>"` dan `"std::option::Option<std::string::String>"`.
///
///
/// String yang dikembalikan tidak boleh dianggap sebagai pengenal unik dari suatu tipe karena beberapa tipe dapat dipetakan ke nama tipe yang sama.
/// Demikian pula, tidak ada jaminan bahwa semua bagian dari suatu tipe akan muncul dalam string yang dikembalikan: misalnya, penentu umur saat ini tidak disertakan.
/// Selain itu, output dapat berubah di antara versi kompilator.
///
/// Implementasi saat ini menggunakan infrastruktur yang sama dengan diagnostik compiler dan debuginfo, tetapi hal ini tidak dijamin.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Mengembalikan nama tipe nilai menunjuk ke sebagai potongan string.
/// Ini sama dengan `type_name::<T>()`, tetapi dapat digunakan jika jenis variabel tidak tersedia dengan mudah.
///
/// # Note
///
/// Ini ditujukan untuk penggunaan diagnostik.Isi dan format yang tepat dari string tidak ditentukan, selain menjadi deskripsi jenis upaya terbaik.
/// Misalnya, `type_name_of_val::<Option<String>>(None)` dapat menampilkan `"Option<String>"` atau `"std::option::Option<std::string::String>"`, tetapi tidak dapat menampilkan `"foobar"`.
///
/// Selain itu, output dapat berubah di antara versi kompilator.
///
/// Fungsi ini tidak menyelesaikan objek trait, artinya `type_name_of_val(&7u32 as &dyn Debug)` dapat mengembalikan `"dyn Debug"`, tetapi tidak `"u32"`.
///
/// Nama tipe tidak boleh dianggap sebagai pengenal unik dari sebuah tipe;
/// beberapa tipe mungkin memiliki nama tipe yang sama.
///
/// Implementasi saat ini menggunakan infrastruktur yang sama dengan diagnostik compiler dan debuginfo, tetapi hal ini tidak dijamin.
///
/// # Examples
///
/// Mencetak tipe integer dan float default.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}