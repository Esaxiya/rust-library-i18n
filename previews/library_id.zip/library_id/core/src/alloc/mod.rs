//! API alokasi memori

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// Kesalahan `AllocError` menunjukkan kegagalan alokasi yang mungkin disebabkan oleh kehabisan sumber daya atau sesuatu yang salah saat menggabungkan argumen input yang diberikan dengan pengalokasi ini.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (kita membutuhkan ini untuk impl downstream dari trait Error)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// Implementasi `Allocator` dapat mengalokasikan, menumbuhkan, menciutkan, dan membatalkan alokasi blok data sewenang-wenang yang dijelaskan melalui [`Layout`][].
///
/// `Allocator` dirancang untuk diimplementasikan pada ZST, referensi, atau pointer pintar karena memiliki pengalokasi seperti `MyAlloc([u8; N])` tidak dapat dipindahkan, tanpa memperbarui pointer ke memori yang dialokasikan.
///
/// Tidak seperti [`GlobalAlloc`][], alokasi berukuran nol diperbolehkan di `Allocator`.
/// Jika pengalokasi yang mendasari tidak mendukung ini (seperti jemalloc) atau mengembalikan pointer nol (seperti `libc::malloc`), ini harus ditangkap oleh implementasi.
///
/// ### Memori yang dialokasikan saat ini
///
/// Beberapa metode mengharuskan blok memori *saat ini dialokasikan* melalui pengalokasi.Artinya:
///
/// * alamat awal untuk blok memori itu sebelumnya dikembalikan oleh [`allocate`], [`grow`], atau [`shrink`], dan
///
/// * blok memori belum dibatalkan alokasinya, di mana blok dibatalkan alokasinya secara langsung dengan diteruskan ke [`deallocate`] atau diubah dengan diteruskan ke [`grow`] atau [`shrink`] yang mengembalikan `Ok`.
///
/// Jika `grow` atau `shrink` mengembalikan `Err`, penunjuk yang diberikan tetap valid.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Pemasangan memori
///
/// Beberapa metode memerlukan tata letak *cocok* dengan blok memori.
/// Apa yang dimaksud dengan layout ke "fit" berarti blok memori (atau yang setara, untuk blok memori ke "fit" sebuah layout) adalah kondisi berikut harus dipenuhi:
///
/// * Blok harus dialokasikan dengan perataan yang sama seperti [`layout.align()`], dan
///
/// * [`layout.size()`] yang diberikan harus berada dalam kisaran `min ..= max`, di mana:
///   - `min` adalah ukuran tata letak yang terakhir digunakan untuk mengalokasikan blok, dan
///   - `max` adalah ukuran aktual terbaru yang dikembalikan dari [`allocate`], [`grow`], atau [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Blok memori yang dikembalikan dari pengalokasi harus mengarah ke memori yang valid dan mempertahankan validitasnya hingga instance dan semua klonnya dihapus,
///
/// * menggandakan atau memindahkan pengalokasi tidak boleh membatalkan blok memori yang dikembalikan dari pengalokasi ini.Pengalokasi yang digandakan harus berperilaku seperti pengalokasi yang sama, dan
///
/// * pointer apa pun ke blok memori yang [*currently allocated*] dapat diteruskan ke metode pengalokasi lainnya.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Mencoba mengalokasikan satu blok memori.
    ///
    /// Jika berhasil, kembalikan [`NonNull<[u8]>`][NonNull] yang memenuhi jaminan ukuran dan keselarasan `layout`.
    ///
    /// Blok yang dikembalikan mungkin memiliki ukuran yang lebih besar dari yang ditentukan oleh `layout.size()`, dan mungkin isinya telah diinisialisasi atau tidak.
    ///
    /// # Errors
    ///
    /// Mengembalikan `Err` menunjukkan bahwa memori telah habis atau `layout` tidak memenuhi ukuran pengalokasi atau batasan penyelarasan.
    ///
    /// Penerapan didorong untuk mengembalikan `Err` saat kehabisan memori daripada panik atau membatalkan, tetapi ini bukan persyaratan yang ketat.
    /// (Secara khusus: itu *legal* untuk mengimplementasikan trait ini di atas pustaka alokasi asli yang mendasari yang membatalkan saat kehabisan memori.)
    ///
    /// Klien yang ingin membatalkan komputasi sebagai tanggapan atas kesalahan alokasi didorong untuk memanggil fungsi [`handle_alloc_error`], daripada langsung memanggil `panic!` atau yang serupa.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Berperilaku seperti `allocate`, tetapi juga memastikan bahwa memori yang dikembalikan diinisialisasi nol.
    ///
    /// # Errors
    ///
    /// Mengembalikan `Err` menunjukkan bahwa memori telah habis atau `layout` tidak memenuhi ukuran pengalokasi atau batasan penyelarasan.
    ///
    /// Penerapan didorong untuk mengembalikan `Err` saat kehabisan memori daripada panik atau membatalkan, tetapi ini bukan persyaratan yang ketat.
    /// (Secara khusus: itu *legal* untuk mengimplementasikan trait ini di atas pustaka alokasi asli yang mendasari yang membatalkan saat kehabisan memori.)
    ///
    /// Klien yang ingin membatalkan komputasi sebagai tanggapan atas kesalahan alokasi didorong untuk memanggil fungsi [`handle_alloc_error`], daripada langsung memanggil `panic!` atau yang serupa.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // KEAMANAN: `alloc` mengembalikan blok memori yang valid
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Membatalkan alokasi memori yang direferensikan oleh `ptr`.
    ///
    /// # Safety
    ///
    /// * `ptr` harus menunjukkan blok memori [*currently allocated*] melalui pengalokasi ini, dan
    /// * `layout` harus [*fit*] blok memori itu.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Mencoba memperpanjang blok memori.
    ///
    /// Mengembalikan [`NonNull<[u8]>`][NonNull] baru yang berisi penunjuk dan ukuran sebenarnya dari memori yang dialokasikan.Pointer cocok untuk menyimpan data yang dijelaskan oleh `new_layout`.
    /// Untuk melakukannya, pengalokasi dapat memperluas alokasi yang direferensikan oleh `ptr` agar sesuai dengan tata letak baru.
    ///
    /// Jika ini mengembalikan `Ok`, maka kepemilikan blok memori yang direferensikan oleh `ptr` telah ditransfer ke pengalokasi ini.
    /// Memori mungkin atau mungkin belum dibebaskan, dan harus dianggap tidak dapat digunakan kecuali ditransfer kembali ke pemanggil lagi melalui nilai kembali dari metode ini.
    ///
    /// Jika metode ini mengembalikan `Err`, maka kepemilikan blok memori belum ditransfer ke pengalokasi ini, dan konten blok memori tidak diubah.
    ///
    /// # Safety
    ///
    /// * `ptr` harus menunjukkan satu blok memori [*currently allocated*] melalui pengalokasi ini.
    /// * `old_layout` harus [*fit*] blok memori itu (Argumen `new_layout` tidak perlu cocok itu.).
    /// * `new_layout.size()` harus lebih besar dari atau sama dengan `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Mengembalikan `Err` jika tata letak baru tidak memenuhi ukuran pengalokasi dan batasan penyelarasan pengalokasi, atau jika berkembang sebaliknya gagal.
    ///
    /// Penerapan didorong untuk mengembalikan `Err` saat kehabisan memori daripada panik atau membatalkan, tetapi ini bukan persyaratan yang ketat.
    /// (Secara khusus: itu *legal* untuk mengimplementasikan trait ini di atas pustaka alokasi asli yang mendasari yang membatalkan saat kehabisan memori.)
    ///
    /// Klien yang ingin membatalkan komputasi sebagai tanggapan atas kesalahan alokasi didorong untuk memanggil fungsi [`handle_alloc_error`], daripada langsung memanggil `panic!` atau yang serupa.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SAFETY: karena `new_layout.size()` harus lebih besar dari atau sama dengan
        // `old_layout.size()`, baik alokasi memori lama dan baru valid untuk membaca dan menulis untuk byte `old_layout.size()`.
        // Selain itu, karena alokasi lama belum dialokasikan, alokasi tersebut tidak dapat tumpang tindih dengan `new_ptr`.
        // Dengan demikian, panggilan ke `copy_nonoverlapping` aman.
        // Kontrak keamanan untuk `dealloc` harus dipegang oleh penelepon.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Berperilaku seperti `grow`, tetapi juga memastikan bahwa konten baru disetel ke nol sebelum dikembalikan.
    ///
    /// Blok memori akan berisi konten berikut setelah panggilan berhasil ke
    /// `grow_zeroed`:
    ///   * Bytes `0..old_layout.size()` dipertahankan dari alokasi aslinya.
    ///   * Bytes `old_layout.size()..old_size` akan dipertahankan atau dihilangkan, bergantung pada implementasi pengalokasi.
    ///   `old_size` mengacu pada ukuran blok memori sebelum panggilan `grow_zeroed`, yang mungkin lebih besar dari ukuran yang semula diminta ketika dialokasikan.
    ///   * Bytes `old_size..new_size` menjadi nol.`new_size` mengacu pada ukuran blok memori yang dikembalikan oleh panggilan `grow_zeroed`.
    ///
    /// # Safety
    ///
    /// * `ptr` harus menunjukkan satu blok memori [*currently allocated*] melalui pengalokasi ini.
    /// * `old_layout` harus [*fit*] blok memori itu (Argumen `new_layout` tidak perlu cocok itu.).
    /// * `new_layout.size()` harus lebih besar dari atau sama dengan `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Mengembalikan `Err` jika tata letak baru tidak memenuhi ukuran pengalokasi dan batasan penyelarasan pengalokasi, atau jika berkembang sebaliknya gagal.
    ///
    /// Penerapan didorong untuk mengembalikan `Err` saat kehabisan memori daripada panik atau membatalkan, tetapi ini bukan persyaratan yang ketat.
    /// (Secara khusus: itu *legal* untuk mengimplementasikan trait ini di atas pustaka alokasi asli yang mendasari yang membatalkan saat kehabisan memori.)
    ///
    /// Klien yang ingin membatalkan komputasi sebagai tanggapan atas kesalahan alokasi didorong untuk memanggil fungsi [`handle_alloc_error`], daripada langsung memanggil `panic!` atau yang serupa.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // SAFETY: karena `new_layout.size()` harus lebih besar dari atau sama dengan
        // `old_layout.size()`, baik alokasi memori lama dan baru valid untuk membaca dan menulis untuk byte `old_layout.size()`.
        // Selain itu, karena alokasi lama belum dialokasikan, alokasi tersebut tidak dapat tumpang tindih dengan `new_ptr`.
        // Dengan demikian, panggilan ke `copy_nonoverlapping` aman.
        // Kontrak keamanan untuk `dealloc` harus dipegang oleh penelepon.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Mencoba mengecilkan blok memori.
    ///
    /// Mengembalikan [`NonNull<[u8]>`][NonNull] baru yang berisi penunjuk dan ukuran sebenarnya dari memori yang dialokasikan.Pointer cocok untuk menyimpan data yang dijelaskan oleh `new_layout`.
    /// Untuk melakukannya, pengalokasi dapat menyusutkan alokasi yang direferensikan oleh `ptr` agar sesuai dengan tata letak baru.
    ///
    /// Jika ini mengembalikan `Ok`, maka kepemilikan blok memori yang direferensikan oleh `ptr` telah ditransfer ke pengalokasi ini.
    /// Memori mungkin atau mungkin belum dibebaskan, dan harus dianggap tidak dapat digunakan kecuali ditransfer kembali ke pemanggil lagi melalui nilai kembali dari metode ini.
    ///
    /// Jika metode ini mengembalikan `Err`, maka kepemilikan blok memori belum ditransfer ke pengalokasi ini, dan konten blok memori tidak diubah.
    ///
    /// # Safety
    ///
    /// * `ptr` harus menunjukkan satu blok memori [*currently allocated*] melalui pengalokasi ini.
    /// * `old_layout` harus [*fit*] blok memori itu (Argumen `new_layout` tidak perlu cocok itu.).
    /// * `new_layout.size()` harus lebih kecil dari atau sama dengan `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Mengembalikan `Err` jika tata letak baru tidak memenuhi ukuran pengalokasi dan batasan penyelarasan pengalokasi, atau jika penyusutan gagal.
    ///
    /// Penerapan didorong untuk mengembalikan `Err` saat kehabisan memori daripada panik atau membatalkan, tetapi ini bukan persyaratan yang ketat.
    /// (Secara khusus: itu *legal* untuk mengimplementasikan trait ini di atas pustaka alokasi asli yang mendasari yang membatalkan saat kehabisan memori.)
    ///
    /// Klien yang ingin membatalkan komputasi sebagai tanggapan atas kesalahan alokasi didorong untuk memanggil fungsi [`handle_alloc_error`], daripada langsung memanggil `panic!` atau yang serupa.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // KEAMANAN: karena `new_layout.size()` harus lebih rendah dari atau sama dengan
        // `old_layout.size()`, baik alokasi memori lama dan baru valid untuk membaca dan menulis untuk byte `new_layout.size()`.
        // Selain itu, karena alokasi lama belum dialokasikan, alokasi tersebut tidak dapat tumpang tindih dengan `new_ptr`.
        // Dengan demikian, panggilan ke `copy_nonoverlapping` aman.
        // Kontrak keamanan untuk `dealloc` harus dipegang oleh penelepon.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Membuat adaptor "by reference" untuk instance `Allocator` ini.
    ///
    /// Adaptor yang dikembalikan juga mengimplementasikan `Allocator` dan hanya akan meminjam ini.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // KEAMANAN: kontrak keselamatan harus ditegakkan oleh penelepon
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // KEAMANAN: kontrak keselamatan harus ditegakkan oleh penelepon
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // KEAMANAN: kontrak keselamatan harus ditegakkan oleh penelepon
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // KEAMANAN: kontrak keselamatan harus ditegakkan oleh penelepon
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}