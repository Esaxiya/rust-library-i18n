use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Meskipun fungsi ini digunakan di satu tempat dan implementasinya dapat disisipkan, upaya sebelumnya untuk melakukannya membuat rustc lebih lambat:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Tata letak blok memori.
///
/// Sebuah instance dari `Layout` menjelaskan tata letak memori tertentu.
/// Anda membangun `Layout` sebagai masukan untuk diberikan kepada pengalokasi.
///
/// Semua tata letak memiliki ukuran terkait dan perataan kekuatan dua.
///
/// (Perhatikan bahwa tata letak *tidak* harus berukuran bukan nol, meskipun `GlobalAlloc` mengharuskan semua permintaan memori berukuran bukan nol.
/// Penelepon harus memastikan bahwa kondisi seperti ini terpenuhi, menggunakan pengalokasi khusus dengan persyaratan yang lebih longgar, atau menggunakan antarmuka `Allocator` yang lebih longgar.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // ukuran blok memori yang diminta, diukur dalam byte.
    size_: usize,

    // penyelarasan blok memori yang diminta, diukur dalam byte.
    // kami memastikan bahwa ini selalu merupakan kekuatan dua, karena API seperti `posix_memalign` memerlukannya dan merupakan batasan yang wajar untuk diterapkan pada konstruktor Tata Letak.
    //
    //
    // (Namun, kami secara analogis tidak membutuhkan `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Membuat `Layout` dari `size` dan `align` tertentu, atau mengembalikan `LayoutError` jika salah satu kondisi berikut tidak terpenuhi:
    ///
    /// * `align` tidak boleh nol,
    ///
    /// * `align` harus menjadi kekuatan dua,
    ///
    /// * `size`, jika dibulatkan ke kelipatan `align` terdekat, tidak boleh meluap (yaitu, nilai yang dibulatkan harus kurang dari atau sama dengan `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (power-of-two menyiratkan align!=0.)

        // Ukuran yang dibulatkan adalah:
        //   size_rounded_up=(size + align, 1)&! (align, 1);
        //
        // Kita tahu dari atas bahwa align!=0.
        // Jika menambahkan (sejajarkan, 1) tidak meluap, maka pembulatan akan baik-baik saja.
        //
        // Sebaliknya,&-masking with! (Align, 1) hanya akan mengurangi bit-bit orde rendah.
        // Jadi, jika luapan terjadi dengan penjumlahan,&-masker tidak bisa mengurangi cukup untuk membatalkan luapan itu.
        //
        //
        // Di atas menyiratkan bahwa pemeriksaan penjumlahan overflow adalah perlu dan cukup.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // KEAMANAN: kondisi untuk `from_size_align_unchecked` telah
        // diperiksa di atas.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Membuat tata letak, melewati semua pemeriksaan.
    ///
    /// # Safety
    ///
    /// Fungsi ini tidak aman karena tidak memverifikasi prasyarat dari [`Layout::from_size_align`].
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // KEAMANAN: penelepon harus memastikan bahwa `align` lebih besar dari nol.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Ukuran minimum dalam byte untuk blok memori tata letak ini.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// Penyelarasan byte minimum untuk blok memori tata letak ini.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Membuat `Layout` yang sesuai untuk menyimpan nilai tipe `T`.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // KEAMANAN: keselarasan dijamin oleh Rust menjadi kekuatan dua dan
        // combo size + align dijamin sesuai dengan address space kami.
        // Akibatnya, gunakan konstruktor yang tidak dicentang di sini untuk menghindari penyisipan kode yang panics jika tidak dioptimalkan dengan cukup baik.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Menghasilkan tata letak yang mendeskripsikan rekaman yang dapat digunakan untuk mengalokasikan struktur pendukung untuk `T` (yang dapat berupa trait atau jenis berukuran besar lainnya seperti potongan).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // KEAMANAN: lihat alasan di `new` mengapa ini menggunakan varian yang tidak aman
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Menghasilkan tata letak yang mendeskripsikan rekaman yang dapat digunakan untuk mengalokasikan struktur pendukung untuk `T` (yang dapat berupa trait atau jenis berukuran besar lainnya seperti potongan).
    ///
    /// # Safety
    ///
    /// Fungsi ini hanya aman untuk dipanggil jika kondisi berikut berlaku:
    ///
    /// - Jika `T` adalah `Sized`, fungsi ini selalu aman untuk dipanggil.
    /// - Jika ekor `T` berukuran besar adalah:
    ///     - a [slice], maka panjang ekor irisan harus berupa bilangan bulat yang diinisialisasi, dan ukuran *nilai keseluruhan*(panjang ekor dinamis + awalan berukuran statis) harus sesuai dengan `isize`.
    ///     - a [trait object], maka bagian vtable dari pointer harus menunjuk ke vtable yang valid untuk tipe `T` yang diperoleh dengan koersi unsizing, dan ukuran *seluruh nilai*(panjang ekor dinamis + prefiks berukuran statis) harus sesuai dengan `isize`.
    ///
    ///     - sebuah (unstable) [extern type], maka fungsi ini selalu aman untuk dipanggil, tetapi mungkin panic atau sebaliknya mengembalikan nilai yang salah, karena tata letak tipe eksternal tidak diketahui.
    ///     Ini adalah perilaku yang sama seperti [`Layout::for_value`] pada referensi ke ekor tipe eksternal.
    ///     - jika tidak, secara konservatif tidak diperbolehkan untuk memanggil fungsi ini.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // KEAMANAN: kami meneruskan prasyarat dari fungsi-fungsi ini ke pemanggil
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // KEAMANAN: lihat alasan di `new` mengapa ini menggunakan varian yang tidak aman
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Membuat `NonNull` yang menjuntai, tetapi selaras untuk Tata Letak ini.
    ///
    /// Perhatikan bahwa nilai penunjuk berpotensi mewakili penunjuk yang valid, yang berarti ini tidak boleh digunakan sebagai nilai sentinel "not yet initialized".
    /// Jenis yang dengan malas mengalokasikan harus melacak inisialisasi dengan cara lain.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // SAFETY: align dijamin bukan nol
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Membuat tata letak yang mendeskripsikan rekaman yang dapat menyimpan nilai tata letak yang sama seperti `self`, tetapi itu juga selaras dengan penyelarasan `align` (diukur dalam byte).
    ///
    ///
    /// Jika `self` sudah memenuhi perataan yang ditentukan, maka kembalikan `self`.
    ///
    /// Perhatikan bahwa metode ini tidak menambahkan padding apa pun ke ukuran keseluruhan, terlepas dari apakah tata letak yang dikembalikan memiliki perataan yang berbeda.
    /// Dengan kata lain, jika `K` berukuran 16, `K.align_to(32)` akan *masih* berukuran 16.
    ///
    /// Mengembalikan kesalahan jika kombinasi `self.size()` dan `align` yang diberikan melanggar ketentuan yang tercantum di [`Layout::from_size_align`].
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Mengembalikan jumlah padding yang harus kita sisipkan setelah `self` untuk memastikan bahwa alamat berikut akan memenuhi `align` (diukur dalam byte).
    ///
    /// misalnya, jika `self.size()` adalah 9, maka `self.padding_needed_for(4)` mengembalikan 3, karena itu adalah jumlah minimum byte padding yang diperlukan untuk mendapatkan alamat 4-aligned (dengan asumsi bahwa blok memori yang sesuai dimulai pada alamat 4-aligned).
    ///
    ///
    /// Nilai kembali dari fungsi ini tidak ada artinya jika `align` bukan pangkat dua.
    ///
    /// Perhatikan bahwa utilitas dari nilai yang dikembalikan memerlukan `align` kurang dari atau sama dengan penyelarasan alamat awal untuk seluruh blok memori yang dialokasikan.Salah satu cara untuk memenuhi batasan ini adalah dengan memastikan `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Nilai yang dibulatkan adalah:
        //   len_rounded_up=(len + align, 1)&! (align, 1);
        // dan kemudian kami mengembalikan perbedaan padding: `len_rounded_up - len`.
        //
        // Kami menggunakan aritmatika modular di seluruh:
        //
        // 1. align dijamin> 0, jadi align, 1 selalu valid.
        //
        // 2.
        // `len + align - 1` dapat meluap paling banyak `align - 1`, jadi&-mask dengan `!(align - 1)` akan memastikan bahwa dalam kasus luapan, `len_rounded_up` itu sendiri akan menjadi 0.
        //
        //    Jadi bantalan yang dikembalikan, ketika ditambahkan ke `len`, menghasilkan 0, yang secara sederhana memenuhi perataan `align`.
        //
        // (Tentu saja, upaya untuk mengalokasikan blok memori yang ukuran dan paddingnya melimpah dengan cara di atas akan menyebabkan pengalokasi tetap menghasilkan kesalahan.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Membuat tata letak dengan membulatkan ukuran tata letak ini ke beberapa keselarasan tata letak.
    ///
    ///
    /// Ini sama dengan menambahkan hasil `padding_needed_for` ke ukuran tata letak saat ini.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Ini tidak bisa meluap.Mengutip dari invariant Layout:
        // > `size`, jika dibulatkan ke kelipatan `align` terdekat,
        // > tidak boleh meluap (yaitu, nilai yang dibulatkan harus kurang dari
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Membuat tata letak yang mendeskripsikan catatan untuk instans `n` dari `self`, dengan jumlah padding yang sesuai di antara masing-masing untuk memastikan bahwa setiap instans diberikan ukuran dan penyelarasan yang diminta.
    /// Jika berhasil, mengembalikan `(k, offs)` dengan `k` adalah tata letak larik dan `offs` adalah jarak antara awal setiap elemen dalam larik.
    ///
    /// Pada aritmatika overflow, mengembalikan `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Ini tidak bisa meluap.Mengutip dari invariant Layout:
        // > `size`, jika dibulatkan ke kelipatan `align` terdekat,
        // > tidak boleh meluap (yaitu, nilai yang dibulatkan harus kurang dari
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // KESELAMATAN: self.align telah diketahui valid dan alokasi_ukuran telah digunakan
        // sudah empuk.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Membuat tata letak yang menjelaskan catatan untuk `self` diikuti oleh `next`, termasuk pengisi apa pun yang diperlukan untuk memastikan bahwa `next` akan disejajarkan dengan benar, tetapi *tidak ada bantalan tambahan*.
    ///
    /// Untuk mencocokkan tata letak representasi C `repr(C)`, Anda harus memanggil `pad_to_align` setelah memperluas tata letak dengan semua bidang.
    /// (Tidak ada cara untuk mencocokkan tata letak representasi Rust default `repr(Rust)`, as it is unspecified.)
    ///
    /// Perhatikan bahwa penyelarasan tata letak yang dihasilkan akan menjadi yang maksimal pada `self` dan `next`, untuk memastikan keselarasan kedua bagian.
    ///
    /// Mengembalikan `Ok((k, offset))`, di mana `k` adalah tata letak dari rekaman yang digabungkan dan `offset` adalah lokasi relatif, dalam byte, dari awal `next` yang disematkan dalam rekaman yang digabungkan (dengan asumsi bahwa rekaman itu sendiri dimulai pada offset 0).
    ///
    ///
    /// Pada aritmatika overflow, mengembalikan `LayoutError`.
    ///
    /// # Examples
    ///
    /// Untuk menghitung tata letak struktur `#[repr(C)]` dan offset bidang dari tata letak bidangnya:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Ingatlah untuk menyelesaikan dengan `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // uji apakah itu berhasil
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Membuat tata letak yang menjelaskan catatan untuk `n` instance `self`, tanpa padding di antara setiap instance.
    ///
    /// Perhatikan bahwa, tidak seperti `repeat`, `repeat_packed` tidak menjamin bahwa instance `self` yang berulang akan disejajarkan dengan benar, meskipun instance `self` yang diberikan telah disejajarkan dengan benar.
    /// Dengan kata lain, jika tata letak yang dikembalikan oleh `repeat_packed` digunakan untuk mengalokasikan larik, tidak ada jaminan bahwa semua elemen dalam larik akan disejajarkan dengan benar.
    ///
    /// Pada aritmatika overflow, mengembalikan `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Membuat tata letak yang menjelaskan rekaman untuk `self` diikuti oleh `next` tanpa padding tambahan di antara keduanya.
    /// Karena tidak ada padding yang dimasukkan, penyelarasan `next` menjadi tidak relevan, dan tidak dimasukkan *sama sekali* ke dalam tata letak yang dihasilkan.
    ///
    ///
    /// Pada aritmatika overflow, mengembalikan `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Membuat tata letak yang menjelaskan rekaman untuk `[T; n]`.
    ///
    /// Pada aritmatika overflow, mengembalikan `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// Parameter yang diberikan ke `Layout::from_size_align` atau beberapa konstruktor `Layout` lainnya tidak memenuhi batasan yang didokumentasikan.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (kita membutuhkan ini untuk impl downstream dari trait Error)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}