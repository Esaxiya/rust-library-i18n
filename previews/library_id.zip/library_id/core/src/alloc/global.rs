use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// Pengalokasi memori yang dapat didaftarkan sebagai perpustakaan standar melalui atribut `#[global_allocator]`.
///
/// Beberapa metode mengharuskan blok memori *saat ini dialokasikan* melalui pengalokasi.Artinya:
///
/// * alamat awal untuk blok memori itu sebelumnya dikembalikan oleh panggilan sebelumnya ke metode alokasi seperti `alloc`, dan
///
/// * blok memori belum dialokasikan, di mana blok dibatalkan alokasinya baik dengan diteruskan ke metode deallocation seperti `dealloc` atau dengan diteruskan ke metode realokasi yang mengembalikan pointer non-null.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// `GlobalAlloc` trait adalah `unsafe` trait karena sejumlah alasan, dan pelaksana harus memastikan bahwa mereka mematuhi kontrak berikut:
///
/// * Ini adalah perilaku yang tidak ditentukan jika pengalokasi global melepas.Pembatasan ini dapat dicabut di future, tetapi saat ini panic dari salah satu fungsi ini dapat menyebabkan ketidakamanan memori.
///
/// * `Layout` pertanyaan dan perhitungan secara umum harus benar.Penelepon trait ini diizinkan untuk mengandalkan kontrak yang ditentukan pada setiap metode, dan pelaksana harus memastikan kontrak tersebut tetap benar.
///
/// * Anda tidak boleh mengandalkan alokasi yang benar-benar terjadi, meskipun ada alokasi heap eksplisit di sumbernya.
/// Pengoptimal dapat mendeteksi alokasi yang tidak digunakan yang dapat dihilangkan seluruhnya atau dipindahkan ke stack dan dengan demikian tidak pernah memanggil pengalokasi.
/// Pengoptimal selanjutnya dapat berasumsi bahwa alokasi tidak bisa salah, sehingga kode yang dulunya gagal karena kegagalan pengalokasi sekarang dapat bekerja secara tiba-tiba karena pengoptimal bekerja di sekitar kebutuhan akan alokasi.
/// Lebih tepatnya, contoh kode berikut ini tidak benar, terlepas dari apakah pengalokasi khusus Anda mengizinkan penghitungan berapa banyak alokasi yang telah terjadi.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Perhatikan bahwa pengoptimalan yang disebutkan di atas bukan satu-satunya pengoptimalan yang dapat diterapkan.Biasanya Anda tidak dapat mengandalkan alokasi heap yang terjadi jika mereka dapat dihapus tanpa mengubah perilaku program.
///   Apakah alokasi terjadi atau tidak bukanlah bagian dari perilaku program, bahkan jika itu dapat dideteksi melalui pengalokasi yang melacak alokasi dengan mencetak atau memiliki efek samping.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Alokasikan memori seperti yang dijelaskan oleh `layout` yang diberikan.
    ///
    /// Mengembalikan pointer ke memori yang baru dialokasikan, atau null untuk menunjukkan kegagalan alokasi.
    ///
    /// # Safety
    ///
    /// Fungsi ini tidak aman karena perilaku yang tidak ditentukan dapat terjadi jika pemanggil tidak memastikan bahwa `layout` memiliki ukuran bukan nol.
    ///
    /// (Ekstensi subtraits mungkin memberikan batasan yang lebih spesifik pada perilaku, misalnya, menjamin alamat sentinel atau pointer nol sebagai tanggapan atas permintaan alokasi ukuran nol.)
    ///
    /// Blok memori yang dialokasikan mungkin atau mungkin tidak diinisialisasi.
    ///
    /// # Errors
    ///
    /// Mengembalikan pointer nol menunjukkan bahwa memori telah habis atau `layout` tidak memenuhi ukuran pengalokasi atau batasan penyelarasan.
    ///
    /// Penerapan didorong untuk mengembalikan null saat kehabisan memori daripada membatalkan, tetapi ini bukan persyaratan yang ketat.
    /// (Secara khusus: itu *legal* untuk mengimplementasikan trait ini di atas pustaka alokasi asli yang mendasari yang membatalkan saat kehabisan memori.)
    ///
    /// Klien yang ingin membatalkan komputasi sebagai tanggapan atas kesalahan alokasi didorong untuk memanggil fungsi [`handle_alloc_error`], daripada langsung memanggil `panic!` atau yang serupa.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Batalkan alokasi blok memori pada penunjuk `ptr` yang diberikan dengan `layout` yang diberikan.
    ///
    /// # Safety
    ///
    /// Fungsi ini tidak aman karena perilaku yang tidak ditentukan dapat terjadi jika pemanggil tidak memastikan semua hal berikut:
    ///
    ///
    /// * `ptr` harus menunjukkan blok memori yang saat ini dialokasikan melalui pengalokasi ini,
    ///
    /// * `layout` harus sama dengan tata letak yang digunakan untuk mengalokasikan blok memori itu.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// Berperilaku seperti `alloc`, tetapi juga memastikan bahwa konten disetel ke nol sebelum dikembalikan.
    ///
    /// # Safety
    ///
    /// Fungsi ini tidak aman karena alasan yang sama dengan `alloc`.
    /// Namun blok memori yang dialokasikan dijamin akan diinisialisasi.
    ///
    /// # Errors
    ///
    /// Mengembalikan pointer nol menunjukkan bahwa memori telah habis atau `layout` tidak memenuhi ukuran pengalokasi atau batasan penyelarasan, seperti di `alloc`.
    ///
    /// Klien yang ingin membatalkan komputasi sebagai tanggapan atas kesalahan alokasi didorong untuk memanggil fungsi [`handle_alloc_error`], daripada langsung memanggil `panic!` atau yang serupa.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // KEAMANAN: kontrak keamanan untuk `alloc` harus ditegakkan oleh penelepon.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // KEAMANAN: setelah alokasi berhasil, wilayah dari `ptr`
            // ukuran `size` dijamin valid untuk penulisan.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Kecilkan atau kembangkan satu blok memori ke `new_size` yang diberikan.
    /// Blok tersebut dijelaskan oleh penunjuk `ptr` dan `layout` yang diberikan.
    ///
    /// Jika ini mengembalikan pointer non-null, maka kepemilikan blok memori yang direferensikan oleh `ptr` telah ditransfer ke pengalokasi ini.
    /// Memori mungkin atau mungkin belum dialokasikan, dan harus dianggap tidak dapat digunakan (kecuali tentu saja itu ditransfer kembali ke pemanggil lagi melalui nilai kembali dari metode ini).
    /// Blok memori baru dialokasikan dengan `layout`, tetapi dengan `size` diperbarui ke `new_size`.
    /// Tata letak baru ini harus digunakan saat membatalkan alokasi blok memori baru dengan `dealloc`.
    /// Rentang `0..min(layout.size(), ukuran_baru) `dari blok memori baru dijamin memiliki nilai yang sama dengan blok asli.
    ///
    /// Jika metode ini mengembalikan null, maka kepemilikan blok memori belum ditransfer ke pengalokasi ini, dan konten blok memori tidak diubah.
    ///
    /// # Safety
    ///
    /// Fungsi ini tidak aman karena perilaku yang tidak ditentukan dapat terjadi jika pemanggil tidak memastikan semua hal berikut:
    ///
    /// * `ptr` harus saat ini dialokasikan melalui pengalokasi ini,
    ///
    /// * `layout` harus tata letak yang sama yang digunakan untuk mengalokasikan blok memori itu,
    ///
    /// * `new_size` harus lebih besar dari nol.
    ///
    /// * `new_size`, jika dibulatkan ke kelipatan `layout.align()` terdekat, tidak boleh meluap (yaitu, nilai yang dibulatkan harus kurang dari `usize::MAX`).
    ///
    /// (Ekstensi subtraits mungkin memberikan batasan yang lebih spesifik pada perilaku, misalnya, menjamin alamat sentinel atau pointer nol sebagai tanggapan atas permintaan alokasi ukuran nol.)
    ///
    /// # Errors
    ///
    /// Mengembalikan null jika tata letak baru tidak memenuhi batasan ukuran dan penyelarasan pengalokasi, atau jika realokasi gagal.
    ///
    /// Penerapan didorong untuk menampilkan null karena kehabisan memori daripada panik atau membatalkan, tetapi ini bukan persyaratan yang ketat.
    /// (Secara khusus: itu *legal* untuk mengimplementasikan trait ini di atas pustaka alokasi asli yang mendasari yang membatalkan saat kehabisan memori.)
    ///
    /// Klien yang ingin membatalkan komputasi sebagai respons terhadap kesalahan realokasi didorong untuk memanggil fungsi [`handle_alloc_error`], daripada langsung memanggil `panic!` atau yang serupa.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // KEAMANAN: penelepon harus memastikan bahwa `new_size` tidak meluap.
        // `layout.align()` berasal dari `Layout` dan dijamin valid.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // KEAMANAN: penelepon harus memastikan bahwa `new_layout` lebih besar dari nol.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // KEAMANAN: blok yang dialokasikan sebelumnya tidak boleh tumpang tindih dengan blok yang baru dialokasikan.
            // Kontrak keamanan untuk `dealloc` harus dipegang oleh penelepon.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}