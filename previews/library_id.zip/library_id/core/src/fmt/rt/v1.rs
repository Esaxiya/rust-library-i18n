//! Ini adalah modul internal yang digunakan oleh ifmt!runtime.Struktur ini dipancarkan ke larik statis ke string format prakompilasi sebelumnya.
//!
//! Definisi ini mirip dengan padanan `ct`-nya, tetapi berbeda dalam hal ini dapat dialokasikan secara statis dan sedikit dioptimalkan untuk runtime
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Kemungkinan penyelarasan yang dapat diminta sebagai bagian dari petunjuk pemformatan.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Indikasi bahwa konten harus rata kiri.
    Left,
    /// Indikasi bahwa konten harus rata kanan.
    Right,
    /// Indikasi bahwa konten harus rata tengah.
    Center,
    /// Tidak ada perataan yang diminta.
    Unknown,
}

/// Digunakan oleh penentu [width](https://doc.rust-lang.org/std/fmt/#width) dan [precision](https://doc.rust-lang.org/std/fmt/#precision).
#[derive(Copy, Clone)]
pub enum Count {
    /// Ditentukan dengan angka literal, menyimpan nilainya
    Is(usize),
    /// Ditentukan menggunakan sintaks `$` dan `*`, menyimpan indeks ke `args`
    Param(usize),
    /// Tidak ditentukan
    Implied,
}