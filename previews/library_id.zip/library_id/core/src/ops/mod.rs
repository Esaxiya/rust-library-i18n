//! Operator yang bisa kelebihan beban.
//!
//! Menerapkan traits ini memungkinkan Anda membebani operator tertentu secara berlebihan.
//!
//! Beberapa dari traits ini diimpor oleh prelude, sehingga tersedia di setiap program Rust.Hanya operator yang didukung oleh traits yang dapat kelebihan beban.
//! Misalnya, operator tambahan (`+`) dapat kelebihan beban melalui [`Add`] trait, tetapi karena operator penugasan (`=`) tidak memiliki dukungan trait, tidak ada cara untuk membebani semantiknya secara berlebihan.
//! Selain itu, modul ini tidak menyediakan mekanisme apa pun untuk membuat operator baru.
//! Jika kelebihan muatan tanpa sifat atau operator khusus diperlukan, Anda harus melihat ke makro atau plugin kompilator untuk memperluas sintaks Rust.
//!
//! Penerapan operator traits seharusnya tidak mengejutkan dalam konteksnya masing-masing, dengan mengingat arti dan [operator precedence] yang biasa.
//! Misalnya, saat mengimplementasikan [`Mul`], operasi tersebut harus memiliki kemiripan dengan perkalian (dan berbagi properti yang diharapkan seperti asosiativitas).
//!
//! Perhatikan bahwa operator `&&` dan `||` mengalami hubung singkat, yaitu, mereka hanya mengevaluasi operan kedua jika memberikan kontribusi pada hasil.Karena perilaku ini tidak dapat diberlakukan oleh traits, `&&` dan `||` tidak didukung sebagai operator yang dapat kelebihan beban.
//!
//! Banyak operator mengambil operan mereka berdasarkan nilainya.Dalam konteks non-generik yang melibatkan tipe bawaan, ini biasanya tidak menjadi masalah.
//! Namun, menggunakan operator ini dalam kode generik, memerlukan perhatian jika nilai harus digunakan kembali daripada membiarkan operator mengkonsumsinya.Salah satu opsinya adalah sesekali menggunakan [`clone`].
//! Opsi lainnya adalah mengandalkan jenis yang terlibat dalam menyediakan implementasi operator tambahan untuk referensi.
//! Misalnya, untuk tipe `T` yang ditentukan pengguna yang seharusnya mendukung penambahan, mungkin sebaiknya `T` dan `&T` mengimplementasikan traits [`Add<T>`][`Add`] dan [`Add<&T>`][`Add`] sehingga kode generik dapat ditulis tanpa kloning yang tidak perlu.
//!
//!
//! # Examples
//!
//! Contoh ini membuat struct `Point` yang mengimplementasikan [`Add`] dan [`Sub`], lalu mendemonstrasikan penambahan dan pengurangan dua `Titik`.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Lihat dokumentasi untuk setiap trait untuk contoh implementasi.
//!
//! [`Fn`], [`FnMut`], dan [`FnOnce`] traits diimplementasikan oleh tipe yang dapat dipanggil seperti fungsi.Perhatikan bahwa [`Fn`] membutuhkan `&self`, [`FnMut`] membutuhkan `&mut self` dan [`FnOnce`] membutuhkan `self`.
//! Ini sesuai dengan tiga jenis metode yang bisa dipanggil pada sebuah instance: call-by-reference, call-by-mutable-reference, dan call-by-value.
//! Penggunaan paling umum dari traits ini adalah untuk bertindak sebagai batas ke fungsi tingkat lebih tinggi yang menggunakan fungsi atau penutupan sebagai argumen.
//!
//! Mengambil [`Fn`] sebagai parameter:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Mengambil [`FnMut`] sebagai parameter:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Mengambil [`FnOnce`] sebagai parameter:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` mengkonsumsi variabel yang ditangkap, sehingga tidak dapat dijalankan lebih dari sekali
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Mencoba memanggil `func()` lagi akan memunculkan kesalahan `use of moved value` untuk `func`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` tidak dapat lagi dipanggil saat ini
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;