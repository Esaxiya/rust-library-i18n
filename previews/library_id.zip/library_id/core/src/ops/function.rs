/// Versi operator panggilan yang menggunakan penerima yang tidak dapat diubah.
///
/// Instance `Fn` dapat dipanggil berulang kali tanpa status mutasi.
///
/// *trait (`Fn`) ini berbeda dengan [function pointers] (`fn`).*
///
/// `Fn` diimplementasikan secara otomatis oleh closure yang hanya mengambil referensi tetap ke variabel yang ditangkap atau tidak menangkap apapun sama sekali, serta (safe) [function pointers] (dengan beberapa peringatan, lihat dokumentasinya untuk lebih jelasnya).
///
/// Selain itu, untuk semua tipe `F` yang mengimplementasikan `Fn`, `&F` juga mengimplementasikan `Fn`.
///
/// Karena [`FnMut`] dan [`FnOnce`] adalah supertraits `Fn`, setiap instance `Fn` dapat digunakan sebagai parameter yang diharapkan [`FnMut`] atau [`FnOnce`].
///
/// Gunakan `Fn` sebagai pengikat ketika Anda ingin menerima parameter dengan tipe seperti fungsi dan perlu memanggilnya berulang kali dan tanpa status mutasi (misalnya, saat memanggilnya secara bersamaan).
/// Jika Anda tidak membutuhkan persyaratan ketat seperti itu, gunakan [`FnMut`] atau [`FnOnce`] sebagai batasan.
///
/// Lihat [chapter on closures in *The Rust Programming Language*][book] untuk informasi lebih lanjut tentang topik ini.
///
/// Yang juga perlu diperhatikan adalah sintaks khusus untuk `Fn` traits (mis
/// `Fn(usize, bool) -> usize`).Mereka yang tertarik dengan detail teknis ini dapat merujuk ke [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Memanggil penutupan
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Menggunakan parameter `Fn`
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // sehingga regex dapat mengandalkan `&str: !FnMut` itu
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Melakukan operasi panggilan.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Versi operator panggilan yang menerima penerima yang bisa berubah.
///
/// Instance `FnMut` dapat dipanggil berulang kali dan dapat berubah status.
///
/// `FnMut` diimplementasikan secara otomatis oleh closure yang mengambil referensi yang bisa berubah ke variabel yang ditangkap, serta semua tipe yang mengimplementasikan [`Fn`], misalnya, (safe) [function pointers] (karena `FnMut` adalah supertrait dari [`Fn`]).
/// Selain itu, untuk semua tipe `F` yang mengimplementasikan `FnMut`, `&mut F` juga mengimplementasikan `FnMut`.
///
/// Karena [`FnOnce`] adalah supertrait dari `FnMut`, semua instance `FnMut` dapat digunakan di mana [`FnOnce`] diharapkan, dan karena [`Fn`] adalah subtrait dari `FnMut`, semua instance [`Fn`] dapat digunakan di mana `FnMut` diharapkan.
///
/// Gunakan `FnMut` sebagai pengikat ketika Anda ingin menerima parameter jenis fungsi dan perlu memanggilnya berulang kali, sambil mengizinkannya untuk mengubah status.
/// Jika Anda tidak ingin parameter berubah status, gunakan [`Fn`] sebagai terikat;jika Anda tidak perlu memanggilnya berulang kali, gunakan [`FnOnce`].
///
/// Lihat [chapter on closures in *The Rust Programming Language*][book] untuk informasi lebih lanjut tentang topik ini.
///
/// Yang juga perlu diperhatikan adalah sintaks khusus untuk `Fn` traits (mis
/// `Fn(usize, bool) -> usize`).Mereka yang tertarik dengan detail teknis ini dapat merujuk ke [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Memanggil penutupan yang saling menangkap
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Menggunakan parameter `FnMut`
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // sehingga regex dapat mengandalkan `&str: !FnMut` itu
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Melakukan operasi panggilan.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Versi operator panggilan yang menggunakan penerima nilai.
///
/// Contoh `FnOnce` dapat dipanggil, tetapi mungkin tidak dapat dipanggil beberapa kali.Karenanya, jika satu-satunya hal yang diketahui tentang suatu tipe adalah ia mengimplementasikan `FnOnce`, ia hanya dapat dipanggil sekali.
///
/// `FnOnce` diimplementasikan secara otomatis oleh closure yang mungkin menggunakan variabel yang ditangkap, serta semua tipe yang mengimplementasikan [`FnMut`], misalnya, (safe) [function pointers] (karena `FnOnce` adalah supertrait dari [`FnMut`]).
///
///
/// Karena [`Fn`] dan [`FnMut`] adalah subtraits dari `FnOnce`, semua instance [`Fn`] atau [`FnMut`] dapat digunakan di tempat yang diharapkan `FnOnce`.
///
/// Gunakan `FnOnce` sebagai pengikat ketika Anda ingin menerima parameter dengan tipe fungsi seperti dan hanya perlu memanggilnya sekali.
/// Jika Anda perlu memanggil parameter berulang kali, gunakan [`FnMut`] sebagai pengikat;jika Anda juga membutuhkannya untuk tidak mengubah status, gunakan [`Fn`].
///
/// Lihat [chapter on closures in *The Rust Programming Language*][book] untuk informasi lebih lanjut tentang topik ini.
///
/// Yang juga perlu diperhatikan adalah sintaks khusus untuk `Fn` traits (mis
/// `Fn(usize, bool) -> usize`).Mereka yang tertarik dengan detail teknis ini dapat merujuk ke [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Menggunakan parameter `FnOnce`
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` mengkonsumsi variabel yang ditangkap, sehingga tidak dapat dijalankan lebih dari sekali.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Mencoba memanggil `func()` lagi akan memunculkan kesalahan `use of moved value` untuk `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` tidak dapat lagi dipanggil saat ini
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // sehingga regex dapat mengandalkan `&str: !FnMut` itu
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Jenis yang dikembalikan setelah operator panggilan digunakan.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Melakukan operasi panggilan.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}