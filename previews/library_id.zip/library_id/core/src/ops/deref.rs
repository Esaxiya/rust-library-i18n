/// Digunakan untuk operasi dereferensi yang tidak dapat diubah, seperti `*v`.
///
/// Selain digunakan untuk operasi dereferensi eksplisit dengan operator (unary) `*` dalam konteks yang tidak dapat diubah, `Deref` juga digunakan secara implisit oleh kompilator dalam banyak situasi.
/// Mekanisme ini disebut ['`Deref` coercion'][more].
/// Dalam konteks yang bisa berubah, [`DerefMut`] digunakan.
///
/// Menerapkan `Deref` untuk pointer pintar membuat akses data di belakangnya menjadi nyaman, itulah mengapa mereka menerapkan `Deref`.
/// Di sisi lain, aturan terkait `Deref` dan [`DerefMut`] dirancang khusus untuk mengakomodasi petunjuk cerdas.
/// Karenanya,**`Deref` sebaiknya hanya diterapkan untuk petunjuk cerdas** untuk menghindari kebingungan.
///
/// Untuk alasan serupa,**trait ini tidak boleh gagal**.Kegagalan selama dereferensi bisa sangat membingungkan ketika `Deref` dipanggil secara implisit.
///
/// # Lebih lanjut tentang pemaksaan `Deref`
///
/// Jika `T` mengimplementasikan `Deref<Target = U>`, dan `x` adalah nilai tipe `T`, maka:
///
/// * Dalam konteks yang tidak dapat diubah, `*x` (di mana `T` bukanlah referensi atau penunjuk mentah) setara dengan `* Deref::deref(&x)`.
/// * Nilai tipe `&T` dipaksakan ke nilai tipe `&U`
/// * `T` secara implisit mengimplementasikan semua metode (immutable) dari tipe `U`.
///
/// Untuk detail selengkapnya, kunjungi [the chapter in *The Rust Programming Language*][book] serta bagian referensi di [the dereference operator][ref-deref-op], [method resolution], dan [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Sebuah struct dengan satu bidang yang dapat diakses dengan mendereferensi struct.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Jenis yang dihasilkan setelah dereferensi.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Dereferensi nilainya.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Digunakan untuk operasi dereferensi yang bisa berubah, seperti di `*v = 1;`.
///
/// Selain digunakan untuk operasi dereferensi eksplisit dengan operator (unary) `*` dalam konteks yang bisa berubah, `DerefMut` juga digunakan secara implisit oleh kompilator dalam banyak situasi.
/// Mekanisme ini disebut ['`Deref` coercion'][more].
/// Dalam konteks yang tidak dapat diubah, [`Deref`] digunakan.
///
/// Mengimplementasikan `DerefMut` untuk smart pointer membuat mutasi data di belakangnya menjadi nyaman, itulah mengapa mereka mengimplementasikan `DerefMut`.
/// Di sisi lain, aturan terkait [`Deref`] dan `DerefMut` dirancang khusus untuk mengakomodasi petunjuk cerdas.
/// Karenanya,**`DerefMut` sebaiknya hanya diterapkan untuk petunjuk cerdas** untuk menghindari kebingungan.
///
/// Untuk alasan serupa,**trait ini tidak boleh gagal**.Kegagalan selama dereferensi bisa sangat membingungkan ketika `DerefMut` dipanggil secara implisit.
///
/// # Lebih lanjut tentang pemaksaan `Deref`
///
/// Jika `T` mengimplementasikan `DerefMut<Target = U>`, dan `x` adalah nilai tipe `T`, maka:
///
/// * Dalam konteks yang bisa berubah, `*x` (di mana `T` bukan referensi atau penunjuk mentah) setara dengan `* DerefMut::deref_mut(&mut x)`.
/// * Nilai tipe `&mut T` dipaksakan ke nilai tipe `&mut U`
/// * `T` secara implisit mengimplementasikan semua metode (mutable) dari tipe `U`.
///
/// Untuk detail selengkapnya, kunjungi [the chapter in *The Rust Programming Language*][book] serta bagian referensi di [the dereference operator][ref-deref-op], [method resolution], dan [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Sebuah struct dengan satu bidang yang dapat dimodifikasi dengan mendereferensi struct.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Saling membedakan nilainya.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Menunjukkan bahwa struct dapat digunakan sebagai penerima metode, tanpa fitur `arbitrary_self_types`.
///
/// Ini diimplementasikan oleh tipe pointer stdlib seperti `Box<T>`, `Rc<T>`, `&T`, dan `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}