/// trait untuk menyesuaikan perilaku operator `?`.
///
/// Jenis yang menerapkan `Try` adalah yang memiliki cara kanonik untuk melihatnya dalam hal dikotomi success/failure.
/// trait ini memungkinkan penggalian nilai keberhasilan atau kegagalan tersebut dari instans yang ada dan membuat instans baru dari nilai keberhasilan atau kegagalan.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Jenis nilai ini jika dianggap berhasil.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Jenis nilai ini jika dianggap gagal.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Menerapkan operator "?".Kembalinya `Ok(t)` berarti eksekusi harus dilanjutkan secara normal, dan hasil `?` adalah nilai `t`.
    /// Kembalinya `Err(e)` berarti eksekusi harus branch ke `catch` terlampir paling dalam, atau kembali dari fungsi.
    ///
    /// Jika hasil `Err(e)` dikembalikan, nilai `e` akan menjadi "wrapped" dalam jenis hasil dari cakupan yang melingkupi (yang harus mengimplementasikan `Try` itu sendiri).
    ///
    /// Secara khusus, nilai `X::from_error(From::from(e))` dikembalikan, di mana `X` adalah jenis hasil dari fungsi penutup.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Bungkus nilai kesalahan untuk menyusun hasil gabungan.
    /// Misalnya, `Result::Err(x)` dan `Result::from_error(x)` setara.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Bungkus nilai OK untuk menyusun hasil komposit.
    /// Misalnya, `Result::Ok(x)` dan `Result::from_ok(x)` setara.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}