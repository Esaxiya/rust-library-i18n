use crate::marker::Unpin;
use crate::pin::Pin;

/// Hasil dimulainya kembali generator.
///
/// Enum ini dikembalikan dari metode `Generator::resume` dan menunjukkan kemungkinan nilai kembalian generator.
/// Saat ini ini sesuai dengan titik suspensi (`Yielded`) atau titik terminasi (`Complete`).
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// Generator ditangguhkan dengan nilai.
    ///
    /// Status ini menunjukkan bahwa generator telah ditangguhkan, dan biasanya sesuai dengan pernyataan `yield`.
    /// Nilai yang diberikan dalam varian ini sesuai dengan ekspresi yang diteruskan ke `yield` dan memungkinkan generator memberikan nilai setiap kali mereka menghasilkan.
    ///
    ///
    Yielded(Y),

    /// Generator dilengkapi dengan nilai kembali.
    ///
    /// Status ini menunjukkan bahwa generator telah menyelesaikan eksekusi dengan nilai yang diberikan.
    /// Setelah generator mengembalikan `Complete`, maka dianggap kesalahan programmer untuk memanggil `resume` lagi.
    ///
    Complete(R),
}

/// trait diimplementasikan dengan tipe generator bawaan.
///
/// Generator, juga biasa disebut coroutine, saat ini merupakan fitur bahasa eksperimental di Rust.
/// Ditambahkan dalam generator [RFC 2033] saat ini dimaksudkan untuk menyediakan blok bangunan untuk sintaks async/await tetapi kemungkinan akan diperluas untuk juga memberikan definisi ergonomis untuk iterator dan primitif lainnya.
///
///
/// Sintaks dan semantik untuk generator tidak stabil dan akan membutuhkan RFC lebih lanjut untuk stabilisasi.Pada saat ini, sintaksnya seperti closure:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Dokumentasi generator lainnya dapat ditemukan di buku tidak stabil.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// Jenis nilai yang dihasilkan generator ini.
    ///
    /// Jenis terkait ini sesuai dengan ekspresi `yield` dan nilai yang diizinkan dikembalikan setiap kali generator menghasilkan.
    ///
    /// Misalnya, iterator-as-a-generator kemungkinan akan memiliki tipe ini sebagai `T`, tipe yang diiterasi.
    ///
    type Yield;

    /// Jenis nilai yang dihasilkan generator ini.
    ///
    /// Ini sesuai dengan tipe yang dikembalikan dari generator baik dengan pernyataan `return` atau secara implisit sebagai ekspresi terakhir literal generator.
    /// Misalnya futures akan menggunakan ini sebagai `Result<T, E>` karena ini mewakili future yang lengkap.
    ///
    ///
    type Return;

    /// Melanjutkan eksekusi generator ini.
    ///
    /// Fungsi ini akan melanjutkan eksekusi generator atau memulai eksekusi jika belum dijalankan.
    /// Panggilan ini akan kembali ke titik suspensi terakhir generator, melanjutkan eksekusi dari `yield` terbaru.
    /// Generator akan terus menjalankan hingga menghasilkan atau kembali, di mana fungsi ini akan kembali.
    ///
    /// # Nilai kembali
    ///
    /// Enum `GeneratorState` yang dikembalikan dari fungsi ini menunjukkan status generator saat kembali.
    /// Jika varian `Yielded` dikembalikan maka generator telah mencapai titik suspensi dan nilai telah dihasilkan.
    /// Generator dalam keadaan ini tersedia untuk dilanjutkan di lain waktu.
    ///
    /// Jika `Complete` dikembalikan maka generator telah selesai dengan nilai yang diberikan.Generator tidak valid untuk dilanjutkan kembali.
    ///
    /// # Panics
    ///
    /// Fungsi ini mungkin panic jika dipanggil setelah varian `Complete` dikembalikan sebelumnya.
    /// Sementara literal generator dalam bahasa dijamin ke panic saat dilanjutkan setelah `Complete`, ini tidak dijamin untuk semua implementasi `Generator` trait.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}