/// Kode khusus di dalam destruktor.
///
/// Ketika sebuah nilai tidak lagi dibutuhkan, Rust akan menjalankan "destructor" pada nilai tersebut.
/// Cara paling umum di mana suatu nilai tidak lagi diperlukan adalah saat nilai tersebut berada di luar cakupan.Destructors mungkin masih berjalan dalam keadaan lain, tetapi kami akan fokus pada cakupan contoh di sini.
/// Untuk mempelajari tentang beberapa dari kasus lain itu, silakan lihat bagian [the reference] tentang penghancur.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Penghancur ini terdiri dari dua komponen:
/// - Panggilan ke `Drop::drop` untuk nilai itu, jika `Drop` trait khusus ini diimplementasikan untuk tipenya.
/// - "drop glue" yang dibuat secara otomatis yang secara rekursif memanggil destruktor dari semua bidang nilai ini.
///
/// Karena Rust secara otomatis memanggil destruktor dari semua bidang yang ada, Anda tidak perlu mengimplementasikan `Drop` dalam banyak kasus.
/// Namun ada beberapa kasus yang berguna, misalnya untuk tipe yang mengelola sumber daya secara langsung.
/// Sumber daya itu mungkin memori, mungkin deskriptor file, mungkin soket jaringan.
/// Setelah nilai jenis itu tidak lagi digunakan, ia harus "clean up" sumber dayanya dengan membebaskan memori atau menutup file atau soket.
/// Ini adalah pekerjaan destruktor, dan oleh karena itu tugas `Drop::drop`.
///
/// ## Examples
///
/// Untuk melihat perusak beraksi, mari kita lihat program berikut:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust pertama-tama akan memanggil `Drop::drop` untuk `_x` lalu untuk `_x.one` dan `_x.two`, yang berarti menjalankan ini akan mencetak
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// Bahkan jika kita menghapus implementasi `Drop` untuk `HasTwoDrop`, penghancur bidangnya masih dipanggil.
/// Ini akan menghasilkan
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## Anda tidak dapat memanggil `Drop::drop` sendiri
///
/// Karena `Drop::drop` digunakan untuk membersihkan nilai, mungkin berbahaya menggunakan nilai ini setelah metode dipanggil.
/// Karena `Drop::drop` tidak mengambil kepemilikan atas inputnya, Rust mencegah penyalahgunaan dengan tidak mengizinkan Anda memanggil `Drop::drop` secara langsung.
///
/// Dengan kata lain, jika Anda mencoba memanggil `Drop::drop` secara eksplisit dalam contoh di atas, Anda akan mendapatkan error compiler.
///
/// Jika Anda ingin secara eksplisit memanggil destruktor suatu nilai, [`mem::drop`] dapat digunakan sebagai gantinya.
///
/// [`mem::drop`]: drop
///
/// ## Jatuhkan pesanan
///
/// Namun, manakah dari dua `HasDrop` kami yang turun lebih dulu?Untuk struct, urutannya sama dengan yang dideklarasikan: `one` pertama, lalu `two`.
/// Jika Anda ingin mencobanya sendiri, Anda dapat memodifikasi `HasDrop` di atas untuk memuat beberapa data, seperti integer, dan kemudian menggunakannya di `println!` di dalam `Drop`.
/// Perilaku ini dijamin oleh bahasa.
///
/// Tidak seperti struct, variabel lokal dijatuhkan dalam urutan terbalik:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// Ini akan mencetak
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Silakan lihat [the reference] untuk aturan lengkapnya.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` dan `Drop` bersifat eksklusif
///
/// Anda tidak dapat mengimplementasikan [`Copy`] dan `Drop` pada tipe yang sama.Tipe `Copy` diduplikasi secara implisit oleh kompiler, sehingga sangat sulit untuk memprediksi kapan, dan seberapa sering destruktor akan dieksekusi.
///
/// Dengan demikian, tipe ini tidak dapat memiliki destruktor.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Jalankan destruktor untuk tipe ini.
    ///
    /// Metode ini dipanggil secara implisit ketika nilai keluar dari ruang lingkup, dan tidak dapat dipanggil secara eksplisit (ini adalah kesalahan kompiler [E0040]).
    /// Namun, fungsi [`mem::drop`] dalam prelude dapat digunakan untuk memanggil implementasi `Drop` argumen.
    ///
    /// Saat metode ini dipanggil, `self` belum dialokasikan.
    /// Itu hanya terjadi setelah metode selesai.
    /// Jika bukan ini masalahnya, `self` akan menjadi referensi yang menggantung.
    ///
    /// # Panics
    ///
    /// Mengingat bahwa [`panic!`] akan memanggil `drop` saat ia dilepas, [`panic!`] apa pun dalam implementasi `drop` kemungkinan akan dibatalkan.
    ///
    /// Perhatikan bahwa meskipun panics ini, nilainya dianggap turun;
    /// Anda tidak boleh menyebabkan `drop` dipanggil lagi.
    /// Ini biasanya secara otomatis ditangani oleh kompilator, tetapi saat menggunakan kode yang tidak aman, terkadang dapat terjadi secara tidak sengaja, terutama saat menggunakan [`ptr::drop_in_place`].
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}