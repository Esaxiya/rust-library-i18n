use crate::marker::Unsize;

/// Trait yang menunjukkan bahwa ini adalah penunjuk atau pembungkus untuk penunjuk, di mana pembongkaran dapat dilakukan pada orang yang ditunjuk.
///
/// Lihat [DST coercion RFC][dst-coerce] dan [the nomicon entry on coercion][nomicon-coerce] untuk lebih jelasnya.
///
/// Untuk tipe penunjuk bawaan, penunjuk ke `T` akan memaksa penunjuk ke `U` jika `T: Unsize<U>` dengan mengubah dari penunjuk tipis ke penunjuk gemuk.
///
/// Untuk tipe kustom, paksaan di sini bekerja dengan memaksa `Foo<T>` ke `Foo<U>` asalkan ada implikasi `CoerceUnsized<Foo<U>> for Foo<T>`.
/// Implikasi seperti itu hanya dapat ditulis jika `Foo<T>` hanya memiliki satu bidang data non-phantom yang melibatkan `T`.
/// Jika jenis bidang itu adalah `Bar<T>`, penerapan `CoerceUnsized<Bar<U>> for Bar<T>` harus ada.
/// Pemaksaan akan bekerja dengan memaksa bidang `Bar<T>` menjadi `Bar<U>` dan mengisi bidang lainnya dari `Foo<T>` untuk membuat `Foo<U>`.
/// Ini akan secara efektif menelusuri ke bidang penunjuk dan memaksa itu.
///
/// Umumnya, untuk pointer pintar Anda akan mengimplementasikan `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`, dengan `?Sized` opsional yang terikat pada `T` itu sendiri.
/// Untuk jenis pembungkus yang langsung menyematkan `T` seperti `Cell<T>` dan `RefCell<T>`, Anda dapat langsung menerapkan `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>`.
///
/// Ini akan membiarkan pemaksaan tipe seperti `Cell<Box<T>>` bekerja.
///
/// [`Unsize`][unsize] digunakan untuk menandai jenis yang dapat dipaksa ke DST jika berada di belakang petunjuk.Ini diimplementasikan secara otomatis oleh kompiler.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Ini digunakan untuk keamanan objek, untuk memeriksa bahwa tipe penerima metode dapat dikirim.
///
/// Contoh implementasi trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}