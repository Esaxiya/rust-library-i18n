//! Panic mendukung libcore
//!
//! Pustaka inti tidak dapat mendefinisikan panik, tetapi ia *mendeklarasikan* panik.
//! Ini berarti bahwa fungsi di dalam libcore diizinkan untuk panic, tetapi agar berguna, crate upstream harus mendefinisikan panik agar libcore digunakan.
//! Antarmuka untuk panik saat ini adalah:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Definisi ini memungkinkan untuk panik dengan pesan umum apa pun, tetapi tidak memungkinkan untuk gagal dengan nilai `Box<Any>`.
//! (`PanicInfo` hanya berisi `&(dyn Any + Send)`, yang kita isi dengan nilai dummy di `PanicInfo: : internal_constructor`.) Alasannya adalah bahwa libcore tidak diizinkan untuk mengalokasikan.
//!
//!
//! Modul ini berisi beberapa fungsi panik lainnya, tetapi ini hanya item bahasa yang diperlukan untuk kompilator.Semua panics disalurkan melalui fungsi yang satu ini.
//! Simbol sebenarnya dideklarasikan melalui atribut `#[panic_handler]`.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Implementasi yang mendasari makro `panic!` libcore saat tidak ada pemformatan yang digunakan.
#[cold]
// jangan pernah sebaris kecuali panic_immediate_abort untuk menghindari pembengkakan kode di situs panggilan sebanyak mungkin
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // dibutuhkan oleh codegen untuk panic pada overflow dan terminator `Assert` MIR lainnya
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Gunakan Arguments::new_v1 sebagai ganti format_args! ("{}", Expr) untuk mengurangi overhead ukuran.
    // Format_args!macro menggunakan Str Display trait untuk menulis expr, yang memanggil Formatter::pad, yang harus mengakomodasi pemotongan dan padding string (meskipun tidak ada yang digunakan di sini).
    //
    // Menggunakan Arguments::new_v1 memungkinkan kompilator untuk menghilangkan Formatter::pad dari biner keluaran, menghemat hingga beberapa kilobyte.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // diperlukan untuk panics yang dievaluasi oleh konstanta
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // dibutuhkan oleh codegen untuk panic pada akses OOB array/slice
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Implementasi yang mendasari makro `panic!` libcore saat pemformatan digunakan.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // CATATAN Fungsi ini tidak pernah melewati batas FFI;itu adalah panggilan Rust-to-Rust yang diselesaikan ke fungsi `#[panic_handler]`.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // KEAMANAN: `panic_impl` didefinisikan dalam kode Rust yang aman dan karenanya aman untuk dipanggil.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Fungsi internal untuk makro `assert_eq!` dan `assert_ne!`
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}