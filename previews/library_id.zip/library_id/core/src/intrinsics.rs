//! Kompilator intrinsik.
//!
//! Definisi terkait ada di `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! Implementasi const yang sesuai ada di `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # Const intrinsics
//!
//! Note: setiap perubahan pada keteguhan intrinsik harus didiskusikan dengan tim bahasa.
//! Ini termasuk perubahan stabilitas konstanta.
//!
//! Untuk membuat intrinsik dapat digunakan pada waktu kompilasi, kita perlu menyalin implementasi dari <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> ke `compiler/rustc_mir/src/interpret/intrinsics.rs` dan menambahkan `#[rustc_const_unstable(feature = "foo", issue = "01234")]` ke intrinsik.
//!
//!
//! Jika intrinsik seharusnya digunakan dari `const fn` dengan atribut `rustc_const_stable`, atribut intrinsik juga harus `rustc_const_stable`.
//! Perubahan seperti itu tidak boleh dilakukan tanpa konsultasi T-lang, karena ini memasukkan fitur ke dalam bahasa yang tidak dapat direplikasi dalam kode pengguna tanpa dukungan compiler.
//!
//! # Volatiles
//!
//! Intrinsik volatil menyediakan operasi yang dimaksudkan untuk bertindak pada memori I/O, yang dijamin tidak akan diatur ulang oleh compiler di seluruh intrinsik volatil lainnya.Lihat dokumentasi LLVM di [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Intrinsik atom menyediakan operasi atom umum pada kata-kata mesin, dengan beberapa urutan memori yang memungkinkan.Mereka mematuhi semantik yang sama dengan C++ 11.Lihat dokumentasi LLVM di [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! Penyegaran cepat tentang pengurutan memori:
//!
//! * Dapatkan, penghalang untuk memperoleh kunci.Pembacaan dan penulisan selanjutnya dilakukan setelah pembatas.
//! * Lepaskan, penghalang untuk membuka kunci.Pembacaan dan penulisan sebelumnya dilakukan sebelum pembatas.
//! * Operasi yang konsisten secara berurutan dan berurutan dijamin akan terjadi secara berurutan.Ini adalah mode standar untuk bekerja dengan jenis atom dan setara dengan `volatile` Java.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Impor ini digunakan untuk menyederhanakan tautan dalam dokumen
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // KEAMANAN: lihat `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, intrinsik ini mengambil petunjuk mentah karena mereka memutasi memori alias, yang tidak valid untuk `&` atau `&mut`.
    //

    /// Menyimpan nilai jika nilai saat ini sama dengan nilai `old`.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `compare_exchange` dengan meneruskan [`Ordering::SeqCst`] sebagai parameter `success` dan `failure`.
    ///
    /// Sebagai contoh, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Menyimpan nilai jika nilai saat ini sama dengan nilai `old`.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `compare_exchange` dengan meneruskan [`Ordering::Acquire`] sebagai parameter `success` dan `failure`.
    ///
    /// Sebagai contoh, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Menyimpan nilai jika nilai saat ini sama dengan nilai `old`.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `compare_exchange` dengan meneruskan [`Ordering::Release`] sebagai `success` dan [`Ordering::Relaxed`] sebagai parameter `failure`.
    /// Sebagai contoh, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Menyimpan nilai jika nilai saat ini sama dengan nilai `old`.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `compare_exchange` dengan melewatkan [`Ordering::AcqRel`] sebagai `success` dan [`Ordering::Acquire`] sebagai parameter `failure`.
    /// Sebagai contoh, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Menyimpan nilai jika nilai saat ini sama dengan nilai `old`.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `compare_exchange` dengan meneruskan [`Ordering::Relaxed`] sebagai parameter `success` dan `failure`.
    ///
    /// Sebagai contoh, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Menyimpan nilai jika nilai saat ini sama dengan nilai `old`.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `compare_exchange` dengan melewatkan [`Ordering::SeqCst`] sebagai `success` dan [`Ordering::Relaxed`] sebagai parameter `failure`.
    /// Sebagai contoh, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Menyimpan nilai jika nilai saat ini sama dengan nilai `old`.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `compare_exchange` dengan melewatkan [`Ordering::SeqCst`] sebagai `success` dan [`Ordering::Acquire`] sebagai parameter `failure`.
    /// Sebagai contoh, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Menyimpan nilai jika nilai saat ini sama dengan nilai `old`.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `compare_exchange` dengan melewatkan [`Ordering::Acquire`] sebagai `success` dan [`Ordering::Relaxed`] sebagai parameter `failure`.
    /// Sebagai contoh, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Menyimpan nilai jika nilai saat ini sama dengan nilai `old`.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `compare_exchange` dengan melewatkan [`Ordering::AcqRel`] sebagai `success` dan [`Ordering::Relaxed`] sebagai parameter `failure`.
    /// Sebagai contoh, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Menyimpan nilai jika nilai saat ini sama dengan nilai `old`.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `compare_exchange_weak` dengan meneruskan [`Ordering::SeqCst`] sebagai parameter `success` dan `failure`.
    ///
    /// Sebagai contoh, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Menyimpan nilai jika nilai saat ini sama dengan nilai `old`.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `compare_exchange_weak` dengan meneruskan [`Ordering::Acquire`] sebagai parameter `success` dan `failure`.
    ///
    /// Sebagai contoh, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Menyimpan nilai jika nilai saat ini sama dengan nilai `old`.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `compare_exchange_weak` dengan melewatkan [`Ordering::Release`] sebagai `success` dan [`Ordering::Relaxed`] sebagai parameter `failure`.
    /// Sebagai contoh, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Menyimpan nilai jika nilai saat ini sama dengan nilai `old`.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `compare_exchange_weak` dengan melewatkan [`Ordering::AcqRel`] sebagai `success` dan [`Ordering::Acquire`] sebagai parameter `failure`.
    /// Sebagai contoh, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Menyimpan nilai jika nilai saat ini sama dengan nilai `old`.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `compare_exchange_weak` dengan meneruskan [`Ordering::Relaxed`] sebagai parameter `success` dan `failure`.
    ///
    /// Sebagai contoh, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Menyimpan nilai jika nilai saat ini sama dengan nilai `old`.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `compare_exchange_weak` dengan melewatkan [`Ordering::SeqCst`] sebagai `success` dan [`Ordering::Relaxed`] sebagai parameter `failure`.
    /// Sebagai contoh, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Menyimpan nilai jika nilai saat ini sama dengan nilai `old`.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `compare_exchange_weak` dengan melewatkan [`Ordering::SeqCst`] sebagai `success` dan [`Ordering::Acquire`] sebagai parameter `failure`.
    /// Sebagai contoh, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Menyimpan nilai jika nilai saat ini sama dengan nilai `old`.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `compare_exchange_weak` dengan melewatkan [`Ordering::Acquire`] sebagai `success` dan [`Ordering::Relaxed`] sebagai parameter `failure`.
    /// Sebagai contoh, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Menyimpan nilai jika nilai saat ini sama dengan nilai `old`.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `compare_exchange_weak` dengan melewatkan [`Ordering::AcqRel`] sebagai `success` dan [`Ordering::Relaxed`] sebagai parameter `failure`.
    /// Sebagai contoh, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Memuat nilai penunjuk saat ini.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `load` dengan melewatkan [`Ordering::SeqCst`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Memuat nilai penunjuk saat ini.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `load` dengan melewatkan [`Ordering::Acquire`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Memuat nilai penunjuk saat ini.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `load` dengan melewatkan [`Ordering::Relaxed`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Menyimpan nilai di lokasi memori yang ditentukan.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `store` dengan melewatkan [`Ordering::SeqCst`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Menyimpan nilai di lokasi memori yang ditentukan.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `store` dengan melewatkan [`Ordering::Release`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Menyimpan nilai di lokasi memori yang ditentukan.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `store` dengan melewatkan [`Ordering::Relaxed`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Menyimpan nilai di lokasi memori yang ditentukan, mengembalikan nilai lama.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `swap` dengan melewatkan [`Ordering::SeqCst`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Menyimpan nilai di lokasi memori yang ditentukan, mengembalikan nilai lama.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `swap` dengan melewatkan [`Ordering::Acquire`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Menyimpan nilai di lokasi memori yang ditentukan, mengembalikan nilai lama.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `swap` dengan melewatkan [`Ordering::Release`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Menyimpan nilai di lokasi memori yang ditentukan, mengembalikan nilai lama.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `swap` dengan melewatkan [`Ordering::AcqRel`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Menyimpan nilai di lokasi memori yang ditentukan, mengembalikan nilai lama.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `swap` dengan melewatkan [`Ordering::Relaxed`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Menambahkan ke nilai saat ini, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `fetch_add` dengan melewatkan [`Ordering::SeqCst`] sebagai `order`.
    /// Sebagai contoh, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Menambahkan ke nilai saat ini, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `fetch_add` dengan melewatkan [`Ordering::Acquire`] sebagai `order`.
    /// Sebagai contoh, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Menambahkan ke nilai saat ini, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `fetch_add` dengan melewatkan [`Ordering::Release`] sebagai `order`.
    /// Sebagai contoh, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Menambahkan ke nilai saat ini, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `fetch_add` dengan melewatkan [`Ordering::AcqRel`] sebagai `order`.
    /// Sebagai contoh, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Menambahkan ke nilai saat ini, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `fetch_add` dengan melewatkan [`Ordering::Relaxed`] sebagai `order`.
    /// Sebagai contoh, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Kurangi dari nilai saat ini, dengan mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `fetch_sub` dengan melewatkan [`Ordering::SeqCst`] sebagai `order`.
    /// Sebagai contoh, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kurangi dari nilai saat ini, dengan mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `fetch_sub` dengan melewatkan [`Ordering::Acquire`] sebagai `order`.
    /// Sebagai contoh, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kurangi dari nilai saat ini, dengan mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `fetch_sub` dengan melewatkan [`Ordering::Release`] sebagai `order`.
    /// Sebagai contoh, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kurangi dari nilai saat ini, dengan mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `fetch_sub` dengan melewatkan [`Ordering::AcqRel`] sebagai `order`.
    /// Sebagai contoh, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kurangi dari nilai saat ini, dengan mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `fetch_sub` dengan melewatkan [`Ordering::Relaxed`] sebagai `order`.
    /// Sebagai contoh, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise dan dengan nilai saat ini, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `fetch_and` dengan melewatkan [`Ordering::SeqCst`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise dan dengan nilai saat ini, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `fetch_and` dengan meneruskan [`Ordering::Acquire`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise dan dengan nilai saat ini, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `fetch_and` dengan melewatkan [`Ordering::Release`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise dan dengan nilai saat ini, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `fetch_and` dengan melewatkan [`Ordering::AcqRel`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise dan dengan nilai saat ini, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `fetch_and` dengan meneruskan [`Ordering::Relaxed`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise nand dengan nilai saat ini, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`AtomicBool`] melalui metode `fetch_nand` dengan melewatkan [`Ordering::SeqCst`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand dengan nilai saat ini, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`AtomicBool`] melalui metode `fetch_nand` dengan melewatkan [`Ordering::Acquire`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand dengan nilai saat ini, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`AtomicBool`] melalui metode `fetch_nand` dengan melewatkan [`Ordering::Release`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand dengan nilai saat ini, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`AtomicBool`] melalui metode `fetch_nand` dengan melewatkan [`Ordering::AcqRel`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand dengan nilai saat ini, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`AtomicBool`] melalui metode `fetch_nand` dengan melewatkan [`Ordering::Relaxed`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise atau dengan nilai saat ini, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `fetch_or` dengan melewatkan [`Ordering::SeqCst`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise atau dengan nilai saat ini, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `fetch_or` dengan melewatkan [`Ordering::Acquire`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise atau dengan nilai saat ini, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `fetch_or` dengan melewatkan [`Ordering::Release`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise atau dengan nilai saat ini, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `fetch_or` dengan melewatkan [`Ordering::AcqRel`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise atau dengan nilai saat ini, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `fetch_or` dengan melewatkan [`Ordering::Relaxed`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise xor dengan nilai saat ini, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `fetch_xor` dengan melewatkan [`Ordering::SeqCst`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor dengan nilai saat ini, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `fetch_xor` dengan melewatkan [`Ordering::Acquire`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor dengan nilai saat ini, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `fetch_xor` dengan melewatkan [`Ordering::Release`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor dengan nilai saat ini, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `fetch_xor` dengan melewatkan [`Ordering::AcqRel`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor dengan nilai saat ini, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe [`atomic`] melalui metode `fetch_xor` dengan melewatkan [`Ordering::Relaxed`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maksimum dengan nilai saat ini menggunakan perbandingan bertanda tangan.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe bilangan bulat bertanda [`atomic`] melalui metode `fetch_max` dengan meneruskan [`Ordering::SeqCst`] sebagai `order`.
    /// Sebagai contoh, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum dengan nilai saat ini menggunakan perbandingan bertanda tangan.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe bilangan bulat bertanda [`atomic`] melalui metode `fetch_max` dengan meneruskan [`Ordering::Acquire`] sebagai `order`.
    /// Sebagai contoh, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum dengan nilai saat ini menggunakan perbandingan bertanda tangan.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe bilangan bulat bertanda [`atomic`] melalui metode `fetch_max` dengan meneruskan [`Ordering::Release`] sebagai `order`.
    /// Sebagai contoh, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum dengan nilai saat ini menggunakan perbandingan bertanda tangan.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe bilangan bulat bertanda [`atomic`] melalui metode `fetch_max` dengan meneruskan [`Ordering::AcqRel`] sebagai `order`.
    /// Sebagai contoh, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimal dengan nilai saat ini.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe bilangan bulat bertanda [`atomic`] melalui metode `fetch_max` dengan meneruskan [`Ordering::Relaxed`] sebagai `order`.
    /// Sebagai contoh, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimum dengan nilai saat ini menggunakan perbandingan bertanda tangan.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe bilangan bulat bertanda [`atomic`] melalui metode `fetch_min` dengan meneruskan [`Ordering::SeqCst`] sebagai `order`.
    /// Sebagai contoh, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum dengan nilai saat ini menggunakan perbandingan bertanda tangan.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe bilangan bulat bertanda [`atomic`] melalui metode `fetch_min` dengan meneruskan [`Ordering::Acquire`] sebagai `order`.
    /// Sebagai contoh, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum dengan nilai saat ini menggunakan perbandingan bertanda tangan.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe bilangan bulat bertanda [`atomic`] melalui metode `fetch_min` dengan meneruskan [`Ordering::Release`] sebagai `order`.
    /// Sebagai contoh, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum dengan nilai saat ini menggunakan perbandingan bertanda tangan.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe bilangan bulat bertanda [`atomic`] melalui metode `fetch_min` dengan meneruskan [`Ordering::AcqRel`] sebagai `order`.
    /// Sebagai contoh, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum dengan nilai saat ini menggunakan perbandingan bertanda tangan.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe bilangan bulat bertanda [`atomic`] melalui metode `fetch_min` dengan meneruskan [`Ordering::Relaxed`] sebagai `order`.
    /// Sebagai contoh, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimum dengan nilai saat ini menggunakan perbandingan tak bertanda tangan.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe bilangan bulat tak bertanda tangan [`atomic`] melalui metode `fetch_min` dengan meneruskan [`Ordering::SeqCst`] sebagai `order`.
    /// Sebagai contoh, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum dengan nilai saat ini menggunakan perbandingan tak bertanda tangan.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe bilangan bulat tak bertanda tangan [`atomic`] melalui metode `fetch_min` dengan meneruskan [`Ordering::Acquire`] sebagai `order`.
    /// Sebagai contoh, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum dengan nilai saat ini menggunakan perbandingan tak bertanda tangan.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe bilangan bulat tak bertanda tangan [`atomic`] melalui metode `fetch_min` dengan meneruskan [`Ordering::Release`] sebagai `order`.
    /// Sebagai contoh, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum dengan nilai saat ini menggunakan perbandingan tak bertanda tangan.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe bilangan bulat tak bertanda tangan [`atomic`] melalui metode `fetch_min` dengan meneruskan [`Ordering::AcqRel`] sebagai `order`.
    /// Sebagai contoh, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum dengan nilai saat ini menggunakan perbandingan tak bertanda tangan.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe bilangan bulat tak bertanda tangan [`atomic`] melalui metode `fetch_min` dengan meneruskan [`Ordering::Relaxed`] sebagai `order`.
    /// Sebagai contoh, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maksimum dengan nilai saat ini menggunakan perbandingan tak bertanda tangan.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe bilangan bulat tak bertanda tangan [`atomic`] melalui metode `fetch_max` dengan meneruskan [`Ordering::SeqCst`] sebagai `order`.
    /// Sebagai contoh, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum dengan nilai saat ini menggunakan perbandingan tak bertanda tangan.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe bilangan bulat tak bertanda tangan [`atomic`] melalui metode `fetch_max` dengan meneruskan [`Ordering::Acquire`] sebagai `order`.
    /// Sebagai contoh, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum dengan nilai saat ini menggunakan perbandingan tak bertanda tangan.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe bilangan bulat tak bertanda tangan [`atomic`] melalui metode `fetch_max` dengan meneruskan [`Ordering::Release`] sebagai `order`.
    /// Sebagai contoh, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum dengan nilai saat ini menggunakan perbandingan tak bertanda tangan.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe bilangan bulat tak bertanda tangan [`atomic`] melalui metode `fetch_max` dengan meneruskan [`Ordering::AcqRel`] sebagai `order`.
    /// Sebagai contoh, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum dengan nilai saat ini menggunakan perbandingan tak bertanda tangan.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada tipe bilangan bulat tak bertanda tangan [`atomic`] melalui metode `fetch_max` dengan meneruskan [`Ordering::Relaxed`] sebagai `order`.
    /// Sebagai contoh, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Intrinsik `prefetch` adalah petunjuk bagi pembuat kode untuk memasukkan instruksi prefetch jika didukung;jika tidak, ini adalah no-op.
    /// Prapengambilan tidak berpengaruh pada perilaku program tetapi dapat mengubah karakteristik kinerjanya.
    ///
    /// Argumen `locality` harus berupa bilangan bulat konstan dan penentu lokalitas temporal mulai dari (0), tanpa lokalitas, hingga (3), penyimpanan dalam cache yang sangat lokal.
    ///
    ///
    /// Intrinsik ini tidak memiliki pasangan yang stabil.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// Intrinsik `prefetch` adalah petunjuk bagi pembuat kode untuk memasukkan instruksi prefetch jika didukung;jika tidak, ini adalah no-op.
    /// Prapengambilan tidak berpengaruh pada perilaku program tetapi dapat mengubah karakteristik kinerjanya.
    ///
    /// Argumen `locality` harus berupa bilangan bulat konstan dan penentu lokalitas temporal mulai dari (0), tanpa lokalitas, hingga (3), penyimpanan dalam cache yang sangat lokal.
    ///
    ///
    /// Intrinsik ini tidak memiliki pasangan yang stabil.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// Intrinsik `prefetch` adalah petunjuk bagi pembuat kode untuk memasukkan instruksi prefetch jika didukung;jika tidak, ini adalah no-op.
    /// Prapengambilan tidak berpengaruh pada perilaku program tetapi dapat mengubah karakteristik kinerjanya.
    ///
    /// Argumen `locality` harus berupa bilangan bulat konstan dan penentu lokalitas temporal mulai dari (0), tanpa lokalitas, hingga (3), penyimpanan dalam cache yang sangat lokal.
    ///
    ///
    /// Intrinsik ini tidak memiliki pasangan yang stabil.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// Intrinsik `prefetch` adalah petunjuk bagi pembuat kode untuk memasukkan instruksi prefetch jika didukung;jika tidak, ini adalah no-op.
    /// Prapengambilan tidak berpengaruh pada perilaku program tetapi dapat mengubah karakteristik kinerjanya.
    ///
    /// Argumen `locality` harus berupa bilangan bulat konstan dan penentu lokalitas temporal mulai dari (0), tanpa lokalitas, hingga (3), penyimpanan dalam cache yang sangat lokal.
    ///
    ///
    /// Intrinsik ini tidak memiliki pasangan yang stabil.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Pagar atom.
    ///
    /// Versi stabil dari intrinsik ini tersedia di [`atomic::fence`] dengan meneruskan [`Ordering::SeqCst`] sebagai `order`.
    ///
    ///
    pub fn atomic_fence();
    /// Pagar atom.
    ///
    /// Versi stabil dari intrinsik ini tersedia di [`atomic::fence`] dengan meneruskan [`Ordering::Acquire`] sebagai `order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Pagar atom.
    ///
    /// Versi stabil dari intrinsik ini tersedia di [`atomic::fence`] dengan meneruskan [`Ordering::Release`] sebagai `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Pagar atom.
    ///
    /// Versi stabil dari intrinsik ini tersedia di [`atomic::fence`] dengan meneruskan [`Ordering::AcqRel`] sebagai `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Penghalang memori khusus kompiler.
    ///
    /// Akses memori tidak akan pernah diatur ulang melewati penghalang ini oleh kompilator, tetapi tidak ada instruksi yang akan dikeluarkan untuk itu.
    /// Ini sesuai untuk operasi pada thread yang sama yang mungkin didahului, seperti saat berinteraksi dengan penangan sinyal.
    ///
    /// Versi stabil dari intrinsik ini tersedia di [`atomic::compiler_fence`] dengan meneruskan [`Ordering::SeqCst`] sebagai `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Penghalang memori khusus kompiler.
    ///
    /// Akses memori tidak akan pernah diatur ulang melewati penghalang ini oleh kompilator, tetapi tidak ada instruksi yang akan dikeluarkan untuk itu.
    /// Ini sesuai untuk operasi pada thread yang sama yang mungkin didahului, seperti saat berinteraksi dengan penangan sinyal.
    ///
    /// Versi stabil dari intrinsik ini tersedia di [`atomic::compiler_fence`] dengan meneruskan [`Ordering::Acquire`] sebagai `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Penghalang memori khusus kompiler.
    ///
    /// Akses memori tidak akan pernah diatur ulang melewati penghalang ini oleh kompilator, tetapi tidak ada instruksi yang akan dikeluarkan untuk itu.
    /// Ini sesuai untuk operasi pada thread yang sama yang mungkin didahului, seperti saat berinteraksi dengan penangan sinyal.
    ///
    /// Versi stabil dari intrinsik ini tersedia di [`atomic::compiler_fence`] dengan meneruskan [`Ordering::Release`] sebagai `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Penghalang memori khusus kompiler.
    ///
    /// Akses memori tidak akan pernah diatur ulang melewati penghalang ini oleh kompilator, tetapi tidak ada instruksi yang akan dikeluarkan untuk itu.
    /// Ini sesuai untuk operasi pada thread yang sama yang mungkin didahului, seperti saat berinteraksi dengan penangan sinyal.
    ///
    /// Versi stabil dari intrinsik ini tersedia di [`atomic::compiler_fence`] dengan meneruskan [`Ordering::AcqRel`] sebagai `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Ajaib intrinsik yang memperoleh maknanya dari atribut yang melekat pada fungsi.
    ///
    /// Misalnya, dataflow menggunakan ini untuk memasukkan pernyataan statis sehingga `rustc_peek(potentially_uninitialized)` benar-benar akan memeriksa ulang bahwa aliran data memang menghitung bahwa itu tidak diinisialisasi pada titik itu di aliran kontrol.
    ///
    ///
    /// Intrinsik ini tidak boleh digunakan di luar kompilator.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Membatalkan pelaksanaan proses.
    ///
    /// Versi yang lebih ramah pengguna dan stabil dari operasi ini adalah [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Memberi tahu pengoptimal bahwa titik dalam kode ini tidak dapat dijangkau, memungkinkan pengoptimalan lebih lanjut.
    ///
    /// NB, ini sangat berbeda dari makro `unreachable!()`: Tidak seperti makro, yang panics ketika dijalankan, itu adalah *perilaku tidak ditentukan* untuk mencapai kode yang ditandai dengan fungsi ini.
    ///
    ///
    /// Versi stabil dari intrinsik ini adalah [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Memberi tahu pengoptimal bahwa suatu kondisi selalu benar.
    /// Jika kondisinya salah, perilaku tidak ditentukan.
    ///
    /// Tidak ada kode yang dibuat untuk intrinsik ini, tetapi pengoptimal akan mencoba mempertahankannya (dan kondisinya) di antara lintasan, yang dapat mengganggu pengoptimalan kode di sekitarnya dan mengurangi kinerja.
    /// Ini tidak boleh digunakan jika invarian dapat ditemukan sendiri oleh pengoptimal, atau jika tidak memungkinkan pengoptimalan yang signifikan.
    ///
    /// Intrinsik ini tidak memiliki pasangan yang stabil.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Petunjuk kepada compiler bahwa kondisi branch kemungkinan benar.
    /// Mengembalikan nilai yang diteruskan padanya.
    ///
    /// Penggunaan apa pun selain dengan pernyataan `if` mungkin tidak akan berpengaruh.
    ///
    /// Intrinsik ini tidak memiliki pasangan yang stabil.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Petunjuk kepada kompilator bahwa kondisi branch kemungkinan besar salah.
    /// Mengembalikan nilai yang diteruskan padanya.
    ///
    /// Penggunaan apa pun selain dengan pernyataan `if` mungkin tidak akan berpengaruh.
    ///
    /// Intrinsik ini tidak memiliki pasangan yang stabil.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Menjalankan jebakan breakpoint, untuk diperiksa oleh debugger.
    ///
    /// Intrinsik ini tidak memiliki pasangan yang stabil.
    pub fn breakpoint();

    /// Ukuran suatu tipe dalam byte.
    ///
    /// Lebih khusus lagi, ini adalah offset dalam byte antara item berurutan dari tipe yang sama, termasuk padding perataan.
    ///
    ///
    /// Versi stabil dari intrinsik ini adalah [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// Penjajaran minimum suatu jenis.
    ///
    /// Versi stabil dari intrinsik ini adalah [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// Penjajaran yang disukai dari suatu jenis.
    ///
    /// Intrinsik ini tidak memiliki pasangan yang stabil.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// Ukuran nilai referensi dalam byte.
    ///
    /// Versi stabil dari intrinsik ini adalah [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// Perataan yang diperlukan dari nilai yang direferensikan.
    ///
    /// Versi stabil dari intrinsik ini adalah [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Mendapat potongan string statis yang berisi nama suatu tipe.
    ///
    /// Versi stabil dari intrinsik ini adalah [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Mendapat pengenal yang unik secara global untuk jenis yang ditentukan.
    /// Fungsi ini akan mengembalikan nilai yang sama untuk suatu jenis terlepas dari crate mana pun ia dipanggil.
    ///
    ///
    /// Versi stabil dari intrinsik ini adalah [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// Penjaga untuk fungsi yang tidak aman yang tidak akan pernah bisa dijalankan jika `T` tidak berpenghuni:
    /// Ini akan secara statis baik panic, atau tidak melakukan apa pun.
    ///
    /// Intrinsik ini tidak memiliki pasangan yang stabil.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// Penjaga untuk fungsi yang tidak aman yang tidak akan pernah dapat dijalankan jika `T` tidak mengizinkan inisialisasi nol: Ini akan secara statis baik panic, atau tidak melakukan apa pun.
    ///
    ///
    /// Intrinsik ini tidak memiliki pasangan yang stabil.
    pub fn assert_zero_valid<T>();

    /// Penjaga untuk fungsi yang tidak aman yang tidak pernah dapat dijalankan jika `T` memiliki pola bit yang tidak valid: Ini akan secara statis baik panic, atau tidak melakukan apa pun.
    ///
    ///
    /// Intrinsik ini tidak memiliki pasangan yang stabil.
    pub fn assert_uninit_valid<T>();

    /// Mendapat referensi ke `Location` statis yang menunjukkan di mana ia dipanggil.
    ///
    /// Pertimbangkan untuk menggunakan [`core::panic::Location::caller`](crate::panic::Location::caller) sebagai gantinya.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Memindahkan nilai keluar dari ruang lingkup tanpa menjalankan lem tetes.
    ///
    /// Ini hanya ada untuk [`mem::forget_unsized`];`forget` normal menggunakan `ManuallyDrop` sebagai gantinya.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Menafsirkan ulang bit nilai dari satu jenis sebagai jenis lainnya.
    ///
    /// Kedua jenis tersebut harus memiliki ukuran yang sama.
    /// Baik aslinya, maupun hasilnya, mungkin bukan [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` secara semantik setara dengan perpindahan bitwise dari satu jenis ke jenis lainnya.Ini menyalin bit dari nilai sumber ke nilai tujuan, kemudian melupakan aslinya.
    /// Ini setara dengan C's `memcpy` di bawah kap, seperti `transmute_copy`.
    ///
    /// Karena `transmute` adalah operasi nilai, penyelarasan *nilai yang ditransmisikan itu sendiri* tidak menjadi perhatian.
    /// Seperti fungsi lainnya, kompilator sudah memastikan bahwa `T` dan `U` selaras dengan benar.
    /// Namun, saat mentransmutasi nilai yang *menunjuk ke tempat lain*(seperti pointer, referensi, kotak…), pemanggil harus memastikan keselarasan yang tepat dari nilai yang diarahkan ke.
    ///
    /// `transmute` **sangat** tidak aman.Ada banyak cara untuk menyebabkan [undefined behavior][ub] dengan fungsi ini.`transmute` harus menjadi pilihan terakhir mutlak.
    ///
    /// [nomicon](../../nomicon/transmutes.html) memiliki dokumentasi tambahan.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Ada beberapa hal yang benar-benar berguna bagi `transmute`.
    ///
    /// Mengubah penunjuk menjadi penunjuk fungsi.Ini *tidak* portabel untuk mesin di mana penunjuk fungsi dan penunjuk data memiliki ukuran yang berbeda.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Memperpanjang seumur hidup, atau memperpendek masa hidup yang tidak berubah.Ini canggih, Rust sangat tidak aman!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Jangan putus asa: banyak kegunaan `transmute` dapat dicapai melalui cara lain.
    /// Di bawah ini adalah aplikasi umum `transmute` yang dapat diganti dengan konstruksi yang lebih aman.
    ///
    /// Mengubah bytes(`&[u8]`) mentah menjadi `u32`, `f64`, dll .:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // gunakan `u32::from_ne_bytes` sebagai gantinya
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // atau gunakan `u32::from_le_bytes` atau `u32::from_be_bytes` untuk menentukan endianness
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Mengubah pointer menjadi `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Gunakan cast `as` sebagai gantinya
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// Mengubah `*mut T` menjadi `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Gunakan peminjaman kembali sebagai gantinya
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// Mengubah `&mut T` menjadi `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Sekarang, satukan `as` dan peminjam kembali, perhatikan bahwa rangkaian `as` `as` tidak transitif
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// Mengubah `&str` menjadi `&[u8]`:
    ///
    /// ```
    /// // ini bukan cara yang baik untuk melakukan ini.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Anda bisa menggunakan `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Atau, cukup gunakan string byte, jika Anda memiliki kendali atas string literal
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// Mengubah `Vec<&T>` menjadi `Vec<Option<&T>>`.
    ///
    /// Untuk mentransmutasikan jenis bagian dalam dari konten suatu wadah, Anda harus memastikan untuk tidak melanggar salah satu invarian penampung tersebut.
    /// Untuk `Vec`, ini berarti ukuran *dan perataan* tipe dalam harus sama.
    /// Kontainer lain mungkin bergantung pada ukuran tipe, kesejajaran, atau bahkan `TypeId`, dalam hal ini transmutasi tidak akan mungkin dilakukan tanpa melanggar invarian kontainer.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // mengkloning vector karena kami akan menggunakannya kembali nanti
    /// let v_clone = v_orig.clone();
    ///
    /// // Menggunakan transmute: ini bergantung pada tata letak data yang tidak ditentukan dari `Vec`, yang merupakan ide yang buruk dan dapat menyebabkan Perilaku Tidak Terdefinisi.
    /////
    /// // Namun, ini tidak ada salinannya.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Ini adalah cara yang disarankan dan aman.
    /// // Itu menyalin seluruh vector, ke dalam array baru.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Ini adalah cara "transmuting" a `Vec` tanpa penyalinan yang tepat dan tidak aman, tanpa bergantung pada tata letak data.
    /// // Alih-alih benar-benar memanggil `transmute`, kami melakukan cast penunjuk, tetapi dalam hal mengubah tipe dalam asli (`&i32`) ke yang baru (`Option<&i32>`), ini memiliki semua peringatan yang sama.
    /////
    /// // Selain informasi yang diberikan di atas, lihat juga dokumentasi [`from_raw_parts`].
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Perbarui ini ketika vec_into_raw_parts distabilkan.
    ///     // Pastikan vector asli tidak jatuh.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Menerapkan `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Ada beberapa cara untuk melakukan ini, dan ada beberapa masalah dengan cara (transmute) berikut ini.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // pertama: transmute bukanlah tipe safe;semua yang diperiksa adalah T dan
    ///         // U berukuran sama.
    ///         // Kedua, di sini, Anda memiliki dua referensi yang bisa berubah yang menunjuk ke memori yang sama.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Ini menghilangkan masalah keamanan tipe;`&mut *` akan* hanya *memberi Anda `&mut T` dari `&mut T` atau `* mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // namun, Anda masih memiliki dua referensi yang bisa berubah yang menunjuk ke memori yang sama.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Beginilah cara perpustakaan standar melakukannya.
    /// // Ini adalah metode terbaik, jika Anda perlu melakukan sesuatu seperti ini
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Ini sekarang memiliki tiga referensi yang bisa berubah menunjuk pada memori yang sama.`slice`, nilai r ret.0, dan nilai r ret.1.
    ///         // `slice` tidak pernah digunakan setelah `let ptr = ...`, sehingga orang dapat memperlakukannya sebagai "dead", dan oleh karena itu, Anda hanya memiliki dua irisan nyata yang dapat berubah.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Meskipun ini membuat const intrinsik stabil, kami memiliki beberapa kode kustom di const fn
    // pemeriksaan yang mencegah penggunaannya dalam `const fn`.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Mengembalikan `true` jika tipe sebenarnya yang diberikan sebagai `T` membutuhkan lem jatuh;mengembalikan `false` jika tipe sebenarnya yang disediakan untuk `T` mengimplementasikan `Copy`.
    ///
    ///
    /// Jika tipe sebenarnya tidak membutuhkan lem jatuh atau mengimplementasikan `Copy`, maka nilai kembalian dari fungsi ini tidak ditentukan.
    ///
    /// Versi stabil dari intrinsik ini adalah [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Menghitung offset dari penunjuk.
    ///
    /// Ini diimplementasikan sebagai intrinsik untuk menghindari konversi ke dan dari integer, karena konversi akan membuang informasi aliasing.
    ///
    /// # Safety
    ///
    /// Baik penunjuk awal dan hasil harus berada dalam batas atau satu byte setelah akhir dari objek yang dialokasikan.
    /// Jika penunjuk berada di luar batas atau terjadi luapan aritmatika, penggunaan lebih lanjut dari nilai yang dikembalikan akan menghasilkan perilaku yang tidak ditentukan.
    ///
    ///
    /// Versi stabil dari intrinsik ini adalah [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Menghitung offset dari penunjuk, berpotensi membungkus.
    ///
    /// Ini diimplementasikan sebagai intrinsik untuk menghindari konversi ke dan dari integer, karena konversi menghambat pengoptimalan tertentu.
    ///
    /// # Safety
    ///
    /// Tidak seperti intrinsik `offset`, intrinsik ini tidak membatasi pointer yang dihasilkan untuk menunjuk ke atau satu byte melewati akhir objek yang dialokasikan, dan itu dibungkus dengan aritmatika komplemen dua.
    /// Nilai yang dihasilkan belum tentu valid untuk digunakan untuk benar-benar mengakses memori.
    ///
    /// Versi stabil dari intrinsik ini adalah [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Setara dengan intrinsik `llvm.memcpy.p0i8.0i8.*` yang sesuai, dengan ukuran `count`*`size_of::<T>()` dan perataan
    ///
    /// `min_align_of::<T>()`
    ///
    /// Parameter volatile disetel ke `true`, jadi tidak akan dioptimalkan kecuali ukurannya sama dengan nol.
    ///
    /// Intrinsik ini tidak memiliki pasangan yang stabil.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Setara dengan `llvm.memmove.p0i8.0i8.*` sesuai intrinsik, dengan ukuran `count* size_of::<T>()` dan perataan
    ///
    /// `min_align_of::<T>()`
    ///
    /// Parameter volatile disetel ke `true`, jadi tidak akan dioptimalkan kecuali ukurannya sama dengan nol.
    ///
    /// Intrinsik ini tidak memiliki pasangan yang stabil.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Setara dengan intrinsik `llvm.memset.p0i8.*` yang sesuai, dengan ukuran `count* size_of::<T>()` dan kesejajaran `min_align_of::<T>()`.
    ///
    ///
    /// Parameter volatile disetel ke `true`, jadi tidak akan dioptimalkan kecuali ukurannya sama dengan nol.
    ///
    /// Intrinsik ini tidak memiliki pasangan yang stabil.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Melakukan beban volatil dari penunjuk `src`.
    ///
    /// Versi stabil dari intrinsik ini adalah [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Melakukan penyimpanan volatile ke penunjuk `dst`.
    ///
    /// Versi stabil dari intrinsik ini adalah [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Melakukan beban volatil dari penunjuk `src` Penunjuk tidak perlu disejajarkan.
    ///
    ///
    /// Intrinsik ini tidak memiliki pasangan yang stabil.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Melakukan penyimpanan volatile ke penunjuk `dst`.
    /// Penunjuk tidak perlu disejajarkan.
    ///
    /// Intrinsik ini tidak memiliki pasangan yang stabil.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Menampilkan akar kuadrat dari sebuah `f32`
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Menampilkan akar kuadrat dari sebuah `f64`
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Menaikkan `f32` menjadi pangkat integer.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Menaikkan `f64` menjadi pangkat integer.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Mengembalikan sinus dari `f32`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Mengembalikan sinus dari `f64`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Mengembalikan kosinus dari `f32`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Mengembalikan kosinus dari `f64`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Menaikkan daya `f32` menjadi `f32`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Menaikkan daya `f64` menjadi `f64`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Menampilkan eksponensial dari sebuah `f32`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Mengembalikan eksponensial dari sebuah `f64`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Mengembalikan 2 yang dipangkatkan dengan `f32`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Mengembalikan 2 yang dipangkatkan dengan `f64`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Mengembalikan logaritma natural dari `f32`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Mengembalikan logaritma natural dari `f64`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Mengembalikan logaritma basis 10 dari sebuah `f32`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Mengembalikan logaritma basis 10 dari sebuah `f64`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Mengembalikan logaritma basis 2 dari sebuah `f32`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Mengembalikan logaritma basis 2 dari sebuah `f64`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Mengembalikan `a * b + c` untuk nilai `f32`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Mengembalikan `a * b + c` untuk nilai `f64`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Mengembalikan nilai absolut dari sebuah `f32`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Mengembalikan nilai absolut dari sebuah `f64`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Menampilkan minimum dua nilai `f32`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Menampilkan minimum dua nilai `f64`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Menampilkan maksimum dua nilai `f32`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Menampilkan maksimum dua nilai `f64`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Menyalin tanda dari `y` ke `x` untuk nilai `f32`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Menyalin tanda dari `y` ke `x` untuk nilai `f64`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Mengembalikan bilangan bulat terbesar kurang dari atau sama dengan `f32`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Mengembalikan bilangan bulat terbesar kurang dari atau sama dengan `f64`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Mengembalikan bilangan bulat terkecil yang lebih besar dari atau sama dengan `f32`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Mengembalikan bilangan bulat terkecil yang lebih besar dari atau sama dengan `f64`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Mengembalikan bagian bilangan bulat dari `f32`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Mengembalikan bagian bilangan bulat dari `f64`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Mengembalikan bilangan bulat terdekat ke `f32`.
    /// Dapat memunculkan pengecualian floating-point yang tidak tepat jika argumennya bukan bilangan bulat.
    pub fn rintf32(x: f32) -> f32;
    /// Mengembalikan bilangan bulat terdekat ke `f64`.
    /// Dapat memunculkan pengecualian floating-point yang tidak tepat jika argumennya bukan bilangan bulat.
    pub fn rintf64(x: f64) -> f64;

    /// Mengembalikan bilangan bulat terdekat ke `f32`.
    ///
    /// Intrinsik ini tidak memiliki pasangan yang stabil.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Mengembalikan bilangan bulat terdekat ke `f64`.
    ///
    /// Intrinsik ini tidak memiliki pasangan yang stabil.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Mengembalikan bilangan bulat terdekat ke `f32`.Membulatkan casing setengah jalan menjauhi nol.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Mengembalikan bilangan bulat terdekat ke `f64`.Membulatkan casing setengah jalan menjauhi nol.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Penambahan float yang memungkinkan pengoptimalan berdasarkan aturan aljabar.
    /// Mungkin menganggap masukan terbatas.
    ///
    /// Intrinsik ini tidak memiliki pasangan yang stabil.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Pengurangan float yang memungkinkan pengoptimalan berdasarkan aturan aljabar.
    /// Mungkin menganggap masukan terbatas.
    ///
    /// Intrinsik ini tidak memiliki pasangan yang stabil.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Perkalian float yang memungkinkan pengoptimalan berdasarkan aturan aljabar.
    /// Mungkin menganggap masukan terbatas.
    ///
    /// Intrinsik ini tidak memiliki pasangan yang stabil.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Divisi float yang memungkinkan pengoptimalan berdasarkan aturan aljabar.
    /// Mungkin menganggap masukan terbatas.
    ///
    /// Intrinsik ini tidak memiliki pasangan yang stabil.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Sisa float yang memungkinkan pengoptimalan berdasarkan aturan aljabar.
    /// Mungkin menganggap masukan terbatas.
    ///
    /// Intrinsik ini tidak memiliki pasangan yang stabil.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Konversikan dengan LLVM fptoui/fptosi, yang mungkin mengembalikan undef untuk nilai di luar jangkauan
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Stabil sebagai [`f32::to_int_unchecked`] dan [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Mengembalikan jumlah bit yang disetel dalam tipe bilangan bulat `T`
    ///
    /// Versi stabil dari intrinsik ini tersedia pada primitif integer melalui metode `count_ones`.
    /// Sebagai contoh,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Menampilkan jumlah bit (zeroes) yang tidak disetel di depan dalam tipe bilangan bulat `T`.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada primitif integer melalui metode `leading_zeros`.
    /// Sebagai contoh,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// `x` dengan nilai `0` akan mengembalikan lebar bit `T`.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Seperti `ctlz`, tetapi sangat tidak aman karena mengembalikan `undef` saat diberi `x` dengan nilai `0`.
    ///
    ///
    /// Intrinsik ini tidak memiliki pasangan yang stabil.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Menampilkan jumlah bit (zeroes) yang tidak disetel di belakangnya dalam tipe bilangan bulat `T`.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada primitif integer melalui metode `trailing_zeros`.
    /// Sebagai contoh,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// Sebuah `x` dengan nilai `0` akan mengembalikan lebar bit `T`:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Seperti `cttz`, tetapi sangat tidak aman karena mengembalikan `undef` saat diberi `x` dengan nilai `0`.
    ///
    ///
    /// Intrinsik ini tidak memiliki pasangan yang stabil.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Membalik byte dalam tipe integer `T`.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada primitif integer melalui metode `swap_bytes`.
    /// Sebagai contoh,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Membalik bit dalam tipe integer `T`.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada primitif integer melalui metode `reverse_bits`.
    /// Sebagai contoh,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Melakukan penambahan bilangan bulat yang diperiksa.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada primitif integer melalui metode `overflowing_add`.
    /// Sebagai contoh,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Melakukan pengurangan bilangan bulat yang diperiksa
    ///
    /// Versi stabil dari intrinsik ini tersedia pada primitif integer melalui metode `overflowing_sub`.
    /// Sebagai contoh,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Melakukan perkalian bilangan bulat yang diperiksa
    ///
    /// Versi stabil dari intrinsik ini tersedia pada primitif integer melalui metode `overflowing_mul`.
    /// Sebagai contoh,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Melakukan pembagian yang tepat, menghasilkan perilaku tidak terdefinisi di mana `x % y != 0` atau `y == 0` atau `x == T::MIN && y == -1`
    ///
    ///
    /// Intrinsik ini tidak memiliki pasangan yang stabil.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Melakukan pembagian yang tidak dicentang, mengakibatkan perilaku tidak terdefinisi di mana `y == 0` atau `x == T::MIN && y == -1`
    ///
    ///
    /// Wrapper aman untuk intrinsik ini tersedia pada primitif integer melalui metode `checked_div`.
    /// Sebagai contoh,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Mengembalikan sisa dari divisi yang tidak dicentang, mengakibatkan perilaku tidak terdefinisi saat `y == 0` atau `x == T::MIN && y == -1`
    ///
    ///
    /// Wrapper aman untuk intrinsik ini tersedia pada primitif integer melalui metode `checked_rem`.
    /// Sebagai contoh,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Melakukan pergeseran kiri yang tidak dicentang, menghasilkan perilaku tidak terdefinisi saat `y < 0` atau `y >= N`, di mana N adalah lebar T dalam bit.
    ///
    ///
    /// Wrapper aman untuk intrinsik ini tersedia pada primitif integer melalui metode `checked_shl`.
    /// Sebagai contoh,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Melakukan shift kanan yang tidak dicentang, menghasilkan perilaku tidak terdefinisi saat `y < 0` atau `y >= N`, di mana N adalah lebar T dalam bit.
    ///
    ///
    /// Wrapper aman untuk intrinsik ini tersedia pada primitif integer melalui metode `checked_shr`.
    /// Sebagai contoh,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Mengembalikan hasil dari penambahan yang tidak dicentang, mengakibatkan perilaku tidak terdefinisi saat `x + y > T::MAX` atau `x + y < T::MIN`.
    ///
    ///
    /// Intrinsik ini tidak memiliki pasangan yang stabil.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Mengembalikan hasil pengurangan yang tidak dicentang, mengakibatkan perilaku tidak terdefinisi saat `x - y > T::MAX` atau `x - y < T::MIN`.
    ///
    ///
    /// Intrinsik ini tidak memiliki pasangan yang stabil.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Mengembalikan hasil perkalian yang tidak dicentang, mengakibatkan perilaku tidak terdefinisi saat `x *y > T::MAX` atau `x* y < T::MIN`.
    ///
    ///
    /// Intrinsik ini tidak memiliki pasangan yang stabil.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Melakukan putar ke kiri.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada primitif integer melalui metode `rotate_left`.
    /// Sebagai contoh,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Melakukan putar ke kanan.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada primitif integer melalui metode `rotate_right`.
    /// Sebagai contoh,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Mengembalikan (a + b) mod 2 <sup>N</sup>, di mana N adalah lebar T dalam bit.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada primitif integer melalui metode `wrapping_add`.
    /// Sebagai contoh,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Mengembalikan (a, b) mod 2 <sup>N</sup>, di mana N adalah lebar T dalam bit.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada primitif integer melalui metode `wrapping_sub`.
    /// Sebagai contoh,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Mengembalikan (a * b) mod 2 <sup>N</sup>, di mana N adalah lebar T dalam bit.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada primitif integer melalui metode `wrapping_mul`.
    /// Sebagai contoh,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Menghitung `a + b`, memenuhi batas numerik.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada primitif integer melalui metode `saturating_add`.
    /// Sebagai contoh,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Menghitung `a - b`, memenuhi batas numerik.
    ///
    /// Versi stabil dari intrinsik ini tersedia pada primitif integer melalui metode `saturating_sub`.
    /// Sebagai contoh,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Mengembalikan nilai diskriminan untuk varian di 'v';
    /// jika `T` tidak memiliki diskriminan, mengembalikan `0`.
    ///
    /// Versi stabil dari intrinsik ini adalah [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Mengembalikan jumlah varian dari tipe `T` yang ditransmisikan ke `usize`;
    /// jika `T` tidak memiliki varian, mengembalikan `0`.Varian yang tidak berpenghuni akan dihitung.
    ///
    /// Versi yang harus distabilkan dari intrinsik ini adalah [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Konstruksi "try catch" Rust yang memanggil penunjuk fungsi `try_fn` dengan penunjuk data `data`.
    ///
    /// Argumen ketiga adalah fungsi yang dipanggil jika panic terjadi.
    /// Fungsi ini mengambil penunjuk data dan penunjuk ke objek pengecualian khusus target yang ditangkap.
    ///
    /// Untuk informasi lebih lanjut, lihat sumber kompiler serta implementasi catch std.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Memancarkan penyimpanan `!nontemporal` menurut LLVM (lihat dokumen mereka).
    /// Mungkin tidak akan pernah stabil.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Lihat dokumentasi `<*const T>::offset_from` untuk detailnya.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Lihat dokumentasi `<*const T>::guaranteed_eq` untuk detailnya.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Lihat dokumentasi `<*const T>::guaranteed_ne` untuk detailnya.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Alokasikan pada waktu kompilasi.Tidak boleh dipanggil saat runtime.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Beberapa fungsi didefinisikan di sini karena secara tidak sengaja tersedia di modul ini di stable.
// Lihat <https://github.com/rust-lang/rust/issues/15702>.
// (`transmute` juga termasuk dalam kategori ini, tetapi tidak dapat digabungkan karena pemeriksaan bahwa `T` dan `U` memiliki ukuran yang sama.)
//

/// Memeriksa apakah `ptr` disejajarkan dengan benar sehubungan dengan `align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Menyalin `count *size_of::<T>()` byte dari `src` ke `dst`.Sumber dan tujuan harus* tidak * tumpang tindih.
///
/// Untuk wilayah memori yang mungkin tumpang tindih, gunakan [`copy`] sebagai gantinya.
///
/// `copy_nonoverlapping` secara semantik setara dengan C's [`memcpy`], tetapi dengan urutan argumen yang ditukar.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Perilaku tidak ditentukan jika salah satu dari kondisi berikut dilanggar:
///
/// * `src` harus [valid] untuk membaca `count * size_of::<T>()` byte.
///
/// * `dst` harus [valid] untuk menulis byte `count * size_of::<T>()`.
///
/// * Baik `src` dan `dst` harus disejajarkan dengan benar.
///
/// * Wilayah memori dimulai pada `src` dengan ukuran `hitungan *
///   ukuran dari: :<T>() `byte tidak boleh *tidak* tumpang tindih dengan wilayah memori yang dimulai dari `dst` dengan ukuran yang sama.
///
/// Seperti [`read`], `copy_nonoverlapping` membuat salinan bitwise dari `T`, terlepas dari apakah `T` adalah [`Copy`].
/// Jika `T` bukan [`Copy`], gunakan *keduanya* nilai di wilayah yang dimulai dari `*src` dan wilayah yang dimulai dari `* dst` dapat [violate memory safety][read-ownership].
///
///
/// Perhatikan bahwa meskipun ukuran yang disalin secara efektif (`count * size_of: :<T>()`) adalah `0`, penunjuk harus non-NULL dan disejajarkan dengan benar.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Terapkan [`Vec::append`] secara manual:
///
/// ```
/// use std::ptr;
///
/// /// Memindahkan semua elemen `src` ke `dst`, membiarkan `src` kosong.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Pastikan `dst` memiliki kapasitas yang cukup untuk menampung semua `src`.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Panggilan ke offset selalu aman karena `Vec` tidak akan pernah mengalokasikan lebih dari `isize::MAX` byte.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Potong `src` tanpa menjatuhkan isinya.
///         // Kami melakukan ini terlebih dahulu, untuk menghindari masalah jika terjadi sesuatu yang lebih jauh di panics.
///         src.set_len(0);
///
///         // Kedua wilayah tidak dapat tumpang tindih karena referensi yang dapat berubah bukan merupakan alias, dan dua vectors yang berbeda tidak dapat memiliki memori yang sama.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Beri tahu `dst` bahwa sekarang berisi konten `src`.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Lakukan pemeriksaan ini hanya pada waktu proses
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Tidak panik untuk memperkecil dampak codegen.
        abort();
    }*/

    // KEAMANAN: kontrak keamanan untuk `copy_nonoverlapping` harus
    // ditegakkan oleh penelepon.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Menyalin `count * size_of::<T>()` byte dari `src` ke `dst`.Sumber dan tujuan mungkin tumpang tindih.
///
/// Jika sumber dan tujuan *tidak akan pernah* tumpang tindih, [`copy_nonoverlapping`] dapat digunakan sebagai gantinya.
///
/// `copy` secara semantik setara dengan C's [`memmove`], tetapi dengan urutan argumen yang ditukar.
/// Penyalinan terjadi seolah-olah byte disalin dari `src` ke array sementara dan kemudian disalin dari array ke `dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Perilaku tidak ditentukan jika salah satu dari kondisi berikut dilanggar:
///
/// * `src` harus [valid] untuk membaca `count * size_of::<T>()` byte.
///
/// * `dst` harus [valid] untuk menulis byte `count * size_of::<T>()`.
///
/// * Baik `src` dan `dst` harus disejajarkan dengan benar.
///
/// Seperti [`read`], `copy` membuat salinan bitwise dari `T`, terlepas dari apakah `T` adalah [`Copy`].
/// Jika `T` bukan [`Copy`], menggunakan kedua nilai di wilayah yang dimulai dari `*src` dan wilayah yang dimulai dari `* dst` dapat [violate memory safety][read-ownership].
///
///
/// Perhatikan bahwa meskipun ukuran yang disalin secara efektif (`count * size_of: :<T>()`) adalah `0`, penunjuk harus non-NULL dan disejajarkan dengan benar.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Secara efisien membuat Rust vector dari buffer yang tidak aman:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` harus disejajarkan dengan benar untuk jenisnya dan bukan nol.
/// /// * `ptr` harus valid untuk membaca elemen bersebelahan `elts` dari tipe `T`.
/// /// * Elemen tersebut tidak boleh digunakan setelah memanggil fungsi ini kecuali `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // KEAMANAN: Prasyarat kami memastikan sumber selaras dan valid,
///     // dan `Vec::with_capacity` memastikan bahwa kami memiliki ruang yang dapat digunakan untuk menulisnya.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // KEAMANAN: Kami membuatnya dengan kapasitas sebanyak ini sebelumnya,
///     // dan `copy` sebelumnya telah menginisialisasi elemen ini.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Lakukan pemeriksaan ini hanya pada waktu proses
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Tidak panik untuk memperkecil dampak codegen.
        abort();
    }*/

    // KEAMANAN: kontrak keamanan untuk `copy` harus ditegakkan oleh penelepon.
    unsafe { copy(src, dst, count) }
}

/// Set memori `count * size_of::<T>()` byte mulai dari `dst` hingga `val`.
///
/// `write_bytes` mirip dengan C's [`memset`], tetapi menetapkan `count * size_of::<T>()` byte ke `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Perilaku tidak ditentukan jika salah satu dari kondisi berikut dilanggar:
///
/// * `dst` harus [valid] untuk menulis byte `count * size_of::<T>()`.
///
/// * `dst` harus disejajarkan dengan benar.
///
/// Selain itu, pemanggil harus memastikan bahwa menulis byte `count * size_of::<T>()` ke wilayah memori tertentu menghasilkan nilai `T` yang valid.
/// Menggunakan wilayah memori yang diketik sebagai `T` yang berisi nilai `T` yang tidak valid adalah perilaku yang tidak ditentukan.
///
/// Perhatikan bahwa meskipun ukuran yang disalin secara efektif (`count * size_of: :<T>()`) adalah `0`, penunjuk harus non-NULL dan disejajarkan dengan benar.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Penggunaan dasar:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Membuat nilai yang tidak valid:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Membocorkan nilai yang sebelumnya dipegang dengan menimpa `Box<T>` dengan penunjuk nol.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // Pada titik ini, menggunakan atau menghapus `v` menghasilkan perilaku yang tidak terdefinisi.
/// // drop(v); // ERROR
///
/// // Bahkan membocorkan `v` "uses", dan karenanya merupakan perilaku yang tidak terdefinisi.
/// // mem::forget(v); // ERROR
///
/// // Faktanya, `v` tidak valid menurut invarian tata letak tipe dasar, jadi operasi *apapun* yang menyentuhnya adalah perilaku yang tidak terdefinisi.
/////
/// // biarkan v2 =v;//ERROR
///
/// unsafe {
///     // Mari kita masukkan nilai yang valid
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Sekarang kotaknya baik-baik saja
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // KEAMANAN: kontrak keamanan untuk `write_bytes` harus ditegakkan oleh penelepon.
    unsafe { write_bytes(dst, val, count) }
}