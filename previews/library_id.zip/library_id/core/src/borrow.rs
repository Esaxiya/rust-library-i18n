//! Modul untuk bekerja dengan data pinjaman.

#![stable(feature = "rust1", since = "1.0.0")]

/// A trait untuk meminjam data.
///
/// Di Rust, adalah umum untuk memberikan representasi yang berbeda dari suatu tipe untuk kasus penggunaan yang berbeda.
/// Misalnya, lokasi penyimpanan dan pengelolaan nilai dapat secara khusus dipilih sesuai untuk penggunaan tertentu melalui jenis penunjuk seperti [`Box<T>`] atau [`Rc<T>`].
/// Di luar pembungkus generik yang dapat digunakan dengan jenis apa pun, beberapa jenis menyediakan aspek opsional yang menyediakan fungsionalitas yang berpotensi mahal.
/// Contoh untuk tipe seperti itu adalah [`String`] yang menambahkan kemampuan untuk memperluas string ke [`str`] dasar.
/// Ini membutuhkan penyimpanan informasi tambahan yang tidak diperlukan untuk string yang sederhana dan tidak dapat diubah.
///
/// Jenis ini memberikan akses ke data pokok melalui referensi ke jenis data tersebut.Mereka dikatakan 'dipinjam' sebagai tipe itu.
/// Misalnya, [`Box<T>`] dapat dipinjam sebagai `T` sedangkan [`String`] dapat dipinjam sebagai `str`.
///
/// Jenis menyatakan bahwa mereka dapat dipinjam sebagai beberapa jenis `T` dengan menerapkan `Borrow<T>`, memberikan referensi ke `T` dalam metode [`borrow`] trait.Satu tipe dapat dipinjam secara gratis karena beberapa tipe berbeda.
/// Jika ingin saling meminjam sebagai tipe-memungkinkan data yang mendasarinya dimodifikasi, ia juga dapat mengimplementasikan [`BorrowMut<T>`].
///
/// Lebih lanjut, saat menyediakan implementasi untuk traits tambahan, perlu dipertimbangkan apakah mereka harus berperilaku identik dengan tipe yang mendasari sebagai konsekuensi dari tindakan sebagai representasi dari tipe yang mendasarinya.
/// Kode umum biasanya menggunakan `Borrow<T>` jika kode tersebut bergantung pada perilaku yang sama dari implementasi trait tambahan ini.
/// traits ini kemungkinan besar akan muncul sebagai trait bounds tambahan.
///
/// Dalam `Eq`, `Ord`, dan `Hash` tertentu harus setara untuk nilai yang dipinjam dan dimiliki: `x.borrow() == y.borrow()` harus memberikan hasil yang sama dengan `x == y`.
///
/// Jika kode generik hanya perlu berfungsi untuk semua tipe yang dapat memberikan referensi ke tipe terkait `T`, seringkali lebih baik menggunakan [`AsRef<T>`] karena lebih banyak tipe dapat mengimplementasikannya dengan aman.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Sebagai kumpulan data, [`HashMap<K, V>`] memiliki kunci dan nilai.Jika data kunci sebenarnya tergabung dalam jenis pengelolaan tertentu, namun, nilai tersebut masih dapat dicari menggunakan referensi ke data kunci tersebut.
/// Misalnya, jika kuncinya adalah string, maka kemungkinan besar disimpan dengan peta hash sebagai [`String`], sementara itu seharusnya dapat dilakukan untuk mencari menggunakan [`&str`][`str`].
/// Jadi, `insert` perlu beroperasi pada `String` sementara `get` harus dapat menggunakan `&str`.
///
/// Sedikit disederhanakan, bagian yang relevan dari `HashMap<K, V>` terlihat seperti ini:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // bidang dihilangkan
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// Seluruh peta hash bersifat umum di atas tipe kunci `K`.Karena kunci ini disimpan dengan peta hash, tipe ini harus memiliki data kunci.
/// Saat memasukkan pasangan nilai-kunci, peta diberi `K` seperti itu dan perlu menemukan keranjang hash yang benar dan memeriksa apakah kunci sudah ada berdasarkan `K` tersebut.Oleh karena itu dibutuhkan `K: Hash + Eq`.
///
/// Saat mencari nilai di peta, bagaimanapun, harus memberikan referensi ke `K` sebagai kunci untuk mencari akan membutuhkan untuk selalu membuat nilai yang dimiliki.
/// Untuk kunci string, ini berarti nilai `String` perlu dibuat hanya untuk penelusuran kasus di mana hanya `str` tersedia.
///
/// Sebaliknya, metode `get` bersifat umum daripada jenis data kunci yang mendasarinya, yang disebut `Q` dalam tanda tangan metode di atas.Ini menyatakan bahwa `K` meminjam sebagai `Q` dengan mensyaratkan `K: Borrow<Q>` tersebut.
/// Dengan tambahan `Q: Hash + Eq`, ini menandakan persyaratan bahwa `K` dan `Q` memiliki implementasi `Hash` dan `Eq` traits yang menghasilkan hasil yang identik.
///
/// Penerapan `get` khususnya bergantung pada implementasi `Hash` yang identik dengan menentukan keranjang hash kunci dengan memanggil `Hash::hash` pada nilai `Q` meskipun itu memasukkan kunci berdasarkan nilai hash yang dihitung dari nilai `K`.
///
///
/// Akibatnya, peta hash rusak jika `K` yang membungkus nilai `Q` menghasilkan hash yang berbeda dari `Q`.Misalnya, bayangkan Anda memiliki tipe yang membungkus string tetapi membandingkan huruf ASCII dengan mengabaikan kapitalisasi:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Karena dua nilai yang sama perlu menghasilkan nilai hash yang sama, implementasi `Hash` juga harus mengabaikan kasus ASCII:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// Bisakah `CaseInsensitiveString` mengimplementasikan `Borrow<str>`?Ini tentu dapat memberikan referensi ke potongan string melalui string yang dimilikinya.
/// Tetapi karena implementasi `Hash`-nya berbeda, ia berperilaku berbeda dari `str` dan oleh karena itu, pada kenyataannya, tidak boleh mengimplementasikan `Borrow<str>`.
/// Jika ingin mengizinkan orang lain mengakses `str` yang mendasarinya, ia dapat melakukannya melalui `AsRef<str>` yang tidak memiliki persyaratan tambahan.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Meminjam secara tetap dari nilai yang dimiliki.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// A trait untuk saling meminjam data.
///
/// Sebagai pendamping [`Borrow<T>`], trait ini memungkinkan suatu tipe untuk dipinjam sebagai tipe yang mendasari dengan memberikan referensi yang bisa berubah.
/// Lihat [`Borrow<T>`] untuk informasi lebih lanjut tentang meminjam sebagai tipe lain.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Saling meminjam dari nilai yang dimiliki.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}