//! `Clone` trait untuk tipe yang tidak dapat 'disalin secara implisit'.
//!
//! Di Rust, beberapa tipe sederhana adalah "implicitly copyable" dan ketika Anda menetapkannya atau meneruskannya sebagai argumen, penerima akan mendapatkan salinannya, meninggalkan nilai aslinya di tempatnya.
//! Jenis ini tidak memerlukan alokasi untuk menyalin dan tidak memiliki finalizer (yaitu, tidak berisi kotak milik sendiri atau mengimplementasikan [`Drop`]), jadi kompilator menganggapnya murah dan aman untuk disalin.
//!
//! Untuk jenis lain, salinan harus dibuat secara eksplisit, dengan konvensi yang mengimplementasikan [`Clone`] trait dan memanggil metode [`clone`].
//!
//! [`clone`]: Clone::clone
//!
//! Contoh penggunaan dasar:
//!
//! ```
//! let s = String::new(); // Jenis string mengimplementasikan Clone
//! let copy = s.clone(); // jadi kita bisa mengkloningnya
//! ```
//!
//! Untuk mengimplementasikan Clone trait dengan mudah, Anda juga dapat menggunakan `#[derive(Clone)]`.Contoh:
//!
//! ```
//! #[derive(Clone)] // kami menambahkan Clone trait ke struct Morpheus
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // dan sekarang kita bisa mengkloningnya!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// trait umum untuk kemampuan menduplikasi objek secara eksplisit.
///
/// Berbeda dari [`Copy`] karena [`Copy`] implisit dan sangat murah, sedangkan `Clone` selalu eksplisit dan mungkin mahal atau mungkin tidak mahal.
/// Untuk menerapkan karakteristik ini, Rust tidak mengizinkan Anda untuk menerapkan ulang [`Copy`], tetapi Anda dapat menerapkan ulang `Clone` dan menjalankan kode arbitrer.
///
/// Karena `Clone` lebih umum daripada [`Copy`], Anda juga dapat membuat [`Copy`] menjadi `Clone` secara otomatis.
///
/// ## Derivable
///
/// trait ini dapat digunakan dengan `#[derive]` jika semua bidang adalah `Clone`.Implementasi `derive`d dari [`Clone`] memanggil [`clone`] di setiap kolom.
///
/// [`clone`]: Clone::clone
///
/// Untuk struct generik, `#[derive]` mengimplementasikan `Clone` secara bersyarat dengan menambahkan `Clone` terikat pada parameter generik.
///
/// ```
/// // `derive` mengimplementasikan Clone for Reading<T>saat T adalah Clone.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Bagaimana cara menerapkan `Clone`?
///
/// Tipe [`Copy`] harus memiliki implementasi `Clone` yang sepele.Lebih formal:
/// jika `T: Copy`, `x: T`, dan `y: &T`, maka `let x = y.clone();` setara dengan `let x = *y;`.
/// Implementasi manual harus berhati-hati untuk menegakkan invarian ini;namun, kode yang tidak aman tidak boleh bergantung padanya untuk memastikan keamanan memori.
///
/// Contohnya adalah struct umum yang memegang penunjuk fungsi.Dalam kasus ini, implementasi `Clone` tidak dapat `diturunkan`d, tetapi dapat diimplementasikan sebagai:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Pelaksana tambahan
///
/// Selain [implementors listed below][impls], jenis berikut juga menerapkan `Clone`:
///
/// * Jenis item fungsi (yaitu, jenis berbeda yang ditentukan untuk setiap fungsi)
/// * Jenis penunjuk fungsi (mis., `fn() -> i32`)
/// * Jenis array, untuk semua ukuran, jika jenis item juga menerapkan `Clone` (misalnya, `[i32; 123456]`)
/// * Jenis tupel, jika setiap komponen juga mengimplementasikan `Clone` (mis., `()`, `(i32, bool)`)
/// * Jenis penutupan, jika tidak menangkap nilai dari lingkungan atau jika semua nilai yang ditangkap menerapkan `Clone` sendiri.
///   Perhatikan bahwa variabel yang diambil oleh referensi bersama selalu menerapkan `Clone` (meskipun referensi tidak), sedangkan variabel yang diambil oleh referensi yang bisa berubah tidak pernah menerapkan `Clone`.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Mengembalikan salinan nilai.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str mengimplementasikan Clone
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Melakukan tugas salin dari `source`.
    ///
    /// `a.clone_from(&b)` fungsinya setara dengan `a = b.clone()`, tetapi dapat diganti untuk menggunakan kembali sumber daya `a` untuk menghindari alokasi yang tidak perlu.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Turunkan makro yang menghasilkan impl dari trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): struct ini digunakan hanya oleh#[menurunkan] untuk menegaskan bahwa setiap komponen dari suatu tipe mengimplementasikan Clone atau Copy.
//
//
// Struct ini tidak boleh muncul dalam kode pengguna.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Implementasi `Clone` untuk tipe primitif.
///
/// Implementasi yang tidak dapat dijelaskan di Rust diimplementasikan di `traits::SelectionContext::copy_clone_conditions()` di `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Referensi bersama dapat dikloning, tetapi referensi yang dapat berubah *tidak bisa*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Referensi bersama dapat dikloning, tetapi referensi yang dapat berubah *tidak bisa*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}