#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Berisi definisi struct untuk tata letak tipe bawaan kompilator.
//!
//! Mereka dapat digunakan sebagai target transmutasi dalam kode yang tidak aman untuk memanipulasi representasi mentah secara langsung.
//!
//!
//! Definisi mereka harus selalu cocok dengan ABI yang ditentukan di `rustc_middle::ty::layout`.
//!

/// Representasi objek trait seperti `&dyn SomeTrait`.
///
/// Struct ini memiliki layout yang sama dengan tipe seperti `&dyn SomeTrait` dan `Box<dyn AnotherTrait>`.
///
/// `TraitObject` dijamin cocok dengan tata letak, tetapi ini bukan jenis objek trait (misalnya, bidang tidak langsung dapat diakses di `&dyn SomeTrait`) juga tidak mengontrol tata letak itu (mengubah definisi tidak akan mengubah tata letak `&dyn SomeTrait`).
///
/// Ini hanya dirancang untuk digunakan oleh kode tidak aman yang perlu memanipulasi detail tingkat rendah.
///
/// Tidak ada cara untuk merujuk ke semua objek trait secara umum, jadi satu-satunya cara untuk membuat nilai jenis ini adalah dengan fungsi seperti [`std::mem::transmute`][transmute].
/// Demikian pula, satu-satunya cara untuk membuat objek trait yang sebenarnya dari nilai `TraitObject` adalah dengan `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Menyintesis objek trait dengan jenis yang tidak cocok - yang vtable tidak sesuai dengan jenis nilai yang ditunjukkan oleh penunjuk data - kemungkinan besar akan menyebabkan perilaku yang tidak ditentukan.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // contoh trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // biarkan kompilator membuat objek trait
/// let object: &dyn Foo = &value;
///
/// // lihat representasi mentahnya
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // penunjuk data adalah alamat `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // buat objek baru, dengan menunjuk ke `i32` yang berbeda, berhati-hatilah saat menggunakan vtabel `i32` dari `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // ini harus bekerja seperti jika kita telah membuat objek trait dari `other_value` secara langsung
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}