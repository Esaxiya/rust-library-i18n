//! Implementasi Trait untuk `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Menerapkan pengurutan string.
///
/// String diurutkan [lexicographically](Ord#lexicographical-comparison) berdasarkan nilai byte-nya.
/// Ini mengurutkan poin kode Unicode berdasarkan posisi mereka di bagan kode.
/// Ini belum tentu sama dengan pesanan "alphabetical", yang bervariasi menurut bahasa dan lokal.
/// Menyortir string menurut standar yang diterima secara budaya memerlukan data khusus lokal yang berada di luar cakupan tipe `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Menerapkan operasi perbandingan pada string.
///
/// String dibandingkan [lexicographically](Ord#lexicographical-comparison) dengan nilai byte-nya.
/// Ini membandingkan poin kode Unicode berdasarkan posisinya di bagan kode.
/// Ini belum tentu sama dengan pesanan "alphabetical", yang bervariasi menurut bahasa dan lokal.
/// Membandingkan string menurut standar yang diterima secara budaya memerlukan data khusus lokal yang berada di luar cakupan tipe `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Menerapkan pemotongan substring dengan sintaks `&self[..]` atau `&mut self[..]`.
///
/// Mengembalikan sepotong seluruh string, yaitu, mengembalikan `&self` atau `&mut self`.Setara dengan `&self [0 ..
/// len] `atau`&mut self [0 ..
/// len]`.
/// Tidak seperti operasi pengindeksan lainnya, ini tidak akan pernah bisa dilakukan oleh panic.
///
/// Operasi ini adalah *O*(1).
///
/// Sebelum 1.20.0, operasi pengindeksan ini masih didukung oleh implementasi langsung `Index` dan `IndexMut`.
///
/// Setara dengan `&self[0 .. len]` atau `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Menerapkan pemotongan substring dengan sintaks `&self[begin .. end]` atau `&mut self[begin .. end]`.
///
/// Mengembalikan sepotong string yang diberikan dari rentang byte [`mulai`, `end`).
///
/// Operasi ini adalah *O*(1).
///
/// Sebelum 1.20.0, operasi pengindeksan ini masih didukung oleh implementasi langsung `Index` dan `IndexMut`.
///
/// # Panics
///
/// Panics jika `begin` atau `end` tidak menunjuk ke offset byte awal dari sebuah karakter (sebagaimana ditentukan oleh `is_char_boundary`), jika `begin > end`, atau jika `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // ini akan panic:
/// // byte 2 terletak di dalam `ö`:
/// // &s [2 ..3];
///
/// // byte 8 terletak di dalam `老`&s [1 ..
/// // 8];
///
/// // byte 100 berada di luar string&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SAFETY: cukup periksa bahwa `start` dan `end` berada di batas karakter,
            // dan kami meneruskan referensi yang aman, sehingga nilai kembaliannya juga akan menjadi satu.
            // Kami juga memeriksa batas karakter, jadi ini UTF-8 yang valid.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SAFETY: baru saja memeriksa bahwa `start` dan `end` berada di batas karakter.
            // Kami tahu penunjuk itu unik karena kami mendapatkannya dari `slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // KEAMANAN: penelepon menjamin bahwa `self` berada dalam batas `slice`
        // yang memenuhi semua kondisi untuk `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // KEAMANAN: lihat komentar untuk `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary memeriksa bahwa indeks ada di [0, .len()] tidak dapat menggunakan kembali `get` seperti di atas, karena masalah NLL
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SAFETY: cukup periksa bahwa `start` dan `end` berada di batas karakter,
            // dan kami meneruskan referensi yang aman, sehingga nilai kembaliannya juga akan menjadi satu.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Menerapkan pemotongan substring dengan sintaks `&self[.. end]` atau `&mut self[.. end]`.
///
/// Mengembalikan sepotong string yang diberikan dari rentang byte [`0`, `end`).
/// Setara dengan `&self[0 .. end]` atau `&mut self[0 .. end]`.
///
/// Operasi ini adalah *O*(1).
///
/// Sebelum 1.20.0, operasi pengindeksan ini masih didukung oleh implementasi langsung `Index` dan `IndexMut`.
///
/// # Panics
///
/// Panics jika `end` tidak menunjuk ke byte awal offset dari sebuah karakter (seperti yang didefinisikan oleh `is_char_boundary`), atau jika `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // SAFETY: baru saja memeriksa bahwa `end` ada di batas karakter,
            // dan kami meneruskan referensi yang aman, sehingga nilai kembaliannya juga akan menjadi satu.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // SAFETY: baru saja memeriksa bahwa `end` ada di batas karakter,
            // dan kami meneruskan referensi yang aman, sehingga nilai kembaliannya juga akan menjadi satu.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // SAFETY: baru saja memeriksa bahwa `end` ada di batas karakter,
            // dan kami meneruskan referensi yang aman, sehingga nilai kembaliannya juga akan menjadi satu.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Menerapkan pemotongan substring dengan sintaks `&self[begin ..]` atau `&mut self[begin ..]`.
///
/// Mengembalikan sepotong string yang diberikan dari rentang byte [`mulai`, `len`).Setara dengan `&self [begin ..
/// len] `atau`&mut self [mulai ..
/// len]`.
///
/// Operasi ini adalah *O*(1).
///
/// Sebelum 1.20.0, operasi pengindeksan ini masih didukung oleh implementasi langsung `Index` dan `IndexMut`.
///
/// # Panics
///
/// Panics jika `begin` tidak menunjuk ke byte awal offset dari sebuah karakter (seperti yang didefinisikan oleh `is_char_boundary`), atau jika `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // SAFETY: baru saja memeriksa bahwa `start` ada di batas karakter,
            // dan kami meneruskan referensi yang aman, sehingga nilai kembaliannya juga akan menjadi satu.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // SAFETY: baru saja memeriksa bahwa `start` ada di batas karakter,
            // dan kami meneruskan referensi yang aman, sehingga nilai kembaliannya juga akan menjadi satu.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // KEAMANAN: penelepon menjamin bahwa `self` berada dalam batas `slice`
        // yang memenuhi semua kondisi untuk `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // KEAMANAN: identik dengan `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // SAFETY: baru saja memeriksa bahwa `start` ada di batas karakter,
            // dan kami meneruskan referensi yang aman, sehingga nilai kembaliannya juga akan menjadi satu.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Menerapkan pemotongan substring dengan sintaks `&self[begin ..= end]` atau `&mut self[begin ..= end]`.
///
/// Mengembalikan sepotong string yang diberikan dari rentang byte [`begin`, `end`].Setara dengan `&self [begin .. end + 1]` atau `&mut self[begin .. end + 1]`, kecuali jika `end` memiliki nilai maksimum untuk `usize`.
///
/// Operasi ini adalah *O*(1).
///
/// # Panics
///
/// Panics jika `begin` tidak menunjuk ke offset byte awal dari sebuah karakter (sebagaimana ditentukan oleh `is_char_boundary`), jika `end` tidak menunjuk ke offset byte akhir dari sebuah karakter (`end + 1` adalah offset byte awal atau sama dengan `len`), jika `begin > end`, atau jika `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // KEAMANAN: penelepon harus memegang kontrak keamanan untuk `get_unchecked`.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // KEAMANAN: penelepon harus memegang kontrak keamanan untuk `get_unchecked_mut`.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Menerapkan pemotongan substring dengan sintaks `&self[..= end]` atau `&mut self[..= end]`.
///
/// Mengembalikan sepotong string yang diberikan dari rentang byte [0, `end`].
/// Setara dengan `&self [0 .. end + 1]`, kecuali jika `end` memiliki nilai maksimum untuk `usize`.
///
/// Operasi ini adalah *O*(1).
///
/// # Panics
///
/// Panics jika `end` tidak menunjuk ke offset byte akhir dari sebuah karakter (`end + 1` adalah offset byte awal seperti yang ditentukan oleh `is_char_boundary`, atau sama dengan `len`), atau jika `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // KEAMANAN: penelepon harus memegang kontrak keamanan untuk `get_unchecked`.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // KEAMANAN: penelepon harus memegang kontrak keamanan untuk `get_unchecked_mut`.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Parse nilai dari string
///
/// Metode [`from_str`] `FromStr` sering digunakan secara implisit, melalui metode [`parse`] [`str`].
/// Lihat dokumentasi [`parse`] untuk mengetahui contohnya.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` tidak memiliki parameter seumur hidup, sehingga Anda hanya dapat mengurai jenis yang tidak berisi parameter seumur hidup itu sendiri.
///
/// Dengan kata lain, Anda dapat mengurai `i32` dengan `FromStr`, tetapi tidak dengan `&i32`.
/// Anda dapat mengurai struct yang berisi `i32`, tetapi tidak yang berisi `&i32`.
///
/// # Examples
///
/// Implementasi dasar `FromStr` pada contoh tipe `Point`:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// Kesalahan terkait yang dapat dikembalikan dari penguraian.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Mengurai string `s` untuk mengembalikan nilai jenis ini.
    ///
    /// Jika penguraian berhasil, kembalikan nilai di dalam [`Ok`], jika tidak, ketika string berformat buruk, kembalikan kesalahan khusus ke dalam [`Err`].
    /// Jenis kesalahan khusus untuk implementasi trait.
    ///
    /// # Examples
    ///
    /// Penggunaan dasar dengan [`i32`], jenis yang mengimplementasikan `FromStr`:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Parsing `bool` dari sebuah string.
    ///
    /// Menghasilkan `Result<bool, ParseBoolError>`, karena `s` mungkin benar-benar dapat diurai atau tidak.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Perhatikan, dalam banyak kasus, metode `.parse()` pada `str` lebih tepat.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}