//! Mendefinisikan jenis kesalahan utf8.

use crate::fmt;

/// Kesalahan yang dapat terjadi saat mencoba menafsirkan urutan [`u8`] sebagai string.
///
/// Dengan demikian, kelompok fungsi dan metode `from_utf8` untuk [`String`] dan [`&str`] memanfaatkan kesalahan ini, misalnya.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// Metode jenis kesalahan ini dapat digunakan untuk membuat fungsionalitas yang mirip dengan `String::from_utf8_lossy` tanpa mengalokasikan memori heap:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// Mengembalikan indeks dalam string tertentu yang UTF-8 validnya telah diverifikasi.
    ///
    /// Ini adalah indeks maksimum sehingga `from_utf8(&input[..index])` akan mengembalikan `Ok(_)`.
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// use std::str;
    ///
    /// // beberapa byte tidak valid, di vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 mengembalikan Utf8Error
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // byte kedua tidak valid di sini
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// Memberikan informasi lebih lanjut tentang kegagalan:
    ///
    /// * `None`: akhir masukan tercapai secara tak terduga.
    ///   `self.valid_up_to()` adalah 1 hingga 3 byte dari akhir input.
    ///   Jika aliran byte (seperti file atau soket jaringan) sedang didekodekan secara bertahap, ini bisa menjadi `char` yang valid yang urutan byte UTF-8-nya mencakup beberapa potongan.
    ///
    ///
    /// * `Some(len)`: byte yang tidak terduga ditemukan.
    ///   Panjang yang diberikan adalah urutan byte tidak valid yang dimulai pada indeks yang diberikan oleh `valid_up_to()`.
    ///   Decoding harus dilanjutkan setelah urutan itu (setelah memasukkan [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD]) jika terjadi decoding lossy.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// Kesalahan kembali saat mengurai `bool` menggunakan [`from_str`] gagal
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}