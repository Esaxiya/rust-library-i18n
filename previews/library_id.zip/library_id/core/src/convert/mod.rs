//! Traits untuk konversi antar jenis.
//!
//! traits dalam modul ini menyediakan cara untuk mengkonversi dari satu tipe ke tipe lainnya.
//! Setiap trait memiliki tujuan yang berbeda:
//!
//! - Terapkan [`AsRef`] trait untuk konversi referensi-ke-referensi yang murah
//! - Terapkan [`AsMut`] trait untuk konversi murah yang bisa diubah menjadi berubah
//! - Terapkan [`From`] trait untuk menggunakan konversi nilai-ke-nilai
//! - Menerapkan [`Into`] trait untuk menggunakan konversi nilai-ke-nilai ke jenis di luar crate saat ini
//! - [`TryFrom`] dan [`TryInto`] traits berperilaku seperti [`From`] dan [`Into`], tetapi harus diterapkan jika konversi dapat gagal.
//!
//! traits dalam modul ini sering digunakan sebagai trait bounds untuk fungsi umum sehingga mendukung argumen berbagai jenis.Lihat dokumentasi masing-masing trait untuk mengetahui contohnya.
//!
//! Sebagai pembuat pustaka, Anda harus selalu lebih suka mengimplementasikan [`From<T>`][`From`] atau [`TryFrom<T>`][`TryFrom`] daripada [`Into<U>`][`Into`] atau [`TryInto<U>`][`TryInto`], karena [`From`] dan [`TryFrom`] memberikan fleksibilitas yang lebih besar dan menawarkan implementasi [`Into`] atau [`TryInto`] yang setara secara gratis, berkat implementasi selimut di pustaka standar.
//! Saat menargetkan versi sebelum Rust 1.41, mungkin perlu menerapkan [`Into`] atau [`TryInto`] secara langsung saat mengonversi ke jenis di luar crate saat ini.
//!
//! # Implementasi Generik
//!
//! - [`AsRef`] dan dereferensi otomatis [`AsMut`] jika tipe bagian dalam adalah referensi
//! - [`From`]`<U>untuk T` menyiratkan [`Into`]`</u><T><U>untuk U`</u>
//! - [`TryFrom`]`<U>untuk T` menyiratkan [`TryInto`]`</u><T><U>untuk U`</u>
//! - [`From`] dan [`Into`] bersifat refleksif, artinya semua tipe `into` bisa sendiri dan `from` sendiri
//!
//! Lihat setiap trait untuk contoh penggunaan.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Fungsi identitas.
///
/// Ada dua hal penting yang perlu diperhatikan tentang fungsi ini:
///
/// - Itu tidak selalu sama dengan closure seperti `|x| x`, karena closure dapat memaksa `x` menjadi tipe yang berbeda.
///
/// - Ini memindahkan input `x` yang diteruskan ke fungsi.
///
/// Meskipun mungkin tampak aneh memiliki fungsi yang hanya mengembalikan input, ada beberapa kegunaan yang menarik.
///
///
/// # Examples
///
/// Menggunakan `identity` untuk tidak melakukan apa pun dalam urutan fungsi lain yang menarik:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Anggaplah menambahkan satu fungsi yang menarik.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Menggunakan `identity` sebagai kasus dasar "do nothing" dalam kondisi:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Lakukan lebih banyak hal menarik ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Menggunakan `identity` untuk mempertahankan varian `Some` dari sebuah iterator `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Digunakan untuk melakukan konversi referensi-ke-referensi yang murah.
///
/// trait ini mirip dengan [`AsMut`] yang digunakan untuk mengkonversi antara referensi yang bisa berubah.
/// Jika Anda perlu melakukan konversi yang mahal, lebih baik menerapkan [`From`] dengan tipe `&T` atau menulis fungsi kustom.
///
/// `AsRef` memiliki tanda tangan yang sama dengan [`Borrow`], tetapi [`Borrow`] berbeda dalam beberapa aspek:
///
/// - Tidak seperti `AsRef`, [`Borrow`] memiliki implikasi selimut untuk `T` apa pun, dan dapat digunakan untuk menerima referensi atau nilai.
/// - [`Borrow`] juga mensyaratkan bahwa [`Hash`], [`Eq`] dan [`Ord`] untuk nilai pinjaman yang setara dengan nilai yang dimiliki.
/// Untuk alasan ini, jika Anda ingin meminjam hanya satu bidang dari sebuah struct Anda dapat mengimplementasikan `AsRef`, tetapi tidak [`Borrow`].
///
/// **Note: trait ini tidak boleh gagal **.Jika konversi bisa gagal, gunakan metode khusus yang mengembalikan [`Option<T>`] atau [`Result<T, E>`].
///
/// # Implementasi Generik
///
/// - `AsRef` auto-dereferences jika tipe bagian dalam adalah referensi atau referensi yang bisa berubah (misalnya: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Dengan menggunakan trait bounds kita dapat menerima argumen dari tipe yang berbeda selama mereka dapat dikonversi ke tipe `T` yang ditentukan.
///
/// Misalnya: Dengan membuat fungsi generik yang menggunakan `AsRef<str>`, kami menyatakan bahwa kami ingin menerima semua referensi yang dapat dikonversi ke [`&str`] sebagai argumen.
/// Karena [`String`] dan [`&str`] mengimplementasikan `AsRef<str>`, kita dapat menerima keduanya sebagai argumen masukan.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Melakukan konversi.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Digunakan untuk melakukan konversi referensi yang bisa berubah-menjadi-berubah yang murah.
///
/// trait ini mirip dengan [`AsRef`] tetapi digunakan untuk mengkonversi antara referensi yang bisa berubah.
/// Jika Anda perlu melakukan konversi yang mahal, lebih baik menerapkan [`From`] dengan tipe `&mut T` atau menulis fungsi kustom.
///
/// **Note: trait ini tidak boleh gagal **.Jika konversi bisa gagal, gunakan metode khusus yang mengembalikan [`Option<T>`] atau [`Result<T, E>`].
///
/// # Implementasi Generik
///
/// - `AsMut` auto-dereferences jika tipe bagian dalam adalah referensi yang bisa berubah (misalnya: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Menggunakan `AsMut` sebagai trait bound untuk fungsi umum, kami dapat menerima semua referensi yang dapat diubah yang dapat dikonversi ke tipe `&mut T`.
/// Karena [`Box<T>`] mengimplementasikan `AsMut<T>`, kita dapat menulis fungsi `add_one` yang mengambil semua argumen yang dapat dikonversi ke `&mut u64`.
/// Karena [`Box<T>`] mengimplementasikan `AsMut<T>`, `add_one` juga menerima argumen tipe `&mut Box<u64>`:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Melakukan konversi.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Konversi nilai ke nilai yang menggunakan nilai masukan.Kebalikan dari [`From`].
///
/// Seseorang harus menghindari penerapan [`Into`] dan mengimplementasikan [`From`] sebagai gantinya.
/// Menerapkan [`From`] secara otomatis menyediakan implementasi [`Into`] berkat implementasi selimut di pustaka standar.
///
/// Lebih suka menggunakan [`Into`] daripada [`From`] saat menentukan trait bounds pada fungsi umum untuk memastikan bahwa jenis yang hanya mengimplementasikan [`Into`] juga dapat digunakan.
///
/// **Note: trait ini tidak boleh gagal **.Jika konversi bisa gagal, gunakan [`TryInto`].
///
/// # Implementasi Generik
///
/// - [`From`]`<T>untuk U` menyiratkan `Into<U> for T`
/// - [`Into`] bersifat refleksif, yang berarti `Into<T> for T` diimplementasikan
///
/// # Menerapkan [`Into`] untuk konversi ke tipe eksternal di versi lama Rust
///
/// Sebelum Rust 1.41, jika tipe tujuan bukan bagian dari crate saat ini, maka Anda tidak dapat mengimplementasikan [`From`] secara langsung.
/// Misalnya, ambil kode ini:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Ini akan gagal untuk dikompilasi di versi bahasa yang lebih lama karena aturan yatim piatu Rust dulu sedikit lebih ketat.
/// Untuk melewati ini, Anda dapat mengimplementasikan [`Into`] secara langsung:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Penting untuk dipahami bahwa [`Into`] tidak menyediakan implementasi [`From`] (seperti yang dilakukan [`From`] dengan [`Into`]).
/// Oleh karena itu, Anda harus selalu mencoba menerapkan [`From`] dan kemudian kembali ke [`Into`] jika [`From`] tidak dapat diterapkan.
///
/// # Examples
///
/// [`String`] mengimplementasikan [`Into`]`<`[`Vec`] `<` [`u8`]`>>`:
///
/// Untuk menyatakan bahwa kita ingin fungsi generik mengambil semua argumen yang dapat dikonversi ke tipe `T` yang ditentukan, kita dapat menggunakan trait bound dari [`Into`]`<T>`.
///
/// Misalnya: Fungsi `is_hello` mengambil semua argumen yang dapat diubah menjadi [`Vec`]`<`[`u8`] `>`.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Melakukan konversi.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Digunakan untuk melakukan konversi nilai-ke-nilai sambil menggunakan nilai masukan.Ini adalah kebalikan dari [`Into`].
///
/// Seseorang harus selalu lebih suka mengimplementasikan `From` daripada [`Into`] karena menerapkan `From` secara otomatis menyediakan implementasi [`Into`] berkat implementasi selimut di pustaka standar.
///
///
/// Hanya terapkan [`Into`] saat menargetkan versi sebelum Rust 1.41 dan mengonversinya ke jenis di luar crate saat ini.
/// `From` tidak dapat melakukan jenis konversi ini di versi sebelumnya karena aturan yatim piatu Rust.
/// Lihat [`Into`] untuk lebih jelasnya.
///
/// Lebih suka menggunakan [`Into`] daripada menggunakan `From` saat menentukan trait bounds pada fungsi generik.
/// Dengan cara ini, tipe yang secara langsung mengimplementasikan [`Into`] dapat digunakan sebagai argumen juga.
///
/// `From` juga sangat berguna saat melakukan penanganan kesalahan.Saat membuat fungsi yang bisa gagal, tipe kembalian umumnya akan dalam bentuk `Result<T, E>`.
/// `From` trait menyederhanakan penanganan kesalahan dengan memungkinkan suatu fungsi mengembalikan satu jenis kesalahan yang merangkum beberapa jenis kesalahan.Lihat bagian "Examples" dan [the book][book] untuk lebih jelasnya.
///
/// **Note: trait ini tidak boleh gagal **.Jika konversi bisa gagal, gunakan [`TryFrom`].
///
/// # Implementasi Generik
///
/// - `From<T> for U` menyiratkan [`Ke`]`<U>untuk T`</u>
/// - `From` bersifat refleksif, yang berarti `From<T> for T` diimplementasikan
///
/// # Examples
///
/// [`String`] mengimplementasikan `From<&str>`:
///
/// Konversi eksplisit dari `&str` ke String dilakukan sebagai berikut:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Saat melakukan penanganan kesalahan, sering kali berguna untuk mengimplementasikan `From` untuk jenis kesalahan Anda sendiri.
/// Dengan mengonversi jenis kesalahan yang mendasari menjadi jenis kesalahan khusus kita sendiri yang merangkum jenis kesalahan yang mendasarinya, kita dapat mengembalikan satu jenis kesalahan tanpa kehilangan informasi tentang penyebab yang mendasarinya.
/// Operator '?' secara otomatis mengubah jenis kesalahan yang mendasari menjadi jenis kesalahan kustom kami dengan memanggil `Into<CliError>::into` yang secara otomatis disediakan saat menerapkan `From`.
/// Kompilator kemudian menyimpulkan implementasi `Into` mana yang harus digunakan.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Melakukan konversi.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Upaya konversi yang menggunakan `self`, yang mungkin mahal atau mungkin tidak mahal.
///
/// Penulis perpustakaan biasanya tidak secara langsung mengimplementasikan trait ini, tetapi lebih memilih mengimplementasikan [`TryFrom`] trait, yang menawarkan fleksibilitas lebih besar dan menyediakan implementasi `TryInto` yang setara secara gratis, berkat implementasi selimut di pustaka standar.
/// Untuk informasi lebih lanjut tentang ini, lihat dokumentasi untuk [`Into`].
///
/// # Menerapkan `TryInto`
///
/// Ini mengalami pembatasan dan alasan yang sama seperti menerapkan [`Into`], lihat di sana untuk detailnya.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Jenis yang dikembalikan jika terjadi kesalahan konversi.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Melakukan konversi.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Jenis konversi yang sederhana dan aman yang mungkin gagal secara terkontrol dalam beberapa keadaan.Ini adalah kebalikan dari [`TryInto`].
///
/// Ini berguna saat Anda melakukan konversi jenis yang mungkin berhasil tetapi mungkin juga memerlukan penanganan khusus.
/// Misalnya, tidak ada cara untuk mengonversi [`i64`] menjadi [`i32`] menggunakan [`From`] trait, karena [`i64`] mungkin berisi nilai yang tidak dapat diwakili oleh [`i32`] sehingga konversi tersebut akan kehilangan data.
///
/// Ini dapat ditangani dengan memotong [`i64`] menjadi [`i32`] (pada dasarnya memberikan modulo [`i32::MAX`] nilai [`i64`]) atau hanya mengembalikan [`i32::MAX`], atau dengan metode lain.
/// [`From`] trait dimaksudkan untuk konversi yang sempurna, jadi `TryFrom` trait memberi tahu programmer ketika konversi jenis bisa menjadi buruk dan membiarkan mereka memutuskan bagaimana menanganinya.
///
/// # Implementasi Generik
///
/// - `TryFrom<T> for U` menyiratkan [`TryInto`]`<U>untuk T`</u>
/// - [`try_from`] bersifat refleksif, yang berarti bahwa `TryFrom<T> for T` diimplementasikan dan tidak dapat gagal-jenis `Error` yang terkait untuk memanggil `T::try_from()` pada nilai jenis `T` adalah [`Infallible`].
/// Ketika tipe [`!`] distabilkan, [`Infallible`] dan [`!`] akan setara.
///
/// `TryFrom<T>` dapat diimplementasikan sebagai berikut:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Seperti yang dijelaskan, [`i32`] mengimplementasikan `TryFrom <` [`i64`]`>`:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Diam-diam memotong `big_number`, perlu mendeteksi dan menangani pemotongan setelah kejadiannya.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Mengembalikan kesalahan karena `big_number` terlalu besar untuk muat dalam `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Mengembalikan `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Jenis yang dikembalikan jika terjadi kesalahan konversi.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Melakukan konversi.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// IMPL UMUM
////////////////////////////////////////////////////////////////////////////////

// Saat mengangkat&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Sebagai lift di atas &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): ganti impls di atas untuk&/&mut dengan yang lebih umum berikut ini:
// // Sebagai lift di atas Deref
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Sized> AsRef <U>untuk D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut mengangkat lebih dari &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): ganti impl di atas untuk &mut dengan yang lebih umum berikut ini:
// // AsMut mengangkat DerefMut
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Sized> AsMut <U>untuk D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Dari implisit Ke
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// Dari (dan dengan demikian Ke) bersifat refleksif
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Catatan stabilitas:** Implikasi ini belum ada, tetapi kami "reserving space" untuk menambahkannya di future.
/// Lihat [rust-lang/rust#64715][#64715] untuk detailnya.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): lakukan perbaikan yang berprinsip sebagai gantinya.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom menyiratkan TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Konversi sempurna secara semantik setara dengan konversi yang bisa salah dengan jenis kesalahan tak berpenghuni.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// IMPLS BETON
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// JENIS KESALAHAN NO-ERROR
////////////////////////////////////////////////////////////////////////////////

/// Jenis kesalahan untuk kesalahan yang tidak akan pernah terjadi.
///
/// Karena enum ini tidak memiliki varian, nilai jenis ini tidak akan pernah benar-benar ada.
/// Ini dapat berguna untuk API umum yang menggunakan [`Result`] dan membuat parameter jenis kesalahan, untuk menunjukkan bahwa hasilnya selalu [`Ok`].
///
/// Misalnya, [`TryFrom`] trait (konversi yang mengembalikan [`Result`]) memiliki implementasi menyeluruh untuk semua jenis yang memiliki implementasi [`Into`] terbalik.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Kompatibilitas Future
///
/// Enum ini memiliki peran yang sama dengan [the `!`“never”type][never], yang tidak stabil dalam versi Rust ini.
/// Saat `!` distabilkan, kami berencana menjadikan `Infallible` sebagai alias tipe untuk itu:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …Dan akhirnya menghentikan `Infallible`.
///
/// Namun ada satu kasus di mana sintaks `!` dapat digunakan sebelum `!` distabilkan sebagai tipe lengkap: dalam posisi tipe kembalian fungsi.
/// Secara khusus, ini memungkinkan implementasi untuk dua jenis penunjuk fungsi yang berbeda:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Dengan `Infallible` menjadi enum, kode ini valid.
/// Namun ketika `Infallible` menjadi alias untuk never type, kedua `impl`s akan mulai tumpang tindih dan oleh karena itu akan dilarang oleh aturan koherensi trait bahasa.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}