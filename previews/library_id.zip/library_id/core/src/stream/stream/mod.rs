use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Antarmuka untuk menangani iterator asinkron.
///
/// Ini adalah aliran utama trait.
/// Untuk mengetahui lebih lanjut tentang konsep streaming secara umum, silakan lihat [module-level documentation].
/// Secara khusus, Anda mungkin ingin tahu cara [implement `Stream`][impl].
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// Jenis barang yang dihasilkan oleh aliran.
    type Item;

    /// Mencoba menarik nilai berikutnya dari aliran ini, mendaftarkan tugas saat ini untuk bangun jika nilainya belum tersedia, dan mengembalikan `None` jika aliran habis.
    ///
    /// # Nilai kembali
    ///
    /// Ada beberapa kemungkinan nilai kembali, masing-masing menunjukkan status aliran yang berbeda:
    ///
    /// - `Poll::Pending` berarti nilai aliran ini selanjutnya belum siap.Implementasi akan memastikan bahwa tugas saat ini akan diberi tahu ketika nilai berikutnya mungkin sudah siap.
    ///
    /// - `Poll::Ready(Some(val))` berarti streaming berhasil menghasilkan nilai, `val`, dan dapat menghasilkan nilai lebih lanjut pada panggilan `poll_next` berikutnya.
    ///
    /// - `Poll::Ready(None)` berarti streaming telah dihentikan, dan `poll_next` tidak boleh dipanggil lagi.
    ///
    /// # Panics
    ///
    /// Setelah streaming selesai (mengembalikan `Ready(None)` from `poll_next`), memanggil metode `poll_next` lagi dapat panic, memblokir selamanya, atau menyebabkan jenis masalah lain; `Stream` trait tidak menempatkan persyaratan pada efek panggilan semacam itu.
    ///
    /// Namun, karena metode `poll_next` tidak ditandai `unsafe`, aturan umum Rust berlaku: panggilan tidak boleh menyebabkan perilaku yang tidak ditentukan (kerusakan memori, penggunaan fungsi `unsafe` yang salah, atau sejenisnya), terlepas dari status streaming.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Mengembalikan batas pada sisa panjang aliran.
    ///
    /// Secara khusus, `size_hint()` mengembalikan tupel di mana elemen pertama adalah batas bawah, dan elemen kedua adalah batas atas.
    ///
    /// Paruh kedua tupel yang dikembalikan adalah [`Option`]`<`[`usize`] `>`.
    /// [`None`] di sini berarti tidak ada batas atas yang diketahui, atau batas atas lebih besar dari [`usize`].
    ///
    /// # Catatan implementasi
    ///
    /// Tidak dipaksakan bahwa implementasi aliran menghasilkan jumlah elemen yang dideklarasikan.Aliran kereta dapat menghasilkan kurang dari batas bawah atau lebih dari batas atas elemen.
    ///
    /// `size_hint()` terutama dimaksudkan untuk digunakan untuk pengoptimalan seperti memesan ruang untuk elemen aliran, tetapi tidak boleh dipercaya, misalnya, menghilangkan pemeriksaan batas dalam kode yang tidak aman.
    /// Implementasi `size_hint()` yang salah seharusnya tidak menyebabkan pelanggaran keamanan memori.
    ///
    /// Oleh karena itu, penerapannya harus memberikan perkiraan yang benar, karena jika tidak maka akan melanggar protokol trait.
    ///
    /// Implementasi default mengembalikan `(0,` [`None`]`)`yang benar untuk streaming apa pun.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}