//! Iterasi asinkron yang dapat disusun.
//!
//! Jika futures adalah nilai asynchronous, maka stream adalah iterator asynchronous.
//! Jika Anda menemukan diri Anda dengan koleksi asinkron dari beberapa jenis, dan perlu melakukan operasi pada elemen koleksi tersebut, Anda akan segera menemukan 'streams'.
//! Aliran banyak digunakan dalam kode Rust asinkron idiomatik, jadi sebaiknya Anda memahaminya.
//!
//! Sebelum menjelaskan lebih lanjut, mari kita bahas tentang bagaimana modul ini disusun:
//!
//! # Organization
//!
//! Modul ini sebagian besar diatur berdasarkan jenis:
//!
//! * [Traits] adalah bagian intinya: traits ini menentukan jenis aliran yang ada dan apa yang dapat Anda lakukan dengannya.Metode traits ini layak digunakan untuk waktu belajar tambahan.
//! * Fungsi menyediakan beberapa cara berguna untuk membuat beberapa aliran dasar.
//! * Struktur sering kali merupakan jenis kembalian dari berbagai metode pada traits modul ini.Anda biasanya ingin melihat metode yang membuat `struct`, daripada `struct` itu sendiri.
//! Untuk detail selengkapnya tentang alasannya, lihat '[Menerapkan Aliran](#menerapkan-aliran)'.
//!
//! [Traits]: #traits
//!
//! Itu dia!Mari kita gali lebih dalam.
//!
//! # Stream
//!
//! Inti dan jiwa dari modul ini adalah [`Stream`] trait.Inti dari [`Stream`] terlihat seperti ini:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! Tidak seperti `Iterator`, `Stream` membuat perbedaan antara metode [`poll_next`] yang digunakan saat mengimplementasikan `Stream`, dan metode (to-be-implemented) `next` yang digunakan saat menggunakan streaming.
//!
//! Konsumen `Stream` hanya perlu mempertimbangkan `next`, yang ketika dipanggil, mengembalikan future yang menghasilkan `Option<Stream::Item>`.
//!
//! future yang dikembalikan oleh `next` akan menghasilkan `Some(Item)` selama masih ada elemen, dan setelah semuanya habis, akan menghasilkan `None` untuk menunjukkan bahwa iterasi telah selesai.
//! Jika kita menunggu sesuatu yang tidak sinkron untuk diselesaikan, future akan menunggu hingga streaming siap untuk menghasilkan lagi.
//!
//! Aliran individu dapat memilih untuk melanjutkan pengulangan, sehingga memanggil `next` lagi mungkin atau mungkin tidak pada akhirnya menghasilkan `Some(Item)` lagi di beberapa titik.
//!
//! Definisi lengkap [`Stream`] menyertakan sejumlah metode lain juga, tetapi mereka adalah metode default, dibangun di atas [`poll_next`], sehingga Anda mendapatkannya secara gratis.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Menerapkan Stream
//!
//! Membuat aliran Anda sendiri melibatkan dua langkah: membuat `struct` untuk menahan status aliran, dan kemudian menerapkan [`Stream`] untuk `struct` tersebut.
//!
//! Mari buat aliran bernama `Counter` yang dihitung dari `1` ke `5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Pertama, struct:
//!
//! /// Aliran yang menghitung dari satu sampai lima
//! struct Counter {
//!     count: usize,
//! }
//!
//! // kami ingin hitungan kami dimulai dari satu, jadi mari tambahkan metode new() untuk membantu.
//! // Ini tidak sepenuhnya diperlukan, tetapi nyaman.
//! // Perhatikan bahwa kita memulai `count` dari nol, kita akan melihat alasannya dalam implementasi `poll_next()`'s di bawah ini.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Kemudian, kami menerapkan `Stream` untuk `Counter` kami:
//!
//! impl Stream for Counter {
//!     // kami akan menghitung dengan menggunakan
//!     type Item = usize;
//!
//!     // poll_next() adalah satu-satunya metode yang diperlukan
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Tingkatkan hitungan kami.Inilah mengapa kami memulai dari nol.
//!         self.count += 1;
//!
//!         // Periksa apakah kita sudah selesai menghitung atau belum.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Stream *malas*.Ini berarti bahwa hanya membuat aliran tidak banyak _do_.Tidak ada yang benar-benar terjadi sampai Anda menelepon `next`.
//! Ini terkadang menjadi sumber kebingungan saat membuat aliran hanya karena efek sampingnya.
//! Kompilator akan memperingatkan kita tentang perilaku seperti ini:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;