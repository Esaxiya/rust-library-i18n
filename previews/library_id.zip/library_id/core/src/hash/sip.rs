//! Implementasi SipHash.

#![allow(deprecated)] // jenis dalam modul ini tidak digunakan lagi

use crate::cmp;
use crate::marker::PhantomData;
use crate::mem;
use crate::ptr;

/// Penerapan SipHash 1-3.
///
/// Saat ini fungsi hashing default yang digunakan oleh pustaka standar (misalnya, `collections::HashMap` menggunakannya secara default).
///
///
/// See: <https://131002.net/siphash>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
#[doc(hidden)]
pub struct SipHasher13 {
    hasher: Hasher<Sip13Rounds>,
}

/// Penerapan SipHash 2-4.
///
/// See: <https://131002.net/siphash/>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
struct SipHasher24 {
    hasher: Hasher<Sip24Rounds>,
}

/// Penerapan SipHash 2-4.
///
/// See: <https://131002.net/siphash/>
///
/// SipHash adalah fungsi hashing serba guna: ia berjalan dengan kecepatan yang baik (bersaing dengan Spooky dan City) dan memungkinkan hashing _keyed_ yang kuat.
///
/// Ini memungkinkan Anda memasukkan tabel hash Anda dari RNG yang kuat, seperti [`rand::os::OsRng`](https://doc.rust-lang.org/rand/rand/os/struct.OsRng.html).
///
/// Meskipun algoritma SipHash dianggap kuat secara umum, itu tidak dimaksudkan untuk tujuan kriptografi.
/// Dengan demikian, semua penggunaan kriptografi dari implementasi ini adalah _strongly discouraged_.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
pub struct SipHasher(SipHasher24);

#[derive(Debug)]
struct Hasher<S: Sip> {
    k0: u64,
    k1: u64,
    length: usize, // berapa banyak byte yang telah kami proses
    state: State,  // hash State
    tail: u64,     // file byte yang belum diproses
    ntail: usize,  // berapa banyak byte dalam ekor yang valid
    _marker: PhantomData<S>,
}

#[derive(Debug, Clone, Copy)]
#[repr(C)]
struct State {
    // v0, v2 dan v1, v3 muncul berpasangan dalam algoritme, dan implementasi simd dari SipHash akan menggunakan vectors dari v02 dan v13.
    //
    // Dengan menempatkannya dalam urutan ini di struct, compiler dapat mengambil hanya beberapa optimasi simd dengan sendirinya.
    //
    v0: u64,
    v2: u64,
    v1: u64,
    v3: u64,
}

macro_rules! compress {
    ($state:expr) => {{ compress!($state.v0, $state.v1, $state.v2, $state.v3) }};
    ($v0:expr, $v1:expr, $v2:expr, $v3:expr) => {{
        $v0 = $v0.wrapping_add($v1);
        $v1 = $v1.rotate_left(13);
        $v1 ^= $v0;
        $v0 = $v0.rotate_left(32);
        $v2 = $v2.wrapping_add($v3);
        $v3 = $v3.rotate_left(16);
        $v3 ^= $v2;
        $v0 = $v0.wrapping_add($v3);
        $v3 = $v3.rotate_left(21);
        $v3 ^= $v0;
        $v2 = $v2.wrapping_add($v1);
        $v1 = $v1.rotate_left(17);
        $v1 ^= $v2;
        $v2 = $v2.rotate_left(32);
    }};
}

/// Memuat integer jenis yang diinginkan dari aliran byte, dalam urutan LE.
/// Menggunakan `copy_nonoverlapping` agar kompilator menghasilkan cara paling efisien untuk memuatnya dari alamat yang mungkin tidak selaras.
///
///
/// Tidak aman karena: pengindeksan tidak dicentang di i..i+size_of(int_ty)
macro_rules! load_int_le {
    ($buf:expr, $i:expr, $int_ty:ident) => {{
        debug_assert!($i + mem::size_of::<$int_ty>() <= $buf.len());
        let mut data = 0 as $int_ty;
        ptr::copy_nonoverlapping(
            $buf.as_ptr().add($i),
            &mut data as *mut _ as *mut u8,
            mem::size_of::<$int_ty>(),
        );
        data.to_le()
    }};
}

/// Memuat u64 menggunakan hingga 7 byte potongan byte.
/// Kelihatannya kikuk tetapi panggilan `copy_nonoverlapping` yang terjadi (melalui `load_int_le!`) semuanya memiliki ukuran tetap dan menghindari panggilan `memcpy`, yang bagus untuk kecepatan.
///
///
/// Tidak aman karena: pengindeksan tidak dicentang di start..start + len
#[inline]
unsafe fn u8to64_le(buf: &[u8], start: usize, len: usize) -> u64 {
    debug_assert!(len < 8);
    let mut i = 0; // indeks byte saat ini (dari LSB) di output u64
    let mut out = 0;
    if i + 3 < len {
        // KEAMANAN: `i` tidak boleh lebih besar dari `len`, dan penelepon harus menjamin
        // bahwa indeks mulai..start + len berada dalam batas.
        out = unsafe { load_int_le!(buf, start + i, u32) } as u64;
        i += 4;
    }
    if i + 1 < len {
        // KEAMANAN: sama seperti di atas.
        out |= (unsafe { load_int_le!(buf, start + i, u16) } as u64) << (i * 8);
        i += 2
    }
    if i < len {
        // KEAMANAN: sama seperti di atas.
        out |= (unsafe { *buf.get_unchecked(start + i) } as u64) << (i * 8);
        i += 1;
    }
    debug_assert_eq!(i, len);
    out
}

impl SipHasher {
    /// Membuat `SipHasher` baru dengan dua kunci awal disetel ke 0.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher {
        SipHasher::new_with_keys(0, 0)
    }

    /// Membuat `SipHasher` yang tidak memiliki kunci yang disediakan.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher {
        SipHasher(SipHasher24 { hasher: Hasher::new_with_keys(key0, key1) })
    }
}

impl SipHasher13 {
    /// Membuat `SipHasher13` baru dengan dua kunci awal disetel ke 0.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher13 {
        SipHasher13::new_with_keys(0, 0)
    }

    /// Membuat `SipHasher13` yang tidak memiliki kunci yang disediakan.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher13 {
        SipHasher13 { hasher: Hasher::new_with_keys(key0, key1) }
    }
}

impl<S: Sip> Hasher<S> {
    #[inline]
    fn new_with_keys(key0: u64, key1: u64) -> Hasher<S> {
        let mut state = Hasher {
            k0: key0,
            k1: key1,
            length: 0,
            state: State { v0: 0, v1: 0, v2: 0, v3: 0 },
            tail: 0,
            ntail: 0,
            _marker: PhantomData,
        };
        state.reset();
        state
    }

    #[inline]
    fn reset(&mut self) {
        self.length = 0;
        self.state.v0 = self.k0 ^ 0x736f6d6570736575;
        self.state.v1 = self.k1 ^ 0x646f72616e646f6d;
        self.state.v2 = self.k0 ^ 0x6c7967656e657261;
        self.state.v3 = self.k1 ^ 0x7465646279746573;
        self.ntail = 0;
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl super::Hasher for SipHasher {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.0.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.0.hasher.finish()
    }
}

#[unstable(feature = "hashmap_internals", issue = "none")]
impl super::Hasher for SipHasher13 {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.hasher.finish()
    }
}

impl<S: Sip> super::Hasher for Hasher<S> {
    // Note: tidak ada metode hashing integer (`write_u *`, `write_i*`) yang ditentukan
    // untuk tipe ini.
    // Kita dapat menambahkannya, menyalin implementasi `short_write` di librustc_data_structures/sip128.rs, dan menambahkan metode `write_u *`/`write_i*` ke `SipHasher`, `SipHasher13`, dan `DefaultHasher`.
    //
    // Ini akan sangat mempercepat hashing integer oleh hashing tersebut, dengan biaya sedikit memperlambat kecepatan kompilasi pada beberapa tolok ukur.
    // Lihat #69152 untuk detailnya.
    //
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        let length = msg.len();
        self.length += length;

        let mut needed = 0;

        if self.ntail != 0 {
            needed = 8 - self.ntail;
            // KEAMANAN: `cmp::min(length, needed)` dijamin tidak akan melebihi `length`
            self.tail |= unsafe { u8to64_le(msg, 0, cmp::min(length, needed)) } << (8 * self.ntail);
            if length < needed {
                self.ntail += length;
                return;
            } else {
                self.state.v3 ^= self.tail;
                S::c_rounds(&mut self.state);
                self.state.v0 ^= self.tail;
                self.ntail = 0;
            }
        }

        // Ekor yang disangga sekarang dibilas, proses input baru.
        let len = length - needed;
        let left = len & 0x7; // len% 8

        let mut i = needed;
        while i < len - left {
            // SAFETY: karena `len - left` adalah kelipatan 8 under terbesar
            // `len`, dan karena `i` dimulai dari `needed` di mana `len` adalah `length - needed`, maka `i + 8` dijamin kurang dari atau sama dengan `length`.
            //
            let mi = unsafe { load_int_le!(msg, i, u64) };

            self.state.v3 ^= mi;
            S::c_rounds(&mut self.state);
            self.state.v0 ^= mi;

            i += 8;
        }

        // KEAMANAN: `i` sekarang menjadi `needed + len.div_euclid(8) * 8`,
        // jadi `i + left` = `needed + len` = `length`, yang menurut definisi sama dengan `msg.len()`.
        //
        self.tail = unsafe { u8to64_le(msg, i, left) };
        self.ntail = left;
    }

    #[inline]
    fn finish(&self) -> u64 {
        let mut state = self.state;

        let b: u64 = ((self.length as u64 & 0xff) << 56) | self.tail;

        state.v3 ^= b;
        S::c_rounds(&mut state);
        state.v0 ^= b;

        state.v2 ^= 0xff;
        S::d_rounds(&mut state);

        state.v0 ^ state.v1 ^ state.v2 ^ state.v3
    }
}

impl<S: Sip> Clone for Hasher<S> {
    #[inline]
    fn clone(&self) -> Hasher<S> {
        Hasher {
            k0: self.k0,
            k1: self.k1,
            length: self.length,
            state: self.state,
            tail: self.tail,
            ntail: self.ntail,
            _marker: self._marker,
        }
    }
}

impl<S: Sip> Default for Hasher<S> {
    /// Membuat `Hasher<S>` dengan dua kunci awal disetel ke 0.
    #[inline]
    fn default() -> Hasher<S> {
        Hasher::new_with_keys(0, 0)
    }
}

#[doc(hidden)]
trait Sip {
    fn c_rounds(_: &mut State);
    fn d_rounds(_: &mut State);
}

#[derive(Debug, Clone, Default)]
struct Sip13Rounds;

impl Sip for Sip13Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
    }
}

#[derive(Debug, Clone, Default)]
struct Sip24Rounds;

impl Sip for Sip24Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
        compress!(state);
    }
}