//! Fungsionalitas untuk pemesanan dan perbandingan.
//!
//! Modul ini berisi berbagai alat untuk mengurutkan dan membandingkan nilai.Singkatnya:
//!
//! * [`Eq`] dan [`PartialEq`] adalah traits yang memungkinkan Anda menentukan kesetaraan total dan parsial antar nilai.
//! Menerapkannya akan membebani operator `==` dan `!=`.
//! * [`Ord`] dan [`PartialOrd`] adalah traits yang memungkinkan Anda menentukan urutan total dan parsial di antara nilai, masing-masing.
//!
//! Menerapkannya akan membebani operator `<`, `<=`, `>`, dan `>=`.
//! * [`Ordering`] adalah enum yang dikembalikan oleh fungsi utama [`Ord`] dan [`PartialOrd`], dan menjelaskan pemesanan.
//! * [`Reverse`] adalah struct yang memungkinkan Anda membalikkan pemesanan dengan mudah.
//! * [`max`] dan [`min`] adalah fungsi yang dibangun dari [`Ord`] dan memungkinkan Anda menemukan nilai maksimum atau minimum.
//!
//! Untuk lebih jelasnya, lihat dokumentasi masing-masing item dalam daftar.
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// Trait untuk perbandingan kesetaraan yaitu [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation).
///
/// trait ini memungkinkan persamaan parsial, untuk tipe yang tidak memiliki hubungan ekivalen penuh.
/// Misalnya, dalam bilangan titik mengambang `NaN != NaN`, maka jenis titik mengambang menerapkan `PartialEq` tetapi tidak [`trait@Eq`].
///
/// Secara formal, persamaannya harus (untuk semua `a`, `b`, `c` jenis `A`, `B`, `C`):
///
/// - **Simetris**: jika `A: PartialEq<B>` dan `B: PartialEq<A>`, maka **`a==b` berarti`b==a`**;dan
///
/// - **Transitif**: jika `A: PartialEq<B>` dan `B: PartialEq<C>` dan `A:
///   PartialEq<C>`, maka **` a==b`dan `b == c` menyiratkan`a==c`**.
///
/// Perhatikan bahwa implik `B: PartialEq<A>` (symmetric) dan `A: PartialEq<C>` (transitive) tidak dipaksa untuk ada, tetapi persyaratan ini berlaku setiap kali ada.
///
/// ## Derivable
///
/// trait ini dapat digunakan dengan `#[derive]`.Saat `derive`d pada struct, dua contoh sama jika semua bidang sama, dan tidak sama jika ada bidang yang tidak sama.Jika `derive`d pada enum, setiap varian sama dengan dirinya sendiri dan tidak sama dengan varian lainnya.
///
/// ## Bagaimana cara menerapkan `PartialEq`?
///
/// `PartialEq` hanya membutuhkan metode [`eq`] untuk diimplementasikan;[`ne`] didefinisikan dalam istilah itu secara default.Setiap implementasi manual [`ne`]*harus* mematuhi aturan bahwa [`eq`] adalah invers ketat dari [`ne`];yaitu, `!(a == b)` jika dan hanya jika `a != b`.
///
/// Implementasi `PartialEq`, [`PartialOrd`], dan [`Ord`]*harus* sesuai satu sama lain.Sangat mudah untuk secara tidak sengaja membuat mereka tidak setuju dengan menggunakan beberapa traits dan menerapkan yang lain secara manual.
///
/// Contoh implementasi untuk domain di mana dua buku dianggap sebagai buku yang sama jika ISBN-nya cocok, meskipun formatnya berbeda:
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## Bagaimana cara membandingkan dua jenis yang berbeda?
///
/// Jenis yang dapat Anda bandingkan dikontrol oleh parameter jenis `PartialEq`.
/// Sebagai contoh, mari kita ubah sedikit kode kita sebelumnya:
///
/// ```
/// // Alat turunannya<BookFormat>==<BookFormat>perbandingan
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // Melaksanakan<Book>==<BookFormat>perbandingan
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // Melaksanakan<BookFormat>==<Book>perbandingan
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// Dengan mengubah `impl PartialEq for Book` menjadi `impl PartialEq<BookFormat> for Book`, kami mengizinkan `Format Buku` dibandingkan dengan`Buku`.
///
/// Perbandingan seperti di atas, yang mengabaikan beberapa bidang struct, bisa berbahaya.Ini dapat dengan mudah menyebabkan pelanggaran yang tidak disengaja terhadap persyaratan untuk hubungan kesetaraan parsial.
/// Misalnya, jika kita mempertahankan implementasi `PartialEq<Book>` di atas untuk `BookFormat` dan menambahkan implementasi `PartialEq<Book>` untuk `Book` (baik melalui `#[derive]` atau melalui implementasi manual dari contoh pertama) maka hasilnya akan melanggar transitivitas:
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// Metode ini menguji nilai `self` dan `other` agar sama, dan digunakan oleh `==`.
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// Metode ini menguji `!=`.
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// Turunkan makro yang menghasilkan impl dari trait `PartialEq`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// Trait untuk perbandingan kesetaraan yaitu [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation).
///
/// Artinya, selain `a == b` dan `a != b` adalah invers ketat, persamaannya harus (untuk semua `a`, `b`, dan `c`):
///
/// - reflexive: `a == a`;
/// - simetris: `a == b` berarti `b == a`;dan
/// - transitif: `a == b` dan `b == c` menyiratkan `a == c`.
///
/// Properti ini tidak dapat diperiksa oleh kompilator, dan oleh karena itu `Eq` menyiratkan [`PartialEq`], dan tidak memiliki metode tambahan.
///
/// ## Derivable
///
/// trait ini dapat digunakan dengan `#[derive]`.
/// Ketika `derive`d, karena `Eq` tidak memiliki metode tambahan, ini hanya memberi tahu kompiler bahwa ini adalah relasi ekivalen daripada relasi ekivalen parsial.
///
/// Perhatikan bahwa strategi `derive` mengharuskan semua bidang adalah `Eq`, yang tidak selalu diinginkan.
///
/// ## Bagaimana cara menerapkan `Eq`?
///
/// Jika Anda tidak dapat menggunakan strategi `derive`, tentukan bahwa jenis Anda mengimplementasikan `Eq`, yang tidak memiliki metode:
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // metode ini digunakan hanya oleh#[menurunkan] untuk menyatakan bahwa setiap komponen dari sebuah tipe mengimplementasikan#[menurunkan] itu sendiri, infrastruktur turunan saat ini berarti melakukan pernyataan ini tanpa menggunakan metode pada trait ini hampir tidak mungkin.
    //
    //
    // Ini tidak boleh diterapkan dengan tangan.
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// Turunkan makro yang menghasilkan impl dari trait `Eq`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: struct ini hanya digunakan oleh#[diturunkan] ke
// menegaskan bahwa setiap komponen dari tipe mengimplementasikan Persamaan.
//
// Struct ini tidak boleh muncul dalam kode pengguna.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// `Ordering` adalah hasil perbandingan antara dua nilai.
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// Urutan di mana nilai yang dibandingkan lebih kecil dari yang lain.
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// Urutan di mana nilai yang dibandingkan sama dengan yang lain.
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// Urutan di mana nilai yang dibandingkan lebih besar dari yang lain.
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// Mengembalikan `true` jika urutannya adalah varian `Equal`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// Mengembalikan `true` jika urutannya bukan varian `Equal`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// Mengembalikan `true` jika urutannya adalah varian `Less`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// Mengembalikan `true` jika urutannya adalah varian `Greater`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// Mengembalikan `true` jika urutannya adalah varian `Less` atau `Equal`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// Mengembalikan `true` jika urutannya adalah varian `Greater` atau `Equal`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// Membalikkan `Ordering`.
    ///
    /// * `Less` menjadi `Greater`.
    /// * `Greater` menjadi `Less`.
    /// * `Equal` menjadi `Equal`.
    ///
    /// # Examples
    ///
    /// Perilaku dasar:
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// Metode ini dapat digunakan untuk membalikkan perbandingan:
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // urutkan larik dari yang terbesar ke terkecil.
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// Rantai dua urutan.
    ///
    /// Mengembalikan `self` jika bukan `Equal`.Jika tidak mengembalikan `other`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// Merangkai urutan dengan fungsi yang diberikan.
    ///
    /// Mengembalikan `self` jika bukan `Equal`.
    /// Jika tidak, panggil `f` dan kembalikan hasilnya.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// Struct pembantu untuk pengurutan terbalik.
///
/// Struct ini adalah pembantu untuk digunakan dengan fungsi seperti [`Vec::sort_by_key`] dan dapat digunakan untuk membalik urutan bagian dari sebuah kunci.
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// Trait untuk tipe yang membentuk [total order](https://en.wikipedia.org/wiki/Total_order).
///
/// Pesanan adalah pesanan total jika (untuk semua `a`, `b` dan `c`):
///
/// - total dan asimetris: tepat satu dari `a < b`, `a == b`, atau `a > b` yang benar;dan
/// - transitif, `a < b` dan `b < c` menyiratkan `a < c`.Hal yang sama harus berlaku untuk `==` dan `>`.
///
/// ## Derivable
///
/// trait ini dapat digunakan dengan `#[derive]`.
/// Ketika `derive`d pada struct, itu akan menghasilkan pengurutan [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order) berdasarkan urutan deklarasi dari atas ke bawah dari anggota struct.
///
/// Saat `derive`d pada enum, varian diurutkan berdasarkan urutan diskriminan atas ke bawah.
///
/// ## Perbandingan leksikografis
///
/// Perbandingan leksikografis adalah operasi dengan properti berikut:
///  - Dua urutan dibandingkan elemen demi elemen.
///  - Elemen ketidakcocokan yang pertama mendefinisikan urutan mana yang secara leksikografis lebih kecil atau lebih besar dari yang lain.
///  - Jika satu urutan adalah awalan dari yang lain, urutan yang lebih pendek secara leksikografis lebih sedikit dari yang lain.
///  - Jika dua urutan memiliki elemen yang setara dan memiliki panjang yang sama, maka urutan tersebut secara leksikografis sama.
///  - Urutan kosong secara leksikografis lebih sedikit daripada urutan yang tidak kosong.
///  - Dua urutan kosong secara leksikografis sama.
///
/// ## Bagaimana cara menerapkan `Ord`?
///
/// `Ord` mengharuskan tipe juga menjadi [`PartialOrd`] dan [`Eq`] (yang membutuhkan [`PartialEq`]).
///
/// Kemudian Anda harus menentukan implementasi untuk [`cmp`].Anda mungkin merasa berguna untuk menggunakan [`cmp`] pada bidang tipe Anda.
///
/// Implementasi [`PartialEq`], [`PartialOrd`], dan `Ord`*harus* sesuai satu sama lain.
/// Yaitu, `a.cmp(b) == Ordering::Equal` jika dan hanya jika `a == b` dan `Some(a.cmp(b)) == a.partial_cmp(b)` untuk semua `a` dan `b`.
/// Sangat mudah untuk secara tidak sengaja membuat mereka tidak setuju dengan menggunakan beberapa traits dan menerapkan yang lain secara manual.
///
/// Berikut adalah contoh saat Anda ingin mengurutkan orang berdasarkan tinggi saja, dengan mengabaikan `id` dan `name`:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// Metode ini mengembalikan [`Ordering`] antara `self` dan `other`.
    ///
    /// Menurut konvensi, `self.cmp(&other)` mengembalikan urutan yang cocok dengan ekspresi `self <operator> other` jika true.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// Membandingkan dan mengembalikan maksimal dua nilai.
    ///
    /// Mengembalikan argumen kedua jika perbandingan menentukannya sama.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// Membandingkan dan mengembalikan minimal dua nilai.
    ///
    /// Mengembalikan argumen pertama jika perbandingan menentukannya sama.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// Batasi nilai untuk interval tertentu.
    ///
    /// Mengembalikan `max` jika `self` lebih besar dari `max`, dan `min` jika `self` lebih kecil dari `min`.
    /// Jika tidak, ini mengembalikan `self`.
    ///
    /// # Panics
    ///
    /// Panics jika `min > max`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// Turunkan makro yang menghasilkan impl dari trait `Ord`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// Trait untuk nilai yang dapat dibandingkan untuk urutan sortir.
///
/// Perbandingan harus memenuhi, untuk semua `a`, `b` dan `c`:
///
/// - asimetri: jika `a < b` lalu `!(a > b)`, serta `a > b` menyiratkan `!(a < b)`;dan
/// - transitivitas: `a < b` dan `b < c` menyiratkan `a < c`.Hal yang sama harus berlaku untuk `==` dan `>`.
///
/// Perhatikan bahwa persyaratan ini berarti bahwa trait itu sendiri harus diimplementasikan secara simetris dan transitif: jika `T: PartialOrd<U>` dan `U: PartialOrd<V>` maka `U: PartialOrd<T>` dan `T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// trait ini dapat digunakan dengan `#[derive]`.Ketika `derive`d pada struct, itu akan menghasilkan pengurutan leksikografik berdasarkan urutan deklarasi dari atas ke bawah dari anggota struct.
/// Saat `derive`d pada enum, varian diurutkan berdasarkan urutan diskriminan atas ke bawah.
///
/// ## Bagaimana cara menerapkan `PartialOrd`?
///
/// `PartialOrd` hanya membutuhkan implementasi metode [`partial_cmp`], dengan metode lain yang dihasilkan dari implementasi default.
///
/// Namun tetap mungkin untuk mengimplementasikan yang lain secara terpisah untuk tipe yang tidak memiliki urutan total.
/// Misalnya, untuk bilangan floating point, `NaN < 0 == false` dan `NaN >= 0 == false` (lih.
/// IEEE 754-2008 bagian 5.11).
///
/// `PartialOrd` mengharuskan tipe Anda menjadi [`PartialEq`].
///
/// Implementasi [`PartialEq`], `PartialOrd`, dan [`Ord`]*harus* sesuai satu sama lain.
/// Sangat mudah untuk secara tidak sengaja membuat mereka tidak setuju dengan menggunakan beberapa traits dan menerapkan yang lain secara manual.
///
/// Jika tipe Anda adalah [`Ord`], Anda dapat menerapkan [`partial_cmp`] dengan menggunakan [`cmp`]:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// Anda juga mungkin merasa berguna untuk menggunakan [`partial_cmp`] pada bidang tipe Anda.
/// Berikut adalah contoh tipe `Person` yang memiliki bidang `height` floating-point yang merupakan satu-satunya bidang yang akan digunakan untuk menyortir:
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// Metode ini mengembalikan urutan antara nilai `self` dan `other` jika ada.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// Jika perbandingan tidak memungkinkan:
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// Metode ini menguji kurang dari (untuk `self` dan `other`) dan digunakan oleh operator `<`.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// Metode ini menguji kurang dari atau sama dengan (untuk `self` dan `other`) dan digunakan oleh operator `<=`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// Metode ini menguji lebih besar dari (untuk `self` dan `other`) dan digunakan oleh operator `>`.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// Metode ini menguji lebih besar dari atau sama dengan (untuk `self` dan `other`) dan digunakan oleh operator `>=`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// Turunkan makro yang menghasilkan impl dari trait `PartialOrd`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// Membandingkan dan mengembalikan minimal dua nilai.
///
/// Mengembalikan argumen pertama jika perbandingan menentukannya sama.
///
/// Secara internal menggunakan alias ke [`Ord::min`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// Mengembalikan minimal dua nilai yang terkait dengan fungsi perbandingan yang ditentukan.
///
/// Mengembalikan argumen pertama jika perbandingan menentukannya sama.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// Mengembalikan elemen yang memberikan nilai minimum dari fungsi yang ditentukan.
///
/// Mengembalikan argumen pertama jika perbandingan menentukannya sama.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// Membandingkan dan mengembalikan maksimal dua nilai.
///
/// Mengembalikan argumen kedua jika perbandingan menentukannya sama.
///
/// Secara internal menggunakan alias ke [`Ord::max`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// Mengembalikan maksimal dua nilai yang terkait dengan fungsi perbandingan yang ditentukan.
///
/// Mengembalikan argumen kedua jika perbandingan menentukannya sama.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// Mengembalikan elemen yang memberikan nilai maksimum dari fungsi yang ditentukan.
///
/// Mengembalikan argumen kedua jika perbandingan menentukannya sama.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// Implementasi PartialEq, Eq, PartialOrd dan Ord untuk tipe primitif
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // Urutan di sini penting untuk menghasilkan perakitan yang lebih optimal.
                    // Lihat <https://github.com/rust-lang/rust/issues/63758> untuk info lebih lanjut.
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // Mentransmisikan ke i8 dan mengubah perbedaan menjadi Pengurutan menghasilkan perakitan yang lebih optimal.
            //
            // Lihat <https://github.com/rust-lang/rust/issues/66780> untuk info lebih lanjut.
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // KEAMANAN: bool karena i8 mengembalikan 0 atau 1, jadi perbedaannya tidak bisa apa-apa
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // &petunjuk

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}