macro_rules! int_impl {
    ($SelfT:ty, $ActualT:ident, $UnsignedT:ty, $BITS:expr, $Min:expr, $Max:expr,
     $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
     $reversed:expr, $le_bytes:expr, $be_bytes:expr,
     $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// Nilai terkecil yang dapat diwakili oleh tipe bilangan bulat ini.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, ", stringify!($Min), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = !0 ^ ((!0 as $UnsignedT) >> 1) as Self;

        /// Nilai terbesar yang dapat diwakili oleh tipe bilangan bulat ini.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($Max), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !Self::MIN;

        /// Ukuran tipe integer ini dalam bit.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Mengonversi potongan string dalam basis tertentu menjadi bilangan bulat.
        ///
        /// String tersebut diharapkan menjadi tanda `+` atau `-` opsional yang diikuti dengan digit.
        /// Spasi kosong di depan dan di belakang menunjukkan kesalahan.
        /// Digit adalah bagian dari karakter ini, bergantung pada `radix`:
        ///
        ///  * `0-9`
        ///  * `a-z`
        ///  * `A-Z`
        ///
        /// # Panics
        ///
        /// Fungsi ini panics jika `radix` tidak dalam kisaran 2 hingga 36.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// Menampilkan bilangan satuan dalam representasi biner `self`.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        #[doc = concat!("let n = 0b100_0000", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 1);
        ///
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 { (self as $UnsignedT).count_ones() }

        /// Mengembalikan jumlah nol dalam representasi biner `self`.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// Menampilkan jumlah nol di depan dalam representasi biner `self`.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]
        /// assert_eq!(n.leading_zeros(), 0);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            (self as $UnsignedT).leading_zeros()
        }

        /// Menampilkan jumlah nol di belakang dalam representasi biner `self`.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        #[doc = concat!("let n = -4", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            (self as $UnsignedT).trailing_zeros()
        }

        /// Mengembalikan jumlah awalan dalam representasi biner `self`.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]

        #[doc = concat!("assert_eq!(n.leading_ones(), ", stringify!($BITS), ");")]
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (self as $UnsignedT).leading_ones()
        }

        /// Mengembalikan jumlah yang tertinggal dalam representasi biner `self`.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        #[doc = concat!("let n = 3", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (self as $UnsignedT).trailing_ones()
        }

        /// Menggeser bit ke kiri dengan jumlah tertentu, `n`, membungkus bit yang terpotong ke akhir bilangan bulat yang dihasilkan.
        ///
        ///
        /// Harap dicatat bahwa ini bukan operasi yang sama dengan operator pemindah `<<`!
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_left(n) as Self
        }

        /// Menggeser bit ke kanan dengan jumlah tertentu, `n`, membungkus bit yang terpotong ke awal bilangan bulat yang dihasilkan.
        ///
        ///
        /// Harap dicatat bahwa ini bukan operasi yang sama dengan operator pemindah `>>`!
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_right(n) as Self
        }

        /// Membalik urutan byte dari bilangan bulat.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// misalkan m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            (self as $UnsignedT).swap_bytes() as Self
        }

        /// Membalik urutan bit dalam bilangan bulat.
        /// Bit paling signifikan kedua menjadi bit paling signifikan, bit paling signifikan kedua menjadi bit paling signifikan kedua, dll.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// misalkan m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            (self as $UnsignedT).reverse_bits() as Self
        }

        /// Mengonversi bilangan bulat dari big endian menjadi endian target.
        ///
        /// Pada big endian ini adalah no-op.Di little endian, byte ditukar.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// jika cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } lain {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Mengonversi bilangan bulat dari little endian menjadi ketangguhan target.
        ///
        /// Di little endian, ini tidak boleh dilakukan.Pada big endian, byte ditukar.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// jika cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } lain {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// Mengubah `self` menjadi big endian dari ketangguhan target.
        ///
        /// Pada big endian ini adalah no-op.Di little endian, byte ditukar.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// jika cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } lain { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // atau tidak?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// Mengubah `self` menjadi little endian dari ketangguhan target.
        ///
        /// Di little endian, ini tidak boleh dilakukan.Pada big endian, byte ditukar.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// jika cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } lain { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Penambahan bilangan bulat yang diperiksa.
        /// Menghitung `self + rhs`, mengembalikan `None` jika terjadi overflow.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), Some(", stringify!($SelfT), "::MAX - 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Penambahan bilangan bulat tidak dicentang.Menghitung `self + rhs`, dengan asumsi overflow tidak dapat terjadi.
        /// Ini menghasilkan perilaku tidak terdefinisi saat
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // KEAMANAN: penelepon harus memegang kontrak keamanan untuk `unchecked_add`.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Pengurangan integer diperiksa.
        /// Menghitung `self - rhs`, mengembalikan `None` jika terjadi overflow.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(1), Some(", stringify!($SelfT), "::MIN + 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Pengurangan integer tidak dicentang.Menghitung `self - rhs`, dengan asumsi overflow tidak dapat terjadi.
        /// Ini menghasilkan perilaku tidak terdefinisi saat
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // KEAMANAN: penelepon harus memegang kontrak keamanan untuk `unchecked_sub`.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Perkalian bilangan bulat diperiksa.
        /// Menghitung `self * rhs`, mengembalikan `None` jika terjadi overflow.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(1), Some(", stringify!($SelfT), "::MAX));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Perkalian bilangan bulat tidak dicentang.Menghitung `self * rhs`, dengan asumsi overflow tidak dapat terjadi.
        /// Ini menghasilkan perilaku tidak terdefinisi saat
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // KEAMANAN: penelepon harus memegang kontrak keamanan untuk `unchecked_mul`.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Divisi integer diperiksa.
        /// Menghitung `self / rhs`, mengembalikan `None` jika `rhs == 0` atau pembagian menghasilkan luapan.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // SAFETY: div dengan nol dan oleh INT_MIN telah diperiksa di atas
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Memeriksa divisi Euclidean.
        /// Menghitung `self.div_euclid(rhs)`, mengembalikan `None` jika `rhs == 0` atau pembagian menghasilkan luapan.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div_euclid(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div_euclid(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }

        /// Memeriksa sisa bilangan bulat.
        /// Menghitung `self % rhs`, mengembalikan `None` jika `rhs == 0` atau pembagian menghasilkan luapan.
        ///
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem(-1), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // SAFETY: div dengan nol dan oleh INT_MIN telah diperiksa di atas
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Memeriksa sisa Euclidean.
        /// Menghitung `self.rem_euclid(rhs)`, mengembalikan `None` jika `rhs == 0` atau pembagian menghasilkan luapan.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem_euclid(-1), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Negasi diperiksa.
        /// Menghitung `-self`, mengembalikan `None` jika `self == MIN`.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_neg(), Some(-5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Memeriksa shift kiri.
        /// Menghitung `self << rhs`, mengembalikan `None` jika `rhs` lebih besar dari atau sama dengan jumlah bit di `self`.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Memeriksa shift kanan.
        /// Menghitung `self >> rhs`, mengembalikan `None` jika `rhs` lebih besar dari atau sama dengan jumlah bit di `self`.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(128), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Nilai absolut yang diperiksa.
        /// Menghitung `self.abs()`, mengembalikan `None` jika `self == MIN`.
        ///
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-5", stringify!($SelfT), ").checked_abs(), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_abs(), None);")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_abs(self) -> Option<Self> {
            if self.is_negative() {
                self.checked_neg()
            } else {
                Some(self)
            }
        }

        /// Eksponensial yang diperiksa.
        /// Menghitung `self.pow(exp)`, mengembalikan `None` jika terjadi overflow.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(8", stringify!($SelfT), ".checked_pow(2), Some(64));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```

        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }
            // karena exp!=0, akhirnya exp harus 1.
            // Tangani bit terakhir eksponen secara terpisah, karena mengkuadratkan basis setelahnya tidak diperlukan dan dapat menyebabkan luapan yang tidak perlu.
            //
            //
            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Penjumlahan bilangan bulat jenuh.
        /// Menghitung `self + rhs`, memenuhi batas numerik, bukan meluap.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(100), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_add(-1), ", stringify!($SelfT), "::MIN);")]
        /// ```

        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Pengurangan bilangan bulat jenuh.
        /// Menghitung `self - rhs`, memenuhi batas numerik, bukan meluap.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(127), -27);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_sub(100), ", stringify!($SelfT), "::MIN);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_sub(-1), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Negasi bilangan bulat jenuh.
        /// Menghitung `-self`, mengembalikan `MAX` jika `self == MIN` bukannya meluap.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_neg(), -100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_neg(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_neg(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_neg(), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_neg(self) -> Self {
            intrinsics::saturating_sub(0, self)
        }

        /// Nilai absolut jenuh.
        /// Menghitung `self.abs()`, mengembalikan `MAX` jika `self == MIN` bukannya meluap.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_abs(self) -> Self {
            if self.is_negative() {
                self.saturating_neg()
            } else {
                self
            }
        }

        /// Perkalian bilangan bulat jenuh.
        /// Menghitung `self * rhs`, memenuhi batas numerik, bukan meluap.
        ///
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".saturating_mul(12), 120);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_mul(10), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_mul(10), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => if (self < 0) == (rhs < 0) {
                    Self::MAX
                } else {
                    Self::MIN
                }
            }
        }

        /// Eksponen bilangan bulat jenuh.
        /// Menghitung `self.pow(exp)`, memenuhi batas numerik, bukan meluap.
        ///
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-4", stringify!($SelfT), ").saturating_pow(3), -64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(3), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None if self < 0 && exp % 2 == 1 => Self::MIN,
                None => Self::MAX,
            }
        }

        /// Membungkus tambahan (modular).
        /// Menghitung `self + rhs`, membungkus di sekitar batas tipe.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_add(27), 127);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_add(2), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// Membungkus pengurangan (modular).
        /// Menghitung `self - rhs`, membungkus di sekitar batas tipe.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".wrapping_sub(127), -127);")]
        #[doc = concat!("assert_eq!((-2", stringify!($SelfT), ").wrapping_sub(", stringify!($SelfT), "::MAX), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// Pembungkus perkalian (modular).
        /// Menghitung `self * rhs`, membungkus di sekitar batas tipe.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".wrapping_mul(12), 120);")]
        /// assert_eq!(11i8.wrapping_mul(12), -124);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// Membungkus divisi (modular).Menghitung `self / rhs`, membungkus di sekitar batas tipe.
        ///
        /// Satu-satunya kasus di mana pembungkusan seperti itu dapat terjadi adalah ketika seseorang membagi `MIN / -1` pada jenis yang ditandatangani (di mana `MIN` adalah nilai minimal negatif untuk jenis tersebut);ini setara dengan `-MIN`, nilai positif yang terlalu besar untuk diwakili dalam jenisnya.
        /// Dalam kasus seperti itu, fungsi ini mengembalikan `MIN` itu sendiri.
        ///
        /// # Panics
        ///
        /// Fungsi ini akan panic jika `rhs` adalah 0.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div(-1), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self.overflowing_div(rhs).0
        }

        /// Membungkus divisi Euclidean.
        /// Menghitung `self.div_euclid(rhs)`, membungkus di sekitar batas tipe.
        ///
        /// Pembungkusan hanya akan terjadi di `MIN / -1` pada jenis bertanda (di mana `MIN` adalah nilai minimal negatif untuk jenis tersebut).
        /// Ini setara dengan `-MIN`, nilai positif yang terlalu besar untuk diwakili dalam jenisnya.
        /// Dalam kasus ini, metode ini mengembalikan `MIN` itu sendiri.
        ///
        /// # Panics
        ///
        /// Fungsi ini akan panic jika `rhs` adalah 0.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div_euclid(-1), -128);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self.overflowing_div_euclid(rhs).0
        }

        /// Membungkus sisa (modular).Menghitung `self % rhs`, membungkus di sekitar batas tipe.
        ///
        /// Pembungkusan seperti itu tidak pernah benar-benar terjadi secara matematis;artefak implementasi membuat `x % y` tidak valid untuk `MIN / -1` pada jenis yang ditandatangani (di mana `MIN` adalah nilai minimal negatif).
        ///
        /// Dalam kasus seperti itu, fungsi ini mengembalikan `0`.
        ///
        /// # Panics
        ///
        /// Fungsi ini akan panic jika `rhs` adalah 0.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem(-1), 0);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self.overflowing_rem(rhs).0
        }

        /// Membungkus sisa Euclidean.Menghitung `self.rem_euclid(rhs)`, membungkus di sekitar batas tipe.
        ///
        /// Pembungkusan hanya akan terjadi di `MIN % -1` pada jenis bertanda (di mana `MIN` adalah nilai minimal negatif untuk jenis tersebut).
        /// Dalam kasus ini, metode ini mengembalikan 0.
        ///
        /// # Panics
        ///
        /// Fungsi ini akan panic jika `rhs` adalah 0.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem_euclid(-1), 0);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self.overflowing_rem_euclid(rhs).0
        }

        /// Membungkus negasi (modular).Menghitung `-self`, membungkus di sekitar batas tipe.
        ///
        /// Satu-satunya kasus di mana pembungkusan seperti itu dapat terjadi adalah ketika seseorang meniadakan `MIN` pada jenis yang ditandatangani (di mana `MIN` adalah nilai minimal negatif untuk jenis tersebut);ini adalah nilai positif yang terlalu besar untuk diwakili dalam jenisnya.
        /// Dalam kasus seperti itu, fungsi ini mengembalikan `MIN` itu sendiri.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_neg(), -100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_neg(), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic-free bitwise shift-left;menghasilkan `self << mask(rhs)`, di mana `mask` menghapus bit orde tinggi apa pun dari `rhs` yang akan menyebabkan pergeseran melebihi bitwidth jenis tersebut.
        ///
        /// Perhatikan bahwa ini *tidak* sama dengan rotate-left;RHS dari pembungkus shift-left dibatasi pada kisaran tipe, daripada bit yang digeser keluar dari LHS yang dikembalikan ke ujung yang lain.
        ///
        /// Semua tipe integer primitif mengimplementasikan fungsi [`rotate_left`](Self::rotate_left), yang mungkin Anda inginkan.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(7), -128);")]
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(128), -1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // SAFETY: penyamaran dengan ukuran bit memastikan bahwa kita tidak bergeser
            // di luar batas
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic-free bitwise shift-right;menghasilkan `self >> mask(rhs)`, di mana `mask` menghapus bit orde tinggi apa pun dari `rhs` yang akan menyebabkan pergeseran melebihi bitwidth jenis tersebut.
        ///
        /// Perhatikan bahwa ini *tidak* sama dengan rotate-right;RHS shift-right pembungkus dibatasi pada kisaran tipe, daripada bit yang digeser keluar dari LHS dikembalikan ke ujung yang lain.
        ///
        /// Semua tipe integer primitif mengimplementasikan fungsi [`rotate_right`](Self::rotate_right), yang mungkin Anda inginkan.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-128", stringify!($SelfT), ").wrapping_shr(7), -1);")]
        /// assert_eq!((-128i16).wrapping_shr(64), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // SAFETY: penyamaran dengan ukuran bit memastikan bahwa kita tidak bergeser
            // di luar batas
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Membungkus nilai absolut (modular).Menghitung `self.abs()`, membungkus di sekitar batas tipe.
        ///
        /// Satu-satunya kasus di mana pembungkusan seperti itu dapat terjadi adalah ketika seseorang mengambil nilai absolut dari nilai minimal negatif untuk jenisnya;ini adalah nilai positif yang terlalu besar untuk diwakili dalam jenisnya.
        /// Dalam kasus seperti itu, fungsi ini mengembalikan `MIN` itu sendiri.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_abs(), ", stringify!($SelfT), "::MIN);")]
        /// assert_eq!((-128i8).wrapping_abs() as u8, 128);
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        pub const fn wrapping_abs(self) -> Self {
             if self.is_negative() {
                 self.wrapping_neg()
             } else {
                 self
             }
        }

        /// Menghitung nilai absolut `self` tanpa membungkus atau panik.
        ///
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        /// assert_eq!((-128i8).unsigned_abs(), 128u8);
        /// ```
        #[stable(feature = "unsigned_abs", since = "1.51.0")]
        #[rustc_const_stable(feature = "unsigned_abs", since = "1.51.0")]
        #[inline]
        pub const fn unsigned_abs(self) -> $UnsignedT {
             self.wrapping_abs() as $UnsignedT
        }

        /// Membungkus eksponensial (modular).
        /// Menghitung `self.pow(exp)`, membungkus di sekitar batas tipe.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(4), 81);")]
        /// assert_eq!(3i8.wrapping_pow(5), -13);
        /// assert_eq!(3i8.wrapping_pow(6), -39);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // karena exp!=0, akhirnya exp harus 1.
            // Tangani bit terakhir eksponen secara terpisah, karena mengkuadratkan basis setelahnya tidak diperlukan dan dapat menyebabkan luapan yang tidak perlu.
            //
            //
            acc.wrapping_mul(base)
        }

        /// Menghitung `self` + `rhs`
        ///
        /// Mengembalikan tupel penjumlahan bersama dengan boolean yang menunjukkan apakah luapan aritmetika akan terjadi.
        /// Jika luapan akan terjadi maka nilai yang dibungkus dikembalikan.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Menghitung `self`, `rhs`
        ///
        /// Mengembalikan tupel pengurangan bersama dengan boolean yang menunjukkan apakah luapan aritmetika akan terjadi.
        /// Jika luapan akan terjadi maka nilai yang dibungkus dikembalikan.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Menghitung perkalian `self` dan `rhs`.
        ///
        /// Mengembalikan tupel perkalian bersama dengan boolean yang menunjukkan apakah luapan aritmetika akan terjadi.
        /// Jika luapan akan terjadi maka nilai yang dibungkus dikembalikan.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_mul(2), (10, false));")]
        /// assert_eq!(1_000_000_000i32.overflowing_mul(10), (1410065408, benar));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Menghitung pembagi ketika `self` dibagi dengan `rhs`.
        ///
        /// Mengembalikan tupel pembagi bersama dengan boolean yang menunjukkan apakah luapan aritmetika akan terjadi.
        /// Jika luapan akan terjadi maka diri dikembalikan.
        ///
        /// # Panics
        ///
        /// Fungsi ini akan panic jika `rhs` adalah 0.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self / rhs, false)
            }
        }

        /// Menghitung hasil bagi dari divisi Euclidean `self.div_euclid(rhs)`.
        ///
        /// Mengembalikan tupel pembagi bersama dengan boolean yang menunjukkan apakah luapan aritmetika akan terjadi.
        /// Jika overflow akan terjadi maka `self` dikembalikan.
        ///
        /// # Panics
        ///
        /// Fungsi ini akan panic jika `rhs` adalah 0.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div_euclid(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self.div_euclid(rhs), false)
            }
        }

        /// Menghitung sisanya saat `self` dibagi dengan `rhs`.
        ///
        /// Mengembalikan tupel sisa setelah membagi bersama dengan boolean yang menunjukkan apakah luapan aritmetika akan terjadi.
        /// Jika luapan akan terjadi maka 0 dikembalikan.
        ///
        /// # Panics
        ///
        /// Fungsi ini akan panic jika `rhs` adalah 0.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem(-1), (0, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self % rhs, false)
            }
        }


        /// Sisa Euclidean meluap.Menghitung `self.rem_euclid(rhs)`.
        ///
        /// Mengembalikan tupel sisa setelah membagi bersama dengan boolean yang menunjukkan apakah luapan aritmetika akan terjadi.
        /// Jika luapan akan terjadi maka 0 dikembalikan.
        ///
        /// # Panics
        ///
        /// Fungsi ini akan panic jika `rhs` adalah 0.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem_euclid(-1), (0, true));")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self.rem_euclid(rhs), false)
            }
        }


        /// Meniadakan diri sendiri, meluap jika ini sama dengan nilai minimum.
        ///
        /// Menampilkan tupel dari versi self yang dinegasikan bersama dengan boolean yang menunjukkan apakah terjadi overflow.
        /// Jika `self` adalah nilai minimum (mis., `i32::MIN` untuk nilai tipe `i32`), maka nilai minimum akan dikembalikan lagi dan `true` akan dikembalikan jika terjadi overflow.
        ///
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_neg(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            if unlikely!(self == Self::MIN) {
                (Self::MIN, true)
            } else {
                (-self, false)
            }
        }

        /// Menggeser diri sendiri yang ditinggalkan oleh `rhs` bit.
        ///
        /// Menampilkan tupel dari versi diri yang digeser bersama dengan boolean yang menunjukkan apakah nilai pergeseran lebih besar dari atau sama dengan jumlah bit.
        /// Jika nilai pergeseran terlalu besar, maka nilai (N-1) ditutup dengan N adalah jumlah bit, dan nilai ini kemudian digunakan untuk melakukan pergeseran.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT),".overflowing_shl(4), (0x10, false));")]
        /// assert_eq!(0x1i32.overflowing_shl(36), (0x10, benar));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// Menggeser diri sendiri dengan bit `rhs`.
        ///
        /// Menampilkan tupel dari versi diri yang digeser bersama dengan boolean yang menunjukkan apakah nilai pergeseran lebih besar dari atau sama dengan jumlah bit.
        /// Jika nilai pergeseran terlalu besar, maka nilai (N-1) ditutup dengan N adalah jumlah bit, dan nilai ini kemudian digunakan untuk melakukan pergeseran.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        /// assert_eq!(0x10i32.overflowing_shr(36), (0x1, benar));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// Menghitung nilai absolut `self`.
        ///
        /// Menampilkan tupel dari versi absolut diri bersama dengan boolean yang menunjukkan apakah terjadi luapan.
        /// Jika diri adalah nilai minimum
        #[doc = concat!("(e.g., ", stringify!($SelfT), "::MIN for values of type ", stringify!($SelfT), "),")]
        /// maka nilai minimum akan dikembalikan lagi dan true akan dikembalikan untuk terjadinya overflow.
        ///
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN).overflowing_abs(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn overflowing_abs(self) -> (Self, bool) {
            (self.wrapping_abs(), self == Self::MIN)
        }

        /// Meningkatkan diri ke pangkat `exp`, menggunakan eksponensiasi dengan mengkuadratkan.
        ///
        /// Mengembalikan tupel eksponen bersama dengan bool yang menunjukkan apakah terjadi luapan.
        ///
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(4), (81, false));")]
        /// assert_eq!(3i8.overflowing_pow(5), (-13, benar));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0 {
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Gores ruang untuk menyimpan hasil overflowing_mul.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // karena exp!=0, akhirnya exp harus 1.
            // Tangani bit terakhir eksponen secara terpisah, karena mengkuadratkan basis setelahnya tidak diperlukan dan dapat menyebabkan luapan yang tidak perlu.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;
            r
        }

        /// Meningkatkan diri ke pangkat `exp`, menggunakan eksponensiasi dengan mengkuadratkan.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        #[doc = concat!("let x: ", stringify!($SelfT), " = 2; // or any other integer type")]
        /// assert_eq!(x.pow(5), 32);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // karena exp!=0, akhirnya exp harus 1.
            // Tangani bit terakhir eksponen secara terpisah, karena mengkuadratkan basis setelahnya tidak diperlukan dan dapat menyebabkan luapan yang tidak perlu.
            //
            //
            acc * base
        }

        /// Menghitung hasil bagi dari divisi Euclidean `self` dengan `rhs`.
        ///
        /// Ini menghitung bilangan bulat `n` sehingga `self = n * rhs + self.rem_euclid(rhs)`, dengan `0 <= self.rem_euclid(rhs) < rhs`.
        ///
        ///
        /// Dengan kata lain, hasilnya `self / rhs` dibulatkan ke bilangan bulat `n` sehingga `self >= n * rhs`.
        /// Jika `self > 0`, ini sama dengan pembulatan menuju nol (default di Rust);
        /// jika `self < 0`, ini sama dengan pembulatan menuju +/-tak terhingga.
        ///
        /// # Panics
        ///
        /// Fungsi ini akan panic jika `rhs` adalah 0 atau pembagian menghasilkan overflow.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// misalkan b=4;
        ///
        /// assert_eq!(a.div_euclid(b), 1); //7>=4 *1 assert_eq!(a.div_euclid(-b), -1);//7>= -4*-1 assert_eq!((-a).div_euclid(b), -2);//-7>=4 *-2 assert_eq!((-a).div_euclid(-b), 2);//-7>= -4* 2
        ///
        /// ```
        ///
        ///
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            let q = self / rhs;
            if self % rhs < 0 {
                return if rhs > 0 { q - 1 } else { q + 1 }
            }
            q
        }


        /// Menghitung sisa tak negatif terkecil dari `self (mod rhs)`.
        ///
        /// Ini dilakukan seolah-olah oleh algoritma pembagian Euclidean-diberikan `r = self.rem_euclid(rhs)`, `self = rhs * self.div_euclid(rhs) + r`, dan `0 <= r < abs(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Fungsi ini akan panic jika `rhs` adalah 0 atau pembagian menghasilkan overflow.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// misalkan b=4;
        ///
        /// assert_eq!(a.rem_euclid(b), 3);
        /// assert_eq!((-a).rem_euclid(b), 1);
        /// assert_eq!(a.rem_euclid(-b), 3);
        /// assert_eq!((-a).rem_euclid(-b), 1);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            let r = self % rhs;
            if r < 0 {
                if rhs < 0 {
                    r - rhs
                } else {
                    r + rhs
                }
            } else {
                r
            }
        }

        /// Menghitung nilai absolut `self`.
        ///
        /// # Perilaku meluap
        ///
        /// Nilai absolut
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// tidak dapat direpresentasikan sebagai
        #[doc = concat!("`", stringify!($SelfT), "`,")]
        /// dan mencoba menghitungnya akan menyebabkan luapan.
        /// Ini berarti kode dalam mode debug akan memicu panic pada kasus ini dan kode yang dioptimalkan akan kembali
        ///
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// tanpa panic.
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".abs(), 10);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").abs(), 10);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn abs(self) -> Self {
            // Perhatikan bahwa#[sebaris] di atas berarti bahwa semantik luapan pengurangan bergantung pada crate tempat kita sedang disebariskan.
            //
            //
            if self.is_negative() {
                -self
            } else {
                self
            }
        }

        /// Mengembalikan angka yang mewakili tanda `self`.
        ///
        ///  - `0` jika angkanya nol
        ///  - `1` jika angkanya positif
        ///  - `-1` jika angkanya negatif
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".signum(), 1);")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".signum(), 0);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").signum(), -1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_sign", since = "1.47.0")]
        #[inline]
        pub const fn signum(self) -> Self {
            match self {
                n if n > 0 =>  1,
                0          =>  0,
                _          => -1,
            }
        }

        /// Mengembalikan `true` jika `self` positif dan `false` jika angkanya nol atau negatif.
        ///
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        #[doc = concat!("assert!(10", stringify!($SelfT), ".is_positive());")]
        #[doc = concat!("assert!(!(-10", stringify!($SelfT), ").is_positive());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_positive(self) -> bool { self > 0 }

        /// Mengembalikan `true` jika `self` negatif dan `false` jika angkanya nol atau positif.
        ///
        ///
        /// # Examples
        ///
        /// Penggunaan dasar:
        ///
        /// ```
        #[doc = concat!("assert!((-10", stringify!($SelfT), ").is_negative());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_negative());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_negative(self) -> bool { self < 0 }

        /// Kembalikan representasi memori dari bilangan bulat ini sebagai larik byte dalam urutan byte (network) big-endian.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Kembalikan representasi memori dari bilangan bulat ini sebagai larik byte dalam urutan byte little-endian.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Kembalikan representasi memori dari bilangan bulat ini sebagai larik byte dalam urutan byte asli.
        ///
        /// Karena ketangguhan asli platform target digunakan, kode portabel harus menggunakan [`to_be_bytes`] atau [`to_le_bytes`], jika sesuai.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     byte, jika cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } lain {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SAFETY: suara const karena integer adalah tipe data lama yang biasa sehingga kami selalu bisa
        // mentransmutasikannya menjadi array byte
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // KEAMANAN: integer adalah tipe data lama sehingga kami selalu dapat mengubahnya menjadi
            // array byte
            unsafe { mem::transmute(self) }
        }

        /// Kembalikan representasi memori dari bilangan bulat ini sebagai larik byte dalam urutan byte asli.
        ///
        ///
        /// [`to_ne_bytes`] harus lebih disukai daripada ini bila memungkinkan.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// biarkan byte= num.as_ne_bytes();
        /// assert_eq!(
        ///     byte, jika cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } lain {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // KEAMANAN: integer adalah tipe data lama sehingga kami selalu dapat mengubahnya menjadi
            // array byte
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Buat nilai integer dari representasinya sebagai byte array di big endian.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// gunakan std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * masukan=istirahat;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Buat nilai integer dari representasi sebagai array byte di little endian.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// gunakan std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * masukan=istirahat;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Buat nilai integer dari representasi memorinya sebagai array byte dalam native endianness.
        ///
        /// Karena ketangguhan asli platform target digunakan, kode portabel kemungkinan besar ingin menggunakan [`from_be_bytes`] atau [`from_le_bytes`], sebagaimana mestinya.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes)]
        /// } lain {
        #[doc = concat!("    ", $le_bytes)]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// gunakan std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * masukan=istirahat;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SAFETY: suara const karena integer adalah tipe data lama yang biasa sehingga kami selalu bisa
        // transmutasi ke mereka
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // KEAMANAN: integer adalah tipe data lama sehingga kami selalu dapat mengubahnya
            unsafe { mem::transmute(bytes) }
        }

        /// Kode baru harus lebih suka digunakan
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Mengembalikan nilai terkecil yang dapat diwakili oleh jenis bilangan bulat ini.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_min_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self {
            Self::MIN
        }

        /// Kode baru harus lebih suka digunakan
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Mengembalikan nilai terbesar yang dapat diwakili oleh jenis bilangan bulat ini.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self {
            Self::MAX
        }
    }
}