//! Adaptasi Rust dari algoritme Grisu3 yang dijelaskan dalam "Mencetak Angka Titik Mengambang dengan Cepat dan Akurat dengan Integer" [^ 1].
//! Ini menggunakan sekitar 1KB tabel yang telah dihitung sebelumnya, dan pada gilirannya, ini sangat cepat untuk sebagian besar input.
//!
//! [^1]: Florian Loitsch.2010. Mencetak angka floating-point dengan cepat dan
//!   akurat dengan bilangan bulat.SIGPLAN Tidak.45, 6 (Juni 2010), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// lihat komentar di `format_shortest_opt` untuk alasannya.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-i;e=4* i, 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f, e, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// Diberikan `x > 0`, mengembalikan `(k, 10^k)` sedemikian rupa sehingga `10^k <= x < 10^(k+1)`.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// Implementasi mode terpendek untuk Grisu.
///
/// Ia mengembalikan `None` ketika ia akan mengembalikan representasi yang tidak tepat sebaliknya.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // kita membutuhkan setidaknya tiga bit ketelitian tambahan

    // mulai dengan nilai yang dinormalisasi dengan eksponen bersama
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // temukan `cached = 10^minusk` seperti `ALPHA <= minusk + plus.e + 64 <= GAMMA`.
    // karena `plus` dinormalisasi, ini berarti `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`;
    // mengingat pilihan kami `ALPHA` dan `GAMMA`, ini menempatkan `plus * cached` ke `[4, 2^32)`.
    //
    // jelas diinginkan untuk memaksimalkan `GAMMA - ALPHA`, sehingga kami tidak memerlukan banyak kekuatan cache dari 10, tetapi ada beberapa pertimbangan:
    //
    //
    // 1. kami ingin mempertahankan `floor(plus * cached)` dalam `u32` karena memerlukan pembagian yang mahal.
    //    (ini sebenarnya tidak dapat dihindari, sisa diperlukan untuk estimasi akurasi.)
    // 2.
    // sisa `floor(plus * cached)` berulang kali dikalikan 10, dan seharusnya tidak meluap.
    //
    // yang pertama memberikan `64 + GAMMA <= 32`, sedangkan yang kedua memberikan `10 * 2^-ALPHA <= 2^64`;
    // -60 dan -32 adalah kisaran maksimal dengan batasan ini, dan V8 juga menggunakannya.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // skala fps.ini memberikan kesalahan maksimal 1 ulp (dibuktikan dari Teorema 5.1).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-kisaran minus aktual
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // di atas `minus`, `v` dan `plus` adalah perkiraan *terkuantisasi*(error <1 ulp).
    // karena kami tidak tahu kesalahannya positif atau negatif, kami menggunakan dua perkiraan yang berjarak sama dan memiliki kesalahan maksimal 2 ulps.
    //
    // "unsafe region" adalah interval liberal yang awalnya kami hasilkan.
    // "safe region" adalah interval konservatif yang hanya kami terima.
    // kami mulai dengan repr yang benar dalam wilayah yang tidak aman, dan mencoba untuk menemukan repr terdekat ke `v` yang juga berada dalam wilayah aman.
    // jika kita tidak bisa, kita menyerah.
    //
    let plus1 = plus.f + 1;
    // biarkan plus0 = plus.f, 1;//hanya untuk penjelasan biarkan minus0 = minus.f + 1;//hanya untuk penjelasan
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // eksponen bersama

    // bagi `plus1` menjadi bagian integral dan pecahan.
    // bagian integral dijamin sesuai dengan u32, karena daya cache menjamin `plus < 2^32` dan `plus.f` yang dinormalisasi selalu kurang dari `2^64 - 2^4` karena persyaratan presisi.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // hitung `10^max_kappa` terbesar tidak lebih dari `plus1` (jadi `plus1 < 10^(max_kappa+1)`).
    // ini adalah batas atas `kappa` di bawah.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // Teorema 6.2: jika `k` adalah bilangan bulat terbesar st
    // `0 <= y mod 10^k <= y - x`,              maka `V = floor(y / 10^k) * 10^k` ada di `[x, y]` dan salah satu representasi terpendek (dengan jumlah angka signifikan minimal) dalam rentang itu.
    //
    //
    // temukan panjang digit `kappa` antara `(minus1, plus1)` sesuai Teorema 6.2.
    // Teorema 6.2 dapat digunakan untuk mengecualikan `x` dengan menggunakan `y mod 10^k < y - x` sebagai gantinya.
    // (mis., `x` =32000, `y` =32777; `kappa` =2 karena `y mod 10 ^ 3=777 <y, x=777`.) algoritme bergantung pada fase verifikasi selanjutnya untuk mengecualikan `y`.
    //
    let delta1 = plus1 - minus1;
    // biarkan delta1int=(delta1>> e) sebagai usize;//hanya untuk penjelasan
    let delta1frac = delta1 & ((1 << e) - 1);

    // membuat bagian yang tidak terpisahkan, sambil memeriksa keakuratan di setiap langkah.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // digit belum diberikan
    loop {
        // kami selalu memiliki setidaknya satu digit untuk dirender, karena invarian `plus1 >= 10^kappa`:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (itu berarti `remainder = plus1int % 10^(kappa+1)`)
        //
        //

        // bagi `remainder` dengan `10^kappa`.keduanya diskalakan oleh `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; kami telah menemukan `kappa` yang benar.
            let ten_kappa = (ten_kappa as u64) << e; // skala 10 ^ kappa kembali ke eksponen bersama
            return round_and_weed(
                // SAFETY: kami menginisialisasi memori itu di atas.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // putus loop ketika kita telah membuat semua digit integral.
        // jumlah digit yang tepat adalah `max_kappa + 1` sebagai `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // memulihkan invarian
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // membuat bagian pecahan, sambil memeriksa keakuratan di setiap langkah.
    // kali ini kita mengandalkan perkalian berulang, karena pembagian akan kehilangan presisi.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // digit berikutnya harus signifikan seperti yang telah kita uji sebelum memecah invarian, di mana `m = max_kappa + 1` (#digit di bagian integral):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // tidak akan meluap, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // bagi `remainder` dengan `10^kappa`.
        // keduanya diskalakan oleh `2^e / 10^kappa`, jadi yang terakhir tersirat di sini.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // pembagi implisit
            return round_and_weed(
                // SAFETY: kami menginisialisasi memori itu di atas.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // memulihkan invarian
        kappa -= 1;
        remainder = r;
    }

    // kami telah menghasilkan semua digit signifikan `plus1`, tetapi tidak yakin apakah itu yang optimal.
    // misalnya, jika `minus1` adalah 3.14153 ... dan `plus1` adalah 3.14158 ..., ada 5 representasi terpendek yang berbeda dari 3.14154 ke 3.14158 tetapi kami hanya memiliki yang terbesar.
    // kita harus menurunkan digit terakhir secara berturut-turut dan memeriksa apakah ini adalah repr yang optimal.
    // ada paling banyak 9 kandidat (..1 hingga ..9), jadi ini cukup cepat.(Fase "rounding")
    //
    // fungsi ini memeriksa apakah repr "optimal" ini benar-benar dalam rentang ulp, dan juga, ada kemungkinan bahwa repr "second-to-optimal" sebenarnya bisa optimal karena kesalahan pembulatan.
    // dalam kedua kasus ini mengembalikan `None`.
    // (Fase "weeding")
    //
    // semua argumen di sini diskalakan oleh nilai umum (tetapi implisit) `k`, sehingga:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (dan juga, `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (dan juga, `threshold > plus1v` dari invarian sebelumnya)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // menghasilkan dua pendekatan untuk `v` (sebenarnya `plus1 - v`) dalam ulps 1.5.
        // representasi yang dihasilkan harus merupakan representasi yang paling dekat dengan keduanya.
        //
        // di sini `plus1 - v` digunakan karena kalkulasi dilakukan sehubungan dengan `plus1` untuk menghindari overflow/underflow (oleh karena itu nama yang tampaknya ditukar).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1 ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ulp)

        // kurangi digit terakhir dan berhenti di representasi terdekat ke `v + 1 ulp`.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // kami bekerja dengan angka perkiraan `w(n)`, yang awalnya sama dengan `plus1 - plus1 % 10^kappa`.setelah menjalankan tubuh loop `n` kali, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // kami menetapkan `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` (dengan demikian `sisa= plus1w(0)`) untuk menyederhanakan pemeriksaan.
            // perhatikan bahwa `plus1w(n)` selalu meningkat.
            //
            // kami memiliki tiga kondisi untuk dihentikan.salah satu dari mereka akan membuat loop tidak dapat melanjutkan, tetapi kami kemudian memiliki setidaknya satu representasi valid yang diketahui paling dekat dengan `v + 1 ulp`.
            // kami akan menandainya sebagai TC1 hingga TC3 agar singkatnya.
            //
            // TC1: `w(n) <= v + 1 ulp`, yaitu, ini adalah repr terakhir yang paling mendekati.
            // ini setara dengan `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up`.
            // dikombinasikan dengan TC2 (yang memeriksa apakah `w(n+1)` is valid), ini mencegah kemungkinan overflow pada kalkulasi `plus1w(n)`.
            //
            // TC2: `w(n+1) < minus1`, repr berikutnya pasti tidak bulat ke `v`.
            // ini setara dengan `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold`.
            // sisi kiri dapat meluap, tetapi kita tahu `threshold > plus1v`, jadi jika TC1 salah, `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` dan kita dapat menguji dengan aman jika `threshold - plus1w(n) < 10^kappa` sebagai gantinya.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, yaitu repr berikutnya adalah
            // tidak lebih dekat ke `v + 1 ulp` dari repr saat ini.
            // diberikan `z(n) = plus1v_up - plus1w(n)`, ini menjadi `abs(z(n)) <= abs(z(n+1))`.sekali lagi dengan asumsi bahwa TC1 salah, kami memiliki `z(n) > 0`.kami memiliki dua kasus untuk dipertimbangkan:
            //
            // - saat `z(n+1) >= 0`: TC3 menjadi `z(n) <= z(n+1)`.
            // karena `plus1w(n)` meningkat, `z(n)` seharusnya menurun dan ini jelas salah.
            // - ketika `z(n+1) < 0`:
            //   - TC3a: prasyaratnya adalah `plus1v_up < plus1w(n) + 10^kappa`.dengan asumsi TC2 salah, `threshold >= plus1w(n) + 10^kappa` jadi tidak bisa overflow.
            //   - TC3b: TC3 menjadi `z(n) <= -z(n+1)`, yaitu `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   TC1 yang dinegasikan memberikan `plus1v_up > plus1w(n)`, sehingga tidak bisa overflow atau underflow saat digabungkan dengan TC3a.
            //
            // akibatnya, kita harus berhenti saat `TC1 || TC2 || (TC3a && TC3b)`.berikut ini sama dengan kebalikannya, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // repr terpendek tidak bisa diakhiri dengan `0`
                plus1w += ten_kappa;
            }
        }

        // periksa apakah representasi ini juga merupakan representasi yang paling dekat dengan `v - 1 ulp`.
        //
        // ini sama dengan kondisi pengakhiran untuk `v + 1 ulp`, dengan semua `plus1v_up` digantikan oleh `plus1v_down` sebagai gantinya.
        // analisis luapan sama-sama berlaku.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // sekarang kami memiliki representasi yang paling dekat dengan `v` antara `plus1` dan `minus1`.
        // ini terlalu liberal, jadi kami menolak `w(n)` apa pun yang tidak antara `plus0` dan `minus0`, yaitu `plus1 - plus1w(n) <= minus0` atau `plus1 - plus1w(n) >= plus0`.
        // kami memanfaatkan fakta bahwa `threshold = plus1 - minus1` dan `plus1 - plus0 = minus0 - minus1 = 2 ulp`.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// Implementasi mode terpendek untuk Grisu dengan fallback Naga.
///
/// Ini harus digunakan untuk banyak kasus.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // KEAMANAN: Pemeriksa pinjaman tidak cukup pintar untuk membiarkan kami menggunakan `buf`
    // di branch kedua, jadi kami mencuci seumur hidup di sini.
    // Tetapi kami hanya menggunakan kembali `buf` jika `format_shortest_opt` mengembalikan `None` jadi tidak apa-apa.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// Implementasi mode yang tepat dan tetap untuk Grisu.
///
/// Ia mengembalikan `None` ketika ia akan mengembalikan representasi yang tidak tepat sebaliknya.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // kita membutuhkan setidaknya tiga bit ketelitian tambahan
    assert!(!buf.is_empty());

    // menormalkan dan menskalakan `v`.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // bagi `v` menjadi bagian integral dan pecahan.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // baik `v` lama dan `v` baru (diskalakan dengan `10^-k`) memiliki kesalahan <1 ulp (Teorema 5.1).
    // karena kami tidak tahu kesalahannya positif atau negatif, kami menggunakan dua pendekatan yang berjarak sama dan memiliki kesalahan maksimal 2 ulps (sama untuk kasus terpendek).
    //
    //
    // tujuannya adalah untuk menemukan rangkaian angka yang dibulatkan persis yang sama untuk `v - 1 ulp` dan `v + 1 ulp`, sehingga kami yakin secara maksimal.
    // jika ini tidak memungkinkan, kami tidak tahu mana yang merupakan output yang benar untuk `v`, jadi kami menyerah dan mundur.
    //
    // `err` didefinisikan sebagai `1 ulp * 2^e` di sini (sama dengan ulp di `vfrac`), dan kami akan menskalakannya setiap kali `v` diskalakan.
    //
    //
    //
    let mut err = 1;

    // hitung `10^max_kappa` terbesar tidak lebih dari `v` (jadi `v < 10^(max_kappa+1)`).
    // ini adalah batas atas `kappa` di bawah.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // jika kita bekerja dengan batasan digit terakhir, kita perlu mempersingkat buffer sebelum rendering sebenarnya untuk menghindari pembulatan ganda.
    //
    // perhatikan bahwa kita harus memperbesar buffer lagi ketika pembulatan terjadi!
    let len = if exp <= limit {
        // Ups, kami bahkan tidak dapat menghasilkan *satu* digit.
        // ini dimungkinkan jika, katakanlah, kita memiliki sesuatu seperti 9.5 dan dibulatkan menjadi 10.
        //
        // pada prinsipnya kita dapat segera memanggil `possibly_round` dengan buffer kosong, tetapi penskalaan `max_ten_kappa << e` sebesar 10 dapat mengakibatkan overflow.
        //
        // sehingga kita menjadi ceroboh di sini dan memperlebar rentang kesalahan dengan faktor 10.
        // ini akan meningkatkan rasio negatif palsu, tetapi hanya sangat,*sangat* sedikit;
        // itu hanya akan menjadi masalah jika mantissa lebih besar dari 60 bit.
        //
        // SAFETY: `len=0`, jadi kewajiban menginisialisasi memori ini sepele.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // membuat bagian yang tidak terpisahkan.
    // kesalahannya sepenuhnya pecahan, jadi kita tidak perlu memeriksanya di bagian ini.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // digit belum diberikan
    loop {
        // kami selalu memiliki setidaknya satu digit untuk membuat invarian:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (itu berarti `remainder = vint % 10^(kappa+1)`)
        //
        //

        // bagi `remainder` dengan `10^kappa`.keduanya diskalakan oleh `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // apakah buffer sudah penuh?jalankan operan pembulatan dengan sisanya.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ kappa) * 2 ^ e
            // KEAMANAN: kami telah menginisialisasi `len` banyak byte.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // putus loop ketika kita telah membuat semua digit integral.
        // jumlah digit yang tepat adalah `max_kappa + 1` sebagai `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // memulihkan invarian
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // membuat bagian pecahan.
    //
    // pada prinsipnya kita dapat melanjutkan ke digit terakhir yang tersedia dan memeriksa keakuratannya.
    // sayangnya kami bekerja dengan bilangan bulat berukuran terbatas, jadi kami memerlukan beberapa kriteria untuk mendeteksi luapan.
    // V8 menggunakan `remainder > err`, yang menjadi salah jika angka signifikan `i` pertama dari `v - 1 ulp` dan `v` berbeda.
    // namun ini menolak terlalu banyak masukan yang valid.
    //
    // karena fase selanjutnya memiliki deteksi luapan yang benar, sebagai gantinya kami menggunakan kriteria yang lebih ketat:
    // kami melanjutkan hingga `err` melebihi `10^kappa / 2`, sehingga kisaran antara `v - 1 ulp` dan `v + 1 ulp` pasti berisi dua atau lebih representasi bulat.
    //
    // ini sama dengan dua perbandingan pertama dari `possibly_round`, untuk referensi.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // invarian, di mana `m = max_kappa + 1` (#digit di bagian integral):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // tidak akan meluap, `2^e * 10 < 2^64`
        err *= 10; // tidak akan meluap, `err * 10 < 2^e * 5 < 2^64`

        // bagi `remainder` dengan `10^kappa`.
        // keduanya diskalakan oleh `2^e / 10^kappa`, jadi yang terakhir tersirat di sini.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // apakah buffer sudah penuh?jalankan operan pembulatan dengan sisanya.
        if i == len {
            // KEAMANAN: kami telah menginisialisasi `len` banyak byte.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // memulihkan invarian
        remainder = r;
    }

    // perhitungan selanjutnya tidak ada gunanya (`possibly_round` pasti gagal), jadi kita menyerah.
    return None;

    // kami telah membuat semua digit `v` yang diminta, yang juga harus sama dengan digit `v - 1 ulp` yang sesuai.
    // sekarang kami memeriksa apakah ada representasi unik yang dimiliki oleh `v - 1 ulp` dan `v + 1 ulp`;ini bisa sama dengan digit yang dihasilkan, atau versi pembulatan dari digit tersebut.
    //
    // jika rentang berisi beberapa representasi dengan panjang yang sama, kita tidak dapat memastikan dan harus mengembalikan `None` sebagai gantinya.
    //
    // semua argumen di sini diskalakan oleh nilai umum (tetapi implisit) `k`, sehingga:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // KEAMANAN: `len` byte pertama dari `buf` harus diinisialisasi.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (untuk referensi, garis putus-putus menunjukkan nilai yang tepat untuk kemungkinan representasi dalam jumlah digit tertentu.)
        //
        //
        // kesalahan terlalu besar sehingga setidaknya ada tiga kemungkinan representasi antara `v - 1 ulp` dan `v + 1 ulp`.
        // kita tidak bisa menentukan mana yang benar.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // pada kenyataannya, 1/2 ulp cukup untuk memperkenalkan dua kemungkinan representasi.
        // (ingat bahwa kita memerlukan representasi unik untuk `v - 1 ulp` dan `v + 1 ulp`.) ini tidak akan meluap, karena `ulp < ten_kappa` dari pemeriksaan pertama.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ kappa-- -------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // jika `v + 1 ulp` lebih dekat dengan representasi dibulatkan ke bawah (yang sudah ada di `buf`), maka kita dapat kembali dengan aman.
        // perhatikan bahwa `v - 1 ulp`*bisa* lebih kecil dari representasi saat ini, tetapi sebagai `1 ulp < 10^kappa / 2`, ketentuan ini sudah cukup:
        // jarak antara `v - 1 ulp` dan representasi saat ini tidak dapat melebihi `10^kappa / 2`.
        //
        // kondisi sama dengan `remainder + ulp < 10^kappa / 2`.
        // karena ini dapat dengan mudah meluap, periksa dulu apakah `remainder < 10^kappa / 2`.
        // kami telah memverifikasi bahwa `ulp < 10^kappa / 2`, jadi selama `10^kappa` tidak meluap sama sekali, pemeriksaan kedua baik-baik saja.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // KEAMANAN: penelepon kami menginisialisasi memori itu.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------sisanya------> |:
        //   :                          |   :
        //   : <---------10 ^ kappa-- ------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // di sisi lain, jika `v - 1 ulp` lebih dekat ke representasi pembulatan, kita harus membulatkan dan mengembalikan.
        // untuk alasan yang sama kami tidak perlu memeriksa `v + 1 ulp`.
        //
        // kondisi sama dengan `remainder - ulp >= 10^kappa / 2`.
        // sekali lagi kita periksa dulu apakah `remainder > ulp` (perhatikan bahwa ini bukan `remainder >= ulp`, karena `10^kappa` tidak pernah nol).
        //
        // juga perhatikan bahwa `remainder - ulp <= 10^kappa`, sehingga pemeriksaan kedua tidak meluap.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // KEAMANAN: penelepon kami pasti telah menginisialisasi memori itu.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // hanya menambahkan satu digit tambahan jika kami telah meminta presisi tetap.
                // kita juga perlu memeriksa bahwa, jika buffer asli kosong, digit tambahan hanya dapat ditambahkan ketika `exp == limit` (case edge).
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // KEAMANAN: kami dan penelepon kami menginisialisasi memori itu.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // jika tidak kita akan dikutuk (yaitu, beberapa nilai antara `v - 1 ulp` dan `v + 1 ulp` dibulatkan ke bawah dan yang lainnya dibulatkan ke atas) dan menyerah.
        //
        None
    }
}

/// Implementasi mode yang tepat dan tetap untuk Grisu dengan fallback Naga.
///
/// Ini harus digunakan untuk banyak kasus.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // KEAMANAN: Pemeriksa pinjaman tidak cukup pintar untuk membiarkan kami menggunakan `buf`
    // di branch kedua, jadi kami mencuci seumur hidup di sini.
    // Tetapi kami hanya menggunakan kembali `buf` jika `format_exact_opt` mengembalikan `None` jadi tidak apa-apa.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}