//! Hampir langsung (tapi sedikit dioptimalkan) terjemahan Rust dari Gambar 3 dari "Mencetak Angka Floating-Point dengan Cepat dan Akurat" [^ 1].
//!
//!
//! [^1]: Burger, RG dan Dybvig, RK 1996. Mencetak bilangan floating-point
//!   dengan cepat dan akurat.SIGPLAN Tidak.31, 5 (Mei 1996), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// array yang telah dihitung sebelumnya dari `Digit`s untuk 10 ^ (2 ^ n)
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// hanya dapat digunakan saat `x < 16 * scale`;`scaleN` harus `scale.mul_small(N)`
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// Implementasi mode terpendek untuk Dragon.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // angka `v` untuk memformat dikenal sebagai:
    // - sama dengan `mant * 2^exp`;
    // - didahului oleh `(mant - 2 *minus)* 2^exp` pada tipe aslinya;dan
    // - diikuti oleh `(mant + 2 *plus)* 2^exp` pada tipe aslinya.
    //
    // jelas, `minus` dan `plus` tidak boleh nol.(untuk tak terbatas, kami menggunakan nilai di luar rentang.) juga kami berasumsi bahwa setidaknya satu digit dihasilkan, yaitu, `mant` juga tidak boleh nol.
    //
    // ini juga berarti bahwa angka apa pun antara `low = (mant - minus)*2^exp` dan `high = (mant + plus)* 2^exp` akan dipetakan ke angka floating point yang tepat ini, dengan menyertakan batas saat mantissa asli genap (yaitu, `!mant_was_odd`).
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` adalah `if d.inclusive {a <= b} else {a < b}`
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // perkirakan `k_0` dari input asli yang memenuhi `10^(k_0-1) < high <= 10^(k_0+1)`.
    // ikatan ketat `k` memuaskan `10^(k-1) < high <= 10^k` dihitung kemudian.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // mengubah `{mant, plus, minus} * 2^exp` menjadi bentuk pecahan sehingga:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // bagi `mant` dengan `10^k`.sekarang `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // memperbaiki ketika `mant + plus > scale` (atau `>=`).
    // kita sebenarnya tidak memodifikasi `scale`, karena kita bisa melewati perkalian awal.
    // sekarang `scale < mant + plus <= scale * 10` dan kami siap untuk menghasilkan angka.
    //
    // perhatikan bahwa `d[0]`*bisa* menjadi nol, saat `scale - plus < mant < scale`.
    // dalam hal ini kondisi pembulatan (`up` di bawah) akan segera dipicu.
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // setara dengan penskalaan `scale` sebesar 10
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // cache `(2, 4, 8) * scale` untuk pembuatan digit.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // invarian, di mana `d[0..n-1]` adalah digit yang dihasilkan sejauh ini:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (jadi `mant / scale < 10`) di mana `d[i..j]` adalah singkatan dari `d [i] * 10 ^ (ji) + ...
        // + d [j-1] * 10 + d[j]`.

        // menghasilkan satu digit: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // ini adalah deskripsi sederhana dari algoritma Naga yang dimodifikasi.
        // banyak derivasi perantara dan argumen kelengkapan dihilangkan untuk kenyamanan.
        //
        // mulai dengan invarian yang dimodifikasi, seperti yang telah kami perbarui `n`:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // asumsikan bahwa `d[0..n-1]` adalah representasi terpendek antara `low` dan `high`, yaitu, `d[0..n-1]` memenuhi kedua hal berikut tetapi `d[0..n-2]` tidak:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (bijectivity: digit dibulatkan ke `v`);dan
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (digit terakhir benar).
        //
        // kondisi kedua disederhanakan menjadi `2 * mant <= scale`.
        // menyelesaikan invarian dalam hal `mant`, `low` dan `high` menghasilkan versi yang lebih sederhana dari kondisi pertama: `-plus < mant < minus`.
        // sejak `-plus < 0 <= mant`, kami memiliki representasi terpendek yang benar saat `mant < minus` dan `2 * mant <= scale`.
        // (yang pertama menjadi `mant <= minus` jika mantissa asli genap.)
        //
        // ketika yang kedua tidak berlaku (`2 * mant> scale`), kita perlu menambah digit terakhir.
        // ini cukup untuk memulihkan kondisi itu: kita sudah tahu bahwa pembuatan digit menjamin `0 <= v / 10^(k-n) - d[0..n-1] < 1`.
        // dalam hal ini, kondisi pertama menjadi `-plus < mant - scale < minus`.
        // sejak `mant < scale` setelah generasi, kami memiliki `scale < mant + plus`.
        // (sekali lagi, ini menjadi `scale <= mant + plus` jika mantissa asli genap.)
        //
        // pendeknya:
        // - berhenti dan bulat `down` (pertahankan angka sebagaimana adanya) saat `mant < minus` (atau `<=`).
        // - berhenti dan putaran `up` (tingkatkan digit terakhir) saat `scale < mant + plus` (atau `<=`).
        // - tetap menghasilkan sebaliknya.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // kami memiliki representasi terpendek, lanjutkan ke pembulatan

        // memulihkan invarian.
        // ini membuat algoritme selalu berhenti: `minus` dan `plus` selalu meningkat, tetapi `mant` terpotong modulo `scale` dan `scale` diperbaiki.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // pembulatan terjadi jika i) hanya ketentuan pembulatan yang dipicu, atau ii) kedua ketentuan dipicu dan pemutusan hubungan kerja lebih memilih pembulatan.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // jika pembulatan mengubah panjangnya, eksponen juga harus berubah.
        // Tampaknya kondisi ini sangat sulit untuk dipenuhi (mungkin tidak mungkin), tetapi kami hanya bersikap aman dan konsisten di sini.
        //
        // SAFETY: kami menginisialisasi memori itu di atas.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // SAFETY: kami menginisialisasi memori itu di atas.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// Implementasi mode yang tepat dan tetap untuk Naga.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // perkirakan `k_0` dari input asli yang memenuhi `10^(k_0-1) < v <= 10^(k_0+1)`.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // bagi `mant` dengan `10^k`.sekarang `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // memperbaiki saat `mant + plus >= scale`, di mana `plus / scale = 10^-buf.len() / 2`.
    // untuk menjaga bignum berukuran tetap, kami menggunakan `mant + floor(plus) >= scale`.
    // kita sebenarnya tidak memodifikasi `scale`, karena kita bisa melewati perkalian awal.
    // sekali lagi dengan algoritme terpendek, `d[0]` bisa menjadi nol tetapi pada akhirnya akan dibulatkan.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // setara dengan penskalaan `scale` sebesar 10
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // jika kita bekerja dengan batasan digit terakhir, kita perlu mempersingkat buffer sebelum rendering sebenarnya untuk menghindari pembulatan ganda.
    //
    // perhatikan bahwa kita harus memperbesar buffer lagi ketika pembulatan terjadi!
    let mut len = if k < limit {
        // Ups, kami bahkan tidak dapat menghasilkan *satu* digit.
        // ini dimungkinkan jika, katakanlah, kita memiliki sesuatu seperti 9.5 dan dibulatkan menjadi 10.
        // kami mengembalikan buffer kosong, dengan pengecualian kasus pembulatan kemudian yang terjadi ketika `k == limit` dan harus menghasilkan tepat satu digit.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // cache `(2, 4, 8) * scale` untuk pembuatan digit.
        // (ini bisa mahal, jadi jangan menghitungnya saat buffer kosong.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // digit berikut semuanya nol, kami berhenti di sini jangan *jangan* mencoba melakukan pembulatan!alih-alih, isi digit yang tersisa.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // SAFETY: kami menginisialisasi memori itu di atas.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // pembulatan jika kita berhenti di tengah digit jika digit berikutnya tepat 5000 ..., periksa digit sebelumnya dan coba untuk membulatkan ke genap (yaitu, hindari pembulatan ketika digit sebelumnya genap).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // KEAMANAN: `buf[len-1]` diinisialisasi.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // jika pembulatan mengubah panjangnya, eksponen juga harus berubah.
        // tetapi kami telah diminta sejumlah digit tetap, jadi jangan ubah buffer ...
        // SAFETY: kami menginisialisasi memori itu di atas.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... kecuali kami telah diminta sebagai gantinya.
            // kita juga perlu memeriksa bahwa, jika buffer asli kosong, digit tambahan hanya dapat ditambahkan ketika `k == limit` (case edge).
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // SAFETY: kami menginisialisasi memori itu di atas.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}