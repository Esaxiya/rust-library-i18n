//! Mendekode nilai floating-point menjadi bagian-bagian individual dan rentang kesalahan.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Nilai terbatas unsigned yang didekodekan, seperti itu:
///
/// - Nilai asli sama dengan `mant * 2^exp`.
///
/// - Angka apa pun dari `(mant - minus)*2^exp` hingga `(mant + plus)* 2^exp` akan dibulatkan ke nilai aslinya.
/// Rentang ini hanya inklusif jika `inclusive` adalah `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Mantissa berskala.
    pub mant: u64,
    /// Rentang kesalahan yang lebih rendah.
    pub minus: u64,
    /// Rentang kesalahan atas.
    pub plus: u64,
    /// Eksponen bersama di basis 2.
    pub exp: i16,
    /// Benar ketika kisaran kesalahan sudah termasuk.
    ///
    /// Di IEEE 754, ini benar ketika mantissa asli genap.
    pub inclusive: bool,
}

/// Nilai unsigned yang didekodekan.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Ketidakterbatasan, baik positif atau negatif.
    Infinite,
    /// Nol, baik positif atau negatif.
    Zero,
    /// Nomor terbatas dengan bidang yang diterjemahkan lebih lanjut.
    Finite(Decoded),
}

/// Jenis floating point yang dapat berupa `decode`d.
pub trait DecodableFloat: RawFloat + Copy {
    /// Nilai normalisasi positif minimum.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Mengembalikan tanda (benar saat negatif) dan nilai `FullDecoded` dari bilangan titik mengambang yang diberikan.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // tetangga: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode selalu mempertahankan eksponennya, sehingga mantissa diskalakan untuk subnormal.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // tetangga: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // dimana maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // tetangga: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}