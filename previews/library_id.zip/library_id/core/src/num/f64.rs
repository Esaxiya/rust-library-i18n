//! Konstanta khusus untuk tipe titik mengambang presisi ganda `f64`.
//!
//! *[See also the `f64` primitive type][f64].*
//!
//! Angka-angka yang signifikan secara matematis disediakan dalam sub-modul `consts`.
//!
//! Untuk konstanta yang ditentukan secara langsung dalam modul ini (berbeda dari yang ditentukan dalam sub-modul `consts`), kode baru harus menggunakan konstanta terkait yang ditentukan langsung pada tipe `f64`.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// Radix atau basis representasi internal `f64`.
/// Gunakan [`f64::RADIX`] sebagai gantinya.
///
/// # Examples
///
/// ```rust
/// // cara usang
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f64::RADIX;
///
/// // cara yang dimaksudkan
/// let r = f64::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f64`")]
pub const RADIX: u32 = f64::RADIX;

/// Jumlah digit signifikan dalam basis 2.
/// Gunakan [`f64::MANTISSA_DIGITS`] sebagai gantinya.
///
/// # Examples
///
/// ```rust
/// // cara usang
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f64::MANTISSA_DIGITS;
///
/// // cara yang dimaksudkan
/// let d = f64::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f64`"
)]
pub const MANTISSA_DIGITS: u32 = f64::MANTISSA_DIGITS;

/// Perkiraan jumlah digit signifikan di basis 10.
/// Gunakan [`f64::DIGITS`] sebagai gantinya.
///
/// # Examples
///
/// ```rust
/// // cara usang
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f64::DIGITS;
///
/// // cara yang dimaksudkan
/// let d = f64::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f64`")]
pub const DIGITS: u32 = f64::DIGITS;

/// [Machine epsilon] nilai untuk `f64`.
/// Gunakan [`f64::EPSILON`] sebagai gantinya.
///
/// Ini adalah perbedaan antara `1.0` dan bilangan terwakili yang lebih besar berikutnya.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // cara usang
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f64::EPSILON;
///
/// // cara yang dimaksudkan
/// let e = f64::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f64`"
)]
pub const EPSILON: f64 = f64::EPSILON;

/// Nilai `f64` hingga terkecil.
/// Gunakan [`f64::MIN`] sebagai gantinya.
///
/// # Examples
///
/// ```rust
/// // cara usang
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN;
///
/// // cara yang dimaksudkan
/// let min = f64::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f64`")]
pub const MIN: f64 = f64::MIN;

/// Nilai `f64` normal positif terkecil.
/// Gunakan [`f64::MIN_POSITIVE`] sebagai gantinya.
///
/// # Examples
///
/// ```rust
/// // cara usang
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_POSITIVE;
///
/// // cara yang dimaksudkan
/// let min = f64::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f64`"
)]
pub const MIN_POSITIVE: f64 = f64::MIN_POSITIVE;

/// Nilai `f64` terbatas terbesar.
/// Gunakan [`f64::MAX`] sebagai gantinya.
///
/// # Examples
///
/// ```rust
/// // cara usang
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX;
///
/// // cara yang dimaksudkan
/// let max = f64::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f64`")]
pub const MAX: f64 = f64::MAX;

/// Satu lebih besar dari kemungkinan pangkat normal minimal 2 eksponen.
/// Gunakan [`f64::MIN_EXP`] sebagai gantinya.
///
/// # Examples
///
/// ```rust
/// // cara usang
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_EXP;
///
/// // cara yang dimaksudkan
/// let min = f64::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f64`"
)]
pub const MIN_EXP: i32 = f64::MIN_EXP;

/// Kekuatan maksimum yang mungkin dari 2 eksponen.
/// Gunakan [`f64::MAX_EXP`] sebagai gantinya.
///
/// # Examples
///
/// ```rust
/// // cara usang
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX_EXP;
///
/// // cara yang dimaksudkan
/// let max = f64::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f64`"
)]
pub const MAX_EXP: i32 = f64::MAX_EXP;

/// Pangkat normal minimum yang mungkin dari 10 eksponen.
/// Gunakan [`f64::MIN_10_EXP`] sebagai gantinya.
///
/// # Examples
///
/// ```rust
/// // cara usang
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_10_EXP;
///
/// // cara yang dimaksudkan
/// let min = f64::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f64`"
)]
pub const MIN_10_EXP: i32 = f64::MIN_10_EXP;

/// Kekuatan maksimum yang mungkin dari 10 eksponen.
/// Gunakan [`f64::MAX_10_EXP`] sebagai gantinya.
///
/// # Examples
///
/// ```rust
/// // cara usang
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX_10_EXP;
///
/// // cara yang dimaksudkan
/// let max = f64::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f64`"
)]
pub const MAX_10_EXP: i32 = f64::MAX_10_EXP;

/// Bukan Angka (NaN).
/// Gunakan [`f64::NAN`] sebagai gantinya.
///
/// # Examples
///
/// ```rust
/// // cara usang
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f64::NAN;
///
/// // cara yang dimaksudkan
/// let nan = f64::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f64`")]
pub const NAN: f64 = f64::NAN;

/// Infinity (∞).
/// Gunakan [`f64::INFINITY`] sebagai gantinya.
///
/// # Examples
///
/// ```rust
/// // cara usang
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f64::INFINITY;
///
/// // cara yang dimaksudkan
/// let inf = f64::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f64`"
)]
pub const INFINITY: f64 = f64::INFINITY;

/// Tak terhingga negatif (−∞).
/// Gunakan [`f64::NEG_INFINITY`] sebagai gantinya.
///
/// # Examples
///
/// ```rust
/// // cara usang
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f64::NEG_INFINITY;
///
/// // cara yang dimaksudkan
/// let ninf = f64::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f64`"
)]
pub const NEG_INFINITY: f64 = f64::NEG_INFINITY;

/// Konstanta matematika dasar.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: ganti dengan konstanta matematika dari cmath.

    /// Konstanta Archimedes (π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f64 = 3.14159265358979323846264338327950288_f64;

    /// Konstanta lingkaran penuh (τ)
    ///
    /// Sama dengan 2π.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f64 = 6.28318530717958647692528676655900577_f64;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f64 = 1.57079632679489661923132169163975144_f64;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f64 = 1.04719755119659774615421446109316763_f64;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f64 = 0.785398163397448309615660845819875721_f64;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f64 = 0.52359877559829887307710723054658381_f64;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f64 = 0.39269908169872415480783042290993786_f64;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f64 = 0.318309886183790671537767526745028724_f64;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f64 = 0.636619772367581343075535053490057448_f64;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f64 = 1.12837916709551257389615890312154517_f64;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f64 = 1.41421356237309504880168872420969808_f64;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f64 = 0.707106781186547524400844362104849039_f64;

    /// Nomor Euler (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f64 = 2.71828182845904523536028747135266250_f64;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f64 = 3.32192809488736234787031942948939018_f64;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f64 = 1.44269504088896340735992468100189214_f64;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f64 = 0.301029995663981195213738894724493027_f64;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f64 = 0.434294481903251827651128918916605082_f64;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f64 = 0.693147180559945309417232121458176568_f64;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f64 = 2.30258509299404568401799145468436421_f64;
}

#[lang = "f64"]
#[cfg(not(test))]
impl f64 {
    /// Radix atau basis representasi internal `f64`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// Jumlah digit signifikan dalam basis 2.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 53;
    /// Perkiraan jumlah digit signifikan di basis 10.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 15;

    /// [Machine epsilon] nilai untuk `f64`.
    ///
    /// Ini adalah perbedaan antara `1.0` dan bilangan terwakili yang lebih besar berikutnya.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f64 = 2.2204460492503131e-16_f64;

    /// Nilai `f64` hingga terkecil.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f64 = -1.7976931348623157e+308_f64;
    /// Nilai `f64` normal positif terkecil.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f64 = 2.2250738585072014e-308_f64;
    /// Nilai `f64` terbatas terbesar.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f64 = 1.7976931348623157e+308_f64;

    /// Satu lebih besar dari kemungkinan pangkat normal minimal 2 eksponen.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -1021;
    /// Kekuatan maksimum yang mungkin dari 2 eksponen.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 1024;

    /// Pangkat normal minimum yang mungkin dari 10 eksponen.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -307;
    /// Kekuatan maksimum yang mungkin dari 10 eksponen.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 308;

    /// Bukan Angka (NaN).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f64 = 0.0_f64 / 0.0_f64;
    /// Infinity (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f64 = 1.0_f64 / 0.0_f64;
    /// Tak terhingga negatif (−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f64 = -1.0_f64 / 0.0_f64;

    /// Mengembalikan `true` jika nilai ini adalah `NaN`.
    ///
    /// ```
    /// let nan = f64::NAN;
    /// let f = 7.0_f64;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): `abs` tidak tersedia untuk umum di libcore karena kekhawatiran tentang portabilitas, jadi implementasi ini untuk penggunaan pribadi secara internal.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f64 {
        f64::from_bits(self.to_bits() & 0x7fff_ffff_ffff_ffff)
    }

    /// Mengembalikan `true` jika nilai ini adalah tak terhingga positif atau tak terhingga negatif, dan `false` sebaliknya.
    ///
    ///
    /// ```
    /// let f = 7.0f64;
    /// let inf = f64::INFINITY;
    /// let neg_inf = f64::NEG_INFINITY;
    /// let nan = f64::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// Mengembalikan `true` jika nomor ini bukan tak hingga maupun `NaN`.
    ///
    /// ```
    /// let f = 7.0f64;
    /// let inf: f64 = f64::INFINITY;
    /// let neg_inf: f64 = f64::NEG_INFINITY;
    /// let nan: f64 = f64::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // NaN tidak perlu ditangani secara terpisah: jika self adalah NaN, perbandingannya tidak benar, persis seperti yang diinginkan.
        //
        self.abs_private() < Self::INFINITY
    }

    /// Mengembalikan `true` jika angkanya adalah [subnormal].
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f64::MIN_POSITIVE; // 2.2250738585072014e-308_f64
    /// let max = f64::MAX;
    /// let lower_than_min = 1.0e-308_f64;
    /// let zero = 0.0_f64;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f64::NAN.is_subnormal());
    /// assert!(!f64::INFINITY.is_subnormal());
    /// // Nilai antara `0` dan `min` di bawah normal.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// Mengembalikan `true` jika angkanya bukan nol, tak terbatas, [subnormal], atau `NaN`.
    ///
    ///
    /// ```
    /// let min = f64::MIN_POSITIVE; // 2.2250738585072014e-308f64
    /// let max = f64::MAX;
    /// let lower_than_min = 1.0e-308_f64;
    /// let zero = 0.0f64;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f64::NAN.is_normal());
    /// assert!(!f64::INFINITY.is_normal());
    /// // Nilai antara `0` dan `min` di bawah normal.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// Mengembalikan kategori titik mengambang dari angka tersebut.
    /// Jika hanya satu properti yang akan diuji, biasanya lebih cepat menggunakan predikat tertentu sebagai gantinya.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f64;
    /// let inf = f64::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u64 = 0x7ff0000000000000;
        const MAN_MASK: u64 = 0x000fffffffffffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// Mengembalikan `true` jika `self` memiliki tanda positif, termasuk `+0.0`, `NaN` dengan bit tanda positif dan tak terhingga positif.
    ///
    ///
    /// ```
    /// let f = 7.0_f64;
    /// let g = -7.0_f64;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.0.0", reason = "renamed to is_sign_positive")]
    #[inline]
    #[doc(hidden)]
    pub fn is_positive(self) -> bool {
        self.is_sign_positive()
    }

    /// Mengembalikan `true` jika `self` memiliki tanda negatif, termasuk `-0.0`, `NaN` dengan bit tanda negatif dan tak terhingga negatif.
    ///
    ///
    /// ```
    /// let f = 7.0_f64;
    /// let g = -7.0_f64;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        self.to_bits() & 0x8000_0000_0000_0000 != 0
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.0.0", reason = "renamed to is_sign_negative")]
    #[inline]
    #[doc(hidden)]
    pub fn is_negative(self) -> bool {
        self.is_sign_negative()
    }

    /// Mengambil (inverse) timbal balik dari sebuah angka, `1/x`.
    ///
    /// ```
    /// let x = 2.0_f64;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f64 {
        1.0 / self
    }

    /// Mengonversi radian menjadi derajat.
    ///
    /// ```
    /// let angle = std::f64::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_degrees(self) -> f64 {
        // Pembagian di sini dibulatkan dengan benar terhadap nilai sebenarnya dari 180/π.
        // (Ini berbeda dari f32, di mana konstanta harus digunakan untuk memastikan hasil yang dibulatkan dengan benar.)
        //
        self * (180.0f64 / consts::PI)
    }

    /// Mengonversi derajat menjadi radian.
    ///
    /// ```
    /// let angle = 180.0_f64;
    ///
    /// let abs_difference = (angle.to_radians() - std::f64::consts::PI).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_radians(self) -> f64 {
        let value: f64 = consts::PI;
        self * (value / 180.0)
    }

    /// Mengembalikan nilai maksimum dari dua angka.
    ///
    /// ```
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// Jika salah satu argumen adalah NaN, maka argumen lainnya dikembalikan.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f64) -> f64 {
        intrinsics::maxnumf64(self, other)
    }

    /// Mengembalikan nilai minimum dari dua angka.
    ///
    /// ```
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// Jika salah satu argumen adalah NaN, maka argumen lainnya dikembalikan.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f64) -> f64 {
        intrinsics::minnumf64(self, other)
    }

    /// Membulatkan ke arah nol dan mengonversi ke jenis bilangan bulat primitif apa pun, dengan asumsi bahwa nilainya terbatas dan cocok dengan jenis itu.
    ///
    ///
    /// ```
    /// let value = 4.6_f64;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f64;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// Nilainya harus:
    ///
    /// * Bukan `NaN`
    /// * Tidak terbatas
    /// * Dapat direpresentasikan dalam tipe kembalian `Int`, setelah memotong bagian pecahannya
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // KEAMANAN: penelepon harus memegang kontrak keamanan untuk `FloatToInt::to_int_unchecked`.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// Transmutasi mentah ke `u64`.
    ///
    /// Ini saat ini identik dengan `transmute::<f64, u64>(self)` di semua platform.
    ///
    /// Lihat `from_bits` untuk beberapa diskusi tentang portabilitas operasi ini (hampir tidak ada masalah).
    ///
    /// Perhatikan bahwa fungsi ini berbeda dari transmisi `as`, yang mencoba mempertahankan nilai *numerik*, dan bukan nilai bitwise.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((1f64).to_bits() != 1f64 as u64); // to_bits() tidak sedang mentransmisi!
    /// assert_eq!((12.5f64).to_bits(), 0x4029000000000000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u64 {
        // KEAMANAN: `u64` adalah tipe data lama sehingga kami selalu dapat mengubahnya
        unsafe { mem::transmute(self) }
    }

    /// Transmutasi mentah dari `u64`.
    ///
    /// Ini saat ini identik dengan `transmute::<u64, f64>(v)` di semua platform.
    /// Ternyata ini sangat portabel, karena dua alasan:
    ///
    /// * Float dan Ints memiliki endian yang sama di semua platform yang didukung.
    /// * IEEE-754 dengan sangat tepat menentukan tata letak bit float.
    ///
    /// Namun ada satu peringatan: sebelum versi 2008 IEEE-754, cara menafsirkan bit pensinyalan NaN tidak benar-benar ditentukan.
    /// Sebagian besar platform (terutama x86 dan ARM) memilih interpretasi yang akhirnya distandarisasi pada tahun 2008, tetapi beberapa tidak (terutama MIPS).
    /// Akibatnya, semua NaN pensinyalan pada MIPS adalah NaN sunyi pada x86, dan sebaliknya.
    ///
    /// Alih-alih mencoba mempertahankan signaling-ness lintas platform, implementasi ini lebih mengutamakan pelestarian bit yang tepat.
    /// Ini berarti bahwa setiap payload yang dikodekan dalam NaN akan dipertahankan meskipun hasil dari metode ini dikirim melalui jaringan dari mesin x86 ke mesin MIPS.
    ///
    ///
    /// Jika hasil dari metode ini hanya dimanipulasi oleh arsitektur yang sama yang memproduksinya, maka tidak ada masalah portabilitas.
    ///
    /// Jika inputnya bukan NaN, maka tidak ada masalah portabilitas.
    ///
    /// Jika Anda tidak peduli tentang pensinyalan (sangat mungkin), maka tidak ada masalah portabilitas.
    ///
    /// Perhatikan bahwa fungsi ini berbeda dari transmisi `as`, yang mencoba mempertahankan nilai *numerik*, dan bukan nilai bitwise.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f64::from_bits(0x4029000000000000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u64) -> Self {
        // KEAMANAN: `u64` adalah tipe data lama sehingga kami selalu dapat mentransmutasikannya
        // Ternyata masalah keamanan dengan sNaN berlebihan!Hore!
        unsafe { mem::transmute(v) }
    }

    /// Kembalikan representasi memori dari angka floating point ini sebagai array byte dalam urutan byte (network) big-endian.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_be_bytes();
    /// assert_eq!(bytes, [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 8] {
        self.to_bits().to_be_bytes()
    }

    /// Kembalikan representasi memori dari angka floating point ini sebagai array byte dalam urutan byte little-endian.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 8] {
        self.to_bits().to_le_bytes()
    }

    /// Kembalikan representasi memori dari angka floating point ini sebagai array byte dalam urutan byte asli.
    ///
    /// Karena ketangguhan asli platform target digunakan, kode portabel harus menggunakan [`to_be_bytes`] atau [`to_le_bytes`], jika sesuai.
    ///
    ///
    /// [`to_be_bytes`]: f64::to_be_bytes
    /// [`to_le_bytes`]: f64::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 8] {
        self.to_bits().to_ne_bytes()
    }

    /// Kembalikan representasi memori dari angka floating point ini sebagai array byte dalam urutan byte asli.
    ///
    ///
    /// [`to_ne_bytes`] harus lebih disukai daripada ini bila memungkinkan.
    ///
    /// [`to_ne_bytes`]: f64::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f64;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 8] {
        // KEAMANAN: `f64` adalah tipe data lama sehingga kami selalu dapat mengubahnya
        unsafe { &*(self as *const Self as *const _) }
    }

    /// Buat nilai floating point dari representasinya sebagai byte array di big endian.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_be_bytes([0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_be_bytes(bytes))
    }

    /// Buat nilai floating point dari representasi sebagai array byte di little endian.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_le_bytes([0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_le_bytes(bytes))
    }

    /// Buat nilai floating point dari representasinya sebagai byte array di native endian.
    ///
    /// Karena ketangguhan asli platform target digunakan, kode portabel kemungkinan besar ingin menggunakan [`from_be_bytes`] atau [`from_le_bytes`], sebagaimana mestinya.
    ///
    ///
    /// [`from_be_bytes`]: f64::from_be_bytes
    /// [`from_le_bytes`]: f64::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_ne_bytes(bytes))
    }

    /// Mengembalikan urutan antara nilai diri dan nilai lainnya.
    /// Berbeda dengan perbandingan parsial standar antara bilangan floating point, perbandingan ini selalu menghasilkan urutan yang sesuai dengan predikat totalOrder sebagaimana didefinisikan dalam standar floating point IEEE 754 (revisi 2008).
    /// Nilai diurutkan dalam urutan berikut:
    /// - NaN tenang negatif
    /// - NaN pensinyalan negatif
    /// - Ketidakterbatasan negatif
    /// - Angka negatif
    /// - Bilangan subnormal negatif
    /// - Nol negatif
    /// - Nol positif
    /// - Bilangan subnormal positif
    /// - Angka positif
    /// - Ketidakterbatasan positif
    /// - NaN pensinyalan positif
    /// - NaN tenang positif
    ///
    /// Perhatikan bahwa fungsi ini tidak selalu sesuai dengan implementasi [`PartialOrd`] dan [`PartialEq`] pada `f64`.Secara khusus, mereka menganggap nol negatif dan positif sama, sedangkan `total_cmp` tidak.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f64,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f64::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f64::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f64::INFINITY, f64::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i64;
        let mut right = other.to_bits() as i64;

        // Dalam kasus negatif, balik semua bit kecuali tanda untuk mencapai tata letak yang sama seperti bilangan bulat pelengkap dua
        //
        // Mengapa ini berhasil?IEEE 754 float terdiri dari tiga bidang:
        // Tanda tangan bit, eksponen dan mantissa.Himpunan bidang eksponen dan mantissa secara keseluruhan memiliki properti bahwa urutan bitwise-nya sama dengan besaran numerik tempat besaran ditentukan.
        // Besaran biasanya tidak ditentukan pada nilai NaN, tetapi IEEE 754 totalOrder mendefinisikan nilai NaN juga untuk mengikuti urutan bitwise.Ini mengarah ke pesanan yang dijelaskan dalam komentar dokumen.
        // Namun, representasi besarnya sama untuk bilangan negatif dan positif-hanya bit tandanya yang berbeda.
        // Untuk dengan mudah membandingkan float sebagai bilangan bulat bertanda, kita perlu membalik bit eksponen dan mantissa jika ada bilangan negatif.
        // Kami secara efektif mengonversi angka ke bentuk "two's complement".
        //
        // Untuk melakukan pembalikan, kami membuat topeng dan XOR melawannya.
        // Kami menghitung tanpa cabang topeng "all-ones except for the sign bit" dari nilai bertanda negatif: tanda geser kanan-memperluas bilangan bulat, jadi kami "fill" topeng dengan bit tanda, dan kemudian mengonversi ke unsigned untuk mendorong satu bit nol lagi.
        //
        // Pada nilai positif, mask semuanya nol, jadi tidak ada operasi.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 63) as u64) >> 1) as i64;
        right ^= (((right >> 63) as u64) >> 1) as i64;

        left.cmp(&right)
    }

    /// Batasi nilai ke interval tertentu kecuali jika itu adalah NaN.
    ///
    /// Mengembalikan `max` jika `self` lebih besar dari `max`, dan `min` jika `self` lebih kecil dari `min`.
    /// Jika tidak, ini mengembalikan `self`.
    ///
    /// Perhatikan bahwa fungsi ini mengembalikan NaN jika nilai awalnya adalah NaN juga.
    ///
    /// # Panics
    ///
    /// Panics jika `min > max`, `min` adalah NaN, atau `max` adalah NaN.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f64).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f64).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f64).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f64::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f64, max: f64) -> f64 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}