//! Konstanta untuk tipe integer unsigned 8-bit.
//!
//! *[See also the `u8` primitive type][u8].*
//!
//! Kode baru harus menggunakan konstanta terkait langsung pada tipe primitif.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u8`"
)]

int_module! { u8 }