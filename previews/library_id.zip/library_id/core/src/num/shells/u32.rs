//! Konstanta untuk tipe integer 32-bit unsigned.
//!
//! *[See also the `u32` primitive type][u32].*
//!
//! Kode baru harus menggunakan konstanta terkait langsung pada tipe primitif.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u32`"
)]

int_module! { u32 }