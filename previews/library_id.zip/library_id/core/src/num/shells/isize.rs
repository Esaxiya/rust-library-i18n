//! Konstanta untuk tipe integer bertanda tangan berukuran pointer.
//!
//! *[See also the `isize` primitive type][isize].*
//!
//! Kode baru harus menggunakan konstanta terkait langsung pada tipe primitif.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `isize`"
)]

int_module! { isize }