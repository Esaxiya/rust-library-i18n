//! Jenis kesalahan untuk konversi ke jenis integral.

use crate::convert::Infallible;
use crate::fmt;

/// Jenis kesalahan dikembalikan ketika konversi tipe integral yang diperiksa gagal.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Cocokkan daripada memaksa untuk memastikan bahwa kode seperti `From<Infallible> for TryFromIntError` di atas akan tetap berfungsi saat `Infallible` menjadi alias untuk `!`.
        //
        //
        match never {}
    }
}

/// Kesalahan yang dapat dikembalikan saat mengurai bilangan bulat.
///
/// Kesalahan ini digunakan sebagai jenis kesalahan untuk fungsi `from_str_radix()` pada jenis integer primitif, seperti [`i8::from_str_radix`].
///
/// # Penyebab potensial
///
/// Di antara penyebab lainnya, `ParseIntError` dapat terlempar karena spasi kosong di awal atau di belakang string misalnya, jika diperoleh dari input standar.
///
/// Menggunakan metode [`str::trim()`] memastikan bahwa tidak ada spasi kosong sebelum penguraian.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum untuk menyimpan berbagai jenis kesalahan yang dapat menyebabkan penguraian integer gagal.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Nilai yang diurai kosong.
    ///
    /// Di antara penyebab lainnya, varian ini akan dibuat saat mengurai string kosong.
    Empty,
    /// Berisi digit yang tidak valid dalam konteksnya.
    ///
    /// Di antara penyebab lainnya, varian ini akan dibuat saat mengurai string yang berisi karakter non-ASCII.
    ///
    /// Varian ini juga dibuat ketika `+` atau `-` salah tempat di dalam string baik di sendiri atau di tengah angka.
    ///
    ///
    InvalidDigit,
    /// Bilangan bulat terlalu besar untuk disimpan dalam jenis bilangan bulat target.
    PosOverflow,
    /// Bilangan bulat terlalu kecil untuk disimpan dalam jenis bilangan bulat target.
    NegOverflow,
    /// Nilainya Nol
    ///
    /// Varian ini akan dikeluarkan jika parsing string memiliki nilai nol, yang akan menjadi ilegal untuk jenis bukan nol.
    ///
    Zero,
}

impl ParseIntError {
    /// Mengeluarkan penyebab mendetail dari penguraian bilangan bulat yang gagal.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}