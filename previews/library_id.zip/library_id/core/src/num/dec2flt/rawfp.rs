//! Sedikit mengutak-atik float IEEE 754 positif.Angka negatif tidak dan tidak perlu ditangani.
//! Bilangan floating point normal memiliki representasi kanonik sebagai (frac, exp) sehingga nilainya adalah 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)) dimana N adalah jumlah bit.
//!
//! Subnormal sedikit berbeda dan aneh, tetapi prinsip yang sama berlaku.
//!
//! Di sini, bagaimanapun, kami merepresentasikannya sebagai (sig, k) dengan f positif, sehingga nilainya adalah f *
//! 2 <sup>e</sup> .Selain membuat "hidden bit" eksplisit, ini mengubah eksponen dengan apa yang disebut pergeseran mantissa.
//!
//! Dengan kata lain, biasanya float ditulis sebagai (1) tetapi di sini ditulis sebagai (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Kami menyebut (1) sebagai **representasi pecahan** dan (2) sebagai **representasi integral**.
//!
//! Banyak fungsi dalam modul ini hanya menangani angka normal.Rutinitas dec2flt secara konservatif mengambil jalur lambat yang benar secara universal (Algoritma M) untuk jumlah yang sangat kecil dan sangat besar.
//! Algoritma itu hanya membutuhkan next_float() yang menangani subnormal dan nol.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// Seorang pembantu trait untuk menghindari duplikasi pada dasarnya semua kode konversi untuk `f32` dan `f64`.
///
/// Lihat komentar dokumen modul induk tentang mengapa ini diperlukan.
///
/// **Jangan pernah** diterapkan untuk jenis lain atau digunakan di luar modul dec2flt.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Ketik yang digunakan oleh `to_bits` dan `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Melakukan transmutasi mentah ke integer.
    fn to_bits(self) -> Self::Bits;

    /// Melakukan transmutasi mentah dari integer.
    fn from_bits(v: Self::Bits) -> Self;

    /// Menampilkan kategori tempat nomor ini berada.
    fn classify(self) -> FpCategory;

    /// Mengembalikan mantissa, eksponen, dan tanda sebagai bilangan bulat.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Mendekode pelampung.
    fn unpack(self) -> Unpacked;

    /// Transmisi dari bilangan bulat kecil yang dapat direpresentasikan dengan tepat.
    /// Panic jika bilangan bulat tidak dapat direpresentasikan, kode lain dalam modul ini memastikan untuk tidak membiarkan hal itu terjadi.
    fn from_int(x: u64) -> Self;

    /// Mendapat nilai 10 <sup>e</sup> dari tabel yang telah dihitung sebelumnya.
    /// Panics untuk `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Apa namanya.
    /// Lebih mudah untuk membuat kode keras daripada menyulap intrinsik dan berharap LLVM terus menerus melipatnya.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Batas konservatif pada digit desimal masukan yang tidak dapat menghasilkan luapan atau nol atau
    /// subnormal.Mungkin eksponen desimal dari nilai normal maksimum, itulah namanya.
    const MAX_NORMAL_DIGITS: usize;

    /// Jika angka desimal paling signifikan memiliki nilai tempat lebih besar dari ini, angka tersebut pasti dibulatkan hingga tak terbatas.
    ///
    const INF_CUTOFF: i64;

    /// Jika angka desimal paling signifikan memiliki nilai tempat kurang dari ini, angka tersebut pasti dibulatkan menjadi nol.
    ///
    const ZERO_CUTOFF: i64;

    /// Jumlah bit dalam eksponen.
    const EXP_BITS: u8;

    /// Jumlah bit dalam signifikansi,*termasuk* bit tersembunyi.
    const SIG_BITS: u8;

    /// Jumlah bit dalam signifikansi,*tidak termasuk* bit tersembunyi.
    const EXPLICIT_SIG_BITS: u8;

    /// Eksponen hukum maksimum dalam representasi pecahan.
    const MAX_EXP: i16;

    /// Eksponen hukum minimum dalam representasi pecahan, tidak termasuk subnormal.
    const MIN_EXP: i16;

    /// `MAX_EXP` untuk representasi integral, yaitu dengan pergeseran diterapkan.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` dikodekan (yaitu, dengan bias offset)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` untuk representasi integral, yaitu dengan pergeseran diterapkan.
    const MIN_EXP_INT: i16;

    /// Signifikansi normalisasi maksimum dalam representasi integral.
    const MAX_SIG: u64;

    /// Signifikansi minimal yang dinormalisasi dalam representasi integral.
    const MIN_SIG: u64;
}

// Sebagian besar solusi untuk #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Mengembalikan mantissa, eksponen, dan tanda sebagai bilangan bulat.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Bias eksponen + pergeseran mantissa
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe tidak yakin apakah `as` dapat dibulatkan dengan benar di semua platform.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Mengembalikan mantissa, eksponen, dan tanda sebagai bilangan bulat.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Bias eksponen + pergeseran mantissa
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe tidak yakin apakah `as` dapat dibulatkan dengan benar di semua platform.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Mengonversi `Fp` ke jenis pelampung mesin terdekat.
/// Tidak menangani hasil di bawah normal.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f adalah 64 bit, jadi xe memiliki pergeseran mantissa 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Bulatkan signifikansi 64-bit menjadi bit T::SIG_BITS dengan setengah hingga genap.
/// Tidak menangani luapan eksponen.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Sesuaikan shift mantissa
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Pembalikan `RawFloat::unpack()` untuk bilangan yang dinormalisasi.
/// Panics jika signifikan atau eksponen tidak valid untuk angka yang dinormalisasi.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Hapus bit yang tersembunyi
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Sesuaikan eksponen untuk bias eksponen dan pergeseran mantissa
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Biarkan tanda sedikit pada 0 ("+"), angka kita semuanya positif
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Bangun subnormal.Mantissa 0 diperbolehkan dan membentuk nol.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Eksponen yang dikodekan adalah 0, bit tanda adalah 0, jadi kita hanya perlu menafsirkan ulang bit-bit tersebut.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Perkirakan bignum dengan Fp.Membulatkan dalam 0.5 ULP dengan setengah hingga genap.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Kami memotong semua bit sebelum indeks `start`, yaitu, kami secara efektif menggeser kanan sejumlah `start`, jadi ini juga eksponen yang kami butuhkan.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Putaran (half-to-even) tergantung pada bit yang terpotong.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Menemukan bilangan floating point terbesar lebih kecil dari argumen.
/// Tidak menangani subnormal, nol, atau eksponen underflow.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Temukan bilangan floating point terkecil yang lebih besar dari argumen.
// Operasi ini menjenuhkan, yaitu next_float(inf) ==inf.
// Tidak seperti kebanyakan kode dalam modul ini, fungsi ini menangani nol, subnormal, dan tak terbatas.
// Namun, seperti semua kode lain di sini, kode ini tidak menangani angka NaN dan negatif.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Ini tampaknya terlalu bagus untuk menjadi kenyataan, tetapi berhasil.
        // 0.0 dikodekan sebagai kata semua-nol.Subnormal adalah 0x000m ... m di mana m adalah mantissa.
        // Secara khusus, subnormal terkecil adalah 0x0 ... 01 dan yang terbesar adalah 0x000F ... F.
        // Angka normal terkecil adalah 0x0010 ... 0, jadi casing sudut ini juga berfungsi.
        // Jika kenaikan melebihi mantissa, bit carry menambah eksponen sesuai keinginan, dan bit mantissa menjadi nol.
        // Karena konvensi bit tersembunyi, ini juga persis seperti yang kita inginkan!
        // Akhirnya, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}