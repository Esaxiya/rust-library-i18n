//! Mengonversi string desimal menjadi angka floating point biner IEEE 754.
//!
//! # Pernyataan masalah
//!
//! Kami diberi string desimal seperti `12.34e56`.
//! String ini terdiri dari bagian integral (`12`), pecahan (`34`), dan eksponen (`56`).Semua bagian bersifat opsional dan diartikan sebagai nol jika hilang.
//!
//! Kami mencari angka floating point IEEE 754 yang paling dekat dengan nilai yang tepat dari string desimal.
//! Diketahui bahwa banyak string desimal tidak memiliki representasi penghentian di basis dua, jadi kami membulatkan ke unit 0.5 di tempat terakhir (dengan kata lain, sebaik mungkin).
//! Dasi, nilai desimal persis di tengah-tengah antara dua pelampung berturut-turut, diselesaikan dengan strategi setengah-ke-genap, yang juga dikenal sebagai pembulatan bankir.
//!
//! Tak perlu dikatakan, ini cukup sulit, baik dalam hal kompleksitas implementasi maupun dalam hal siklus CPU yang diambil.
//!
//! # Implementation
//!
//! Pertama, kita mengabaikan tanda.Atau lebih tepatnya, kami menghapusnya di awal proses konversi dan menerapkannya kembali di akhir.
//! Ini benar di semua kasus edge karena float IEEE simetris di sekitar nol, meniadakan satu hanya membalik bit pertama.
//!
//! Kemudian kami menghapus titik desimal dengan menyesuaikan eksponen: Secara konseptual, `12.34e56` berubah menjadi `1234e54`, yang kami gambarkan dengan bilangan bulat positif `f = 1234` dan bilangan bulat `e = 54`.
//! Representasi `(f, e)` digunakan oleh hampir semua kode yang melewati tahap penguraian.
//!
//! Kami kemudian mencoba rantai panjang kasus khusus yang semakin umum dan mahal menggunakan bilangan bulat berukuran mesin dan bilangan titik mengambang berukuran tetap yang kecil (`f32`/`f64` pertama, lalu tipe dengan signifikansi 64 bit, `Fp`).
//!
//! Ketika semua ini gagal, kami gigit jari dan menggunakan algoritma sederhana namun sangat lambat yang melibatkan komputasi `f * 10^e` sepenuhnya dan melakukan pencarian berulang untuk perkiraan terbaik.
//!
//! Pada dasarnya, modul ini dan turunannya menerapkan algoritme yang dijelaskan di:
//! "How to Read Floating Point Numbers Accurately" oleh William D.
//! Clinger, tersedia online: <http://citeseerx.ist.psu.edu/viewdoc/summary?doi=10.1.1.45.4152>
//!
//! Selain itu, ada banyak fungsi pembantu yang digunakan di kertas tetapi tidak tersedia di Rust (atau setidaknya di inti).
//! Versi kami juga diperumit oleh kebutuhan untuk menangani overflow dan underflow dan keinginan untuk menangani angka di bawah normal.
//! Bellerophon dan Algorithm R mengalami masalah dengan overflow, subnormal, dan underflow.
//! Kami secara konservatif beralih ke Algoritma M (dengan modifikasi yang dijelaskan di bagian 8 makalah) jauh sebelum input masuk ke wilayah kritis.
//!
//! Aspek lain yang perlu diperhatikan adalah ``RawFloat`` trait di mana hampir semua fungsi diparameterisasi.Orang mungkin berpikir bahwa itu cukup untuk mengurai ke `f64` dan mengirimkan hasilnya ke `f32`.
//! Sayangnya ini bukan dunia tempat kita tinggal, dan ini tidak ada hubungannya dengan penggunaan pembulatan basis dua atau setengah hingga genap.
//!
//! Pertimbangkan misalnya dua jenis `d2` dan `d4` mewakili jenis desimal dengan masing-masing dua digit desimal dan empat digit desimal dan mengambil "0.01499" sebagai input.Mari gunakan pembulatan setengah ke atas.
//! Langsung ke dua digit desimal menghasilkan `0.01`, tetapi jika kita membulatkan menjadi empat digit terlebih dahulu, kita mendapatkan `0.0150`, yang kemudian dibulatkan menjadi `0.02`.
//! Prinsip yang sama juga berlaku untuk operasi lain, jika Anda menginginkan akurasi ULP 0.5, Anda perlu melakukan *semuanya* dengan presisi penuh dan membulatkan *tepat sekali, di akhir*, dengan mempertimbangkan semua bit yang terpotong sekaligus.
//!
//! FIXME: Meskipun beberapa duplikasi kode diperlukan, mungkin bagian-bagian kode dapat diubahsuaikan sedemikian rupa sehingga lebih sedikit kode yang diduplikasi.
//! Sebagian besar algoritme tidak bergantung pada tipe float ke output, atau hanya membutuhkan akses ke beberapa konstanta, yang dapat diteruskan sebagai parameter.
//!
//! # Other
//!
//! Konversi harus *tidak pernah* panic.
//! Ada pernyataan dan panics eksplisit dalam kode, tetapi tidak boleh dipicu dan hanya berfungsi sebagai pemeriksaan kesehatan internal.Semua panics harus dianggap sebagai bug.
//!
//! Ada tes unit tetapi sayangnya tidak memadai untuk memastikan kebenaran, tes tersebut hanya mencakup sebagian kecil dari kemungkinan kesalahan.
//! Tes yang jauh lebih ekstensif terletak di direktori `src/etc/test-float-parse` sebagai skrip Python.
//!
//! Catatan tentang bilangan bulat overflow: Banyak bagian dari file ini melakukan aritmatika dengan eksponen desimal `e`.
//! Terutama, kita menggeser koma desimal: Sebelum angka desimal pertama, setelah angka desimal terakhir, dan seterusnya.Ini bisa meluap jika dilakukan secara sembarangan.
//! Kami mengandalkan submodul penguraian untuk hanya membagikan eksponen yang cukup kecil, di mana "sufficient" berarti "such that the exponent +/- the number of decimal digits fits into a 64 bit integer".
//! Eksponen yang lebih besar diterima, tetapi kami tidak melakukan aritmatika dengannya, eksponen tersebut segera diubah menjadi {positive,negative} {zero,infinity}.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![doc(hidden)]
#![unstable(
    feature = "dec2flt",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

use crate::fmt;
use crate::str::FromStr;

use self::num::digits_to_big;
use self::parse::{parse_decimal, Decimal, ParseResult, Sign};
use self::rawfp::RawFloat;

mod algorithm;
mod num;
mod table;
// Keduanya memiliki tesnya sendiri.
pub mod parse;
pub mod rawfp;

macro_rules! from_str_float_impl {
    ($t:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl FromStr for $t {
            type Err = ParseFloatError;

            /// Mengonversi string di basis 10 menjadi pelampung.
            /// Menerima eksponen desimal opsional.
            ///
            /// Fungsi ini menerima string seperti
            ///
            /// * '3.14'
            /// * '-3.14'
            /// * '2.5E10', atau setara, '2.5e10'
            /// * '2.5E-10'
            /// * '5.'
            /// * '.5', atau, dengan kata lain, '0.5'
            /// * 'inf', '-inf', 'NaN'
            ///
            /// Spasi kosong di depan dan di belakang menunjukkan kesalahan.
            ///
            /// # Grammar
            ///
            /// Semua string yang mematuhi tata bahasa [EBNF] berikut akan menghasilkan [`Ok`] yang dikembalikan:
            ///
            ///
            /// ```txt
            /// Float  ::= Sign? ( 'inf' | 'NaN' | Number )
            /// Number ::= ( Digit+ |
            ///              Digit+ '.' Digit* |
            ///              Digit* '.' Digit+ ) Exp?
            /// Exp    ::= [eE] Sign? Digit+
            /// Sign   ::= [+-]
            /// Digit  ::= [0-9]
            /// ```
            ///
            /// [EBNF]: https://www.w3.org/TR/REC-xml/#sec-notation
            ///
            /// # Bug yang diketahui
            ///
            /// Dalam beberapa situasi, beberapa string yang seharusnya membuat float yang valid malah mengembalikan kesalahan.
            /// Lihat [issue #31407] untuk detailnya.
            ///
            /// [issue #31407]: https://github.com/rust-lang/rust/issues/31407
            ///
            /// # Arguments
            ///
            /// * src, Sebuah string
            ///
            /// # Nilai kembali
            ///
            /// `Err(ParseFloatError)` jika string tidak mewakili angka yang valid.
            /// Sebaliknya, `Ok(n)` di mana `n` adalah bilangan floating-point yang diwakili oleh `src`.
            ///
            #[inline]
            fn from_str(src: &str) -> Result<Self, ParseFloatError> {
                dec2flt(src)
            }
        }
    };
}
from_str_float_impl!(f32);
from_str_float_impl!(f64);

/// Kesalahan yang bisa dikembalikan saat mengurai float.
///
/// Kesalahan ini digunakan sebagai jenis kesalahan untuk implementasi [`FromStr`] untuk [`f32`] dan [`f64`].
///
///
/// # Example
///
/// ```
/// use std::str::FromStr;
///
/// if let Err(e) = f64::from_str("a.12") {
///     println!("Failed conversion to f64: {}", e);
/// }
/// ```
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseFloatError {
    kind: FloatErrorKind,
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum FloatErrorKind {
    Empty,
    Invalid,
}

impl ParseFloatError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            FloatErrorKind::Empty => "cannot parse float from empty string",
            FloatErrorKind::Invalid => "invalid float literal",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseFloatError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

fn pfe_empty() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Empty }
}

fn pfe_invalid() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Invalid }
}

/// Membagi string desimal menjadi tanda dan sisanya, tanpa memeriksa atau memvalidasi sisanya.
fn extract_sign(s: &str) -> (Sign, &str) {
    match s.as_bytes()[0] {
        b'+' => (Sign::Positive, &s[1..]),
        b'-' => (Sign::Negative, &s[1..]),
        // Jika string tidak valid, kami tidak pernah menggunakan tanda, jadi kami tidak perlu memvalidasi di sini.
        _ => (Sign::Positive, s),
    }
}

/// Mengonversi string desimal menjadi bilangan floating point.
fn dec2flt<T: RawFloat>(s: &str) -> Result<T, ParseFloatError> {
    if s.is_empty() {
        return Err(pfe_empty());
    }
    let (sign, s) = extract_sign(s);
    let flt = match parse_decimal(s) {
        ParseResult::Valid(decimal) => convert(decimal)?,
        ParseResult::ShortcutToInf => T::INFINITY,
        ParseResult::ShortcutToZero => T::ZERO,
        ParseResult::Invalid => match s {
            "inf" => T::INFINITY,
            "NaN" => T::NAN,
            _ => {
                return Err(pfe_invalid());
            }
        },
    };

    match sign {
        Sign::Positive => Ok(flt),
        Sign::Negative => Ok(-flt),
    }
}

/// Pekerja keras utama untuk konversi desimal-ke-float: Atur semua preprocessing dan cari tahu algoritma mana yang harus melakukan konversi yang sebenarnya.
///
fn convert<T: RawFloat>(mut decimal: Decimal<'_>) -> Result<T, ParseFloatError> {
    simplify(&mut decimal);
    if let Some(x) = trivial_cases(&decimal) {
        return Ok(x);
    }
    // Remove/shift keluar koma desimal.
    let e = decimal.exp - decimal.fractional.len() as i64;
    if let Some(x) = algorithm::fast_path(decimal.integral, decimal.fractional, e) {
        return Ok(x);
    }
    // Big32x40 dibatasi hingga 1280 bit, yang diterjemahkan menjadi sekitar 385 digit desimal.
    // Jika kita melebihi ini, kita akan crash, jadi kita error sebelum terlalu dekat (dalam 10 ^ 10).
    let upper_bound = bound_intermediate_digits(&decimal, e);
    if upper_bound > 375 {
        return Err(pfe_invalid());
    }
    let f = digits_to_big(decimal.integral, decimal.fractional);

    // Sekarang eksponen pasti cocok dalam 16 bit, yang digunakan di seluruh algoritme utama.
    let e = e as i16;
    // FIXME Batas ini agak konservatif.
    // Analisis yang lebih cermat tentang mode kegagalan Bellerophon dapat memungkinkan penggunaannya dalam lebih banyak kasus untuk kecepatan yang sangat besar.
    let exponent_in_range = table::MIN_E <= e && e <= table::MAX_E;
    let value_in_range = upper_bound <= T::MAX_NORMAL_DIGITS as u64;
    if exponent_in_range && value_in_range {
        Ok(algorithm::bellerophon(&f, e))
    } else {
        Ok(algorithm::algorithm_m(&f, e))
    }
}

// Seperti yang tertulis, pengoptimalan ini buruk (lihat #27130, meskipun mengacu pada kode versi lama).
// `inline(always)` adalah solusi untuk itu.
// Hanya ada dua situs panggilan secara keseluruhan dan itu tidak membuat ukuran kode menjadi lebih buruk.

/// Hapus nol jika memungkinkan, bahkan jika eksponen harus diubah
#[inline(always)]
fn simplify(decimal: &mut Decimal<'_>) {
    let is_zero = &|&&d: &&u8| -> bool { d == b'0' };
    // Pemangkasan nol ini tidak mengubah apa pun tetapi dapat mengaktifkan jalur cepat (<15 digit).
    let leading_zeros = decimal.integral.iter().take_while(is_zero).count();
    decimal.integral = &decimal.integral[leading_zeros..];
    let trailing_zeros = decimal.fractional.iter().rev().take_while(is_zero).count();
    let end = decimal.fractional.len() - trailing_zeros;
    decimal.fractional = &decimal.fractional[..end];
    // Sederhanakan bilangan dari bentuk 0.0 ... x dan x ... 0.0, sesuaikan eksponennya.
    // Ini mungkin tidak selalu menjadi kemenangan (mungkin mendorong beberapa angka keluar dari jalur cepat), tetapi menyederhanakan bagian lain secara signifikan (terutama, mendekati besaran nilainya).
    //
    if decimal.integral.is_empty() {
        let leading_zeros = decimal.fractional.iter().take_while(is_zero).count();
        decimal.fractional = &decimal.fractional[leading_zeros..];
        decimal.exp -= leading_zeros as i64;
    } else if decimal.fractional.is_empty() {
        let trailing_zeros = decimal.integral.iter().rev().take_while(is_zero).count();
        let end = decimal.integral.len() - trailing_zeros;
        decimal.integral = &decimal.integral[..end];
        decimal.exp += trailing_zeros as i64;
    }
}

/// Mengembalikan batas atas quick-an-dirty pada ukuran (log10) dari nilai terbesar yang akan dihitung Algoritme R dan Algoritme M saat mengerjakan desimal yang ditentukan.
///
fn bound_intermediate_digits(decimal: &Decimal<'_>, e: i64) -> u64 {
    // Kami tidak perlu terlalu khawatir tentang overflow di sini berkat trivial_cases() dan parser, yang menyaring input paling ekstrim untuk kami.
    //
    let f_len: u64 = decimal.integral.len() as u64 + decimal.fractional.len() as u64;
    if e >= 0 {
        // Dalam kasus e>=0, kedua algoritma menghitung tentang `f * 10^e`.
        // Algoritma R melanjutkan untuk melakukan beberapa perhitungan rumit dengan ini tetapi kita dapat mengabaikannya untuk batas atas karena juga mengurangi pecahan sebelumnya, jadi kita memiliki banyak buffer di sana.
        //
        f_len + (e as u64)
    } else {
        // Jika e <0, Algoritma R melakukan hal yang kurang lebih sama, tetapi Algoritma M berbeda:
        // Ia mencoba untuk menemukan bilangan positif k sehingga `f << k / 10^e` adalah signifikan dalam kisaran.
        // Ini akan menghasilkan sekitar `2^53 *f* 10^e` <`10^17 *f* 10^e`.
        // Satu masukan yang memicu ini adalah 0,33 ... 33 (375 x 3).
        f_len + e.unsigned_abs() + 17
    }
}

/// Mendeteksi overflow dan underflow yang jelas bahkan tanpa melihat angka desimal.
fn trivial_cases<T: RawFloat>(decimal: &Decimal<'_>) -> Option<T> {
    // Ada nol tetapi mereka dilucuti oleh simplify()
    if decimal.integral.is_empty() && decimal.fractional.is_empty() {
        return Some(T::ZERO);
    }
    // Ini adalah perkiraan kasar dari ceil(log10(the real value)).
    // Kita tidak perlu terlalu khawatir tentang overflow di sini karena panjang inputnya kecil (setidaknya dibandingkan dengan 2 ^ 64) dan parser sudah menangani eksponen yang nilai absolutnya lebih besar dari 10 ^ 18 (yang masih pendek 10 ^ 19). dari 2 ^ 64).
    //
    //
    let max_place = decimal.exp + decimal.integral.len() as i64;
    if max_place > T::INF_CUTOFF {
        return Some(T::INFINITY);
    } else if max_place < T::ZERO_CUTOFF {
        return Some(T::ZERO);
    }
    None
}