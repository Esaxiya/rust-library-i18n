//! Berbagai algoritma dari kertas.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Jumlah bit signifikan dalam Fp
const P: u32 = 64;

// Kami hanya menyimpan perkiraan terbaik untuk *semua* eksponen, sehingga variabel "h" dan kondisi terkait dapat dihilangkan.
// Ini memperdagangkan kinerja untuk beberapa kilobyte ruang.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// Di sebagian besar arsitektur, operasi floating point memiliki ukuran bit yang eksplisit, oleh karena itu ketepatan komputasi ditentukan pada basis per operasi.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// Di x86, x87 FPU digunakan untuk operasi float jika ekstensi SSE/SSE2 tidak tersedia.
// FPU x87 beroperasi dengan presisi 80 bit secara default, yang berarti bahwa operasi akan dibulatkan menjadi 80 bit yang menyebabkan pembulatan ganda terjadi ketika nilai pada akhirnya direpresentasikan sebagai
//
// 32/64 nilai bit float.Untuk mengatasinya, kata kontrol FPU dapat diatur agar penghitungan dilakukan dengan presisi yang diinginkan.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// Struktur yang digunakan untuk mempertahankan nilai asli kata kontrol FPU, sehingga dapat dipulihkan saat struktur tersebut dijatuhkan.
    ///
    ///
    /// FPU x87 adalah register 16-bit yang bidangnya adalah sebagai berikut:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// Dokumentasi untuk semua bidang tersedia di Panduan Pengembang Perangkat Lunak Arsitektur IA-32 (Volume 1).
    ///
    /// Satu-satunya bidang yang relevan untuk kode berikut adalah PC, Kontrol Presisi.
    /// Bidang ini menentukan ketepatan operasi yang dilakukan oleh FPU.
    /// Ini dapat diatur ke:
    ///  - 0b00, presisi tunggal, 32-bit
    ///  - 0b10, presisi ganda yaitu 64-bit
    ///  - 0b11, presisi diperpanjang ganda yaitu 80-bit (status default) Nilai 0b01 dicadangkan dan tidak boleh digunakan.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // KEAMANAN: instruksi `fldcw` telah diaudit agar dapat bekerja dengan benar
        // `u16` apapun
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: Kami menggunakan sintaks ATT untuk mendukung LLVM 8 dan LLVM 9.
                options(att_syntax, nostack),
            )
        }
    }

    /// Menyetel bidang presisi FPU ke `T` dan mengembalikan `FPUControlWord`.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Hitung nilai bidang Kontrol Presisi yang sesuai untuk `T`.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 bit
            8 => 0x0200, // 64 bit
            _ => 0x0300, // default, 80 bit
        };

        // Dapatkan nilai asli dari kata kontrol untuk memulihkannya nanti, ketika struktur `FPUControlWord` dihilangkan SAFETY: instruksi `fnstcw` telah diaudit agar dapat bekerja dengan benar dengan `u16` manapun
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: Kami menggunakan sintaks ATT untuk mendukung LLVM 8 dan LLVM 9.
                options(att_syntax, nostack),
            )
        }

        // Atur kata kontrol ke presisi yang diinginkan.
        // Ini dicapai dengan menutupi presisi lama (bit 8 dan 9, 0x300) dan menggantinya dengan bendera presisi yang dihitung di atas.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// Jalur cepat Bellerophon menggunakan bilangan bulat dan pelampung seukuran mesin.
///
/// Ini diekstraksi menjadi fungsi terpisah sehingga dapat dicoba sebelum membangun bignum.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Kami membandingkan nilai pastinya dengan MAX_SIG mendekati akhir, ini hanyalah penolakan yang cepat dan murah (dan juga membebaskan kode lainnya dari kekhawatiran tentang kekurangan aliran).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // Jalur cepat sangat bergantung pada aritmatika yang dibulatkan ke jumlah bit yang benar tanpa pembulatan perantara.
    // Pada x86 (tanpa SSE atau SSE2), ketepatan tumpukan FPU x87 harus diubah sehingga langsung membulatkan ke bit 64/32.
    // Fungsi `set_precision` menangani pengaturan presisi pada arsitektur yang memerlukan pengaturan dengan mengubah status global (seperti kata kontrol FPU x87).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // Kasus e <0 tidak dapat dilipat ke dalam branch lainnya.
    // Kekuatan negatif menghasilkan bagian pecahan berulang dalam biner, yang dibulatkan, yang menyebabkan kesalahan nyata (dan terkadang cukup signifikan!) Pada hasil akhir.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// Algoritma Bellerophon adalah kode sepele yang dibenarkan oleh analisis numerik non-trivial.
///
/// Ini membulatkan `` f '' ke float dengan 64 bit signifikan dan mengalikannya dengan perkiraan terbaik `10^e` (dalam format floating point yang sama).Ini cukup sering untuk mendapatkan hasil yang benar.
/// Namun, jika hasilnya mendekati setengah antara dua float (ordinary) yang berdekatan, kesalahan pembulatan gabungan dari perkalian dua aproksimasi berarti hasilnya mungkin meleset beberapa bit.
/// Ketika ini terjadi, Algoritma R iteratif memperbaiki segalanya.
///
/// Tangan-bergelombang "close to halfway" dibuat presisi dengan analisis numerik di koran.
/// Dalam kata-kata Clinger:
///
/// > Slop, diekspresikan dalam unit bit paling signifikan, adalah batas inklusif untuk kesalahan
/// > terakumulasi selama kalkulasi floating point dari pendekatan ke f * 10 ^ e.(Slop adalah
/// > bukan batasan untuk kesalahan sebenarnya, tetapi membatasi perbedaan antara pendekatan z dan
/// > perkiraan terbaik yang menggunakan p bit signifikan.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // Kasus abs(e) <log5(2^N) ada di fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // Apakah slop cukup besar untuk membuat perbedaan saat dibulatkan ke n bit?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// Algoritme berulang yang meningkatkan perkiraan titik mengambang `f * 10^e`.
///
/// Setiap iterasi membuat satu unit di tempat terakhir lebih dekat, yang tentu saja membutuhkan waktu sangat lama untuk menyatu jika `z0` mati sedikit.
/// Untungnya, ketika digunakan sebagai fallback untuk Bellerophon, perkiraan awal paling banyak satu ULP.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Temukan bilangan bulat positif `x`, `y` sehingga `x / y` persis `(f *10^e) / (m* 2^k)`.
        // Ini tidak hanya menghindari berurusan dengan tanda-tanda `e` dan `k`, kami juga menghilangkan kekuatan dua yang umum untuk `10^e` dan `2^k` untuk membuat angka-angka lebih kecil.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Ini ditulis agak canggung karena bignum kami tidak mendukung angka negatif, jadi kami menggunakan informasi tanda + nilai absolut.
        // Perkalian dengan m_digits tidak bisa meluap.
        // Jika `x` atau `y` cukup besar sehingga kita perlu mengkhawatirkan overflow, maka `make_ratio` juga cukup besar sehingga `make_ratio` telah mengurangi pecahan dengan faktor 2 ^ 64 atau lebih.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Tidak perlu x lagi, simpan clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Masih butuh y, buat salinannya.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// Mengingat `x = f` dan `y = m` di mana `f` mewakili digit desimal masukan seperti biasa dan `m` adalah signifikansi pendekatan floating point, buat rasio `x / y` sama dengan `(f *10^e) / (m* 2^k)`, mungkin dikurangi dengan pangkat dua yang keduanya memiliki kesamaan.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, kecuali bahwa kita mengurangi pecahan dengan beberapa pangkat dua.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m Ini tidak dapat meluap karena memerlukan `e` positif dan `k` negatif, yang hanya dapat terjadi untuk nilai yang sangat dekat dengan 1, yang berarti bahwa `e` dan `k` akan relatif kecil.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Ini juga tidak bisa meluap, lihat di atas.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), sekali lagi dikurangi dengan pangkat dua.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Secara konseptual, Algoritma M adalah cara paling sederhana untuk mengubah desimal menjadi float.
///
/// Kami membentuk rasio yang sama dengan `f * 10^e`, lalu melempar pangkat dua sampai memberikan signifikansi float yang valid.
/// Eksponen biner `k` adalah berapa kali kita mengalikan pembilang atau penyebut dengan dua, yaitu, setiap saat `f *10^e` sama dengan `(u / v)* 2^k`.
/// Ketika kita sudah menemukan signifikansinya, kita hanya perlu membulatkannya dengan memeriksa sisa pembagian, yang dilakukan di fungsi helper lebih jauh di bawah.
///
///
/// Algoritme ini sangat lambat, bahkan dengan pengoptimalan yang dijelaskan di `quick_start()`.
/// Namun, ini yang paling sederhana dari algoritme untuk beradaptasi untuk hasil overflow, underflow, dan subnormal.
/// Implementasi ini mengambil alih ketika Bellerophon dan Algorithm R kewalahan.
/// Mendeteksi underflow dan overflow mudah: Rasio masih belum signifikan dalam kisaran, namun eksponen minimum/maximum telah tercapai.
/// Dalam kasus overflow, kami hanya mengembalikan infinity.
///
/// Menangani underflow dan subnormal lebih rumit.
/// Satu masalah besar adalah, dengan eksponen minimum, rasio mungkin masih terlalu besar untuk sebuah signifikan.
/// Lihat underflow() untuk detailnya.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // FIXME kemungkinan pengoptimalan: menggeneralisasi big_to_fp sehingga kita dapat melakukan yang setara dengan fp_to_float(big_to_fp(u)) di sini, hanya tanpa pembulatan ganda.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Kita harus berhenti pada eksponen minimum, jika kita menunggu sampai `k < T::MIN_EXP_INT`, maka kita akan kehilangan faktor dua.
            // Sayangnya ini berarti kita harus membuat kasus khusus bilangan normal dengan eksponen minimum.
            // FIXME menemukan formulasi yang lebih elegan, tetapi jalankan tes `tiny-pow10` untuk memastikan bahwa formulasi tersebut benar!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Lewati sebagian besar iterasi Algoritma M dengan memeriksa panjang bit.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // Panjang bit adalah perkiraan dari dua logaritma basis, dan log(u / v) = log(u), log(v).
    // Estimasi meleset paling banyak 1, tetapi selalu di bawah estimasi, sehingga error pada log(u) dan log(v) memiliki tanda yang sama dan dibatalkan (jika keduanya besar).
    // Oleh karena itu, kesalahan untuk log(u / v) paling banyak juga.
    // Rasio target adalah salah satu di mana u/v berada dalam kisaran signifikan.Jadi kondisi terminasi kami adalah log2(u / v) menjadi bit signifikan, plus/minus satu.
    // FIXME Melihat bit kedua dapat meningkatkan perkiraan dan menghindari beberapa divisi lagi.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Underflow atau subnormal.Serahkan saja ke fungsi utama.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Meluap.Serahkan saja ke fungsi utama.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // Rasio bukanlah signifikan dalam kisaran dengan eksponen minimum, jadi kita perlu membulatkan bit berlebih dan menyesuaikan eksponennya.
    // Nilai sebenarnya sekarang terlihat seperti ini:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q trunc.(diwakili oleh rem)
    //
    // Oleh karena itu, ketika bit yang dibulatkan adalah!= 0.5 ULP, mereka memutuskan pembulatannya sendiri.
    // Jika sama dan sisanya bukan nol, nilainya masih perlu dibulatkan.
    // Hanya ketika bit-bit yang dibulatkan adalah 1/2 dan sisanya adalah nol, kita memiliki situasi setengah-ke-genap.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Putaran-ke-genap biasa, dikaburkan dengan harus membulatkan berdasarkan sisa divisi.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}