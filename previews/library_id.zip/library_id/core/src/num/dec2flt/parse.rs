//! Memvalidasi dan mendekomposisi string desimal dalam bentuk:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! Dengan kata lain, sintaks floating-point standar, dengan dua pengecualian: Tanpa tanda, dan tanpa penanganan "inf" dan "NaN".Ini ditangani oleh fungsi driver (super::dec2flt).
//!
//! Meskipun mengenali input yang valid relatif mudah, modul ini juga harus menolak variasi tidak valid yang tak terhitung jumlahnya, tidak pernah panic, dan melakukan banyak pemeriksaan yang diandalkan modul lain agar tidak panic (atau overflow) pada gilirannya.
//!
//! Lebih buruk lagi, semua yang terjadi dalam satu masukan.
//! Jadi, berhati-hatilah saat memodifikasi apa pun, dan periksa kembali dengan modul lainnya.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// Bagian menarik dari string desimal.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// Eksponen desimal, dijamin memiliki kurang dari 18 digit desimal.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// Memeriksa apakah string input adalah bilangan floating point yang valid dan jika demikian, temukan bagian integral, bagian pecahan, dan eksponen di dalamnya.
/// Tidak menangani tanda.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // Tidak ada digit sebelum 'e'
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // Kami membutuhkan setidaknya satu digit sebelum atau sesudah titik.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // Menelusuri sampah setelah bagian pecahan
            }
        }
        _ => Invalid, // Mengekor sampah setelah string digit pertama
    }
}

/// Mengukir angka desimal hingga karakter non-digit pertama.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// Ekstraksi eksponen dan pemeriksaan kesalahan.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // Mengekor sampah setelah eksponen
    }
    if number.is_empty() {
        return Invalid; // Eksponen kosong
    }
    // Pada titik ini, kita pasti memiliki string digit yang valid.Mungkin terlalu lama untuk dimasukkan ke dalam `i64`, tetapi jika sebesar itu, inputnya pasti nol atau tak terbatas.
    // Karena setiap nol dalam angka desimal hanya menyesuaikan eksponen dengan +/-1, pada exp=10 ^ 18 input harus 17 exabyte (!) angka nol untuk mendekati finit.
    //
    // Ini bukanlah kasus penggunaan yang perlu kami tangani.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}