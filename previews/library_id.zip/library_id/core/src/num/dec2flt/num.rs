//! Fungsi utilitas untuk bignum yang tidak terlalu masuk akal untuk diubah menjadi metode.

// FIXME Nama modul ini agak disayangkan, karena modul lain juga mengimpor `core::num`.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Uji apakah memotong semua bit yang kurang signifikan dari `ones_place` menyebabkan kesalahan relatif kurang, sama, atau lebih besar dari 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Jika semua bit yang tersisa adalah nol, itu= 0.5 ULP, jika tidak> 0.5 Jika tidak ada bit lagi (half_bit==0), di bawah ini juga mengembalikan Equal dengan benar.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Mengonversi string ASCII yang hanya berisi angka desimal menjadi `u64`.
///
/// Tidak melakukan pemeriksaan overflow atau karakter tidak valid, jadi jika pemanggil tidak hati-hati, hasilnya adalah palsu dan bisa panic (meskipun tidak akan `unsafe`).
/// Selain itu, string kosong diperlakukan sebagai nol.
/// Fungsi ini ada karena
///
/// 1. menggunakan `FromStr` pada `&[u8]` membutuhkan `from_utf8_unchecked`, yang berarti buruk, dan
/// 2. menyatukan hasil dari `integral.parse()` dan `fractional.parse()` lebih rumit daripada keseluruhan fungsi ini.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Mengonversi string digit ASCII menjadi bignum.
///
/// Seperti `from_str_unchecked`, fungsi ini bergantung pada parser untuk menyingkirkan non-digit.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Membuka bignum menjadi bilangan bulat 64 bit.Panics jika angkanya terlalu besar.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Mengekstrak berbagai bit.

/// Indeks 0 adalah bit yang paling tidak signifikan dan kisarannya setengah terbuka seperti biasa.
/// Panics jika diminta untuk mengekstrak lebih banyak bit daripada yang sesuai ke dalam tipe yang dikembalikan.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}