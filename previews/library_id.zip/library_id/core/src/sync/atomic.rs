//! Jenis atom
//!
//! Tipe atom menyediakan komunikasi memori bersama primitif antar utas, dan merupakan blok penyusun dari tipe konkuren lainnya.
//!
//! Modul ini mendefinisikan versi atom dari sejumlah pilihan tipe primitif, termasuk [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`], dll.
//! Jenis atom menampilkan operasi yang, bila digunakan dengan benar, menyinkronkan pembaruan antar utas.
//!
//! Setiap metode mengambil [`Ordering`] yang mewakili kekuatan penghalang memori untuk operasi itu.Urutan ini sama dengan [C++20 atomic orderings][1].Untuk informasi lebih lanjut, lihat [nomicon][2].
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! Variabel atom aman untuk dibagikan antar utas (mereka menerapkan [`Sync`]) tetapi mereka sendiri tidak menyediakan mekanisme untuk berbagi dan mengikuti [threading model](../../../std/thread/index.html#the-threading-model) dari Rust.
//!
//! Cara paling umum untuk membagikan variabel atom adalah dengan memasukkannya ke dalam [`Arc`][arc] (penunjuk bersama yang dihitung referensi-atom).
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! Jenis atom dapat disimpan dalam variabel statis, diinisialisasi menggunakan penginisialisasi konstan seperti [`AtomicBool::new`].Statika atom sering digunakan untuk inisialisasi global yang lambat.
//!
//! # Portability
//!
//! Semua tipe atom dalam modul ini dijamin menjadi [lock-free] jika tersedia.Ini berarti mereka tidak memperoleh mutex global secara internal.Jenis atom dan operasi tidak dijamin bebas menunggu.
//! Ini berarti bahwa operasi seperti `fetch_or` dapat diimplementasikan dengan loop bandingkan dan tukar.
//!
//! Operasi atom dapat diterapkan pada lapisan instruksi dengan atomika berukuran lebih besar.Misalnya, beberapa platform menggunakan instruksi atom 4-byte untuk mengimplementasikan `AtomicI8`.
//! Perhatikan bahwa emulasi ini seharusnya tidak berdampak pada kebenaran kode, itu hanya sesuatu yang harus diperhatikan.
//!
//! Jenis atom dalam modul ini mungkin tidak tersedia di semua platform.Jenis atom di sini semuanya tersedia secara luas, dan umumnya dapat diandalkan.Beberapa pengecualian penting adalah:
//!
//! * PowerPC dan platform MIPS dengan pointer 32-bit tidak memiliki tipe `AtomicU64` atau `AtomicI64`.
//! * ARM platform seperti `armv5te` yang bukan untuk Linux hanya menyediakan operasi `load` dan `store`, dan tidak mendukung operasi Bandingkan dan Tukar (CAS), seperti `swap`, `fetch_add`, dll.
//! Selain itu di Linux, operasi CAS ini diimplementasikan melalui [operating system support], yang mungkin disertai dengan penalti kinerja.
//! * ARM target dengan `thumbv6m` hanya menyediakan operasi `load` dan `store`, dan tidak mendukung operasi Bandingkan dan Tukar (CAS), seperti `swap`, `fetch_add`, dll.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! Perhatikan bahwa platform future dapat ditambahkan yang juga tidak memiliki dukungan untuk beberapa operasi atom.Kode portabel yang maksimal perlu berhati-hati tentang jenis atom yang digunakan.
//! `AtomicUsize` dan `AtomicIsize` umumnya paling portabel, tetapi meskipun demikian mereka tidak tersedia di semua tempat.
//! Untuk referensi, pustaka `std` memerlukan atomics berukuran penunjuk, meskipun `core` tidak.
//!
//! Saat ini Anda harus menggunakan `#[cfg(target_arch)]` terutama untuk mengompilasi kode secara bersyarat dengan atomics.Ada juga `#[cfg(target_has_atomic)]` yang tidak stabil yang mungkin distabilkan di future.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! Spinlock sederhana:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // Tunggu utas lainnya membuka kunci
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! Pertahankan hitungan global utas langsung:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// Jenis boolean yang dapat dibagikan dengan aman di antara utas.
///
/// Tipe ini memiliki representasi dalam memori yang sama dengan [`bool`].
///
/// **Catatan**: Jenis ini hanya tersedia pada platform yang mendukung beban atom dan penyimpanan `u8`.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// Membuat `AtomicBool` yang diinisialisasi ke `false`.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// Pengiriman secara implisit diimplementasikan untuk AtomicBool.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// Jenis penunjuk mentah yang dapat dibagikan dengan aman di antara utas.
///
/// Tipe ini memiliki representasi dalam memori yang sama dengan `*mut T`.
///
/// **Catatan**: Jenis ini hanya tersedia pada platform yang mendukung beban atom dan penyimpanan pointer.
/// Ukurannya tergantung pada ukuran penunjuk target.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// Membuat `AtomicPtr<T>` nol.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// Urutan memori atom
///
/// Urutan memori menentukan cara operasi atom menyinkronkan memori.
/// Pada [`Ordering::Relaxed`] terlemahnya, hanya memori yang tersentuh langsung oleh operasi yang disinkronkan.
/// Di sisi lain, pasangan penyimpanan-beban operasi [`Ordering::SeqCst`] menyinkronkan memori lain sambil mempertahankan urutan total operasi tersebut di semua utas.
///
///
/// Urutan memori Rust adalah [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order).
///
/// Untuk informasi lebih lanjut, lihat [nomicon].
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// Tidak ada batasan pemesanan, hanya operasi atom.
    ///
    /// Sesuai dengan [`memory_order_relaxed`] di C++ 20.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// Saat digabungkan dengan penyimpanan, semua operasi sebelumnya akan dipesan sebelum pemuatan nilai ini dengan pemesanan [`Acquire`] (atau lebih kuat).
    ///
    /// Secara khusus, semua penulisan sebelumnya menjadi terlihat oleh semua utas yang melakukan pemuatan [`Acquire`] (atau lebih kuat) dari nilai ini.
    ///
    /// Perhatikan bahwa menggunakan pengurutan ini untuk operasi yang menggabungkan beban dan penyimpanan mengarah ke operasi beban [`Relaxed`]!
    ///
    /// Pemesanan ini hanya berlaku untuk operasi yang dapat melakukan penyimpanan.
    ///
    /// Sesuai dengan [`memory_order_release`] di C++ 20.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// Ketika digabungkan dengan beban, jika nilai yang dimuat ditulis oleh operasi penyimpanan dengan pemesanan [`Release`] (atau lebih kuat), maka semua operasi selanjutnya akan dipesan setelah penyimpanan itu.
    /// Secara khusus, semua muatan berikutnya akan melihat data ditulis sebelum disimpan.
    ///
    /// Perhatikan bahwa menggunakan pengurutan ini untuk operasi yang menggabungkan beban dan penyimpanan mengarah ke operasi penyimpanan [`Relaxed`]!
    ///
    /// Pengurutan ini hanya berlaku untuk operasi yang dapat melakukan beban.
    ///
    /// Sesuai dengan [`memory_order_acquire`] di C++ 20.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// Memiliki efek [`Acquire`] dan [`Release`] secara bersamaan:
    /// Untuk beban menggunakan pengurutan [`Acquire`].Untuk toko menggunakan pemesanan [`Release`].
    ///
    /// Perhatikan bahwa dalam kasus `compare_and_swap`, ada kemungkinan bahwa operasi tersebut akhirnya tidak melakukan penyimpanan apa pun dan karena itu hanya memesan [`Acquire`].
    ///
    /// Namun, `AcqRel` tidak akan pernah melakukan akses [`Relaxed`].
    ///
    /// Pemesanan ini hanya berlaku untuk operasi yang menggabungkan beban dan penyimpanan.
    ///
    /// Sesuai dengan [`memory_order_acq_rel`] di C++ 20.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// Seperti [`Acquire`]/[`Release`]/[`AcqRel`](masing-masing untuk operasi muat, simpan, dan muat dengan penyimpanan) dengan jaminan tambahan bahwa semua utas melihat semua operasi yang konsisten secara berurutan dalam urutan yang sama .
    ///
    ///
    /// Sesuai dengan [`memory_order_seq_cst`] di C++ 20.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// [`AtomicBool`] diinisialisasi ke `false`.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// Membuat `AtomicBool` baru.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// Mengembalikan referensi yang bisa berubah ke [`bool`] yang mendasari.
    ///
    /// Ini aman karena referensi yang dapat berubah menjamin bahwa tidak ada utas lain yang mengakses data atom secara bersamaan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // KEAMANAN: referensi yang bisa berubah menjamin kepemilikan yang unik.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// Dapatkan akses atomik ke `&mut bool`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // KEAMANAN: referensi yang bisa berubah menjamin kepemilikan unik, dan
        // keselarasan `bool` dan `Self` adalah 1.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// Mengkonsumsi atom dan mengembalikan nilai yang terkandung.
    ///
    /// Ini aman karena meneruskan `self` berdasarkan nilai menjamin bahwa tidak ada utas lain yang mengakses data atom secara bersamaan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// Memuat nilai dari bool.
    ///
    /// `load` mengambil argumen [`Ordering`] yang menjelaskan urutan memori dari operasi ini.
    /// Nilai yang memungkinkan adalah [`SeqCst`], [`Acquire`] dan [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics jika `order` adalah [`Release`] atau [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // KEAMANAN: semua data race dicegah oleh atomic intrinsics dan raw
        // pointer yang diteruskan valid karena kami mendapatkannya dari referensi.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// Menyimpan nilai ke dalam bool.
    ///
    /// `store` mengambil argumen [`Ordering`] yang menjelaskan urutan memori dari operasi ini.
    /// Nilai yang memungkinkan adalah [`SeqCst`], [`Release`] dan [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics jika `order` adalah [`Acquire`] atau [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // KEAMANAN: semua data race dicegah oleh atomic intrinsics dan raw
        // pointer yang diteruskan valid karena kami mendapatkannya dari referensi.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// Menyimpan nilai ke dalam bool, mengembalikan nilai sebelumnya.
    ///
    /// `swap` mengambil argumen [`Ordering`] yang menjelaskan urutan memori dari operasi ini.Semua mode pemesanan dimungkinkan.
    /// Perhatikan bahwa menggunakan [`Acquire`] membuat bagian penyimpanan dari operasi ini [`Relaxed`], dan menggunakan [`Release`] membuat bagian beban menjadi [`Relaxed`].
    ///
    ///
    /// **Note:** Metode ini hanya tersedia di platform yang mendukung operasi atom di `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // KEAMANAN: data race dicegah oleh atomic intrinsics.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// Menyimpan nilai ke dalam [`bool`] jika nilai saat ini sama dengan nilai `current`.
    ///
    /// Nilai kembali selalu nilai sebelumnya.Jika sama dengan `current`, maka nilainya telah diperbarui.
    ///
    /// `compare_and_swap` juga mengambil argumen [`Ordering`] yang menjelaskan urutan memori untuk operasi ini.
    /// Perhatikan bahwa meskipun menggunakan [`AcqRel`], operasi mungkin gagal dan karenanya hanya menjalankan pemuatan `Acquire`, tetapi tidak memiliki semantik `Release`.
    /// Menggunakan [`Acquire`] membuat penyimpanan bagian dari operasi ini [`Relaxed`] jika itu terjadi, dan menggunakan [`Release`] membuat bagian beban [`Relaxed`].
    ///
    /// **Note:** Metode ini hanya tersedia di platform yang mendukung operasi atom di `u8`.
    ///
    /// # Bermigrasi ke `compare_exchange` dan `compare_exchange_weak`
    ///
    /// `compare_and_swap` setara dengan `compare_exchange` dengan pemetaan berikut untuk urutan memori:
    ///
    /// Asli |Sukses |Kegagalan
    /// -------- | ------- | -------
    /// Santai |Santai |Santai Memperoleh |Dapatkan |Memperoleh Rilis |Rilis |Santai AcqRel |AcqRel |Akuisisi SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` dibiarkan gagal secara palsu bahkan ketika perbandingan berhasil, yang memungkinkan kompiler untuk menghasilkan kode assembly yang lebih baik ketika bandingkan dan swap digunakan dalam satu putaran.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Menyimpan nilai ke dalam [`bool`] jika nilai saat ini sama dengan nilai `current`.
    ///
    /// Nilai yang dikembalikan adalah hasil yang menunjukkan apakah nilai baru telah ditulis dan berisi nilai sebelumnya.
    /// Jika berhasil, nilai ini dijamin sama dengan `current`.
    ///
    /// `compare_exchange` membutuhkan dua argumen [`Ordering`] untuk menjelaskan urutan memori dari operasi ini.
    /// `success` menjelaskan urutan yang diperlukan untuk operasi baca-ubah-tulis yang terjadi jika perbandingan dengan `current` berhasil.
    /// `failure` menjelaskan urutan yang diperlukan untuk operasi beban yang terjadi saat perbandingan gagal.
    /// Menggunakan [`Acquire`] sebagai pemesanan sukses menjadikan toko bagian dari operasi ini [`Relaxed`], dan menggunakan [`Release`] membuat berhasil memuat [`Relaxed`].
    ///
    /// Pengurutan yang gagal hanya bisa [`SeqCst`], [`Acquire`] atau [`Relaxed`] dan harus setara atau lebih lemah dari pengurutan yang berhasil.
    ///
    /// **Note:** Metode ini hanya tersedia di platform yang mendukung operasi atom di `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // KEAMANAN: data race dicegah oleh atomic intrinsics.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Menyimpan nilai ke dalam [`bool`] jika nilai saat ini sama dengan nilai `current`.
    ///
    /// Tidak seperti [`AtomicBool::compare_exchange`], fungsi ini dibiarkan gagal secara semu bahkan jika perbandingan berhasil, yang dapat menghasilkan kode yang lebih efisien pada beberapa platform.
    ///
    /// Nilai yang dikembalikan adalah hasil yang menunjukkan apakah nilai baru telah ditulis dan berisi nilai sebelumnya.
    ///
    /// `compare_exchange_weak` membutuhkan dua argumen [`Ordering`] untuk menjelaskan urutan memori dari operasi ini.
    /// `success` menjelaskan urutan yang diperlukan untuk operasi baca-ubah-tulis yang terjadi jika perbandingan dengan `current` berhasil.
    /// `failure` menjelaskan urutan yang diperlukan untuk operasi beban yang terjadi saat perbandingan gagal.
    /// Menggunakan [`Acquire`] sebagai pemesanan sukses menjadikan toko bagian dari operasi ini [`Relaxed`], dan menggunakan [`Release`] membuat berhasil memuat [`Relaxed`].
    /// Pengurutan yang gagal hanya bisa [`SeqCst`], [`Acquire`] atau [`Relaxed`] dan harus setara atau lebih lemah dari pengurutan yang berhasil.
    ///
    /// **Note:** Metode ini hanya tersedia di platform yang mendukung operasi atom di `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // KEAMANAN: data race dicegah oleh atomic intrinsics.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// "and" logis dengan nilai boolean.
    ///
    /// Melakukan operasi logika "and" pada nilai saat ini dan argumen `val`, dan menyetel nilai baru ke hasil.
    ///
    /// Mengembalikan nilai sebelumnya.
    ///
    /// `fetch_and` mengambil argumen [`Ordering`] yang menjelaskan urutan memori dari operasi ini.Semua mode pemesanan dimungkinkan.
    /// Perhatikan bahwa menggunakan [`Acquire`] membuat bagian penyimpanan dari operasi ini [`Relaxed`], dan menggunakan [`Release`] membuat bagian beban menjadi [`Relaxed`].
    ///
    ///
    /// **Note:** Metode ini hanya tersedia di platform yang mendukung operasi atom di `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // KEAMANAN: data race dicegah oleh atomic intrinsics.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// "nand" logis dengan nilai boolean.
    ///
    /// Melakukan operasi logika "nand" pada nilai saat ini dan argumen `val`, dan menyetel nilai baru ke hasil.
    ///
    /// Mengembalikan nilai sebelumnya.
    ///
    /// `fetch_nand` mengambil argumen [`Ordering`] yang menjelaskan urutan memori dari operasi ini.Semua mode pemesanan dimungkinkan.
    /// Perhatikan bahwa menggunakan [`Acquire`] membuat bagian penyimpanan dari operasi ini [`Relaxed`], dan menggunakan [`Release`] membuat bagian beban menjadi [`Relaxed`].
    ///
    ///
    /// **Note:** Metode ini hanya tersedia di platform yang mendukung operasi atom di `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // Kami tidak dapat menggunakan atomic_nand di sini karena dapat menghasilkan bool dengan nilai yang tidak valid.
        // Ini terjadi karena operasi atom dilakukan dengan integer 8-bit secara internal, yang akan mengatur 7 bit teratas.
        //
        // Jadi kami hanya menggunakan fetch_xor atau swap sebagai gantinya.
        if val {
            // ! (x&true)== !x Kita harus membalik bool.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&false)==true Kita harus mengatur bool menjadi true.
            //
            self.swap(true, order)
        }
    }

    /// "or" logis dengan nilai boolean.
    ///
    /// Melakukan operasi logika "or" pada nilai saat ini dan argumen `val`, dan menyetel nilai baru ke hasil.
    ///
    /// Mengembalikan nilai sebelumnya.
    ///
    /// `fetch_or` mengambil argumen [`Ordering`] yang menjelaskan urutan memori dari operasi ini.Semua mode pemesanan dimungkinkan.
    /// Perhatikan bahwa menggunakan [`Acquire`] membuat bagian penyimpanan dari operasi ini [`Relaxed`], dan menggunakan [`Release`] membuat bagian beban menjadi [`Relaxed`].
    ///
    ///
    /// **Note:** Metode ini hanya tersedia di platform yang mendukung operasi atom di `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // KEAMANAN: data race dicegah oleh atomic intrinsics.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// "xor" logis dengan nilai boolean.
    ///
    /// Melakukan operasi logika "xor" pada nilai saat ini dan argumen `val`, dan menyetel nilai baru ke hasil.
    ///
    /// Mengembalikan nilai sebelumnya.
    ///
    /// `fetch_xor` mengambil argumen [`Ordering`] yang menjelaskan urutan memori dari operasi ini.Semua mode pemesanan dimungkinkan.
    /// Perhatikan bahwa menggunakan [`Acquire`] membuat bagian penyimpanan dari operasi ini [`Relaxed`], dan menggunakan [`Release`] membuat bagian beban menjadi [`Relaxed`].
    ///
    ///
    /// **Note:** Metode ini hanya tersedia di platform yang mendukung operasi atom di `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // KEAMANAN: data race dicegah oleh atomic intrinsics.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// Mengembalikan penunjuk yang bisa berubah ke [`bool`] yang mendasari.
    ///
    /// Melakukan pembacaan dan penulisan non-atom pada bilangan bulat yang dihasilkan dapat menjadi perlombaan data.
    /// Metode ini sebagian besar berguna untuk FFI, di mana tanda tangan fungsi dapat menggunakan `*mut bool`, bukan `&AtomicBool`.
    ///
    /// Mengembalikan penunjuk `*mut` dari referensi bersama ke atom ini aman karena jenis atom bekerja dengan mutabilitas interior.
    /// Semua modifikasi atom mengubah nilai melalui referensi bersama, dan dapat melakukannya dengan aman selama mereka menggunakan operasi atom.
    /// Setiap penggunaan pointer mentah yang dikembalikan memerlukan blok `unsafe` dan masih harus menjunjung tinggi batasan yang sama: operasi di atasnya harus atomic.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// Mengambil nilai, dan menerapkan fungsi padanya yang mengembalikan nilai baru opsional.Mengembalikan `Result` dari `Ok(previous_value)` jika fungsi mengembalikan `Some(_)`, jika tidak `Err(previous_value)`.
    ///
    /// Note: Ini mungkin memanggil fungsi beberapa kali jika nilai telah diubah dari utas lain untuk sementara, selama fungsi mengembalikan `Some(_)`, tetapi fungsi tersebut hanya akan diterapkan sekali ke nilai yang disimpan.
    ///
    ///
    /// `fetch_update` membutuhkan dua argumen [`Ordering`] untuk menjelaskan urutan memori dari operasi ini.
    /// Yang pertama menjelaskan urutan yang diperlukan ketika operasi akhirnya berhasil, sedangkan yang kedua menjelaskan urutan beban yang diperlukan.
    /// Ini sesuai dengan urutan keberhasilan dan kegagalan masing-masing [`AtomicBool::compare_exchange`].
    ///
    /// Menggunakan [`Acquire`] sebagai pemesanan sukses membuat bagian penyimpanan dari operasi ini [`Relaxed`], dan menggunakan [`Release`] membuat pemuatan akhir yang berhasil [`Relaxed`].
    /// Urutan beban (failed) hanya boleh [`SeqCst`], [`Acquire`] atau [`Relaxed`] dan harus setara atau lebih lemah dari urutan sukses.
    ///
    /// **Note:** Metode ini hanya tersedia di platform yang mendukung operasi atom di `u8`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// Membuat `AtomicPtr` baru.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// Mengembalikan referensi yang bisa berubah ke penunjuk yang mendasarinya.
    ///
    /// Ini aman karena referensi yang dapat berubah menjamin bahwa tidak ada utas lain yang mengakses data atom secara bersamaan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// Dapatkan akses atom ke sebuah pointer.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - referensi yang bisa berubah menjamin kepemilikan unik.
        //  - keselarasan `*mut T` dan `Self` sama di semua platform yang didukung oleh rust, seperti yang diverifikasi di atas.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// Mengkonsumsi atom dan mengembalikan nilai yang terkandung.
    ///
    /// Ini aman karena meneruskan `self` berdasarkan nilai menjamin bahwa tidak ada utas lain yang mengakses data atom secara bersamaan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// Memuat nilai dari penunjuk.
    ///
    /// `load` mengambil argumen [`Ordering`] yang menjelaskan urutan memori dari operasi ini.
    /// Nilai yang memungkinkan adalah [`SeqCst`], [`Acquire`] dan [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics jika `order` adalah [`Release`] atau [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // KEAMANAN: data race dicegah oleh atomic intrinsics.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// Menyimpan nilai ke penunjuk.
    ///
    /// `store` mengambil argumen [`Ordering`] yang menjelaskan urutan memori dari operasi ini.
    /// Nilai yang memungkinkan adalah [`SeqCst`], [`Release`] dan [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics jika `order` adalah [`Acquire`] atau [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // KEAMANAN: data race dicegah oleh atomic intrinsics.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// Menyimpan nilai ke penunjuk, mengembalikan nilai sebelumnya.
    ///
    /// `swap` mengambil argumen [`Ordering`] yang menjelaskan urutan memori dari operasi ini.Semua mode pemesanan dimungkinkan.
    /// Perhatikan bahwa menggunakan [`Acquire`] membuat bagian penyimpanan dari operasi ini [`Relaxed`], dan menggunakan [`Release`] membuat bagian beban menjadi [`Relaxed`].
    ///
    ///
    /// **Note:** Metode ini hanya tersedia pada platform yang mendukung operasi atom pada pointer.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // KEAMANAN: data race dicegah oleh atomic intrinsics.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// Menyimpan nilai ke penunjuk jika nilai saat ini sama dengan nilai `current`.
    ///
    /// Nilai kembali selalu nilai sebelumnya.Jika sama dengan `current`, maka nilainya telah diperbarui.
    ///
    /// `compare_and_swap` juga mengambil argumen [`Ordering`] yang menjelaskan urutan memori untuk operasi ini.
    /// Perhatikan bahwa meskipun menggunakan [`AcqRel`], operasi mungkin gagal dan karenanya hanya menjalankan pemuatan `Acquire`, tetapi tidak memiliki semantik `Release`.
    /// Menggunakan [`Acquire`] membuat penyimpanan bagian dari operasi ini [`Relaxed`] jika itu terjadi, dan menggunakan [`Release`] membuat bagian beban [`Relaxed`].
    ///
    /// **Note:** Metode ini hanya tersedia pada platform yang mendukung operasi atom pada pointer.
    ///
    /// # Bermigrasi ke `compare_exchange` dan `compare_exchange_weak`
    ///
    /// `compare_and_swap` setara dengan `compare_exchange` dengan pemetaan berikut untuk urutan memori:
    ///
    /// Asli |Sukses |Kegagalan
    /// -------- | ------- | -------
    /// Santai |Santai |Santai Memperoleh |Dapatkan |Memperoleh Rilis |Rilis |Santai AcqRel |AcqRel |Akuisisi SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` dibiarkan gagal secara palsu bahkan ketika perbandingan berhasil, yang memungkinkan kompiler untuk menghasilkan kode assembly yang lebih baik ketika bandingkan dan swap digunakan dalam satu putaran.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Menyimpan nilai ke penunjuk jika nilai saat ini sama dengan nilai `current`.
    ///
    /// Nilai yang dikembalikan adalah hasil yang menunjukkan apakah nilai baru telah ditulis dan berisi nilai sebelumnya.
    /// Jika berhasil, nilai ini dijamin sama dengan `current`.
    ///
    /// `compare_exchange` membutuhkan dua argumen [`Ordering`] untuk menjelaskan urutan memori dari operasi ini.
    /// `success` menjelaskan urutan yang diperlukan untuk operasi baca-ubah-tulis yang terjadi jika perbandingan dengan `current` berhasil.
    /// `failure` menjelaskan urutan yang diperlukan untuk operasi beban yang terjadi saat perbandingan gagal.
    /// Menggunakan [`Acquire`] sebagai pemesanan sukses menjadikan toko bagian dari operasi ini [`Relaxed`], dan menggunakan [`Release`] membuat berhasil memuat [`Relaxed`].
    ///
    /// Pengurutan yang gagal hanya bisa [`SeqCst`], [`Acquire`] atau [`Relaxed`] dan harus setara atau lebih lemah dari pengurutan yang berhasil.
    ///
    /// **Note:** Metode ini hanya tersedia pada platform yang mendukung operasi atom pada pointer.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // KEAMANAN: data race dicegah oleh atomic intrinsics.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// Menyimpan nilai ke penunjuk jika nilai saat ini sama dengan nilai `current`.
    ///
    /// Tidak seperti [`AtomicPtr::compare_exchange`], fungsi ini dibiarkan gagal secara semu bahkan jika perbandingan berhasil, yang dapat menghasilkan kode yang lebih efisien pada beberapa platform.
    ///
    /// Nilai yang dikembalikan adalah hasil yang menunjukkan apakah nilai baru telah ditulis dan berisi nilai sebelumnya.
    ///
    /// `compare_exchange_weak` membutuhkan dua argumen [`Ordering`] untuk menjelaskan urutan memori dari operasi ini.
    /// `success` menjelaskan urutan yang diperlukan untuk operasi baca-ubah-tulis yang terjadi jika perbandingan dengan `current` berhasil.
    /// `failure` menjelaskan urutan yang diperlukan untuk operasi beban yang terjadi saat perbandingan gagal.
    /// Menggunakan [`Acquire`] sebagai pemesanan sukses menjadikan toko bagian dari operasi ini [`Relaxed`], dan menggunakan [`Release`] membuat berhasil memuat [`Relaxed`].
    /// Pengurutan yang gagal hanya bisa [`SeqCst`], [`Acquire`] atau [`Relaxed`] dan harus setara atau lebih lemah dari pengurutan yang berhasil.
    ///
    /// **Note:** Metode ini hanya tersedia pada platform yang mendukung operasi atom pada pointer.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // KEAMANAN: Intrinsik ini tidak aman karena beroperasi pada pointer mentah
        // tetapi kami tahu pasti bahwa penunjuk tersebut valid (kami baru saja mendapatkannya dari `UnsafeCell` yang kami miliki sebagai referensi) dan operasi atom itu sendiri memungkinkan kami untuk mengubah konten `UnsafeCell` dengan aman.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// Mengambil nilai, dan menerapkan fungsi padanya yang mengembalikan nilai baru opsional.Mengembalikan `Result` dari `Ok(previous_value)` jika fungsi mengembalikan `Some(_)`, jika tidak `Err(previous_value)`.
    ///
    /// Note: Ini mungkin memanggil fungsi beberapa kali jika nilai telah diubah dari utas lain untuk sementara, selama fungsi mengembalikan `Some(_)`, tetapi fungsi tersebut hanya akan diterapkan sekali ke nilai yang disimpan.
    ///
    ///
    /// `fetch_update` membutuhkan dua argumen [`Ordering`] untuk menjelaskan urutan memori dari operasi ini.
    /// Yang pertama menjelaskan urutan yang diperlukan ketika operasi akhirnya berhasil, sedangkan yang kedua menjelaskan urutan beban yang diperlukan.
    /// Ini sesuai dengan urutan keberhasilan dan kegagalan masing-masing [`AtomicPtr::compare_exchange`].
    ///
    /// Menggunakan [`Acquire`] sebagai pemesanan sukses membuat bagian penyimpanan dari operasi ini [`Relaxed`], dan menggunakan [`Release`] membuat pemuatan akhir yang berhasil [`Relaxed`].
    /// Urutan beban (failed) hanya boleh [`SeqCst`], [`Acquire`] atau [`Relaxed`] dan harus setara atau lebih lemah dari urutan sukses.
    ///
    /// **Note:** Metode ini hanya tersedia pada platform yang mendukung operasi atom pada pointer.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// Mengubah `bool` menjadi `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // Makro ini akhirnya tidak digunakan pada beberapa arsitektur.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// Jenis bilangan bulat yang dapat dibagikan dengan aman di antara utas.
        ///
        /// Tipe ini memiliki representasi dalam memori yang sama dengan tipe integer yang mendasari, [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// Untuk informasi lebih lanjut tentang perbedaan antara jenis atom dan jenis non-atom serta informasi tentang portabilitas jenis ini, silakan lihat [module-level documentation].
        ///
        ///
        /// **Note:** Jenis ini hanya tersedia pada platform yang mendukung beban atom dan penyimpanan [`
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// Bilangan bulat atom yang diinisialisasi ke `0`.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // Pengiriman diterapkan secara implisit.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// Membuat bilangan bulat atom baru.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// Mengembalikan referensi yang bisa berubah ke bilangan bulat yang mendasarinya.
            ///
            /// Ini aman karena referensi yang dapat berubah menjamin bahwa tidak ada utas lain yang mengakses data atom secara bersamaan.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// biarkan mut some_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq! (some_int, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - referensi yang bisa berubah menjamin kepemilikan unik.
                //  - keselarasan `$int_type` dan `Self` sama, seperti yang dijanjikan oleh $cfg_align dan diverifikasi di atas.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// Mengkonsumsi atom dan mengembalikan nilai yang terkandung.
            ///
            /// Ini aman karena meneruskan `self` berdasarkan nilai menjamin bahwa tidak ada utas lain yang mengakses data atom secara bersamaan.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// Memuat nilai dari bilangan bulat atom.
            ///
            /// `load` mengambil argumen [`Ordering`] yang menjelaskan urutan memori dari operasi ini.
            /// Nilai yang memungkinkan adalah [`SeqCst`], [`Acquire`] dan [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics jika `order` adalah [`Release`] atau [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // KEAMANAN: data race dicegah oleh atomic intrinsics.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// Menyimpan nilai ke dalam bilangan bulat atom.
            ///
            /// `store` mengambil argumen [`Ordering`] yang menjelaskan urutan memori dari operasi ini.
            ///  Nilai yang memungkinkan adalah [`SeqCst`], [`Release`] dan [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics jika `order` adalah [`Acquire`] atau [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // KEAMANAN: data race dicegah oleh atomic intrinsics.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// Menyimpan nilai ke dalam bilangan bulat atom, mengembalikan nilai sebelumnya.
            ///
            /// `swap` mengambil argumen [`Ordering`] yang menjelaskan urutan memori dari operasi ini.Semua mode pemesanan dimungkinkan.
            /// Perhatikan bahwa menggunakan [`Acquire`] membuat bagian penyimpanan dari operasi ini [`Relaxed`], dan menggunakan [`Release`] membuat bagian beban menjadi [`Relaxed`].
            ///
            ///
            /// **Catatan**: Metode ini hanya tersedia di platform yang mendukung operasi atom di
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // KEAMANAN: data race dicegah oleh atomic intrinsics.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// Menyimpan nilai ke dalam bilangan bulat atom jika nilai saat ini sama dengan nilai `current`.
            ///
            /// Nilai kembali selalu nilai sebelumnya.Jika sama dengan `current`, maka nilainya telah diperbarui.
            ///
            /// `compare_and_swap` juga mengambil argumen [`Ordering`] yang menjelaskan urutan memori untuk operasi ini.
            /// Perhatikan bahwa meskipun menggunakan [`AcqRel`], operasi mungkin gagal dan karenanya hanya menjalankan pemuatan `Acquire`, tetapi tidak memiliki semantik `Release`.
            ///
            /// Menggunakan [`Acquire`] membuat penyimpanan bagian dari operasi ini [`Relaxed`] jika itu terjadi, dan menggunakan [`Release`] membuat bagian beban [`Relaxed`].
            ///
            /// **Catatan**: Metode ini hanya tersedia di platform yang mendukung operasi atom di
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Bermigrasi ke `compare_exchange` dan `compare_exchange_weak`
            ///
            /// `compare_and_swap` setara dengan `compare_exchange` dengan pemetaan berikut untuk urutan memori:
            ///
            /// Asli |Sukses |Kegagalan
            /// -------- | ------- | -------
            /// Santai |Santai |Santai Memperoleh |Dapatkan |Memperoleh Rilis |Rilis |Santai AcqRel |AcqRel |Akuisisi SeqCst |SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` dibiarkan gagal secara palsu bahkan ketika perbandingan berhasil, yang memungkinkan kompiler untuk menghasilkan kode assembly yang lebih baik ketika bandingkan dan swap digunakan dalam satu putaran.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// Menyimpan nilai ke dalam bilangan bulat atom jika nilai saat ini sama dengan nilai `current`.
            ///
            /// Nilai yang dikembalikan adalah hasil yang menunjukkan apakah nilai baru telah ditulis dan berisi nilai sebelumnya.
            /// Jika berhasil, nilai ini dijamin sama dengan `current`.
            ///
            /// `compare_exchange` membutuhkan dua argumen [`Ordering`] untuk menjelaskan urutan memori dari operasi ini.
            /// `success` menjelaskan urutan yang diperlukan untuk operasi baca-ubah-tulis yang terjadi jika perbandingan dengan `current` berhasil.
            /// `failure` menjelaskan urutan yang diperlukan untuk operasi beban yang terjadi saat perbandingan gagal.
            /// Menggunakan [`Acquire`] sebagai pemesanan sukses menjadikan toko bagian dari operasi ini [`Relaxed`], dan menggunakan [`Release`] membuat berhasil memuat [`Relaxed`].
            ///
            /// Pengurutan yang gagal hanya bisa [`SeqCst`], [`Acquire`] atau [`Relaxed`] dan harus setara atau lebih lemah dari pengurutan yang berhasil.
            ///
            /// **Catatan**: Metode ini hanya tersedia di platform yang mendukung operasi atom di
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // KEAMANAN: data race dicegah oleh atomic intrinsics.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// Menyimpan nilai ke dalam bilangan bulat atom jika nilai saat ini sama dengan nilai `current`.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// fungsi ini dibiarkan gagal secara semu bahkan jika perbandingan berhasil, yang dapat menghasilkan kode yang lebih efisien pada beberapa platform.
            /// Nilai yang dikembalikan adalah hasil yang menunjukkan apakah nilai baru telah ditulis dan berisi nilai sebelumnya.
            ///
            /// `compare_exchange_weak` membutuhkan dua argumen [`Ordering`] untuk menjelaskan urutan memori dari operasi ini.
            /// `success` menjelaskan urutan yang diperlukan untuk operasi baca-ubah-tulis yang terjadi jika perbandingan dengan `current` berhasil.
            /// `failure` menjelaskan urutan yang diperlukan untuk operasi beban yang terjadi saat perbandingan gagal.
            /// Menggunakan [`Acquire`] sebagai pemesanan sukses menjadikan toko bagian dari operasi ini [`Relaxed`], dan menggunakan [`Release`] membuat berhasil memuat [`Relaxed`].
            ///
            /// Pengurutan yang gagal hanya bisa [`SeqCst`], [`Acquire`] atau [`Relaxed`] dan harus setara atau lebih lemah dari pengurutan yang berhasil.
            ///
            /// **Catatan**: Metode ini hanya tersedia di platform yang mendukung operasi atom di
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// biarkan mut tua= val.load(Ordering::Relaxed);
            /// loop {let new=old * 2;
            ///     cocokkan val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // KEAMANAN: data race dicegah oleh atomic intrinsics.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// Menambahkan ke nilai saat ini, mengembalikan nilai sebelumnya.
            ///
            /// Operasi ini membungkus overflow.
            ///
            /// `fetch_add` mengambil argumen [`Ordering`] yang menjelaskan urutan memori dari operasi ini.Semua mode pemesanan dimungkinkan.
            /// Perhatikan bahwa menggunakan [`Acquire`] membuat bagian penyimpanan dari operasi ini [`Relaxed`], dan menggunakan [`Release`] membuat bagian beban menjadi [`Relaxed`].
            ///
            ///
            /// **Catatan**: Metode ini hanya tersedia di platform yang mendukung operasi atom di
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // KEAMANAN: data race dicegah oleh atomic intrinsics.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// Mengurangi dari nilai saat ini, mengembalikan nilai sebelumnya.
            ///
            /// Operasi ini membungkus overflow.
            ///
            /// `fetch_sub` mengambil argumen [`Ordering`] yang menjelaskan urutan memori dari operasi ini.Semua mode pemesanan dimungkinkan.
            /// Perhatikan bahwa menggunakan [`Acquire`] membuat bagian penyimpanan dari operasi ini [`Relaxed`], dan menggunakan [`Release`] membuat bagian beban menjadi [`Relaxed`].
            ///
            ///
            /// **Catatan**: Metode ini hanya tersedia di platform yang mendukung operasi atom di
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // KEAMANAN: data race dicegah oleh atomic intrinsics.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// Bitwise "and" dengan nilai saat ini.
            ///
            /// Melakukan operasi "and" bitwise pada nilai saat ini dan argumen `val`, dan menyetel nilai baru ke hasil.
            ///
            /// Mengembalikan nilai sebelumnya.
            ///
            /// `fetch_and` mengambil argumen [`Ordering`] yang menjelaskan urutan memori dari operasi ini.Semua mode pemesanan dimungkinkan.
            /// Perhatikan bahwa menggunakan [`Acquire`] membuat bagian penyimpanan dari operasi ini [`Relaxed`], dan menggunakan [`Release`] membuat bagian beban menjadi [`Relaxed`].
            ///
            ///
            /// **Catatan**: Metode ini hanya tersedia di platform yang mendukung operasi atom di
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // KEAMANAN: data race dicegah oleh atomic intrinsics.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// Bitwise "nand" dengan nilai saat ini.
            ///
            /// Melakukan operasi "nand" bitwise pada nilai saat ini dan argumen `val`, dan menyetel nilai baru ke hasil.
            ///
            /// Mengembalikan nilai sebelumnya.
            ///
            /// `fetch_nand` mengambil argumen [`Ordering`] yang menjelaskan urutan memori dari operasi ini.Semua mode pemesanan dimungkinkan.
            /// Perhatikan bahwa menggunakan [`Acquire`] membuat bagian penyimpanan dari operasi ini [`Relaxed`], dan menggunakan [`Release`] membuat bagian beban menjadi [`Relaxed`].
            ///
            ///
            /// **Catatan**: Metode ini hanya tersedia di platform yang mendukung operasi atom di
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13&0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // KEAMANAN: data race dicegah oleh atomic intrinsics.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// Bitwise "or" dengan nilai saat ini.
            ///
            /// Melakukan operasi "or" bitwise pada nilai saat ini dan argumen `val`, dan menyetel nilai baru ke hasil.
            ///
            /// Mengembalikan nilai sebelumnya.
            ///
            /// `fetch_or` mengambil argumen [`Ordering`] yang menjelaskan urutan memori dari operasi ini.Semua mode pemesanan dimungkinkan.
            /// Perhatikan bahwa menggunakan [`Acquire`] membuat bagian penyimpanan dari operasi ini [`Relaxed`], dan menggunakan [`Release`] membuat bagian beban menjadi [`Relaxed`].
            ///
            ///
            /// **Catatan**: Metode ini hanya tersedia di platform yang mendukung operasi atom di
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // KEAMANAN: data race dicegah oleh atomic intrinsics.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// Bitwise "xor" dengan nilai saat ini.
            ///
            /// Melakukan operasi "xor" bitwise pada nilai saat ini dan argumen `val`, dan menyetel nilai baru ke hasil.
            ///
            /// Mengembalikan nilai sebelumnya.
            ///
            /// `fetch_xor` mengambil argumen [`Ordering`] yang menjelaskan urutan memori dari operasi ini.Semua mode pemesanan dimungkinkan.
            /// Perhatikan bahwa menggunakan [`Acquire`] membuat bagian penyimpanan dari operasi ini [`Relaxed`], dan menggunakan [`Release`] membuat bagian beban menjadi [`Relaxed`].
            ///
            ///
            /// **Catatan**: Metode ini hanya tersedia di platform yang mendukung operasi atom di
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // KEAMANAN: data race dicegah oleh atomic intrinsics.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// Mengambil nilai, dan menerapkan fungsi padanya yang mengembalikan nilai baru opsional.Mengembalikan `Result` dari `Ok(previous_value)` jika fungsi mengembalikan `Some(_)`, jika tidak `Err(previous_value)`.
            ///
            /// Note: Ini mungkin memanggil fungsi beberapa kali jika nilai telah diubah dari utas lain untuk sementara, selama fungsi mengembalikan `Some(_)`, tetapi fungsi tersebut hanya akan diterapkan sekali ke nilai yang disimpan.
            ///
            ///
            /// `fetch_update` membutuhkan dua argumen [`Ordering`] untuk menjelaskan urutan memori dari operasi ini.
            /// Yang pertama menjelaskan urutan yang diperlukan ketika operasi akhirnya berhasil, sedangkan yang kedua menjelaskan urutan beban yang diperlukan.Ini sesuai dengan urutan keberhasilan dan kegagalan
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// Menggunakan [`Acquire`] sebagai pemesanan sukses membuat bagian penyimpanan dari operasi ini [`Relaxed`], dan menggunakan [`Release`] membuat pemuatan akhir yang berhasil [`Relaxed`].
            /// Urutan beban (failed) hanya boleh [`SeqCst`], [`Acquire`] atau [`Relaxed`] dan harus setara atau lebih lemah dari urutan sukses.
            ///
            /// **Catatan**: Metode ini hanya tersedia di platform yang mendukung operasi atom di
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (Pemesanan: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// assert_eq! (x.fetch_update (Pemesanan: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// Maksimal dengan nilai saat ini.
            ///
            /// Menemukan nilai maksimum saat ini dan argumen `val`, dan menyetel nilai baru ke hasil.
            ///
            /// Mengembalikan nilai sebelumnya.
            ///
            /// `fetch_max` mengambil argumen [`Ordering`] yang menjelaskan urutan memori dari operasi ini.Semua mode pemesanan dimungkinkan.
            /// Perhatikan bahwa menggunakan [`Acquire`] membuat bagian penyimpanan dari operasi ini [`Relaxed`], dan menggunakan [`Release`] membuat bagian beban menjadi [`Relaxed`].
            ///
            ///
            /// **Catatan**: Metode ini hanya tersedia di platform yang mendukung operasi atom di
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// biarkan bar=42;
            /// biarkan max_foo=foo.fetch_max (bar, Ordering::SeqCst).max(bar);
            /// menegaskan! (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // KEAMANAN: data race dicegah oleh atomic intrinsics.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// Minimal dengan nilai saat ini.
            ///
            /// Menemukan nilai minimum saat ini dan argumen `val`, dan menyetel nilai baru ke hasil.
            ///
            /// Mengembalikan nilai sebelumnya.
            ///
            /// `fetch_min` mengambil argumen [`Ordering`] yang menjelaskan urutan memori dari operasi ini.Semua mode pemesanan dimungkinkan.
            /// Perhatikan bahwa menggunakan [`Acquire`] membuat bagian penyimpanan dari operasi ini [`Relaxed`], dan menggunakan [`Release`] membuat bagian beban menjadi [`Relaxed`].
            ///
            ///
            /// **Catatan**: Metode ini hanya tersedia di platform yang mendukung operasi atom di
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// biarkan bar=12;
            /// biarkan min_foo=foo.fetch_min (bar, Ordering::SeqCst).min(bar);
            /// assert_eq! (min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // KEAMANAN: data race dicegah oleh atomic intrinsics.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// Mengembalikan penunjuk yang bisa berubah ke bilangan bulat yang mendasarinya.
            ///
            /// Melakukan pembacaan dan penulisan non-atom pada bilangan bulat yang dihasilkan dapat menjadi perlombaan data.
            /// Metode ini sebagian besar berguna untuk FFI, di mana tanda tangan fungsi dapat digunakan
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// Mengembalikan penunjuk `*mut` dari referensi bersama ke atom ini aman karena jenis atom bekerja dengan mutabilitas interior.
            /// Semua modifikasi atom mengubah nilai melalui referensi bersama, dan dapat melakukannya dengan aman selama mereka menggunakan operasi atom.
            /// Setiap penggunaan pointer mentah yang dikembalikan memerlukan blok `unsafe` dan masih harus menjunjung tinggi batasan yang sama: operasi di atasnya harus atomic.
            ///
            ///
            /// # Examples
            ///
            /// `` abaikan (extern-declaration)
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// "C" eksternal {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // KEAMANAN: Aman selama `my_atomic_op` bersifat atomik.
            /// tidak aman {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // KEAMANAN: penelepon harus memegang kontrak keamanan untuk `atomic_store`.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // KEAMANAN: penelepon harus memegang kontrak keamanan untuk `atomic_load`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // KEAMANAN: penelepon harus memegang kontrak keamanan untuk `atomic_swap`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// Mengembalikan nilai sebelumnya (seperti __sync_fetch_and_add).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // KEAMANAN: penelepon harus memegang kontrak keamanan untuk `atomic_add`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// Mengembalikan nilai sebelumnya (seperti __sync_fetch_and_sub).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // KEAMANAN: penelepon harus memegang kontrak keamanan untuk `atomic_sub`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // KEAMANAN: penelepon harus memegang kontrak keamanan untuk `atomic_compare_exchange`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // KEAMANAN: penelepon harus memegang kontrak keamanan untuk `atomic_compare_exchange_weak`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // KEAMANAN: penelepon harus memegang kontrak keamanan untuk `atomic_and`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // KEAMANAN: penelepon harus memegang kontrak keamanan untuk `atomic_nand`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // KEAMANAN: penelepon harus memegang kontrak keamanan untuk `atomic_or`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // KEAMANAN: penelepon harus memegang kontrak keamanan untuk `atomic_xor`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// mengembalikan nilai maksimal (perbandingan bertanda tangan)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // KEAMANAN: penelepon harus memegang kontrak keamanan untuk `atomic_max`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// mengembalikan nilai min (perbandingan bertanda tangan)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // KEAMANAN: penelepon harus memegang kontrak keamanan untuk `atomic_min`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// mengembalikan nilai maks (perbandingan tidak bertanda tangan)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // KEAMANAN: penelepon harus memegang kontrak keamanan untuk `atomic_umax`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// mengembalikan nilai min (perbandingan tidak bertanda tangan)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // KEAMANAN: penelepon harus memegang kontrak keamanan untuk `atomic_umin`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// Pagar atom.
///
/// Bergantung pada urutan yang ditentukan, pagar mencegah kompilator dan CPU menyusun ulang jenis operasi memori tertentu di sekitarnya.
/// Itu menciptakan hubungan sinkron-dengan antara itu dan operasi atom atau pagar di utas lain.
///
/// Pagar 'A' yang memiliki (setidaknya) semantik pengurutan [`Release`], disinkronkan dengan pagar 'B' dengan (setidaknya) semantik [`Acquire`], jika dan hanya jika ada operasi X dan Y, keduanya beroperasi pada beberapa objek atom 'M' sehingga A diurutkan sebelumnya X, Y disinkronkan sebelum B dan Y mengamati perubahan ke M.
/// Ini memberikan ketergantungan terjadi-sebelum antara A dan B.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// Operasi atom dengan semantik [`Release`] atau [`Acquire`] juga dapat disinkronkan dengan pagar.
///
/// Pagar yang memiliki urutan [`SeqCst`], selain memiliki semantik [`Acquire`] dan [`Release`], berpartisipasi dalam urutan program global dari operasi dan/atau pagar [`SeqCst`] lainnya.
///
/// Menerima pemesanan [`Acquire`], [`Release`], [`AcqRel`] dan [`SeqCst`].
///
/// # Panics
///
/// Panics jika `order` adalah [`Relaxed`].
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // Primitif pengecualian timbal balik berdasarkan spinlock.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // Tunggu hingga nilai lama adalah `false`.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // Pagar ini disinkronkan dengan penyimpanan di `unlock`.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // KEAMANAN: menggunakan pagar atom aman.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// Pagar memori kompiler.
///
/// `compiler_fence` tidak memancarkan kode mesin apa pun, tetapi membatasi jenis memori yang menata ulang compiler yang boleh dilakukan.Secara khusus, bergantung pada semantik [`Ordering`] yang diberikan, kompilator mungkin dilarang memindahkan baca atau tulis dari sebelum atau setelah panggilan ke sisi lain panggilan ke `compiler_fence`.Perhatikan bahwa ini **tidak** mencegah *perangkat keras* melakukan pemesanan ulang seperti itu.
///
/// Ini bukan masalah dalam konteks eksekusi thread tunggal, tetapi jika thread lain dapat mengubah memori pada saat yang sama, diperlukan sinkronisasi primitif yang lebih kuat seperti [`fence`].
///
/// Pengurutan ulang yang dicegah oleh semantik pengurutan yang berbeda adalah:
///
///  - dengan [`SeqCst`], pembacaan dan penulisan ulang tidak diperbolehkan.
///  - dengan [`Release`], operasi baca dan tulis sebelumnya tidak dapat dipindahkan melewati penulisan berikutnya.
///  - dengan [`Acquire`], pembacaan dan penulisan berikutnya tidak dapat dipindahkan ke pembacaan sebelumnya.
///  - dengan [`AcqRel`], kedua aturan di atas diterapkan.
///
/// `compiler_fence` umumnya hanya berguna untuk mencegah utas agar tidak berpacu dengan *dengan sendirinya*.Artinya, jika utas tertentu mengeksekusi satu bagian kode, lalu terputus, dan mulai mengeksekusi kode di tempat lain (saat masih di utas yang sama, dan secara konseptual masih pada inti yang sama).Dalam program tradisional, ini hanya dapat terjadi ketika penangan sinyal terdaftar.
/// Dalam kode tingkat yang lebih rendah, situasi seperti itu juga dapat muncul saat menangani interupsi, saat mengimplementasikan untaian hijau dengan pre-emption, dll.
/// Pembaca yang penasaran didorong untuk membaca diskusi kernel Linux tentang [memory barriers].
///
/// # Panics
///
/// Panics jika `order` adalah [`Relaxed`].
///
/// # Examples
///
/// Tanpa `compiler_fence`, `assert_eq!` dalam kode berikut *tidak* dijamin akan berhasil, meskipun semuanya terjadi dalam satu utas.
/// Untuk mengetahui alasannya, ingatlah bahwa kompilator bebas menukar penyimpanan ke `IMPORTANT_VARIABLE` dan `IS_READ` karena keduanya adalah `Ordering::Relaxed`.Jika ya, dan penangan sinyal dipanggil tepat setelah `IS_READY` diperbarui, maka penangan sinyal akan melihat `IS_READY=1`, tetapi `IMPORTANT_VARIABLE=0`.
/// Menggunakan `compiler_fence` memperbaiki situasi ini.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // mencegah penulisan sebelumnya dipindahkan melampaui titik ini
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // KEAMANAN: menggunakan pagar atom aman.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// Memberi sinyal kepada prosesor bahwa prosesor berada di dalam putaran-putaran tunggu-sibuk ("kunci putar").
///
/// Fungsi ini tidak digunakan lagi karena mendukung [`hint::spin_loop`].
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}