//! traits primitif dan tipe yang mewakili properti dasar tipe.
//!
//! Jenis Rust dapat diklasifikasikan dalam berbagai cara yang berguna sesuai dengan sifat intrinsiknya.
//! Klasifikasi ini direpresentasikan sebagai traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Jenis yang dapat ditransfer melintasi batas utas.
///
/// trait ini secara otomatis diimplementasikan ketika kompilator menentukan itu tepat.
///
/// Contoh tipe non-`Kirim` adalah pointer penghitung referensi [`rc::Rc`][`Rc`].
/// Jika dua utas mencoba menggandakan [`Rc`] yang mengarah ke nilai referensi yang dihitung sama, mereka mungkin mencoba memperbarui jumlah referensi pada saat yang sama, yaitu [undefined behavior][ub] karena [`Rc`] tidak menggunakan operasi atom.
///
/// Sepupunya [`sync::Arc`][arc] memang menggunakan operasi atom (menimbulkan beberapa overhead) dan dengan demikian `Send`.
///
/// Lihat [the Nomicon](../../nomicon/send-and-sync.html) untuk lebih jelasnya.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Jenis dengan ukuran konstan yang diketahui pada waktu kompilasi.
///
/// Semua parameter tipe memiliki batas implisit `Sized`.Sintaks khusus `?Sized` dapat digunakan untuk menghilangkan batasan ini jika tidak sesuai.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//error: Sized tidak diterapkan untuk [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Satu-satunya pengecualian adalah tipe `Self` implisit dari trait.
/// trait tidak memiliki ikatan `Sized` implisit karena ini tidak kompatibel dengan [objek trait] di mana, menurut definisi, trait perlu bekerja dengan semua implementor yang memungkinkan, dan dengan demikian dapat berukuran berapa pun.
///
///
/// Meskipun Rust akan memungkinkan Anda mengikat `Sized` ke trait, Anda tidak akan dapat menggunakannya untuk membentuk objek trait nanti:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // biarkan y: &dyn Bar= &Impl;//error: trait `Bar` tidak dapat dijadikan objek
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // untuk Default, misalnya, yang mengharuskan `[T]: !Default` dapat dievaluasi
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Tipe yang bisa "unsized" menjadi tipe yang berukuran dinamis.
///
/// Misalnya, tipe array berukuran `[i8; 2]` mengimplementasikan `Unsize<[i8]>` dan `Unsize<dyn fmt::Debug>`.
///
/// Semua implementasi `Unsize` disediakan secara otomatis oleh kompilator.
///
/// `Unsize` diimplementasikan untuk:
///
/// - `[T; N]` adalah `Unsize<[T]>`
/// - `T` adalah `Unsize<dyn Trait>` saat `T: Trait`
/// - `Foo<..., T, ...>` adalah `Unsize<Foo<..., U, ...>>` jika:
///   - `T: Unsize<U>`
///   - Foo adalah sebuah struct
///   - Hanya bidang terakhir `Foo` yang memiliki tipe yang melibatkan `T`
///   - `T` bukan bagian dari jenis bidang lainnya
///   - `Bar<T>: Unsize<Bar<U>>`, jika field terakhir `Foo` memiliki tipe `Bar<T>`
///
/// `Unsize` digunakan bersama dengan [`ops::CoerceUnsized`] untuk memungkinkan wadah "user-defined" seperti [`Rc`] berisi jenis berukuran dinamis.
/// Lihat [DST coercion RFC][RFC982] dan [the nomicon entry on coercion][nomicon-coerce] untuk lebih jelasnya.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// trait diperlukan untuk konstanta yang digunakan dalam pencocokan pola.
///
/// Jenis apa pun yang mendapatkan `PartialEq` secara otomatis mengimplementasikan trait ini,*terlepas* dari apakah parameter jenisnya mengimplementasikan `Eq`.
///
/// Jika item `const` berisi beberapa jenis yang tidak mengimplementasikan trait ini, maka jenis tersebut (1.) tidak mengimplementasikan `PartialEq` (yang berarti konstanta tidak akan menyediakan metode perbandingan tersebut, yang diasumsikan pembuatan kode tersedia), atau (2.) yang diimplementasikan *miliknya sendiri* versi `PartialEq` (yang kami asumsikan tidak sesuai dengan perbandingan persamaan struktural).
///
///
/// Dalam salah satu dari dua skenario di atas, kami menolak penggunaan konstanta seperti itu dalam kecocokan pola.
///
/// Lihat juga [structural match RFC][RFC1445], dan [issue 63438] yang memotivasi migrasi dari desain berbasis atribut ke trait ini.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// trait diperlukan untuk konstanta yang digunakan dalam pencocokan pola.
///
/// Jenis apa pun yang mendapatkan `Eq` secara otomatis mengimplementasikan trait ini,*terlepas* dari apakah parameter jenisnya mengimplementasikan `Eq`.
///
/// Ini adalah peretasan untuk mengatasi batasan dalam sistem tipe kami.
///
/// # Background
///
/// Kami ingin mewajibkan jenis konstanta yang digunakan dalam pencocokan pola memiliki atribut `#[derive(PartialEq, Eq)]`.
///
/// Dalam dunia yang lebih ideal, kita dapat memeriksa persyaratan itu hanya dengan memeriksa bahwa jenis yang diberikan mengimplementasikan `StructuralPartialEq` trait *dan*`Eq` trait.
/// Namun, Anda dapat memiliki ADT yang *melakukan*`derive(PartialEq, Eq)`, dan menjadi kasus yang kami ingin compiler menerimanya, namun tipe konstanta gagal untuk mengimplementasikan `Eq`.
///
/// Yakni, kasus seperti ini:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Masalah dalam kode di atas adalah bahwa `Wrap<fn(&())>` tidak mengimplementasikan `PartialEq`, atau `Eq`, karena `untuk <'a> fn(&'a _)` does not implement those traits.)
///
/// Oleh karena itu, kami tidak dapat mengandalkan pemeriksaan naif untuk `StructuralPartialEq` dan `Eq` belaka.
///
/// Sebagai peretasan untuk mengatasi ini, kami menggunakan dua traits terpisah yang disuntikkan oleh masing-masing dari dua turunan (`#[derive(PartialEq)]` dan `#[derive(Eq)]`) dan memeriksa apakah keduanya ada sebagai bagian dari pemeriksaan kecocokan struktural.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Jenis yang nilainya dapat diduplikasi hanya dengan menyalin bit.
///
/// Secara default, binding variabel memiliki 'semantik pindahkan'.Dengan kata lain:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` telah pindah ke `y`, sehingga tidak dapat digunakan
///
/// // println! ("{: ?}", x);//kesalahan: penggunaan nilai yang dipindahkan
/// ```
///
/// Namun, jika suatu jenis mengimplementasikan `Copy`, ia malah memiliki 'salin semantik':
///
/// ```
/// // Kita bisa mendapatkan implementasi `Copy`.
/// // `Clone` juga diperlukan, karena ini adalah potret super dari `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` adalah salinan `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Penting untuk diperhatikan bahwa dalam dua contoh ini, satu-satunya perbedaan adalah apakah Anda diizinkan mengakses `x` setelah penetapan.
/// Di balik terpal, baik salinan maupun pemindahan dapat mengakibatkan bit disalin dalam memori, meskipun terkadang hal ini dioptimalkan.
///
/// ## Bagaimana cara menerapkan `Copy`?
///
/// Ada dua cara untuk mengimplementasikan `Copy` pada tipe Anda.Yang paling sederhana adalah menggunakan `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Anda juga dapat mengimplementasikan `Copy` dan `Clone` secara manual:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Ada perbedaan kecil di antara keduanya: strategi `derive` juga akan menempatkan `Copy` terikat pada parameter jenis, yang tidak selalu diinginkan.
///
/// ## Apa perbedaan antara `Copy` dan `Clone`?
///
/// Salinan terjadi secara implisit, misalnya sebagai bagian dari tugas `y = x`.Perilaku `Copy` tidak dapat dibebani secara berlebihan;itu selalu merupakan salinan sederhana yang bijak.
///
/// Kloning adalah tindakan eksplisit, `x.clone()`.Implementasi [`Clone`] dapat menyediakan perilaku khusus jenis apa pun yang diperlukan untuk menggandakan nilai dengan aman.
/// Misalnya, implementasi [`Clone`] untuk [`String`] perlu menyalin buffer string yang diarahkan ke dalam heap.
/// Salinan bitwise sederhana dari nilai [`String`] hanya akan menyalin penunjuk, yang mengarah ke garis bebas ganda.
/// Karena alasan ini, [`String`] adalah [`Clone`] tetapi bukan `Copy`.
///
/// [`Clone`] adalah potret supertrait dari `Copy`, jadi semua yang `Copy` juga harus mengimplementasikan [`Clone`].
/// Jika suatu tipe adalah `Copy` maka implementasi [`Clone`]-nya hanya perlu mengembalikan `*self` (lihat contoh di atas).
///
/// ## Kapan tipe saya bisa menjadi `Copy`?
///
/// Suatu tipe dapat mengimplementasikan `Copy` jika semua komponennya mengimplementasikan `Copy`.Misalnya, struct ini dapat berupa `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Sebuah struct bisa `Copy`, dan [`i32`] adalah `Copy`, oleh karena itu `Point` memenuhi syarat untuk menjadi `Copy`.
/// Sebaliknya, pertimbangkan
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// Struct `PointList` tidak dapat menerapkan `Copy`, karena [`Vec<T>`] bukan `Copy`.Jika kami mencoba mendapatkan implementasi `Copy`, kami akan mendapatkan error:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Referensi bersama (`&T`) juga merupakan `Copy`, jadi suatu jenis dapat berupa `Copy`, meskipun memiliki referensi bersama jenis `T` yang *bukan*`Copy`.
/// Pertimbangkan struct berikut, yang dapat mengimplementasikan `Copy`, karena ini hanya menyimpan *referensi bersama* untuk tipe non-`Copy` `PointList` dari atas:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Kapan *tidak bisa* tipe saya menjadi `Copy`?
///
/// Beberapa jenis tidak dapat disalin dengan aman.Misalnya, menyalin `&mut T` akan membuat referensi yang bisa berubah alias.
/// Menyalin [`String`] akan menggandakan tanggung jawab untuk mengelola buffer [`String`], yang mengarah ke free double.
///
/// Menggeneralisasi kasus terakhir, semua jenis yang mengimplementasikan [`Drop`] tidak boleh `Copy`, karena ia mengelola beberapa sumber daya selain byte [`size_of::<T>`]-nya sendiri.
///
/// Jika Anda mencoba menerapkan `Copy` pada struct atau enum yang berisi data non-`Copy`, Anda akan mendapatkan kesalahan [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Kapan *harus* tipe saya menjadi `Copy`?
///
/// Secara umum, jika tipe _can_ Anda mengimplementasikan `Copy`, seharusnya.
/// Perlu diingat, bahwa mengimplementasikan `Copy` adalah bagian dari API publik jenis Anda.
/// Jika jenisnya mungkin menjadi non-`Copy` di future, sebaiknya abaikan implementasi `Copy` sekarang, untuk menghindari perubahan API yang mengganggu.
///
/// ## Pelaksana tambahan
///
/// Selain [implementors listed below][impls], jenis berikut juga menerapkan `Copy`:
///
/// * Jenis item fungsi (yaitu, jenis berbeda yang ditentukan untuk setiap fungsi)
/// * Jenis penunjuk fungsi (mis., `fn() -> i32`)
/// * Jenis array, untuk semua ukuran, jika jenis item juga menerapkan `Copy` (misalnya, `[i32; 123456]`)
/// * Jenis tupel, jika setiap komponen juga mengimplementasikan `Copy` (mis., `()`, `(i32, bool)`)
/// * Jenis penutupan, jika tidak menangkap nilai dari lingkungan atau jika semua nilai yang ditangkap menerapkan `Copy` sendiri.
///   Perhatikan bahwa variabel yang diambil oleh referensi bersama selalu menerapkan `Copy` (meskipun referensi tidak), sedangkan variabel yang diambil oleh referensi yang bisa berubah tidak pernah menerapkan `Copy`.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Hal ini memungkinkan penyalinan jenis yang tidak menerapkan `Copy` karena batas waktu yang tidak terpenuhi (menyalin `A<'_>` jika hanya `A<'static>: Copy` dan `A<'_>: Clone`).
// Kami memiliki atribut ini di sini untuk saat ini hanya karena ada beberapa spesialisasi yang ada di `Copy` yang sudah ada di pustaka standar, dan tidak ada cara untuk melakukan perilaku ini dengan aman saat ini.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Turunkan makro yang menghasilkan impl dari trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Jenis yang aman untuk berbagi referensi antar utas.
///
/// trait ini secara otomatis diimplementasikan ketika kompilator menentukan itu tepat.
///
/// Definisi tepatnya adalah: tipe `T` adalah [`Sync`] jika dan hanya jika `&T` adalah [`Send`].
/// Dengan kata lain, jika tidak ada kemungkinan [undefined behavior][ub] (termasuk data race) saat meneruskan referensi `&T` antar utas.
///
/// Seperti yang diharapkan, tipe primitif seperti [`u8`] dan [`f64`] semuanya [`Sync`], dan begitu juga tipe agregat sederhana yang memuatnya, seperti tupel, struct, dan enum.
/// Contoh lain dari tipe [`Sync`] dasar termasuk tipe "immutable" seperti `&T`, dan tipe yang mewarisi perubahan sederhana, seperti [`Box<T>`][box], [`Vec<T>`][vec] dan kebanyakan tipe koleksi lainnya.
///
/// (Parameter umum harus [`Sync`] agar penampungnya menjadi [`Sync`].)
///
/// Konsekuensi yang agak mengejutkan dari definisi tersebut adalah bahwa `&mut T` adalah `Sync` (jika `T` adalah `Sync`) meskipun tampaknya itu memberikan mutasi yang tidak tersinkronisasi.
/// Triknya adalah bahwa referensi yang bisa berubah di belakang referensi bersama (yaitu, `& &mut T`) menjadi hanya-baca, seolah-olah itu adalah `& &T`.
/// Oleh karena itu, tidak ada risiko perlombaan data.
///
/// Jenis yang bukan `Sync` adalah yang memiliki "interior mutability" dalam bentuk yang tidak aman untuk thread, seperti [`Cell`][cell] dan [`RefCell`][refcell].
/// Jenis ini memungkinkan mutasi isinya bahkan melalui referensi bersama yang tidak dapat diubah.
/// Misalnya metode `set` pada [`Cell<T>`][cell] membutuhkan `&self`, sehingga hanya memerlukan referensi bersama [`&Cell<T>`][cell].
/// Metode ini tidak melakukan sinkronisasi, sehingga [`Cell`][cell] tidak dapat menjadi `Sync`.
///
/// Contoh lain dari jenis non-`Sync` adalah penunjuk penghitung referensi [`Rc`][rc].
/// Diberikan referensi [`&Rc<T>`][rc], Anda dapat mengkloning [`Rc<T>`][rc] baru, memodifikasi jumlah referensi dengan cara non-atom.
///
/// Untuk kasus ketika seseorang memang membutuhkan mutabilitas interior yang aman untuk thread, Rust menyediakan [atomic data types], serta penguncian eksplisit melalui [`sync::Mutex`][mutex] dan [`sync::RwLock`][rwlock].
/// Jenis ini memastikan bahwa mutasi apa pun tidak dapat menyebabkan balapan data, oleh karena itu jenisnya adalah `Sync`.
/// Demikian juga, [`sync::Arc`][arc] menyediakan analog [`Rc`][rc] yang aman untuk thread.
///
/// Semua tipe dengan mutabilitas interior juga harus menggunakan pembungkus [`cell::UnsafeCell`][unsafecell] di sekitar value(s) yang dapat dimutasi melalui referensi bersama.
/// Gagal melakukan ini adalah [undefined behavior][ub].
/// Misalnya, [`transmute`][transmute]-ing dari `&T` ke `&mut T` tidak valid.
///
/// Lihat [the Nomicon][nomicon-send-and-sync] untuk detail selengkapnya tentang `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): setelah dukungan untuk menambahkan catatan di `rustc_on_unimplemented` mendarat dalam versi beta, dan telah diperpanjang untuk memeriksa apakah penutupan ada di mana saja dalam rantai persyaratan, perpanjang seperti (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Tipe berukuran nol digunakan untuk menandai hal-hal yang "act like" mereka miliki sebagai `T`.
///
/// Menambahkan bidang `PhantomData<T>` ke tipe Anda memberi tahu kompiler bahwa tipe Anda bertindak seolah-olah ia menyimpan nilai tipe `T`, meskipun sebenarnya tidak.
/// Informasi ini digunakan saat menghitung properti keamanan tertentu.
///
/// Untuk penjelasan yang lebih mendalam tentang cara menggunakan `PhantomData<T>`, silakan lihat [the Nomicon](../../nomicon/phantom-data.html).
///
/// # Catatan yang mengerikan 👻👻👻
///
/// Meskipun keduanya memiliki nama yang menakutkan, `PhantomData` dan 'jenis hantu' terkait, tetapi tidak identik.Parameter tipe phantom hanyalah parameter tipe yang tidak pernah digunakan.
/// Di Rust, hal ini sering menyebabkan kompiler mengeluh, dan solusinya adalah menambahkan penggunaan "dummy" melalui `PhantomData`.
///
/// # Examples
///
/// ## Parameter seumur hidup yang tidak digunakan
///
/// Mungkin kasus penggunaan paling umum untuk `PhantomData` adalah struct yang memiliki parameter masa pakai yang tidak terpakai, biasanya sebagai bagian dari beberapa kode yang tidak aman.
/// Misalnya, berikut adalah struct `Slice` yang memiliki dua pointer tipe `*const T`, mungkin mengarah ke array di suatu tempat:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Tujuannya adalah agar data yang mendasarinya hanya valid untuk masa pakai `'a`, jadi `Slice` tidak boleh lebih lama dari `'a`.
/// Namun, maksud ini tidak diekspresikan dalam kode, karena tidak ada penggunaan masa pakai `'a` dan oleh karena itu tidak jelas penerapannya pada data apa.
/// Kita dapat memperbaiki ini dengan memberi tahu kompiler untuk bertindak *seolah-olah* struct `Slice` berisi referensi `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Ini juga pada gilirannya memerlukan penjelasan `T: 'a`, yang menunjukkan bahwa referensi apa pun di `T` berlaku selama `'a` seumur hidup.
///
/// Saat menginisialisasi `Slice` Anda cukup memberikan nilai `PhantomData` untuk bidang `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Parameter tipe yang tidak digunakan
///
/// Kadang-kadang terjadi bahwa Anda memiliki parameter tipe yang tidak terpakai yang menunjukkan tipe data apa sebuah struct "tied", meskipun data itu sebenarnya tidak ditemukan di struct itu sendiri.
/// Berikut adalah contoh di mana ini muncul dengan [FFI].
/// Antarmuka asing menggunakan pegangan tipe `*mut ()` untuk merujuk ke nilai Rust dari tipe yang berbeda.
/// Kami melacak tipe Rust menggunakan parameter tipe hantu di struct `ExternalResource` yang membungkus pegangan.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Kepemilikan dan drop check
///
/// Menambahkan bidang tipe `PhantomData<T>` menunjukkan bahwa tipe Anda memiliki data tipe `T`.Ini pada gilirannya menyiratkan bahwa ketika tipe Anda dihapus, itu mungkin menjatuhkan satu atau lebih contoh tipe `T`.
/// Hal ini berkaitan dengan analisis [drop check] kompiler Rust.
///
/// Jika struct Anda sebenarnya tidak *memiliki* data jenis `T`, lebih baik menggunakan jenis referensi, seperti `PhantomData<&'a T>` (ideally) atau `PhantomData<*const T>` (jika tidak ada masa berlaku), agar tidak menunjukkan kepemilikan.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Compiler-internal trait digunakan untuk menunjukkan jenis diskriminan enum.
///
/// trait ini secara otomatis diimplementasikan untuk setiap jenis dan tidak menambahkan jaminan apa pun ke [`mem::Discriminant`].
/// Ini adalah **perilaku tidak terdefinisi** untuk mengubah antara `DiscriminantKind::Discriminant` dan `mem::Discriminant`.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Jenis diskriminan, yang harus memenuhi trait bounds yang disyaratkan oleh `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Compiler-internal trait digunakan untuk menentukan apakah suatu tipe berisi `UnsafeCell` secara internal, tetapi tidak melalui tipuan.
///
/// Ini memengaruhi, misalnya, apakah `static` jenis itu ditempatkan di memori statis hanya-baca atau memori statis yang dapat ditulis.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Jenis yang dapat dipindahkan dengan aman setelah disematkan.
///
/// Rust sendiri tidak memiliki gagasan tentang tipe yang tidak dapat dipindahkan, dan menganggap gerakan (misalnya, melalui penugasan atau [`mem::replace`]) untuk selalu aman.
///
/// Tipe [`Pin`][Pin] digunakan sebagai gantinya untuk mencegah pergerakan melalui sistem tipe.Pointer `P<T>` yang dibungkus dengan pembungkus [`Pin<P<T>>`][Pin] tidak dapat dipindahkan.
/// Lihat dokumentasi [`pin` module] untuk informasi lebih lanjut tentang penyematan.
///
/// Menerapkan `Unpin` trait untuk `T` menghilangkan batasan penyematan jenis, yang kemudian memungkinkan pemindahan `T` dari [`Pin<P<T>>`][Pin] dengan fungsi seperti [`mem::replace`].
///
///
/// `Unpin` tidak memiliki konsekuensi sama sekali untuk data yang tidak disematkan.
/// Secara khusus, [`mem::replace`] dengan senang hati memindahkan data `!Unpin` (ini berfungsi untuk `&mut T` apa pun, tidak hanya saat `T: Unpin`).
/// Namun, Anda tidak dapat menggunakan [`mem::replace`] pada data yang dibungkus di dalam [`Pin<P<T>>`][Pin] karena Anda tidak bisa mendapatkan `&mut T` yang Anda perlukan untuk itu, dan *itulah* yang membuat sistem ini berfungsi.
///
/// Jadi ini, misalnya, hanya dapat dilakukan pada tipe yang mengimplementasikan `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Kami membutuhkan referensi yang bisa berubah untuk memanggil `mem::replace`.
/// // Kita bisa mendapatkan referensi seperti itu dengan (implicitly) yang memanggil `Pin::deref_mut`, tetapi itu hanya mungkin karena `String` mengimplementasikan `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// trait ini secara otomatis diimplementasikan untuk hampir semua jenis.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Jenis penanda yang tidak mengimplementasikan `Unpin`.
///
/// Jika suatu tipe berisi `PhantomPinned`, itu tidak akan mengimplementasikan `Unpin` secara default.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Implementasi `Copy` untuk tipe primitif.
///
/// Implementasi yang tidak dapat dijelaskan di Rust diimplementasikan di `traits::SelectionContext::copy_clone_conditions()` di `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Referensi bersama dapat disalin, tetapi referensi yang dapat diubah *tidak dapat*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}