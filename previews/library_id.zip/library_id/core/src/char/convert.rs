//! Konversi karakter.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// Mengubah `u32` menjadi `char`.
///
/// Perhatikan bahwa semua [`char`] adalah [`u32`] valid, dan dapat ditransmisikan ke satu dengan
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Namun, kebalikannya tidak benar: tidak semua [`u32`] yang valid adalah [`char`] yang valid.
/// `from_u32()` akan mengembalikan `None` jika masukan bukan nilai yang valid untuk [`char`].
///
/// Untuk versi tidak aman dari fungsi ini yang mengabaikan pemeriksaan ini, lihat [`from_u32_unchecked`].
///
///
/// # Examples
///
/// Penggunaan dasar:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// Mengembalikan `None` saat input bukan [`char`] yang valid:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// Mengubah `u32` menjadi `char`, mengabaikan validitas.
///
/// Perhatikan bahwa semua [`char`] adalah [`u32`] valid, dan dapat ditransmisikan ke satu dengan
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Namun, kebalikannya tidak benar: tidak semua [`u32`] yang valid adalah [`char`] yang valid.
/// `from_u32_unchecked()` akan mengabaikan ini, dan secara membabi buta mentransmisikan ke [`char`], mungkin membuat yang tidak valid.
///
///
/// # Safety
///
/// Fungsi ini tidak aman, karena dapat membuat nilai `char` yang tidak valid.
///
/// Untuk versi aman dari fungsi ini, lihat fungsi [`from_u32`].
///
/// # Examples
///
/// Penggunaan dasar:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // KEAMANAN: pemanggil harus menjamin bahwa `i` adalah nilai karakter yang valid.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// Mengubah [`char`] menjadi [`u32`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// Mengubah [`char`] menjadi [`u64`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Karakter dicor ke nilai titik kode, kemudian diperpanjang nol hingga 64 bit.
        // Lihat [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// Mengubah [`char`] menjadi [`u128`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Karakter dicor ke nilai titik kode, kemudian diperpanjang nol hingga 128 bit.
        // Lihat [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u128
    }
}

/// Memetakan byte dalam 0x00 ..=0xFF ke `char` yang titik kodenya memiliki nilai yang sama, dalam U + 0000 ..=U + 00FF.
///
/// Unicode dirancang sedemikian rupa sehingga ini secara efektif mendekode byte dengan pengkodean karakter yang oleh IANA disebut ISO-8859-1.
/// Pengkodean ini kompatibel dengan ASCII.
///
/// Perhatikan bahwa ini berbeda dari ISO/IEC 8859-1 alias
/// ISO 8859-1 (dengan satu tanda hubung lebih sedikit), yang menyisakan beberapa "blanks", nilai byte yang tidak ditetapkan ke karakter apa pun.
/// ISO-8859-1 (IANA) menetapkannya ke kode kontrol C0 dan C1.
///
/// Perhatikan bahwa ini *juga* berbeda dari Windows-1252 alias
/// halaman kode 1252, yang merupakan superset ISO/IEC 8859-1 yang memberikan beberapa (tidak semua!) kosong pada tanda baca dan berbagai karakter Latin.
///
/// Untuk membingungkan lebih jauh, [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1`, dan `windows-1252` semuanya adalah alias untuk superset Windows-1252 yang mengisi bagian kosong yang tersisa dengan kode kontrol C0 dan C1 yang sesuai.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// Mengubah [`u8`] menjadi [`char`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// Kesalahan yang dapat dikembalikan saat mengurai karakter.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // SAFETY: diperiksa bahwa ini adalah nilai unicode yang legal
            Ok(unsafe { transmute(i) })
        }
    }
}

/// Jenis kesalahan kembali ketika konversi dari u32 ke char gagal.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// Mengonversi digit di radix yang diberikan menjadi `char`.
///
/// 'radix' di sini terkadang juga disebut 'base'.
/// Radix dua menunjukkan bilangan biner, radix sepuluh, desimal, dan radix enam belas, heksadesimal, untuk memberikan beberapa nilai yang sama.
///
/// Radian sewenang-wenang didukung.
///
/// `from_digit()` akan mengembalikan `None` jika input bukan berupa digit dalam radix yang diberikan.
///
/// # Panics
///
/// Panics jika diberi radix lebih besar dari 36.
///
/// # Examples
///
/// Penggunaan dasar:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // Desimal 11 adalah satu digit di basis 16
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// Mengembalikan `None` saat input bukan berupa digit:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// Melewati radix besar, menyebabkan panic:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}