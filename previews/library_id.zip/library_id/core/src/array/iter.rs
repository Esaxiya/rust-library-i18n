//! Mendefinisikan iterator yang dimiliki `IntoIter` untuk array.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// Sebuah iterator [array] nilai.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Ini adalah larik yang sedang kita iterasi.
    ///
    /// Elemen dengan indeks `i` di mana `alive.start <= i < alive.end` belum dihasilkan dan merupakan entri array yang valid.
    /// Elemen dengan indeks `i < alive.start` atau `i >= alive.end` telah dihasilkan dan tidak boleh diakses lagi!Elemen-elemen mati itu bahkan mungkin dalam keadaan benar-benar tidak diinisialisasi!
    ///
    ///
    /// Jadi invariannya adalah:
    /// - `data[alive]` masih hidup (yaitu berisi elemen yang valid)
    /// - `data[..alive.start]` dan `data[alive.end..]` sudah mati (yaitu elemen sudah dibaca dan tidak boleh disentuh lagi!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Elemen di `data` yang belum dihasilkan.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Membuat iterator baru di atas `array` yang diberikan.
    ///
    /// *Catatan*: metode ini mungkin tidak digunakan lagi di future, setelah [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // Tipe `value` disini adalah `i32`, bukan `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // KEAMANAN: Transmute di sini sebenarnya aman.Dokumen `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` dijamin memiliki ukuran dan kesejajaran yang sama
        // > sebagai `T`.
        //
        // Dokumen tersebut bahkan menunjukkan transmutasi dari array `MaybeUninit<T>` ke array `T`.
        //
        //
        // Dengan itu, inisialisasi ini memenuhi invarian.

        // FIXME(LukasKalbertodt): sebenarnya menggunakan `mem::transmute` di sini, setelah berfungsi dengan const generics:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Sampai saat itu, kita dapat menggunakan `mem::transmute_copy` untuk membuat salinan bitwise sebagai tipe yang berbeda, lalu lupakan `array` agar tidak dijatuhkan.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Menampilkan potongan tetap dari semua elemen yang belum dihasilkan.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // KEAMANAN: Kami tahu bahwa semua elemen dalam `alive` diinisialisasi dengan benar.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Mengembalikan potongan yang bisa berubah dari semua elemen yang belum dihasilkan.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // KEAMANAN: Kami tahu bahwa semua elemen dalam `alive` diinisialisasi dengan benar.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Dapatkan indeks berikutnya dari depan.
        //
        // Meningkatkan `alive.start` sebanyak 1 akan mempertahankan invarian terkait `alive`.
        // Namun karena perubahan ini, untuk waktu yang singkat, zona hidup bukanlah `data[alive]` lagi, melainkan `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Baca elemen dari larik.
            // KEAMANAN: `idx` adalah indeks ke bekas wilayah "alive" dari
            // Himpunan.Membaca elemen ini berarti `data[idx]` dianggap sudah mati sekarang (yaitu jangan disentuh).
            // Karena `idx` adalah awal dari zona hidup, zona hidup sekarang menjadi `data[alive]` lagi, memulihkan semua invarian.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Dapatkan indeks berikutnya dari belakang.
        //
        // Penurunan `alive.end` sebanyak 1 mempertahankan invarian terkait `alive`.
        // Namun karena perubahan ini, untuk waktu yang singkat, zona hidup bukanlah `data[alive]` lagi, melainkan `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Baca elemen dari larik.
            // KEAMANAN: `idx` adalah indeks ke bekas wilayah "alive" dari
            // Himpunan.Membaca elemen ini berarti `data[idx]` dianggap sudah mati sekarang (yaitu jangan disentuh).
            // Karena `idx` adalah akhir dari zona hidup, zona hidup sekarang menjadi `data[alive]` lagi, memulihkan semua invarian.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // KEAMANAN: Ini aman: `as_mut_slice` mengembalikan tepat sub-bagian
        // elemen yang belum dipindahkan dan yang tersisa untuk dibuang.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Tidak akan pernah mengalir karena invarian `hidup.start <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Iterator memang melaporkan panjang yang benar.
// Jumlah elemen "alive" (yang masih akan dihasilkan) adalah panjang rentang `alive`.
// Rentang ini berkurang panjangnya baik di `next` atau `next_back`.
// Itu selalu dikurangi 1 dalam metode tersebut, tetapi hanya jika `Some(_)` dikembalikan.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Catatan, kami tidak benar-benar perlu mencocokkan rentang hidup yang sama persis, jadi kami bisa mengkloning ke offset 0 di mana pun `self` berada.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Kloning semua elemen hidup.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Tulis klon ke dalam larik baru, lalu perbarui rentang hidupnya.
            // Jika mengkloning panics, kami akan menghapus item sebelumnya dengan benar.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Hanya mencetak elemen yang belum dihasilkan: kami tidak dapat mengakses elemen yang dihasilkan lagi.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}