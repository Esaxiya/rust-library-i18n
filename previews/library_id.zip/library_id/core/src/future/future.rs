#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// future mewakili komputasi asinkron.
///
/// future adalah nilai yang mungkin belum menyelesaikan komputasi.
/// Jenis "asynchronous value" ini memungkinkan utas untuk terus melakukan pekerjaan yang berguna sementara menunggu nilai tersedia.
///
///
/// # Metode `poll`
///
/// Metode inti future, `poll`,*mencoba* untuk menyelesaikan future menjadi nilai akhir.
/// Metode ini tidak memblokir jika nilainya belum siap.
/// Sebaliknya, tugas saat ini dijadwalkan untuk dibangunkan ketika memungkinkan untuk membuat kemajuan lebih lanjut dengan `poll`ing lagi.
/// `context` yang diteruskan ke metode `poll` dapat memberikan [`Waker`], yang merupakan pegangan untuk mengaktifkan tugas saat ini.
///
/// Saat menggunakan future, biasanya Anda tidak akan memanggil `poll` secara langsung, melainkan `.await` nilainya.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Jenis nilai yang dihasilkan setelah penyelesaian.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Mencoba menyelesaikan future ke nilai akhir, mendaftarkan tugas saat ini untuk bangun jika nilainya belum tersedia.
    ///
    /// # Nilai kembali
    ///
    /// Fungsi ini mengembalikan:
    ///
    /// - [`Poll::Pending`] jika future belum siap
    /// - [`Poll::Ready(val)`] dengan hasil `val` dari future ini jika berhasil diselesaikan.
    ///
    /// Setelah future selesai, klien tidak boleh melakukan `poll` lagi.
    ///
    /// Ketika future belum siap, `poll` mengembalikan `Poll::Pending` dan menyimpan tiruan dari [`Waker`] yang disalin dari [`Context`] saat ini.
    /// [`Waker`] ini kemudian dibangunkan setelah future dapat membuat kemajuan.
    /// Misalnya, future menunggu soket menjadi dapat dibaca akan memanggil `.clone()` pada [`Waker`] dan menyimpannya.
    /// Ketika sinyal tiba di tempat lain yang menunjukkan bahwa soket dapat dibaca, [`Waker::wake`] dipanggil dan tugas soket future diaktifkan.
    /// Setelah tugas dibangunkan, tugas tersebut harus mencoba untuk `poll` future lagi, yang mungkin atau mungkin tidak menghasilkan nilai akhir.
    ///
    /// Perhatikan bahwa pada beberapa panggilan ke `poll`, hanya [`Waker`] dari [`Context`] yang diteruskan ke panggilan terbaru yang harus dijadwalkan untuk menerima bangun.
    ///
    /// # Karakteristik runtime
    ///
    /// Futures sendiri *inert*;mereka harus *secara aktif*`disurvei untuk membuat kemajuan, yang berarti bahwa setiap kali tugas saat ini dibangunkan, tugas tersebut harus secara aktif melakukan re-`poll` menunggu futures yang masih diminati.
    ///
    /// Fungsi `poll` tidak dipanggil berulang kali dalam loop yang ketat-sebaliknya, fungsi ini hanya akan dipanggil jika future menunjukkan bahwa ia siap untuk membuat kemajuan (dengan memanggil `wake()`).
    /// Jika Anda terbiasa dengan syscall `poll(2)` atau `select(2)` pada Unix, perlu diperhatikan bahwa futures biasanya *tidak* mengalami masalah yang sama dengan "all wakeups must poll all events";mereka lebih mirip `epoll(4)`.
    ///
    /// Implementasi `poll` harus berusaha untuk kembali dengan cepat, dan tidak boleh diblokir.Kembali dengan cepat mencegah penyumbatan thread atau loop acara yang tidak perlu.
    /// Jika diketahui sebelumnya bahwa panggilan ke `poll` mungkin membutuhkan waktu beberapa saat, pekerjaan harus dipindahkan ke kumpulan utas (atau yang serupa) untuk memastikan bahwa `poll` dapat kembali dengan cepat.
    ///
    /// # Panics
    ///
    /// Setelah future selesai (mengembalikan `Ready` dari `poll`), memanggil metode `poll` lagi dapat panic, memblokir selamanya, atau menyebabkan jenis masalah lain;`Future` trait tidak menetapkan persyaratan tentang pengaruh panggilan semacam itu.
    /// Namun, karena metode `poll` tidak ditandai `unsafe`, aturan umum Rust berlaku: panggilan tidak boleh menyebabkan perilaku yang tidak ditentukan (kerusakan memori, penggunaan fungsi `unsafe` yang salah, atau sejenisnya), terlepas dari status future.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}