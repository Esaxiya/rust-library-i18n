#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Memperluas ke `$crate::panic::panic_2015` atau `$crate::panic::panic_2021` tergantung pada edisi pemanggil.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Menegaskan bahwa dua ekspresi sama satu sama lain (menggunakan [`PartialEq`]).
///
/// Di panic, makro ini akan mencetak nilai ekspresi dengan representasi debugnya.
///
///
/// Seperti [`assert!`], makro ini memiliki bentuk kedua, di mana pesan panic khusus dapat disediakan.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Reborrows di bawah ini disengaja.
                    // Tanpa mereka, slot tumpukan untuk peminjaman diinisialisasi bahkan sebelum nilainya dibandingkan, yang menyebabkan perlambatan yang nyata.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Reborrows di bawah ini disengaja.
                    // Tanpa mereka, slot tumpukan untuk peminjaman diinisialisasi bahkan sebelum nilainya dibandingkan, yang menyebabkan perlambatan yang nyata.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Menegaskan bahwa dua ekspresi tidak sama satu sama lain (menggunakan [`PartialEq`]).
///
/// Di panic, makro ini akan mencetak nilai ekspresi dengan representasi debugnya.
///
///
/// Seperti [`assert!`], makro ini memiliki bentuk kedua, di mana pesan panic khusus dapat disediakan.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Reborrows di bawah ini disengaja.
                    // Tanpa mereka, slot tumpukan untuk peminjaman diinisialisasi bahkan sebelum nilainya dibandingkan, yang menyebabkan perlambatan yang nyata.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Reborrows di bawah ini disengaja.
                    // Tanpa mereka, slot tumpukan untuk peminjaman diinisialisasi bahkan sebelum nilainya dibandingkan, yang menyebabkan perlambatan yang nyata.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Menegaskan bahwa ekspresi boolean adalah `true` saat runtime.
///
/// Ini akan memanggil makro [`panic!`] jika ekspresi yang diberikan tidak dapat dievaluasi ke `true` saat runtime.
///
/// Seperti [`assert!`], makro ini juga memiliki versi kedua, di mana pesan panic khusus dapat disediakan.
///
/// # Uses
///
/// Tidak seperti [`assert!`], pernyataan `debug_assert!` hanya diaktifkan di build yang tidak dioptimalkan secara default.
/// Build yang dioptimalkan tidak akan menjalankan pernyataan `debug_assert!` kecuali `-C debug-assertions` diteruskan ke compiler.
/// Hal ini membuat `debug_assert!` berguna untuk pemeriksaan yang terlalu mahal untuk hadir dalam versi rilis tetapi mungkin berguna selama pengembangan.
/// Hasil perluasan `debug_assert!` selalu dicentang jenisnya.
///
/// Penegasan yang tidak dicentang memungkinkan program dalam keadaan tidak konsisten untuk terus berjalan, yang mungkin memiliki konsekuensi yang tidak terduga tetapi tidak menimbulkan ketidakamanan selama ini hanya terjadi dalam kode yang aman.
///
/// Namun, biaya kinerja pernyataan tidak dapat diukur secara umum.
/// Mengganti [`assert!`] dengan `debug_assert!` dengan demikian hanya dianjurkan setelah pembuatan profil menyeluruh, dan yang lebih penting, hanya dalam kode yang aman!
///
/// # Examples
///
/// ```
/// // pesan panic untuk pernyataan ini adalah nilai string dari ekspresi yang diberikan.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // fungsi yang sangat sederhana
/// debug_assert!(some_expensive_computation());
///
/// // menegaskan dengan pesan khusus
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Menegaskan bahwa dua ekspresi sama satu sama lain.
///
/// Di panic, makro ini akan mencetak nilai ekspresi dengan representasi debugnya.
///
/// Tidak seperti [`assert_eq!`], pernyataan `debug_assert_eq!` hanya diaktifkan di build yang tidak dioptimalkan secara default.
/// Build yang dioptimalkan tidak akan menjalankan pernyataan `debug_assert_eq!` kecuali `-C debug-assertions` diteruskan ke compiler.
/// Hal ini membuat `debug_assert_eq!` berguna untuk pemeriksaan yang terlalu mahal untuk hadir dalam versi rilis tetapi mungkin berguna selama pengembangan.
///
/// Hasil perluasan `debug_assert_eq!` selalu dicentang jenisnya.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Menegaskan bahwa dua ekspresi tidak sama satu sama lain.
///
/// Di panic, makro ini akan mencetak nilai ekspresi dengan representasi debugnya.
///
/// Tidak seperti [`assert_ne!`], pernyataan `debug_assert_ne!` hanya diaktifkan di build yang tidak dioptimalkan secara default.
/// Build yang dioptimalkan tidak akan menjalankan pernyataan `debug_assert_ne!` kecuali `-C debug-assertions` diteruskan ke compiler.
/// Hal ini membuat `debug_assert_ne!` berguna untuk pemeriksaan yang terlalu mahal untuk hadir dalam versi rilis tetapi mungkin berguna selama pengembangan.
///
/// Hasil perluasan `debug_assert_ne!` selalu dicentang jenisnya.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Mengembalikan apakah ekspresi yang diberikan cocok dengan salah satu pola yang diberikan.
///
/// Seperti dalam ekspresi `match`, pola dapat diikuti secara opsional oleh `if` dan ekspresi pelindung yang memiliki akses ke nama yang terikat oleh pola.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Membuka hasil atau menyebarkan kesalahannya.
///
/// Operator `?` telah ditambahkan untuk menggantikan `try!` dan harus digunakan sebagai gantinya.
/// Selain itu, `try` adalah kata yang dicadangkan di Rust 2018, jadi jika Anda harus menggunakannya, Anda harus menggunakan [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` cocok dengan [`Result`] yang diberikan.Untuk varian `Ok`, ekspresi memiliki nilai dari nilai yang dibungkus.
///
/// Dalam kasus varian `Err`, itu mengambil kesalahan dalam.`try!` kemudian melakukan konversi menggunakan `From`.
/// Ini memberikan konversi otomatis antara kesalahan khusus dan kesalahan yang lebih umum.
/// Kesalahan yang dihasilkan kemudian segera dikembalikan.
///
/// Karena pengembalian awal, `try!` hanya dapat digunakan dalam fungsi yang mengembalikan [`Result`].
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Metode yang disukai untuk mengembalikan Kesalahan dengan cepat
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Metode sebelumnya untuk mengembalikan Kesalahan dengan cepat
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Ini sama dengan:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Menulis data yang diformat ke dalam buffer.
///
/// Makro ini menerima 'writer', string format, dan daftar argumen.
/// Argumen akan diformat sesuai dengan format string yang ditentukan dan hasilnya akan diteruskan ke penulis.
/// Penulis mungkin memiliki nilai apa pun dengan metode `write_fmt`;umumnya ini berasal dari implementasi [`fmt::Write`] atau [`io::Write`] trait.
/// Makro mengembalikan apa pun yang dikembalikan metode `write_fmt`;biasanya [`fmt::Result`], atau [`io::Result`].
///
/// Lihat [`std::fmt`] untuk informasi lebih lanjut tentang format string sintaks.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Sebuah modul dapat mengimpor `std::fmt::Write` dan `std::io::Write` dan memanggil `write!` pada objek yang mengimplementasikan keduanya, karena objek biasanya tidak mengimplementasikan keduanya.
///
/// Namun, modul harus mengimpor traits yang memenuhi syarat sehingga namanya tidak bertentangan:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // menggunakan fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // menggunakan io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Makro ini juga dapat digunakan dalam pengaturan `no_std`.
/// Dalam pengaturan `no_std` Anda bertanggung jawab atas detail implementasi komponen.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Tulis data yang diformat ke dalam buffer, dengan baris baru ditambahkan.
///
/// Di semua platform, baris baru adalah karakter LINE FEED (`\n`/`U+000A`) saja (tidak ada tambahan CARRIAGE RETURN (`\r`/`U+000D`).
///
/// Untuk informasi lebih lanjut, lihat [`write!`].Untuk informasi tentang sintaks string format, lihat [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Sebuah modul dapat mengimpor `std::fmt::Write` dan `std::io::Write` dan memanggil `write!` pada objek yang mengimplementasikan keduanya, karena objek biasanya tidak mengimplementasikan keduanya.
/// Namun, modul harus mengimpor traits yang memenuhi syarat sehingga namanya tidak bertentangan:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // menggunakan fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // menggunakan io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Menunjukkan kode yang tidak dapat dijangkau.
///
/// Ini berguna kapan pun kompilator tidak dapat menentukan bahwa beberapa kode tidak dapat dijangkau.Sebagai contoh:
///
/// * Cocokkan lengan dengan kondisi pelindung.
/// * Loop yang berhenti secara dinamis.
/// * Iterator yang berhenti secara dinamis.
///
/// Jika penentuan bahwa kode tidak dapat dijangkau terbukti tidak benar, program segera diakhiri dengan [`panic!`].
///
/// Mitra yang tidak aman dari makro ini adalah fungsi [`unreachable_unchecked`], yang akan menyebabkan perilaku tidak terdefinisi jika kode tercapai.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Ini akan selalu [`panic!`].
///
/// # Examples
///
/// Lengan korek api:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // kompilasi kesalahan jika dikomentari
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // salah satu implementasi x/3 yang paling buruk
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Menunjukkan kode yang tidak diterapkan dengan panik dengan pesan "not implemented".
///
/// Ini memungkinkan kode Anda untuk memeriksa-ketik, yang berguna jika Anda membuat prototipe atau menerapkan trait yang memerlukan beberapa metode yang tidak Anda rencanakan untuk digunakan semuanya.
///
/// Perbedaan antara `unimplemented!` dan [`todo!`] adalah bahwa meskipun `todo!` menyampaikan maksud untuk mengimplementasikan fungsionalitas nanti dan pesannya adalah "not yet implemented", `unimplemented!` tidak membuat klaim seperti itu.
/// Pesannya adalah "not implemented".
/// Juga beberapa IDE akan menandai `todo!` S.
///
/// # Panics
///
/// Ini akan selalu [`panic!`] karena `unimplemented!` hanyalah singkatan dari `panic!` dengan pesan tetap dan spesifik.
///
/// Seperti `panic!`, makro ini memiliki bentuk kedua untuk menampilkan nilai kustom.
///
/// # Examples
///
/// Katakanlah kita memiliki trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Kami ingin mengimplementasikan `Foo` untuk 'MyStruct', tetapi untuk beberapa alasan hanya masuk akal untuk mengimplementasikan fungsi `bar()`.
/// `baz()` dan `qux()` masih perlu didefinisikan dalam implementasi `Foo` kita, tetapi kita dapat menggunakan `unimplemented!` dalam definisinya agar kode kita dapat dikompilasi.
///
/// Kami masih ingin program kami berhenti berjalan jika metode yang tidak diterapkan tercapai.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // Tidak masuk akal untuk `baz` a `MyStruct`, jadi kami tidak memiliki logika sama sekali.
/////
///         // Ini akan menampilkan "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Kami memiliki beberapa logika di sini, Kami dapat menambahkan pesan ke tidak diimplementasikan!untuk menampilkan kelalaian kami.
///         // Ini akan menampilkan: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Menunjukkan kode yang belum selesai.
///
/// Ini dapat berguna jika Anda sedang membuat prototipe dan hanya ingin memeriksa jenis kode Anda.
///
/// Perbedaan antara [`unimplemented!`] dan `todo!` adalah bahwa meskipun `todo!` menyampaikan maksud untuk mengimplementasikan fungsionalitas nanti dan pesannya adalah "not yet implemented", `unimplemented!` tidak membuat klaim seperti itu.
/// Pesannya adalah "not implemented".
/// Juga beberapa IDE akan menandai `todo!` S.
///
/// # Panics
///
/// Ini akan selalu [`panic!`].
///
/// # Examples
///
/// Berikut adalah contoh beberapa kode yang sedang diproses.Kami memiliki trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Kami ingin menerapkan `Foo` pada salah satu tipe kami, tetapi kami juga ingin mengerjakan `bar()` terlebih dahulu.Agar kode kita dapat dikompilasi, kita perlu mengimplementasikan `baz()`, sehingga kita dapat menggunakan `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // implementasi berlangsung di sini
///     }
///
///     fn baz(&self) {
///         // jangan khawatir tentang menerapkan baz() untuk saat ini
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // kami bahkan tidak menggunakan baz(), jadi ini bagus.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Definisi makro bawaan.
///
/// Sebagian besar properti makro (stabilitas, visibilitas, dll.) Diambil dari kode sumber di sini, dengan pengecualian fungsi perluasan yang mengubah input makro menjadi output, fungsi tersebut disediakan oleh compiler.
///
///
pub(crate) mod builtin {

    /// Menyebabkan kompilasi gagal dengan pesan kesalahan yang diberikan saat ditemui.
    ///
    /// Makro ini harus digunakan ketika crate menggunakan strategi kompilasi bersyarat untuk memberikan pesan kesalahan yang lebih baik untuk kondisi yang salah.
    ///
    /// Ini adalah bentuk tingkat kompiler [`panic!`], tetapi mengeluarkan kesalahan selama *kompilasi* daripada pada *waktu proses*.
    ///
    /// # Examples
    ///
    /// Dua contoh tersebut adalah makro dan lingkungan `#[cfg]`.
    ///
    /// Memancarkan kesalahan kompiler yang lebih baik jika makro melewati nilai yang tidak valid.
    /// Tanpa branch terakhir, kompilator masih akan mengeluarkan kesalahan, tetapi pesan kesalahan tidak akan menyebutkan dua nilai yang valid.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Keluarkan kesalahan kompiler jika salah satu dari sejumlah fitur tidak tersedia.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Membuat parameter untuk makro pemformatan string lainnya.
    ///
    /// Makro ini berfungsi dengan mengambil format string literal yang berisi `{}` untuk setiap argumen tambahan yang diteruskan.
    /// `format_args!` menyiapkan parameter tambahan untuk memastikan keluaran dapat diinterpretasikan sebagai string dan mengkanonikalisasi argumen menjadi satu jenis.
    /// Setiap nilai yang mengimplementasikan [`Display`] trait dapat diteruskan ke `format_args!`, begitu juga implementasi [`Debug`] dapat diteruskan ke `{:?}` dalam string pemformatan.
    ///
    ///
    /// Makro ini menghasilkan nilai tipe [`fmt::Arguments`].Nilai ini dapat diteruskan ke makro dalam [`std::fmt`] untuk melakukan pengalihan yang berguna.
    /// Semua makro pemformatan lainnya ([`format!`], [`write!`], [`println!`], dll) di-proxy-kan melalui yang satu ini.
    /// `format_args!`, tidak seperti makro turunannya, alokasi heap menghindari.
    ///
    /// Anda dapat menggunakan nilai [`fmt::Arguments`] yang dikembalikan `format_args!` dalam konteks `Debug` dan `Display` seperti yang terlihat di bawah ini.
    /// Contoh juga menunjukkan bahwa format `Debug` dan `Display` sama: string format yang diinterpolasi di `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Untuk informasi lebih lanjut, lihat dokumentasi di [`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Sama seperti `format_args`, tetapi pada akhirnya menambahkan baris baru.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Memeriksa variabel lingkungan pada waktu kompilasi.
    ///
    /// Makro ini akan diperluas ke nilai variabel lingkungan bernama pada waktu kompilasi, menghasilkan ekspresi tipe `&'static str`.
    ///
    ///
    /// Jika variabel lingkungan tidak ditentukan, maka kesalahan kompilasi akan dikeluarkan.
    /// Untuk tidak mengeluarkan kesalahan kompilasi, gunakan makro [`option_env!`] sebagai gantinya.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Anda dapat menyesuaikan pesan kesalahan dengan meneruskan string sebagai parameter kedua:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Jika variabel lingkungan `documentation` tidak ditentukan, Anda akan mendapatkan kesalahan berikut:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Secara opsional, memeriksa variabel lingkungan pada waktu kompilasi.
    ///
    /// Jika variabel lingkungan bernama ada pada waktu kompilasi, ini akan diperluas menjadi ekspresi tipe `Option<&'static str>` yang nilainya `Some` dari nilai variabel lingkungan.
    /// Jika variabel lingkungan tidak ada, maka ini akan diperluas ke `None`.
    /// Lihat [`Option<T>`][Option] untuk informasi lebih lanjut tentang tipe ini.
    ///
    /// Kesalahan waktu kompilasi tidak pernah dikeluarkan saat menggunakan makro ini terlepas dari apakah variabel lingkungan ada atau tidak.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Menggabungkan pengenal menjadi satu pengenal.
    ///
    /// Makro ini mengambil sejumlah pengenal yang dipisahkan koma, dan menggabungkan semuanya menjadi satu, menghasilkan ekspresi yang merupakan pengenal baru.
    /// Perhatikan bahwa kebersihan membuatnya sedemikian rupa sehingga makro ini tidak dapat menangkap variabel lokal.
    /// Selain itu, sebagai aturan umum, makro hanya diperbolehkan dalam posisi item, pernyataan, atau ekspresi.
    /// Itu berarti meskipun Anda dapat menggunakan makro ini untuk merujuk ke variabel, fungsi atau modul yang ada, dll, Anda tidak dapat menentukan yang baru dengannya.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (baru, menyenangkan, nama) { }//tidak dapat digunakan dengan cara ini!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Menggabungkan literal menjadi potongan string statis.
    ///
    /// Makro ini mengambil literal yang dipisahkan koma berapa pun, menghasilkan ekspresi tipe `&'static str` yang mewakili semua literal yang digabungkan dari kiri ke kanan.
    ///
    ///
    /// Literal integer dan floating point dirangkai agar bisa digabungkan.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Memperluas ke nomor baris yang dipanggil.
    ///
    /// Dengan [`column!`] dan [`file!`], makro ini memberikan informasi debugging untuk pengembang tentang lokasi di dalam sumber.
    ///
    /// Ekspresi yang diperluas memiliki tipe `u32` dan berbasis 1, jadi baris pertama di setiap file bernilai 1, baris kedua ke 2, dll.
    /// Ini konsisten dengan pesan kesalahan oleh penyusun umum atau editor populer.
    /// Baris yang dikembalikan adalah *tidak harus* baris pemanggilan `line!` itu sendiri, melainkan pemanggilan makro pertama yang mengarah ke pemanggilan makro `line!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Memperluas ke nomor kolom tempat nomor tersebut dipanggil.
    ///
    /// Dengan [`line!`] dan [`file!`], makro ini memberikan informasi debugging untuk pengembang tentang lokasi di dalam sumber.
    ///
    /// Ekspresi yang diperluas memiliki tipe `u32` dan berbasis 1, jadi kolom pertama di setiap baris bernilai 1, yang kedua ke 2, dll.
    /// Ini konsisten dengan pesan kesalahan oleh penyusun umum atau editor populer.
    /// Kolom yang dikembalikan adalah *tidak harus* baris pemanggilan `column!` itu sendiri, melainkan pemanggilan makro pertama yang mengarah ke pemanggilan makro `column!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Memperluas ke nama file yang dipanggil.
    ///
    /// Dengan [`line!`] dan [`column!`], makro ini memberikan informasi debugging untuk pengembang tentang lokasi di dalam sumber.
    ///
    /// Ekspresi yang diperluas memiliki tipe `&'static str`, dan file yang dikembalikan bukan pemanggilan makro `file!` itu sendiri, melainkan pemanggilan makro pertama yang mengarah ke pemanggilan makro `file!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Merangkai argumennya.
    ///
    /// Makro ini akan menghasilkan ekspresi tipe `&'static str` yang merupakan stringifikasi dari semua tokens yang diteruskan ke makro.
    /// Tidak ada batasan yang ditempatkan pada sintaks pemanggilan makro itu sendiri.
    ///
    /// Perhatikan bahwa hasil yang diperluas dari input tokens dapat berubah di future.Anda harus berhati-hati jika mengandalkan hasilnya.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Termasuk file yang dikodekan UTF-8 sebagai string.
    ///
    /// File terletak relatif terhadap file saat ini (mirip dengan bagaimana modul ditemukan).
    /// Jalur yang disediakan diinterpretasikan dengan cara khusus platform pada waktu kompilasi.
    /// Jadi, misalnya, pemanggilan dengan jalur Windows yang berisi garis miring terbalik `\` tidak akan dikompilasi dengan benar di Unix.
    ///
    ///
    /// Makro ini akan menghasilkan ekspresi tipe `&'static str` yang merupakan konten file.
    ///
    /// # Examples
    ///
    /// Asumsikan ada dua file di direktori yang sama dengan konten berikut:
    ///
    /// File 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// File 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// Mengompilasi 'main.rs' dan menjalankan biner yang dihasilkan akan mencetak "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Menyertakan file sebagai referensi ke array byte.
    ///
    /// File terletak relatif terhadap file saat ini (mirip dengan bagaimana modul ditemukan).
    /// Jalur yang disediakan diinterpretasikan dengan cara khusus platform pada waktu kompilasi.
    /// Jadi, misalnya, pemanggilan dengan jalur Windows yang berisi garis miring terbalik `\` tidak akan dikompilasi dengan benar di Unix.
    ///
    ///
    /// Makro ini akan menghasilkan ekspresi tipe `&'static [u8; N]` yang merupakan konten file.
    ///
    /// # Examples
    ///
    /// Asumsikan ada dua file di direktori yang sama dengan konten berikut:
    ///
    /// File 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// File 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// Mengompilasi 'main.rs' dan menjalankan biner yang dihasilkan akan mencetak "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Memperluas ke string yang mewakili jalur modul saat ini.
    ///
    /// Jalur modul saat ini dapat dianggap sebagai hierarki modul yang mengarah kembali ke crate root.
    /// Komponen pertama dari jalur yang dikembalikan adalah nama crate yang saat ini sedang dikompilasi.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Mengevaluasi kombinasi boolean dari flag konfigurasi pada waktu kompilasi.
    ///
    /// Selain atribut `#[cfg]`, makro ini disediakan untuk memungkinkan evaluasi ekspresi boolean dari tanda konfigurasi.
    /// Hal ini sering kali menyebabkan lebih sedikit duplikasi kode.
    ///
    /// Sintaks yang diberikan ke makro ini adalah sintaks yang sama dengan atribut [`cfg`].
    ///
    /// `cfg!`, tidak seperti `#[cfg]`, tidak menghapus kode apa pun dan hanya mengevaluasi benar atau salah.
    /// Misalnya, semua blok dalam ekspresi if/else harus valid saat `cfg!` digunakan untuk kondisi tersebut, terlepas dari apa yang dievaluasi oleh `cfg!`.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Mengurai file sebagai ekspresi atau item sesuai dengan konteksnya.
    ///
    /// File terletak relatif terhadap file saat ini (mirip dengan bagaimana modul ditemukan).Jalur yang disediakan diinterpretasikan dengan cara khusus platform pada waktu kompilasi.
    /// Jadi, misalnya, pemanggilan dengan jalur Windows yang berisi garis miring terbalik `\` tidak akan dikompilasi dengan benar di Unix.
    ///
    /// Menggunakan makro ini seringkali merupakan ide yang buruk, karena jika file diuraikan sebagai ekspresi, itu akan ditempatkan di kode sekitarnya secara tidak higienis.
    /// Hal ini dapat mengakibatkan variabel atau fungsi berbeda dari yang diharapkan file jika ada variabel atau fungsi yang memiliki nama yang sama di file saat ini.
    ///
    ///
    /// # Examples
    ///
    /// Asumsikan ada dua file di direktori yang sama dengan konten berikut:
    ///
    /// File 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// File 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// Mengompilasi 'main.rs' dan menjalankan biner yang dihasilkan akan mencetak "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Menegaskan bahwa ekspresi boolean adalah `true` saat runtime.
    ///
    /// Ini akan memanggil makro [`panic!`] jika ekspresi yang diberikan tidak dapat dievaluasi ke `true` saat runtime.
    ///
    /// # Uses
    ///
    /// Pernyataan selalu diperiksa dalam versi debug dan rilis, dan tidak dapat dinonaktifkan.
    /// Lihat [`debug_assert!`] untuk pernyataan yang tidak diaktifkan dalam rilis build secara default.
    ///
    /// Kode yang tidak aman dapat mengandalkan `assert!` untuk menerapkan invarian waktu proses yang, jika dilanggar, dapat menyebabkan ketidakamanan.
    ///
    /// Kasus penggunaan `assert!` lainnya termasuk pengujian dan penerapan run-time invariants dalam kode yang aman (yang pelanggarannya tidak dapat mengakibatkan ketidakamanan).
    ///
    ///
    /// # Pesan Kustom
    ///
    /// Makro ini memiliki bentuk kedua, di mana pesan panic kustom dapat diberikan dengan atau tanpa argumen untuk pemformatan.
    /// Lihat [`std::fmt`] untuk sintaks formulir ini.
    /// Ekspresi yang digunakan sebagai argumen format hanya akan dievaluasi jika pernyataan gagal.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // pesan panic untuk pernyataan ini adalah nilai string dari ekspresi yang diberikan.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // fungsi yang sangat sederhana
    ///
    /// assert!(some_computation());
    ///
    /// // menegaskan dengan pesan khusus
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Perakitan inline.
    ///
    /// Baca [unstable book] untuk penggunaannya.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// Perakitan inline bergaya LLVM.
    ///
    /// Baca [unstable book] untuk penggunaannya.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Perakitan sebaris tingkat modul.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Cetakan melewati tokens ke dalam keluaran standar.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Mengaktifkan atau menonaktifkan fungsionalitas pelacakan yang digunakan untuk men-debug makro lain.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Atribut makro yang digunakan untuk menerapkan makro turunan.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Makro atribut diterapkan ke suatu fungsi untuk mengubahnya menjadi pengujian unit.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Makro atribut diterapkan ke suatu fungsi untuk mengubahnya menjadi pengujian tolok ukur.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// Detail implementasi makro `#[test]` dan `#[bench]`.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Atribut makro diterapkan ke statis untuk mendaftarkannya sebagai pengalokasi global.
    ///
    /// Lihat juga [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Mempertahankan item yang diterapkan jika jalur yang diteruskan dapat diakses, dan menghapusnya jika tidak.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Memperluas semua atribut `#[cfg]` dan `#[cfg_attr]` dalam fragmen kode yang diterapkan padanya.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Detail implementasi kompilator `rustc` yang tidak stabil, jangan gunakan.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Detail implementasi kompilator `rustc` yang tidak stabil, jangan gunakan.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}