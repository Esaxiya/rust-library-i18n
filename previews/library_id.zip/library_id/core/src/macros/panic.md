Panics utas saat ini.

Hal ini memungkinkan program untuk segera dihentikan dan memberikan umpan balik kepada pemanggil program.
`panic!` harus digunakan ketika program mencapai keadaan tidak dapat dipulihkan.

Makro ini adalah cara sempurna untuk menegaskan kondisi dalam kode contoh dan pengujian.
`panic!` terkait erat dengan metode `unwrap` untuk enum [`Option`][ounwrap] dan [`Result`][runwrap].
Kedua implementasi memanggil `panic!` jika disetel ke varian [`None`] atau [`Err`].

Saat menggunakan `panic!()` Anda dapat menentukan payload string, yang dibuat menggunakan sintaks [`format!`].
Muatan itu digunakan saat menginjeksi panic ke thread pemanggil Rust, menyebabkan thread ke panic seluruhnya.

Perilaku `std` hook default, yaitu
kode yang berjalan langsung setelah panic dipanggil, adalah untuk mencetak muatan pesan ke `stderr` bersama dengan informasi file/line/column dari panggilan `panic!()`.

Anda dapat mengganti panic hook menggunakan [`std::panic::set_hook()`].
Di dalam hook, panic dapat diakses sebagai `&dyn Any + Send`, yang berisi `&str` atau `String` untuk pemanggilan `panic!()` biasa.
Untuk panic dengan nilai tipe lain, [`panic_any`] dapat digunakan.

[`Result`] enum sering kali merupakan solusi yang lebih baik untuk memulihkan kesalahan daripada menggunakan makro `panic!`.
Makro ini harus digunakan untuk menghindari melanjutkan menggunakan nilai yang salah, seperti dari sumber eksternal.
Informasi rinci tentang penanganan kesalahan ditemukan di [book].

Lihat juga makro [`compile_error!`], untuk meningkatkan kesalahan selama kompilasi.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Implementasi saat ini

Jika utas utama panics itu akan menghentikan semua utas Anda dan mengakhiri program Anda dengan kode `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





