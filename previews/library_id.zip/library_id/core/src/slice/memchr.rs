// Implementasi asli diambil dari rust-memchr.
// Hak Cipta 2015 Andrew Gallant, bluss dan Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Gunakan pemotongan.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Mengembalikan `true` jika `x` berisi nol byte.
///
/// Dari *Matters Computational*, J. Arndt:
///
/// "Idenya adalah untuk mengurangi satu dari masing-masing byte dan kemudian mencari byte di mana pinjaman disebarkan sampai ke yang paling signifikan
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Mengembalikan indeks pertama yang cocok dengan byte `x` di `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Jalur cepat untuk irisan kecil
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Pindai nilai byte tunggal dengan membaca dua kata `usize` sekaligus.
    //
    // Pisahkan `text` menjadi tiga bagian
    // - bagian awal tidak selaras, sebelum kata pertama alamat rata dalam teks
    // - tubuh, pindai dengan 2 kata sekaligus
    // - bagian terakhir yang tersisa, <2 kata ukuran

    // cari hingga batas rata
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // cari tubuh teks
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // SAFETY: predikat while menjamin jarak minimal 2 * usize_bytes
        // antara offset dan akhir potongan.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // putus jika ada byte yang cocok
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Temukan byte setelah titik pengulangan tubuh berhenti.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Mengembalikan indeks terakhir yang cocok dengan byte `x` di `text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Pindai nilai byte tunggal dengan membaca dua kata `usize` sekaligus.
    //
    // Pisahkan `text` menjadi tiga bagian:
    // - ekor tidak selaras, setelah kata terakhir alamat rata dalam teks,
    // - tubuh, dipindai oleh 2 kata sekaligus,
    // - byte pertama yang tersisa, <2 word size.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Kami menyebutnya hanya untuk mendapatkan panjang prefiks dan sufiks.
        // Di tengah kami selalu memproses dua bagian sekaligus.
        // KEAMANAN: mentransmutasikan `[u8]` ke `[usize]` aman kecuali untuk perbedaan ukuran yang ditangani oleh `align_to`.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Telusuri badan teks, pastikan kami tidak melewati min_aligned_offset.
    // offset selalu sejajar, jadi hanya menguji `>` sudah cukup dan menghindari kemungkinan overflow.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // SAFETY: offset dimulai pada len, suffix.len(), selama lebih besar dari
        // min_aligned_offset (prefix.len()) jarak yang tersisa setidaknya 2 * chunk_bytes.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Putuskan jika ada byte yang cocok.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Temukan byte sebelum titik loop tubuh berhenti.
    text[..offset].iter().rposition(|elt| *elt == x)
}