// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Memutar rentang `[mid-left, mid+right)` sedemikian rupa sehingga elemen di `mid` menjadi elemen pertama.Secara setara, putar elemen rentang `left` ke kiri atau elemen `right` ke kanan.
///
/// # Safety
///
/// Rentang yang ditentukan harus valid untuk membaca dan menulis.
///
/// # Algorithm
///
/// Algoritma 1 digunakan untuk nilai kecil `left + right` atau untuk `T` besar.
/// Elemen dipindahkan ke posisi terakhirnya satu per satu mulai dari `mid - left` dan maju dengan langkah `right` modulo `left + right`, sehingga hanya diperlukan satu sementara.
/// Akhirnya, kami tiba kembali di `mid - left`.
/// Namun, jika `gcd(left + right, right)` bukan 1, langkah di atas akan melompati elemen.
/// Sebagai contoh:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Untungnya, jumlah elemen yang dilewati di antara elemen yang diselesaikan selalu sama, jadi kita bisa mengimbangi posisi awal dan melakukan lebih banyak putaran (jumlah total putaran adalah `gcd(left + right, right)` value).
///
/// Hasil akhirnya adalah semua elemen diselesaikan satu kali dan hanya sekali.
///
/// Algoritme 2 digunakan jika `left + right` besar tetapi `min(left, right)` cukup kecil untuk muat ke buffer tumpukan.
/// Elemen `min(left, right)` disalin ke buffer, `memmove` diterapkan ke yang lain, dan elemen yang ada di buffer dipindahkan kembali ke lubang di sisi berlawanan dari tempat asalnya.
///
/// Algoritme yang dapat di-vektorisasi mengungguli yang di atas setelah `left + right` menjadi cukup besar.
/// Algoritma 1 dapat vektorisasi dengan memotong dan melakukan banyak putaran sekaligus, tetapi rata-rata ada terlalu sedikit putaran sampai `left + right` sangat besar, dan kasus terburuk dari satu putaran selalu ada.
/// Alih-alih, algoritme 3 menggunakan pertukaran berulang elemen `min(left, right)` hingga masalah rotasi yang lebih kecil tersisa.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// ketika `left < right` pertukaran terjadi dari kiri sebagai gantinya.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. algoritma di bawah ini bisa gagal jika kasus ini tidak diperiksa
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Algoritme 1 Tanda mikro menunjukkan bahwa kinerja rata-rata untuk pergantian acak lebih baik hingga sekitar `left + right == 32`, tetapi kinerja kasus terburuk mencapai titik impas sekitar 16.
            // 24 dipilih sebagai jalan tengah.
            // Jika ukuran `T` lebih besar dari 4 `usize`, algoritme ini juga mengungguli algoritme lainnya.
            //
            //
            let x = unsafe { mid.sub(left) };
            // awal ronde pertama
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` dapat ditemukan sebelumnya dengan menghitung `gcd(left + right, right)`, tetapi lebih cepat melakukan satu putaran yang menghitung gcd sebagai efek samping, kemudian melakukan sisa potongan
            //
            //
            let mut gcd = right;
            // benchmark mengungkapkan bahwa lebih cepat menukar temporer sepenuhnya daripada membaca satu sementara sekali, menyalin ke belakang, dan kemudian menulis sementara itu di bagian paling akhir.
            // Hal ini mungkin karena fakta bahwa menukar atau mengganti temporaries hanya menggunakan satu alamat memori dalam loop daripada perlu mengelola dua alamat memori.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // alih-alih menaikkan `i` dan kemudian memeriksa apakah itu di luar batas, kami memeriksa apakah `i` akan melampaui batas pada kenaikan berikutnya.
                // Ini mencegah pembungkusan pointer atau `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // akhir babak pertama
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // persyaratan ini harus ada di sini jika `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // selesaikan potongan dengan lebih banyak putaran
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` bukan tipe berukuran nol, jadi tidak masalah untuk membaginya dengan ukurannya.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Algoritme 2 `[T; 0]` di sini adalah untuk memastikan bahwa ini selaras dengan tepat untuk T
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algoritma 3 Ada cara alternatif untuk menukar yang melibatkan menemukan di mana pertukaran terakhir dari algoritma ini akan berada, dan menukar menggunakan potongan terakhir itu daripada menukar potongan yang berdekatan seperti yang dilakukan algoritma ini, tetapi cara ini masih lebih cepat.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Algoritma 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}