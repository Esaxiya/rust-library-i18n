//! Makro yang digunakan oleh iterator irisan.

// Membariskan is_empty dan len membuat perbedaan performa yang sangat besar
macro_rules! is_empty {
    // Cara kami menyandikan panjang iterator ZST, ini berfungsi baik untuk ZST dan non-ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Untuk menghilangkan beberapa pemeriksaan batas (lihat `position`), kami menghitung panjang dengan cara yang tidak terduga.
// (Diuji oleh `codegen/slice-position-bounds-check`.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // terkadang kami digunakan dalam blok yang tidak aman

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // _cannot_ ini menggunakan `unchecked_sub` karena kita bergantung pada pembungkus untuk mewakili panjang iterator irisan ZST yang panjang.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Kami tahu bahwa `start <= end`, jadi bisa melakukan lebih baik daripada `offset_from`, yang harus ditangani dengan tanda tangan.
            // Dengan menyetel flag yang sesuai di sini kita dapat memberi tahu LLVM hal ini, yang membantunya menghapus pemeriksaan batas.
            // KEAMANAN: Berdasarkan jenis invarian, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Dengan juga memberi tahu LLVM bahwa pointer dipisahkan oleh beberapa ukuran tipe yang tepat, itu dapat mengoptimalkan `len() == 0` ke `start == end` daripada `(end - start) < size`.
            //
            // KEAMANAN: Berdasarkan tipe invarian, pointer sejajar sehingga
            //         jarak antara mereka harus kelipatan dari ukuran pointee
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// Definisi bersama dari iterator `Iter` dan `IterMut`
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Mengembalikan elemen pertama dan memindahkan awal iterator ke depan sebesar 1.
        // Sangat meningkatkan kinerja dibandingkan dengan fungsi sebaris.
        // Iterator tidak boleh kosong.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Mengembalikan elemen terakhir dan memindahkan ujung iterator mundur sebesar 1.
        // Sangat meningkatkan kinerja dibandingkan dengan fungsi sebaris.
        // Iterator tidak boleh kosong.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Kecilkan iterator saat T adalah ZST, dengan menggerakkan ujung iterator ke belakang sebesar `n`.
        // `n` tidak boleh melebihi `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Fungsi pembantu untuk membuat potongan dari iterator.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // KEAMANAN: iterator dibuat dari potongan dengan pointer
                // `self.ptr` dan panjang `len!(self)`.
                // Ini menjamin bahwa semua prasyarat untuk `from_raw_parts` terpenuhi.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Fungsi pembantu untuk memindahkan awal iterator ke depan dengan elemen `offset`, mengembalikan awal yang lama.
            //
            // Tidak aman karena offset tidak boleh melebihi `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // KEAMANAN: penelepon menjamin bahwa `offset` tidak melebihi `self.len()`,
                    // jadi pointer baru ini ada di dalam `self` dan dengan demikian dijamin bukan null.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Fungsi pembantu untuk memindahkan ujung iterator mundur dengan elemen `offset`, mengembalikan ujung yang baru.
            //
            // Tidak aman karena offset tidak boleh melebihi `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // KEAMANAN: penelepon menjamin bahwa `offset` tidak melebihi `self.len()`,
                    // yang dijamin tidak akan meluap `isize`.
                    // Juga, penunjuk yang dihasilkan berada dalam batas `slice`, yang memenuhi persyaratan lain untuk `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // dapat diimplementasikan dengan irisan, tetapi ini menghindari pemeriksaan batas

                // KEAMANAN: Panggilan `assume` aman karena penunjuk awal slice
                // harus bukan nol, dan irisan di atas selain ZST juga harus memiliki penunjuk akhir bukan nol.
                // Panggilan ke `next_unchecked!` aman karena kami memeriksa apakah iterator kosong terlebih dahulu.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Iterator ini sekarang kosong.
                    if mem::size_of::<T>() == 0 {
                        // Kita harus melakukannya dengan cara ini karena `ptr` mungkin tidak pernah 0, tetapi `end` bisa jadi (karena pembungkusan).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // SAFETY: end tidak bisa 0 jika T bukan ZST karena ptr bukan 0 dan end>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // KEAMANAN: Kami berada di batas.`post_inc_start` melakukan hal yang benar bahkan untuk ZST.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Kami mengganti implementasi default, yang menggunakan `try_fold`, karena implementasi sederhana ini menghasilkan IR LLVM yang lebih sedikit dan lebih cepat untuk dikompilasi.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Kami mengganti implementasi default, yang menggunakan `try_fold`, karena implementasi sederhana ini menghasilkan IR LLVM yang lebih sedikit dan lebih cepat untuk dikompilasi.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Kami mengganti implementasi default, yang menggunakan `try_fold`, karena implementasi sederhana ini menghasilkan IR LLVM yang lebih sedikit dan lebih cepat untuk dikompilasi.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Kami mengganti implementasi default, yang menggunakan `try_fold`, karena implementasi sederhana ini menghasilkan IR LLVM yang lebih sedikit dan lebih cepat untuk dikompilasi.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Kami mengganti implementasi default, yang menggunakan `try_fold`, karena implementasi sederhana ini menghasilkan IR LLVM yang lebih sedikit dan lebih cepat untuk dikompilasi.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Kami mengganti implementasi default, yang menggunakan `try_fold`, karena implementasi sederhana ini menghasilkan IR LLVM yang lebih sedikit dan lebih cepat untuk dikompilasi.
            // Selain itu, `assume` menghindari pemeriksaan batas.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // KESELAMATAN: kami dijamin akan dibatasi oleh invarian loop:
                        // ketika `i >= n`, `self.next()` mengembalikan `None` dan loop berhenti.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Kami mengganti implementasi default, yang menggunakan `try_fold`, karena implementasi sederhana ini menghasilkan IR LLVM yang lebih sedikit dan lebih cepat untuk dikompilasi.
            // Selain itu, `assume` menghindari pemeriksaan batas.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // KEAMANAN: `i` harus lebih rendah dari `n` karena dimulai pada `n`
                        // dan hanya menurun.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // KEAMANAN: penelepon harus menjamin bahwa `i` dalam batas
                // potongan yang mendasari, jadi `i` tidak dapat meluap `isize`, dan referensi yang dikembalikan dijamin merujuk ke elemen potongan dan dengan demikian dijamin valid.
                //
                // Perhatikan juga bahwa pemanggil juga menjamin bahwa kita tidak akan pernah dipanggil dengan indeks yang sama lagi, dan tidak ada metode lain yang akan mengakses subslice ini dipanggil, jadi valid untuk referensi yang dikembalikan dapat berubah dalam kasus
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // dapat diimplementasikan dengan irisan, tetapi ini menghindari pemeriksaan batas

                // KEAMANAN: Panggilan `assume` aman karena penunjuk awal slice tidak boleh null,
                // dan irisan di atas non-ZST juga harus memiliki penunjuk akhir bukan nol.
                // Panggilan ke `next_back_unchecked!` aman karena kami memeriksa apakah iterator kosong terlebih dahulu.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Iterator ini sekarang kosong.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // KEAMANAN: Kami berada di batas.`pre_dec_end` melakukan hal yang benar bahkan untuk ZST.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}