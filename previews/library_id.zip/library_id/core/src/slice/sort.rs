//! Penyortiran irisan
//!
//! Modul ini berisi algoritme pengurutan berdasarkan quicksort yang mengalahkan pola Orson Peters, diterbitkan di: <https://github.com/orlp/pdqsort>
//!
//!
//! Pengurutan tidak stabil kompatibel dengan libcore karena tidak mengalokasikan memori, tidak seperti implementasi pengurutan stabil kami.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Saat dijatuhkan, salinan dari `src` ke `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // KEAMANAN: Ini adalah kelas penolong.
        //          Silakan lihat penggunaannya untuk kebenaran.
        //          Yaitu, seseorang harus yakin bahwa `src` dan `dst` tidak tumpang tindih seperti yang disyaratkan oleh `ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Menggeser elemen pertama ke kanan hingga menemukan elemen yang lebih besar atau sama.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // KEAMANAN: Operasi tidak aman di bawah ini melibatkan pengindeksan tanpa pemeriksaan terikat (`get_unchecked` dan `get_unchecked_mut`)
    // dan menyalin memori (`ptr::copy_nonoverlapping`).
    //
    // Sebuah.Pengindeksan:
    //  1. Kami memeriksa ukuran array ke>=2.
    //  2. Semua pengindeksan yang akan kami lakukan selalu antara {0 <= index < len} paling banyak.
    //
    // b.Penyalinan memori
    //  1. Kami memperoleh petunjuk ke referensi yang dijamin valid.
    //  2. Mereka tidak dapat tumpang tindih karena kami memperoleh petunjuk ke indeks perbedaan dari potongan tersebut.
    //     Yakni, `i` dan `i-1`.
    //  3. Jika potongan diratakan dengan benar, elemen-elemennya diratakan dengan benar.
    //     Merupakan tanggung jawab penelepon untuk memastikan potongannya sejajar dengan benar.
    //
    // Lihat komentar di bawah untuk detail lebih lanjut.
    unsafe {
        // Jika dua elemen pertama rusak ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Baca elemen pertama ke dalam variabel yang dialokasikan dengan tumpukan.
            // Jika operasi perbandingan berikut panics, `hole` akan dihapus dan secara otomatis menulis elemen kembali ke potongan.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Pindahkan elemen `i`-th satu tempat ke kiri, dengan demikian menggeser lubang ke kanan.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` dijatuhkan dan dengan demikian menyalin `tmp` ke lubang yang tersisa di `v`.
        }
    }
}

/// Menggeser elemen terakhir ke kiri hingga menemukan elemen yang lebih kecil atau sama.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // KEAMANAN: Operasi tidak aman di bawah ini melibatkan pengindeksan tanpa pemeriksaan terikat (`get_unchecked` dan `get_unchecked_mut`)
    // dan menyalin memori (`ptr::copy_nonoverlapping`).
    //
    // Sebuah.Pengindeksan:
    //  1. Kami memeriksa ukuran array ke>=2.
    //  2. Semua pengindeksan yang akan kami lakukan selalu antara `0 <= index < len-1` paling banyak.
    //
    // b.Penyalinan memori
    //  1. Kami memperoleh petunjuk ke referensi yang dijamin valid.
    //  2. Mereka tidak dapat tumpang tindih karena kami memperoleh petunjuk ke indeks perbedaan dari potongan tersebut.
    //     Yakni, `i` dan `i+1`.
    //  3. Jika potongan diratakan dengan benar, elemen-elemennya diratakan dengan benar.
    //     Merupakan tanggung jawab penelepon untuk memastikan potongannya sejajar dengan benar.
    //
    // Lihat komentar di bawah untuk detail lebih lanjut.
    unsafe {
        // Jika dua elemen terakhir rusak ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Baca elemen terakhir ke dalam variabel yang dialokasikan dengan tumpukan.
            // Jika operasi perbandingan berikut panics, `hole` akan dihapus dan secara otomatis menulis elemen kembali ke potongan.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Pindahkan elemen `i`-th satu tempat ke kanan, dengan demikian menggeser lubang ke kiri.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` dijatuhkan dan dengan demikian menyalin `tmp` ke lubang yang tersisa di `v`.
        }
    }
}

/// Sortir sebagian irisan dengan menggeser beberapa elemen yang tidak teratur di sekitarnya.
///
/// Mengembalikan `true` jika potongan diurutkan di bagian akhir.Fungsi ini adalah *O*(*n*) kasus terburuk.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Jumlah maksimum pasangan out-of-order yang berdekatan yang akan digeser.
    const MAX_STEPS: usize = 5;
    // Jika potongan lebih pendek dari ini, jangan menggeser elemen apa pun.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // KEAMANAN: Kami sudah secara eksplisit melakukan pemeriksaan terikat dengan `i < len`.
        // Semua pengindeksan kami berikutnya hanya dalam kisaran `0 <= index < len`
        unsafe {
            // Temukan pasangan berikutnya dari elemen out-of-order yang berdekatan.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Sudahkah kita selesai?
        if i == len {
            return true;
        }

        // Jangan menggeser elemen pada larik pendek, yang memiliki biaya kinerja.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Tukar pasangan elemen yang ditemukan.Ini menempatkan mereka dalam urutan yang benar.
        v.swap(i - 1, i);

        // Geser elemen yang lebih kecil ke kiri.
        shift_tail(&mut v[..i], is_less);
        // Geser elemen yang lebih besar ke kanan.
        shift_head(&mut v[i..], is_less);
    }

    // Tidak berhasil mengurutkan irisan dalam jumlah langkah yang terbatas.
    false
}

/// Mengurutkan irisan menggunakan semacam penyisipan, yang merupakan kasus terburuk *O*(*n*^ 2).
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Mengurutkan `v` menggunakan heapsort, yang menjamin *O*(*n*\*log(* n*)) kasus terburuk.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Tumpukan biner ini menghormati invarian `parent >= child`.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Anak-anak `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Pilih anak yang lebih besar.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Hentikan jika invarian bertahan di `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Tukar `node` dengan anak yang lebih besar, turun satu langkah ke bawah, dan lanjutkan mengayak.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Bangun heap dalam waktu linier.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Munculkan elemen maksimal dari heap.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Partisi `v` menjadi elemen yang lebih kecil dari `pivot`, diikuti oleh elemen yang lebih besar dari atau sama dengan `pivot`.
///
///
/// Mengembalikan jumlah elemen yang lebih kecil dari `pivot`.
///
/// Partisi dilakukan blok-demi-blok untuk meminimalkan biaya operasi percabangan.
/// Ide ini dipresentasikan di kertas [BlockQuicksort][pdf].
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Jumlah elemen dalam blok tipikal.
    const BLOCK: usize = 128;

    // Algoritme partisi mengulangi langkah-langkah berikut sampai selesai:
    //
    // 1. Lacak blok dari sisi kiri untuk mengidentifikasi elemen yang lebih besar dari atau sama dengan poros.
    // 2. Lacak blok dari sisi kanan untuk mengidentifikasi elemen yang lebih kecil dari poros.
    // 3. Tukarkan elemen yang diidentifikasi antara sisi kiri dan kanan.
    //
    // Kami menyimpan variabel berikut untuk satu blok elemen:
    //
    // 1. `block` - Jumlah elemen di blok.
    // 2. `start` - Mulai penunjuk ke dalam larik `offsets`.
    // 3. `end` - Akhiri penunjuk ke dalam larik `offsets`.
    // 4. `offset, Indeks elemen yang rusak di dalam blok.

    // Blok saat ini di sisi kiri (dari `l` ke `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Blok saat ini di sisi kanan (dari `r.sub(block_r)` to `r`).
    // KEAMANAN: Dokumentasi untuk .add() secara khusus menyebutkan bahwa `vec.as_ptr().add(vec.len())` selalu aman`
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Ketika kita mendapatkan VLA, coba buat satu array dengan panjang `min(v.len(), 2 * BLOK) `
    // dari dua larik berukuran tetap dengan panjang `BLOCK`.VLA mungkin lebih hemat cache.

    // Mengembalikan jumlah elemen antara pointer `l` (inclusive) dan `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Kita telah selesai mempartisi blok-demi-blok ketika `l` dan `r` sudah sangat dekat.
        // Kemudian kami melakukan beberapa pekerjaan tambalan untuk mempartisi elemen yang tersisa di antaranya.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Jumlah elemen yang tersisa (masih belum dibandingkan dengan poros).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Sesuaikan ukuran blok sehingga blok kiri dan kanan tidak tumpang tindih, tetapi sejajar sempurna untuk menutupi seluruh celah yang tersisa.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Lacak elemen `block_l` dari sisi kiri.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // KEAMANAN: Operasi tidak aman di bawah ini melibatkan penggunaan `offset`.
                //         Menurut kondisi yang dibutuhkan oleh fungsi, kami memuaskan mereka karena:
                //         1. `offsets_l` adalah tumpukan-dialokasikan, dan dengan demikian dianggap sebagai objek yang dialokasikan terpisah.
                //         2. Fungsi `is_less` mengembalikan `bool`.
                //            Mentransmisikan `bool` tidak akan pernah melebihi `isize`.
                //         3. Kami telah menjamin bahwa `block_l` akan menjadi `<= BLOCK`.
                //            Plus, `end_l` awalnya disetel ke penunjuk awal `offsets_` yang dideklarasikan di stack.
                //            Jadi, kita tahu bahwa bahkan dalam kasus terburuk (semua pemanggilan `is_less` mengembalikan false) kita hanya akan melewati paling banyak 1 byte.
                //        Operasi tidak aman lainnya di sini adalah dereferensi `elem`.
                //        Namun, `elem` pada awalnya adalah penunjuk awal ke potongan yang selalu valid.
                unsafe {
                    // Perbandingan tanpa cabang.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Lacak elemen `block_r` dari sisi kanan.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // KEAMANAN: Operasi tidak aman di bawah ini melibatkan penggunaan `offset`.
                //         Menurut kondisi yang dibutuhkan oleh fungsi, kami memuaskan mereka karena:
                //         1. `offsets_r` adalah tumpukan-dialokasikan, dan dengan demikian dianggap sebagai objek yang dialokasikan terpisah.
                //         2. Fungsi `is_less` mengembalikan `bool`.
                //            Mentransmisikan `bool` tidak akan pernah melebihi `isize`.
                //         3. Kami telah menjamin bahwa `block_r` akan menjadi `<= BLOCK`.
                //            Plus, `end_r` awalnya disetel ke penunjuk awal `offsets_` yang dideklarasikan di stack.
                //            Jadi, kita tahu bahwa bahkan dalam kasus terburuk (semua pemanggilan `is_less` mengembalikan nilai true) kita hanya akan paling banyak 1 byte melewati akhir.
                //        Operasi tidak aman lainnya di sini adalah dereferensi `elem`.
                //        Namun, `elem` awalnya `1 *sizeof(T)` melewati bagian akhir dan kami menurunkannya dengan `1* sizeof(T)` sebelum mengaksesnya.
                //        Plus, `block_r` dinyatakan lebih kecil dari `BLOCK` dan karena itu `elem` paling banyak mengarah ke awal potongan.
                unsafe {
                    // Perbandingan tanpa cabang.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Jumlah elemen yang rusak untuk ditukar antara sisi kiri dan kanan.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Alih-alih menukar satu pasangan pada satu waktu, lebih efisien untuk melakukan permutasi siklik.
            // Ini tidak sepenuhnya setara dengan swapping, tetapi menghasilkan hasil yang serupa menggunakan operasi memori yang lebih sedikit.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Semua elemen yang rusak di blok kiri dipindahkan.Pindah ke blok berikutnya.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Semua elemen yang rusak di blok kanan dipindahkan.Pindah ke blok sebelumnya.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Yang tersisa sekarang adalah paling banyak satu blok (kiri atau kanan) dengan elemen yang tidak teratur yang perlu dipindahkan.
    // Elemen yang tersisa seperti itu dapat dengan mudah digeser ke ujung dalam blok mereka.
    //

    if start_l < end_l {
        // Blok kiri tetap ada.
        // Pindahkan sisa elemen yang tidak teratur ke paling kanan.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Blok kanan tetap ada.
        // Pindahkan sisa elemen yang tidak teratur ke paling kiri.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Tidak ada yang bisa dilakukan, kita sudah selesai.
        width(v.as_mut_ptr(), l)
    }
}

/// Partisi `v` menjadi elemen yang lebih kecil dari `v[pivot]`, diikuti oleh elemen yang lebih besar dari atau sama dengan `v[pivot]`.
///
///
/// Mengembalikan tupel dari:
///
/// 1. Jumlah elemen lebih kecil dari `v[pivot]`.
/// 2. Benar jika `v` sudah dipartisi.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Tempatkan poros di awal irisan.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Baca pivot menjadi variabel yang dialokasikan dengan tumpukan untuk efisiensi.
        // Jika operasi perbandingan berikut panics, poros akan secara otomatis ditulis kembali ke dalam irisan.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Temukan pasangan pertama dari elemen yang rusak.
        let mut l = 0;
        let mut r = v.len();

        // KEAMANAN: Ketidakamanan di bawah ini melibatkan pengindeksan array.
        // Untuk yang pertama: Kami sudah melakukan pengecekan batas di sini dengan `l < r`.
        // Untuk yang kedua: Awalnya kami memiliki `l == 0` dan `r == v.len()` dan kami memeriksa `l < r` itu di setiap operasi pengindeksan.
        //                     Dari sini kita tahu bahwa `r` harus minimal `r == l` yang terbukti valid dari yang pertama.
        unsafe {
            // Temukan elemen pertama yang lebih besar dari atau sama dengan pivot.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Temukan elemen terakhir yang lebih kecil dari pivot.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` keluar dari ruang lingkup dan menulis pivot (yang merupakan variabel yang dialokasikan tumpukan) kembali ke potongan tempat asalnya.
        // Langkah ini sangat penting untuk memastikan keamanan!
        //
    };

    // Tempatkan poros di antara dua partisi.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Partisi `v` menjadi elemen yang sama dengan `v[pivot]` diikuti oleh elemen yang lebih besar dari `v[pivot]`.
///
/// Mengembalikan jumlah elemen yang sama dengan pivot.
/// Diasumsikan bahwa `v` tidak mengandung elemen yang lebih kecil dari pivot.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Tempatkan poros di awal irisan.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Baca pivot menjadi variabel yang dialokasikan dengan tumpukan untuk efisiensi.
    // Jika operasi perbandingan berikut panics, poros akan secara otomatis ditulis kembali ke dalam irisan.
    // KEAMANAN: Pointer di sini valid karena diperoleh dari referensi ke sebuah slice.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Sekarang partisi slice.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // KEAMANAN: Ketidakamanan di bawah ini melibatkan pengindeksan array.
        // Untuk yang pertama: Kami sudah melakukan pengecekan batas di sini dengan `l < r`.
        // Untuk yang kedua: Awalnya kami memiliki `l == 0` dan `r == v.len()` dan kami memeriksa `l < r` itu di setiap operasi pengindeksan.
        //                     Dari sini kita tahu bahwa `r` harus minimal `r == l` yang terbukti valid dari yang pertama.
        unsafe {
            // Temukan elemen pertama yang lebih besar dari pivot.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Temukan elemen terakhir yang sama dengan pivot.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Sudahkah kita selesai?
            if l >= r {
                break;
            }

            // Tukar pasangan elemen rusak yang ditemukan.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Kami menemukan elemen `l` sama dengan pivot.Tambahkan 1 ke akun untuk pivot itu sendiri.
    l + 1

    // `_pivot_guard` keluar dari ruang lingkup dan menulis pivot (yang merupakan variabel yang dialokasikan tumpukan) kembali ke potongan tempat asalnya.
    // Langkah ini sangat penting untuk memastikan keamanan!
}

/// Menyebarkan beberapa elemen di sekitar dalam upaya untuk memecahkan pola yang mungkin menyebabkan partisi tidak seimbang dalam quicksort.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Generator nomor pseudorandom dari kertas "Xorshift RNGs" oleh George Marsaglia.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Ambil nomor acak modulo nomor ini.
        // Angka tersebut cocok dengan `usize` karena `len` tidak lebih besar dari `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Beberapa kandidat pivot akan berada di dekat indeks ini.Mari kita acak mereka.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Hasilkan nomor acak modulo `len`.
            // Namun, untuk menghindari operasi yang mahal, pertama-tama kami mengambil modulo dengan kekuatan dua, dan kemudian menurunkan `len` hingga cocok dengan kisaran `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` dijamin kurang dari `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Memilih pivot di `v` dan mengembalikan indeks dan `true` jika potongan kemungkinan sudah diurutkan.
///
/// Elemen di `v` mungkin diatur ulang dalam prosesnya.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Panjang minimum untuk memilih metode median-of-median.
    // Irisan yang lebih pendek menggunakan metode median-of-three yang sederhana.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Jumlah swap maksimum yang dapat dilakukan dalam fungsi ini.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Tiga indeks di dekat mana kita akan memilih poros.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Menghitung jumlah total swap yang akan kita lakukan saat menyortir indeks.
    let mut swaps = 0;

    if len >= 8 {
        // Menukar indeks sehingga `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Menukar indeks sehingga `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Menemukan median `v[a - 1], v[a], v[a + 1]` dan menyimpan indeks ke `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Temukan median di sekitar `a`, `b`, dan `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Temukan median antara `a`, `b`, dan `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Jumlah maksimum swap dilakukan.
        // Kemungkinan potongannya menurun atau sebagian besar menurun, jadi membalikkan mungkin akan membantu mengurutkan lebih cepat.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Mengurutkan `v` secara rekursif.
///
/// Jika irisan memiliki pendahulu dalam larik asli, itu ditetapkan sebagai `pred`.
///
/// `limit` adalah jumlah partisi tidak seimbang yang diizinkan sebelum beralih ke `heapsort`.
/// Jika nol, fungsi ini akan langsung beralih ke heapsort.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Irisan hingga panjang ini diurutkan menggunakan semacam penyisipan.
    const MAX_INSERTION: usize = 20;

    // Benar jika partisi terakhir cukup seimbang.
    let mut was_balanced = true;
    // Benar jika partisi terakhir tidak mengacak elemen (potongan sudah dipartisi).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Irisan yang sangat pendek disortir menggunakan semacam penyisipan.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Jika terlalu banyak pilihan pivot buruk yang dibuat, cukup kembali ke heapsort untuk menjamin kasus terburuk `O(n * log(n))`.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Jika pemartisian terakhir tidak seimbang, coba hancurkan pola pada potongan dengan mengacak beberapa elemen di sekitarnya.
        // Semoga kami akan memilih pivot yang lebih baik kali ini.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Pilih poros dan coba tebak apakah potongan sudah diurutkan.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Jika pemartisian terakhir cukup seimbang dan tidak mengacak elemen, dan jika pemilihan pivot memprediksi potongan kemungkinan sudah diurutkan ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Cobalah mengidentifikasi beberapa elemen yang rusak dan pindahkan ke posisi yang benar.
            // Jika potongan akhirnya tersortir sepenuhnya, kita sudah selesai.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Jika poros yang dipilih sama dengan pendahulunya, maka itu adalah elemen terkecil dalam irisan.
        // Partisi irisan menjadi elemen yang sama dengan dan elemen yang lebih besar dari pivot.
        // Kasus ini biasanya dipukul ketika irisan mengandung banyak elemen duplikat.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Lanjutkan mengurutkan elemen yang lebih besar dari pivot.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Buat partisi pada irisan.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Pisahkan irisan menjadi `left`, `pivot`, dan `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Perulangan ke sisi yang lebih pendek hanya untuk meminimalkan jumlah total panggilan rekursif dan mengkonsumsi lebih sedikit ruang tumpukan.
        // Kemudian lanjutkan dengan sisi yang lebih panjang (ini mirip dengan rekursi ekor).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Mengurutkan `v` menggunakan quicksort yang mengalahkan pola, yaitu *O*(*n*\*log(* n*)) kasus terburuk.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Penyortiran tidak memiliki perilaku yang berarti pada tipe berukuran nol.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Batasi jumlah partisi yang tidak seimbang ke `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Untuk irisan hingga panjang ini, mungkin lebih cepat jika disortir.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Pilih poros
        let (pivot, _) = choose_pivot(v, is_less);

        // Jika poros yang dipilih sama dengan pendahulunya, maka itu adalah elemen terkecil dalam irisan.
        // Partisi irisan menjadi elemen yang sama dengan dan elemen yang lebih besar dari pivot.
        // Kasus ini biasanya dipukul ketika irisan mengandung banyak elemen duplikat.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Jika kita telah melewati indeks kita, maka kita baik-baik saja.
                if mid > index {
                    return;
                }

                // Jika tidak, lanjutkan mengurutkan elemen yang lebih besar dari pivot.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Pisahkan irisan menjadi `left`, `pivot`, dan `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Jika mid==index, maka kita selesai, karena partition() menjamin bahwa semua elemen setelah mid lebih besar dari atau sama dengan mid.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Penyortiran tidak memiliki perilaku yang berarti pada tipe berukuran nol.Tidak melakukan apapun.
    } else if index == v.len() - 1 {
        // Temukan elemen maks dan letakkan di posisi terakhir larik.
        // Kami bebas menggunakan `unwrap()` di sini karena kami tahu v tidak boleh kosong.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Temukan elemen min dan letakkan di posisi pertama larik.
        // Kami bebas menggunakan `unwrap()` di sini karena kami tahu v tidak boleh kosong.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}