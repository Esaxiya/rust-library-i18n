//! Operasi di ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Memeriksa apakah semua byte dalam potongan ini berada dalam kisaran ASCII.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Memeriksa apakah dua irisan cocok tidak peka huruf besar/kecil ASCII.
    ///
    /// Sama seperti `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, tetapi tanpa mengalokasikan dan menyalin sementara.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Mengonversi potongan ini menjadi huruf besar ASCII yang setara di tempat.
    ///
    /// Huruf ASCII 'a' hingga 'z' dipetakan ke 'A' hingga 'Z', tetapi huruf non-ASCII tidak berubah.
    ///
    /// Untuk mengembalikan nilai huruf besar baru tanpa mengubah yang sudah ada, gunakan [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Mengonversi potongan ini menjadi huruf kecil ASCII yang setara di tempat.
    ///
    /// Huruf ASCII 'A' hingga 'Z' dipetakan ke 'a' hingga 'z', tetapi huruf non-ASCII tidak berubah.
    ///
    /// Untuk mengembalikan nilai huruf kecil baru tanpa mengubah yang sudah ada, gunakan [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Mengembalikan `true` jika ada byte dalam kata `v` nonascii (>=128).
/// Diambil dari `../str/mod.rs`, yang melakukan hal serupa untuk validasi utf8.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Tes ASCII yang dioptimalkan yang akan menggunakan operasi usize-at-a-time alih-alih operasi byte-at-a-time (jika memungkinkan).
///
/// Algoritme yang kami gunakan di sini cukup sederhana.Jika `s` terlalu pendek, kami hanya memeriksa setiap byte dan selesai dengannya.Jika tidak:
///
/// - Baca kata pertama dengan beban yang tidak selaras.
/// - Sejajarkan penunjuk, baca kata-kata berikutnya hingga diakhiri dengan muatan yang selaras.
/// - Baca `usize` terakhir dari `s` dengan beban yang tidak selaras.
///
/// Jika salah satu dari beban ini menghasilkan sesuatu yang `contains_nonascii` (above) mengembalikan benar, maka kita tahu jawabannya salah.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Jika kita tidak mendapatkan apa pun dari implementasi word-at-a-time, kembali ke loop skalar.
    //
    // Kami juga melakukan ini untuk arsitektur di mana `size_of::<usize>()` tidak memiliki penyelarasan yang memadai untuk `usize`, karena ini adalah casing edge yang aneh.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Kami selalu membaca kata pertama tidak selaras, yang berarti `align_offset`
    // 0, kita akan membaca nilai yang sama lagi untuk pembacaan selaras.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // KEAMANAN: Kami memverifikasi `len < USIZE_SIZE` di atas.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Kami memeriksa ini di atas, secara implisit.
    // Perhatikan bahwa `offset_to_aligned` adalah `align_offset` atau `USIZE_SIZE`, keduanya secara eksplisit dicentang di atas.
    //
    debug_assert!(offset_to_aligned <= len);

    // KESELAMATAN: word_ptr adalah ptr penggunaan (selaras dengan benar) yang kita gunakan untuk membaca
    // bagian tengah irisan.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` adalah indeks byte `word_ptr`, digunakan untuk pemeriksaan akhir loop.
    let mut byte_pos = offset_to_aligned;

    // Paranoia memeriksa tentang penyelarasan, karena kita akan melakukan banyak beban yang tidak selaras.
    // Dalam praktiknya, hal ini tidak mungkin dilakukan kecuali bug di `align_offset`.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Bacalah kata-kata berikutnya sampai kata rata terakhir, tidak termasuk kata rata terakhir dengan sendirinya untuk dilakukan pemeriksaan ekor nanti, untuk memastikan bahwa ekor selalu satu `usize` paling banyak untuk tambahan cabang `byte_pos == len`.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Periksa kewarasan bahwa pembacaan ada batasnya
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // Dan asumsi kami tentang `byte_pos` berlaku.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // KEAMANAN: Kami tahu `word_ptr` sejajar dengan benar (karena
        // `align_offset`), dan kami tahu bahwa kami memiliki cukup byte antara `word_ptr` dan akhir
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // SAFETY: Kami tahu bahwa `byte_pos <= len - USIZE_SIZE`, yang artinya
        // setelah `add` ini, `word_ptr` akan menjadi paling lama satu masa lalu.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Pemeriksaan kesehatan untuk memastikan hanya ada satu `usize` yang tersisa.
    // Ini harus dijamin oleh kondisi loop kami.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // KEAMANAN: Ini bergantung pada `len >= USIZE_SIZE`, yang kami periksa di awal.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}