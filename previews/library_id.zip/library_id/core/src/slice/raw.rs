//! Fungsi gratis untuk membuat `&[T]` dan `&mut [T]`.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Membentuk irisan dari penunjuk dan panjang.
///
/// Argumen `len` adalah jumlah **elemen**, bukan jumlah byte.
///
/// # Safety
///
/// Perilaku tidak ditentukan jika salah satu dari kondisi berikut dilanggar:
///
/// * `data` harus [valid] untuk pembacaan untuk `len * mem::size_of::<T>()` banyak byte, dan harus disejajarkan dengan benar.Ini khususnya berarti:
///
///     * Seluruh rentang memori potongan ini harus berada dalam satu objek yang dialokasikan!
///       Irisan tidak pernah bisa menjangkau beberapa objek yang dialokasikan.Lihat [below](#incorrect-usage) untuk contoh yang salah karena tidak memperhitungkan hal ini.
///     * `data` harus bukan nol dan sejajar bahkan untuk irisan dengan panjang nol.
///     Salah satu alasannya adalah bahwa pengoptimalan tata letak enum mungkin mengandalkan referensi (termasuk irisan dengan panjang berapa pun) yang diselaraskan dan bukan nol untuk membedakannya dari data lain.
///     Anda bisa mendapatkan penunjuk yang dapat digunakan sebagai `data` untuk irisan panjang-nol menggunakan [`NonNull::dangling()`].
///
/// * `data` harus menunjuk ke `len` berturut-turut nilai yang diinisialisasi dengan benar dari tipe `T`.
///
/// * Memori yang direferensikan oleh potongan yang dikembalikan tidak boleh dimutasi selama masa pakai `'a`, kecuali di dalam `UnsafeCell`.
///
/// * Ukuran total `len * mem::size_of::<T>()` potongan tidak boleh lebih dari `isize::MAX`.
///   Lihat dokumentasi keamanan [`pointer::offset`].
///
/// # Caveat
///
/// Umur potongan yang dikembalikan disimpulkan dari penggunaannya.
/// Untuk mencegah penyalahgunaan yang tidak disengaja, disarankan untuk menghubungkan masa ke masa pakai sumber mana pun yang aman dalam konteksnya, seperti dengan menyediakan fungsi pembantu yang mengambil masa pakai nilai host untuk potongan tersebut, atau dengan anotasi eksplisit.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // memanifestasikan potongan untuk satu elemen
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Penggunaan salah
///
/// Fungsi `join_slices` berikut **tidak sehat** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // Penegasan di atas memastikan `fst` dan `snd` bersebelahan, tetapi mereka mungkin masih terkandung dalam _different allocated objects_, dalam hal ini membuat potongan ini adalah perilaku yang tidak ditentukan.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` dan `b` adalah objek yang dialokasikan berbeda ...
///     let a = 42;
///     let b = 27;
///     // ... yang bagaimanapun dapat diletakkan berdekatan dalam memori: |a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // KEAMANAN: penelepon harus memegang kontrak keamanan untuk `from_raw_parts`.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Melakukan fungsionalitas yang sama seperti [`from_raw_parts`], kecuali potongan yang bisa berubah dikembalikan.
///
/// # Safety
///
/// Perilaku tidak ditentukan jika salah satu dari kondisi berikut dilanggar:
///
/// * `data` harus [valid] untuk membaca dan menulis untuk `len * mem::size_of::<T>()` banyak byte, dan harus disejajarkan dengan benar.Ini khususnya berarti:
///
///     * Seluruh rentang memori potongan ini harus berada dalam satu objek yang dialokasikan!
///       Irisan tidak pernah bisa menjangkau beberapa objek yang dialokasikan.
///     * `data` harus bukan nol dan sejajar bahkan untuk irisan dengan panjang nol.
///     Salah satu alasannya adalah bahwa pengoptimalan tata letak enum mungkin mengandalkan referensi (termasuk irisan dengan panjang berapa pun) yang diselaraskan dan bukan nol untuk membedakannya dari data lain.
///
///     Anda bisa mendapatkan penunjuk yang dapat digunakan sebagai `data` untuk irisan panjang-nol menggunakan [`NonNull::dangling()`].
///
/// * `data` harus menunjuk ke `len` berturut-turut nilai yang diinisialisasi dengan benar dari tipe `T`.
///
/// * Memori yang direferensikan oleh potongan yang dikembalikan tidak boleh diakses melalui penunjuk lain (tidak berasal dari nilai yang dikembalikan) selama masa pakai `'a`.
///   Akses baca dan tulis dilarang.
///
/// * Ukuran total `len * mem::size_of::<T>()` potongan tidak boleh lebih dari `isize::MAX`.
///   Lihat dokumentasi keamanan [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // KEAMANAN: penelepon harus memegang kontrak keamanan untuk `from_raw_parts_mut`.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Mengonversi referensi ke T menjadi potongan dengan panjang 1 (tanpa menyalin).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Mengonversi referensi ke T menjadi potongan dengan panjang 1 (tanpa menyalin).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}