//! Kelola memori secara manual melalui petunjuk mentah.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Banyak fungsi dalam modul ini menggunakan pointer mentah sebagai argumen dan membaca atau menulis padanya.Agar aman, petunjuk ini harus *valid*.
//! Validnya pointer bergantung pada operasi yang digunakan untuk (membaca atau menulis), dan tingkat memori yang diakses (yaitu, berapa byte read/written).
//! Sebagian besar fungsi menggunakan `*mut T` dan `* const T` untuk mengakses hanya satu nilai, dalam hal ini dokumentasi menghilangkan ukuran dan secara implisit menganggapnya sebagai byte `size_of::<T>()`.
//!
//! Aturan yang tepat untuk validitas belum ditentukan.Jaminan yang diberikan pada saat ini sangat minim:
//!
//! * Sebuah pointer [null]*tidak pernah* valid, bahkan untuk akses [size zero][zst].
//! * Agar sebuah pointer valid, itu perlu, tetapi tidak selalu cukup, pointer menjadi *dereferenceable*: kisaran memori dengan ukuran yang diberikan mulai dari pointer semuanya harus berada dalam batas-batas satu objek yang dialokasikan.
//!
//! Perhatikan bahwa di Rust, setiap variabel (stack-allocated) dianggap sebagai objek terpisah yang dialokasikan.
//! * Bahkan untuk operasi [size zero][zst], pointer tidak boleh menunjuk ke memori yang dibatalkan alokasinya, yaitu, deallocation membuat pointer tidak valid bahkan untuk operasi berukuran nol.
//! Namun, mentransmisikan bilangan bulat bukan nol *literal* ke pointer berlaku untuk akses berukuran nol, meskipun beberapa memori kebetulan ada di alamat itu dan dialokasikan.
//! Ini sesuai dengan menulis pengalokasi Anda sendiri: mengalokasikan objek berukuran nol tidaklah terlalu sulit.
//! Cara kanonik untuk mendapatkan penunjuk yang valid untuk akses berukuran nol adalah [`NonNull::dangling`].
//! * Semua akses yang dilakukan oleh fungsi dalam modul ini adalah *non-atom* dalam arti [atomic operations] digunakan untuk menyinkronkan antar utas.
//! Ini berarti perilaku tidak ditentukan untuk melakukan dua akses bersamaan ke lokasi yang sama dari utas berbeda kecuali keduanya hanya mengakses membaca dari memori.
//! Perhatikan bahwa ini secara eksplisit mencakup [`read_volatile`] dan [`write_volatile`]: Akses volatile tidak dapat digunakan untuk sinkronisasi antar-thread.
//! * Hasil casting referensi ke pointer valid selama objek yang mendasarinya hidup dan tidak ada referensi (hanya pointer mentah) yang digunakan untuk mengakses memori yang sama.
//!
//! Aksioma ini, bersama dengan penggunaan [`offset`] yang hati-hati untuk aritmatika pointer, cukup untuk mengimplementasikan banyak hal berguna dengan benar dalam kode yang tidak aman.
//! Jaminan yang lebih kuat pada akhirnya akan diberikan, karena aturan [aliasing] sedang ditentukan.
//! Untuk informasi lebih lanjut, lihat [book] serta bagian dalam referensi yang ditujukan untuk [undefined behavior][ub].
//!
//! ## Alignment
//!
//! Pointer mentah yang valid seperti yang didefinisikan di atas belum tentu diselaraskan dengan benar (di mana perataan "proper" ditentukan oleh jenis poin, yaitu, `*const T` harus disejajarkan dengan `mem::align_of::<T>()`).
//! Namun, sebagian besar fungsi memerlukan argumennya untuk diselaraskan dengan benar, dan akan secara eksplisit menyatakan persyaratan ini dalam dokumentasinya.
//! Pengecualian penting untuk ini adalah [`read_unaligned`] dan [`write_unaligned`].
//!
//! Ketika suatu fungsi membutuhkan penyelarasan yang tepat, ia melakukannya meskipun aksesnya memiliki ukuran 0, yaitu, meskipun memori tidak benar-benar disentuh.Pertimbangkan untuk menggunakan [`NonNull::dangling`] dalam kasus seperti itu.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Menjalankan destruktor (jika ada) dari nilai yang diarahkan ke.
///
/// Ini secara semantik setara dengan memanggil [`ptr::read`] dan membuang hasilnya, tetapi memiliki keuntungan sebagai berikut:
///
/// * *Diperlukan* untuk menggunakan `drop_in_place` untuk menghapus jenis berukuran besar seperti objek trait, karena tidak dapat dibaca ke tumpukan dan dijatuhkan secara normal.
///
/// * Lebih ramah bagi pengoptimal untuk melakukan ini di atas [`ptr::read`] saat melepaskan memori yang dialokasikan secara manual (misalnya, dalam implementasi `Box`/`Rc`/`Vec`), karena kompilator tidak perlu membuktikan bahwa tidak ada gunanya menghapus salinan.
///
///
/// * Dapat digunakan untuk melepaskan data [pinned] jika `T` bukan `repr(packed)` (data yang disematkan tidak boleh dipindahkan sebelum dijatuhkan).
///
/// Nilai yang tidak selaras tidak dapat diletakkan di tempatnya, mereka harus disalin ke lokasi yang disejajarkan terlebih dahulu menggunakan [`ptr::read_unaligned`].Untuk struct yang dikemas, pemindahan ini dilakukan secara otomatis oleh kompilator.
/// Ini berarti field dari struct yang dikemas tidak ditempatkan pada tempatnya.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// Perilaku tidak ditentukan jika salah satu dari kondisi berikut dilanggar:
///
/// * `to_drop` harus [valid] untuk membaca dan menulis.
///
/// * `to_drop` harus disejajarkan dengan benar.
///
/// * Nilai `to_drop` poin harus valid untuk dijatuhkan, yang mungkin berarti harus menjunjung invarian tambahan, ini bergantung pada tipe.
///
/// Selain itu, jika `T` bukan [`Copy`], menggunakan nilai menunjuk ke setelah memanggil `drop_in_place` dapat menyebabkan perilaku tidak terdefinisi.Perhatikan bahwa `*to_drop = foo` dihitung sebagai penggunaan karena akan menyebabkan nilainya turun lagi.
/// [`write()`] dapat digunakan untuk menimpa data tanpa menyebabkannya dijatuhkan.
///
/// Perhatikan bahwa meskipun `T` memiliki ukuran `0`, penunjuk harus non-NULL dan disejajarkan dengan benar.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Hapus item terakhir secara manual dari vector:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Dapatkan pointer mentah ke elemen terakhir di `v`.
///     let ptr = &mut v[1] as *mut _;
///     // Persingkat `v` untuk mencegah item terakhir dijatuhkan.
///     // Kami melakukan itu terlebih dahulu, untuk mencegah masalah jika `drop_in_place` di bawah panics.
///     v.set_len(1);
///     // Tanpa panggilan `drop_in_place`, item terakhir tidak akan pernah dijatuhkan, dan memori yang dikelolanya akan bocor.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Pastikan item terakhir telah dijatuhkan.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Perhatikan bahwa kompilator melakukan salinan ini secara otomatis ketika melepaskan struct yang dikemas, misalnya, Anda biasanya tidak perlu khawatir tentang masalah seperti itu kecuali jika Anda memanggil `drop_in_place` secara manual.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Kode di sini tidak masalah, ini diganti dengan lem tetes asli oleh kompiler.
    //

    // KEAMANAN: lihat komentar di atas
    unsafe { drop_in_place(to_drop) }
}

/// Membuat pointer mentah null.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Membuat pointer mentah yang bisa berubah nol.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// Implikasi manual diperlukan untuk menghindari ikatan `T: Clone`.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// Implikasi manual diperlukan untuk menghindari ikatan `T: Copy`.
impl<T> Copy for FatPtr<T> {}

/// Membentuk potongan mentah dari penunjuk dan panjang.
///
/// Argumen `len` adalah jumlah **elemen**, bukan jumlah byte.
///
/// Fungsi ini aman, tetapi sebenarnya menggunakan nilai hasil tidak aman.
/// Lihat dokumentasi [`slice::from_raw_parts`] untuk persyaratan keamanan irisan.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // membuat penunjuk irisan saat memulai dengan penunjuk ke elemen pertama
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // KEAMANAN: Mengakses nilai dari penyatuan `Repr` aman karena * const [T]
        //
        // dan FatPtr memiliki tata letak memori yang sama.Hanya std yang dapat membuat jaminan ini.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Menjalankan fungsionalitas yang sama seperti [`slice_from_raw_parts`], kecuali bahwa potongan mentah yang dapat diubah dikembalikan, sebagai lawan dari potongan mentah yang tidak dapat diubah.
///
///
/// Lihat dokumentasi [`slice_from_raw_parts`] untuk lebih jelasnya.
///
/// Fungsi ini aman, tetapi sebenarnya menggunakan nilai hasil tidak aman.
/// Lihat dokumentasi [`slice::from_raw_parts_mut`] untuk persyaratan keamanan irisan.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // tetapkan nilai pada indeks di potongan
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // KEAMANAN: Mengakses nilai dari penyatuan `Repr` aman karena * mut [T]
        // dan FatPtr memiliki tata letak memori yang sama
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Menukar nilai di dua lokasi yang bisa berubah dari jenis yang sama, tanpa juga melakukan deinisialisasi.
///
/// Namun untuk dua pengecualian berikut, fungsi ini secara semantik setara dengan [`mem::swap`]:
///
///
/// * Ini beroperasi pada pointer mentah, bukan referensi.
/// Ketika referensi tersedia, [`mem::swap`] lebih disukai.
///
/// * Kedua nilai yang diarahkan ke mungkin tumpang tindih.
/// Jika nilainya tumpang tindih, maka wilayah memori yang tumpang tindih dari `x` akan digunakan.
/// Ini ditunjukkan pada contoh kedua di bawah ini.
///
/// # Safety
///
/// Perilaku tidak ditentukan jika salah satu dari kondisi berikut dilanggar:
///
/// * Baik `x` dan `y` harus [valid] untuk membaca dan menulis.
///
/// * Baik `x` dan `y` harus disejajarkan dengan benar.
///
/// Perhatikan bahwa meskipun `T` memiliki ukuran `0`, penunjuknya harus non-NULL dan disejajarkan dengan benar.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Menukar dua wilayah yang tidak tumpang tindih:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // ini `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // ini `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Menukar dua wilayah yang tumpang tindih:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // ini `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // ini `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // Indeks `1..3` dari potongan tersebut tumpang tindih antara `x` dan `y`.
///     // Hasil yang masuk akal bagi mereka adalah `[2, 3]`, sehingga indeks `0..3` adalah `[1, 2, 3]` (cocok dengan `y` sebelum `swap`);atau untuk `[0, 1]` sehingga indeks `1..4` adalah `[0, 1, 2]` (cocok dengan `x` sebelum `swap`).
/////
///     // Implementasi ini ditetapkan untuk membuat pilihan terakhir.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Beri diri kita ruang untuk bekerja.
    // Kami tidak perlu khawatir tentang penurunan: `MaybeUninit` tidak melakukan apa pun saat dijatuhkan.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Lakukan swap SAFETY: pemanggil harus menjamin bahwa `x` dan `y` valid untuk penulisan dan disejajarkan dengan benar.
    // `tmp` tidak boleh tumpang tindih baik `x` atau `y` karena `tmp` baru saja dialokasikan di tumpukan sebagai objek yang dialokasikan terpisah.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` dan `y` mungkin tumpang tindih
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Menukar byte `count * size_of::<T>()` antara dua wilayah memori yang dimulai dari `x` dan `y`.
/// Kedua wilayah harus *tidak* tumpang tindih.
///
/// # Safety
///
/// Perilaku tidak ditentukan jika salah satu dari kondisi berikut dilanggar:
///
/// * Baik `x` dan `y` harus [valid] untuk pembacaan dan penulisan `count *
///   ukuran dari: :<T>() `byte.
///
/// * Baik `x` dan `y` harus disejajarkan dengan benar.
///
/// * Wilayah memori dimulai pada `x` dengan ukuran `hitungan *
///   ukuran dari: :<T>() `byte tidak boleh *tidak* tumpang tindih dengan wilayah memori yang dimulai dari `y` dengan ukuran yang sama.
///
/// Perhatikan bahwa meskipun ukuran yang disalin secara efektif (`count * size_of: :<T>()`) adalah `0`, penunjuk harus non-NULL dan disejajarkan dengan benar.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Penggunaan dasar:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // KEAMANAN: penelepon harus menjamin bahwa `x` dan `y` adalah
    // valid untuk penulisan dan disejajarkan dengan benar.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // Untuk jenis yang lebih kecil dari pengoptimalan blok di bawah ini, cukup tukar langsung untuk menghindari pesimisasi codegen.
    //
    if mem::size_of::<T>() < 32 {
        // KEAMANAN: penelepon harus menjamin bahwa `x` dan `y` valid
        // untuk menulis, sejajar dengan benar, dan tidak tumpang tindih.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // KEAMANAN: penelepon harus memegang kontrak keamanan untuk `swap_nonoverlapping`.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // Pendekatan di sini adalah menggunakan simd untuk menukar x&y secara efisien.
    // Pengujian mengungkapkan bahwa menukar 32 byte atau 64 byte sekaligus paling efisien untuk prosesor Intel Haswell E.
    // LLVM lebih bisa dioptimalkan jika kita memberikan struct #[repr(simd)], meskipun sebenarnya kita tidak menggunakan struct ini secara langsung.
    //
    //
    // FIXME repr(simd) rusak pada emscripten dan redoks
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Ulangi x&y, salin `Block` sekaligus Pengoptimal harus membuka gulungan sepenuhnya untuk sebagian besar jenis NB
    // Kita tidak dapat menggunakan perulangan for karena `range` impl memanggil `mem::swap` secara rekursif
    //
    let mut i = 0;
    while i + block_size <= len {
        // Buat beberapa memori yang tidak diinisialisasi sebagai ruang awal. Mendeklarasikan `t` di sini menghindari penyelarasan tumpukan saat loop ini tidak digunakan
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // KEAMANAN: Sebagai `i < len`, dan sebagai penelepon harus menjamin bahwa `x` dan `y` valid
        // untuk byte `len`, `x + i` dan `y + i` harus merupakan alamat yang valid, yang memenuhi kontrak keamanan untuk `add`.
        //
        // Selain itu, pemanggil harus menjamin bahwa `x` dan `y` valid untuk penulisan, disejajarkan dengan benar, dan tidak tumpang tindih, yang memenuhi kontrak keamanan untuk `copy_nonoverlapping`.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Tukar satu blok byte x&y, menggunakan t sebagai buffer sementara Ini harus dioptimalkan menjadi operasi SIMD yang efisien jika tersedia
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Tukar byte yang tersisa
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // KEAMANAN: lihat komentar keamanan sebelumnya.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// Memindahkan `src` ke `dst` yang ditunjuk, mengembalikan nilai `dst` sebelumnya.
///
/// Tidak ada nilai yang dijatuhkan.
///
/// Fungsi ini secara semantik setara dengan [`mem::replace`] kecuali bahwa fungsi ini beroperasi pada pointer mentah, bukan referensi.
/// Ketika referensi tersedia, [`mem::replace`] lebih disukai.
///
/// # Safety
///
/// Perilaku tidak ditentukan jika salah satu dari kondisi berikut dilanggar:
///
/// * `dst` harus [valid] untuk membaca dan menulis.
///
/// * `dst` harus disejajarkan dengan benar.
///
/// * `dst` harus menunjuk ke nilai tipe `T` yang diinisialisasi dengan benar.
///
/// Perhatikan bahwa meskipun `T` memiliki ukuran `0`, penunjuk harus non-NULL dan disejajarkan dengan benar.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` akan memiliki efek yang sama tanpa memerlukan blok yang tidak aman.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // KEAMANAN: penelepon harus menjamin bahwa `dst` valid
    // mentransmisikan ke referensi yang bisa berubah (valid untuk penulisan, disejajarkan, diinisialisasi), dan tidak boleh tumpang tindih dengan `src` karena `dst` harus mengarah ke objek alokasi yang berbeda.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // tidak bisa tumpang tindih
    }
    src
}

/// Membaca nilai dari `src` tanpa memindahkannya.Ini membuat memori di `src` tidak berubah.
///
/// # Safety
///
/// Perilaku tidak ditentukan jika salah satu dari kondisi berikut dilanggar:
///
/// * `src` harus [valid] untuk dibaca.
///
/// * `src` harus disejajarkan dengan benar.Gunakan [`read_unaligned`] jika tidak demikian.
///
/// * `src` harus menunjuk ke nilai tipe `T` yang diinisialisasi dengan benar.
///
/// Perhatikan bahwa meskipun `T` memiliki ukuran `0`, penunjuk harus non-NULL dan disejajarkan dengan benar.
///
/// # Examples
///
/// Penggunaan dasar:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Terapkan [`mem::swap`] secara manual:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Buat salinan bitwise dari nilai di `a` di `tmp`.
///         let tmp = ptr::read(a);
///
///         // Keluar pada titik ini (baik dengan secara eksplisit mengembalikan atau dengan memanggil fungsi yang panics) akan menyebabkan nilai di `tmp` turun sementara nilai yang sama masih direferensikan oleh `a`.
///         // Ini dapat memicu perilaku tidak ditentukan jika `T` bukan `Copy`.
/////
/////
///
///         // Buat salinan bitwise dari nilai di `b` di `a`.
///         // Ini aman karena referensi yang bisa berubah tidak bisa alias.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Seperti di atas, keluar dari sini dapat memicu perilaku tidak ditentukan karena nilai yang sama direferensikan oleh `a` dan `b`.
/////
///
///         // Pindahkan `tmp` ke `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` telah dipindahkan (`write` mengambil alih kepemilikan argumen keduanya), jadi tidak ada yang dijatuhkan secara implisit di sini.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Kepemilikan Nilai yang Dikembalikan
///
/// `read` membuat salinan bitwise dari `T`, terlepas dari apakah `T` adalah [`Copy`].
/// Jika `T` bukan [`Copy`], menggunakan nilai yang dikembalikan dan nilai di `*src` dapat melanggar keamanan memori.
/// Perhatikan bahwa menetapkan ke `*src` dihitung sebagai penggunaan karena akan mencoba menurunkan nilai di `* src`.
///
/// [`write()`] dapat digunakan untuk menimpa data tanpa menyebabkannya dijatuhkan.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` sekarang menunjuk ke memori dasar yang sama dengan `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // Menetapkan ke `s2` menyebabkan nilai aslinya turun.
///     // Di luar titik ini, `s` tidak boleh lagi digunakan, karena memori yang mendasarinya telah dibebaskan.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // Menetapkan ke `s` akan menyebabkan nilai lama turun lagi, mengakibatkan perilaku tidak terdefinisi.
/////
///     // s= String::from("bar");//ERROR
///
///     // `ptr::write` dapat digunakan untuk menimpa nilai tanpa menjatuhkannya.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // KEAMANAN: penelepon harus menjamin bahwa `src` valid untuk dibaca.
    // `src` tidak dapat tumpang tindih dengan `tmp` karena `tmp` baru saja dialokasikan di tumpukan sebagai objek terpisah yang dialokasikan.
    //
    //
    // Selain itu, karena kami baru saja menulis nilai yang valid ke `tmp`, dijamin akan diinisialisasi dengan benar.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Membaca nilai dari `src` tanpa memindahkannya.Ini membuat memori di `src` tidak berubah.
///
/// Tidak seperti [`read`], `read_unaligned` bekerja dengan pointer yang tidak selaras.
///
/// # Safety
///
/// Perilaku tidak ditentukan jika salah satu dari kondisi berikut dilanggar:
///
/// * `src` harus [valid] untuk dibaca.
///
/// * `src` harus menunjuk ke nilai tipe `T` yang diinisialisasi dengan benar.
///
/// Seperti [`read`], `read_unaligned` membuat salinan bitwise dari `T`, terlepas dari apakah `T` adalah [`Copy`].
/// Jika `T` bukan [`Copy`], menggunakan nilai yang dikembalikan dan nilai di `*src` dapat [violate memory safety][read-ownership].
///
/// Perhatikan bahwa meskipun `T` memiliki ukuran `0`, penunjuk harus non-NULL.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## Pada struct `packed`
///
/// Saat ini tidak mungkin untuk membuat pointer mentah ke bidang yang tidak selaras dari struct yang dikemas.
///
/// Mencoba membuat penunjuk mentah ke bidang struktur `unaligned` dengan ekspresi seperti `&packed.unaligned as *const FieldType` membuat referensi tidak selaras perantara sebelum mengonversinya menjadi penunjuk mentah.
///
/// Referensi ini bersifat sementara dan segera dilemparkan tidak penting karena kompilator selalu mengharapkan referensi diselaraskan dengan benar.
/// Akibatnya, menggunakan `&packed.unaligned as *const FieldType` langsung menyebabkan* perilaku tidak terdefinisi * dalam program Anda.
///
/// Contoh hal-hal yang tidak boleh dilakukan dan kaitannya dengan `read_unaligned` adalah:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Di sini kami mencoba untuk mengambil alamat integer 32-bit yang tidak selaras.
///     let unaligned =
///         // Referensi sementara yang tidak selaras dibuat di sini yang menghasilkan perilaku tidak ditentukan terlepas dari apakah referensi tersebut digunakan atau tidak.
/////
///         &packed.unaligned
///         // Mentransmisikan ke pointer mentah tidak membantu;kesalahan sudah terjadi.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Mengakses bidang yang tidak selaras secara langsung dengan misalnya `packed.unaligned` aman.
///
///
///
///
///
///
// FIXME: Perbarui dokumen berdasarkan hasil RFC #2582 dan teman-teman.
/// # Examples
///
/// Baca nilai usize dari buffer byte:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // KEAMANAN: penelepon harus menjamin bahwa `src` valid untuk dibaca.
    // `src` tidak dapat tumpang tindih dengan `tmp` karena `tmp` baru saja dialokasikan di tumpukan sebagai objek terpisah yang dialokasikan.
    //
    //
    // Selain itu, karena kami baru saja menulis nilai yang valid ke `tmp`, dijamin akan diinisialisasi dengan benar.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Menimpa lokasi memori dengan nilai yang diberikan tanpa membaca atau menghapus nilai lama.
///
/// `write` tidak menjatuhkan konten `dst`.
/// Ini aman, tetapi dapat membocorkan alokasi atau sumber daya, jadi berhati-hatilah agar tidak menimpa objek yang harus dibuang.
///
///
/// Selain itu, itu tidak menjatuhkan `src`.Secara semantik, `src` dipindahkan ke lokasi yang ditunjuk oleh `dst`.
///
/// Ini sesuai untuk menginisialisasi memori yang tidak diinisialisasi, atau menimpa memori yang sebelumnya telah [`read`].
///
/// # Safety
///
/// Perilaku tidak ditentukan jika salah satu dari kondisi berikut dilanggar:
///
/// * `dst` harus [valid] untuk menulis.
///
/// * `dst` harus disejajarkan dengan benar.Gunakan [`write_unaligned`] jika tidak demikian.
///
/// Perhatikan bahwa meskipun `T` memiliki ukuran `0`, penunjuk harus non-NULL dan disejajarkan dengan benar.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Penggunaan dasar:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Terapkan [`mem::swap`] secara manual:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Buat salinan bitwise dari nilai di `a` di `tmp`.
///         let tmp = ptr::read(a);
///
///         // Keluar pada titik ini (baik dengan secara eksplisit mengembalikan atau dengan memanggil fungsi yang panics) akan menyebabkan nilai di `tmp` turun sementara nilai yang sama masih direferensikan oleh `a`.
///         // Ini dapat memicu perilaku tidak ditentukan jika `T` bukan `Copy`.
/////
/////
///
///         // Buat salinan bitwise dari nilai di `b` di `a`.
///         // Ini aman karena referensi yang bisa berubah tidak bisa alias.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Seperti di atas, keluar dari sini dapat memicu perilaku tidak ditentukan karena nilai yang sama direferensikan oleh `a` dan `b`.
/////
///
///         // Pindahkan `tmp` ke `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` telah dipindahkan (`write` mengambil alih kepemilikan argumen keduanya), jadi tidak ada yang dijatuhkan secara implisit di sini.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Kami memanggil intrinsik secara langsung untuk menghindari panggilan fungsi dalam kode yang dihasilkan karena `intrinsics::copy_nonoverlapping` adalah fungsi pembungkus.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // KEAMANAN: pemanggil harus menjamin bahwa `dst` valid untuk menulis.
    // `dst` tidak dapat tumpang tindih dengan `src` karena pemanggil memiliki akses yang dapat diubah ke `dst` sementara `src` dimiliki oleh fungsi ini.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Menimpa lokasi memori dengan nilai yang diberikan tanpa membaca atau menghapus nilai lama.
///
/// Tidak seperti [`write()`], penunjuk mungkin tidak sejajar.
///
/// `write_unaligned` tidak menjatuhkan konten `dst`.Ini aman, tetapi dapat membocorkan alokasi atau sumber daya, jadi berhati-hatilah agar tidak menimpa objek yang harus dibuang.
///
/// Selain itu, itu tidak menjatuhkan `src`.Secara semantik, `src` dipindahkan ke lokasi yang ditunjuk oleh `dst`.
///
/// Ini sesuai untuk menginisialisasi memori yang tidak diinisialisasi, atau menimpa memori yang sebelumnya telah dibaca dengan [`read_unaligned`].
///
/// # Safety
///
/// Perilaku tidak ditentukan jika salah satu dari kondisi berikut dilanggar:
///
/// * `dst` harus [valid] untuk menulis.
///
/// Perhatikan bahwa meskipun `T` memiliki ukuran `0`, penunjuk harus non-NULL.
///
/// [valid]: self#safety
///
/// ## Pada struct `packed`
///
/// Saat ini tidak mungkin untuk membuat pointer mentah ke bidang yang tidak selaras dari struct yang dikemas.
///
/// Mencoba membuat penunjuk mentah ke bidang struktur `unaligned` dengan ekspresi seperti `&packed.unaligned as *const FieldType` membuat referensi tidak selaras perantara sebelum mengonversinya menjadi penunjuk mentah.
///
/// Referensi ini bersifat sementara dan segera dilemparkan tidak penting karena kompilator selalu mengharapkan referensi diselaraskan dengan benar.
/// Akibatnya, menggunakan `&packed.unaligned as *const FieldType` langsung menyebabkan* perilaku tidak terdefinisi * dalam program Anda.
///
/// Contoh hal-hal yang tidak boleh dilakukan dan kaitannya dengan `write_unaligned` adalah:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Di sini kami mencoba untuk mengambil alamat integer 32-bit yang tidak selaras.
///     let unaligned =
///         // Referensi sementara yang tidak selaras dibuat di sini yang menghasilkan perilaku tidak ditentukan terlepas dari apakah referensi tersebut digunakan atau tidak.
/////
///         &mut packed.unaligned
///         // Mentransmisikan ke pointer mentah tidak membantu;kesalahan sudah terjadi.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Mengakses bidang yang tidak selaras secara langsung dengan misalnya `packed.unaligned` aman.
///
///
///
///
///
///
///
///
///
// FIXME: Perbarui dokumen berdasarkan hasil RFC #2582 dan teman-teman.
/// # Examples
///
/// Tulis nilai usize ke buffer byte:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // KEAMANAN: pemanggil harus menjamin bahwa `dst` valid untuk menulis.
    // `dst` tidak dapat tumpang tindih dengan `src` karena pemanggil memiliki akses yang dapat diubah ke `dst` sementara `src` dimiliki oleh fungsi ini.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Kami memanggil intrinsik secara langsung untuk menghindari panggilan fungsi dalam kode yang dihasilkan.
        intrinsics::forget(src);
    }
}

/// Melakukan pembacaan volatil nilai dari `src` tanpa memindahkannya.Ini membuat memori di `src` tidak berubah.
///
/// Operasi volatil dimaksudkan untuk bekerja pada memori I/O, dan dijamin tidak akan dihilangkan atau diatur ulang oleh compiler di seluruh operasi volatil lainnya.
///
/// # Notes
///
/// Rust saat ini tidak memiliki model memori yang ditentukan secara formal dan ketat, jadi semantik yang tepat dari apa yang dimaksud "volatile" di sini dapat berubah seiring waktu.
/// Meskipun demikian, semantik hampir selalu berakhir sangat mirip dengan [C11's definition of volatile][c11].
///
/// Kompilator tidak boleh mengubah urutan relatif atau jumlah operasi memori volatil.
/// Namun, operasi memori volatile pada tipe berukuran nol (misalnya, jika tipe berukuran nol diteruskan ke `read_volatile`) adalah noops dan dapat diabaikan.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Perilaku tidak ditentukan jika salah satu dari kondisi berikut dilanggar:
///
/// * `src` harus [valid] untuk dibaca.
///
/// * `src` harus disejajarkan dengan benar.
///
/// * `src` harus menunjuk ke nilai tipe `T` yang diinisialisasi dengan benar.
///
/// Seperti [`read`], `read_volatile` membuat salinan bitwise dari `T`, terlepas dari apakah `T` adalah [`Copy`].
/// Jika `T` bukan [`Copy`], menggunakan nilai yang dikembalikan dan nilai di `*src` dapat [violate memory safety][read-ownership].
/// Namun, menyimpan jenis non-[`Salin`] dalam memori volatil hampir pasti tidak benar.
///
/// Perhatikan bahwa meskipun `T` memiliki ukuran `0`, penunjuk harus non-NULL dan disejajarkan dengan benar.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Sama seperti di C, apakah suatu operasi mudah berubah tidak ada hubungannya dengan pertanyaan yang melibatkan akses bersamaan dari beberapa utas.Akses yang mudah menguap berperilaku persis seperti akses non-atomik dalam hal itu.
///
/// Secara khusus, perlombaan antara `read_volatile` dan operasi tulis apa pun ke lokasi yang sama adalah perilaku yang tidak ditentukan.
///
/// # Examples
///
/// Penggunaan dasar:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Tidak panik untuk memperkecil dampak codegen.
        abort();
    }
    // KEAMANAN: penelepon harus memegang kontrak keamanan untuk `volatile_load`.
    unsafe { intrinsics::volatile_load(src) }
}

/// Melakukan penulisan volatil dari lokasi memori dengan nilai yang diberikan tanpa membaca atau menghapus nilai lama.
///
/// Operasi volatil dimaksudkan untuk bekerja pada memori I/O, dan dijamin tidak akan dihilangkan atau diatur ulang oleh compiler di seluruh operasi volatil lainnya.
///
/// `write_volatile` tidak menjatuhkan konten `dst`.Ini aman, tetapi dapat membocorkan alokasi atau sumber daya, jadi berhati-hatilah agar tidak menimpa objek yang harus dibuang.
///
/// Selain itu, itu tidak menjatuhkan `src`.Secara semantik, `src` dipindahkan ke lokasi yang ditunjuk oleh `dst`.
///
/// # Notes
///
/// Rust saat ini tidak memiliki model memori yang ditentukan secara formal dan ketat, jadi semantik yang tepat dari apa yang dimaksud "volatile" di sini dapat berubah seiring waktu.
/// Meskipun demikian, semantik hampir selalu berakhir sangat mirip dengan [C11's definition of volatile][c11].
///
/// Kompilator tidak boleh mengubah urutan relatif atau jumlah operasi memori volatil.
/// Namun, operasi memori volatile pada tipe berukuran nol (misalnya, jika tipe berukuran nol diteruskan ke `write_volatile`) adalah noops dan dapat diabaikan.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Perilaku tidak ditentukan jika salah satu dari kondisi berikut dilanggar:
///
/// * `dst` harus [valid] untuk menulis.
///
/// * `dst` harus disejajarkan dengan benar.
///
/// Perhatikan bahwa meskipun `T` memiliki ukuran `0`, penunjuk harus non-NULL dan disejajarkan dengan benar.
///
/// [valid]: self#safety
///
/// Sama seperti di C, apakah suatu operasi mudah berubah tidak ada hubungannya dengan pertanyaan yang melibatkan akses bersamaan dari beberapa utas.Akses yang mudah menguap berperilaku persis seperti akses non-atomik dalam hal itu.
///
/// Secara khusus, perlombaan antara `write_volatile` dan operasi lainnya (membaca atau menulis) di lokasi yang sama adalah perilaku yang tidak ditentukan.
///
/// # Examples
///
/// Penggunaan dasar:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Tidak panik untuk memperkecil dampak codegen.
        abort();
    }
    // KEAMANAN: penelepon harus memegang kontrak keamanan untuk `volatile_store`.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Sejajarkan penunjuk `p`.
///
/// Hitung offset (dalam kaitannya dengan elemen langkah `stride`) yang harus diterapkan ke penunjuk `p` sehingga penunjuk `p` akan disejajarkan dengan `a`.
///
/// Note: Implementasi ini telah disesuaikan dengan hati-hati agar tidak panic.UB untuk ini ke panic.
/// Satu-satunya perubahan nyata yang dapat dilakukan di sini adalah perubahan `INV_TABLE_MOD_16` dan konstanta terkait.
///
/// Jika kita pernah memutuskan untuk membuatnya mungkin untuk memanggil intrinsik dengan `a` yang bukan kekuatan dua, mungkin akan lebih bijaksana untuk hanya mengubah ke implementasi yang naif daripada mencoba menyesuaikan ini untuk mengakomodasi perubahan itu.
///
///
/// Jika ada pertanyaan, buka@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): Penggunaan langsung dari intrinsik ini meningkatkan codegen secara signifikan pada level-opt <=
    // 1, di mana versi metode operasi ini tidak sebaris.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Hitung invers modular perkalian dari `x` modulo `m`.
    ///
    /// Implementasi ini disesuaikan untuk `align_offset` dan memiliki prasyarat berikut:
    ///
    /// * `m` adalah kekuatan dua;
    /// * `x < m`; (jika `x ≥ m`, berikan `x % m` sebagai gantinya)
    ///
    /// Penerapan fungsi ini tidak akan panic.Pernah.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Tabel invers modular perkalian modulo 2⁴=16.
        ///
        /// Perhatikan, bahwa tabel ini tidak berisi nilai yang tidak memiliki invers (mis., Untuk `0⁻¹ mod 16`, `2⁻¹ mod 16`, dll.)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Modulo yang menjadi tujuan `INV_TABLE_MOD_16`.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // KEAMANAN: `m` harus memiliki kekuatan dua, maka bukan nol.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Kami mengulangi "up" menggunakan rumus berikut:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // sampai 2²ⁿ ≥ m.Kemudian kita dapat mengurangi ke `m` yang kita inginkan dengan mengambil hasil `mod m`.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // Perhatikan, bahwa kami menggunakan operasi pembungkusan di sini dengan sengaja-rumus aslinya menggunakan misalnya, pengurangan `mod n`.
                // Tidak apa-apa untuk melakukannya `mod usize::MAX` sebagai gantinya, karena kami mengambil hasil `mod n` pada akhirnya.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // KEAMANAN: `a` adalah pangkat dua, oleh karena itu bukan nol.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` case dapat dihitung lebih sederhana melalui `-p (mod a)`, tetapi hal itu menghambat kemampuan LLVM untuk memilih instruksi seperti `lea`.Sebagai gantinya kami menghitung
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // yang mendistribusikan operasi di sekitar penahan beban, tetapi cukup pesimis `and` agar LLVM dapat memanfaatkan berbagai pengoptimalan yang diketahuinya.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Sudah sejajar.Yay!
        return 0;
    } else if stride == 0 {
        // Jika penunjuk tidak sejajar, dan elemen berukuran nol, maka tidak ada jumlah elemen yang akan menyejajarkan penunjuk.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // KEAMANAN: a adalah pangkat dua, maka bukan nol.stride==0 kasus ditangani di atas.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // KEAMANAN: gcdpow memiliki batas atas yang paling banyak adalah jumlah bit dalam sebuah usize.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // KEAMANAN: gcd selalu lebih besar atau sama dengan 1.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // branch ini menyelesaikan persamaan kongruensi linier berikut:
        //
        // ` p + so = 0 mod a `
        //
        // `p` di sini adalah nilai pointer, `s`, langkah `T`, offset `o` di `T`s, dan `a`, perataan yang diminta.
        //
        // Dengan `g = gcd(a, s)`, dan kondisi di atas yang menyatakan bahwa `p` juga habis dibagi oleh `g`, kita dapat menunjukkan `a' = a/g`, `s' = s/g`, `p' = p/g`, maka ini menjadi setara dengan:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // Suku pertama adalah "the relative alignment of `p` to `a`" (dibagi `g`), suku kedua adalah "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (dibagi lagi dengan `g`).
        //
        // Pembagian oleh `g` diperlukan untuk membuat inversi dengan baik jika `a` dan `s` bukan co-prime.
        //
        // Selanjutnya hasil yang dihasilkan larutan ini bukan "minimal", sehingga perlu diambil hasil `o mod lcm(s, a)`.Kita bisa mengganti `lcm(s, a)` hanya dengan `a'`.
        //
        //
        //
        //
        //

        // KEAMANAN: `gcdpow` memiliki batas atas tidak lebih dari jumlah 0-bit di belakangnya di `a`.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // KEAMANAN: `a2` bukan nol.Menggeser `a` oleh `gcdpow` tidak dapat mengubah bit set mana pun
        // di `a` (yang hanya memiliki satu).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // KEAMANAN: `gcdpow` memiliki batas atas tidak lebih dari jumlah 0-bit di belakangnya di `a`.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // KESELAMATAN: `gcdpow` memiliki batas atas tidak lebih besar dari jumlah di belakang 0-bit
        // `a`.
        // Selain itu, pengurangan tidak dapat melimpah, karena `a2 = a >> gcdpow` akan selalu lebih besar dari `(p % a) >> gcdpow`.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // KEAMANAN: `a2` adalah kekuatan dua, seperti yang dibuktikan di atas.`s2` benar-benar kurang dari `a2`
        // karena `(s % a) >> gcdpow` lebih kecil dari `a >> gcdpow`.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Tidak bisa disejajarkan sama sekali.
    usize::MAX
}

/// Membandingkan petunjuk mentah untuk kesetaraan.
///
/// Ini sama dengan menggunakan operator `==`, tetapi kurang umum:
/// argumen harus berupa pointer mentah `*const T`, bukan apa pun yang mengimplementasikan `PartialEq`.
///
/// Ini dapat digunakan untuk membandingkan referensi `&T` (yang memaksa ke `*const T` secara implisit) menurut alamatnya daripada membandingkan nilai yang mereka tunjuk (yang dilakukan oleh implementasi `PartialEq for &T`).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Irisan juga dibandingkan dengan panjangnya (penunjuk lemak):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Traits juga dibandingkan dengan implementasinya:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Pointer memiliki alamat yang sama.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Objek memiliki alamat yang sama, tetapi `Trait` memiliki implementasi yang berbeda.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Mengonversi referensi ke `*const u8` membandingkan menurut alamat.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Hash pointer mentah.
///
/// Ini dapat digunakan untuk mencirikan referensi `&T` (yang memaksa ke `*const T` secara implisit) berdasarkan alamatnya daripada nilai yang ditunjukkannya (yang dilakukan oleh implementasi `Hash for &T`).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Impls untuk pointer fungsi
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Pemeran perantara seperti yang digunakan diperlukan untuk AVR
                // sehingga ruang alamat penunjuk fungsi sumber dipertahankan di penunjuk fungsi terakhir.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Pemeran perantara seperti yang digunakan diperlukan untuk AVR
                // sehingga ruang alamat penunjuk fungsi sumber dipertahankan di penunjuk fungsi terakhir.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // Tidak ada fungsi variadic dengan 0 parameter
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Buat pointer mentah `const` ke suatu tempat, tanpa membuat referensi perantara.
///
/// Membuat referensi dengan `&`/`&mut` hanya diperbolehkan jika penunjuk disejajarkan dengan benar dan menunjuk ke data yang diinisialisasi.
/// Untuk kasus di mana persyaratan tersebut tidak berlaku, pointer mentah harus digunakan sebagai gantinya.
/// Namun, `&expr as *const _` membuat referensi sebelum mentransmisikannya ke pointer mentah, dan referensi tersebut tunduk pada aturan yang sama seperti semua referensi lainnya.
///
/// Makro ini dapat membuat pointer mentah *tanpa* membuat referensi terlebih dahulu.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` akan membuat referensi yang tidak selaras, dan dengan demikian menjadi Perilaku Tidak Terdefinisi!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Buat pointer mentah `mut` ke suatu tempat, tanpa membuat referensi perantara.
///
/// Membuat referensi dengan `&`/`&mut` hanya diperbolehkan jika penunjuk disejajarkan dengan benar dan menunjuk ke data yang diinisialisasi.
/// Untuk kasus di mana persyaratan tersebut tidak berlaku, pointer mentah harus digunakan sebagai gantinya.
/// Namun, `&mut expr as *mut _` membuat referensi sebelum mentransmisikannya ke pointer mentah, dan referensi tersebut tunduk pada aturan yang sama seperti semua referensi lainnya.
///
/// Makro ini dapat membuat pointer mentah *tanpa* membuat referensi terlebih dahulu.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` akan membuat referensi yang tidak selaras, dan dengan demikian menjadi Perilaku Tidak Terdefinisi!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` memaksa menyalin bidang alih-alih membuat referensi.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}