use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::slice::{self, SliceIndex};

#[lang = "mut_ptr"]
impl<T: ?Sized> *mut T {
    /// Mengembalikan `true` jika pointernya null.
    ///
    /// Perhatikan bahwa tipe tidak berukuran memiliki banyak kemungkinan penunjuk nol, karena hanya penunjuk data mentah yang dipertimbangkan, bukan panjangnya, vtabel, dll.
    /// Oleh karena itu, dua pointer yang nol mungkin masih tidak sebanding satu sama lain.
    ///
    /// ## Perilaku selama evaluasi const
    ///
    /// Jika fungsi ini digunakan selama evaluasi const, ia dapat mengembalikan `false` untuk pointer yang ternyata null pada waktu proses.
    /// Secara khusus, ketika pointer ke beberapa memori diimbangi di luar batasnya sedemikian rupa sehingga pointer yang dihasilkan adalah null, fungsi tersebut akan tetap mengembalikan `false`.
    ///
    /// Tidak ada cara bagi CTFE untuk mengetahui posisi absolut dari memori tersebut, jadi kami tidak dapat mengetahui apakah pointernya null atau tidak.
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Bandingkan melalui cast ke pointer tipis, jadi pointer gemuk hanya mempertimbangkan bagian "data" mereka untuk null-ness.
        //
        (self as *mut u8).guaranteed_eq(null_mut())
    }

    /// Mentransmisikan ke penunjuk jenis lain.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *mut U {
        self as _
    }

    /// Menguraikan pointer (mungkin lebar) menjadi komponen alamat dan metadata.
    ///
    /// Penunjuk nantinya dapat direkonstruksi dengan [`from_raw_parts_mut`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*mut (), <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self))
    }

    /// Mengembalikan `None` jika pointernya null, atau mengembalikan referensi bersama ke nilai yang dibungkus dalam `Some`.Jika nilainya mungkin tidak diinisialisasi, [`as_uninit_ref`] harus digunakan sebagai gantinya.
    ///
    /// Untuk mitra yang bisa berubah, lihat [`as_mut`].
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    /// [`as_mut`]: #method.as_mut
    ///
    /// # Safety
    ///
    /// Saat memanggil metode ini, Anda harus memastikan bahwa *baik* penunjuknya adalah NULL *atau* semua hal berikut ini benar:
    ///
    /// * Penunjuk harus disejajarkan dengan benar.
    ///
    /// * Ini harus "dereferencable" dalam arti yang didefinisikan di [the module documentation].
    ///
    /// * Penunjuk harus menunjuk ke contoh `T` yang diinisialisasi.
    ///
    /// * Anda harus menerapkan aturan aliasing Rust, karena masa pakai yang dikembalikan `'a` dipilih secara sewenang-wenang dan tidak selalu mencerminkan masa pakai data yang sebenarnya.
    ///   Secara khusus, selama durasi ini, memori yang ditunjuk penunjuk tidak boleh bermutasi (kecuali di dalam `UnsafeCell`).
    ///
    /// Ini berlaku bahkan jika hasil dari metode ini tidak digunakan!
    /// (Bagian tentang diinisialisasi belum sepenuhnya diputuskan, tetapi sampai itu, satu-satunya pendekatan yang aman adalah memastikan bahwa mereka benar-benar diinisialisasi.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Versi yang tidak dicentang
    ///
    /// Jika Anda yakin penunjuk tidak akan pernah nol dan mencari semacam `as_ref_unchecked` yang mengembalikan `&T` daripada `Option<&T>`, ketahuilah bahwa Anda dapat merujuk penunjuk secara langsung.
    ///
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // KEAMANAN: penelepon harus menjamin bahwa `self` valid untuk a
        // referensi jika tidak null.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Mengembalikan `None` jika pointernya null, atau mengembalikan referensi bersama ke nilai yang dibungkus dalam `Some`.
    /// Berbeda dengan [`as_ref`], ini tidak mengharuskan nilai harus diinisialisasi.
    ///
    /// Untuk mitra yang bisa berubah, lihat [`as_uninit_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    ///
    /// # Safety
    ///
    /// Saat memanggil metode ini, Anda harus memastikan bahwa *baik* penunjuknya adalah NULL *atau* semua hal berikut ini benar:
    ///
    /// * Penunjuk harus disejajarkan dengan benar.
    ///
    /// * Ini harus "dereferencable" dalam arti yang didefinisikan di [the module documentation].
    ///
    /// * Anda harus menerapkan aturan aliasing Rust, karena masa pakai yang dikembalikan `'a` dipilih secara sewenang-wenang dan tidak selalu mencerminkan masa pakai data yang sebenarnya.
    ///
    ///   Secara khusus, selama durasi ini, memori yang ditunjuk penunjuk tidak boleh bermutasi (kecuali di dalam `UnsafeCell`).
    ///
    /// Ini berlaku bahkan jika hasil dari metode ini tidak digunakan!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // KEAMANAN: penelepon harus menjamin bahwa `self` memenuhi semua
        // persyaratan untuk referensi.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Menghitung offset dari penunjuk.
    ///
    /// `count` dalam satuan T;misalnya, `count` dari 3 mewakili offset pointer `3 * size_of::<T>()` byte.
    ///
    /// # Safety
    ///
    /// Jika salah satu dari kondisi berikut dilanggar, hasilnya adalah Perilaku Tidak Terdefinisi:
    ///
    /// * Baik penunjuk awal dan hasil harus berada dalam batas atau satu byte setelah akhir dari objek yang dialokasikan sama.
    /// Perhatikan bahwa di Rust, setiap variabel (stack-allocated) dianggap sebagai objek terpisah yang dialokasikan.
    ///
    /// * Offset yang dihitung,**dalam byte**, tidak dapat melebihi `isize`.
    ///
    /// * Offset yang berada dalam batas tidak dapat bergantung pada "wrapping around" ruang alamat.Artinya, jumlah presisi tak terbatas,**dalam byte** harus sesuai dengan usize.
    ///
    /// Kompiler dan pustaka standar umumnya mencoba memastikan alokasi tidak pernah mencapai ukuran yang menjadi perhatian offset.
    /// Misalnya, `Vec` dan `Box` memastikan bahwa mereka tidak pernah mengalokasikan lebih dari `isize::MAX` byte, jadi `vec.as_ptr().add(vec.len())` selalu aman.
    ///
    /// Sebagian besar platform pada dasarnya bahkan tidak dapat membuat alokasi seperti itu.
    /// Misalnya, tidak ada platform 64-bit yang dikenal yang dapat melayani permintaan untuk 2 <sup>63</sup> byte karena batasan tabel halaman atau pemisahan ruang alamat.
    /// Namun, beberapa platform 32-bit dan 16-bit mungkin berhasil melayani permintaan lebih dari `isize::MAX` byte dengan hal-hal seperti Ekstensi Alamat Fisik.
    ///
    /// Dengan demikian, memori yang diperoleh langsung dari pengalokasi atau file yang dipetakan memori *mungkin* terlalu besar untuk ditangani dengan fungsi ini.
    ///
    /// Pertimbangkan untuk menggunakan [`wrapping_offset`] sebagai gantinya jika batasan ini sulit dipenuhi.
    /// Satu-satunya keuntungan dari metode ini adalah memungkinkan pengoptimalan compiler yang lebih agresif.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1));
    ///     println!("{}", *ptr.offset(2));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // KEAMANAN: penelepon harus memegang kontrak keamanan untuk `offset`.
        // Pointer yang diperoleh valid untuk penulisan karena pemanggil harus menjamin bahwa ia menunjuk ke objek yang dialokasikan sama dengan `self`.
        //
        unsafe { intrinsics::offset(self, count) as *mut T }
    }

    /// Menghitung offset dari penunjuk menggunakan pembungkusan aritmatika.
    /// `count` dalam satuan T;misalnya, `count` dari 3 mewakili offset pointer `3 * size_of::<T>()` byte.
    ///
    /// # Safety
    ///
    /// Operasi ini sendiri selalu aman, tetapi menggunakan penunjuk yang dihasilkan tidak.
    ///
    /// Pointer yang dihasilkan tetap terpasang ke objek yang dialokasikan sama dengan yang ditunjuk `self`.
    /// Ini mungkin *tidak* digunakan untuk mengakses objek dialokasikan yang berbeda.Perhatikan bahwa di Rust, setiap variabel (stack-allocated) dianggap sebagai objek terpisah yang dialokasikan.
    ///
    /// Dengan kata lain, `let z = x.wrapping_offset((y as isize) - (x as isize))`*tidak* membuat `z` sama dengan `y` meskipun kami menganggap `T` memiliki ukuran `1` dan tidak ada luapan: `z` masih terpasang ke objek tempat `x` dilampirkan, dan mendereferensi itu adalah Perilaku Tidak Terdefinisi kecuali `x` dan `y` menunjuk ke objek yang dialokasikan sama.
    ///
    /// Dibandingkan dengan [`offset`], metode ini pada dasarnya menunda persyaratan untuk tetap berada dalam objek yang dialokasikan sama: [`offset`] adalah Perilaku Tidak Terdefinisi langsung saat melintasi batas objek;`wrapping_offset` menghasilkan pointer tetapi masih mengarah ke Perilaku Tidak Terdefinisi jika pointer didereferensi ketika berada di luar batas objek yang dilampirkan.
    /// [`offset`] dapat dioptimalkan dengan lebih baik dan karenanya lebih disukai dalam kode yang peka terhadap kinerja.
    ///
    /// Pemeriksaan tertunda hanya mempertimbangkan nilai penunjuk yang didereferensi, bukan nilai antara yang digunakan selama penghitungan hasil akhir.
    /// Misalnya, `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` selalu sama dengan `x`.Dengan kata lain, meninggalkan objek yang dialokasikan dan kemudian memasukkannya kembali nanti diizinkan.
    ///
    /// Jika Anda perlu melewati batas objek, arahkan penunjuk ke bilangan bulat dan lakukan penghitungan di sana.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// // Iterasi menggunakan pointer mentah dengan penambahan dua elemen
    /// let mut data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *mut u8 = data.as_mut_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         *ptr = 0;
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// assert_eq!(&data, &[0, 2, 0, 4, 0]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // KEAMANAN: intrinsik `arith_offset` tidak memiliki prasyarat untuk dipanggil.
        unsafe { intrinsics::arith_offset(self, count) as *mut T }
    }

    /// Mengembalikan `None` jika pointernya null, atau mengembalikan referensi unik ke nilai yang dibungkus dalam `Some`.Jika nilainya mungkin tidak diinisialisasi, [`as_uninit_mut`] harus digunakan sebagai gantinya.
    ///
    /// Untuk mitra bersama, lihat [`as_ref`].
    ///
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    /// [`as_ref`]: #method.as_ref-1
    ///
    /// # Safety
    ///
    /// Saat memanggil metode ini, Anda harus memastikan bahwa *baik* penunjuknya adalah NULL *atau* semua hal berikut ini benar:
    ///
    /// * Penunjuk harus disejajarkan dengan benar.
    ///
    /// * Ini harus "dereferencable" dalam arti yang didefinisikan di [the module documentation].
    ///
    /// * Penunjuk harus menunjuk ke contoh `T` yang diinisialisasi.
    ///
    /// * Anda harus menerapkan aturan aliasing Rust, karena masa pakai yang dikembalikan `'a` dipilih secara sewenang-wenang dan tidak selalu mencerminkan masa pakai data yang sebenarnya.
    ///   Secara khusus, selama masa ini, memori yang ditunjuk penunjuk tidak boleh diakses (dibaca atau ditulis) melalui penunjuk lain.
    ///
    /// Ini berlaku bahkan jika hasil dari metode ini tidak digunakan!
    /// (Bagian tentang diinisialisasi belum sepenuhnya diputuskan, tetapi sampai itu, satu-satunya pendekatan yang aman adalah memastikan bahwa mereka benar-benar diinisialisasi.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { ptr.as_mut().unwrap() };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Ini akan mencetak: "[4, 2, 3]".
    /// ```
    ///
    /// # Versi yang tidak dicentang
    ///
    /// Jika Anda yakin penunjuk tidak akan pernah nol dan mencari semacam `as_mut_unchecked` yang mengembalikan `&mut T` daripada `Option<&mut T>`, ketahuilah bahwa Anda dapat merujuk penunjuk secara langsung.
    ///
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { &mut *ptr };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Ini akan mencetak: "[4, 2, 3]".
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_mut<'a>(self) -> Option<&'a mut T> {
        // KEAMANAN: penelepon harus menjamin bahwa `self` valid
        // referensi yang bisa berubah jika bukan null.
        if self.is_null() { None } else { unsafe { Some(&mut *self) } }
    }

    /// Mengembalikan `None` jika pointernya null, atau mengembalikan referensi unik ke nilai yang dibungkus dalam `Some`.
    /// Berbeda dengan [`as_mut`], ini tidak mengharuskan nilai harus diinisialisasi.
    ///
    /// Untuk mitra bersama, lihat [`as_uninit_ref`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    ///
    /// # Safety
    ///
    /// Saat memanggil metode ini, Anda harus memastikan bahwa *baik* penunjuknya adalah NULL *atau* semua hal berikut ini benar:
    ///
    /// * Penunjuk harus disejajarkan dengan benar.
    ///
    /// * Ini harus "dereferencable" dalam arti yang didefinisikan di [the module documentation].
    ///
    /// * Anda harus menerapkan aturan aliasing Rust, karena masa pakai yang dikembalikan `'a` dipilih secara sewenang-wenang dan tidak selalu mencerminkan masa pakai data yang sebenarnya.
    ///
    ///   Secara khusus, selama masa ini, memori yang ditunjuk penunjuk tidak boleh diakses (dibaca atau ditulis) melalui penunjuk lain.
    ///
    /// Ini berlaku bahkan jika hasil dari metode ini tidak digunakan!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut<'a>(self) -> Option<&'a mut MaybeUninit<T>>
    where
        T: Sized,
    {
        // KEAMANAN: penelepon harus menjamin bahwa `self` memenuhi semua
        // persyaratan untuk referensi.
        if self.is_null() { None } else { Some(unsafe { &mut *(self as *mut MaybeUninit<T>) }) }
    }

    /// Mengembalikan apakah dua petunjuk dijamin sama.
    ///
    /// Saat runtime, fungsi ini berperilaku seperti `self == other`.
    /// Namun, dalam beberapa konteks (misalnya, evaluasi waktu kompilasi), tidak selalu memungkinkan untuk menentukan persamaan dua pointer, jadi fungsi ini mungkin mengembalikan `false` secara palsu untuk pointer yang nantinya benar-benar menjadi sama.
    ///
    /// Tapi ketika mengembalikan `true`, pointernya dijamin sama.
    ///
    /// Fungsi ini adalah cermin dari [`guaranteed_ne`], tetapi bukan kebalikannya.Ada perbandingan penunjuk dimana kedua fungsi mengembalikan `false`.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// Nilai yang dikembalikan dapat berubah tergantung pada versi kompilator dan kode yang tidak aman mungkin tidak bergantung pada hasil fungsi ini untuk kesehatan.
    /// Disarankan untuk hanya menggunakan fungsi ini untuk pengoptimalan kinerja di mana nilai pengembalian `false` palsu oleh fungsi ini tidak mempengaruhi hasil, tetapi hanya kinerja.
    /// Konsekuensi penggunaan metode ini untuk membuat runtime dan kode waktu kompilasi berperilaku berbeda belum dieksplorasi.
    /// Metode ini tidak boleh digunakan untuk memperkenalkan perbedaan seperti itu, dan juga tidak boleh distabilkan sebelum kita memiliki pemahaman yang lebih baik tentang masalah ini.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self as *const _, other as *const _)
    }

    /// Menampilkan apakah dua penunjuk dijamin tidak sama.
    ///
    /// Saat runtime, fungsi ini berperilaku seperti `self != other`.
    /// Namun, dalam beberapa konteks (misalnya, evaluasi waktu kompilasi), tidak selalu memungkinkan untuk menentukan ketidaksamaan dua pointer, jadi fungsi ini mungkin mengembalikan `false` secara palsu untuk pointer yang nantinya benar-benar berubah menjadi tidak sama.
    ///
    /// Namun saat mengembalikan `true`, penunjuk dijamin tidak sama.
    ///
    /// Fungsi ini adalah cermin dari [`guaranteed_eq`], tetapi bukan kebalikannya.Ada perbandingan penunjuk dimana kedua fungsi mengembalikan `false`.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// Nilai yang dikembalikan dapat berubah tergantung pada versi kompilator dan kode yang tidak aman mungkin tidak bergantung pada hasil fungsi ini untuk kesehatan.
    /// Disarankan untuk hanya menggunakan fungsi ini untuk pengoptimalan kinerja di mana nilai pengembalian `false` palsu oleh fungsi ini tidak mempengaruhi hasil, tetapi hanya kinerja.
    /// Konsekuensi penggunaan metode ini untuk membuat runtime dan kode waktu kompilasi berperilaku berbeda belum dieksplorasi.
    /// Metode ini tidak boleh digunakan untuk memperkenalkan perbedaan seperti itu, dan juga tidak boleh distabilkan sebelum kita memiliki pemahaman yang lebih baik tentang masalah ini.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const unsafe fn guaranteed_ne(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self as *const _, other as *const _)
    }

    /// Menghitung jarak antara dua penunjuk.Nilai yang dikembalikan dalam satuan T: jarak dalam byte dibagi dengan `mem::size_of::<T>()`.
    ///
    /// Fungsi ini adalah kebalikan dari [`offset`].
    ///
    /// [`offset`]: #method.offset-1
    ///
    /// # Safety
    ///
    /// Jika salah satu dari kondisi berikut dilanggar, hasilnya adalah Perilaku Tidak Terdefinisi:
    ///
    /// * Baik penunjuk awal dan lainnya harus berada dalam batas atau satu byte setelah akhir dari objek yang dialokasikan sama.
    /// Perhatikan bahwa di Rust, setiap variabel (stack-allocated) dianggap sebagai objek terpisah yang dialokasikan.
    ///
    /// * Kedua penunjuk harus *diturunkan dari* penunjuk ke objek yang sama.
    ///   (Lihat di bawah untuk contoh.)
    ///
    /// * Jarak antara pointer, dalam byte, harus merupakan kelipatan tepat dari ukuran `T`.
    ///
    /// * Jarak antara pointer,**dalam byte**, tidak dapat melebihi `isize`.
    ///
    /// * Jarak yang berada dalam batas tidak dapat bergantung pada "wrapping around" ruang alamat.
    ///
    /// Jenis Rust tidak pernah lebih besar dari `isize::MAX` dan alokasi Rust tidak pernah menutupi ruang alamat, jadi dua pointer dalam beberapa nilai dari setiap jenis Rust `T` akan selalu memenuhi dua kondisi terakhir.
    ///
    /// Pustaka standar juga secara umum memastikan bahwa alokasi tidak pernah mencapai ukuran di mana offset menjadi perhatian.
    /// Misalnya, `Vec` dan `Box` memastikan mereka tidak pernah mengalokasikan lebih dari `isize::MAX` byte, jadi `ptr_into_vec.offset_from(vec.as_ptr())` selalu memenuhi dua kondisi terakhir.
    ///
    /// Sebagian besar platform pada dasarnya bahkan tidak dapat membangun alokasi sebesar itu.
    /// Misalnya, tidak ada platform 64-bit yang dikenal yang dapat melayani permintaan untuk 2 <sup>63</sup> byte karena batasan tabel halaman atau pemisahan ruang alamat.
    /// Namun, beberapa platform 32-bit dan 16-bit mungkin berhasil melayani permintaan lebih dari `isize::MAX` byte dengan hal-hal seperti Ekstensi Alamat Fisik.
    /// Dengan demikian, memori yang diperoleh langsung dari pengalokasi atau file yang dipetakan memori *mungkin* terlalu besar untuk ditangani dengan fungsi ini.
    /// (Perhatikan bahwa [`offset`] dan [`add`] juga memiliki batasan yang serupa dan karenanya tidak dapat digunakan pada alokasi yang begitu besar juga.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Fungsi ini panics jika `T` adalah Tipe ("ZST") Berukuran Nol.
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let mut a = [0; 5];
    /// let ptr1: *mut i32 = &mut a[1];
    /// let ptr2: *mut i32 = &mut a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Penggunaan yang salah*:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8));
    /// let ptr2 = Box::into_raw(Box::new(1u8));
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Jadikan ptr2_other sebagai "alias" dari ptr2, tetapi diturunkan dari ptr1.
    /// let ptr2_other = (ptr1 as *mut u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Karena ptr2_other dan ptr2 diturunkan dari pointer ke objek yang berbeda, menghitung offsetnya adalah perilaku tidak terdefinisi, meskipun keduanya mengarah ke alamat yang sama!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Perilaku Tidak Terdefinisi
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        // KEAMANAN: penelepon harus memegang kontrak keamanan untuk `offset_from`.
        unsafe { (self as *const T).offset_from(origin) }
    }

    /// Menghitung offset dari penunjuk (kemudahan untuk `.offset(count as isize)`).
    ///
    /// `count` dalam satuan T;misalnya, `count` dari 3 mewakili offset pointer `3 * size_of::<T>()` byte.
    ///
    /// # Safety
    ///
    /// Jika salah satu dari kondisi berikut dilanggar, hasilnya adalah Perilaku Tidak Terdefinisi:
    ///
    /// * Baik penunjuk awal dan hasil harus berada dalam batas atau satu byte setelah akhir dari objek yang dialokasikan sama.
    /// Perhatikan bahwa di Rust, setiap variabel (stack-allocated) dianggap sebagai objek terpisah yang dialokasikan.
    ///
    /// * Offset yang dihitung,**dalam byte**, tidak dapat melebihi `isize`.
    ///
    /// * Offset yang berada dalam batas tidak dapat mengandalkan ruang alamat "wrapping around".Artinya, jumlah presisi tak terbatas harus sesuai dengan `usize`.
    ///
    /// Kompiler dan pustaka standar umumnya mencoba memastikan alokasi tidak pernah mencapai ukuran yang menjadi perhatian offset.
    /// Misalnya, `Vec` dan `Box` memastikan bahwa mereka tidak pernah mengalokasikan lebih dari `isize::MAX` byte, jadi `vec.as_ptr().add(vec.len())` selalu aman.
    ///
    /// Sebagian besar platform pada dasarnya bahkan tidak dapat membuat alokasi seperti itu.
    /// Misalnya, tidak ada platform 64-bit yang dikenal yang dapat melayani permintaan untuk 2 <sup>63</sup> byte karena batasan tabel halaman atau pemisahan ruang alamat.
    /// Namun, beberapa platform 32-bit dan 16-bit mungkin berhasil melayani permintaan lebih dari `isize::MAX` byte dengan hal-hal seperti Ekstensi Alamat Fisik.
    ///
    /// Dengan demikian, memori yang diperoleh langsung dari pengalokasi atau file yang dipetakan memori *mungkin* terlalu besar untuk ditangani dengan fungsi ini.
    ///
    /// Pertimbangkan untuk menggunakan [`wrapping_add`] sebagai gantinya jika batasan ini sulit dipenuhi.
    /// Satu-satunya keuntungan dari metode ini adalah memungkinkan pengoptimalan compiler yang lebih agresif.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // KEAMANAN: penelepon harus memegang kontrak keamanan untuk `offset`.
        unsafe { self.offset(count as isize) }
    }

    /// Menghitung offset dari penunjuk (kemudahan untuk `.offset ((dihitung sebagai isize).wrapping_neg())`).
    ///
    /// `count` dalam satuan T;misalnya, `count` dari 3 mewakili offset pointer `3 * size_of::<T>()` byte.
    ///
    /// # Safety
    ///
    /// Jika salah satu dari kondisi berikut dilanggar, hasilnya adalah Perilaku Tidak Terdefinisi:
    ///
    /// * Baik penunjuk awal dan hasil harus berada dalam batas atau satu byte setelah akhir dari objek yang dialokasikan sama.
    /// Perhatikan bahwa di Rust, setiap variabel (stack-allocated) dianggap sebagai objek terpisah yang dialokasikan.
    ///
    /// * Offset yang dihitung tidak boleh melebihi `isize::MAX`**byte**.
    ///
    /// * Offset yang berada dalam batas tidak dapat bergantung pada "wrapping around" ruang alamat.Artinya, jumlah presisi tak terbatas harus sesuai dengan usize.
    ///
    /// Kompiler dan pustaka standar umumnya mencoba memastikan alokasi tidak pernah mencapai ukuran yang menjadi perhatian offset.
    /// Misalnya, `Vec` dan `Box` memastikan bahwa mereka tidak pernah mengalokasikan lebih dari `isize::MAX` byte, jadi `vec.as_ptr().add(vec.len()).sub(vec.len())` selalu aman.
    ///
    /// Sebagian besar platform pada dasarnya bahkan tidak dapat membuat alokasi seperti itu.
    /// Misalnya, tidak ada platform 64-bit yang dikenal yang dapat melayani permintaan untuk 2 <sup>63</sup> byte karena batasan tabel halaman atau pemisahan ruang alamat.
    /// Namun, beberapa platform 32-bit dan 16-bit mungkin berhasil melayani permintaan lebih dari `isize::MAX` byte dengan hal-hal seperti Ekstensi Alamat Fisik.
    ///
    /// Dengan demikian, memori yang diperoleh langsung dari pengalokasi atau file yang dipetakan memori *mungkin* terlalu besar untuk ditangani dengan fungsi ini.
    ///
    /// Pertimbangkan untuk menggunakan [`wrapping_sub`] sebagai gantinya jika batasan ini sulit dipenuhi.
    /// Satu-satunya keuntungan dari metode ini adalah memungkinkan pengoptimalan compiler yang lebih agresif.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // KEAMANAN: penelepon harus memegang kontrak keamanan untuk `offset`.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Menghitung offset dari penunjuk menggunakan pembungkusan aritmatika.
    /// (kenyamanan untuk `.wrapping_offset(count as isize)`)
    ///
    /// `count` dalam satuan T;misalnya, `count` dari 3 mewakili offset pointer `3 * size_of::<T>()` byte.
    ///
    /// # Safety
    ///
    /// Operasi ini sendiri selalu aman, tetapi menggunakan penunjuk yang dihasilkan tidak.
    ///
    /// Pointer yang dihasilkan tetap terpasang ke objek yang dialokasikan sama dengan yang ditunjuk `self`.
    /// Ini mungkin *tidak* digunakan untuk mengakses objek dialokasikan yang berbeda.Perhatikan bahwa di Rust, setiap variabel (stack-allocated) dianggap sebagai objek terpisah yang dialokasikan.
    ///
    /// Dengan kata lain, `let z = x.wrapping_add((y as usize) - (x as usize))`*tidak* membuat `z` sama dengan `y` meskipun kami menganggap `T` memiliki ukuran `1` dan tidak ada luapan: `z` masih terpasang ke objek tempat `x` dilampirkan, dan mendereferensi itu adalah Perilaku Tidak Terdefinisi kecuali `x` dan `y` menunjuk ke objek yang dialokasikan sama.
    ///
    /// Dibandingkan dengan [`add`], metode ini pada dasarnya menunda persyaratan untuk tetap berada dalam objek yang dialokasikan sama: [`add`] adalah Perilaku Tidak Terdefinisi langsung saat melintasi batas objek;`wrapping_add` menghasilkan pointer tetapi masih mengarah ke Perilaku Tidak Terdefinisi jika pointer didereferensi ketika berada di luar batas objek yang dilampirkan.
    /// [`add`] dapat dioptimalkan dengan lebih baik dan karenanya lebih disukai dalam kode yang peka terhadap kinerja.
    ///
    /// Pemeriksaan tertunda hanya mempertimbangkan nilai penunjuk yang didereferensi, bukan nilai antara yang digunakan selama penghitungan hasil akhir.
    /// Misalnya, `x.wrapping_add(o).wrapping_sub(o)` selalu sama dengan `x`.Dengan kata lain, meninggalkan objek yang dialokasikan dan kemudian memasukkannya kembali nanti diizinkan.
    ///
    /// Jika Anda perlu melewati batas objek, arahkan penunjuk ke bilangan bulat dan lakukan penghitungan di sana.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// // Iterasi menggunakan pointer mentah dengan penambahan dua elemen
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Loop ini mencetak "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Menghitung offset dari penunjuk menggunakan pembungkusan aritmatika.
    /// (kenyamanan untuk `.wrapping_offset ((dihitung sebagai isize).wrapping_neg())`)
    ///
    /// `count` dalam satuan T;misalnya, `count` dari 3 mewakili offset pointer `3 * size_of::<T>()` byte.
    ///
    /// # Safety
    ///
    /// Operasi ini sendiri selalu aman, tetapi menggunakan penunjuk yang dihasilkan tidak.
    ///
    /// Pointer yang dihasilkan tetap terpasang ke objek yang dialokasikan sama dengan yang ditunjuk `self`.
    /// Ini mungkin *tidak* digunakan untuk mengakses objek dialokasikan yang berbeda.Perhatikan bahwa di Rust, setiap variabel (stack-allocated) dianggap sebagai objek terpisah yang dialokasikan.
    ///
    /// Dengan kata lain, `let z = x.wrapping_sub((x as usize) - (y as usize))`*tidak* membuat `z` sama dengan `y` meskipun kami menganggap `T` memiliki ukuran `1` dan tidak ada luapan: `z` masih terpasang ke objek tempat `x` dilampirkan, dan mendereferensi itu adalah Perilaku Tidak Terdefinisi kecuali `x` dan `y` menunjuk ke objek yang dialokasikan sama.
    ///
    /// Dibandingkan dengan [`sub`], metode ini pada dasarnya menunda persyaratan untuk tetap berada dalam objek yang dialokasikan sama: [`sub`] adalah Perilaku Tidak Terdefinisi langsung saat melintasi batas objek;`wrapping_sub` menghasilkan pointer tetapi masih mengarah ke Perilaku Tidak Terdefinisi jika pointer didereferensi ketika berada di luar batas objek yang dilampirkan.
    /// [`sub`] dapat dioptimalkan dengan lebih baik dan karenanya lebih disukai dalam kode yang peka terhadap kinerja.
    ///
    /// Pemeriksaan tertunda hanya mempertimbangkan nilai penunjuk yang didereferensi, bukan nilai antara yang digunakan selama penghitungan hasil akhir.
    /// Misalnya, `x.wrapping_add(o).wrapping_sub(o)` selalu sama dengan `x`.Dengan kata lain, meninggalkan objek yang dialokasikan dan kemudian memasukkannya kembali nanti diizinkan.
    ///
    /// Jika Anda perlu melewati batas objek, arahkan penunjuk ke bilangan bulat dan lakukan penghitungan di sana.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Penggunaan dasar:
    ///
    /// ```
    /// // Iterasi menggunakan pointer mentah dengan penambahan dua elemen (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Loop ini mencetak "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Setel nilai penunjuk ke `ptr`.
    ///
    /// Jika `self` adalah penunjuk (fat) ke tipe tidak berukuran, operasi ini hanya akan mempengaruhi bagian penunjuk, sedangkan untuk (thin) penunjuk ke jenis berukuran, ini memiliki efek yang sama seperti tugas sederhana.
    ///
    /// Penunjuk yang dihasilkan akan memiliki asal `val`, yaitu untuk penunjuk gemuk, operasi ini secara semantik sama dengan membuat penunjuk lemak baru dengan nilai penunjuk data `val` tetapi metadata `self`.
    ///
    ///
    /// # Examples
    ///
    /// Fungsi ini terutama berguna untuk memungkinkan aritmatika pointer byte-bijaksana pada pointer yang berpotensi gemuk:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let mut arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &mut arr[0] as *mut dyn Debug;
    /// let thin = ptr as *mut u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *mut i32), 3);
    ///     println!("{:?}", &*ptr); // akan mencetak "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *mut u8) -> Self {
        let thin = &mut self as *mut *mut T as *mut *mut u8;
        // KEAMANAN: Jika penunjuk tipis, operasi ini identik
        // ke tugas sederhana.
        // Dalam kasus penunjuk gemuk, dengan penerapan tata letak penunjuk lemak saat ini, bidang pertama penunjuk tersebut selalu merupakan penunjuk data, yang juga ditetapkan.
        //
        unsafe { *thin = val };
        self
    }

    /// Membaca nilai dari `self` tanpa memindahkannya.
    /// Ini membuat memori di `self` tidak berubah.
    ///
    /// Lihat [`ptr::read`] untuk masalah keamanan dan contoh.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // KEAMANAN: penelepon harus memegang kontrak keamanan untuk ``.
        unsafe { read(self) }
    }

    /// Melakukan pembacaan volatil nilai dari `self` tanpa memindahkannya.Ini membuat memori di `self` tidak berubah.
    ///
    /// Operasi volatil dimaksudkan untuk bekerja pada memori I/O, dan dijamin tidak akan dihilangkan atau diatur ulang oleh compiler di seluruh operasi volatil lainnya.
    ///
    ///
    /// Lihat [`ptr::read_volatile`] untuk masalah keamanan dan contoh.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // KEAMANAN: penelepon harus memegang kontrak keamanan untuk `read_volatile`.
        unsafe { read_volatile(self) }
    }

    /// Membaca nilai dari `self` tanpa memindahkannya.
    /// Ini membuat memori di `self` tidak berubah.
    ///
    /// Tidak seperti `read`, penunjuk mungkin tidak sejajar.
    ///
    /// Lihat [`ptr::read_unaligned`] untuk masalah keamanan dan contoh.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // KEAMANAN: penelepon harus memegang kontrak keamanan untuk `read_unaligned`.
        unsafe { read_unaligned(self) }
    }

    /// Menyalin `count * size_of<T>` byte dari `self` ke `dest`.
    /// Sumber dan tujuan mungkin tumpang tindih.
    ///
    /// NOTE: ini memiliki urutan argumen *sama* dengan [`ptr::copy`].
    ///
    /// Lihat [`ptr::copy`] untuk masalah keamanan dan contoh.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // KEAMANAN: penelepon harus memegang kontrak keamanan untuk `copy`.
        unsafe { copy(self, dest, count) }
    }

    /// Menyalin `count * size_of<T>` byte dari `self` ke `dest`.
    /// Sumber dan tujuan mungkin *tidak* tumpang tindih.
    ///
    /// NOTE: ini memiliki urutan argumen *sama* dengan [`ptr::copy_nonoverlapping`].
    ///
    /// Lihat [`ptr::copy_nonoverlapping`] untuk masalah keamanan dan contoh.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // KEAMANAN: penelepon harus memegang kontrak keamanan untuk `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Menyalin `count * size_of<T>` byte dari `src` ke `self`.
    /// Sumber dan tujuan mungkin tumpang tindih.
    ///
    /// NOTE: ini memiliki urutan argumen *berlawanan* dari [`ptr::copy`].
    ///
    /// Lihat [`ptr::copy`] untuk masalah keamanan dan contoh.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // KEAMANAN: penelepon harus memegang kontrak keamanan untuk `copy`.
        unsafe { copy(src, self, count) }
    }

    /// Menyalin `count * size_of<T>` byte dari `src` ke `self`.
    /// Sumber dan tujuan mungkin *tidak* tumpang tindih.
    ///
    /// NOTE: ini memiliki urutan argumen *berlawanan* dari [`ptr::copy_nonoverlapping`].
    ///
    /// Lihat [`ptr::copy_nonoverlapping`] untuk masalah keamanan dan contoh.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from_nonoverlapping(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // KEAMANAN: penelepon harus memegang kontrak keamanan untuk `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(src, self, count) }
    }

    /// Menjalankan destruktor (jika ada) dari nilai yang diarahkan ke.
    ///
    /// Lihat [`ptr::drop_in_place`] untuk masalah keamanan dan contoh.
    ///
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn drop_in_place(self) {
        // KEAMANAN: penelepon harus memegang kontrak keamanan untuk `drop_in_place`.
        unsafe { drop_in_place(self) }
    }

    /// Menimpa lokasi memori dengan nilai yang diberikan tanpa membaca atau menghapus nilai lama.
    ///
    ///
    /// Lihat [`ptr::write`] untuk masalah keamanan dan contoh.
    ///
    /// [`ptr::write`]: crate::ptr::write()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write(self, val: T)
    where
        T: Sized,
    {
        // KEAMANAN: penelepon harus memegang kontrak keamanan untuk `write`.
        unsafe { write(self, val) }
    }

    /// Memanggil memset pada penunjuk yang ditentukan, menyetel `count * size_of::<T>()` byte memori mulai dari `self` hingga `val`.
    ///
    ///
    /// Lihat [`ptr::write_bytes`] untuk masalah keamanan dan contoh.
    ///
    /// [`ptr::write_bytes`]: crate::ptr::write_bytes()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_bytes(self, val: u8, count: usize)
    where
        T: Sized,
    {
        // KEAMANAN: penelepon harus memegang kontrak keamanan untuk `write_bytes`.
        unsafe { write_bytes(self, val, count) }
    }

    /// Melakukan penulisan volatil dari lokasi memori dengan nilai yang diberikan tanpa membaca atau menghapus nilai lama.
    ///
    /// Operasi volatil dimaksudkan untuk bekerja pada memori I/O, dan dijamin tidak akan dihilangkan atau diatur ulang oleh compiler di seluruh operasi volatil lainnya.
    ///
    ///
    /// Lihat [`ptr::write_volatile`] untuk masalah keamanan dan contoh.
    ///
    /// [`ptr::write_volatile`]: crate::ptr::write_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_volatile(self, val: T)
    where
        T: Sized,
    {
        // KEAMANAN: penelepon harus memegang kontrak keamanan untuk `write_volatile`.
        unsafe { write_volatile(self, val) }
    }

    /// Menimpa lokasi memori dengan nilai yang diberikan tanpa membaca atau menghapus nilai lama.
    ///
    ///
    /// Tidak seperti `write`, penunjuk mungkin tidak sejajar.
    ///
    /// Lihat [`ptr::write_unaligned`] untuk masalah keamanan dan contoh.
    ///
    /// [`ptr::write_unaligned`]: crate::ptr::write_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
    #[inline]
    pub const unsafe fn write_unaligned(self, val: T)
    where
        T: Sized,
    {
        // KEAMANAN: penelepon harus memegang kontrak keamanan untuk `write_unaligned`.
        unsafe { write_unaligned(self, val) }
    }

    /// Mengganti nilai di `self` dengan `src`, mengembalikan nilai lama, tanpa menurunkan keduanya.
    ///
    ///
    /// Lihat [`ptr::replace`] untuk masalah keamanan dan contoh.
    ///
    /// [`ptr::replace`]: crate::ptr::replace()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn replace(self, src: T) -> T
    where
        T: Sized,
    {
        // KEAMANAN: penelepon harus memegang kontrak keamanan untuk `replace`.
        unsafe { replace(self, src) }
    }

    /// Menukar nilai di dua lokasi yang bisa berubah dari jenis yang sama, tanpa juga melakukan deinisialisasi.
    /// Mereka mungkin tumpang tindih, tidak seperti `mem::swap` yang setara.
    ///
    /// Lihat [`ptr::swap`] untuk masalah keamanan dan contoh.
    ///
    /// [`ptr::swap`]: crate::ptr::swap()
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn swap(self, with: *mut T)
    where
        T: Sized,
    {
        // KEAMANAN: penelepon harus memegang kontrak keamanan untuk `swap`.
        unsafe { swap(self, with) }
    }

    /// Menghitung offset yang perlu diterapkan ke penunjuk agar sejajar dengan `align`.
    ///
    /// Jika tidak mungkin untuk menyelaraskan penunjuk, implementasi akan mengembalikan `usize::MAX`.
    /// Diijinkan untuk implementasi untuk *selalu* mengembalikan `usize::MAX`.
    /// Hanya performa algoritme Anda yang dapat bergantung pada mendapatkan offset yang dapat digunakan di sini, bukan kebenarannya.
    ///
    /// Offset dinyatakan dalam jumlah elemen `T`, dan bukan byte.Nilai yang dikembalikan dapat digunakan dengan metode `wrapping_add`.
    ///
    /// Tidak ada jaminan apa pun bahwa mengimbangi penunjuk tidak akan meluap atau melampaui alokasi yang ditunjuk penunjuk.
    ///
    /// Terserah pemanggil untuk memastikan bahwa offset yang dikembalikan benar dalam semua hal selain penyelarasan.
    ///
    /// # Panics
    ///
    /// Fungsi panics jika `align` bukan power-of-two.
    ///
    /// # Examples
    ///
    /// Mengakses `u8` yang berdekatan sebagai `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // sementara penunjuk dapat disejajarkan melalui `offset`, penunjuk akan mengarah ke luar alokasi
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // KEAMANAN: `align` telah diperiksa menjadi kekuatan 2 di atas
        unsafe { align_offset(self, align) }
    }
}

#[lang = "mut_slice_ptr"]
impl<T> *mut [T] {
    /// Menampilkan panjang potongan mentah.
    ///
    /// Nilai yang dikembalikan adalah jumlah **elemen**, bukan jumlah byte.
    ///
    /// Fungsi ini aman, bahkan saat potongan mentah tidak dapat ditransmisikan ke referensi potongan karena penunjuknya null atau tidak selaras.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // SAFETY: ini aman karena `*const [T]` dan `FatPtr<T>` memiliki layout yang sama.
            // Hanya `std` yang dapat memberikan jaminan ini.
            unsafe { Repr { rust_mut: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Mengembalikan pointer mentah ke buffer slice.
    ///
    /// Ini sama dengan mentransmisikan `self` ke `*mut T`, tetapi lebih aman untuk tipe.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 0 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self as *mut T
    }

    /// Mengembalikan pointer mentah ke elemen atau subslice, tanpa melakukan pemeriksaan batas.
    ///
    /// Memanggil metode ini dengan indeks di luar batas atau saat `self` tidak dapat dideferensi adalah *[perilaku tidak ditentukan]* meskipun penunjuk yang dihasilkan tidak digunakan.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &mut [1, 2, 4] as *mut [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1), x.as_mut_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> *mut I::Output
    where
        I: SliceIndex<[T]>,
    {
        // KEAMANAN: penelepon memastikan bahwa `self` dapat dibedakan dan `index` dalam batas.
        unsafe { index.get_unchecked_mut(self) }
    }

    /// Mengembalikan `None` jika pointernya null, atau mengembalikan potongan bersama ke nilai yang dibungkus dalam `Some`.
    /// Berbeda dengan [`as_ref`], ini tidak mengharuskan nilai harus diinisialisasi.
    ///
    /// Untuk mitra yang bisa berubah, lihat [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_slice_mut`]: #method.as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Saat memanggil metode ini, Anda harus memastikan bahwa *baik* penunjuknya adalah NULL *atau* semua hal berikut ini benar:
    ///
    /// * Penunjuk harus [valid] agar dapat dibaca `ptr.len() * mem::size_of::<T>()` banyak byte, dan harus disejajarkan dengan benar.Ini khususnya berarti:
    ///
    ///     * Seluruh rentang memori potongan ini harus berada dalam satu objek yang dialokasikan!
    ///       Irisan tidak pernah bisa menjangkau beberapa objek yang dialokasikan.
    ///
    ///     * Penunjuk harus sejajar bahkan untuk irisan panjang-nol.
    ///     Salah satu alasannya adalah bahwa pengoptimalan tata letak enum mungkin mengandalkan referensi (termasuk irisan dengan panjang berapa pun) yang diselaraskan dan bukan nol untuk membedakannya dari data lain.
    ///
    ///     Anda bisa mendapatkan penunjuk yang dapat digunakan sebagai `data` untuk irisan panjang-nol menggunakan [`NonNull::dangling()`].
    ///
    /// * Ukuran total `ptr.len() * mem::size_of::<T>()` potongan tidak boleh lebih dari `isize::MAX`.
    ///   Lihat dokumentasi keamanan [`pointer::offset`].
    ///
    /// * Anda harus menerapkan aturan aliasing Rust, karena masa pakai yang dikembalikan `'a` dipilih secara sewenang-wenang dan tidak selalu mencerminkan masa pakai data yang sebenarnya.
    ///   Secara khusus, selama durasi ini, memori yang ditunjuk penunjuk tidak boleh bermutasi (kecuali di dalam `UnsafeCell`).
    ///
    /// Ini berlaku bahkan jika hasil dari metode ini tidak digunakan!
    ///
    /// Lihat juga [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // KEAMANAN: penelepon harus memegang kontrak keamanan untuk `as_uninit_slice`.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }

    /// Mengembalikan `None` jika pointernya null, atau mengembalikan potongan unik ke nilai yang dibungkus dalam `Some`.
    /// Berbeda dengan [`as_mut`], ini tidak mengharuskan nilai harus diinisialisasi.
    ///
    /// Untuk mitra bersama, lihat [`as_uninit_slice`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_slice`]: #method.as_uninit_slice-1
    ///
    /// # Safety
    ///
    /// Saat memanggil metode ini, Anda harus memastikan bahwa *baik* penunjuknya adalah NULL *atau* semua hal berikut ini benar:
    ///
    /// * Penunjuk harus [valid] untuk membaca dan menulis untuk `ptr.len() * mem::size_of::<T>()` banyak byte, dan harus disejajarkan dengan benar.Ini khususnya berarti:
    ///
    ///     * Seluruh rentang memori potongan ini harus berada dalam satu objek yang dialokasikan!
    ///       Irisan tidak pernah bisa menjangkau beberapa objek yang dialokasikan.
    ///
    ///     * Penunjuk harus sejajar bahkan untuk irisan panjang-nol.
    ///     Salah satu alasannya adalah bahwa pengoptimalan tata letak enum mungkin mengandalkan referensi (termasuk irisan dengan panjang berapa pun) yang diselaraskan dan bukan nol untuk membedakannya dari data lain.
    ///
    ///     Anda bisa mendapatkan penunjuk yang dapat digunakan sebagai `data` untuk irisan panjang-nol menggunakan [`NonNull::dangling()`].
    ///
    /// * Ukuran total `ptr.len() * mem::size_of::<T>()` potongan tidak boleh lebih dari `isize::MAX`.
    ///   Lihat dokumentasi keamanan [`pointer::offset`].
    ///
    /// * Anda harus menerapkan aturan aliasing Rust, karena masa pakai yang dikembalikan `'a` dipilih secara sewenang-wenang dan tidak selalu mencerminkan masa pakai data yang sebenarnya.
    ///   Secara khusus, selama masa ini, memori yang ditunjuk penunjuk tidak boleh diakses (dibaca atau ditulis) melalui penunjuk lain.
    ///
    /// Ini berlaku bahkan jika hasil dari metode ini tidak digunakan!
    ///
    /// Lihat juga [`slice::from_raw_parts_mut`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut<'a>(self) -> Option<&'a mut [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // KEAMANAN: penelepon harus memegang kontrak keamanan untuk `as_uninit_slice_mut`.
            Some(unsafe { slice::from_raw_parts_mut(self as *mut MaybeUninit<T>, self.len()) })
        }
    }
}

// Kesetaraan untuk pointer
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *mut T {
    #[inline]
    fn eq(&self, other: &*mut T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *mut T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *mut T {
    #[inline]
    fn cmp(&self, other: &*mut T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *mut T {
    #[inline]
    fn partial_cmp(&self, other: &*mut T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*mut T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*mut T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*mut T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*mut T) -> bool {
        *self >= *other
    }
}