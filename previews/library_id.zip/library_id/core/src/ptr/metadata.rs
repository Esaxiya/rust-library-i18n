#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Menyediakan jenis metadata penunjuk dari jenis menunjuk ke apa pun.
///
/// # Metadata penunjuk
///
/// Jenis penunjuk mentah dan jenis referensi di Rust dapat dianggap terbuat dari dua bagian:
/// penunjuk data yang berisi alamat memori dari nilai tersebut, dan beberapa metadata.
///
/// Untuk jenis berukuran statis (yang menerapkan `Sized` traits) serta untuk jenis `extern`, pointer dikatakan "tipis": metadata berukuran nol dan jenisnya adalah `()`.
///
///
/// Pointer ke [dynamically-sized types][dst] dikatakan "lebar" atau "gemuk", mereka memiliki metadata yang tidak berukuran nol:
///
/// * Untuk struct yang bidang terakhirnya adalah DST, metadata adalah metadata untuk bidang terakhir
/// * Untuk tipe `str`, metadata adalah panjang byte sebagai `usize`
/// * Untuk jenis potongan seperti `[T]`, metadata adalah panjang item sebagai `usize`
/// * Untuk objek trait seperti `dyn SomeTrait`, metadatanya adalah [`DynMetadata<Self>`][DynMetadata] (mis. `DynMetadata<dyn SomeTrait>`)
///
/// Di future, bahasa Rust dapat memperoleh jenis jenis baru yang memiliki metadata penunjuk berbeda.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait
///
/// Inti dari trait ini adalah tipe yang terkait dengan `Metadata`, yaitu `()` atau `usize` atau `DynMetadata<_>` seperti dijelaskan di atas.
/// Ini secara otomatis diterapkan untuk setiap jenis.
/// Ini dapat diasumsikan untuk diterapkan dalam konteks umum, bahkan tanpa ikatan yang sesuai.
///
/// # Usage
///
/// Pointer mentah dapat diuraikan menjadi alamat data dan komponen metadata dengan metode [`to_raw_parts`] mereka.
///
/// Atau, metadata saja dapat diekstraksi dengan fungsi [`metadata`].
/// Referensi dapat diteruskan ke [`metadata`] dan secara implisit dipaksakan.
///
/// Penunjuk (possibly-wide) dapat disatukan kembali dari alamat dan metadatanya dengan [`from_raw_parts`] atau [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Jenis metadata dalam pointer dan referensi ke `Self`.
    #[lang = "metadata_type"]
    // NOTE: Simpan trait bounds di `static_assert_expected_bounds_for_metadata`
    //
    // di `library/core/src/ptr/metadata.rs` sinkron dengan yang ada di sini:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Petunjuk ke jenis yang menerapkan alias trait ini "tipis".
///
/// Ini termasuk jenis `Sized` statis dan jenis `extern`.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: jangan stabilkan ini sebelum alias trait stabil dalam bahasa?
pub trait Thin = Pointee<Metadata = ()>;

/// Ekstrak komponen metadata dari sebuah pointer.
///
/// Nilai tipe `*mut T`, `&T`, atau `&mut T` dapat diteruskan langsung ke fungsi ini karena secara implisit dipaksakan ke `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // KEAMANAN: Mengakses nilai dari penyatuan `PtrRepr` aman karena * const T
    // dan PtrComponents<T>memiliki tata letak memori yang sama.
    // Hanya std yang dapat membuat jaminan ini.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Membentuk penunjuk mentah (possibly-wide) dari alamat data dan metadata.
///
/// Fungsi ini aman tetapi penunjuk yang dikembalikan belum tentu aman untuk dereferensi.
/// Untuk irisan, lihat dokumentasi [`slice::from_raw_parts`] untuk persyaratan keselamatan.
/// Untuk objek trait, metadata harus berasal dari penunjuk ke tipe ereased dasar yang sama.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // KEAMANAN: Mengakses nilai dari penyatuan `PtrRepr` aman karena * const T
    // dan PtrComponents<T>memiliki tata letak memori yang sama.
    // Hanya std yang dapat membuat jaminan ini.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Melakukan fungsionalitas yang sama seperti [`from_raw_parts`], kecuali penunjuk `*mut` mentah dikembalikan, sebagai lawan dari penunjuk `* const` mentah.
///
///
/// Lihat dokumentasi [`from_raw_parts`] untuk lebih jelasnya.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // KEAMANAN: Mengakses nilai dari penyatuan `PtrRepr` aman karena * const T
    // dan PtrComponents<T>memiliki tata letak memori yang sama.
    // Hanya std yang dapat membuat jaminan ini.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Implikasi manual diperlukan untuk menghindari ikatan `T: Copy`.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Implikasi manual diperlukan untuk menghindari ikatan `T: Clone`.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Metadata untuk jenis objek `Dyn = dyn SomeTrait` trait.
///
/// Ini adalah penunjuk ke vtable (tabel panggilan virtual) yang mewakili semua informasi yang diperlukan untuk memanipulasi tipe konkret yang disimpan di dalam objek trait.
/// Vtable terutama berisi:
///
/// * jenis ukuran
/// * jenis perataan
/// * pointer ke tipe implan `drop_in_place` (mungkin tidak ada operasi untuk data biasa-lama)
/// * petunjuk ke semua metode untuk implementasi tipe trait
///
/// Perhatikan bahwa tiga yang pertama adalah spesial karena mereka perlu mengalokasikan, menjatuhkan, dan membatalkan alokasi objek trait apa pun.
///
/// Anda dapat memberi nama struct ini dengan parameter tipe yang bukan objek `dyn` trait (misalnya `DynMetadata<u64>`) tetapi tidak untuk mendapatkan nilai yang berarti dari struct itu.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Awalan umum dari semua vtables.Ini diikuti oleh pointer fungsi untuk metode trait.
///
/// Detail implementasi pribadi `DynMetadata::size_of` dll.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Mengembalikan ukuran tipe yang terkait dengan vtable ini.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Mengembalikan perataan jenis yang terkait dengan vtable ini.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Mengembalikan ukuran dan perataan sebagai `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // SAFETY: penyusun memancarkan vtable ini untuk jenis beton Rust yang
        // dikenal memiliki tata letak yang valid.Alasan yang sama seperti di `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Implikasi manual diperlukan untuk menghindari batas `Dyn: $Trait`.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}