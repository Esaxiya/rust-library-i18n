use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` tetapi bukan nol dan kovarian.
///
/// Ini sering kali merupakan hal yang benar untuk digunakan saat membuat struktur data menggunakan pointer mentah, tetapi pada akhirnya lebih berbahaya untuk digunakan karena properti tambahannya.Jika Anda tidak yakin apakah Anda harus menggunakan `NonNull<T>`, gunakan saja `*mut T`!
///
/// Tidak seperti `*mut T`, penunjuk harus selalu bukan nol, bahkan jika penunjuk tidak pernah dirujuk.Ini agar enum dapat menggunakan nilai terlarang ini sebagai diskriminan-`Option<NonNull<T>>` memiliki ukuran yang sama dengan `* mut T`.
/// Namun penunjuk mungkin masih menjuntai jika tidak dideferensiasi.
///
/// Tidak seperti `*mut T`, `NonNull<T>` dipilih sebagai kovarian atas `T`.Hal ini memungkinkan untuk menggunakan `NonNull<T>` saat membuat jenis kovarian, tetapi menimbulkan risiko ketidaknyamanan jika digunakan dalam jenis yang seharusnya tidak menjadi kovarian.
/// (Pilihan sebaliknya dibuat untuk `*mut T` meskipun secara teknis ketidaknyamanan hanya bisa disebabkan oleh pemanggilan fungsi yang tidak aman.)
///
/// Kovarian benar untuk sebagian besar abstraksi aman, seperti `Box`, `Rc`, `Arc`, `Vec`, dan `LinkedList`.Ini terjadi karena mereka menyediakan API publik yang mengikuti aturan XOR bersama yang dapat berubah normal dari Rust.
///
/// Jika jenis Anda tidak dapat menjadi kovarian dengan aman, Anda harus memastikannya berisi beberapa bidang tambahan untuk memberikan invarian.Seringkali bidang ini adalah tipe [`PhantomData`] seperti `PhantomData<Cell<T>>` atau `PhantomData<&'a mut T>`.
///
/// Perhatikan bahwa `NonNull<T>` memiliki instance `From` untuk `&T`.Namun, ini tidak mengubah fakta bahwa mutasi melalui (pointer yang diturunkan dari a) referensi bersama adalah perilaku yang tidak ditentukan kecuali mutasi terjadi di dalam [`UnsafeCell<T>`].Hal yang sama berlaku untuk membuat referensi yang bisa berubah dari referensi bersama.
///
/// Saat menggunakan instans `From` ini tanpa `UnsafeCell<T>`, Anda bertanggung jawab untuk memastikan bahwa `as_mut` tidak pernah dipanggil, dan `as_ptr` tidak pernah digunakan untuk mutasi.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` pointer bukan `Send` karena data yang mereka referensikan mungkin memiliki alias.
// NB, impl ini tidak diperlukan, tetapi harus memberikan pesan kesalahan yang lebih baik.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` pointer bukan `Sync` karena data yang mereka referensikan mungkin memiliki alias.
// NB, impl ini tidak diperlukan, tetapi harus memberikan pesan kesalahan yang lebih baik.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Membuat `NonNull` baru yang menjuntai, tetapi sejajar.
    ///
    /// Ini berguna untuk menginisialisasi tipe yang dialokasikan dengan malas, seperti yang dilakukan `Vec::new`.
    ///
    /// Perhatikan bahwa nilai penunjuk berpotensi mewakili penunjuk yang valid ke `T`, yang berarti ini tidak boleh digunakan sebagai nilai sentinel "not yet initialized".
    /// Jenis yang dengan malas mengalokasikan harus melacak inisialisasi dengan cara lain.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // KEAMANAN: mem::align_of() mengembalikan penggunaan bukan nol yang kemudian dicor
        // ke * mut T.
        // Oleh karena itu, `ptr` bukan null dan kondisi untuk memanggil new_unchecked() dipatuhi.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Mengembalikan referensi bersama ke nilai.Berbeda dengan [`as_ref`], ini tidak mengharuskan nilai harus diinisialisasi.
    ///
    /// Untuk mitra yang bisa berubah, lihat [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Saat memanggil metode ini, Anda harus memastikan bahwa semua hal berikut ini benar:
    ///
    /// * Penunjuk harus disejajarkan dengan benar.
    ///
    /// * Ini harus "dereferencable" dalam arti yang didefinisikan di [the module documentation].
    ///
    /// * Anda harus menerapkan aturan aliasing Rust, karena masa pakai yang dikembalikan `'a` dipilih secara sewenang-wenang dan tidak selalu mencerminkan masa pakai data yang sebenarnya.
    ///
    ///   Secara khusus, selama durasi ini, memori yang ditunjuk penunjuk tidak boleh bermutasi (kecuali di dalam `UnsafeCell`).
    ///
    /// Ini berlaku bahkan jika hasil dari metode ini tidak digunakan!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // KEAMANAN: penelepon harus menjamin bahwa `self` memenuhi semua
        // persyaratan untuk referensi.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Mengembalikan referensi unik ke nilai.Berbeda dengan [`as_mut`], ini tidak mengharuskan nilai harus diinisialisasi.
    ///
    /// Untuk mitra bersama, lihat [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Saat memanggil metode ini, Anda harus memastikan bahwa semua hal berikut ini benar:
    ///
    /// * Penunjuk harus disejajarkan dengan benar.
    ///
    /// * Ini harus "dereferencable" dalam arti yang didefinisikan di [the module documentation].
    ///
    /// * Anda harus menerapkan aturan aliasing Rust, karena masa pakai yang dikembalikan `'a` dipilih secara sewenang-wenang dan tidak selalu mencerminkan masa pakai data yang sebenarnya.
    ///
    ///   Secara khusus, selama masa ini, memori yang ditunjuk penunjuk tidak boleh diakses (dibaca atau ditulis) melalui penunjuk lain.
    ///
    /// Ini berlaku bahkan jika hasil dari metode ini tidak digunakan!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // KEAMANAN: penelepon harus menjamin bahwa `self` memenuhi semua
        // persyaratan untuk referensi.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Membuat `NonNull` baru.
    ///
    /// # Safety
    ///
    /// `ptr` harus bukan nol.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // KEAMANAN: penelepon harus menjamin bahwa `ptr` bukan null.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Membuat `NonNull` baru jika `ptr` bukan nol.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // KEAMANAN: Pointer sudah diperiksa dan bukan null
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Melakukan fungsionalitas yang sama seperti [`std::ptr::from_raw_parts`], kecuali penunjuk `NonNull` dikembalikan, sebagai lawan dari penunjuk `*const` mentah.
    ///
    ///
    /// Lihat dokumentasi [`std::ptr::from_raw_parts`] untuk lebih jelasnya.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // KEAMANAN: Hasil `ptr::from::raw_parts_mut` bukan nol karena `data_address` adalah.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Menguraikan pointer (mungkin lebar) menjadi komponen alamat dan metadata.
    ///
    /// Penunjuk nantinya dapat direkonstruksi dengan [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Memperoleh penunjuk `*mut` yang mendasari.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Mengembalikan referensi bersama ke nilai.Jika nilainya mungkin tidak diinisialisasi, [`as_uninit_ref`] harus digunakan sebagai gantinya.
    ///
    /// Untuk mitra yang bisa berubah, lihat [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Saat memanggil metode ini, Anda harus memastikan bahwa semua hal berikut ini benar:
    ///
    /// * Penunjuk harus disejajarkan dengan benar.
    ///
    /// * Ini harus "dereferencable" dalam arti yang didefinisikan di [the module documentation].
    ///
    /// * Penunjuk harus menunjuk ke contoh `T` yang diinisialisasi.
    ///
    /// * Anda harus menerapkan aturan aliasing Rust, karena masa pakai yang dikembalikan `'a` dipilih secara sewenang-wenang dan tidak selalu mencerminkan masa pakai data yang sebenarnya.
    ///
    ///   Secara khusus, selama durasi ini, memori yang ditunjuk penunjuk tidak boleh bermutasi (kecuali di dalam `UnsafeCell`).
    ///
    /// Ini berlaku bahkan jika hasil dari metode ini tidak digunakan!
    /// (Bagian tentang diinisialisasi belum sepenuhnya diputuskan, tetapi sampai itu, satu-satunya pendekatan yang aman adalah memastikan bahwa mereka benar-benar diinisialisasi.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // KEAMANAN: penelepon harus menjamin bahwa `self` memenuhi semua
        // persyaratan untuk referensi.
        unsafe { &*self.as_ptr() }
    }

    /// Mengembalikan referensi unik ke nilai.Jika nilainya mungkin tidak diinisialisasi, [`as_uninit_mut`] harus digunakan sebagai gantinya.
    ///
    /// Untuk mitra bersama, lihat [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Saat memanggil metode ini, Anda harus memastikan bahwa semua hal berikut ini benar:
    ///
    /// * Penunjuk harus disejajarkan dengan benar.
    ///
    /// * Ini harus "dereferencable" dalam arti yang didefinisikan di [the module documentation].
    ///
    /// * Penunjuk harus menunjuk ke contoh `T` yang diinisialisasi.
    ///
    /// * Anda harus menerapkan aturan aliasing Rust, karena masa pakai yang dikembalikan `'a` dipilih secara sewenang-wenang dan tidak selalu mencerminkan masa pakai data yang sebenarnya.
    ///
    ///   Secara khusus, selama masa ini, memori yang ditunjuk penunjuk tidak boleh diakses (dibaca atau ditulis) melalui penunjuk lain.
    ///
    /// Ini berlaku bahkan jika hasil dari metode ini tidak digunakan!
    /// (Bagian tentang diinisialisasi belum sepenuhnya diputuskan, tetapi sampai itu, satu-satunya pendekatan yang aman adalah memastikan bahwa mereka benar-benar diinisialisasi.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // KEAMANAN: penelepon harus menjamin bahwa `self` memenuhi semua
        // persyaratan untuk referensi yang bisa berubah.
        unsafe { &mut *self.as_ptr() }
    }

    /// Mentransmisikan ke penunjuk jenis lain.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // KEAMANAN: `self` adalah penunjuk `NonNull` yang tentunya bukan null
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Membuat potongan mentah non-null dari pointer tipis dan panjang.
    ///
    /// Argumen `len` adalah jumlah **elemen**, bukan jumlah byte.
    ///
    /// Fungsi ini aman, tetapi mendereferensi nilai hasil tidak aman.
    /// Lihat dokumentasi [`slice::from_raw_parts`] untuk persyaratan keamanan irisan.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // membuat penunjuk irisan saat memulai dengan penunjuk ke elemen pertama
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Perhatikan bahwa contoh ini secara artifisial mendemonstrasikan penggunaan metode ini, tetapi `let slice= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // KESELAMATAN: `data` adalah pointer `NonNull` yang tentunya bukan null
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Menampilkan panjang potongan mentah bukan nol.
    ///
    /// Nilai yang dikembalikan adalah jumlah **elemen**, bukan jumlah byte.
    ///
    /// Fungsi ini aman, bahkan ketika potongan mentah bukan nol tidak dapat dirujuk ke potongan karena penunjuk tidak memiliki alamat yang valid.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Mengembalikan pointer non-null ke buffer slice.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // KEAMANAN: Kami tahu `self` bukan nol.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Mengembalikan pointer mentah ke buffer slice.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Menampilkan referensi bersama ke bagian dari nilai yang mungkin tidak diinisialisasi.Berbeda dengan [`as_ref`], ini tidak mengharuskan nilai harus diinisialisasi.
    ///
    /// Untuk mitra yang bisa berubah, lihat [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Saat memanggil metode ini, Anda harus memastikan bahwa semua hal berikut ini benar:
    ///
    /// * Penunjuk harus [valid] agar dapat dibaca `ptr.len() * mem::size_of::<T>()` banyak byte, dan harus disejajarkan dengan benar.Ini khususnya berarti:
    ///
    ///     * Seluruh rentang memori potongan ini harus berada dalam satu objek yang dialokasikan!
    ///       Irisan tidak pernah bisa menjangkau beberapa objek yang dialokasikan.
    ///
    ///     * Penunjuk harus sejajar bahkan untuk irisan panjang-nol.
    ///     Salah satu alasannya adalah bahwa pengoptimalan tata letak enum mungkin mengandalkan referensi (termasuk irisan dengan panjang berapa pun) yang diselaraskan dan bukan nol untuk membedakannya dari data lain.
    ///
    ///     Anda bisa mendapatkan penunjuk yang dapat digunakan sebagai `data` untuk irisan panjang-nol menggunakan [`NonNull::dangling()`].
    ///
    /// * Ukuran total `ptr.len() * mem::size_of::<T>()` potongan tidak boleh lebih dari `isize::MAX`.
    ///   Lihat dokumentasi keamanan [`pointer::offset`].
    ///
    /// * Anda harus menerapkan aturan aliasing Rust, karena masa pakai yang dikembalikan `'a` dipilih secara sewenang-wenang dan tidak selalu mencerminkan masa pakai data yang sebenarnya.
    ///   Secara khusus, selama durasi ini, memori yang ditunjuk penunjuk tidak boleh bermutasi (kecuali di dalam `UnsafeCell`).
    ///
    /// Ini berlaku bahkan jika hasil dari metode ini tidak digunakan!
    ///
    /// Lihat juga [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // KEAMANAN: penelepon harus memegang kontrak keamanan untuk `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Menampilkan referensi unik ke bagian dari nilai yang mungkin tidak diinisialisasi.Berbeda dengan [`as_mut`], ini tidak mengharuskan nilai harus diinisialisasi.
    ///
    /// Untuk mitra bersama, lihat [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Saat memanggil metode ini, Anda harus memastikan bahwa semua hal berikut ini benar:
    ///
    /// * Penunjuk harus [valid] untuk membaca dan menulis untuk `ptr.len() * mem::size_of::<T>()` banyak byte, dan harus disejajarkan dengan benar.Ini khususnya berarti:
    ///
    ///     * Seluruh rentang memori potongan ini harus berada dalam satu objek yang dialokasikan!
    ///       Irisan tidak pernah bisa menjangkau beberapa objek yang dialokasikan.
    ///
    ///     * Penunjuk harus sejajar bahkan untuk irisan panjang-nol.
    ///     Salah satu alasannya adalah bahwa pengoptimalan tata letak enum mungkin mengandalkan referensi (termasuk irisan dengan panjang berapa pun) yang diselaraskan dan bukan nol untuk membedakannya dari data lain.
    ///
    ///     Anda bisa mendapatkan penunjuk yang dapat digunakan sebagai `data` untuk irisan panjang-nol menggunakan [`NonNull::dangling()`].
    ///
    /// * Ukuran total `ptr.len() * mem::size_of::<T>()` potongan tidak boleh lebih dari `isize::MAX`.
    ///   Lihat dokumentasi keamanan [`pointer::offset`].
    ///
    /// * Anda harus menerapkan aturan aliasing Rust, karena masa pakai yang dikembalikan `'a` dipilih secara sewenang-wenang dan tidak selalu mencerminkan masa pakai data yang sebenarnya.
    ///   Secara khusus, selama masa ini, memori yang ditunjuk penunjuk tidak boleh diakses (dibaca atau ditulis) melalui penunjuk lain.
    ///
    /// Ini berlaku bahkan jika hasil dari metode ini tidak digunakan!
    ///
    /// Lihat juga [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Ini aman karena `memory` valid untuk membaca dan menulis untuk `memory.len()` banyak byte.
    /// // Perhatikan bahwa memanggil `memory.as_mut()` tidak diizinkan di sini karena konten mungkin belum diinisialisasi.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // KEAMANAN: penelepon harus memegang kontrak keamanan untuk `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Mengembalikan pointer mentah ke elemen atau subslice, tanpa melakukan pemeriksaan batas.
    ///
    /// Memanggil metode ini dengan indeks di luar batas atau saat `self` tidak dapat dideferensi adalah *[perilaku tidak ditentukan]* meskipun penunjuk yang dihasilkan tidak digunakan.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // KEAMANAN: penelepon memastikan bahwa `self` dapat dibedakan dan `index` dalam batas.
        // Akibatnya, pointer yang dihasilkan tidak boleh NULL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // KEAMANAN: Pointer unik tidak boleh null, jadi ketentuan untuk
        // new_unchecked() dihormati.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // KEAMANAN: Referensi yang bisa berubah tidak boleh kosong.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // KEAMANAN: Referensi tidak boleh nol, jadi ketentuan untuk
        // new_unchecked() dihormati.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}