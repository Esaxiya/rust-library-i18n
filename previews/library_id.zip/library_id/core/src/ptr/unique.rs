use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Pembungkus di sekitar `*mut T` non-null mentah yang menunjukkan bahwa pemilik pembungkus ini memiliki referensi.
/// Berguna untuk membuat abstraksi seperti `Box<T>`, `Vec<T>`, `String`, dan `HashMap<K, V>`.
///
/// Tidak seperti `*mut T`, `Unique<T>` berperilaku "as if" itu adalah turunan dari `T`.
/// Ini mengimplementasikan `Send`/`Sync` jika `T` adalah `Send`/`Sync`.
/// Ini juga menyiratkan jenis jaminan aliasing yang kuat yang dapat diharapkan oleh instance `T`:
/// rujukan penunjuk tidak boleh dimodifikasi tanpa jalur unik ke Unique miliknya.
///
/// Jika Anda tidak yakin apakah benar menggunakan `Unique` untuk tujuan Anda, pertimbangkan untuk menggunakan `NonNull`, yang memiliki semantik lebih lemah.
///
///
/// Tidak seperti `*mut T`, penunjuk harus selalu bukan nol, bahkan jika penunjuk tidak pernah dereferensi.
/// Ini agar enum dapat menggunakan nilai terlarang ini sebagai diskriminan-`Option<Unique<T>>` memiliki ukuran yang sama dengan `Unique<T>`.
/// Namun penunjuk mungkin masih menjuntai jika tidak dideferensiasi.
///
/// Tidak seperti `*mut T`, `Unique<T>` adalah kovarian atas `T`.
/// Ini harus selalu benar untuk semua jenis yang menjunjung tinggi persyaratan aliasing Unik.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: penanda ini tidak memiliki konsekuensi untuk varian, tetapi diperlukan
    // agar dropck memahami bahwa secara logis kita memiliki `T`.
    //
    // Untuk detailnya, lihat:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` pointer adalah `Send` jika `T` adalah `Send` karena data yang mereka referensikan tidak dipisahkan.
/// Perhatikan bahwa invarian aliasing ini tidak didukung oleh sistem tipe;abstraksi menggunakan `Unique` harus memaksakannya.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` pointer adalah `Sync` jika `T` adalah `Sync` karena data yang mereka referensikan tidak dipisahkan.
/// Perhatikan bahwa invarian aliasing ini tidak didukung oleh sistem tipe;abstraksi menggunakan `Unique` harus memaksakannya.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Membuat `Unique` baru yang menjuntai, tetapi sejajar.
    ///
    /// Ini berguna untuk menginisialisasi tipe yang dialokasikan dengan malas, seperti yang dilakukan `Vec::new`.
    ///
    /// Perhatikan bahwa nilai penunjuk berpotensi mewakili penunjuk yang valid ke `T`, yang berarti ini tidak boleh digunakan sebagai nilai sentinel "not yet initialized".
    /// Jenis yang dengan malas mengalokasikan harus melacak inisialisasi dengan cara lain.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // KEAMANAN: mem::align_of() mengembalikan pointer non-null yang valid.Itu
        // kondisi untuk memanggil new_unchecked() dengan demikian dihormati.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Membuat `Unique` baru.
    ///
    /// # Safety
    ///
    /// `ptr` harus bukan nol.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // KEAMANAN: penelepon harus menjamin bahwa `ptr` bukan null.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Membuat `Unique` baru jika `ptr` bukan nol.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // KEAMANAN: Pointer telah diperiksa dan bukan null.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Memperoleh penunjuk `*mut` yang mendasari.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Dereferensi konten.
    ///
    /// Seumur hidup yang dihasilkan terikat pada diri sendiri sehingga ini berperilaku "as if" itu sebenarnya adalah turunan dari T yang dipinjam.
    /// Jika masa pakai (unbound) lebih lama diperlukan, gunakan `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // KEAMANAN: penelepon harus menjamin bahwa `self` memenuhi semua
        // persyaratan untuk referensi.
        unsafe { &*self.as_ptr() }
    }

    /// Saling membedakan konten.
    ///
    /// Seumur hidup yang dihasilkan terikat pada diri sendiri sehingga ini berperilaku "as if" itu sebenarnya adalah turunan dari T yang dipinjam.
    /// Jika masa pakai (unbound) lebih lama diperlukan, gunakan `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // KEAMANAN: penelepon harus menjamin bahwa `self` memenuhi semua
        // persyaratan untuk referensi yang bisa berubah.
        unsafe { &mut *self.as_ptr() }
    }

    /// Mentransmisikan ke penunjuk jenis lain.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // KEAMANAN: Unique::new_unchecked() menciptakan keunikan dan kebutuhan baru
        // pointer yang diberikan tidak boleh null.
        // Karena kita memberikan self sebagai pointer, maka tidak boleh null.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // KEAMANAN: Referensi yang bisa berubah tidak boleh kosong
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}