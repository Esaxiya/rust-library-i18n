use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// Jenis pembungkus untuk membuat instance `T` yang tidak diinisialisasi.
///
/// # Inisialisasi invarian
///
/// Kompilator, secara umum, mengasumsikan bahwa variabel diinisialisasi dengan benar sesuai dengan persyaratan jenis variabel.Misalnya, variabel jenis referensi harus sejajar dan non-NULL.
/// Ini adalah invarian yang harus *selalu* ditegakkan, bahkan dalam kode yang tidak aman.
/// Akibatnya, inisialisasi nol variabel tipe referensi menyebabkan [undefined behavior][ub] seketika, tidak peduli apakah referensi tersebut pernah digunakan untuk mengakses memori:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // perilaku tidak terdefinisi!⚠️
/// // Kode yang setara dengan `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // perilaku tidak terdefinisi!⚠️
/// ```
///
/// Ini dimanfaatkan oleh kompiler untuk berbagai pengoptimalan, seperti mengeliminasi pemeriksaan waktu proses dan mengoptimalkan tata letak `enum`.
///
/// Demikian pula, memori yang sepenuhnya tidak diinisialisasi dapat memiliki konten apa pun, sedangkan `bool` harus selalu `true` atau `false`.Oleh karena itu, membuat `bool` yang tidak diinisialisasi adalah perilaku yang tidak ditentukan:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // perilaku tidak terdefinisi!⚠️
/// // Kode yang setara dengan `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // perilaku tidak terdefinisi!⚠️
/// ```
///
/// Selain itu, memori yang tidak diinisialisasi adalah khusus karena tidak memiliki nilai tetap ("fixed" berarti "it won't change without being written to").Membaca byte yang tidak diinisialisasi yang sama beberapa kali dapat memberikan hasil yang berbeda.
/// Ini membuat perilaku tidak terdefinisi untuk memiliki data yang tidak diinisialisasi dalam variabel meskipun variabel tersebut memiliki tipe integer, yang jika tidak dapat menahan pola bit *tetap* apa pun:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // perilaku tidak terdefinisi!⚠️
/// // Kode yang setara dengan `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // perilaku tidak terdefinisi!⚠️
/// ```
/// (Perhatikan bahwa aturan seputar bilangan bulat yang tidak diinisialisasi belum diselesaikan, tetapi hingga selesai, disarankan untuk menghindarinya.)
///
/// Di atas semua itu, ingatlah bahwa kebanyakan tipe memiliki invarian tambahan selain hanya dianggap diinisialisasi pada level tipe.
/// Misalnya, [`Vec<T>`] yang diinisialisasi `1` dianggap telah diinisialisasi (dalam implementasi saat ini; ini bukan merupakan jaminan stabil) karena satu-satunya persyaratan yang diketahui oleh compiler adalah bahwa penunjuk data harus bukan null.
/// Membuat `Vec<T>` seperti itu tidak menyebabkan perilaku *langsung* tidak terdefinisi, tetapi akan menyebabkan perilaku tidak terdefinisi dengan sebagian besar operasi aman (termasuk menjatuhkannya).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` berfungsi untuk mengaktifkan kode yang tidak aman untuk menangani data yang tidak diinisialisasi.
/// Ini adalah sinyal bagi compiler yang menunjukkan bahwa data di sini mungkin *tidak* akan diinisialisasi:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Buat referensi yang tidak diinisialisasi secara eksplisit.
/// // Kompilator mengetahui bahwa data di dalam `MaybeUninit<T>` mungkin tidak valid, dan karenanya ini bukan UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Setel ke nilai yang valid.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Ekstrak data yang diinisialisasi-ini hanya diperbolehkan *setelah* menginisialisasi `x` dengan benar!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Kompilator kemudian tahu untuk tidak membuat asumsi atau optimasi yang salah pada kode ini.
///
/// Anda dapat menganggap `MaybeUninit<T>` mirip dengan `Option<T>` tetapi tanpa pelacakan run-time apa pun dan tanpa pemeriksaan keamanan apa pun.
///
/// ## out-pointers
///
/// Anda dapat menggunakan `MaybeUninit<T>` untuk mengimplementasikan "out-pointers": alih-alih mengembalikan data dari suatu fungsi, teruskan penunjuk ke beberapa memori (uninitialized) untuk memasukkan hasilnya.
/// Ini bisa berguna ketika penting bagi pemanggil untuk mengontrol bagaimana memori hasil disimpan akan dialokasikan, dan Anda ingin menghindari perpindahan yang tidak perlu.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` tidak menjatuhkan konten lama, yang penting.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Sekarang kita tahu `v` diinisialisasi!Ini juga memastikan vector dijatuhkan dengan benar.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Menginisialisasi elemen array demi elemen
///
/// `MaybeUninit<T>` dapat digunakan untuk menginisialisasi array besar elemen demi elemen:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Buat array `MaybeUninit` yang tidak diinisialisasi.
///     // `assume_init` aman karena jenis yang kami klaim telah diinisialisasi di sini adalah sekumpulan `MaybeUninit`, yang tidak memerlukan inisialisasi.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Menjatuhkan `MaybeUninit` tidak berarti apa-apa.
///     // Jadi, menggunakan penugasan pointer mentah sebagai ganti `ptr::write` tidak menyebabkan nilai lama yang tidak diinisialisasi dihapus.
/////
///     // Juga jika ada panic selama perulangan ini, kami mengalami kebocoran memori, tetapi tidak ada masalah keamanan memori.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Semuanya diinisialisasi.
///     // Transmisikan array ke tipe yang diinisialisasi.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Anda juga dapat bekerja dengan array yang diinisialisasi sebagian, yang dapat ditemukan di struktur data tingkat rendah.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Buat array `MaybeUninit` yang tidak diinisialisasi.
/// // `assume_init` aman karena jenis yang kami klaim telah diinisialisasi di sini adalah sekumpulan `MaybeUninit`, yang tidak memerlukan inisialisasi.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Hitung jumlah elemen yang telah kami tetapkan.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Untuk setiap item dalam array, lepaskan jika kita mengalokasikannya.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Menginisialisasi struct bidang demi bidang
///
/// Anda dapat menggunakan `MaybeUninit<T>`, dan makro [`std::ptr::addr_of_mut`], untuk menginisialisasi struct bidang demi bidang:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Menginisialisasi bidang `name`
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Inisialisasi bidang `list` Jika ada panic di sini, maka `String` di bidang `name` bocor.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Semua bidang diinisialisasi, jadi kami memanggil `assume_init` untuk mendapatkan Foo yang diinisialisasi.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` dijamin memiliki ukuran, kesejajaran, dan ABI yang sama dengan `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Namun perlu diingat bahwa tipe *yang berisi*`MaybeUninit<T>` belum tentu memiliki tata letak yang sama;Rust secara umum tidak menjamin bahwa bidang `Foo<T>` memiliki urutan yang sama dengan `Foo<U>` meskipun `T` dan `U` memiliki ukuran dan kesejajaran yang sama.
///
/// Selain itu, karena nilai bit apa pun valid untuk `MaybeUninit<T>`, kompilator tidak dapat menerapkan pengoptimalan non-zero/niche-filling, yang berpotensi menghasilkan ukuran yang lebih besar:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Jika `T` aman untuk FFI, begitu pula `MaybeUninit<T>`.
///
/// Meskipun `MaybeUninit` adalah `#[repr(transparent)]` (menunjukkan bahwa `MaybeUninit` menjamin ukuran, penyelarasan, dan ABI yang sama dengan `T`), ini *tidak* mengubah peringatan sebelumnya.
/// `Option<T>` dan `Option<MaybeUninit<T>>` mungkin masih memiliki ukuran yang berbeda, dan tipe yang berisi bidang tipe `T` dapat ditata (dan ukurannya) berbeda dari jika bidang itu adalah `MaybeUninit<T>`.
/// `MaybeUninit` adalah tipe serikat pekerja, dan `#[repr(transparent)]` pada serikat pekerja tidak stabil (lihat [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Seiring waktu, jaminan pasti `#[repr(transparent)]` pada serikat pekerja dapat berkembang, dan `MaybeUninit` mungkin tetap atau tidak tetap `#[repr(transparent)]`.
/// Meskipun demikian, `MaybeUninit<T>` akan *selalu* menjamin bahwa ia memiliki ukuran, kesejajaran, dan ABI yang sama dengan `T`;hanya cara `MaybeUninit` mengimplementasikan jaminan yang dapat berkembang.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Item lang sehingga kita bisa membungkus jenis lain di dalamnya.Ini berguna untuk generator.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Tidak memanggil `T::clone()`, kami tidak dapat mengetahui apakah kami cukup diinisialisasi untuk itu.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Membuat `MaybeUninit<T>` baru yang diinisialisasi dengan nilai yang diberikan.
    /// Aman untuk memanggil [`assume_init`] dengan nilai hasil dari fungsi ini.
    ///
    /// Perhatikan bahwa menghapus `MaybeUninit<T>` tidak akan pernah memanggil kode drop `T`.
    /// Merupakan tanggung jawab Anda untuk memastikan `T` dijatuhkan jika diinisialisasi.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Membuat `MaybeUninit<T>` baru dalam keadaan tidak diinisialisasi.
    ///
    /// Perhatikan bahwa menghapus `MaybeUninit<T>` tidak akan pernah memanggil kode drop `T`.
    /// Merupakan tanggung jawab Anda untuk memastikan `T` dijatuhkan jika diinisialisasi.
    ///
    /// Lihat [type-level documentation][MaybeUninit] untuk beberapa contoh.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Buat larik baru dari item `MaybeUninit<T>`, dalam keadaan tidak diinisialisasi.
    ///
    /// Note: dalam versi future Rust metode ini mungkin menjadi tidak diperlukan ketika sintaks literal array memungkinkan [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// Contoh di bawah ini dapat menggunakan `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Mengembalikan sepotong (mungkin lebih kecil) data yang sebenarnya telah dibaca
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // KEAMANAN: `[MaybeUninit<_>; LEN]` yang tidak diinisialisasi valid.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Membuat `MaybeUninit<T>` baru dalam keadaan tidak diinisialisasi, dengan memori diisi dengan byte `0`.Itu tergantung pada `T` apakah itu sudah membuat inisialisasi yang tepat.
    ///
    /// Misalnya, `MaybeUninit<usize>::zeroed()` diinisialisasi, tetapi `MaybeUninit<&'static i32>::zeroed()` bukan karena referensi tidak boleh null.
    ///
    /// Perhatikan bahwa menghapus `MaybeUninit<T>` tidak akan pernah memanggil kode drop `T`.
    /// Merupakan tanggung jawab Anda untuk memastikan `T` dijatuhkan jika diinisialisasi.
    ///
    /// # Example
    ///
    /// Penggunaan yang benar dari fungsi ini: menginisialisasi struct dengan nol, di mana semua bidang dari struct dapat menampung pola-bit 0 sebagai nilai yang valid.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Salah* penggunaan fungsi ini: memanggil `x.zeroed().assume_init()` saat `0` bukan pola bit yang valid untuk jenis:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Di dalam pasangan, kami membuat `NotZero` yang tidak memiliki diskriminan yang valid.
    /// // Ini adalah perilaku yang tidak terdefinisi.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // KEAMANAN: `u.as_mut_ptr()` menunjuk ke memori yang dialokasikan.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Setel nilai `MaybeUninit<T>`.
    /// Ini menimpa nilai sebelumnya tanpa menjatuhkannya, jadi berhati-hatilah untuk tidak menggunakan ini dua kali kecuali Anda ingin melewatkan menjalankan destruktor.
    ///
    /// Demi kenyamanan Anda, ini juga mengembalikan referensi yang bisa berubah ke konten `self` (sekarang diinisialisasi dengan aman).
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // KEAMANAN: Kami baru saja menginisialisasi nilai ini.
        unsafe { self.assume_init_mut() }
    }

    /// Mendapat penunjuk ke nilai yang terkandung.
    /// Membaca dari penunjuk ini atau mengubahnya menjadi referensi adalah perilaku yang tidak ditentukan kecuali `MaybeUninit<T>` diinisialisasi.
    /// Menulis ke memori yang ditunjuk oleh penunjuk (non-transitively) ini adalah perilaku tidak terdefinisi (kecuali di dalam `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Penggunaan yang benar dari metode ini:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Buat referensi ke `MaybeUninit<T>`.Ini tidak apa-apa karena kami memulainya.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *Salah* penggunaan metode ini:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Kami telah membuat referensi ke vector yang tidak diinisialisasi!Ini adalah perilaku yang tidak terdefinisi.⚠️
    /// ```
    ///
    /// (Perhatikan bahwa aturan seputar referensi ke data yang tidak diinisialisasi belum diselesaikan, tetapi hingga selesai, disarankan untuk menghindarinya.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` dan `ManuallyDrop` sama-sama `repr(transparent)` sehingga kita dapat menggunakan penunjuk.
        self as *const _ as *const T
    }

    /// Mendapat penunjuk yang bisa berubah ke nilai yang ada.
    /// Membaca dari penunjuk ini atau mengubahnya menjadi referensi adalah perilaku yang tidak ditentukan kecuali `MaybeUninit<T>` diinisialisasi.
    ///
    /// # Examples
    ///
    /// Penggunaan yang benar dari metode ini:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Buat referensi ke `MaybeUninit<Vec<u32>>`.
    /// // Ini tidak apa-apa karena kami memulainya.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *Salah* penggunaan metode ini:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Kami telah membuat referensi ke vector yang tidak diinisialisasi!Ini adalah perilaku yang tidak terdefinisi.⚠️
    /// ```
    ///
    /// (Perhatikan bahwa aturan seputar referensi ke data yang tidak diinisialisasi belum diselesaikan, tetapi hingga selesai, disarankan untuk menghindarinya.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` dan `ManuallyDrop` sama-sama `repr(transparent)` sehingga kita dapat menggunakan penunjuk.
        self as *mut _ as *mut T
    }

    /// Mengekstrak nilai dari penampung `MaybeUninit<T>`.Ini adalah cara yang bagus untuk memastikan bahwa data akan dihapus, karena `T` yang dihasilkan tunduk pada penanganan penurunan yang biasa.
    ///
    /// # Safety
    ///
    /// Terserah pemanggil untuk menjamin bahwa `MaybeUninit<T>` benar-benar dalam keadaan diinisialisasi.Memanggil ini ketika konten belum sepenuhnya diinisialisasi menyebabkan perilaku tidak terdefinisi langsung.
    /// [type-level documentation][inv] berisi lebih banyak informasi tentang invarian inisialisasi ini.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Di atas semua itu, ingatlah bahwa kebanyakan tipe memiliki invarian tambahan selain hanya dianggap diinisialisasi pada level tipe.
    /// Misalnya, [`Vec<T>`] yang diinisialisasi `1` dianggap telah diinisialisasi (dalam implementasi saat ini; ini bukan merupakan jaminan stabil) karena satu-satunya persyaratan yang diketahui oleh compiler adalah bahwa penunjuk data harus bukan null.
    ///
    /// Membuat `Vec<T>` seperti itu tidak menyebabkan perilaku *langsung* tidak terdefinisi, tetapi akan menyebabkan perilaku tidak terdefinisi dengan sebagian besar operasi aman (termasuk menjatuhkannya).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Penggunaan yang benar dari metode ini:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *Salah* penggunaan metode ini:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` belum diinisialisasi, jadi baris terakhir ini menyebabkan perilaku tidak terdefinisi.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // KEAMANAN: penelepon harus menjamin bahwa `self` telah diinisialisasi.
        // Ini juga berarti bahwa `self` harus merupakan varian `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Membaca nilai dari penampung `MaybeUninit<T>`.`T` yang dihasilkan tunduk pada penanganan jatuh biasa.
    ///
    /// Jika memungkinkan, lebih baik menggunakan [`assume_init`] sebagai gantinya, yang mencegah duplikasi konten `MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// Terserah pemanggil untuk menjamin bahwa `MaybeUninit<T>` benar-benar dalam keadaan diinisialisasi.Memanggil ini ketika konten belum sepenuhnya diinisialisasi menyebabkan perilaku tidak terdefinisi.
    /// [type-level documentation][inv] berisi lebih banyak informasi tentang invarian inisialisasi ini.
    ///
    /// Selain itu, ini meninggalkan salinan data yang sama di `MaybeUninit<T>`.
    /// Saat menggunakan banyak salinan data (dengan memanggil `assume_init_read` beberapa kali, atau pertama memanggil `assume_init_read` lalu [`assume_init`]), Anda bertanggung jawab untuk memastikan bahwa data memang bisa digandakan.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Penggunaan yang benar dari metode ini:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` adalah `Copy`, jadi kami mungkin membacanya berkali-kali.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Menduplikasi nilai `None` tidak apa-apa, jadi kita mungkin membacanya berkali-kali.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *Salah* penggunaan metode ini:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Kami sekarang membuat dua salinan dari vector yang sama, yang mengarah ke bebas ganda ⚠️ saat keduanya dijatuhkan!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // KEAMANAN: penelepon harus menjamin bahwa `self` telah diinisialisasi.
        // Membaca dari `self.as_ptr()` aman karena `self` harus diinisialisasi.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Menjatuhkan nilai yang terkandung di tempatnya.
    ///
    /// Jika Anda memiliki kepemilikan `MaybeUninit`, Anda dapat menggunakan [`assume_init`] sebagai gantinya.
    ///
    /// # Safety
    ///
    /// Terserah pemanggil untuk menjamin bahwa `MaybeUninit<T>` benar-benar dalam keadaan diinisialisasi.Memanggil ini ketika konten belum sepenuhnya diinisialisasi menyebabkan perilaku tidak terdefinisi.
    ///
    /// Selain itu, semua invarian tambahan dari tipe `T` harus dipenuhi, karena implementasi `Drop` dari `T` (atau anggotanya) mungkin mengandalkan ini.
    /// Misalnya, [`Vec<T>`] yang diinisialisasi `1` dianggap telah diinisialisasi (dalam implementasi saat ini; ini bukan merupakan jaminan stabil) karena satu-satunya persyaratan yang diketahui oleh compiler adalah bahwa penunjuk data harus bukan null.
    ///
    /// Namun, menjatuhkan `Vec<T>` seperti itu akan menyebabkan perilaku tidak terdefinisi.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // KEAMANAN: penelepon harus menjamin bahwa `self` telah diinisialisasi dan
        // memenuhi semua invarian `T`.
        // Menjatuhkan nilai pada tempatnya aman jika memang demikian.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Mendapat referensi bersama ke nilai yang terkandung.
    ///
    /// Ini dapat berguna ketika kita ingin mengakses `MaybeUninit` yang telah diinisialisasi tetapi tidak memiliki kepemilikan `MaybeUninit` (mencegah penggunaan `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Memanggil ini ketika konten belum sepenuhnya diinisialisasi menyebabkan perilaku tidak terdefinisi: terserah pemanggil untuk menjamin bahwa `MaybeUninit<T>` benar-benar dalam keadaan diinisialisasi.
    ///
    ///
    /// # Examples
    ///
    /// ### Penggunaan yang benar dari metode ini:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Inisialisasi `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Sekarang `MaybeUninit<_>` kami diketahui telah diinisialisasi, tidak apa-apa untuk membuat referensi bersama untuk itu:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // KEAMANAN: `x` telah diinisialisasi.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *Salah* penggunaan metode ini:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Kami telah membuat referensi ke vector yang tidak diinisialisasi!Ini adalah perilaku yang tidak terdefinisi.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Inisialisasi `MaybeUninit` menggunakan `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Referensi ke `Cell<bool>` yang tidak diinisialisasi: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // KEAMANAN: penelepon harus menjamin bahwa `self` telah diinisialisasi.
        // Ini juga berarti bahwa `self` harus merupakan varian `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Mendapat referensi (unique) yang bisa berubah ke nilai yang terkandung.
    ///
    /// Ini dapat berguna ketika kita ingin mengakses `MaybeUninit` yang telah diinisialisasi tetapi tidak memiliki kepemilikan `MaybeUninit` (mencegah penggunaan `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Memanggil ini ketika konten belum sepenuhnya diinisialisasi menyebabkan perilaku tidak terdefinisi: terserah pemanggil untuk menjamin bahwa `MaybeUninit<T>` benar-benar dalam keadaan diinisialisasi.
    /// Misalnya, `.assume_init_mut()` tidak dapat digunakan untuk menginisialisasi `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### Penggunaan yang benar dari metode ini:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Menginisialisasi *semua* byte dari buffer input.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Inisialisasi `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Sekarang kita tahu bahwa `buf` telah diinisialisasi, jadi kita bisa `.assume_init()`-nya.
    /// // Namun, menggunakan `.assume_init()` dapat memicu `memcpy` dari 2048 byte.
    /// // Untuk menegaskan buffer kami telah diinisialisasi tanpa menyalinnya, kami meningkatkan `&mut MaybeUninit<[u8; 2048]>` ke `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // KEAMANAN: `buf` telah diinisialisasi.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Sekarang kita dapat menggunakan `buf` sebagai potongan normal:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *Salah* penggunaan metode ini:
    ///
    /// Anda tidak dapat menggunakan `.assume_init_mut()` untuk menginisialisasi nilai:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Kami telah membuat referensi (mutable) ke `bool` yang tidak diinisialisasi!
    ///     // Ini adalah perilaku yang tidak terdefinisi.⚠️
    /// }
    /// ```
    ///
    /// Misalnya, Anda tidak dapat melakukan [`Read`] ke buffer yang tidak diinisialisasi:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) referensi ke memori yang tidak diinisialisasi!
    ///                             // Ini adalah perilaku yang tidak terdefinisi.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Anda juga tidak dapat menggunakan akses lapangan langsung untuk melakukan inisialisasi bertahap bidang demi bidang:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) referensi ke memori yang tidak diinisialisasi!
    ///                  // Ini adalah perilaku yang tidak terdefinisi.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) referensi ke memori yang tidak diinisialisasi!
    ///                  // Ini adalah perilaku yang tidak terdefinisi.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Saat ini kami mengandalkan kesalahan di atas, yaitu, kami memiliki referensi ke data yang tidak diinisialisasi (misalnya, dalam `libcore/fmt/float.rs`).
    // Kita harus membuat keputusan akhir tentang aturan sebelum stabilisasi.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // KEAMANAN: penelepon harus menjamin bahwa `self` telah diinisialisasi.
        // Ini juga berarti bahwa `self` harus merupakan varian `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Mengekstrak nilai dari larik penampung `MaybeUninit`.
    ///
    /// # Safety
    ///
    /// Terserah pemanggil untuk menjamin bahwa semua elemen array berada dalam keadaan diinisialisasi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // KEAMANAN: Sekarang aman karena kami menginisialisasi semua elemen
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Pemanggil menjamin bahwa semua elemen array diinisialisasi
        // * `MaybeUninit<T>` dan T dijamin memiliki tata letak yang sama
        // * MaybeUnint tidak turun, jadi tidak ada kebebasan ganda Dan dengan demikian konversi aman
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Dengan asumsi semua elemen diinisialisasi, dapatkan potongan untuk mereka.
    ///
    /// # Safety
    ///
    /// Terserah pemanggil untuk menjamin bahwa elemen `MaybeUninit<T>` benar-benar dalam keadaan diinisialisasi.
    ///
    /// Memanggil ini ketika konten belum sepenuhnya diinisialisasi menyebabkan perilaku tidak terdefinisi.
    ///
    /// Lihat [`assume_init_ref`] untuk detail dan contoh selengkapnya.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // KEAMANAN: casting slice ke `*const [T]` aman karena pemanggil menjaminnya
        // `slice` diinisialisasi, dan`MaybeUninit` dijamin memiliki tata letak yang sama seperti `T`.
        // Pointer yang diperoleh valid karena mengacu pada memori yang dimiliki oleh `slice` yang merupakan referensi dan dengan demikian dijamin valid untuk dibaca.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Dengan asumsi semua elemen diinisialisasi, dapatkan potongan yang bisa berubah untuk mereka.
    ///
    /// # Safety
    ///
    /// Terserah pemanggil untuk menjamin bahwa elemen `MaybeUninit<T>` benar-benar dalam keadaan diinisialisasi.
    ///
    /// Memanggil ini ketika konten belum sepenuhnya diinisialisasi menyebabkan perilaku tidak terdefinisi.
    ///
    /// Lihat [`assume_init_mut`] untuk detail dan contoh selengkapnya.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // SAFETY: mirip dengan catatan keselamatan untuk `slice_get_ref`, tetapi kami memiliki file
        // referensi yang bisa berubah yang juga dijamin valid untuk penulisan.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Mendapat pointer ke elemen pertama dari array.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Mendapat pointer yang bisa berubah ke elemen pertama dari array.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Menyalin elemen dari `src` ke `this`, mengembalikan referensi yang bisa berubah ke konten `this` yang sekarang diinitalisasi.
    ///
    /// Jika `T` tidak mengimplementasikan `Copy`, gunakan [`write_slice_cloned`]
    ///
    /// Ini mirip dengan [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Fungsi ini akan menjadi panic jika kedua irisan memiliki panjang yang berbeda.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // KESELAMATAN: kami baru saja menyalin semua elemen len ke dalam kapasitas cadangan
    /// // elemen src.len() pertama dari vec sudah valid sekarang.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // KEAMANAN: &[T] dan&[MaybeUninit<T>] memiliki tata letak yang sama
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // KEAMANAN: Elemen yang valid baru saja disalin ke `this` sehingga initalized
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Menggandakan elemen dari `src` ke `this`, mengembalikan referensi yang bisa berubah ke konten `this` yang sekarang diinitalisasi.
    /// Semua elemen yang sudah diinitalisasi tidak akan dihapus.
    ///
    /// Jika `T` mengimplementasikan `Copy`, gunakan [`write_slice`]
    ///
    /// Ini mirip dengan [`slice::clone_from_slice`] tetapi tidak menjatuhkan elemen yang ada.
    ///
    /// # Panics
    ///
    /// Fungsi ini akan panic jika dua irisan memiliki panjang yang berbeda, atau jika implementasi `Clone` panics.
    ///
    /// Jika ada panic, elemen yang sudah digandakan akan dihapus.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // KEAMANAN: kami baru saja mengkloning semua elemen len ke dalam kapasitas cadangan
    /// // elemen src.len() pertama dari vec sudah valid sekarang.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // tidak seperti copy_from_slice ini tidak memanggil clone_from_slice pada slice ini karena `MaybeUninit<T: Clone>` tidak mengimplementasikan Clone.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // KEAMANAN: potongan mentah ini hanya akan berisi objek yang diinisialisasi
                // itulah mengapa, diperbolehkan untuk menjatuhkannya.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Kita perlu secara eksplisit mengirisnya dengan panjang yang sama
        // untuk pemeriksaan batas yang akan dihilangkan, dan pengoptimal akan menghasilkan memcpy untuk kasus sederhana (misalnya T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // diperlukan penjagaan b/c panic mungkin terjadi selama klon
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // KESELAMATAN: Elemen yang valid baru saja ditulis ke `this` sehingga diinitalisasi
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}