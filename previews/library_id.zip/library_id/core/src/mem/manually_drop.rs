use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Sebuah pembungkus untuk mencegah kompilator memanggil destruktor `T` secara otomatis.
/// Pembungkus ini 0 biaya.
///
/// `ManuallyDrop<T>` tunduk pada pengoptimalan tata letak yang sama seperti `T`.
/// Akibatnya, ia *tidak berpengaruh* pada asumsi yang dibuat kompilator tentang isinya.
/// Misalnya, menginisialisasi `ManuallyDrop<&mut T>` dengan [`mem::zeroed`] adalah perilaku yang tidak ditentukan.
/// Jika Anda perlu menangani data yang tidak diinisialisasi, gunakan [`MaybeUninit<T>`] sebagai gantinya.
///
/// Perhatikan bahwa mengakses nilai di dalam `ManuallyDrop<T>` aman.
/// Ini berarti bahwa `ManuallyDrop<T>` yang kontennya telah dihapus tidak boleh diekspos melalui API yang aman bagi publik.
/// Sejalan dengan itu, `ManuallyDrop::drop` tidak aman.
///
/// # `ManuallyDrop` dan taruh pesanan.
///
/// Rust memiliki nilai [drop order] yang terdefinisi dengan baik.
/// Untuk memastikan bahwa kolom atau lokal diletakkan dalam urutan tertentu, susun ulang deklarasi tersebut sehingga urutan penurunan implisit adalah yang benar.
///
/// Anda dapat menggunakan `ManuallyDrop` untuk mengontrol urutan pelepasan, tetapi ini memerlukan kode yang tidak aman dan sulit dilakukan dengan benar jika ada pembatalan.
///
///
/// Misalnya, jika Anda ingin memastikan bahwa bidang tertentu dihapus setelah yang lain, jadikan itu bidang terakhir dari sebuah struct:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` akan dihapus setelah `children`.
///     // Rust menjamin bahwa kolom dihapus dalam urutan deklarasi.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Bungkus nilai untuk dijatuhkan secara manual.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Anda masih dapat mengoperasikan nilainya dengan aman
    /// assert_eq!(*x, "Hello");
    /// // Tapi `Drop` tidak akan dijalankan di sini
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Mengekstrak nilai dari penampung `ManuallyDrop`.
    ///
    /// Ini memungkinkan nilai dijatuhkan lagi.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Ini menjatuhkan `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Mengambil nilai dari penampung `ManuallyDrop<T>`.
    ///
    /// Metode ini terutama ditujukan untuk memindahkan nilai dalam penurunan.
    /// Alih-alih menggunakan [`ManuallyDrop::drop`] untuk menjatuhkan nilai secara manual, Anda dapat menggunakan metode ini untuk mengambil nilai dan menggunakannya sesuka hati.
    ///
    /// Jika memungkinkan, lebih baik menggunakan [`into_inner`][`ManuallyDrop::into_inner`] sebagai gantinya, yang mencegah duplikasi konten `ManuallyDrop<T>`.
    ///
    ///
    /// # Safety
    ///
    /// Fungsi ini secara semantik mengeluarkan nilai yang terkandung tanpa mencegah penggunaan lebih lanjut, membiarkan status penampung ini tidak berubah.
    /// Merupakan tanggung jawab Anda untuk memastikan bahwa `ManuallyDrop` ini tidak digunakan lagi.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // KEAMANAN: kami membaca dari referensi, yang dijamin
        // agar valid untuk dibaca.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Jatuhkan nilai yang terkandung secara manual.Ini persis sama dengan memanggil [`ptr::drop_in_place`] dengan penunjuk ke nilai yang terkandung.
    /// Dengan demikian, kecuali nilai yang terkandung adalah struct yang dikemas, destruktor akan dipanggil di tempat tanpa memindahkan nilai, dan dengan demikian dapat digunakan untuk menjatuhkan data [pinned] dengan aman.
    ///
    /// Jika Anda memiliki kepemilikan atas nilai tersebut, Anda dapat menggunakan [`ManuallyDrop::into_inner`] sebagai gantinya.
    ///
    /// # Safety
    ///
    /// Fungsi ini menjalankan destruktor dari nilai yang terkandung.
    /// Selain perubahan yang dibuat oleh destruktor itu sendiri, memori dibiarkan tidak berubah, dan sejauh menyangkut kompilator masih memegang pola bit yang valid untuk tipe `T`.
    ///
    ///
    /// Namun, nilai "zombie" ini tidak boleh diekspos ke kode aman, dan fungsi ini tidak boleh dipanggil lebih dari sekali.
    /// Untuk menggunakan nilai setelah dijatuhkan, atau menjatuhkan nilai beberapa kali, dapat menyebabkan Perilaku Tidak Terdefinisi (tergantung pada apa yang dilakukan `drop`).
    /// Ini biasanya dicegah oleh sistem tipe, tetapi pengguna `ManuallyDrop` harus memegang jaminan tersebut tanpa bantuan dari kompilator.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // KEAMANAN: kami menjatuhkan nilai yang ditunjukkan oleh referensi yang bisa berubah
        // yang dijamin valid untuk penulisan.
        // Terserah pemanggil untuk memastikan bahwa `slot` tidak terputus lagi.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}