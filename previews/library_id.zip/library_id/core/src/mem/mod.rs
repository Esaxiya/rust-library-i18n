//! Fungsi dasar untuk menangani memori.
//!
//! Modul ini berisi fungsi untuk menanyakan ukuran dan penyelarasan tipe, menginisialisasi dan memanipulasi memori.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Mengambil kepemilikan dan "forgets" tentang nilai **tanpa menjalankan destruktornya**.
///
/// Sumber daya apa pun yang dikelola oleh nilai, seperti memori heap atau pegangan file, akan bertahan selamanya dalam keadaan tidak dapat dijangkau.Namun, itu tidak menjamin bahwa penunjuk ke memori ini akan tetap valid.
///
/// * Jika Anda ingin membocorkan memori, lihat [`Box::leak`].
/// * Jika Anda ingin mendapatkan penunjuk mentah ke memori, lihat [`Box::into_raw`].
/// * Jika Anda ingin membuang nilai dengan benar, menjalankan destruktornya, lihat [`mem::drop`].
///
/// # Safety
///
/// `forget` tidak ditandai sebagai `unsafe`, karena jaminan keamanan Rust tidak termasuk jaminan bahwa penghancur akan selalu berjalan.
/// Misalnya, program dapat membuat siklus referensi menggunakan [`Rc`][rc], atau memanggil [`process::exit`][exit] untuk keluar tanpa menjalankan destruktor.
/// Jadi, mengizinkan `mem::forget` dari kode aman tidak secara mendasar mengubah jaminan keamanan Rust.
///
/// Meskipun demikian, sumber daya yang bocor seperti memori atau objek I/O biasanya tidak diinginkan.
/// Kebutuhan muncul dalam beberapa kasus penggunaan khusus untuk FFI atau kode tidak aman, tetapi meskipun demikian, [`ManuallyDrop`] biasanya lebih disukai.
///
/// Karena melupakan nilai diperbolehkan, kode `unsafe` apa pun yang Anda tulis harus memungkinkan kemungkinan ini.Anda tidak dapat mengembalikan nilai dan berharap pemanggil akan menjalankan destruktor nilai tersebut.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// Penggunaan aman kanonis `mem::forget` adalah untuk menghindari destruktor nilai yang diterapkan oleh `Drop` trait.Misalnya, ini akan membocorkan `File`, yaitu
/// merebut kembali ruang yang diambil oleh variabel tetapi tidak pernah menutup sumber daya sistem yang mendasarinya:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Ini berguna saat kepemilikan resource yang mendasari sebelumnya ditransfer ke kode di luar Rust, misalnya dengan mengirimkan deskriptor file mentah ke kode C.
///
/// # Hubungan dengan `ManuallyDrop`
///
/// Meskipun `mem::forget` juga dapat digunakan untuk mentransfer kepemilikan *memori*, hal itu rawan kesalahan.
/// [`ManuallyDrop`] harus digunakan sebagai gantinya.Pertimbangkan, misalnya, kode ini:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Buat `String` menggunakan konten `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // membocorkan `v` karena memorinya sekarang dikelola oleh `s`
/// mem::forget(v);  // ERROR, v tidak valid dan tidak boleh diteruskan ke suatu fungsi
/// assert_eq!(s, "Az");
/// // `s` secara implisit dijatuhkan dan memorinya dibatalkan alokasinya.
/// ```
///
/// Ada dua masalah dengan contoh di atas:
///
/// * Jika lebih banyak kode ditambahkan antara konstruksi `String` dan pemanggilan `mem::forget()`, panic di dalamnya akan menyebabkan bebas ganda karena memori yang sama ditangani oleh `v` dan `s`.
/// * Setelah memanggil `v.as_mut_ptr()` dan mengirimkan kepemilikan data ke `s`, nilai `v` tidak valid.
/// Meskipun nilai baru saja dipindahkan ke `mem::forget` (yang tidak akan memeriksanya), beberapa jenis memiliki persyaratan ketat pada nilainya yang membuatnya tidak valid saat menggantung atau tidak lagi dimiliki.
/// Menggunakan nilai yang tidak valid dengan cara apa pun, termasuk meneruskannya ke atau mengembalikannya dari fungsi, merupakan perilaku tidak terdefinisi dan dapat merusak asumsi yang dibuat oleh compiler.
///
/// Beralih ke `ManuallyDrop` menghindari kedua masalah tersebut:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Sebelum kita membongkar `v` menjadi bagian aslinya, pastikan tidak terjatuh!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Sekarang bongkar `v`.Operasi ini tidak bisa panic, jadi tidak mungkin ada kebocoran.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Terakhir, buat `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` secara implisit dijatuhkan dan memorinya dibatalkan alokasinya.
/// ```
///
/// `ManuallyDrop` dengan kuat mencegah bebas ganda karena kita menonaktifkan destruktor `v` sebelum melakukan hal lain.
/// `mem::forget()` tidak mengizinkan ini karena menggunakan argumennya, memaksa kita untuk memanggilnya hanya setelah mengekstrak apapun yang kita butuhkan dari `v`.
/// Bahkan jika panic diperkenalkan antara konstruksi `ManuallyDrop` dan membangun string (yang tidak dapat terjadi dalam kode seperti yang ditunjukkan), itu akan mengakibatkan kebocoran dan bukan double free.
/// Dengan kata lain, `ManuallyDrop` melakukan kesalahan di sisi bocor, bukannya kesalahan di sisi (dua kali lipat) jatuh.
///
/// Selain itu, `ManuallyDrop` mencegah kita dari keharusan ke "touch" `v` setelah mentransfer kepemilikan ke `s`-langkah terakhir dari berinteraksi dengan `v` untuk membuangnya tanpa menjalankan destruktornya sepenuhnya dihindari.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Seperti [`forget`], tetapi juga menerima nilai yang tidak berukuran besar.
///
/// Fungsi ini hanyalah ganjalan yang dimaksudkan untuk dihilangkan saat fitur `unsized_locals` distabilkan.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Mengembalikan ukuran tipe dalam byte.
///
/// Lebih khusus lagi, ini adalah offset dalam byte antara elemen-elemen yang berurutan dalam sebuah array dengan tipe item tersebut termasuk padding keselarasan.
///
/// Jadi, untuk setiap tipe `T` dan panjang `n`, `[T; n]` memiliki ukuran `n * size_of::<T>()`.
///
/// Secara umum, ukuran suatu tipe tidak stabil di seluruh kompilasi, tetapi tipe tertentu seperti primitif.
///
/// Tabel berikut memberikan ukuran untuk primitif.
///
/// Ketik |ukuran dari: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 karakter |4
///
/// Selanjutnya `usize` dan `isize` memiliki ukuran yang sama.
///
/// Tipe `*const T`, `&T`, `Box<T>`, `Option<&T>`, dan `Option<Box<T>>` semuanya memiliki ukuran yang sama.
/// Jika `T` Berukuran, semua tipe tersebut memiliki ukuran yang sama dengan `usize`.
///
/// Perubahan pointer tidak mengubah ukurannya.Dengan demikian, `&T` dan `&mut T` memiliki ukuran yang sama.
/// Begitu juga untuk `*const T` dan `* mut T`.
///
/// # Ukuran item `#[repr(C)]`
///
/// Representasi `C` untuk item memiliki tata letak yang ditentukan.
/// Dengan tata letak ini, ukuran item juga stabil selama semua kolom memiliki ukuran yang stabil.
///
/// ## Ukuran Struktur
///
/// Untuk `structs`, ukurannya ditentukan oleh algoritma berikut.
///
/// Untuk setiap bidang di struct yang diurutkan berdasarkan urutan deklarasi:
///
/// 1. Tambahkan ukuran bidang.
/// 2. Bulatkan ukuran saat ini ke kelipatan terdekat dari [alignment] bidang berikutnya.
///
/// Terakhir, bulatkan ukuran struct ke kelipatan [alignment] yang terdekat.
/// Penjajaran struct biasanya merupakan penjajaran terbesar dari semua bidangnya;ini dapat diubah dengan menggunakan `repr(align(N))`.
///
/// Tidak seperti `C`, struct berukuran nol tidak dibulatkan menjadi satu byte.
///
/// ## Ukuran Enum
///
/// Enum yang tidak membawa data selain diskriminan memiliki ukuran yang sama dengan enum C pada platform tempat mereka dikompilasi.
///
/// ## Ukuran Serikat Pekerja
///
/// Ukuran persatuan adalah ukuran bidang terbesarnya.
///
/// Tidak seperti `C`, serikat berukuran nol tidak dibulatkan menjadi satu byte.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Beberapa primitif
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Beberapa array
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Kesamaan ukuran pointer
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Menggunakan `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Ukuran kolom pertama adalah 1, jadi tambahkan 1 ke ukurannya.Ukurannya 1.
/// // Perataan bidang kedua adalah 2, jadi tambahkan 1 ke ukuran bantalan.Ukurannya 2.
/// // Ukuran kolom kedua adalah 2, jadi tambahkan 2 ke ukurannya.Ukurannya 4.
/// // Perataan bidang ketiga adalah 1, jadi tambahkan 0 ke ukuran padding.Ukurannya 4.
/// // Ukuran bidang ketiga adalah 1, jadi tambahkan 1 ke ukurannya.Ukurannya 5.
/// // Terakhir, perataan struct adalah 2 (karena perataan terbesar di antara bidangnya adalah 2), jadi tambahkan 1 ke ukuran padding.
/// // Ukurannya 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Tuple struct mengikuti aturan yang sama.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Perhatikan bahwa menata ulang bidang dapat menurunkan ukuran.
/// // Kita dapat menghapus kedua byte padding dengan meletakkan `third` sebelum `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Ukuran serikat adalah ukuran bidang terbesar.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Mengembalikan ukuran nilai yang diarahkan ke dalam byte.
///
/// Ini biasanya sama dengan `size_of::<T>()`.
/// Namun, jika `T`*tidak memiliki* ukuran yang diketahui secara statis, misalnya, potongan [`[T]`][slice] atau [trait object], maka `size_of_val` dapat digunakan untuk mendapatkan ukuran yang diketahui secara dinamis.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // SAFETY: `val` adalah referensi, jadi ini adalah penunjuk mentah yang valid
    unsafe { intrinsics::size_of_val(val) }
}

/// Mengembalikan ukuran nilai yang diarahkan ke dalam byte.
///
/// Ini biasanya sama dengan `size_of::<T>()`.Namun, jika `T`*tidak memiliki* ukuran yang diketahui secara statis, misalnya, potongan [`[T]`][slice] atau [trait object], maka `size_of_val_raw` dapat digunakan untuk mendapatkan ukuran yang diketahui secara dinamis.
///
/// # Safety
///
/// Fungsi ini hanya aman untuk dipanggil jika kondisi berikut berlaku:
///
/// - Jika `T` adalah `Sized`, fungsi ini selalu aman untuk dipanggil.
/// - Jika ekor `T` berukuran besar adalah:
///     - a [slice], maka panjang ekor irisan harus berupa bilangan bulat yang diinisialisasi, dan ukuran *nilai keseluruhan*(panjang ekor dinamis + awalan berukuran statis) harus sesuai dengan `isize`.
///     - a [trait object], maka bagian vtable dari pointer harus menunjuk ke vtable valid yang diperoleh dengan paksaan unsizing, dan ukuran *seluruh nilai*(panjang ekor dinamis + prefiks berukuran statis) harus sesuai dengan `isize`.
///
///     - sebuah (unstable) [extern type], maka fungsi ini selalu aman untuk dipanggil, tetapi mungkin panic atau sebaliknya mengembalikan nilai yang salah, karena tata letak tipe eksternal tidak diketahui.
///     Ini adalah perilaku yang sama seperti [`size_of_val`] pada referensi ke tipe dengan ekor tipe eksternal.
///     - jika tidak, secara konservatif tidak diperbolehkan untuk memanggil fungsi ini.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // KEAMANAN: pemanggil harus memberikan pointer mentah yang valid
    unsafe { intrinsics::size_of_val(val) }
}

/// Mengembalikan perataan minimum yang diperlukan [ABI] untuk suatu jenis.
///
/// Setiap referensi ke nilai tipe `T` harus kelipatan dari angka ini.
///
/// Ini adalah perataan yang digunakan untuk bidang struct.Ini mungkin lebih kecil dari perataan yang disukai.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Mengembalikan perataan minimum yang diperlukan [ABI] dari jenis nilai yang ditunjuk `val`.
///
/// Setiap referensi ke nilai tipe `T` harus kelipatan dari angka ini.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // SAFETY: val adalah referensi, jadi ini adalah pointer mentah yang valid
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Mengembalikan perataan minimum yang diperlukan [ABI] untuk suatu jenis.
///
/// Setiap referensi ke nilai tipe `T` harus kelipatan dari angka ini.
///
/// Ini adalah perataan yang digunakan untuk bidang struct.Ini mungkin lebih kecil dari perataan yang disukai.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Mengembalikan perataan minimum yang diperlukan [ABI] dari jenis nilai yang ditunjuk `val`.
///
/// Setiap referensi ke nilai tipe `T` harus kelipatan dari angka ini.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // SAFETY: val adalah referensi, jadi ini adalah pointer mentah yang valid
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Mengembalikan perataan minimum yang diperlukan [ABI] dari jenis nilai yang ditunjuk `val`.
///
/// Setiap referensi ke nilai tipe `T` harus kelipatan dari angka ini.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Fungsi ini hanya aman untuk dipanggil jika kondisi berikut berlaku:
///
/// - Jika `T` adalah `Sized`, fungsi ini selalu aman untuk dipanggil.
/// - Jika ekor `T` berukuran besar adalah:
///     - a [slice], maka panjang ekor irisan harus berupa bilangan bulat yang diinisialisasi, dan ukuran *nilai keseluruhan*(panjang ekor dinamis + awalan berukuran statis) harus sesuai dengan `isize`.
///     - a [trait object], maka bagian vtable dari pointer harus menunjuk ke vtable valid yang diperoleh dengan paksaan unsizing, dan ukuran *seluruh nilai*(panjang ekor dinamis + prefiks berukuran statis) harus sesuai dengan `isize`.
///
///     - sebuah (unstable) [extern type], maka fungsi ini selalu aman untuk dipanggil, tetapi mungkin panic atau sebaliknya mengembalikan nilai yang salah, karena tata letak tipe eksternal tidak diketahui.
///     Ini adalah perilaku yang sama seperti [`align_of_val`] pada referensi ke tipe dengan ekor tipe eksternal.
///     - jika tidak, secara konservatif tidak diperbolehkan untuk memanggil fungsi ini.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // KEAMANAN: pemanggil harus memberikan pointer mentah yang valid
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Mengembalikan `true` jika menghilangkan nilai tipe `T` itu penting.
///
/// Ini murni petunjuk pengoptimalan, dan dapat diterapkan secara konservatif:
/// mungkin mengembalikan `true` untuk jenis yang sebenarnya tidak perlu dihapus.
/// Karena itu, selalu mengembalikan `true` akan menjadi implementasi yang valid dari fungsi ini.Namun jika fungsi ini benar-benar mengembalikan `false`, maka Anda dapat yakin bahwa menghapus `T` tidak memiliki efek samping.
///
/// Implementasi tingkat rendah dari hal-hal seperti koleksi, yang perlu melepaskan datanya secara manual, harus menggunakan fungsi ini untuk menghindari upaya yang tidak perlu untuk melepaskan semua kontennya saat dimusnahkan.
///
/// Ini mungkin tidak membuat perbedaan dalam build rilis (di mana loop yang tidak memiliki efek samping mudah dideteksi dan dihilangkan), tetapi sering kali merupakan kemenangan besar untuk build debug.
///
/// Perhatikan bahwa [`drop_in_place`] sudah melakukan pemeriksaan ini, jadi jika beban kerja Anda dapat dikurangi menjadi sejumlah kecil panggilan [`drop_in_place`], penggunaan ini tidak perlu.
/// Dalam catatan khusus bahwa Anda dapat [`drop_in_place`] sepotong, dan itu akan melakukan pemeriksaan need_drop tunggal untuk semua nilai.
///
/// Tipe seperti Vec oleh karena itu hanya `drop_in_place(&mut self[..])` tanpa menggunakan `needs_drop` secara eksplisit.
/// Tipe seperti [`HashMap`], di sisi lain, harus menjatuhkan nilai satu per satu dan harus menggunakan API ini.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Berikut adalah contoh bagaimana suatu koleksi dapat menggunakan `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // jatuhkan datanya
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Mengembalikan nilai tipe `T` yang diwakili oleh pola byte semua-nol.
///
/// Ini berarti bahwa, misalnya, padding byte di `(u8, u16)` belum tentu bernilai nol.
///
/// Tidak ada jaminan bahwa pola byte semua-nol mewakili nilai yang valid dari beberapa tipe `T`.
/// Misalnya, pola byte semua-nol bukanlah nilai yang valid untuk jenis referensi (`&T`, `&mut T`) dan penunjuk fungsi.
/// Menggunakan `zeroed` pada tipe seperti itu menyebabkan [undefined behavior][ub] langsung karena [the Rust compiler assumes][inv] yang selalu ada nilai yang valid dalam variabel yang dianggap diinisialisasi.
///
///
/// Ini memiliki efek yang sama seperti [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// Terkadang berguna untuk FFI, tetapi umumnya harus dihindari.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Penggunaan yang benar dari fungsi ini: menginisialisasi integer dengan nol.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Salah* penggunaan fungsi ini: menginisialisasi referensi dengan nol.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Perilaku tidak terdefinisi!
/// let _y: fn() = unsafe { mem::zeroed() }; // Dan lagi!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // KEAMANAN: penelepon harus menjamin bahwa nilai semua-nol valid untuk `T`.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Melewati pemeriksaan inisialisasi memori normal Rust dengan berpura-pura menghasilkan nilai tipe `T`, sementara tidak melakukan apa pun.
///
/// **Fungsi ini tidak digunakan lagi.** Gunakan [`MaybeUninit<T>`] sebagai gantinya.
///
/// Alasan penghentian ini adalah karena fungsi tersebut pada dasarnya tidak dapat digunakan dengan benar: ini memiliki efek yang sama seperti [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// Seperti yang dijelaskan oleh [`assume_init` documentation][assume_init], [the Rust compiler assumes][inv] bahwa nilai diinisialisasi dengan benar.
/// Akibatnya, menelepon misalnya
/// `mem::uninitialized::<bool>()` menyebabkan perilaku tidak terdefinisi langsung untuk mengembalikan `bool` yang bukan merupakan `true` atau `false`.
/// Lebih buruk lagi, memori yang benar-benar tidak diinisialisasi seperti yang dikembalikan di sini adalah khusus karena kompilator tahu bahwa ia tidak memiliki nilai tetap.
/// Hal ini membuat perilaku tidak terdefinisi untuk memiliki data yang tidak diinisialisasi dalam variabel meskipun variabel tersebut memiliki tipe integer.
/// (Perhatikan bahwa aturan seputar bilangan bulat yang tidak diinisialisasi belum diselesaikan, tetapi hingga selesai, disarankan untuk menghindarinya.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // KEAMANAN: penelepon harus menjamin bahwa nilai unitialisasi valid untuk `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Menukar nilai di dua lokasi yang bisa berubah, tanpa menghapus salah satunya.
///
/// * Jika Anda ingin menukar dengan nilai default atau dummy, lihat [`take`].
/// * Jika Anda ingin menukar dengan nilai yang diteruskan, mengembalikan nilai lama, lihat [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // KESELAMATAN: petunjuk mentah telah dibuat dari referensi yang dapat berubah aman yang memenuhi semua
    // kendala di `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Mengganti `dest` dengan nilai default `T`, mengembalikan nilai `dest` sebelumnya.
///
/// * Jika Anda ingin mengganti nilai dari dua variabel, lihat [`swap`].
/// * Jika Anda ingin mengganti dengan nilai yang diteruskan dan bukan nilai default, lihat [`replace`].
///
/// # Examples
///
/// Contoh sederhana:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` memungkinkan mengambil kepemilikan bidang struct dengan menggantinya dengan nilai "empty".
/// Tanpa `take` Anda dapat mengalami masalah seperti ini:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Perhatikan bahwa `T` tidak selalu mengimplementasikan [`Clone`], jadi `T` bahkan tidak dapat mengkloning dan mengatur ulang `self.buf`.
/// Tetapi `take` dapat digunakan untuk memisahkan nilai asli `self.buf` dari `self`, memungkinkannya untuk dikembalikan:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Memindahkan `src` ke `dest` yang direferensikan, mengembalikan nilai `dest` sebelumnya.
///
/// Tidak ada nilai yang dijatuhkan.
///
/// * Jika Anda ingin mengganti nilai dari dua variabel, lihat [`swap`].
/// * Jika Anda ingin mengganti dengan nilai default, lihat [`take`].
///
/// # Examples
///
/// Contoh sederhana:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` memungkinkan konsumsi bidang struct dengan menggantinya dengan nilai lain.
/// Tanpa `replace` Anda dapat mengalami masalah seperti ini:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Perhatikan bahwa `T` tidak selalu mengimplementasikan [`Clone`], jadi kami bahkan tidak dapat mengkloning `self.buf[i]` untuk menghindari pemindahan.
/// Tetapi `replace` dapat digunakan untuk memisahkan nilai asli pada indeks tersebut dari `self`, memungkinkannya untuk dikembalikan:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // KEAMANAN: Kami membaca dari `dest` tetapi langsung menulis `src` ke dalamnya setelah itu,
    // sedemikian rupa sehingga nilai lama tidak diduplikasi.
    // Tidak ada yang dijatuhkan dan tidak ada yang bisa panic di sini.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Membuang nilai.
///
/// Ini dilakukan dengan memanggil implementasi argumen [`Drop`][drop].
///
/// Ini secara efektif tidak melakukan apa pun untuk jenis yang mengimplementasikan `Copy`, mis
/// integers.
/// Nilai tersebut disalin dan _then_ dipindahkan ke fungsi tersebut, sehingga nilainya tetap ada setelah pemanggilan fungsi ini.
///
///
/// Fungsi ini bukanlah sihir;itu secara harfiah didefinisikan sebagai
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Karena `_x` dipindahkan ke fungsi tersebut, maka secara otomatis dijatuhkan sebelum fungsi tersebut kembali.
///
/// [drop]: Drop
///
/// # Examples
///
/// Penggunaan dasar:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // secara eksplisit menjatuhkan vector
/// ```
///
/// Karena [`RefCell`] memberlakukan aturan peminjaman saat runtime, `drop` dapat merilis peminjaman [`RefCell`]:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // lepaskan pinjaman yang bisa berubah di slot ini
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Integer dan tipe lain yang mengimplementasikan [`Copy`] tidak terpengaruh oleh `drop`.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // salinan `x` dipindahkan dan dijatuhkan
/// drop(y); // salinan `y` dipindahkan dan dijatuhkan
///
/// println!("x: {}, y: {}", x, y.0); // masih ada
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Menafsirkan `src` memiliki tipe `&U`, lalu membaca `src` tanpa memindahkan nilai yang terkandung.
///
/// Fungsi ini secara tidak aman akan menganggap pointer `src` valid untuk byte [`size_of::<U>`][size_of] dengan mentransmutasikan `&T` ke `&U` dan kemudian membaca `&U` (kecuali bahwa ini dilakukan dengan cara yang benar bahkan ketika `&U` membuat persyaratan penyelarasan yang lebih ketat daripada `&T`).
/// Ini juga akan membuat salinan nilai yang terkandung secara tidak aman alih-alih keluar dari `src`.
///
/// Ini bukan kesalahan waktu kompilasi jika `T` dan `U` memiliki ukuran yang berbeda, tetapi sangat disarankan untuk hanya menjalankan fungsi ini di mana `T` dan `U` memiliki ukuran yang sama.Fungsi ini memicu [undefined behavior][ub] jika `U` lebih besar dari `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Salin data dari 'foo_array' dan perlakukan sebagai 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Ubah data yang disalin
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // Isi 'foo_array' seharusnya tidak berubah
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Jika U memiliki persyaratan perataan yang lebih tinggi, src mungkin tidak sejajar dengan tepat.
    if align_of::<U>() > align_of::<T>() {
        // SAFETY: `src` adalah referensi yang dijamin valid untuk dibaca.
        // Penelepon harus menjamin bahwa transmutasi sebenarnya aman.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // SAFETY: `src` adalah referensi yang dijamin valid untuk dibaca.
        // Kami baru saja memeriksa bahwa `src as *const U` telah disejajarkan dengan benar.
        // Penelepon harus menjamin bahwa transmutasi sebenarnya aman.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Jenis buram yang mewakili diskriminan enum.
///
/// Lihat fungsi [`discriminant`] dalam modul ini untuk informasi lebih lanjut.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Implementasi trait ini tidak dapat diturunkan karena kami tidak ingin ada batasan pada T.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Mengembalikan nilai yang secara unik mengidentifikasi varian enum di `v`.
///
/// Jika `T` bukan enum, memanggil fungsi ini tidak akan menghasilkan perilaku yang tidak ditentukan, tetapi nilai yang dikembalikan tidak ditentukan.
///
///
/// # Stability
///
/// Diskriminan varian enum dapat berubah jika definisi enum berubah.
/// Diskriminan dari beberapa varian tidak akan berubah antara kompilasi dengan kompilator yang sama.
///
/// # Examples
///
/// Ini dapat digunakan untuk membandingkan enum yang membawa data, sambil mengabaikan data sebenarnya:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Menampilkan jumlah varian dalam jenis enum `T`.
///
/// Jika `T` bukan enum, memanggil fungsi ini tidak akan menghasilkan perilaku yang tidak ditentukan, tetapi nilai yang dikembalikan tidak ditentukan.
/// Demikian pula, jika `T` adalah enum dengan varian lebih dari `usize::MAX`, nilai kembaliannya tidak ditentukan.
/// Varian yang tidak berpenghuni akan dihitung.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}