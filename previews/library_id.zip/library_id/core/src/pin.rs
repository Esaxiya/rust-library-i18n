//! Jenis yang menyematkan data ke lokasinya di memori.
//!
//! Terkadang berguna untuk memiliki objek yang dijamin tidak akan bergerak, dalam arti penempatannya di memori tidak berubah, dan dengan demikian dapat diandalkan.
//! Contoh utama dari skenario seperti itu adalah membangun struct referensi sendiri, karena memindahkan objek dengan pointer ke dirinya sendiri akan membatalkannya, yang dapat menyebabkan perilaku tidak terdefinisi.
//!
//! Pada level tinggi, [`Pin<P>`] memastikan bahwa pointee dari setiap tipe pointer `P` memiliki lokasi yang stabil di memori, yang berarti ia tidak dapat dipindahkan ke tempat lain dan memorinya tidak dapat dialokasikan hingga dijatuhkan.Kami mengatakan bahwa yang dimaksud adalah "pinned".Segalanya menjadi lebih halus saat membahas jenis yang menggabungkan pin dengan data yang tidak disematkan;[see below](#projections-and-structural-pinning) untuk lebih jelasnya.
//!
//! Secara default, semua tipe di Rust dapat dipindahkan.
//! Rust memungkinkan penerusan semua tipe berdasarkan nilai, dan tipe smart-pointer umum seperti [`Box<T>`] dan `&mut T` memungkinkan penggantian dan pemindahan nilai yang dikandungnya: Anda dapat keluar dari [`Box<T>`], atau Anda dapat menggunakan [`mem::swap`].
//! [`Pin<P>`] membungkus tipe penunjuk `P`, jadi [`Pin`]`<`[`Box`] `<T>>`berfungsi seperti biasa
//!
//! [`Box<T>`]: when sebuah [`Pin`]`<`[`Box`] `<T>>`dijatuhkan, begitu juga isinya, dan memori mendapat
//!
//! dialokasikan.Demikian pula, [`Pin`]`<&mut T>`sangat mirip dengan `&mut T`.Namun, [`Pin<P>`] tidak mengizinkan klien benar-benar mendapatkan [`Box<T>`] atau `&mut T` ke data yang disematkan, yang menyiratkan bahwa Anda tidak dapat menggunakan operasi seperti [`mem::swap`]:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` membutuhkan `&mut T`, tetapi kami tidak bisa mendapatkannya.
//!     // Kami terjebak, kami tidak dapat menukar konten referensi ini.
//!     // Kami dapat menggunakan `Pin::get_unchecked_mut`, tetapi itu tidak aman karena suatu alasan:
//!     // kami tidak diizinkan menggunakannya untuk memindahkan barang-barang dari `Pin`.
//! }
//! ```
//!
//! Patut ditegaskan kembali bahwa [`Pin<P>`]*tidak* mengubah fakta bahwa kompiler Rust menganggap semua jenis dapat dipindahkan.[`mem::swap`] tetap dapat dipanggil untuk `T` mana pun.Sebaliknya, [`Pin<P>`] mencegah *nilai* tertentu * (ditunjukkan oleh pointer yang dibungkus dalam [`Pin<P>`]) agar tidak dipindahkan dengan membuatnya tidak mungkin untuk memanggil metode yang memerlukan `&mut T` padanya (seperti [`mem::swap`]).
//!
//! [`Pin<P>`] dapat digunakan untuk membungkus semua tipe pointer `P`, dan karena itu berinteraksi dengan [`Deref`] dan [`DerefMut`].[`Pin<P>`] di mana `P: Deref` harus dianggap sebagai "`P`-style pointer" untuk `P::Target` yang disematkan-jadi, [`Pin`]`<`[`Box`] `<T>>`adalah penunjuk milik ke `T` yang disematkan, dan [`Pin`] `<` [`Rc`]`<T>>`adalah penunjuk dihitung referensi ke `T` yang disematkan.
//! Untuk kebenarannya, [`Pin<P>`] mengandalkan implementasi [`Deref`] dan [`DerefMut`] untuk tidak keluar dari parameter `self` mereka, dan hanya mengembalikan pointer ke data yang disematkan saat dipanggil pada pointer yang disematkan.
//!
//! # `Unpin`
//!
//! Banyak jenis yang selalu dapat dipindahkan dengan bebas, bahkan saat disematkan, karena tidak bergantung pada memiliki alamat yang stabil.Ini mencakup semua tipe dasar (seperti [`bool`], [`i32`], dan referensi) serta tipe yang hanya terdiri dari tipe-tipe ini.Jenis yang tidak peduli tentang penyematan menerapkan [`Unpin`] auto-trait, yang membatalkan efek [`Pin<P>`].
//! Untuk `T: Unpin`, [`Pin`]`<`[`Box`] `<T>>`dan [`Box<T>`] berfungsi sama, seperti halnya [`Pin`] `<&mut T>` dan `&mut T`.
//!
//! Perhatikan bahwa menyematkan dan [`Unpin`] hanya memengaruhi tipe `P::Target` yang diarahkan ke, bukan tipe penunjuk `P` itu sendiri yang terbungkus dalam [`Pin<P>`].Misalnya, apakah [`Box<T>`] adalah [`Unpin`] atau tidak tidak berpengaruh pada perilaku [`Pin`]`<`[`Box`] `<T>>`(di sini, `T` adalah tipe yang diarahkan ke).
//!
//! # Contoh: struct referensi sendiri
//!
//! Sebelum kami membahas lebih detail untuk menjelaskan jaminan dan pilihan yang terkait dengan `Pin<T>`, kami membahas beberapa contoh bagaimana itu dapat digunakan.
//! Jangan ragu untuk [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Ini adalah struct referensi sendiri karena bidang potongan mengarah ke bidang data.
//! // Kami tidak dapat menginformasikan compiler tentang hal itu dengan referensi normal, karena pola ini tidak dapat dijelaskan dengan aturan peminjaman yang biasa.
//! //
//! // Sebagai gantinya kami menggunakan pointer mentah, meskipun yang diketahui tidak null, karena kami tahu itu menunjuk ke string.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Untuk memastikan data tidak bergerak saat fungsi kembali, kami menempatkannya di heap di mana ia akan tinggal selama masa pakai objek, dan satu-satunya cara untuk mengaksesnya adalah melalui penunjuk ke sana.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // kami hanya membuat penunjuk setelah data ada di tempatnya jika tidak, penunjuk akan sudah dipindahkan bahkan sebelum kami memulai
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // kami tahu ini aman karena memodifikasi bidang tidak memindahkan seluruh struct
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // Penunjuk harus menunjuk ke lokasi yang benar, selama struct belum bergerak.
//! //
//! // Sementara itu, kami bebas untuk memindahkan penunjuk.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Karena tipe kami tidak menerapkan Lepas pin, ini akan gagal untuk dikompilasi:
//! // biarkan mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Contoh: daftar tertaut ganda yang mengganggu
//!
//! Dalam daftar tertaut ganda yang mengganggu, collection sebenarnya tidak mengalokasikan memori untuk elemen itu sendiri.
//! Alokasi dikontrol oleh klien, dan elemen dapat berada di bingkai tumpukan yang umurnya lebih pendek daripada koleksi.
//!
//! Untuk membuat ini berfungsi, setiap elemen memiliki petunjuk ke pendahulunya dan penerusnya dalam daftar.Elemen hanya dapat ditambahkan jika disematkan, karena memindahkan elemen akan membuat penunjuk tidak valid.Selain itu, implementasi [`Drop`] dari elemen daftar tertaut akan menambal petunjuk pendahulunya dan penggantinya untuk menghapus dirinya sendiri dari daftar.
//!
//! Yang terpenting, kami harus dapat mengandalkan panggilan [`drop`].Jika sebuah elemen dapat dibatalkan alokasinya atau tidak valid tanpa memanggil [`drop`], pointer ke dalamnya dari elemen tetangganya akan menjadi tidak valid, yang akan merusak struktur data.
//!
//! Oleh karena itu, penyematan juga disertai dengan jaminan terkait [`drop`].
//!
//! # `Drop` guarantee
//!
//! Tujuan penyematan adalah agar dapat mengandalkan penempatan beberapa data di memori.
//! Untuk membuat ini berfungsi, tidak hanya memindahkan data yang dibatasi;deallocating, repurposing, atau tidak validasi memori yang digunakan untuk menyimpan data juga dibatasi.
//! Secara konkret, untuk data yang disematkan, Anda harus mempertahankan invarian yang *memorinya tidak akan dibatalkan atau digunakan ulang sejak disematkan hingga [`drop`] dipanggil*.Hanya sekali [`drop`] kembali atau panics, memori dapat digunakan kembali.
//!
//! Memori dapat menjadi "invalidated" dengan deallocation, tetapi juga dengan mengganti [`Some(v)`] dengan [`None`], atau memanggil [`Vec::set_len`] ke "kill" beberapa elemen dari vector.Ini dapat digunakan kembali dengan menggunakan [`ptr::write`] untuk menimpanya tanpa memanggil destruktor terlebih dahulu.Semua ini tidak diizinkan untuk data yang disematkan tanpa memanggil [`drop`].
//!
//! Ini adalah jenis jaminan bahwa daftar tertaut yang mengganggu dari bagian sebelumnya harus berfungsi dengan benar.
//!
//! Perhatikan bahwa jaminan ini *tidak* berarti bahwa memori tidak bocor!Tidak masalah jika Anda tidak memanggil [`drop`] pada elemen yang disematkan (misalnya, Anda masih dapat memanggil [`mem::forget`] pada [`Pin`]`<`[`Box`] `<T>>`).Dalam contoh daftar tertaut ganda, elemen itu hanya akan tetap ada di daftar.Namun Anda tidak dapat mengosongkan atau menggunakan kembali penyimpanan *tanpa memanggil [`drop`]*.
//!
//! # `Drop` implementation
//!
//! Jika jenis Anda menggunakan penyematan (seperti dua contoh di atas), Anda harus berhati-hati saat menerapkan [`Drop`].Fungsi [`drop`] menggunakan `&mut self`, tetapi ini disebut *meskipun tipe Anda sebelumnya disematkan*!Seolah-olah kompilator secara otomatis memanggil [`Pin::get_unchecked_mut`].
//!
//! Hal ini tidak pernah dapat menyebabkan masalah dalam kode aman karena menerapkan jenis yang bergantung pada penyematan memerlukan kode yang tidak aman, namun perlu diketahui bahwa memutuskan untuk menggunakan penyematan pada jenis Anda (misalnya dengan mengimplementasikan beberapa operasi pada [`Pin`]`<&Self>`atau [`Pin`] `<&mut Self>`) juga memiliki konsekuensi untuk implementasi [`Drop`] Anda: jika elemen jenis Anda dapat disematkan, Anda harus memperlakukan [`Drop`] sebagai secara implisit mengambil [`Pin`]`<&mut Diri>`.
//!
//!
//! Misalnya, Anda dapat mengimplementasikan `Drop` sebagai berikut:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` tidak apa-apa karena kita tahu nilai ini tidak akan pernah digunakan lagi setelah dijatuhkan.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Kode drop yang sebenarnya ada di sini.
//!         }
//!     }
//! }
//! ```
//!
//! Fungsi `inner_drop` memiliki tipe yang [`drop`]*harus* miliki, jadi ini memastikan bahwa Anda tidak menggunakan `self`/`this` secara tidak sengaja dengan cara yang bertentangan dengan penyematan.
//!
//! Selain itu, jika tipe Anda adalah `#[repr(packed)]`, kompiler akan secara otomatis memindahkan bidang-bidang agar dapat melepaskannya.Bahkan mungkin melakukannya untuk bidang yang kebetulan cukup rata.Akibatnya, Anda tidak dapat menggunakan pin dengan tipe `#[repr(packed)]`.
//!
//! # Proyeksi dan Struktural Pinning
//!
//! Saat bekerja dengan struct yang disematkan, muncul pertanyaan bagaimana seseorang dapat mengakses bidang struct itu dalam metode yang hanya membutuhkan [`Pin`]`<&mut Struct>`.
//! Pendekatan biasa adalah menulis metode pembantu (disebut *proyeksi*) yang mengubah [`Pin`]`<&mut Struct>`menjadi referensi ke bidang, tetapi jenis apa yang harus dimiliki referensi itu?Apakah [`Pin`]`<&mut Field>`atau `&mut Field`?
//! Pertanyaan yang sama muncul dengan bidang `enum`, dan juga saat mempertimbangkan jenis container/wrapper seperti [`Vec<T>`], [`Box<T>`], atau [`RefCell<T>`].
//! (Pertanyaan ini berlaku untuk referensi yang bisa berubah dan bersama, kami hanya menggunakan kasus referensi yang bisa berubah yang lebih umum di sini untuk ilustrasi.)
//!
//! Ternyata terserah pembuat struktur data untuk memutuskan apakah proyeksi yang disematkan untuk bidang tertentu mengubah [`Pin`]`<&mut Struct>`menjadi [`Pin`] `<&mut Field>` atau `&mut Field`.Ada beberapa batasan, dan batasan yang paling penting adalah *konsistensi*:
//! setiap bidang dapat *baik* diproyeksikan ke referensi yang disematkan,*atau* telah dihapus pin sebagai bagian dari proyeksi.
//! Jika keduanya dilakukan untuk bidang yang sama, kemungkinan besar itu tidak masuk akal!
//!
//! Sebagai pembuat struktur data, Anda harus memutuskan untuk setiap bidang apakah menyematkan "propagates" ke bidang ini atau tidak.
//! Pinning yang merambat disebut juga "structural", karena mengikuti struktur tipenya.
//! Dalam subbagian berikut, kami menjelaskan pertimbangan yang harus dibuat untuk salah satu pilihan.
//!
//! ## Pining *tidak* struktural untuk `field`
//!
//! Tampaknya kontra-intuitif bahwa bidang struct yang disematkan mungkin tidak disematkan, tetapi itu sebenarnya adalah pilihan termudah: jika [`Pin`]`<&mut Field>`tidak pernah dibuat, tidak ada yang salah!Jadi, jika Anda memutuskan bahwa beberapa bidang tidak memiliki penyematan struktural, Anda harus memastikan bahwa Anda tidak pernah membuat referensi yang disematkan ke bidang itu.
//!
//! Bidang tanpa penyematan struktural mungkin memiliki metode proyeksi yang mengubah [`Pin`]`<&mut Struct>`menjadi `&mut Field`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Ini tidak apa-apa karena `field` dianggap tidak pernah disematkan.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Anda juga dapat `impl Unpin for Struct`*meskipun* tipe `field` bukan [`Unpin`].Apa yang dipikirkan jenis itu tentang pemasangan pin tidak relevan jika tidak ada [`Pin`]`<&mut Field>`yang pernah dibuat.
//!
//! ## Pinning *bersifat* struktural untuk `field`
//!
//! Pilihan lainnya adalah memutuskan bahwa penyematan adalah "structural" untuk `field`, artinya jika struct disematkan maka begitu juga bidangnya.
//!
//! Hal ini memungkinkan penulisan proyeksi yang membuat [`Pin`]`<&mut Field>`, sehingga menyaksikan bahwa bidang tersebut disematkan:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Ini tidak apa-apa karena `field` disematkan saat `self` dipasang.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Namun, penyematan struktural hadir dengan beberapa persyaratan tambahan:
//!
//! 1. Struktur harus hanya [`Unpin`] jika semua bidang struktural adalah [`Unpin`].Ini adalah defaultnya, tetapi [`Unpin`] adalah trait yang aman, jadi sebagai pembuat struct, Anda bertanggung jawab *bukan* untuk menambahkan sesuatu seperti `impl<T> Unpin for Struct<T>`.
//! (Perhatikan bahwa menambahkan operasi proyeksi memerlukan kode yang tidak aman, jadi fakta bahwa [`Unpin`] adalah trait yang aman tidak melanggar prinsip bahwa Anda hanya perlu mengkhawatirkan semua ini jika Anda menggunakan `tidak aman`.)
//! 2. Penghancur struct tidak boleh memindahkan bidang struktural dari argumennya.Ini adalah poin tepat yang dimunculkan di [previous section][drop-impl]: `drop` mengambil `&mut self`, tetapi struct (dan karenanya bidangnya) mungkin telah disematkan sebelumnya.
//!     Anda harus menjamin bahwa Anda tidak memindahkan bidang di dalam implementasi [`Drop`] Anda.
//!     Secara khusus, seperti yang dijelaskan sebelumnya, ini berarti bahwa struct Anda tidak boleh *bukan* berupa `#[repr(packed)]`.
//!     Lihat bagian tersebut untuk mengetahui cara menulis [`drop`] dengan cara yang dapat dilakukan oleh compiler untuk membantu Anda agar tidak merusak pinning secara tidak sengaja.
//! 3. Anda harus memastikan bahwa Anda menjunjung [`Drop` guarantee][drop-guarantee]:
//!     setelah struct Anda disematkan, memori yang berisi konten tidak akan ditimpa atau dialokasikan tanpa memanggil destruktor konten.
//!     Ini bisa rumit, seperti yang disaksikan oleh [`VecDeque<T>`]: penghancur [`VecDeque<T>`] bisa gagal memanggil [`drop`] pada semua elemen jika salah satu penghancur panics.Hal ini melanggar jaminan [`Drop`], karena dapat menyebabkan elemen dibatalkan alokasinya tanpa pemanggilan destruktornya.([`VecDeque<T>`] tidak memiliki proyeksi pin, jadi ini tidak menyebabkan ketidaknyamanan.)
//! 4. Anda tidak boleh menawarkan operasi lain yang dapat menyebabkan data dipindahkan dari bidang struktural saat jenis Anda disematkan.Misalnya, jika struct berisi [`Option<T>`] dan ada operasi serupa `take` dengan tipe `fn(Pin<&mut Struct<T>>) -> Option<T>`, operasi tersebut dapat digunakan untuk memindahkan `T` dari `Struct<T>` yang disematkan-yang berarti penyematan tidak dapat bersifat struktural untuk bidang yang menampung ini data.
//!
//!     Untuk contoh yang lebih kompleks tentang memindahkan data dari jenis yang disematkan, bayangkan jika [`RefCell<T>`] memiliki metode `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>`.
//!     Kemudian kita bisa melakukan hal berikut:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Ini bencana, artinya kita dapat menyematkan konten [`RefCell<T>`] terlebih dahulu (menggunakan `RefCell::get_pin_mut`) dan kemudian memindahkan konten itu menggunakan referensi yang bisa berubah yang kita dapatkan nanti.
//!
//! ## Examples
//!
//! Untuk tipe seperti [`Vec<T>`], kedua kemungkinan (penyematan struktural atau tidak) masuk akal.
//! [`Vec<T>`] dengan penyematan struktural dapat memiliki metode `get_pin`/`get_pin_mut` untuk mendapatkan referensi yang disematkan ke elemen.Namun, itu tidak dapat *tidak* mengizinkan pemanggilan [`pop`][Vec::pop] pada [`Vec<T>`] yang disematkan karena itu akan memindahkan konten (tersemat secara struktural)!Juga tidak dapat mengizinkan [`push`][Vec::push], yang mungkin mengalokasikan kembali dan dengan demikian juga memindahkan konten.
//!
//! Sebuah [`Vec<T>`] tanpa penyematan struktural dapat `impl<T> Unpin for Vec<T>`, karena konten tidak pernah disematkan dan [`Vec<T>`] itu sendiri baik-baik saja dengan dipindahkan juga.
//! Pada saat itu, penyematan sama sekali tidak berpengaruh pada vector.
//!
//! Di pustaka standar, jenis penunjuk umumnya tidak memiliki penyematan struktural, dan karenanya tidak menawarkan proyeksi penyematan.Inilah mengapa `Box<T>: Unpin` berlaku untuk semua `T`.
//! Masuk akal untuk melakukan ini untuk jenis penunjuk, karena memindahkan `Box<T>` tidak benar-benar menggerakkan `T`: [`Box<T>`] dapat dengan bebas dipindahkan (alias `Unpin`) meskipun `T` tidak.Bahkan, bahkan [`Pin`]`<`[`Box`] `<T>>`dan [`Pin`] `<&mut T>` selalu [`Unpin`] itu sendiri, karena alasan yang sama: kontennya (`T`) disematkan, tetapi penunjuk itu sendiri dapat dipindahkan tanpa memindahkan data yang disematkan.
//! Untuk [`Box<T>`] dan [`Pin`]`<`[`Box`] `<T>>`, apakah konten disematkan sepenuhnya terlepas dari apakah penunjuk disematkan, artinya penyematan *tidak* struktural.
//!
//! Saat mengimplementasikan kombinator [`Future`], Anda biasanya memerlukan penyematan struktural untuk futures bertingkat, karena Anda perlu mendapatkan referensi yang disematkan ke sana untuk memanggil [`poll`].
//! Namun jika kombinator Anda berisi data lain yang tidak perlu disematkan, Anda dapat membuat bidang tersebut tidak terstruktur dan karenanya dapat mengaksesnya secara bebas dengan referensi yang dapat berubah meskipun Anda hanya memiliki [`Pin`]`<&mut Self>`(seperti seperti dalam implementasi [`poll`] Anda sendiri).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// Penunjuk yang disematkan.
///
/// Ini adalah pembungkus di sekitar semacam penunjuk yang membuat penunjuk "pin" itu nilainya di tempatnya, mencegah nilai yang dirujuk oleh penunjuk itu dipindahkan kecuali jika ia mengimplementasikan [`Unpin`].
///
///
/// *Lihat dokumentasi [`pin` module] untuk penjelasan tentang penyematan.*
///
/// [`pin` module]: self
///
// Note: `Clone` yang diturunkan di bawah ini menyebabkan ketidaknyamanan karena mungkin untuk diterapkan
// `Clone` untuk referensi yang bisa berubah.
// Lihat <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> untuk lebih jelasnya.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Implementasi berikut tidak diturunkan untuk menghindari masalah kesehatan.
// `&self.pointer` seharusnya tidak dapat diakses oleh implementasi trait yang tidak tepercaya.
//
// Lihat <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> untuk lebih jelasnya.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Buat `Pin<P>` baru di sekitar penunjuk ke beberapa data dari tipe yang mengimplementasikan [`Unpin`].
    ///
    /// Tidak seperti `Pin::new_unchecked`, metode ini aman karena penunjuk `P` merujuk ke jenis [`Unpin`], yang membatalkan jaminan penyematan.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // KEAMANAN: nilai yang ditunjukkan adalah `Unpin`, jadi tidak ada persyaratan
        // sekitar pinning.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Buka bungkus `Pin<P>` ini yang mengembalikan penunjuk yang mendasarinya.
    ///
    /// Ini mengharuskan data di dalam `Pin` ini adalah [`Unpin`] sehingga kita dapat mengabaikan invarian penyematan saat membukanya.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Buat `Pin<P>` baru di sekitar referensi ke beberapa jenis data yang mungkin atau mungkin tidak mengimplementasikan `Unpin`.
    ///
    /// Jika `pointer` mengacu pada jenis `Unpin`, sebaiknya gunakan `Pin::new`.
    ///
    /// # Safety
    ///
    /// Konstruktor ini tidak aman karena kami tidak dapat menjamin bahwa data yang ditunjukkan oleh `pointer` telah disematkan, artinya data tidak akan dipindahkan atau penyimpanannya tidak valid hingga dijatuhkan.
    /// Jika `Pin<P>` yang dibuat tidak menjamin bahwa data yang ditunjuk `P` telah disematkan, itu merupakan pelanggaran kontrak API dan dapat menyebabkan perilaku yang tidak ditentukan dalam operasi (safe) selanjutnya.
    ///
    /// Dengan menggunakan metode ini, Anda membuat promise tentang implementasi `P::Deref` dan `P::DerefMut`, jika ada.
    /// Yang terpenting, mereka tidak boleh keluar dari argumen `self`: `Pin::as_mut` dan `Pin::as_ref` akan memanggil `DerefMut::deref_mut` dan `Deref::deref`*pada penunjuk yang disematkan* dan mengharapkan metode ini untuk mempertahankan invarian penyematan.
    /// Selain itu, dengan memanggil metode ini Anda promise yang referensi referensi `P` tidak akan dipindahkan lagi;khususnya, tidak mungkin mendapatkan `&mut P::Target` dan kemudian keluar dari referensi tersebut (menggunakan, misalnya [`mem::swap`]).
    ///
    ///
    /// Misalnya, memanggil `Pin::new_unchecked` pada `&'a mut T` tidak aman karena meskipun Anda dapat menyematkannya untuk masa pakai `'a` tertentu, Anda tidak memiliki kendali apakah akan tetap disematkan setelah `'a` berakhir:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Ini berarti pointee `a` tidak akan pernah bisa bergerak lagi.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // Alamat `a` diubah menjadi slot stack `b`, jadi `a` dipindahkan meskipun sebelumnya kita telah menyematkannya!Kami telah melanggar kontrak API pemasangan pin.
    /////
    /// }
    /// ```
    ///
    /// Sebuah nilai, setelah disematkan, harus tetap disematkan selamanya (kecuali tipenya mengimplementasikan `Unpin`).
    ///
    /// Demikian pula, memanggil `Pin::new_unchecked` pada `Rc<T>` tidak aman karena mungkin ada alias untuk data yang sama yang tidak tunduk pada batasan pemasangan pin:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Ini berarti orang yang dimaksud tidak akan pernah bisa bergerak lagi.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Sekarang, jika `x` adalah satu-satunya referensi, kami memiliki referensi yang dapat berubah ke data yang kami sematkan di atas, yang dapat kami gunakan untuk memindahkannya seperti yang telah kita lihat pada contoh sebelumnya.
    ///     // Kami telah melanggar kontrak API pemasangan pin.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Mendapat referensi bersama yang disematkan dari penunjuk yang disematkan ini.
    ///
    /// Ini adalah metode umum untuk beralih dari `&Pin<Pointer<T>>` ke `Pin<&T>`.
    /// Aman karena, sebagai bagian dari kontrak `Pin::new_unchecked`, pihak yang ditunjuk tidak dapat bergerak setelah `Pin<Pointer<T>>` dibuat.
    ///
    /// "Malicious" implementasi `Pointer::Deref` juga dikesampingkan oleh kontrak `Pin::new_unchecked`.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // KEAMANAN: lihat dokumentasi tentang fungsi ini
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Buka bungkus `Pin<P>` ini yang mengembalikan penunjuk yang mendasarinya.
    ///
    /// # Safety
    ///
    /// Fungsi ini tidak aman.Anda harus menjamin bahwa Anda akan terus memperlakukan pointer `P` sebagai pin setelah Anda memanggil fungsi ini, sehingga invarian pada tipe `Pin` dapat dipertahankan.
    /// Jika kode yang menggunakan `P` yang dihasilkan tidak terus mempertahankan invarian penyematan yang merupakan pelanggaran kontrak API dan dapat menyebabkan perilaku tidak terdefinisi di operasi (safe) selanjutnya.
    ///
    ///
    /// Jika data pokok adalah [`Unpin`], sebaiknya gunakan [`Pin::into_inner`].
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Mendapat referensi yang dapat diubah yang disematkan dari penunjuk yang disematkan ini.
    ///
    /// Ini adalah metode umum untuk beralih dari `&mut Pin<Pointer<T>>` ke `Pin<&mut T>`.
    /// Aman karena, sebagai bagian dari kontrak `Pin::new_unchecked`, pihak yang ditunjuk tidak dapat bergerak setelah `Pin<Pointer<T>>` dibuat.
    ///
    /// "Malicious" implementasi `Pointer::DerefMut` juga dikesampingkan oleh kontrak `Pin::new_unchecked`.
    ///
    /// Metode ini berguna saat melakukan beberapa panggilan ke fungsi yang menggunakan jenis yang disematkan.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // lakukan sesuatu
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` mengkonsumsi `self`, jadi pinjam kembali `Pin<&mut Self>` melalui `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // KEAMANAN: lihat dokumentasi tentang fungsi ini
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Menetapkan nilai baru ke memori di belakang referensi yang disematkan.
    ///
    /// Ini menimpa data yang disematkan, tetapi tidak apa-apa: destruktornya dijalankan sebelum ditimpa, jadi tidak ada jaminan penyematan yang dilanggar.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Membuat pin baru dengan memetakan nilai interior.
    ///
    /// Misalnya, jika Anda ingin mendapatkan `Pin` bidang dari sesuatu, Anda dapat menggunakan ini untuk mendapatkan akses ke bidang itu dalam satu baris kode.
    /// Namun, ada beberapa masalah dengan "pinning projections" ini;
    /// lihat dokumentasi [`pin` module] untuk detail lebih lanjut tentang topik itu.
    ///
    /// # Safety
    ///
    /// Fungsi ini tidak aman.
    /// Anda harus menjamin bahwa data yang Anda kembalikan tidak akan berpindah selama nilai argumen tidak berpindah (misalnya, karena ini adalah salah satu bidang dari nilai tersebut), dan juga bahwa Anda tidak keluar dari argumen yang Anda terima. fungsi interior.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // KEAMANAN: kontrak keamanan untuk `new_unchecked` harus
        // ditegakkan oleh penelepon.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Mendapatkan referensi bersama dari pin.
    ///
    /// Ini aman karena tidak mungkin keluar dari referensi bersama.
    /// Sepertinya ada masalah di sini dengan mutabilitas interior: pada kenyataannya,*adalah* mungkin untuk memindahkan `T` dari `&RefCell<T>`.
    /// Namun, ini bukan masalah selama tidak ada `Pin<&T>` yang menunjuk ke data yang sama, dan `RefCell<T>` tidak mengizinkan Anda membuat referensi yang disematkan ke kontennya.
    ///
    /// Lihat pembahasan di ["pinning projections"] untuk detail lebih lanjut.
    ///
    /// Note: `Pin` juga mengimplementasikan `Deref` ke target, yang dapat digunakan untuk mengakses nilai bagian dalam.
    /// Namun, `Deref` hanya memberikan referensi yang berlaku selama meminjam `Pin`, bukan seumur hidup `Pin` itu sendiri.
    /// Metode ini memungkinkan mengubah `Pin` menjadi referensi dengan masa pakai yang sama dengan `Pin` asli.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Mengubah `Pin<&mut T>` ini menjadi `Pin<&T>` dengan masa pakai yang sama.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Mendapat referensi yang bisa berubah ke data di dalam `Pin` ini.
    ///
    /// Ini mengharuskan data di dalam `Pin` ini adalah `Unpin`.
    ///
    /// Note: `Pin` juga mengimplementasikan `DerefMut` ke data, yang dapat digunakan untuk mengakses nilai bagian dalam.
    /// Namun, `DerefMut` hanya memberikan referensi yang berlaku selama meminjam `Pin`, bukan seumur hidup `Pin` itu sendiri.
    ///
    /// Metode ini memungkinkan mengubah `Pin` menjadi referensi dengan masa pakai yang sama dengan `Pin` asli.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Mendapat referensi yang bisa berubah ke data di dalam `Pin` ini.
    ///
    /// # Safety
    ///
    /// Fungsi ini tidak aman.
    /// Anda harus menjamin bahwa Anda tidak akan pernah memindahkan data keluar dari referensi yang dapat berubah yang Anda terima saat Anda memanggil fungsi ini, sehingga invarian pada tipe `Pin` dapat dipertahankan.
    ///
    ///
    /// Jika data pokok adalah `Unpin`, sebaiknya gunakan `Pin::get_mut`.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Buat pin baru dengan memetakan nilai interior.
    ///
    /// Misalnya, jika Anda ingin mendapatkan `Pin` bidang dari sesuatu, Anda dapat menggunakan ini untuk mendapatkan akses ke bidang itu dalam satu baris kode.
    /// Namun, ada beberapa masalah dengan "pinning projections" ini;
    /// lihat dokumentasi [`pin` module] untuk detail lebih lanjut tentang topik itu.
    ///
    /// # Safety
    ///
    /// Fungsi ini tidak aman.
    /// Anda harus menjamin bahwa data yang Anda kembalikan tidak akan berpindah selama nilai argumen tidak berpindah (misalnya, karena ini adalah salah satu bidang dari nilai tersebut), dan juga bahwa Anda tidak keluar dari argumen yang Anda terima. fungsi interior.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // KEAMANAN: penelepon bertanggung jawab untuk tidak memindahkan
        // nilai dari referensi ini.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // KEAMANAN: karena nilai `this` dijamin tidak ada
        // telah dipindahkan, panggilan ke `new_unchecked` ini aman.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Dapatkan referensi yang disematkan dari referensi statis.
    ///
    /// Ini aman, karena `T` dipinjam untuk masa pakai `'static`, yang tidak pernah berakhir.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // KEAMANAN: 'pinjaman statis menjamin data tidak akan
        // moved/invalidated sampai dijatuhkan (yang tidak pernah).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Dapatkan referensi yang bisa diubah dengan pin dari referensi yang bisa berubah statis.
    ///
    /// Ini aman, karena `T` dipinjam untuk masa pakai `'static`, yang tidak pernah berakhir.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // KEAMANAN: 'pinjaman statis menjamin data tidak akan
        // moved/invalidated sampai dijatuhkan (yang tidak pernah).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: ini berarti bahwa setiap impl `CoerceUnsized` yang memungkinkan pemaksaan dari
// tipe yang mengimplikasikan `Deref<Target=impl !Unpin>` ke tipe yang mengimplikasikan `Deref<Target=Unpin>` tidak sehat.
// Namun, impl semacam itu mungkin tidak masuk akal karena alasan lain, jadi kami hanya perlu berhati-hati untuk tidak mengizinkan impl tersebut mendarat di std.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}