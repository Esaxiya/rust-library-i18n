//! Wadah yang bisa berubah-ubah.
//!
//! Keamanan memori Rust didasarkan pada aturan ini: Mengingat objek `T`, hanya mungkin memiliki salah satu dari berikut ini:
//!
//! - Memiliki beberapa referensi (`&T`) yang tidak dapat diubah ke objek (juga dikenal sebagai **aliasing**).
//! - Memiliki satu referensi yang bisa berubah (`&mut T`) ke objek (juga dikenal sebagai **mutability**).
//!
//! Ini diberlakukan oleh kompiler Rust.Namun, ada situasi di mana aturan ini tidak cukup fleksibel.Kadang-kadang diperlukan untuk memiliki banyak referensi ke suatu objek dan belum mengubahnya.
//!
//! Kontainer yang dapat dibagikan ada untuk mengizinkan perubahan dengan cara yang terkontrol, bahkan dengan adanya aliasing.Baik [`Cell<T>`] dan [`RefCell<T>`] memungkinkan melakukan ini dengan cara utas tunggal.
//! Namun, baik `Cell<T>` maupun `RefCell<T>` tidak aman untuk thread (mereka tidak menerapkan [`Sync`]).
//! Jika Anda perlu melakukan aliasing dan mutasi antara beberapa utas, dimungkinkan untuk menggunakan tipe [`Mutex<T>`], [`RwLock<T>`] atau [`atomic`].
//!
//! Nilai dari tipe `Cell<T>` dan `RefCell<T>` dapat dimutasi melalui referensi bersama (mis
//! tipe `&T` umum), sedangkan kebanyakan tipe Rust hanya dapat dimutasi melalui referensi unik (`&mut T`).
//! Kami mengatakan bahwa `Cell<T>` dan `RefCell<T>` memberikan 'mutabilitas interior', berbeda dengan tipe Rust khas yang menunjukkan 'mutabilitas yang diwariskan'.
//!
//! Jenis sel hadir dalam dua jenis: `Cell<T>` dan `RefCell<T>`.`Cell<T>` menerapkan perubahan interior dengan memindahkan nilai masuk dan keluar dari `Cell<T>`.
//! Untuk menggunakan referensi sebagai ganti nilai, seseorang harus menggunakan tipe `RefCell<T>`, memperoleh kunci tulis sebelum bermutasi.`Cell<T>` menyediakan metode untuk mengambil dan mengubah nilai interior saat ini:
//!
//!  - Untuk tipe yang mengimplementasikan [`Copy`], metode [`get`](Cell::get) mengambil nilai interior saat ini.
//!  - Untuk tipe yang menerapkan [`Default`], metode [`take`](Cell::take) menggantikan nilai interior saat ini dengan [`Default::default()`] dan mengembalikan nilai yang diganti.
//!  - Untuk semua tipe, metode [`replace`](Cell::replace) menggantikan nilai interior saat ini dan mengembalikan nilai yang diganti dan metode [`into_inner`](Cell::into_inner) menggunakan `Cell<T>` dan mengembalikan nilai interior.
//!  Selain itu, metode [`set`](Cell::set) menggantikan nilai interior, menghilangkan nilai yang diganti.
//!
//! `RefCell<T>` menggunakan masa pakai Rust untuk mengimplementasikan 'peminjaman dinamis', sebuah proses di mana seseorang dapat mengklaim akses sementara, eksklusif, dan dapat diubah ke nilai dalam.
//! Meminjam untuk `RefCell<T>`s dilacak 'pada waktu proses', tidak seperti jenis referensi asli Rust yang seluruhnya dilacak secara statis, pada waktu kompilasi.
//! Karena pinjaman `RefCell<T>` bersifat dinamis, maka dimungkinkan untuk mencoba meminjam nilai yang sudah dipinjam bersama;ketika ini terjadi itu menghasilkan utas panic.
//!
//! # Kapan memilih mutabilitas interior
//!
//! Mutabilitas bawaan yang lebih umum, di mana seseorang harus memiliki akses unik untuk mengubah nilai, adalah salah satu elemen bahasa utama yang memungkinkan Rust untuk bernalar kuat tentang penunjuk aliasing, secara statis mencegah bug crash.
//! Karena itu, mutabilitas yang diwariskan lebih disukai, dan mutabilitas interior adalah pilihan terakhir.
//! Karena jenis sel memungkinkan mutasi yang seharusnya tidak diizinkan, ada kalanya mutabilitas interior mungkin sesuai, atau bahkan *harus* digunakan, mis.
//!
//! * Memperkenalkan 'inside' mutabilitas dari sesuatu yang tidak berubah
//! * Detail implementasi metode yang tidak dapat diubah secara logis.
//! * Mutasi implementasi [`Clone`].
//!
//! ## Memperkenalkan 'inside' mutabilitas dari sesuatu yang tidak berubah
//!
//! Banyak jenis penunjuk cerdas bersama, termasuk [`Rc<T>`] dan [`Arc<T>`], menyediakan wadah yang dapat digandakan dan dibagikan di antara banyak pihak.
//! Karena nilai yang terkandung dapat berupa multi-alias, nilai tersebut hanya dapat dipinjam dengan `&`, bukan `&mut`.
//! Tanpa sel, mustahil untuk mengubah data di dalam pointer pintar ini sama sekali.
//!
//! Maka sangat umum untuk meletakkan `RefCell<T>` di dalam tipe penunjuk bersama untuk memperkenalkan kembali mutabilitas:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Buat blok baru untuk membatasi cakupan pinjaman dinamis
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Perhatikan bahwa jika kita tidak membiarkan peminjaman cache sebelumnya keluar dari ruang lingkup maka peminjaman berikutnya akan menyebabkan thread dinamis panic.
//!     //
//!     // Ini adalah bahaya utama menggunakan `RefCell`.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Perhatikan bahwa contoh ini menggunakan `Rc<T>` dan bukan `Arc<T>`.`RefCell<T>`s untuk skenario single-threaded.Pertimbangkan untuk menggunakan [`RwLock<T>`] atau [`Mutex<T>`] jika Anda memerlukan mutabilitas bersama dalam situasi multi-threaded.
//!
//! ## Detail implementasi metode yang tidak dapat diubah secara logis
//!
//! Kadang-kadang mungkin diinginkan untuk tidak mengekspos di API bahwa ada mutasi yang terjadi "under the hood".
//! Ini mungkin karena secara logis operasi tersebut tidak dapat diubah, tetapi misalnya, caching memaksa implementasi untuk melakukan mutasi;atau karena Anda harus menggunakan mutasi untuk menerapkan metode trait yang pada awalnya ditentukan untuk menggunakan `&self`.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Perhitungan mahal dilakukan di sini
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## Mutasi implementasi `Clone`
//!
//! Ini hanyalah kasus khusus, tetapi umum, dari sebelumnya: menyembunyikan mutabilitas untuk operasi yang tampaknya tidak dapat diubah.
//! Metode [`clone`](Clone::clone) diharapkan tidak mengubah nilai sumber, dan dinyatakan menggunakan `&self`, bukan `&mut self`.
//! Oleh karena itu, setiap mutasi yang terjadi dalam metode `clone` harus menggunakan tipe sel.
//! Misalnya, [`Rc<T>`] mempertahankan jumlah referensinya dalam `Cell<T>`.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// Lokasi memori yang bisa berubah.
///
/// # Examples
///
/// Dalam contoh ini, Anda dapat melihat bahwa `Cell<T>` mengaktifkan mutasi di dalam struct yang tidak dapat diubah.
/// Dengan kata lain, ini mengaktifkan "interior mutability".
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // EROR: `my_struct` tidak dapat diubah
/// // my_struct.regular_field =nilai_baru;
///
/// // KARYA: meskipun `my_struct` tidak dapat diubah, `special_field` adalah `Cell`,
/// // yang selalu bisa dimutasi
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Lihat [module-level documentation](self) untuk lebih lanjut.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// Membuat `Cell<T>`, dengan nilai `Default` untuk T.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Membuat `Cell` baru yang berisi nilai yang diberikan.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Menetapkan nilai yang terkandung.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Menukar nilai dari dua sel.
    /// Perbedaan dengan `std::mem::swap` adalah fungsi ini tidak memerlukan referensi `&mut`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // KEAMANAN: Ini bisa berisiko jika dipanggil dari utas terpisah, tetapi `Cell`
        // adalah `!Sync` jadi ini tidak akan terjadi.
        // Ini juga tidak akan membatalkan petunjuk apa pun karena `Cell` memastikan tidak ada lagi yang mengarah ke salah satu dari `Sel` ini.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Mengganti nilai tertampung dengan `val`, dan mengembalikan nilai tertampung yang lama.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // KEAMANAN: Ini dapat menyebabkan balapan data jika dipanggil dari utas terpisah,
        // tetapi `Cell` adalah `!Sync` jadi ini tidak akan terjadi.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Buka bungkus nilainya.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Mengembalikan salinan dari nilai yang terkandung.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // KEAMANAN: Ini dapat menyebabkan balapan data jika dipanggil dari utas terpisah,
        // tetapi `Cell` adalah `!Sync` jadi ini tidak akan terjadi.
        unsafe { *self.value.get() }
    }

    /// Memperbarui nilai yang terkandung menggunakan fungsi dan mengembalikan nilai baru.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Mengembalikan penunjuk mentah ke data yang mendasari dalam sel ini.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Mengembalikan referensi yang bisa berubah ke data yang mendasarinya.
    ///
    /// Panggilan ini saling meminjam `Cell` (pada waktu kompilasi) yang menjamin bahwa kita memiliki satu-satunya referensi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Mengembalikan `&Cell<T>` dari `&mut T`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // KEAMANAN: `&mut` memastikan akses unik.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Mengambil nilai sel, meninggalkan `Default::default()` di tempatnya.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// Mengembalikan `&[Cell<T>]` dari `&Cell<[T]>`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // KEAMANAN: `Cell<T>` memiliki tata letak memori yang sama dengan `T`.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Lokasi memori yang bisa berubah dengan aturan pinjam yang diperiksa secara dinamis
///
/// Lihat [module-level documentation](self) untuk lebih lanjut.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// Kesalahan dikembalikan oleh [`RefCell::try_borrow`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// Kesalahan dikembalikan oleh [`RefCell::try_borrow_mut`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Nilai positif mewakili jumlah `Ref` aktif.Nilai negatif mewakili jumlah `RefMut` aktif.
// Beberapa `RefMut` hanya dapat aktif dalam satu waktu jika mengacu pada komponen `RefCell` yang berbeda dan tidak tumpang tindih (misalnya, rentang potongan yang berbeda).
//
// `Ref` dan `RefMut` keduanya berukuran dua kata, sehingga kemungkinan besar `Ref` atau`RefMut` tidak akan pernah cukup untuk meluap setengah dari rentang `usize`.
// Jadi, `BorrowFlag` mungkin tidak akan pernah overflow atau underflow.
// Namun, ini bukan jaminan, karena program patologis dapat berulang kali membuat dan kemudian mem::forget `Ref`s atau`RefMut`s.
// Dengan demikian, semua kode harus secara eksplisit memeriksa overflow dan underflow untuk menghindari ketidakamanan, atau setidaknya berperilaku dengan benar jika terjadi overflow atau underflow (misalnya, lihat BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// Membuat `RefCell` baru yang berisi `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// Mengkonsumsi `RefCell`, mengembalikan nilai yang dibungkus.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Karena fungsi ini mengambil nilai `self` (`RefCell`), kompilator secara statis memverifikasi bahwa saat ini tidak dipinjam.
        //
        self.value.into_inner()
    }

    /// Mengganti nilai yang dibungkus dengan yang baru, mengembalikan nilai lama, tanpa deinisialisasi salah satunya.
    ///
    ///
    /// Fungsi ini sesuai dengan [`std::mem::replace`](../mem/fn.replace.html).
    ///
    /// # Panics
    ///
    /// Panics jika nilainya saat ini dipinjam.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Mengganti nilai yang dibungkus dengan yang baru yang dihitung dari `f`, mengembalikan nilai lama, tanpa mendeinisialisasi salah satunya.
    ///
    ///
    /// # Panics
    ///
    /// Panics jika nilainya saat ini dipinjam.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Menukar nilai yang dibungkus `self` dengan nilai yang dibungkus `other`, tanpa deinisialisasi salah satunya.
    ///
    ///
    /// Fungsi ini sesuai dengan [`std::mem::swap`](../mem/fn.swap.html).
    ///
    /// # Panics
    ///
    /// Panics jika nilai di `RefCell` saat ini dipinjam.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Meminjam nilai yang dibungkus secara permanen.
    ///
    /// Peminjaman berlangsung sampai `Ref` yang dikembalikan keluar dari ruang lingkup.
    /// Beberapa pinjaman yang tidak dapat diubah dapat diambil pada saat yang bersamaan.
    ///
    /// # Panics
    ///
    /// Panics jika nilai saat ini bisa dipinjam.
    /// Untuk varian non-panik, gunakan [`try_borrow`](#method.try_borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// Contoh panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Meminjam nilai yang dibungkus secara permanen, mengembalikan kesalahan jika nilai saat ini bisa dipinjam.
    ///
    ///
    /// Peminjaman berlangsung sampai `Ref` yang dikembalikan keluar dari ruang lingkup.
    /// Beberapa pinjaman yang tidak dapat diubah dapat diambil pada saat yang bersamaan.
    ///
    /// Ini adalah varian [`borrow`](#method.borrow) yang tidak panik.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // KEAMANAN: `BorrowRef` memastikan bahwa hanya ada akses yang tidak dapat diubah
            // dengan nilai saat dipinjam.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Saling meminjam nilai yang dibungkus.
    ///
    /// Peminjaman berlangsung hingga `RefMut` yang dikembalikan atau semua `RefMut` yang diturunkan darinya keluar dari cakupan.
    ///
    /// Nilainya tidak dapat dipinjam selama pinjaman ini aktif.
    ///
    /// # Panics
    ///
    /// Panics jika nilainya saat ini dipinjam.
    /// Untuk varian non-panik, gunakan [`try_borrow_mut`](#method.try_borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// Contoh panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Mungkin meminjam nilai yang dibungkus, mengembalikan kesalahan jika nilainya saat ini dipinjam.
    ///
    ///
    /// Peminjaman berlangsung hingga `RefMut` yang dikembalikan atau semua `RefMut` yang diturunkan darinya keluar dari cakupan.
    /// Nilainya tidak dapat dipinjam selama pinjaman ini aktif.
    ///
    /// Ini adalah varian [`borrow_mut`](#method.borrow_mut) yang tidak panik.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // KEAMANAN: `BorrowRef` menjamin akses unik.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Mengembalikan penunjuk mentah ke data yang mendasari dalam sel ini.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Mengembalikan referensi yang bisa berubah ke data yang mendasarinya.
    ///
    /// Panggilan ini saling meminjam `RefCell` (pada waktu kompilasi) jadi tidak perlu pemeriksaan dinamis.
    ///
    /// Namun berhati-hatilah: metode ini mengharapkan `self` dapat berubah, yang umumnya tidak terjadi saat menggunakan `RefCell`.
    ///
    /// Lihatlah metode [`borrow_mut`] sebagai gantinya jika `self` tidak bisa berubah.
    ///
    /// Juga, perlu diketahui bahwa metode ini hanya untuk keadaan khusus dan biasanya bukan yang Anda inginkan.
    /// Jika ragu, gunakan [`borrow_mut`] sebagai gantinya.
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Batalkan efek pelindung bocor pada status pinjaman `RefCell`.
    ///
    /// Panggilan ini mirip dengan [`get_mut`] tetapi lebih terspesialisasi.
    /// Ini meminjam `RefCell` untuk memastikan tidak ada pinjaman dan kemudian menyetel ulang pelacakan negara bagian dari pinjaman bersama.
    /// Ini relevan jika beberapa pinjaman `Ref` atau `RefMut` telah bocor.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Meminjam nilai yang dibungkus secara permanen, mengembalikan kesalahan jika nilai saat ini bisa dipinjam.
    ///
    /// # Safety
    ///
    /// Tidak seperti `RefCell::borrow`, metode ini tidak aman karena tidak mengembalikan `Ref`, sehingga membiarkan flag pinjam tidak tersentuh.
    /// Meminjam `RefCell` secara bersamaan saat referensi yang dikembalikan oleh metode ini masih aktif adalah perilaku yang tidak ditentukan.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // KESELAMATAN: Kami memeriksa bahwa tidak ada yang aktif menulis sekarang, tetapi kenyataannya begitu
            // tanggung jawab pemanggil untuk memastikan bahwa tidak ada yang menulis sampai referensi yang dikembalikan tidak lagi digunakan.
            // Selain itu, `self.value.get()` mengacu pada nilai yang dimiliki oleh `self` dan dengan demikian dijamin valid selama masa pakai `self`.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// Mengambil nilai yang dibungkus, meninggalkan `Default::default()` di tempatnya.
    ///
    /// # Panics
    ///
    /// Panics jika nilainya saat ini dipinjam.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics jika nilai saat ini bisa dipinjam.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// Membuat `RefCell<T>`, dengan nilai `Default` untuk T.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics jika nilai di `RefCell` saat ini dipinjam.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics jika nilai di `RefCell` saat ini dipinjam.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics jika nilai di `RefCell` saat ini dipinjam.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics jika nilai di `RefCell` saat ini dipinjam.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics jika nilai di `RefCell` saat ini dipinjam.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics jika nilai di `RefCell` saat ini dipinjam.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics jika nilai di `RefCell` saat ini dipinjam.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Penambahan pinjaman dapat menghasilkan nilai non-membaca (<=0) dalam kasus berikut:
            // 1. Itu <0, yaitu ada pinjaman tertulis, jadi kami tidak dapat mengizinkan pinjaman baca karena aturan aliasing referensi Rust
            // 2.
            // Itu adalah isize::MAX (jumlah maksimum pinjaman membaca) dan meluap ke isize::MIN (jumlah maksimum pinjaman tertulis) jadi kami tidak dapat mengizinkan pinjaman baca tambahan karena isize tidak dapat mewakili begitu banyak pinjaman baca (ini hanya dapat terjadi jika Anda mem::forget lebih dari sejumlah kecil `Ref`, yang bukan praktik yang baik)
            //
            //
            //
            //
            None
        } else {
            // Penambahan pinjaman dapat menghasilkan nilai pembacaan (> 0) dalam kasus berikut:
            // 1. Itu=0, yaitu tidak dipinjam, dan kami mengambil pinjaman baca pertama
            // 2. Itu> 0 dan <isize::MAX, yaitu
            // ada pinjaman baca, dan isize cukup besar untuk mewakili memiliki satu pinjaman baca lagi
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Karena referensi ini ada, kita tahu bahwa bendera pinjam adalah pinjaman baca.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Cegah konter peminjaman agar tidak meluap menjadi pinjaman tertulis.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Membungkus referensi pinjaman ke nilai dalam kotak `RefCell`.
/// Jenis pembungkus untuk nilai pinjaman yang tidak dapat diubah dari `RefCell<T>`.
///
/// Lihat [module-level documentation](self) untuk lebih lanjut.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Menyalin `Ref`.
    ///
    /// `RefCell` sudah dipinjam secara permanen, jadi ini tidak bisa gagal.
    ///
    /// Ini adalah fungsi terkait yang perlu digunakan sebagai `Ref::clone(...)`.
    /// Implementasi `Clone` atau metode akan mengganggu penggunaan `r.borrow().clone()` secara luas untuk mengkloning konten `RefCell`.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Membuat `Ref` baru untuk komponen data yang dipinjam.
    ///
    /// `RefCell` sudah dipinjam secara permanen, jadi ini tidak bisa gagal.
    ///
    /// Ini adalah fungsi terkait yang perlu digunakan sebagai `Ref::map(...)`.
    /// Suatu metode akan mengganggu metode dengan nama yang sama pada konten `RefCell` yang digunakan melalui `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Membuat `Ref` baru untuk komponen opsional dari data yang dipinjam.
    /// Pelindung asli dikembalikan sebagai `Err(..)` jika penutupan mengembalikan `None`.
    ///
    /// `RefCell` sudah dipinjam secara permanen, jadi ini tidak bisa gagal.
    ///
    /// Ini adalah fungsi terkait yang perlu digunakan sebagai `Ref::filter_map(...)`.
    /// Suatu metode akan mengganggu metode dengan nama yang sama pada konten `RefCell` yang digunakan melalui `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Membagi `Ref` menjadi beberapa `Ref` untuk berbagai komponen data yang dipinjam.
    ///
    /// `RefCell` sudah dipinjam secara permanen, jadi ini tidak bisa gagal.
    ///
    /// Ini adalah fungsi terkait yang perlu digunakan sebagai `Ref::map_split(...)`.
    /// Suatu metode akan mengganggu metode dengan nama yang sama pada konten `RefCell` yang digunakan melalui `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Ubah menjadi referensi ke data yang mendasarinya.
    ///
    /// `RefCell` yang mendasarinya tidak akan pernah bisa dipinjam lagi dan akan selalu tampak sudah dipinjam selamanya.
    ///
    /// Bukan ide yang baik untuk membocorkan lebih dari sejumlah referensi yang konstan.
    /// `RefCell` dapat dipinjam lagi secara permanen jika hanya sejumlah kecil kebocoran yang terjadi secara total.
    ///
    /// Ini adalah fungsi terkait yang perlu digunakan sebagai `Ref::leak(...)`.
    /// Suatu metode akan mengganggu metode dengan nama yang sama pada konten `RefCell` yang digunakan melalui `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // Dengan melupakan Referensi ini, kami memastikan bahwa konter peminjaman di RefCell tidak dapat kembali ke UNUSED selama masa hidup `'b`.
        // Menyetel ulang status pelacakan referensi akan membutuhkan referensi unik ke RefCell yang dipinjam.
        // Tidak ada referensi yang bisa berubah lebih lanjut yang dapat dibuat dari sel asli.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Membuat `RefMut` baru untuk komponen data yang dipinjam, misalnya varian enum.
    ///
    /// `RefCell` sudah bisa dipinjam, jadi ini tidak bisa gagal.
    ///
    /// Ini adalah fungsi terkait yang perlu digunakan sebagai `RefMut::map(...)`.
    /// Suatu metode akan mengganggu metode dengan nama yang sama pada konten `RefCell` yang digunakan melalui `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): perbaiki pinjam-cek
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Membuat `RefMut` baru untuk komponen opsional dari data yang dipinjam.
    /// Pelindung asli dikembalikan sebagai `Err(..)` jika penutupan mengembalikan `None`.
    ///
    /// `RefCell` sudah bisa dipinjam, jadi ini tidak bisa gagal.
    ///
    /// Ini adalah fungsi terkait yang perlu digunakan sebagai `RefMut::filter_map(...)`.
    /// Suatu metode akan mengganggu metode dengan nama yang sama pada konten `RefCell` yang digunakan melalui `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): perbaiki pinjam-cek
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // SAFETY: fungsi memegang referensi eksklusif selama durasi
        // dari panggilannya melalui `orig`, dan penunjuk hanya tidak direferensikan di dalam pemanggilan fungsi yang tidak pernah mengizinkan referensi eksklusif untuk melarikan diri.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // KEAMANAN: sama seperti di atas.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Membagi `RefMut` menjadi beberapa `RefMut` untuk berbagai komponen dari data yang dipinjam.
    ///
    /// `RefCell` yang mendasari akan tetap dipinjam sampai kedua `RefMut` yang dikembalikan keluar dari ruang lingkup.
    ///
    /// `RefCell` sudah bisa dipinjam, jadi ini tidak bisa gagal.
    ///
    /// Ini adalah fungsi terkait yang perlu digunakan sebagai `RefMut::map_split(...)`.
    /// Suatu metode akan mengganggu metode dengan nama yang sama pada konten `RefCell` yang digunakan melalui `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Ubah menjadi referensi yang bisa berubah ke data yang mendasarinya.
    ///
    /// `RefCell` yang mendasarinya tidak dapat dipinjam lagi dan akan selalu tampak sudah saling meminjam, menjadikan referensi yang dikembalikan satu-satunya ke interior.
    ///
    ///
    /// Ini adalah fungsi terkait yang perlu digunakan sebagai `RefMut::leak(...)`.
    /// Suatu metode akan mengganggu metode dengan nama yang sama pada konten `RefCell` yang digunakan melalui `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Dengan melupakan BorrowRefMut ini, kami memastikan bahwa loket peminjaman di RefCell tidak dapat kembali ke UNUSED dalam masa hidup `'b`.
        // Menyetel ulang status pelacakan referensi akan membutuhkan referensi unik ke RefCell yang dipinjam.
        // Tidak ada referensi lebih lanjut yang dapat dibuat dari sel asli dalam masa hidup itu, menjadikan pinjaman saat ini satu-satunya referensi untuk sisa masa pakai.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: Tidak seperti BorrowRefMut::clone, new dipanggil untuk membuat inisial
        // referensi yang bisa berubah, sehingga saat ini tidak boleh ada referensi yang ada.
        // Jadi, sementara clone menambah refcount yang bisa berubah, di sini kami secara eksplisit hanya mengizinkan perpindahan dari UNUSED ke UNUSED, 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // Mengkloning `BorrowRefMut`.
    //
    // Ini hanya valid jika setiap `BorrowRefMut` digunakan untuk melacak referensi yang dapat berubah ke rentang yang berbeda dan tidak tumpang tindih dari objek asli.
    //
    // Ini tidak ada dalam Clone impl sehingga kode tidak memanggil ini secara implisit.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Cegah konter peminjaman dari kekurangan arus.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// Jenis pembungkus untuk nilai yang bisa dipinjam dari `RefCell<T>`.
///
/// Lihat [module-level documentation](self) untuk lebih lanjut.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Inti primitif untuk mutabilitas interior di Rust.
///
/// Jika Anda memiliki referensi `&T`, biasanya di Rust kompilator melakukan pengoptimalan berdasarkan pengetahuan yang ditunjukkan `&T` ke data yang tidak dapat diubah.Mutasi data tersebut, misalnya melalui alias atau dengan mentransmutasi `&T` menjadi `&mut T`, dianggap sebagai perilaku yang tidak terdefinisi.
/// `UnsafeCell<T>` menyisih dari jaminan keabadian untuk `&T`: referensi bersama `&UnsafeCell<T>` mungkin mengarah ke data yang sedang dimutasi.Ini disebut "interior mutability".
///
/// Semua jenis lain yang memungkinkan mutabilitas internal, seperti `Cell<T>` dan `RefCell<T>`, secara internal menggunakan `UnsafeCell` untuk menggabungkan datanya.
///
/// Perhatikan bahwa hanya jaminan keabadian untuk referensi bersama yang dipengaruhi oleh `UnsafeCell`.Jaminan keunikan untuk referensi yang bisa berubah tidak terpengaruh.Tidak ada *cara* legal untuk mendapatkan aliasing `&mut`, bahkan dengan `UnsafeCell<T>`.
///
/// API `UnsafeCell` sendiri secara teknis sangat sederhana: [`.get()`] memberi Anda `*mut T` penunjuk mentah ke isinya.Terserah _you_ sebagai desainer abstraksi untuk menggunakan penunjuk mentah itu dengan benar.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// Aturan aliasing Rust yang tepat agak berubah-ubah, tetapi poin utamanya tidak diperdebatkan:
///
/// - Jika Anda membuat referensi aman dengan seumur hidup `'a` (baik referensi `&T` atau `&mut T`) yang dapat diakses oleh kode aman (misalnya, karena Anda mengembalikannya), maka Anda tidak boleh mengakses data dengan cara apa pun yang bertentangan dengan referensi untuk sisanya. dari `'a`.
/// Misalnya, ini berarti bahwa jika Anda mengambil `*mut T` dari `UnsafeCell<T>` dan mentransmisikannya ke `&T`, maka data di `T` harus tetap tidak dapat diubah (modulo semua data `UnsafeCell` yang ditemukan dalam `T`, tentu saja) hingga masa pakai referensi tersebut berakhir.
/// Demikian pula, jika Anda membuat referensi `&mut T` yang dirilis ke kode aman, maka Anda tidak boleh mengakses data dalam `UnsafeCell` hingga referensi tersebut kedaluwarsa.
///
/// - Sepanjang waktu, Anda harus menghindari balapan data.Jika beberapa utas memiliki akses ke `UnsafeCell` yang sama, maka penulisan apa pun harus memiliki hubungan terjadi-sebelum yang tepat ke semua akses lain (atau gunakan atomics).
///
/// Untuk membantu dengan desain yang tepat, skenario berikut secara eksplisit dinyatakan legal untuk kode utas tunggal:
///
/// 1. Referensi `&T` dapat dirilis ke kode aman dan di sana dapat hidup berdampingan dengan referensi `&T` lainnya, tetapi tidak dengan `&mut T`
///
/// 2. Referensi `&mut T` dapat dirilis ke kode aman asalkan tidak ada `&mut T` atau `&T` lain yang hidup berdampingan dengannya.`&mut T` harus selalu unik.
///
/// Perhatikan bahwa sementara memutasikan konten `&UnsafeCell<T>` (meskipun referensi `&UnsafeCell<T>` lain alias sel) tidak masalah (asalkan Anda menerapkan invarian di atas dengan cara lain), masih belum ditentukan perilaku untuk memiliki beberapa alias `&mut UnsafeCell<T>`.
/// Artinya, `UnsafeCell` adalah pembungkus yang dirancang untuk memiliki interaksi khusus dengan _shared_ accesses (_i.e._, melalui referensi `&UnsafeCell<_>`);tidak ada keajaiban apa pun saat berurusan dengan _exclusive_ accesses (_e.g._, melalui `&mut UnsafeCell<_>`): baik sel maupun nilai yang dibungkus tidak dapat dialiasi selama durasi pinjaman `&mut` tersebut.
///
/// Ini dipamerkan oleh pengakses [`.get_mut()`], yaitu _safe_ getter yang menghasilkan `&mut T`.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Berikut adalah contoh yang menunjukkan cara mengubah konten `UnsafeCell<_>` meskipun ada beberapa referensi yang aliasing sel:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Dapatkan beberapa/referensi bersama ke `x` yang sama.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // KEAMANAN: dalam cakupan ini tidak ada referensi lain ke konten `x`,
///     // jadi milik kita unik secara efektif.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- meminjam-+
///     *p1_exclusive += 27; // |
/// } // <---------- tidak bisa melampaui titik ini -------------------+
///
/// unsafe {
///     // KEAMANAN: dalam lingkup ini tidak ada yang berharap memiliki akses eksklusif ke konten `x`,
///     // sehingga kami dapat memiliki beberapa akses bersama secara bersamaan.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// Contoh berikut menunjukkan fakta bahwa akses eksklusif ke `UnsafeCell<T>` menyiratkan akses eksklusif ke `T`-nya:
///
/// ```rust
/// #![forbid(unsafe_code)] // dengan akses eksklusif,
///                         // `UnsafeCell` adalah pembungkus no-op transparan, jadi tidak perlu `unsafe` di sini.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Dapatkan referensi unik yang diperiksa waktu kompilasi untuk `x`.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Dengan referensi eksklusif, kami dapat memutasi konten secara gratis.
/// *p_unique.get_mut() = 0;
/// // Atau, dengan kata lain:
/// x = UnsafeCell::new(0);
///
/// // Saat kami memiliki nilainya, kami dapat mengekstrak isinya secara gratis.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Membuat instance baru dari `UnsafeCell` yang akan membungkus nilai yang ditentukan.
    ///
    ///
    /// Semua akses ke nilai dalam melalui metode adalah `unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Buka bungkus nilainya.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Mendapat penunjuk yang bisa berubah ke nilai yang dibungkus.
    ///
    /// Ini dapat dilemparkan ke penunjuk apa pun.
    /// Pastikan bahwa aksesnya unik (tidak ada referensi aktif, dapat diubah atau tidak) saat mentransmisi ke `&mut T`, dan pastikan tidak ada mutasi atau alias yang dapat diubah yang terjadi saat mentransmisi ke `&T`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // Kami hanya dapat mentransmisikan penunjuk dari `UnsafeCell<T>` ke `T` karena #[repr(transparent)].
        // Ini mengeksploitasi status khusus libstd, tidak ada jaminan untuk kode pengguna bahwa ini akan bekerja di versi future dari kompilator!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Mengembalikan referensi yang bisa berubah ke data yang mendasarinya.
    ///
    /// Panggilan ini saling meminjam `UnsafeCell` (pada waktu kompilasi) yang menjamin bahwa kita memiliki satu-satunya referensi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Mendapat penunjuk yang bisa berubah ke nilai yang dibungkus.
    /// Perbedaan dengan [`get`] adalah fungsi ini menerima pointer mentah, yang berguna untuk menghindari pembuatan referensi sementara.
    ///
    /// Hasilnya dapat dilemparkan ke penunjuk dalam bentuk apa pun.
    /// Pastikan bahwa aksesnya unik (tidak ada referensi aktif, dapat diubah atau tidak) saat mentransmisi ke `&mut T`, dan pastikan tidak ada mutasi atau alias yang dapat diubah yang terjadi saat mentransmisi ke `&T`.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// Inisialisasi `UnsafeCell` secara bertahap memerlukan `raw_get`, karena memanggil `get` akan memerlukan referensi ke data yang tidak diinisialisasi:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // Kami hanya dapat mentransmisikan penunjuk dari `UnsafeCell<T>` ke `T` karena #[repr(transparent)].
        // Ini mengeksploitasi status khusus libstd, tidak ada jaminan untuk kode pengguna bahwa ini akan bekerja di versi future dari kompilator!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// Membuat `UnsafeCell`, dengan nilai `Default` untuk T.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}