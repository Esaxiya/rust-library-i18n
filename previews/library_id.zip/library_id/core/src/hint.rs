#![stable(feature = "core_hint", since = "1.27.0")]

//! Petunjuk untuk kompiler yang mempengaruhi bagaimana kode harus dikeluarkan atau dioptimalkan.
//! Petunjuk mungkin berupa waktu kompilasi atau runtime.

use crate::intrinsics;

/// Memberi tahu compiler bahwa titik dalam kode ini tidak dapat dijangkau, sehingga memungkinkan pengoptimalan lebih lanjut.
///
/// # Safety
///
/// Mencapai fungsi ini sepenuhnya *perilaku tidak terdefinisi*(UB).Secara khusus, kompilator mengasumsikan bahwa semua UB tidak boleh terjadi, dan oleh karena itu akan menghilangkan semua cabang yang menjangkau panggilan ke `unreachable_unchecked()`.
///
/// Seperti semua contoh UB, jika asumsi ini ternyata salah, yaitu, panggilan `unreachable_unchecked()` sebenarnya dapat dijangkau di antara semua aliran kontrol yang mungkin, kompilator akan menerapkan strategi pengoptimalan yang salah, dan terkadang bahkan merusak kode yang tampaknya tidak terkait, menyebabkan kesulitan-masalah untuk men-debug.
///
///
/// Gunakan fungsi ini hanya jika Anda dapat membuktikan bahwa kode tidak akan pernah memanggilnya.
/// Jika tidak, pertimbangkan untuk menggunakan makro [`unreachable!`], yang tidak mengizinkan pengoptimalan tetapi akan panic saat dijalankan.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` selalu positif (bukan nol), maka `checked_div` tidak akan pernah mengembalikan `None`.
/////
///     // Oleh karena itu, branch lain tidak dapat dijangkau.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // KEAMANAN: kontrak keamanan untuk `intrinsics::unreachable` harus
    // dijunjung oleh pemanggil.
    unsafe { intrinsics::unreachable() }
}

/// Memancarkan instruksi mesin untuk memberi sinyal pada prosesor bahwa prosesor sedang berjalan dalam putaran-putaran tunggu-sibuk ("kunci putar").
///
/// Setelah menerima sinyal putaran-putaran, prosesor dapat mengoptimalkan perilakunya dengan, misalnya, menghemat daya atau mengganti utas hyper.
///
/// Fungsi ini berbeda dari [`thread::yield_now`] yang langsung menghasilkan penjadwal sistem, sedangkan `spin_loop` tidak berinteraksi dengan sistem operasi.
///
/// Kasus penggunaan umum untuk `spin_loop` adalah mengimplementasikan pemintalan optimis terbatas dalam loop CAS dalam sinkronisasi primitif.
/// Untuk menghindari masalah seperti inversi prioritas, sangat disarankan agar putaran putaran dihentikan setelah sejumlah iterasi yang terbatas dan syscall pemblokiran yang sesuai dibuat.
///
///
/// **Catatan**: Pada platform yang tidak mendukung penerimaan petunjuk spin-loop, fungsi ini tidak melakukan apa pun.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // Nilai atom bersama yang akan digunakan utas untuk berkoordinasi
/// let live = Arc::new(AtomicBool::new(false));
///
/// // Di thread latar belakang, kami akhirnya akan menyetel nilainya
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Lakukan beberapa pekerjaan, lalu buat nilainya menjadi hidup
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // Kembali ke utas kami saat ini, kami menunggu nilainya ditetapkan
/// while !live.load(Ordering::Acquire) {
///     // Putaran putaran adalah petunjuk bagi CPU bahwa kita sedang menunggu, tetapi mungkin tidak terlalu lama
/////
///     hint::spin_loop();
/// }
///
/// // Nilainya sekarang sudah ditetapkan
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // KEAMANAN: atribut `cfg` memastikan bahwa kami hanya menjalankan ini pada target x86.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // KEAMANAN: atribut `cfg` memastikan bahwa kami hanya menjalankan ini pada target x86_64.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // KEAMANAN: atribut `cfg` memastikan bahwa kami hanya menjalankan ini pada target aarch64.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // KEAMANAN: attr `cfg` memastikan bahwa kami hanya mengeksekusi ini pada target lengan
            // dengan dukungan fitur v6.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// Fungsi identitas yang *__ mengisyaratkan __* ke kompiler untuk menjadi pesimis maksimal tentang apa yang bisa dilakukan `black_box`.
///
/// Tidak seperti [`std::convert::identity`], kompilator Rust didorong untuk mengasumsikan bahwa `black_box` dapat menggunakan `dummy` dengan cara valid apa pun yang memungkinkan kode Rust tanpa memperkenalkan perilaku tidak terdefinisi dalam kode panggilan.
///
/// Properti ini membuat `black_box` berguna untuk menulis kode di mana pengoptimalan tertentu tidak diinginkan, seperti tolok ukur.
///
/// Namun perlu dicatat, bahwa `black_box` hanya (dan hanya dapat) disediakan dengan basis "best-effort".Sejauh mana itu dapat memblokir pengoptimalan dapat bervariasi tergantung pada platform dan backend kode-gen yang digunakan.
/// Program tidak dapat mengandalkan `black_box` untuk *kebenaran* dengan cara apa pun.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // Kita perlu "use" argumen dalam beberapa cara LLVM tidak dapat melakukan introspeksi, dan pada target yang mendukungnya kita biasanya dapat memanfaatkan perakitan inline untuk melakukan ini.
    // Interpretasi LLVM tentang perakitan inline adalah kotak hitam.
    // Ini bukan implementasi terbaik karena mungkin melakukan deoptimisasi lebih dari yang kita inginkan, tetapi sejauh ini cukup baik.
    //
    //

    #[cfg(not(miri))] // Ini hanya petunjuk, jadi tidak apa-apa untuk melewati di Miri.
    // KEAMANAN: perakitan inline adalah tanpa operasi.
    unsafe {
        // FIXME: Tidak dapat menggunakan `asm!` karena tidak mendukung MIPS dan arsitektur lainnya.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}