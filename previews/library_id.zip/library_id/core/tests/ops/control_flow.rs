use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Ini bukan area permukaan yang stabil, tetapi membantu menjaga `?` tetap murah di antara keduanya, meskipun LLVM tidak selalu dapat memanfaatkannya saat ini.
    //
    // (Sayangnya Hasil dan Opsi tidak konsisten, jadi ControlFlow tidak dapat mencocokkan keduanya.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}