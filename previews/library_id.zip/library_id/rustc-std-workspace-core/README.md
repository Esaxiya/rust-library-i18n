# `rustc-std-workspace-core` crate

crate ini adalah crate kosong dan kosong yang hanya bergantung pada `libcore` dan mengekspor ulang semua isinya.
crate adalah inti dari pemberdayaan perpustakaan standar untuk bergantung pada crates dari crates.io

Crates di crates.io yang bergantung pada pustaka standar bergantung pada `rustc-std-workspace-core` crate dari crates.io, yang kosong.

Kami menggunakan `[patch]` untuk menimpanya ke crate ini di repositori ini.
Akibatnya, crates di crates.io akan menarik ketergantungan edge ke `libcore`, versi yang ditentukan dalam repositori ini.
Itu harus menarik semua tepi ketergantungan untuk memastikan Cargo membangun crates dengan sukses!

Perhatikan bahwa crates pada crates.io harus bergantung pada crate ini dengan nama `core` agar semuanya bekerja dengan benar.Untuk melakukan itu mereka dapat menggunakan:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Melalui penggunaan kunci `package`, crate diubah namanya menjadi `core`, artinya akan terlihat seperti

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

ketika Cargo memanggil kompilator, memenuhi direktif `extern crate core` implisit yang diinjeksikan oleh kompilator.




