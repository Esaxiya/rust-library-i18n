use backtrace::Backtrace;

// Nama modul 50 karakter
mod _234567890_234567890_234567890_234567890_234567890 {
    // Nama struct 50 karakter
    #[allow(non_camel_case_types)]
    pub struct _234567890_234567890_234567890_234567890_234567890<T>(T);
    impl<T> _234567890_234567890_234567890_234567890_234567890<T> {
        #[allow(dead_code)]
        pub fn new() -> crate::Backtrace {
            crate::Backtrace::new()
        }
    }
}

// Nama fungsi yang panjang harus dipotong menjadi (MAX_SYM_NAME, 1) karakter.
// Hanya jalankan pengujian ini untuk pnidui, karena gnu mencetak "<no info>" untuk semua bingkai.
#[test]
#[cfg(all(windows, target_env = "msvc"))]
fn test_long_fn_name() {
    use _234567890_234567890_234567890_234567890_234567890::_234567890_234567890_234567890_234567890_234567890 as S;

    // 10 pengulangan nama struct, jadi nama fungsi yang memenuhi syarat minimal 10 *(50 + 50)* 2=2000 karakter.
    //
    // Ini sebenarnya lebih lama karena juga menyertakan `::`, `<>` dan nama modul saat ini
    //
    let bt = S::<S<S<S<S<S<S<S<S<S<i32>>>>>>>>>>::new();
    println!("{:?}", bt);

    let mut found_long_name_frame = false;

    for frame in bt.frames() {
        let symbols = frame.symbols();
        if symbols.is_empty() {
            continue;
        }

        if let Some(function_name) = symbols[0].name() {
            let function_name = function_name.as_str().unwrap();
            if function_name.contains("::_234567890_234567890_234567890_234567890_234567890") {
                found_long_name_frame = true;
                assert!(function_name.len() > 200);
            }
        }
    }

    assert!(found_long_name_frame);
}