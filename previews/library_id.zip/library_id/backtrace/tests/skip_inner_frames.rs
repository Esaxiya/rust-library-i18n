use backtrace::Backtrace;

// Tes ini hanya bekerja pada platform yang memiliki fungsi `symbol_address` yang berfungsi untuk frame yang melaporkan alamat awal sebuah simbol.
// Akibatnya, ini hanya diaktifkan di beberapa platform.
//
const ENABLED: bool = cfg!(all(
    // Windows belum benar-benar diuji, dan OSX tidak mendukung untuk benar-benar menemukan bingkai penutup, jadi nonaktifkan ini
    //
    target_os = "linux",
    // Di ARM, menemukan fungsi penutup hanya mengembalikan ip itu sendiri.
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}