# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Library untuk memperoleh backtrack saat runtime untuk Rust.
Pustaka ini bertujuan untuk meningkatkan dukungan pustaka standar dengan menyediakan antarmuka terprogram untuk digunakan, tetapi juga mendukung pencetakan lacak balik saat ini dengan mudah seperti libstd's panics.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Untuk merekam lacak balik dan menunda penanganannya hingga lain waktu, Anda dapat menggunakan tipe `Backtrace` level atas.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Namun, jika Anda menginginkan lebih banyak akses mentah ke fungsionalitas pelacakan aktual, Anda dapat menggunakan fungsi `trace` dan `resolve` secara langsung.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Selesaikan penunjuk instruksi ini ke nama simbol
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // lanjutkan ke frame berikutnya
    });
}
```

# License

Proyek ini dilisensikan di bawah salah satu dari

 * Lisensi Apache, Versi 2.0, ([LICENSE-APACHE](LICENSE-APACHE) atau http://www.apache.org/licenses/LICENSE-2.0)
 * Lisensi MIT ([LICENSE-MIT](LICENSE-MIT) atau http://opensource.org/licenses/MIT)

sesuai pilihan Anda.

### Contribution

Kecuali jika Anda secara eksplisit menyatakan sebaliknya, setiap kontribusi yang dengan sengaja dikirimkan untuk dimasukkan dalam backtrace-rs oleh Anda, sebagaimana didefinisikan dalam lisensi Apache-2.0, akan memiliki lisensi ganda seperti di atas, tanpa syarat atau ketentuan tambahan.







