use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// Representasi dari backtrace yang dimiliki dan berdiri sendiri.
///
/// Struktur ini dapat digunakan untuk menangkap lacak balik di berbagai titik dalam program dan kemudian digunakan untuk memeriksa lacak balik pada saat itu.
///
///
/// `Backtrace` mendukung pencetakan latar belakang yang cantik melalui implementasi `Debug`-nya.
///
/// # Fitur yang dibutuhkan
///
/// Fungsi ini memerlukan fitur `std` dari `backtrace` crate diaktifkan, dan fitur `std` diaktifkan secara default.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // Bingkai di sini terdaftar dari atas ke bawah tumpukan
    frames: Vec<BacktraceFrame>,
    // Indeks yang kami yakini adalah awal sebenarnya dari lacak balik, dengan menghilangkan bingkai seperti `Backtrace::new` dan `backtrace::trace`.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// Versi yang diambil dari bingkai dalam lacak balik.
///
/// Jenis ini dikembalikan sebagai daftar dari `Backtrace::frames` dan mewakili satu bingkai tumpukan dalam lacak balik yang diambil.
///
/// # Fitur yang dibutuhkan
///
/// Fungsi ini memerlukan fitur `std` dari `backtrace` crate diaktifkan, dan fitur `std` diaktifkan secara default.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// Versi yang diambil dari simbol dalam lacak balik.
///
/// Jenis ini dikembalikan sebagai daftar dari `BacktraceFrame::symbols` dan mewakili metadata untuk simbol di lacak balik.
///
/// # Fitur yang dibutuhkan
///
/// Fungsi ini memerlukan fitur `std` dari `backtrace` crate diaktifkan, dan fitur `std` diaktifkan secara default.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// Menangkap backtrace di callsite fungsi ini, mengembalikan representasi yang dimiliki.
    ///
    /// Fungsi ini berguna untuk merepresentasikan lacak balik sebagai objek di Rust.Nilai yang dikembalikan ini dapat dikirim melintasi utas dan dicetak di tempat lain, dan tujuan nilai ini adalah untuk menjadi mandiri sepenuhnya.
    ///
    /// Perhatikan bahwa pada beberapa platform, memperoleh lacak balik penuh dan menyelesaikannya bisa sangat mahal.
    /// Jika biayanya terlalu banyak untuk aplikasi Anda, disarankan untuk menggunakan `Backtrace::new_unresolved()` yang menghindari langkah resolusi simbol (yang biasanya memakan waktu paling lama) dan memungkinkan penangguhannya di kemudian hari.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # Fitur yang dibutuhkan
    ///
    /// Fungsi ini memerlukan fitur `std` dari `backtrace` crate diaktifkan, dan fitur `std` diaktifkan secara default.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // ingin memastikan ada bingkai di sini untuk dihapus
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// Mirip dengan `new` kecuali bahwa ini tidak menyelesaikan simbol apa pun, ini hanya menangkap lacak balik sebagai daftar alamat.
    ///
    /// Di lain waktu, fungsi `resolve` dapat dipanggil untuk menyelesaikan simbol lacak balik ini menjadi nama yang dapat dibaca.
    /// Fungsi ini ada karena proses resolusi terkadang memakan waktu lama sedangkan backtrace mana pun mungkin jarang dicetak.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // tidak ada nama simbol
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // nama simbol sekarang hadir
    /// ```
    ///
    /// # Fitur yang dibutuhkan
    ///
    /// Fungsi ini memerlukan fitur `std` dari `backtrace` crate diaktifkan, dan fitur `std` diaktifkan secara default.
    ///
    ///
    ///
    #[inline(never)] // ingin memastikan ada bingkai di sini untuk dihapus
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// Mengembalikan bingkai dari saat lacak balik ini diambil.
    ///
    /// Entri pertama dari potongan ini kemungkinan besar adalah fungsi `Backtrace::new`, dan bingkai terakhir kemungkinan adalah sesuatu tentang bagaimana utas ini atau fungsi utama dimulai.
    ///
    ///
    /// # Fitur yang dibutuhkan
    ///
    /// Fungsi ini memerlukan fitur `std` dari `backtrace` crate diaktifkan, dan fitur `std` diaktifkan secara default.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// Jika lacak balik ini dibuat dari `new_unresolved` maka fungsi ini akan menyelesaikan semua alamat di lacak balik ke nama simbolisnya.
    ///
    ///
    /// Jika lacak balik ini sebelumnya telah diselesaikan atau dibuat melalui `new`, fungsi ini tidak melakukan apa pun.
    ///
    /// # Fitur yang dibutuhkan
    ///
    /// Fungsi ini memerlukan fitur `std` dari `backtrace` crate diaktifkan, dan fitur `std` diaktifkan secara default.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// Sama seperti `Frame::ip`
    ///
    /// # Fitur yang dibutuhkan
    ///
    /// Fungsi ini memerlukan fitur `std` dari `backtrace` crate diaktifkan, dan fitur `std` diaktifkan secara default.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// Sama seperti `Frame::symbol_address`
    ///
    /// # Fitur yang dibutuhkan
    ///
    /// Fungsi ini memerlukan fitur `std` dari `backtrace` crate diaktifkan, dan fitur `std` diaktifkan secara default.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// Sama seperti `Frame::module_base_address`
    ///
    /// # Fitur yang dibutuhkan
    ///
    /// Fungsi ini memerlukan fitur `std` dari `backtrace` crate diaktifkan, dan fitur `std` diaktifkan secara default.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// Menampilkan daftar simbol yang sesuai dengan bingkai ini.
    ///
    /// Biasanya hanya ada satu simbol per frame, tetapi terkadang jika sejumlah fungsi dimasukkan ke dalam satu frame, maka beberapa simbol akan dikembalikan.
    /// Simbol pertama yang tertera adalah "innermost function", sedangkan simbol terakhir adalah yang paling luar (pemanggil terakhir).
    ///
    /// Perhatikan bahwa jika bingkai ini berasal dari lacak balik yang belum terselesaikan, maka ini akan mengembalikan daftar kosong.
    ///
    /// # Fitur yang dibutuhkan
    ///
    /// Fungsi ini memerlukan fitur `std` dari `backtrace` crate diaktifkan, dan fitur `std` diaktifkan secara default.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// Sama seperti `Symbol::name`
    ///
    /// # Fitur yang dibutuhkan
    ///
    /// Fungsi ini memerlukan fitur `std` dari `backtrace` crate diaktifkan, dan fitur `std` diaktifkan secara default.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// Sama seperti `Symbol::addr`
    ///
    /// # Fitur yang dibutuhkan
    ///
    /// Fungsi ini memerlukan fitur `std` dari `backtrace` crate diaktifkan, dan fitur `std` diaktifkan secara default.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// Sama seperti `Symbol::filename`
    ///
    /// # Fitur yang dibutuhkan
    ///
    /// Fungsi ini memerlukan fitur `std` dari `backtrace` crate diaktifkan, dan fitur `std` diaktifkan secara default.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// Sama seperti `Symbol::lineno`
    ///
    /// # Fitur yang dibutuhkan
    ///
    /// Fungsi ini memerlukan fitur `std` dari `backtrace` crate diaktifkan, dan fitur `std` diaktifkan secara default.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// Sama seperti `Symbol::colno`
    ///
    /// # Fitur yang dibutuhkan
    ///
    /// Fungsi ini memerlukan fitur `std` dari `backtrace` crate diaktifkan, dan fitur `std` diaktifkan secara default.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // Saat mencetak jalur kami mencoba untuk menghapus cwd jika ada, jika tidak kami hanya mencetak jalur apa adanya.
        // Perhatikan bahwa kami juga hanya melakukan ini untuk format pendek, karena jika penuh kiranya kami ingin mencetak semuanya.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}