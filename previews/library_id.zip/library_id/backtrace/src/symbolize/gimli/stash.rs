// hanya digunakan di Linux sekarang, jadi izinkan kode mati di tempat lain
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Alokasi arena sederhana untuk buffer byte.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Mengalokasikan buffer dengan ukuran yang ditentukan dan mengembalikan referensi yang bisa berubah padanya.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // SAFETY: ini adalah satu-satunya fungsi yang pernah membuat mutable
        // referensi ke `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // KEAMANAN: kami tidak pernah menghapus elemen dari `self.buffers`, jadi referensi
        // ke data di dalam buffer apa pun akan tetap aktif selama `self` melakukannya.
        &mut buffers[i]
    }
}