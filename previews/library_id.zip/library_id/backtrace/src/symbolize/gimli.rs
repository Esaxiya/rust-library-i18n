//! Dukungan untuk simbolikasi menggunakan `gimli` crate di crates.io
//!
//! Ini adalah implementasi simbolikasi default untuk Rust.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // 'seumur hidup statis adalah kebohongan untuk meretas kurangnya dukungan untuk struct referensi sendiri.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // Ubah menjadi 'masa pakai statis karena simbol hanya boleh meminjam `map` dan `stash` dan kami akan menyimpannya di bawah ini.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Untuk memuat pustaka asli di Windows, lihat beberapa diskusi di rust-lang/rust#71060 untuk berbagai strategi di sini.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // Perpustakaan MinGW saat ini tidak mendukung ASLR (rust-lang/rust#16514), tetapi DLL masih dapat dipindahkan di sekitar ruang alamat.
            // Tampaknya alamat di info debug semuanya seolah-olah pustaka ini dimuat di "image base", yang merupakan bidang di header file COFF-nya.
            // Karena ini adalah daftar yang tampaknya debuginfo daftar, kami mengurai tabel simbol dan menyimpan alamat seolah-olah pustaka dimuat di "image base" juga.
            //
            // Namun, pustaka tersebut mungkin tidak dimuat di "image base".
            // (mungkin ada sesuatu yang lain yang dimuat di sana?) Di sinilah bidang `bias` berperan, dan kita perlu mencari tahu nilai `bias` di sini.Sayangnya meskipun tidak jelas bagaimana mendapatkan ini dari modul yang dimuat.
            // Apa yang kami miliki, bagaimanapun, adalah alamat pemuatan aktual (`modBaseAddr`).
            //
            // Sebagai sedikit penyangkalan untuk saat ini kami mem-mmap file, membaca informasi header file, lalu melepaskan mmap.Ini boros karena kita mungkin akan membuka kembali mmap nanti, tapi ini akan bekerja dengan cukup baik untuk saat ini.
            //
            // Setelah kita memiliki `image_base` (lokasi pemuatan yang diinginkan) dan `base_addr` (lokasi pemuatan aktual), kita dapat mengisi `bias` (perbedaan antara yang sebenarnya dan yang diinginkan) dan kemudian alamat yang dinyatakan dari setiap segmen adalah `image_base` karena itulah yang dikatakan oleh file tersebut.
            //
            //
            // Untuk saat ini tampaknya tidak seperti ELF/MachO yang dapat kita lakukan dengan satu segmen per perpustakaan, menggunakan `modBaseSize` sebagai ukuran keseluruhan.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS menggunakan format file Mach-O dan menggunakan API khusus DYLD untuk memuat daftar pustaka asli yang merupakan bagian dari aplikasi.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // Ambil nama pustaka ini yang sesuai dengan jalur tempat memuatnya juga.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // Muat header gambar dari pustaka ini dan delegasikan ke `object` untuk mengurai semua perintah muat sehingga kita dapat mengetahui semua segmen yang terlibat di sini.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // Ulangi segmen dan daftarkan kawasan yang dikenal untuk segmen yang kami temukan.
            // Selain itu, catat informasi tentang segmen teks untuk diproses nanti, lihat komentar di bawah.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // Tentukan "slide" untuk pustaka ini yang akhirnya menjadi bias yang kita gunakan untuk mencari tahu di mana objek memori dimuat.
            // Ini adalah perhitungan yang sedikit aneh dan merupakan hasil dari mencoba beberapa hal di alam liar dan melihat apa yang bertahan.
            //
            // Ide umumnya adalah bahwa `bias` plus `stated_virtual_memory_address` segmen akan menjadi tempat di ruang alamat aktual segmen tersebut berada.
            // Hal lain yang kami andalkan adalah bahwa alamat asli dikurangi `bias` adalah indeks yang harus dicari di tabel simbol dan debuginfo.
            //
            // Namun, ternyata untuk pustaka yang dimuat sistem, penghitungan ini salah.Untuk executable asli, bagaimanapun, ini tampak benar.
            // Mengangkat beberapa logika dari sumber LLDB, ia memiliki beberapa casing khusus untuk bagian `__TEXT` pertama yang dimuat dari file offset 0 dengan ukuran bukan nol.
            // Untuk alasan apa pun saat ini ada tampaknya berarti bahwa tabel simbol relatif hanya dengan slide vmaddr untuk pustaka.
            // Jika *tidak* ada maka tabel simbol relatif terhadap slide vmaddr ditambah alamat segmen yang dinyatakan.
            //
            // Untuk menangani situasi ini jika kami *tidak* menemukan bagian teks pada file offset nol maka kami meningkatkan bias dengan alamat yang dinyatakan bagian teks pertama dan mengurangi semua alamat yang dinyatakan dengan jumlah itu juga.
            //
            // Dengan cara itu tabel simbol selalu muncul relatif terhadap jumlah bias perpustakaan.
            // Ini tampaknya memiliki hasil yang tepat untuk dilambangkan melalui tabel simbol.
            //
            // Sejujurnya saya tidak sepenuhnya yakin apakah ini benar atau apakah ada hal lain yang seharusnya menunjukkan bagaimana melakukan ini.
            // Untuk saat ini meskipun tampaknya (?) ini bekerja dengan cukup baik dan kami harus selalu dapat menyesuaikannya dari waktu ke waktu jika perlu.
            //
            // Untuk informasi lebih lanjut, lihat #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Unix lainnya (mis
        // Linux) menggunakan ELF sebagai format file objek dan biasanya mengimplementasikan API yang disebut `dl_iterate_phdr` untuk memuat pustaka asli.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` harus menjadi petunjuk yang valid.
        // `vec` harus menjadi penunjuk yang valid ke `std::Vec`.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 tidak secara native mendukung info debug, tetapi sistem build akan menempatkan info debug di jalur `romfs:/debug_info.elf`.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // Semua yang lain harus menggunakan ELF, tetapi tidak tahu cara memuat pustaka asli.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// Semua pustaka bersama yang diketahui yang telah dimuat.
    libraries: Vec<Library>,

    /// Cache pemetaan tempat kami menyimpan informasi katai yang telah diuraikan.
    ///
    /// Daftar ini memiliki kapasitas tetap untuk seluruh masa pakainya yang tidak pernah bertambah.
    /// Elemen `usize` dari setiap pasangan adalah indeks ke `libraries` di atas di mana `usize::max_value()` mewakili eksekusi saat ini.
    ///
    /// `Mapping` adalah informasi katai parsing yang sesuai.
    ///
    /// Perhatikan bahwa ini pada dasarnya adalah cache LRU dan kami akan memindahkan banyak hal di sini saat kami melambangkan alamat.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// Segmen pustaka ini dimuat ke dalam memori, dan di mana mereka dimuat.
    segments: Vec<LibrarySegment>,
    /// "bias" dari pustaka ini, biasanya saat dimuat ke dalam memori.
    /// Nilai ini ditambahkan ke alamat yang dinyatakan setiap segmen untuk mendapatkan alamat memori virtual aktual tempat segmen tersebut dimuat.
    /// Selain itu, bias ini dikurangkan dari alamat memori virtual nyata untuk diindeks ke debuginfo dan tabel simbol.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// Alamat yang dinyatakan dari segmen ini di file objek.
    /// Ini sebenarnya bukan tempat segmen dimuat, melainkan alamat ini ditambah `bias` pustaka yang memuatnya adalah tempat untuk menemukannya.
    ///
    stated_virtual_memory_address: usize,
    /// Ukuran segmen ini di memori.
    len: usize,
}

// tidak aman karena ini harus disinkronkan secara eksternal
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // tidak aman karena ini harus disinkronkan secara eksternal
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // Cache LRU yang sangat kecil dan sangat sederhana untuk pemetaan info debug.
        //
        // Tingkat klik harus sangat tinggi, karena tumpukan tipikal tidak bersilangan di antara banyak pustaka bersama.
        //
        // Struktur `addr2line::Context` cukup mahal untuk dibuat.
        // Biayanya diperkirakan akan diamortisasi oleh kueri `locate` berikutnya, yang memanfaatkan struktur yang dibangun saat membuat `addr2line: : Context`s untuk mendapatkan percepatan yang bagus.
        //
        // Jika kita tidak memiliki cache ini, amortisasi itu tidak akan pernah terjadi, dan menyimbolkan backtraces akan menjadi ssssllllooooowwww.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // Pertama, uji apakah `lib` ini memiliki segmen yang berisi `addr` (menangani relokasi).Jika pemeriksaan ini berhasil maka kita dapat melanjutkan di bawah dan benar-benar menerjemahkan alamatnya.
                //
                // Perhatikan bahwa kami menggunakan `wrapping_add` di sini untuk menghindari pemeriksaan luapan.Telah terlihat di alam liar bahwa penghitungan bias SVMA + meluap.
                // Tampaknya agak aneh hal itu akan terjadi tetapi tidak banyak yang dapat kita lakukan selain mungkin mengabaikan segmen itu karena kemungkinan besar mengarah ke luar angkasa.
                //
                // Ini awalnya muncul di rust-lang/backtrace-rs#329.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // Sekarang kita tahu `lib` berisi `addr`, kita bisa mengimbangi dengan bias untuk menemukan alamat memori virutal yang disebutkan.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Invarian: setelah persyaratan ini selesai tanpa pengembalian awal
        // dari kesalahan, entri cache untuk jalur ini ada di indeks 0.

        if let Some(idx) = idx {
            // Saat pemetaan sudah ada di cache, pindahkan ke depan.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // Jika pemetaan tidak ada di cache, buat pemetaan baru, masukkan ke bagian depan cache, dan hapus entri cache terlama jika perlu.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // jangan membocorkan masa pakai `'static`, pastikan itu hanya untuk diri kita sendiri
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // Perpanjang masa pakai `sym` ke `'static` karena sayangnya kami diminta di sini, tetapi hanya akan keluar sebagai referensi sehingga tidak ada referensi ke sana yang harus disimpan di luar bingkai ini.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // Terakhir, dapatkan pemetaan cache atau buat pemetaan baru untuk file ini, dan evaluasi info DWARF untuk menemukan file/line/name untuk alamat ini.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// Kami dapat menemukan informasi bingkai untuk simbol ini, dan bingkai `addr2line` secara internal memiliki semua detailnya.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// Tidak dapat menemukan informasi debug, tetapi kami menemukannya di tabel simbol dari elf yang dapat dieksekusi.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}