use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Selesaikan alamat ke simbol, meneruskan simbol ke penutupan yang ditentukan.
///
/// Fungsi ini akan mencari alamat yang diberikan di area seperti tabel simbol lokal, tabel simbol dinamis, atau info debug DWARF (tergantung pada implementasi yang diaktifkan) untuk menemukan simbol yang akan dihasilkan.
///
///
/// Penutupan tidak dapat dipanggil jika resolusi tidak dapat dilakukan, dan juga dapat dipanggil lebih dari sekali dalam kasus fungsi sebaris.
///
/// Simbol yang dihasilkan mewakili eksekusi pada `addr` yang ditentukan, mengembalikan pasangan file/line untuk alamat tersebut (jika tersedia).
///
/// Perhatikan bahwa jika Anda memiliki `Frame`, disarankan untuk menggunakan fungsi `resolve_frame` daripada yang ini.
///
/// # Fitur yang dibutuhkan
///
/// Fungsi ini memerlukan fitur `std` dari `backtrace` crate diaktifkan, dan fitur `std` diaktifkan secara default.
///
/// # Panics
///
/// Fungsi ini berusaha untuk tidak pernah panic, tetapi jika `cb` menyediakan panics maka beberapa platform akan memaksa panic ganda untuk membatalkan proses.
/// Beberapa platform menggunakan pustaka C yang secara internal menggunakan callback yang tidak dapat dibatalkan, jadi panik dari `cb` dapat memicu pembatalan proses.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // hanya melihat bingkai atas
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Selesaikan bingkai pengambilan sebelumnya ke simbol, meneruskan simbol ke penutupan yang ditentukan.
///
/// Functin ini menjalankan fungsi yang sama dengan `resolve` kecuali ia menggunakan `Frame` sebagai argumen, bukan sebagai alamat.
/// Hal ini dapat memungkinkan beberapa implementasi platform pelacakan mundur untuk memberikan informasi simbol yang lebih akurat atau informasi tentang bingkai sebaris misalnya.
///
/// Disarankan untuk menggunakan ini jika Anda bisa.
///
/// # Fitur yang dibutuhkan
///
/// Fungsi ini memerlukan fitur `std` dari `backtrace` crate diaktifkan, dan fitur `std` diaktifkan secara default.
///
/// # Panics
///
/// Fungsi ini berusaha untuk tidak pernah panic, tetapi jika `cb` menyediakan panics maka beberapa platform akan memaksa panic ganda untuk membatalkan proses.
/// Beberapa platform menggunakan pustaka C yang secara internal menggunakan callback yang tidak dapat dibatalkan, jadi panik dari `cb` dapat memicu pembatalan proses.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // hanya melihat bingkai atas
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// Nilai IP dari bingkai tumpukan biasanya (always?) instruksi *setelah* panggilan yang merupakan pelacakan tumpukan sebenarnya.
// Melambangkan ini pada menyebabkan nomor filename/line menjadi satu di depan dan mungkin menjadi kosong jika mendekati akhir fungsi.
//
// Ini tampaknya pada dasarnya selalu terjadi pada semua platform, jadi kami selalu mengurangi satu dari ip yang diselesaikan untuk menyelesaikannya ke instruksi panggilan sebelumnya alih-alih instruksi yang dikembalikan.
//
//
// Idealnya kami tidak akan melakukan ini.
// Idealnya kami akan meminta penelepon `resolve` API di sini untuk secara manual melakukan -1 dan akun yang mereka inginkan informasi lokasi untuk instruksi *sebelumnya*, bukan saat ini.
// Idealnya kami juga akan mengekspos di `Frame` jika kami memang alamat dari instruksi berikutnya atau saat ini.
//
// Untuk saat ini meskipun ini adalah perhatian khusus sehingga kami selalu menguranginya secara internal.
// Konsumen harus terus bekerja dan mendapatkan hasil yang cukup baik, jadi kita harus cukup baik.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Sama seperti `resolve`, hanya tidak aman karena tidak disinkronkan.
///
/// Fungsi ini tidak memiliki jaminan sinkronisasi tetapi tersedia jika fitur `std` dari crate ini tidak dikompilasi.
/// Lihat fungsi `resolve` untuk dokumentasi dan contoh selengkapnya.
///
/// # Panics
///
/// Lihat informasi di `resolve` untuk peringatan tentang `cb` karena panik.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Sama seperti `resolve_frame`, hanya tidak aman karena tidak disinkronkan.
///
/// Fungsi ini tidak memiliki jaminan sinkronisasi tetapi tersedia jika fitur `std` dari crate ini tidak dikompilasi.
/// Lihat fungsi `resolve_frame` untuk dokumentasi dan contoh selengkapnya.
///
/// # Panics
///
/// Lihat informasi di `resolve_frame` untuk peringatan tentang `cb` karena panik.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// A trait mewakili resolusi simbol dalam file.
///
/// trait ini dihasilkan sebagai objek trait untuk penutupan yang diberikan ke fungsi `backtrace::resolve`, dan secara virtual dikirim karena tidak diketahui implementasi mana yang ada di belakangnya.
///
///
/// Simbol dapat memberikan informasi kontekstual tentang suatu fungsi, misalnya nama, nama file, nomor baris, alamat persis, dll.
/// Tidak semua informasi selalu tersedia dalam simbol, jadi semua metode mengembalikan `Option`.
///
///
pub struct Symbol {
    // TODO: batas seumur hidup ini harus dipertahankan pada akhirnya ke `Symbol`,
    // tapi saat ini perubahan yang menghancurkan.
    // Untuk saat ini ini aman karena `Symbol` hanya diberikan dengan referensi dan tidak dapat dikloning.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Mengembalikan nama fungsi ini.
    ///
    /// Struktur yang dikembalikan dapat digunakan untuk menanyakan berbagai properti tentang nama simbol:
    ///
    ///
    /// * Implementasi `Display` akan mencetak simbol yang telah di-demangled.
    /// * Nilai `str` mentah dari simbol dapat diakses (jika valid utf-8).
    /// * Byte mentah untuk nama simbol dapat diakses.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Mengembalikan alamat awal fungsi ini.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Mengembalikan nama file mentah sebagai potongan.
    /// Ini terutama berguna untuk lingkungan `no_std`.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Mengembalikan nomor kolom tempat simbol ini sedang dieksekusi.
    ///
    /// Hanya gimli yang saat ini memberikan nilai di sini dan bahkan hanya jika `filename` mengembalikan `Some`, sehingga karenanya tunduk pada peringatan serupa.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Mengembalikan nomor baris di mana simbol ini sedang dieksekusi.
    ///
    /// Nilai pengembalian ini biasanya `Some` jika `filename` mengembalikan `Some`, dan akibatnya tunduk pada peringatan serupa.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Mengembalikan nama file tempat fungsi ini ditentukan.
    ///
    /// Ini saat ini hanya tersedia ketika libbacktrace atau gimli digunakan (mis
    /// unix platform lainnya) dan saat biner dikompilasi dengan debuginfo.
    /// Jika tidak satu pun dari ketentuan ini terpenuhi, kemungkinan besar ini akan mengembalikan `None`.
    ///
    /// # Fitur yang dibutuhkan
    ///
    /// Fungsi ini memerlukan fitur `std` dari `backtrace` crate diaktifkan, dan fitur `std` diaktifkan secara default.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Mungkin simbol C++ yang diurai, jika penguraian simbol yang rusak sebagai Rust gagal.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Pastikan untuk menyimpan ini dalam ukuran nol, sehingga fitur `cpp_demangle` tidak memiliki biaya saat dinonaktifkan.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Sebuah pembungkus di sekitar nama simbol untuk memberikan aksesor ergonomis ke nama yang telah di-demangled, byte mentah, string mentah, dll.
///
// Izinkan kode mati ketika fitur `cpp_demangle` tidak diaktifkan.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Membuat nama simbol baru dari byte yang mendasari mentah.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Mengembalikan nama simbol (mangled) mentah sebagai `str` jika simbol tersebut adalah utf-8 yang valid.
    ///
    /// Gunakan implementasi `Display` jika Anda menginginkan versi demangled.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Mengembalikan nama simbol mentah sebagai daftar byte
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Ini mungkin akan dicetak jika simbol yang telah dihancurkan sebenarnya tidak valid, jadi tangani kesalahan di sini dengan baik dengan tidak menyebarkannya ke luar.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Mencoba mengklaim kembali memori cache yang digunakan untuk menyimbolkan alamat.
///
/// Metode ini akan mencoba merilis struktur data global apa pun yang telah di-cache secara global atau di utas yang biasanya mewakili informasi DWARF yang diurai atau serupa.
///
///
/// # Caveats
///
/// Meskipun fungsi ini selalu tersedia, fungsi ini sebenarnya tidak melakukan apa pun pada sebagian besar implementasi.
/// Library seperti dbghelp atau libbacktrace tidak menyediakan fasilitas untuk membatalkan alokasi status dan mengelola memori yang dialokasikan.
/// Untuk saat ini fitur `gimli-symbolize` dari crate ini adalah satu-satunya fitur yang fungsi ini berpengaruh.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}