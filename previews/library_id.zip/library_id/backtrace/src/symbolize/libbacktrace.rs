//! Strategi simbolisasi menggunakan kode penguraian DWARF di libbacktrace.
//!
//! Pustaka C libbacktrace, biasanya didistribusikan dengan gcc, mendukung tidak hanya pembuatan lacak balik (yang sebenarnya tidak kita gunakan) tetapi juga melambangkan lacak balik dan menangani informasi debug katai tentang hal-hal seperti bingkai sebaris dan yang lainnya.
//!
//!
//! Ini relatif rumit karena banyak masalah di sini, tetapi ide dasarnya adalah:
//!
//! * Pertama kita sebut `backtrace_syminfo`.Ini mendapatkan informasi simbol dari tabel simbol dinamis jika kita bisa.
//! * Selanjutnya kita sebut `backtrace_pcinfo`.Ini akan mengurai tabel debuginfo jika tersedia dan memungkinkan kami memulihkan informasi tentang bingkai sebaris, nama file, nomor baris, dll.
//!
//! Ada banyak tipuan tentang memasukkan tabel katai ke dalam libbacktrace, tapi mudah-mudahan ini bukan akhir dari dunia dan cukup jelas saat membaca di bawah ini.
//!
//! Ini adalah strategi simbolikasi default untuk platform non-MSVC dan non-OSX.Dalam libstd ini adalah strategi default untuk OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Jika memungkinkan, pilih nama `function` yang berasal dari debuginfo dan biasanya bisa lebih akurat untuk bingkai sebaris misalnya.
                // Jika itu tidak ada, kembali ke nama tabel simbol yang ditentukan di `symname`.
                //
                // Perhatikan bahwa terkadang `function` terasa kurang akurat, misalnya dicantumkan sebagai `try<i32,closure>` bukan `std::panicking::try::do_call`.
                //
                // Tidak begitu jelas mengapa, tetapi secara keseluruhan nama `function` tampaknya lebih akurat.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // jangan lakukan apa pun untuk saat ini
}

/// Jenis penunjuk `data` diteruskan ke `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Setelah callback ini dipanggil dari `backtrace_syminfo` saat kita mulai menyelesaikannya, kita melangkah lebih jauh untuk memanggil `backtrace_pcinfo`.
    // Fungsi `backtrace_pcinfo` akan berkonsultasi dengan informasi debug dan mencoba melakukan hal-hal seperti memulihkan informasi file/line serta bingkai sebaris.
    // Perhatikan bahwa `backtrace_pcinfo` dapat gagal atau tidak berbuat banyak jika tidak ada info debug, jadi jika itu terjadi, kami pasti akan memanggil callback dengan setidaknya satu simbol dari `syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Jenis penunjuk `data` diteruskan ke `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// API libbacktrace mendukung pembuatan sebuah negara, tetapi tidak mendukung penghancuran sebuah negara.
// Saya pribadi mengartikan hal ini bahwa suatu negara dimaksudkan untuk diciptakan dan kemudian hidup selamanya.
//
// Saya ingin mendaftarkan penangan at_exit() yang membersihkan status ini, tetapi libbacktrace tidak menyediakan cara untuk melakukannya.
//
// Dengan batasan ini, fungsi ini memiliki status cache statis yang dihitung saat pertama kali diminta.
//
// Ingatlah bahwa penelusuran mundur semua terjadi secara serial (satu kunci global).
//
// Perhatikan kurangnya sinkronisasi di sini karena persyaratan bahwa `resolve` disinkronkan secara eksternal.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Jangan menggunakan kapabilitas threadsafe dari libbacktrace karena kami selalu memanggilnya secara tersinkronisasi.
        //
        0,
        error_cb,
        ptr::null_mut(), // tidak ada data tambahan
    );

    return STATE;

    // Perhatikan bahwa agar libbacktrace dapat beroperasi, ia perlu menemukan info debug DWARF untuk executable saat ini.Ini biasanya dilakukan melalui sejumlah mekanisme termasuk, tetapi tidak terbatas pada:
    //
    // * /proc/self/exe di platform yang didukung
    // * Nama file diteruskan secara eksplisit saat membuat status
    //
    // Pustaka libbacktrace adalah gumpalan besar kode C.Ini secara alami berarti memiliki kerentanan keamanan memori, terutama saat menangani debuginfo yang rusak.
    // Libstd telah mengalami banyak hal ini secara historis.
    //
    // Jika /proc/self/exe digunakan maka kita biasanya dapat mengabaikan ini karena kita berasumsi bahwa libbacktrace adalah "mostly correct" dan sebaliknya tidak melakukan hal-hal aneh dengan info debug katai "attempted to be correct".
    //
    //
    // Namun, jika kami mengirimkan nama file, maka mungkin saja pada beberapa platform (seperti BSD) di mana aktor jahat dapat menyebabkan file sewenang-wenang ditempatkan di lokasi itu.
    // Ini berarti bahwa jika kami memberi tahu libbacktrace tentang nama file, file tersebut mungkin menggunakan file arbitrer, mungkin menyebabkan segfault.
    // Jika kami tidak memberi tahu libbacktrace apa pun, itu tidak akan melakukan apa pun pada platform yang tidak mendukung jalur seperti /proc/self/exe!
    //
    // Mengingat semua itu kami berusaha sekeras mungkin untuk *tidak* memasukkan nama file, tetapi kami harus pada platform yang tidak mendukung /proc/self/exe sama sekali.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Perhatikan bahwa idealnya kami akan menggunakan `std::env::current_exe`, tetapi kami tidak dapat meminta `std` di sini.
            //
            // Gunakan `_NSGetExecutablePath` untuk memuat jalur yang dapat dieksekusi saat ini ke dalam area statis (yang jika terlalu kecil menyerah saja).
            //
            //
            // Perhatikan bahwa kami sangat mempercayai libbacktrace di sini untuk tidak mati pada file executable yang korup, tetapi pasti ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows memiliki mode membuka file yang setelah dibuka tidak dapat dihapus.
            // Secara umum itulah yang kami inginkan di sini karena kami ingin memastikan bahwa executable kami tidak berubah dari bawah kami setelah kami menyerahkannya ke libbacktrace, semoga mengurangi kemampuan untuk meneruskan data sewenang-wenang ke libbacktrace (yang mungkin salah penanganan).
            //
            //
            // Mengingat bahwa kami melakukan sedikit tarian di sini untuk mencoba mendapatkan semacam kunci pada gambar kami sendiri:
            //
            // * Dapatkan pegangan untuk proses saat ini, muat nama filenya.
            // * Buka file ke nama file itu dengan bendera yang tepat.
            // * Muat ulang nama file proses saat ini, pastikan itu sama
            //
            // Jika itu semua lolos, kami secara teori memang membuka file proses kami dan kami jamin itu tidak akan berubah.FWIW banyak dari ini disalin dari libstd secara historis, jadi ini adalah interpretasi terbaik saya tentang apa yang terjadi.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Ini hidup dalam memori statis sehingga kita dapat mengembalikannya ..
                static mut BUF: [i8; N] = [0; N];
                // ... dan ini hidup di tumpukan karena bersifat sementara
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // sengaja membocorkan `handle` di sini karena membukanya harus menjaga kunci kami pada nama file ini.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Kami ingin mengembalikan potongan yang nul-terminated, jadi jika semuanya terisi dan sama dengan panjang total maka samakan dengan kegagalan.
                //
                //
                // Jika tidak, saat kembali berhasil, pastikan byte nol disertakan dalam potongan.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // kesalahan lacak balik saat ini tersapu di bawah permadani
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Panggil `backtrace_syminfo` API yang (dari membaca kode) harus memanggil `syminfo_cb` tepat satu kali (atau mungkin gagal dengan kesalahan).
    // Kami kemudian menangani lebih banyak dalam `syminfo_cb`.
    //
    // Perhatikan bahwa kami melakukan ini karena `syminfo` akan berkonsultasi dengan tabel simbol, menemukan nama simbol meskipun tidak ada informasi debug dalam biner.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}