#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// Pemformat untuk lacak balik.
///
/// Jenis ini dapat digunakan untuk mencetak lacak balik dari mana pun asal lacak balik itu.
/// Jika Anda memiliki tipe `Backtrace` maka implementasi `Debug`-nya sudah menggunakan format pencetakan ini.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// Gaya pencetakan yang bisa kita cetak
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Mencetak lacak balik singkat yang idealnya hanya berisi informasi yang relevan
    Short,
    /// Mencetak lacak balik yang berisi semua kemungkinan informasi
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Buat `BacktraceFmt` baru yang akan menulis keluaran ke `fmt` yang disediakan.
    ///
    /// Argumen `format` akan mengontrol gaya di mana lacak balik dicetak, dan argumen `print_path` akan digunakan untuk mencetak contoh nama file `BytesOrWideString`.
    /// Jenis ini sendiri tidak melakukan pencetakan nama file, tetapi panggilan balik ini diperlukan untuk melakukannya.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Mencetak pembukaan untuk lacak balik yang akan dicetak.
    ///
    /// Ini diperlukan pada beberapa platform agar lacak balik sepenuhnya disimbolkan nanti, dan jika tidak, ini seharusnya menjadi metode pertama yang Anda panggil setelah membuat `BacktraceFmt`.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Menambahkan bingkai ke keluaran lacak balik.
    ///
    /// Komit ini mengembalikan instance RAII dari `BacktraceFrameFmt` yang dapat digunakan untuk benar-benar mencetak bingkai, dan jika dihancurkan, penghitung bingkai akan bertambah.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Menyelesaikan keluaran backtrace.
    ///
    /// Saat ini tidak ada operasi tetapi ditambahkan untuk kompatibilitas future dengan format lacak balik.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // Saat ini tidak ada operasi-- termasuk hook ini untuk memungkinkan penambahan future.
        Ok(())
    }
}

/// Pemformat untuk hanya satu bingkai lacak balik.
///
/// Jenis ini dibuat oleh fungsi `BacktraceFmt::frame`.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Mencetak `BacktraceFrame` dengan pemformat bingkai ini.
    ///
    /// Ini akan mencetak semua instans `BacktraceSymbol` secara rekursif di dalam `BacktraceFrame`.
    ///
    /// # Fitur yang dibutuhkan
    ///
    /// Fungsi ini memerlukan fitur `std` dari `backtrace` crate diaktifkan, dan fitur `std` diaktifkan secara default.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// Mencetak `BacktraceSymbol` dalam `BacktraceFrame`.
    ///
    /// # Fitur yang dibutuhkan
    ///
    /// Fungsi ini memerlukan fitur `std` dari `backtrace` crate diaktifkan, dan fitur `std` diaktifkan secara default.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: ini tidak bagus bahwa kami tidak akan mencetak apa pun
            // dengan nama file non-utf8.
            // Untungnya hampir semuanya utf8 jadi ini seharusnya tidak terlalu buruk.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Mencetak `Frame` dan `Symbol` yang dilacak mentah, biasanya dari dalam callback mentah crate ini.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Menambahkan bingkai mentah ke keluaran lacak balik.
    ///
    /// Metode ini, tidak seperti sebelumnya, mengambil argumen mentah jika sumbernya berasal dari lokasi yang berbeda.
    /// Perhatikan bahwa ini dapat dipanggil beberapa kali untuk satu bingkai.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Menambahkan bingkai mentah ke keluaran lacak balik, termasuk informasi kolom.
    ///
    /// Metode ini, seperti sebelumnya, mengambil argumen mentah jika sumbernya berasal dari lokasi yang berbeda.
    /// Perhatikan bahwa ini dapat dipanggil beberapa kali untuk satu bingkai.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Fuchsia tidak dapat melambangkan dalam suatu proses sehingga memiliki format khusus yang dapat digunakan untuk melambangkan nanti.
        // Cetak itu alih-alih mencetak alamat dalam format kita sendiri di sini.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Tidak perlu mencetak bingkai "null", itu pada dasarnya hanya berarti bahwa pelacakan balik sistem agak ingin melacak kembali sangat jauh.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Untuk mengurangi ukuran TCB di enclave Sgx, kami tidak ingin menerapkan fungsionalitas resolusi simbol.
        // Sebaliknya, kita dapat mencetak offset alamat di sini, yang nantinya dapat dipetakan ke fungsi yang benar.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Cetak indeks bingkai serta penunjuk instruksi opsional bingkai.
        // Jika kita berada di luar simbol pertama dari bingkai ini meskipun kita hanya mencetak spasi yang sesuai.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Selanjutnya tulis nama simbol, menggunakan format alternatif untuk informasi lebih lanjut jika kita backtrace penuh.
        // Di sini kami juga menangani simbol yang tidak memiliki nama,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // Dan terakhir, cetak nomor filename/line jika tersedia.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line dicetak pada baris di bawah nama simbol, jadi cetak beberapa spasi yang sesuai untuk mengurutkan diri kita sendiri.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Delegasikan ke panggilan balik internal kami untuk mencetak nama file dan kemudian mencetak nomor baris.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Tambahkan nomor kolom, jika tersedia.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Kami hanya peduli dengan simbol pertama dari sebuah bingkai
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}