use core::ffi::c_void;
use core::fmt;

/// Memeriksa tumpukan panggilan saat ini, meneruskan semua bingkai aktif ke dalam closure yang disediakan untuk menghitung pelacakan tumpukan.
///
/// Fungsi ini adalah pekerja keras perpustakaan ini dalam menghitung jejak tumpukan untuk suatu program.Penutupan `cb` yang diberikan adalah instance yang dihasilkan dari `Frame` yang mewakili informasi tentang bingkai panggilan tersebut di stack.
/// Penutupan tersebut menghasilkan bingkai dengan cara top-down (paling baru-baru ini disebut fungsi terlebih dahulu).
///
/// Nilai kembalian closure merupakan indikasi apakah lacak balik harus dilanjutkan.Nilai kembali `false` akan menghentikan pelacakan mundur dan segera kembali.
///
/// Setelah `Frame` diperoleh, Anda mungkin ingin memanggil `backtrace::resolve` untuk mengubah `ip` (penunjuk instruksi) atau alamat simbol ke `Symbol` di mana nama dan/atau nama file/nomor baris dapat dipelajari.
///
///
/// Perhatikan bahwa ini adalah fungsi level yang relatif rendah dan jika Anda ingin, misalnya, merekam lacak balik untuk diperiksa nanti, maka jenis `Backtrace` mungkin lebih tepat.
///
/// # Fitur yang dibutuhkan
///
/// Fungsi ini memerlukan fitur `std` dari `backtrace` crate diaktifkan, dan fitur `std` diaktifkan secara default.
///
/// # Panics
///
/// Fungsi ini berusaha untuk tidak pernah panic, tetapi jika `cb` menyediakan panics maka beberapa platform akan memaksa panic ganda untuk membatalkan proses.
/// Beberapa platform menggunakan pustaka C yang secara internal menggunakan callback yang tidak dapat dibatalkan, jadi panik dari `cb` dapat memicu pembatalan proses.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // lanjutkan pelacakan ke belakang
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Sama seperti `trace`, hanya tidak aman karena tidak disinkronkan.
///
/// Fungsi ini tidak memiliki jaminan sinkronisasi tetapi tersedia jika fitur `std` dari crate ini tidak dikompilasi.
/// Lihat fungsi `trace` untuk dokumentasi dan contoh selengkapnya.
///
/// # Panics
///
/// Lihat informasi di `trace` untuk peringatan tentang `cb` karena panik.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// A trait mewakili satu frame backtrace, yang dihasilkan oleh fungsi `trace` dari crate ini.
///
/// Penutupan fungsi pelacakan akan menghasilkan frame, dan frame tersebut secara virtual dikirim karena implementasi yang mendasarinya tidak selalu diketahui hingga runtime.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Mengembalikan penunjuk instruksi saat ini dari bingkai ini.
    ///
    /// Ini biasanya adalah instruksi berikutnya untuk dieksekusi dalam frame, tetapi tidak semua implementasi mencantumkan ini dengan akurasi 100% (tetapi umumnya cukup dekat).
    ///
    ///
    /// Direkomendasikan untuk meneruskan nilai ini ke `backtrace::resolve` untuk mengubahnya menjadi nama simbol.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Mengembalikan penunjuk tumpukan saat ini dari bingkai ini.
    ///
    /// Jika backend tidak dapat memulihkan penunjuk tumpukan untuk bingkai ini, penunjuk nol dikembalikan.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Mengembalikan alamat simbol awal dari bingkai fungsi ini.
    ///
    /// Ini akan mencoba untuk memundurkan penunjuk instruksi yang dikembalikan oleh `ip` ke awal fungsi, mengembalikan nilai itu.
    ///
    /// Namun, dalam beberapa kasus, backend hanya akan mengembalikan `ip` dari fungsi ini.
    ///
    /// Nilai yang dikembalikan terkadang dapat digunakan jika `backtrace::resolve` gagal pada `ip` yang diberikan di atas.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Mengembalikan alamat dasar modul tempat bingkai tersebut berada.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Ini harus didahulukan, untuk memastikan bahwa Miri mendapat prioritas di atas platform host
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // hanya digunakan dalam dbghelp melambangkan
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}