use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr mengambil callback yang akan menerima pointer dl_phdr_info untuk setiap DSO yang telah ditautkan ke dalam proses.
    // dl_iterate_phdr juga memastikan bahwa dynamic linker dikunci dari awal hingga akhir iterasi.
    // Jika callback mengembalikan nilai bukan nol, iterasi dihentikan lebih awal.
    // 'data' akan diteruskan sebagai argumen ketiga ke callback pada setiap panggilan.
    // 'size' memberikan ukuran dl_phdr_info tersebut.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Kita perlu mem-parsing ID build dan beberapa data header program dasar yang berarti kita memerlukan sedikit hal dari spesifikasi ELF juga.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Sekarang kita harus mereplikasi, sedikit demi sedikit, struktur tipe dl_phdr_info yang digunakan oleh dynamic linker fuchsia saat ini.
// Chromium juga memiliki batas ABI dan juga crashpad.
// Akhirnya kami ingin memindahkan kasus ini untuk menggunakan elf-search tetapi kami perlu menyediakannya di SDK dan itu belum dilakukan.
//
// Jadi kami (dan mereka) terjebak karena harus menggunakan metode ini yang menyebabkan hubungan erat dengan fuchsia libc.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Kami tidak memiliki cara untuk mengetahui apakah e_phoff dan e_phnum valid.
    // libc harus memastikan hal ini untuk kita, jadi aman untuk membuat potongan di sini.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr mewakili header program ELF 64-bit dalam kesempurnaan arsitektur target.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr mewakili header program ELF yang valid dan isinya.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Kami tidak memiliki cara untuk memeriksa apakah p_addr atau p_memsz valid.
    // Libc Fuchsia mem-parsing catatan terlebih dahulu, jadi karena berada di sini, header ini harus valid.
    //
    // NoteIter tidak membutuhkan data yang mendasari untuk menjadi valid tetapi membutuhkan batas untuk menjadi valid.
    // Kami percaya bahwa libc telah memastikan bahwa inilah masalahnya bagi kami di sini.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// Jenis catatan untuk ID build.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr mewakili header catatan ELF di endianness target.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Catatan mewakili catatan ELF (tajuk + konten).
// Namanya dibiarkan sebagai potongan u8 karena tidak selalu null diakhiri dan rust membuatnya cukup mudah untuk memeriksa apakah byte cocok.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter memungkinkan Anda mengulang segmen catatan dengan aman.
// Ini berakhir segera setelah terjadi kesalahan atau tidak ada catatan lagi.
// Jika Anda mengulang data yang tidak valid, itu akan berfungsi seolah-olah tidak ada catatan yang ditemukan.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Ini adalah fungsi invarian yang penunjuk dan ukuran yang diberikan menunjukkan rentang byte yang valid yang semuanya dapat dibaca.
    // Isi byte ini bisa apa saja kecuali rentangnya harus valid agar aman.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to aligns 'x' to 'to'-byte alignment dengan asumsi 'to' adalah pangkat 2.
// Ini mengikuti pola standar dalam kode parsing C/C ++ ELF di mana (x + to, 1)&-to digunakan.
// Rust tidak membiarkan Anda meniadakan penggunaan jadi saya gunakan
// Konversi pelengkap 2 untuk menciptakannya kembali.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 mengkonsumsi num byte dari slice (jika ada) dan juga memastikan bahwa slice terakhir disejajarkan dengan benar.
// Jika jumlah byte yang diminta terlalu besar atau potongan tidak dapat diatur kembali setelah itu karena tidak cukup byte yang tersisa, Tidak ada yang dikembalikan dan potongan tidak diubah.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Fungsi ini tidak memiliki invarian nyata yang harus dipegang pemanggil selain mungkin 'bytes' harus diselaraskan untuk kinerja (dan pada beberapa kebenaran arsitektur).
// Nilai di bidang Elf_Nhdr mungkin tidak masuk akal tetapi fungsi ini tidak memastikan hal seperti itu.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Ini aman selama ada cukup ruang dan kami baru saja mengonfirmasi bahwa dalam pernyataan if di atas jadi ini seharusnya tidak berbahaya.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Perhatikan bahwa sice_of: :<Elf_Nhdr>() selalu selaras 4-byte.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Periksa apakah kita sudah mencapai akhir.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Kami mentransmutasikan sebuah nhdr tetapi kami dengan hati-hati mempertimbangkan struct yang dihasilkan.
        // Kami tidak mempercayai namesz atau descsz dan kami tidak membuat keputusan yang tidak aman berdasarkan jenisnya.
        //
        // Jadi, meskipun kita membuang sampah sepenuhnya, kita tetap harus aman.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Menunjukkan bahwa segmen dapat dieksekusi.
const PERM_X: u32 = 0b00000001;
/// Menunjukkan bahwa segmen dapat ditulis.
const PERM_W: u32 = 0b00000010;
/// Menunjukkan bahwa segmen dapat dibaca.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Merepresentasikan segmen ELF saat runtime.
struct Segment {
    /// Memberikan alamat virtual waktu proses dari konten segmen ini.
    addr: usize,
    /// Memberikan ukuran memori dari konten segmen ini.
    size: usize,
    /// Memberikan alamat virtual modul segmen ini dengan file ELF.
    mod_rel_addr: usize,
    /// Memberikan izin yang ditemukan di file ELF.
    /// Namun, izin ini belum tentu merupakan izin yang ada pada waktu proses.
    flags: Perm,
}

/// Memungkinkan seseorang mengulang Segmen dari DSO.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Mewakili ELF DSO (Dynamic Shared Object).
/// Jenis ini mereferensikan data yang disimpan di DSO sebenarnya daripada membuat salinannya sendiri.
struct Dso<'a> {
    /// Linker dinamis selalu memberi kita nama, meskipun namanya kosong.
    /// Dalam kasus eksekusi utama, nama ini akan kosong.
    /// Dalam kasus objek bersama itu akan menjadi soname (lihat DT_SONAME).
    name: &'a str,
    /// Di Fuchsia, hampir semua binari memiliki ID build tetapi ini bukan persyaratan yang ketat.
    /// Tidak ada cara untuk mencocokkan informasi DSO dengan file ELF yang sebenarnya setelahnya jika tidak ada build_id jadi kami mengharuskan setiap DSO memilikinya di sini.
    ///
    /// DSO tanpa build_id akan diabaikan.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Mengembalikan iterator atas Segmen di DSO ini.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Kesalahan ini menyandikan masalah yang muncul saat mengurai informasi tentang setiap DSO.
///
enum Error {
    /// NameError berarti bahwa kesalahan terjadi saat mengonversi string gaya C menjadi string rust.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError berarti kami tidak menemukan ID build.
    /// Ini bisa jadi karena DSO tidak memiliki ID build atau karena segmen yang berisi ID build memiliki format yang salah.
    ///
    BuildIDError,
}

/// Memanggil 'dso' atau 'error' untuk setiap DSO yang ditautkan ke proses oleh linker dinamis.
///
///
/// # Arguments
///
/// * `visitor` - DsoPrinter yang memiliki salah satu metode makan yang disebut foreach DSO.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr memastikan bahwa info.name akan mengarah ke lokasi yang valid.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Fungsi ini mencetak markup simbolisasi Fuchsia untuk semua informasi yang terdapat dalam DSO.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}