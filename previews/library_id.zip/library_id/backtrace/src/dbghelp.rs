//! Sebuah modul untuk membantu mengelola dbghelp binding di Windows
//!
//! Jejak balik pada Windows (setidaknya untuk MSVC) sebagian besar didukung melalui `dbghelp.dll` dan berbagai fungsi yang dikandungnya.
//! Fungsi-fungsi ini saat ini dimuat *secara dinamis* daripada menautkan ke `dbghelp.dll` secara statis.
//! Ini saat ini dilakukan oleh pustaka standar (dan secara teori diperlukan di sana), tetapi merupakan upaya untuk membantu mengurangi dependensi dll statis pustaka karena backtrack biasanya cukup opsional.
//!
//! Meskipun demikian, `dbghelp.dll` hampir selalu berhasil dimuat di Windows.
//!
//! Perhatikan bahwa karena kita memuat semua dukungan ini secara dinamis, kita tidak dapat benar-benar menggunakan definisi mentah di `winapi`, tetapi kita perlu mendefinisikan sendiri jenis penunjuk fungsi dan menggunakannya.
//! Kami tidak benar-benar ingin berada dalam bisnis menduplikasi winapi, jadi kami memiliki fitur Cargo `verify-winapi` yang menegaskan bahwa semua binding cocok dengan winapi dan fitur ini diaktifkan di CI.
//!
//! Akhirnya, Anda akan mencatat di sini bahwa dll untuk `dbghelp.dll` tidak pernah dibongkar, dan itu disengaja.
//! Pemikirannya adalah kita dapat menyimpan cache secara global dan menggunakannya di antara panggilan ke API, menghindari loads/unloads yang mahal.
//! Jika ini adalah masalah untuk alat pendeteksi kebocoran atau semacamnya kita bisa menyeberang jembatan saat kita sampai di sana.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Bekerja di sekitar `SymGetOptions` dan `SymSetOptions` tidak hadir di winapi itu sendiri.
// Jika tidak, ini hanya digunakan saat kami memeriksa ulang tipe terhadap winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Belum didefinisikan dalam winapi
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Ini didefinisikan di winapi, tetapi salah (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Belum didefinisikan dalam winapi
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Makro ini digunakan untuk menentukan struktur `Dbghelp` yang secara internal berisi semua penunjuk fungsi yang mungkin kita muat.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// DLL yang dimuat untuk `dbghelp.dll`
            dll: HMODULE,

            // Setiap penunjuk fungsi untuk setiap fungsi yang mungkin kita gunakan
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Awalnya kami belum memuat DLL
            dll: 0 as *mut _,
            // Semua fungsi dimulai dari nol untuk mengatakan bahwa mereka perlu dimuat secara dinamis.
            //
            $($name: 0,)*
        };

        // Kenyamanan typedef untuk setiap jenis fungsi.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Upaya untuk membuka `dbghelp.dll`.
            /// Mengembalikan sukses jika berhasil atau error jika `LoadLibraryW` gagal.
            ///
            /// Panics jika perpustakaan sudah dimuat.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Fungsi untuk setiap metode yang ingin kami gunakan.
            // Ketika dipanggil itu akan membaca penunjuk fungsi yang di-cache atau memuatnya dan mengembalikan nilai yang dimuat.
            // Beban dipastikan berhasil.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Kenyamanan proxy untuk menggunakan kunci pembersihan untuk merujuk fungsi dbghelp.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Inisialisasi semua dukungan yang diperlukan untuk mengakses fungsi `dbghelp` API dari crate ini.
///
///
/// Perhatikan bahwa fungsi ini **aman**, secara internal memiliki sinkronisasi sendiri.
/// Perhatikan juga bahwa aman untuk memanggil fungsi ini beberapa kali secara rekursif.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Hal pertama yang perlu kita lakukan adalah menyinkronkan fungsi ini.Ini dapat dipanggil secara bersamaan dari utas lain atau secara rekursif dalam satu utas.
        // Perhatikan bahwa ini lebih rumit dari itu karena apa yang kita gunakan di sini, `dbghelp`,*juga* perlu disinkronkan dengan semua penelepon lain ke `dbghelp` dalam proses ini.
        //
        // Biasanya tidak ada banyak panggilan ke `dbghelp` dalam proses yang sama dan kami mungkin dapat dengan aman berasumsi bahwa hanya kami yang mengaksesnya.
        // Namun, ada satu pengguna utama lain yang harus kita khawatirkan yang ironisnya adalah diri kita sendiri, tetapi di perpustakaan standar.
        // Pustaka standar Rust bergantung pada crate ini untuk dukungan lacak balik, dan crate ini juga ada di crates.io.
        // Ini berarti bahwa jika pustaka standar mencetak lacak balik panic, ia mungkin berpacu dengan crate ini yang berasal dari crates.io, menyebabkan segfault.
        //
        // Untuk membantu mengatasi masalah sinkronisasi ini, kami menggunakan trik khusus Windows di sini (bagaimanapun juga, ini adalah pembatasan khusus Windows tentang sinkronisasi).
        // Kami membuat *sesi-lokal* bernama mutex untuk melindungi panggilan ini.
        // Maksudnya di sini adalah agar pustaka standar dan crate ini tidak harus berbagi API tingkat Rust untuk menyinkronkan di sini, tetapi dapat bekerja di belakang layar untuk memastikan mereka menyinkronkan satu sama lain.
        //
        // Dengan begitu, ketika fungsi ini dipanggil melalui pustaka standar atau melalui crates.io, kita dapat memastikan bahwa mutex yang sama sedang diperoleh.
        //
        // Jadi semua itu untuk mengatakan bahwa hal pertama yang kita lakukan di sini adalah kita secara atomik membuat `HANDLE` yang diberi nama mutex pada Windows.
        // Kami menyinkronkan sedikit dengan utas lain yang berbagi fungsi ini secara khusus dan memastikan bahwa hanya satu pegangan yang dibuat per contoh fungsi ini.
        // Perhatikan bahwa pegangan tidak pernah ditutup setelah disimpan di global.
        //
        // Setelah kita benar-benar membuka kunci, kita langsung mendapatkannya, dan pegangan `Init` yang kita berikan akan bertanggung jawab untuk menjatuhkannya pada akhirnya.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Oke, Fiuh!Sekarang setelah kita semua tersinkronisasi dengan aman, mari kita mulai memproses semuanya.
        // Pertama kita perlu memastikan bahwa `dbghelp.dll` benar-benar dimuat dalam proses ini.
        // Kami melakukan ini secara dinamis untuk menghindari ketergantungan statis.
        // Ini secara historis telah dilakukan untuk mengatasi masalah penautan yang aneh dan dimaksudkan untuk membuat binari sedikit lebih portabel karena ini sebagian besar hanyalah utilitas debugging.
        //
        //
        // Setelah kita membuka `dbghelp.dll` kita perlu memanggil beberapa fungsi inisialisasi di dalamnya, dan itu lebih rinci di bawah.
        // Kami hanya melakukan ini sekali, jadi kami punya boolean global yang menunjukkan apakah kami sudah selesai atau belum.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Pastikan bahwa flag `SYMOPT_DEFERRED_LOADS` disetel, karena menurut dokumen MSVC sendiri tentang ini: "This is the fastest, most efficient way to use the symbol handler.", jadi mari kita lakukan!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Sebenarnya menginisialisasi simbol dengan MSVC.Perhatikan bahwa ini bisa gagal, tetapi kami mengabaikannya.
        // Tidak ada banyak seni sebelumnya untuk ini per se, tetapi LLVM secara internal tampaknya mengabaikan nilai yang dikembalikan di sini dan salah satu pustaka pembersih di LLVM mencetak peringatan menakutkan jika ini gagal tetapi pada dasarnya mengabaikannya dalam jangka panjang.
        //
        //
        // Satu kasus yang sering muncul pada Rust adalah bahwa pustaka standar dan crate pada crates.io ini sama-sama ingin bersaing untuk `SymInitializeW`.
        // Pustaka standar secara historis ingin menginisialisasi kemudian membersihkan sebagian besar waktu, tetapi sekarang setelah menggunakan crate ini, itu berarti seseorang akan mendapatkan inisialisasi terlebih dahulu dan yang lain akan mengambil inisialisasi itu.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}