#![feature(no_core)]
#![no_core]

// Lihat rustc-std-workspace-core untuk mengetahui mengapa crate ini diperlukan.

// Ubah nama crate untuk menghindari konflik dengan modul alokasi di liballoc.
extern crate alloc as foo;

pub use foo::*;