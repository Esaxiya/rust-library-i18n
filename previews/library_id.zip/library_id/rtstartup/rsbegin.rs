// rsbegin.o dan rsend.o adalah yang disebut "compiler runtime startup objects".
// Mereka berisi kode yang diperlukan untuk menginisialisasi runtime kompilator dengan benar.
//
// Ketika gambar yang dapat dieksekusi atau dylib ditautkan, semua kode pengguna dan pustaka adalah "sandwiched" di antara dua file objek ini, jadi kode atau data dari rsbegin.o menjadi yang pertama di masing-masing bagian gambar, sedangkan kode dan data dari rsend.o menjadi yang terakhir.
// Efek ini dapat digunakan untuk menempatkan simbol di awal atau di akhir bagian, serta untuk memasukkan header atau footer yang diperlukan.
//
// Perhatikan bahwa titik masuk modul sebenarnya terletak di objek startup runtime C (biasanya disebut `crtX.o`), yang kemudian memanggil callback inisialisasi komponen runtime lainnya (terdaftar melalui bagian gambar khusus lainnya).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Menandai awal bagian info pelepasan bingkai tumpukan
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Gores ruang untuk pembukuan internal bersantai.
    // Ini didefinisikan sebagai `struct object` di $ GCC/unwind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Buka info rutinitas registration/deregistration.
    // Lihat dokumen libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // mendaftar info bersantai saat modul startup
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // batalkan pendaftaran saat dimatikan
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // Registrasi rutin init/uninit khusus MinGW
    pub mod mingw_init {
        // Objek startup MinGW (crt0.o/dllcrt0.o) akan memanggil konstruktor global di bagian .ctors dan .dtors saat memulai dan keluar.
        // Dalam kasus DLL, ini dilakukan saat DLL dimuat dan dibongkar.
        //
        // Linker akan mengurutkan bagian, yang memastikan bahwa callback kita berada di akhir daftar.
        // Karena konstruktor dijalankan dalam urutan terbalik, ini memastikan bahwa callback kita adalah yang pertama dan terakhir dieksekusi.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: C inisialisasi callback
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtor. *: C pemutusan panggilan balik
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}