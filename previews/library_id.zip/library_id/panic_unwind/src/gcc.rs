//! Implementasi panics didukung oleh libgcc/libunwind (dalam beberapa bentuk).
//!
//! Untuk latar belakang tentang penanganan pengecualian dan pelepasan tumpukan, silakan lihat "Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html) dan dokumen yang ditautkan darinya.
//! Ini juga bacaan yang bagus:
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## Ringkasan singkat
//!
//! Penanganan pengecualian terjadi dalam dua fase: fase pencarian dan fase pembersihan.
//!
//! Dalam kedua fase ini, unwinder berjalan tumpukan frame dari atas ke bawah menggunakan informasi dari bagian pelepasan frame tumpukan dari modul proses saat ini ("module" di sini mengacu pada modul OS, yaitu, perpustakaan yang dapat dieksekusi atau dinamis).
//!
//!
//! Untuk setiap bingkai tumpukan, itu memanggil "personality routine" terkait, yang alamatnya juga disimpan di bagian info lepas.
//!
//! Dalam fase pencarian, tugas rutinitas kepribadian adalah memeriksa objek pengecualian yang dilempar, dan memutuskan apakah objek tersebut harus ditangkap di bingkai tumpukan itu.Setelah bingkai penangan diidentifikasi, fase pembersihan dimulai.
//!
//! Dalam fase pembersihan, unwinder mengaktifkan kembali setiap rutinitas kepribadian.
//! Kali ini memutuskan kode pembersihan mana (jika ada) yang perlu dijalankan untuk bingkai tumpukan saat ini.Jika demikian, kontrol ditransfer ke branch khusus di badan fungsi, "landing pad", yang memanggil destruktor, membebaskan memori, dll.
//! Di ujung landasan pendaratan, kontrol dipindahkan kembali ke pelepasan dan penguluran resume.
//!
//! Setelah tumpukan telah dilepas ke tingkat bingkai penangan, pelepasan berhenti dan rutinitas kepribadian terakhir mentransfer kontrol ke blok tangkapan.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// ID kelas pengecualian Rust.
// Ini digunakan oleh rutinitas kepribadian untuk menentukan apakah pengecualian dilemparkan oleh runtime mereka sendiri.
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // MOZ\0 RUST-vendor, bahasa
    0x4d4f5a_00_52555354
}

// ID register diambil dari LLVM TargetLowering::getExceptionPointerRegister() dan TargetLowering::getExceptionSelectorRegister() untuk setiap arsitektur, kemudian dipetakan ke nomor register DWARF melalui tabel definisi register (biasanya<arch>RegisterInfo.td, cari "DwarfRegNum").
//
// Lihat juga http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register.
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // EAX, EDX

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // RAX, RDX

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0, X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3, X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// Kode berikut didasarkan pada rutinitas kepribadian C dan C++ GCC.Untuk referensi, lihat:
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM Rutinitas kepribadian EHABI.
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS menggunakan rutin default sebagai gantinya karena menggunakan SjLj unwinding.
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // Jejak balik di ARM akan memanggil rutinitas kepribadian dengan status==_US_VIRTUAL_UNWIND_FRAME |_US_FORCE_UNWIND.
                // Dalam kasus tersebut kami ingin melanjutkan melepas tumpukan, jika tidak semua backtrack kami akan berakhir pada __rust_try
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // DWARF unwinder mengasumsikan bahwa_Unwind_Context menampung hal-hal seperti fungsi dan pointer LSDA, namun ARM EHABI menempatkannya ke dalam objek pengecualian.
            // Untuk mempertahankan tanda tangan dari fungsi seperti _Unwind_GetLanguageSpecificData(), yang hanya mengambil penunjuk konteks, rutinitas kepribadian GCC menyimpan penunjuk ke exception_object dalam konteks, menggunakan lokasi yang dicadangkan untuk ARM "scratch register" (r12).
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ... Pendekatan yang lebih berprinsip adalah memberikan definisi lengkap_Unwind_Context ARM di binding libunwind kami dan mengambil data yang diperlukan dari sana secara langsung, melewati fungsi kompatibilitas DWARF.
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // EHABI membutuhkan rutinitas kepribadian untuk memperbarui nilai SP di cache penghalang dari objek pengecualian.
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // Di ARM EHABI, rutinitas kepribadian bertanggung jawab untuk benar-benar melepas bingkai tumpukan tunggal sebelum dikembalikan (ARM EHABI Sec.
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // didefinisikan di libgcc
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // Rutinitas kepribadian default, yang digunakan secara langsung pada sebagian besar target dan secara tidak langsung pada Windows x86_64 melalui SEH.
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // Pada target x86_64 MinGW, mekanisme pelepasannya SEH namun data pengendali pelepasan (alias LSDA) menggunakan pengkodean yang kompatibel dengan GCC.
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // Rutinitas kepribadian untuk sebagian besar target kita.
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // Alamat pengirim menunjuk 1 byte melewati instruksi panggilan, yang bisa berada di kisaran IP berikutnya dalam tabel kisaran LSDA.
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// Bingkai pendaftaran info santai
//
// Setiap gambar modul berisi bagian info pelepasan bingkai (biasanya ".eh_frame").Ketika modul loaded/unloaded ke dalam proses, unwinder harus diberi tahu tentang lokasi bagian ini di memori.Metode pencapaian yang berbeda-beda di setiap platform.
// Pada beberapa (mis., Linux), unwinder dapat menemukan bagian info pelepasannya sendiri (dengan secara dinamis menghitung modul yang saat ini dimuat melalui dl_iterate_phdr() API and finding their ".eh_frame" sections); Lainnya, seperti Windows, memerlukan modul untuk secara aktif mendaftarkan bagian info pelepasnya melalui API pembuka.
//
//
// Modul ini mendefinisikan dua simbol yang direferensikan dan dipanggil dari rsbegin.rs untuk mendaftarkan informasi kita dengan runtime GCC.
// Implementasi pelepasan tumpukan (untuk saat ini) ditangguhkan ke libgcc_eh, namun Rust crates menggunakan titik masuk khusus Rust ini untuk menghindari potensi bentrokan dengan runtime GCC.
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}