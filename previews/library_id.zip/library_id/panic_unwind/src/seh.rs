//! Windows SEH
//!
//! Di Windows (saat ini hanya di MSVC), mekanisme penanganan pengecualian default adalah Penanganan Pengecualian Terstruktur (SEH).
//! Ini sangat berbeda dari penanganan pengecualian berbasis Dwarf (misalnya, apa yang digunakan platform unix lain) dalam hal internal kompilator, jadi LLVM diharuskan memiliki banyak dukungan ekstra untuk SEH.
//!
//! Singkatnya, yang terjadi di sini adalah:
//!
//! 1. Fungsi `panic` memanggil fungsi Windows standar `_CxxThrowException` untuk menampilkan pengecualian seperti C++ , yang memicu proses pelepasan.
//! 2.
//! Semua bantalan pendaratan yang dibuat oleh kompilator menggunakan fungsi kepribadian `__CxxFrameHandler3`, fungsi di CRT, dan kode pelepasan di Windows akan menggunakan fungsi kepribadian ini untuk menjalankan semua kode pembersihan pada tumpukan.
//!
//! 3. Semua panggilan yang dihasilkan compiler ke `invoke` memiliki landasan pendaratan yang disetel sebagai instruksi `cleanuppad` LLVM, yang menunjukkan permulaan rutinitas pembersihan.
//! Kepribadian (di langkah 2, didefinisikan di CRT) bertanggung jawab untuk menjalankan rutinitas pembersihan.
//! 4. Akhirnya kode "catch" dalam intrinsik `try` (dihasilkan oleh kompilator) dijalankan dan menunjukkan bahwa kontrol harus kembali ke Rust.
//! Ini dilakukan melalui instruksi `catchswitch` plus `catchpad` dalam istilah LLVM IR, yang akhirnya mengembalikan kontrol normal ke program dengan instruksi `catchret`.
//!
//! Beberapa perbedaan khusus dari penanganan pengecualian berbasis gcc adalah:
//!
//! * Rust tidak memiliki fungsi kepribadian kustom, melainkan *selalu*`__CxxFrameHandler3`.Selain itu, tidak ada pemfilteran tambahan yang dilakukan, jadi kami akhirnya menangkap pengecualian C++ apa pun yang kebetulan terlihat seperti yang kami lemparkan.
//! Perhatikan bahwa melempar pengecualian ke Rust adalah perilaku yang tidak ditentukan, jadi ini akan baik-baik saja.
//! * Kami punya beberapa data untuk dikirim melintasi batas yang tidak berliku, khususnya `Box<dyn Any + Send>`.Seperti dengan pengecualian Dwarf, kedua petunjuk ini disimpan sebagai muatan dalam pengecualian itu sendiri.
//! Namun, di MSVC, alokasi heap tambahan tidak diperlukan karena stack panggilan dipertahankan saat fungsi filter sedang dijalankan.
//! Ini berarti bahwa pointer diteruskan langsung ke `_CxxThrowException` yang kemudian dipulihkan dalam fungsi filter untuk ditulis ke bingkai tumpukan dari intrinsik `try`.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Ini perlu menjadi Option karena kita menangkap pengecualian dengan referensi dan destruktornya dijalankan oleh runtime C++ .
    // Saat kita mengeluarkan Kotak dari pengecualian, kita perlu membiarkan pengecualian dalam keadaan valid agar destruktornya berjalan tanpa menjatuhkan Kotak dua kali.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// Pertama, sejumlah definisi tipe.Ada beberapa keanehan khusus platform di sini, dan banyak yang secara terang-terangan disalin dari LLVM.Tujuan dari semua ini adalah untuk mengimplementasikan fungsi `panic` di bawah ini melalui panggilan ke `_CxxThrowException`.
//
// Fungsi ini membutuhkan dua argumen.Yang pertama adalah penunjuk ke data yang kami kirimkan, yang dalam hal ini adalah objek trait kami.Cukup mudah ditemukan!Namun, selanjutnya lebih rumit.
// Ini adalah penunjuk ke struktur `_ThrowInfo`, dan umumnya hanya dimaksudkan untuk mendeskripsikan pengecualian yang dilemparkan.
//
// Saat ini definisi tipe [1] ini sedikit berbulu, dan keanehan utama (dan perbedaan dari artikel online) adalah bahwa pada 32-bit penunjuk adalah penunjuk tetapi pada 64-bit penunjuk diekspresikan sebagai offset 32-bit dari Simbol `__ImageBase`.
//
// Makro `ptr_t` dan `ptr!` pada modul di bawah digunakan untuk mengekspresikannya.
//
// Labirin definisi tipe juga mengikuti dengan cermat apa yang dipancarkan LLVM untuk operasi semacam ini.Misalnya, jika Anda mengkompilasi kode C++ ini di MSVC dan memancarkan IR LLVM:
//
//      #include <stdint.h>
//
//      struct rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      batal foo() { rust_panic a = {0, 1};
//          melempar;}
//
// Pada dasarnya itulah yang kami coba tiru.Sebagian besar nilai konstanta di bawah ini baru saja disalin dari LLVM,
//
// Bagaimanapun, semua struktur ini dibangun dengan cara yang sama, dan itu agak bertele-tele bagi kami.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Perhatikan bahwa kami sengaja mengabaikan aturan mangling nama di sini: kami tidak ingin C++ dapat menangkap Rust panics hanya dengan mendeklarasikan `struct rust_panic`.
//
//
// Saat memodifikasi, pastikan bahwa string nama jenis sama persis dengan yang digunakan di `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // Byte `\x01` utama di sini sebenarnya adalah sinyal ajaib untuk LLVM untuk *tidak* menerapkan mangling lain seperti mengawali dengan karakter `_`.
    //
    //
    // Simbol ini adalah vtabel yang digunakan oleh C++ 's `std::type_info`.
    // Objek tipe `std::type_info`, tipe deskriptor, memiliki penunjuk ke tabel ini.
    // Deskriptor tipe direferensikan oleh struktur C++ EH yang ditentukan di atas dan yang kami buat di bawah.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Deskriptor jenis ini hanya digunakan saat melontarkan pengecualian.
// Bagian tangkapan ditangani oleh try intrinsic, yang menghasilkan TypeDescriptornya sendiri.
//
// Ini bagus karena runtime MSVC menggunakan perbandingan string pada nama tipe untuk mencocokkan TypeDescriptors daripada persamaan pointer.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Destruktor digunakan jika kode C++ memutuskan untuk menangkap pengecualian dan melepaskannya tanpa menyebarkannya.
// Bagian tangkap dari try intrinsic akan menyetel kata pertama dari objek pengecualian ke 0 sehingga dilewati oleh destruktor.
//
// Perhatikan bahwa x86 Windows menggunakan konvensi panggilan "thiscall" untuk fungsi anggota C++ alih-alih konvensi panggilan "C" default.
//
// Fungsi exception_copy agak istimewa di sini: ini dipanggil oleh runtime MSVC di bawah blok try/catch dan panic yang kami buat di sini akan digunakan sebagai hasil dari salinan pengecualian.
//
// Ini digunakan oleh runtime C++ untuk mendukung pengambilan pengecualian dengan std::exception_ptr, yang tidak dapat kami dukung karena Box<dyn Any>tidak dapat dikloning.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException dijalankan sepenuhnya pada bingkai tumpukan ini, jadi tidak perlu mentransfer `data` ke heap.
    // Kami baru saja meneruskan penunjuk tumpukan ke fungsi ini.
    //
    // ManuallyDrop diperlukan di sini karena kami tidak ingin Exception dihapus saat melepasnya.
    // Sebaliknya, ini akan dihapus oleh exception_cleanup yang dipanggil oleh runtime C++ .
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Ini ... mungkin tampak mengejutkan, dan memang bisa dibenarkan.Pada MSVC 32-bit, penunjuk di antara struktur ini hanya itu, penunjuk.
    // Pada MSVC 64-bit, bagaimanapun, penunjuk antar struktur lebih diekspresikan sebagai offset 32-bit dari `__ImageBase`.
    //
    // Akibatnya, pada MSVC 32-bit kita dapat mendeklarasikan semua petunjuk ini di `statis` di atas.
    // Pada MSVC 64-bit, kami harus mengekspresikan pengurangan pointer dalam statika, yang saat ini tidak diizinkan oleh Rust, jadi kami tidak dapat melakukannya.
    //
    // Hal terbaik berikutnya, kemudian adalah mengisi struktur ini saat runtime (tetap saja panik sudah menjadi "slow path").
    // Jadi di sini kami menafsirkan ulang semua bidang penunjuk ini sebagai bilangan bulat 32-bit dan kemudian menyimpan nilai yang relevan ke dalamnya (secara atomik, karena panics bersamaan mungkin terjadi).
    //
    // Secara teknis runtime mungkin akan melakukan pembacaan nonatomik bidang ini, tetapi secara teori mereka tidak pernah membaca nilai *salah* sehingga seharusnya tidak terlalu buruk ...
    //
    // Bagaimanapun, pada dasarnya kita perlu melakukan sesuatu seperti ini sampai kita dapat mengekspresikan lebih banyak operasi dalam statika (dan kita mungkin tidak akan pernah bisa).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // Muatan NULL di sini berarti kita sampai di sini dari tangkapan (...) dari __rust_try.
    // Ini terjadi ketika pengecualian asing non-Rust tertangkap.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Ini diperlukan oleh kompilator untuk ada (misalnya, ini adalah item lang), tetapi tidak pernah benar-benar dipanggil oleh kompilator karena __C_specific_handler atau_except_handler3 adalah fungsi kepribadian yang selalu digunakan.
//
// Oleh karena itu, ini hanyalah rintisan yang membatalkan.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}