//! Implementasi panics melalui stack unwinding
//!
//! crate ini adalah implementasi dari panics di Rust menggunakan mekanisme pelepasan tumpukan "most native" dari platform yang sedang dikompilasi.
//! Ini pada dasarnya dikategorikan menjadi tiga kelompok saat ini:
//!
//! 1. Target MSVC menggunakan SEH di file `seh.rs`.
//! 2. Emscripten menggunakan pengecualian C++ di file `emcc.rs`.
//! 3. Semua target lain menggunakan libunwind/libgcc di file `gcc.rs`.
//!
//! Dokumentasi lebih lanjut tentang setiap implementasi dapat ditemukan di modul masing-masing.
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` tidak digunakan dengan Miri, jadi peringatan diam.
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // Objek startup Rust runtime bergantung pada simbol-simbol ini, jadi buatlah untuk publik.
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // Target yang tidak mendukung pelepasan.
        // - arch=wasm32
        // - os=tidak ada (target "bare metal")
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // Gunakan runtime Miri.
        // Kita juga masih perlu memuat runtime normal di atas, karena rustc mengharapkan item lang tertentu dari sana akan ditentukan.
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // Gunakan runtime yang sebenarnya.
        use real_imp as imp;
    }
}

extern "C" {
    /// Handler di libstd dipanggil saat objek panic dijatuhkan di luar `catch_unwind`.
    ///
    fn __rust_drop_panic() -> !;

    /// Penangan di libstd dipanggil saat pengecualian asing ditangkap.
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// Titik masuk untuk mengajukan pengecualian, hanya mendelegasikan ke implementasi khusus platform.
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}