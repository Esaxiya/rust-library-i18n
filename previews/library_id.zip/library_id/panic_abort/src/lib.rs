//! Implementasi Rust panics melalui proses dibatalkan
//!
//! Jika dibandingkan dengan implementasi melalui unwinding, crate ini *jauh* lebih sederhana!Meski begitu, ini tidak begitu serbaguna, tapi ini dia!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" muatan dan shim ke abort yang relevan pada platform yang dimaksud.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // hubungi std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // Di Windows, gunakan mekanisme __fastfail khusus prosesor.Di Windows 8 dan yang lebih baru, ini akan menghentikan proses dengan segera tanpa menjalankan penangan pengecualian dalam proses.
            // Dalam versi Windows sebelumnya, urutan instruksi ini akan diperlakukan sebagai pelanggaran akses, menghentikan proses tetapi tanpa harus melewati semua penangan pengecualian.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: ini adalah implementasi yang sama seperti pada libstd's `abort_internal`
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// Ini ... agak aneh.Tl; dr;adalah bahwa ini diperlukan untuk menautkan dengan benar, penjelasan yang lebih panjang ada di bawah.
//
// Saat ini binari libcore/libstd yang kami kirimkan semuanya dikompilasi dengan `-C panic=unwind`.Ini dilakukan untuk memastikan bahwa binari kompatibel secara maksimal dengan sebanyak mungkin situasi.
// Kompilator, bagaimanapun, membutuhkan "personality function" untuk semua fungsi yang dikompilasi dengan `-C panic=unwind`.Fungsi kepribadian ini di-hardcode ke simbol `rust_eh_personality` dan ditentukan oleh item lang `eh_personality`.
//
// So...
// mengapa tidak mendefinisikan item lang itu di sini?Pertanyaan bagus!Cara runtime panic ditautkan sebenarnya sedikit halus karena mereka "sort of" di penyimpanan crate kompiler, tetapi hanya benar-benar ditautkan jika yang lain tidak benar-benar ditautkan.
//
// Ini berarti bahwa crate dan panic_unwind crate ini dapat muncul di penyimpanan crate penyusun, dan jika keduanya menentukan item lang `eh_personality` maka itu akan menemui kesalahan.
//
// Untuk menangani ini, kompilator hanya memerlukan `eh_personality` yang ditentukan jika runtime panic yang ditautkan adalah runtime yang tidak berliku, dan sebaliknya tidak perlu ditentukan (memang seharusnya demikian).
// Dalam kasus ini, bagaimanapun, perpustakaan ini hanya mendefinisikan simbol ini sehingga setidaknya ada beberapa kepribadian di suatu tempat.
//
// Pada dasarnya simbol ini hanya didefinisikan untuk terhubung ke binari libcore/libstd, tetapi tidak boleh dipanggil karena kami tidak menautkan sama sekali dalam runtime yang tidak berliku.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // Di x86_64-pc-windows-gnu kami menggunakan fungsi kepribadian kami sendiri yang perlu mengembalikan `ExceptionContinueSearch` saat kami meneruskan semua bingkai kami.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // Mirip dengan di atas, ini terkait dengan item `eh_catch_typeinfo` lang yang hanya digunakan di Emscripten saat ini.
    //
    // Karena panics tidak menghasilkan pengecualian dan pengecualian asing saat ini UB dengan -C panic=abort (meskipun ini dapat berubah sewaktu-waktu), panggilan catch_unwind apa pun tidak akan pernah menggunakan typeinfo ini.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // Keduanya dipanggil oleh objek startup kami di i686-pc-windows-gnu, tetapi mereka tidak perlu melakukan apa pun sehingga bodynya tidak aktif.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}