//! Windows SEH
//!
//! 在 Windows 上 (当前仅在 MSVC 上)，默认的异常处理机制是结构化异常处理 (SEH)。
//! 就编译器内部而言，这与基于 Dwarf 的异常处理 (例如，其他 unix 平台使用的异常处理) 完全不同，因此要求 LLVM 对 SEH 提供大量额外支持。
//!
//! 简而言之，这里发生的是:
//!
//! 1. `panic` 函数调用标准 Windows 函数 `_CxxThrowException` 引发类似 C++ 的异常，从而触发展开进程。
//! 2.
//! 编译器生成的所有着陆垫都使用个性函数 `__CxxFrameHandler3` (CRT 中的一个函数)，而 Windows 中的展开代码将使用此个性函数来执行栈上的所有清理代码。
//!
//! 3. 编译器生成的所有对 `invoke` 的调用都将着陆区设置为 `cleanuppad` LLVM 指令，该指令指示清除例程的开始。
//! 个性 (在 CRT 中定义的步骤 2) 负责运行清除例程。
//! 4. 最终，执行 `try` 内部函数中的 "catch" 代码 (由编译器生成)，并指示控件应返回 Rust。
//! 这是通过 `catchswitch` 加上 LLVM IR 术语中的 `catchpad` 指令完成的，最后使用 `catchret` 指令将正常控制权返回给程序。
//!
//! 与基于 gcc 的异常处理的某些特定区别是:
//!
//! * Rust 没有自定义的个性函数，而是 *始终*`__CxxFrameHandler3`。此外，没有执行任何额外的过滤，因此我们最终捕获了所有碰巧看起来像我们抛出的 C++ 异常。
//! 注意，向 Rust 抛出异常是未定义的行为，因此应该没问题。
//! * 我们已经有一些数据可以跨展开边界传输，特别是 `Box<dyn Any + Send>`。像 Dwarf 异常一样，这两个指针作为有效载荷存储在异常本身中。
//! 但是，在 MSVC 上，不需要额外的堆分配，因为在执行过滤器函数时会保留调用栈。
//! 这意味着将指针直接传递到 `_CxxThrowException`，然后将其在过滤器函数中恢复以写入 `try` 内部函数的栈帧。
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // 这必须是一个 Option，因为我们通过 quot 捕获了异常，并且其析构函数由 C++ 运行时执行。
    // 当我们将 Box 排除在异常之外时，我们需要将异常保持在有效状态，以使其析构函数得以运行，而无需双重丢弃 Box。
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// 首先，介绍一堆类型定义。这里有一些特定于平台的奇怪之处，很多都是从 LLVM 中公然复制的。所有这些目的是通过调用 `_CxxThrowException` 来实现下面的 `panic` 函数。
//
// 此函数需要两个参数。第一个是指向我们要传递的数据的指针，在这种情况下，它是我们的 trait 对象。很容易找到! 但是，下一个更为复杂。
// 这是指向 `_ThrowInfo` 结构体的指针，通常仅用于描述所抛出的异常。
//
// 目前，[1] 类型的定义有点毛茸茸，主要的奇怪之处 (与在线文章不同) 是在 32 位上，指针是指针，但在 64 位上，指针表示为相对于 32 位偏移量。`__ImageBase` 符号。
//
// 以下模块中的 `ptr_t` 和 `ptr!` 宏用于表达这一点。
//
// 类型定义的迷宫还密切关注 LLVM 为此类操作发出的内容。例如，如果您在 MSVC 上编译此 C++ 代码并发出 LLVM IR:
//
//      #include <stdint.h>
//
//      struct rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2]; };
//
//      void foo() { rust_panic a = {0, 1};
//          throw a; }
//
// 从本质上讲，这就是我们要模仿的东西。下面的大多数常量值都是从 LLVM 复制的，
//
// 无论如何，这些结构都是以类似的方式构造的，对我们来说只是有些冗长。
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// 请注意，我们在这里有意忽略名称处理规则: 我们不希望 C++ 能够通过简单地声明 `struct rust_panic` 来捕获 Rust panics。
//
//
// 进行修改时，请确保类型名称字符串与 `compiler/rustc_codegen_llvm/src/intrinsic.rs` 中使用的字符串完全匹配。
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // 这里的前导 `\x01` 字节实际上是向 LLVM 发出的神奇信号，*不* 应用任何其他操作，例如以 `_` 字符作为前缀。
    //
    //
    // 此符号是 C++ `std::type_info` 使用的 vtable。
    // `std::type_info` 类型的对象 (类型描述符) 具有指向此表的指针。
    // 类型描述符由上面定义的 C++ EH 结构引用，并在下面构造。
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// 仅在引发异常时使用此类型描述符。
// catch 部分由 try 内部函数处理，try 内部函数生成自己的 TypeDescriptor。
//
// 这很好，因为 MSVC 运行时在类型名称上使用字符串比较来匹配 TypeDescriptor 而不是指针相等。
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// 如果 C++ 代码决定捕获异常并将其丢弃而不传播，则使用析构函数。
// try 内在函数的 catch 部分会将异常对象的第一个字设置为 0，以便析构函数将其跳过。
//
// 请注意，x86 Windows 对 C++ 成员函数使用 "thiscall" 调用约定，而不是默认的 "C" 调用约定。
//
// exception_copy 函数在这里有点特殊: 它由 MSVC 运行时在 try/catch 块下调用，我们在此处生成的 panic 将用作异常副本的结果。
//
// C++ 运行时使用它来支持捕获 std::exception_ptr 的异常，由于 Box<dyn Any> 不完整，我们无法支持该异常。
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException 完全在此栈帧上执行，因此无需将 `data` 转移到堆。
    // 我们只是将栈指针传递给该函数。
    //
    // 这里需要使用 ManuallyDrop，因为我们不希望在展开时删除 Exception。
    // 相反，它将由 C++ 运行时调用的 exception_cleanup 丢弃。
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // 这……可能看起来令人惊讶，而且理所当然地如此。在 32 位 MSVC 上，这些结构体之间的指针就是指针。
    // 但是，在 64 位 MSVC 上，结构之间的指针被表示为相对于 `__ImageBase` 的 32 位偏移量。
    //
    // 因此，在 32 位 MSVC 上，我们可以在上面的 `static` 中声明所有这些指针。
    // 在 64 位 MSVC 上，我们将不得不在静态变量中表示指针的减法，而 Rust 当前不允许这样做，因此我们实际上无法做到这一点。
    //
    // 接下来的第二件事是在运行时填充这些结构 (无论如何，恐慌已经是 "slow path")。
    // 因此，在这里，我们将所有这些指针字段重新解释为 32 位整数，然后将相关值存储到其中 (从原子上讲，可能会发生并发 panics)。
    //
    // 从技术上讲，运行时可能会以非原子方式读取这些字段，但是从理论上讲，它们从不读取 *rong* 值，因此它应该不会太糟...
    //
    // 在任何情况下，我们基本上都需要做这样的事情，直到我们可以在静态变量中表达更多的操作为止 (而且我们可能永远做不到)。
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // 此处的 NULL 负载意味着我们是从 __rust_try 的 (...) 捕获那里到达的。
    // 当捕获到非 Rust 外部异常时，会发生这种情况。
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// 这是编译器必须存在的 (例如，它是一个 lang 项)，但是实际上从来没有被编译器调用，因为 __C_specific_handler 或 _except_handler3 是始终使用的个性函数。
//
// 因此，这只是一个终止存根。
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}