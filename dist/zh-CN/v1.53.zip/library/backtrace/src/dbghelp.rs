//! 一个有助于在 Windows 上管理 dbghelp 绑定的模块
//!
//! Windows 上的回溯跟踪 (至少对于 MSVC 而言) 主要通过 `dbghelp.dll` 及其包含的各种函数提供支持。
//! 这些函数当前是动态加载的，而不是静态链接到 `dbghelp.dll`。
//! 目前，这是由标准库完成的 (理论上是由标准库完成的)，但是由于回溯通常是非常可选的，因此它旨在帮助减少库的静态 dll 依赖性。
//!
//! 话虽如此，`dbghelp.dll` 几乎总是成功地加载到 Windows 上。
//!
//! 请注意，尽管由于我们是动态加载所有这些支持，所以我们实际上不能在 `winapi` 中使用原始定义，而是需要自己定义函数指针类型并使用它。
//! 我们真的不希望复制 winapi，因此我们拥有 Cargo 功能 `verify-winapi`，该功能断言所有绑定均与 winapi 中的绑定匹配，并且此功能已在 CI 上启用。
//!
//! 最后，您会在这里注意到 `dbghelp.dll` 的 dll 从未卸载，这是当前故意的。
//! 这种想法是，我们可以全局缓存它，并在调用 API 之间使用它，避免昂贵的加载/卸载。
//! 如果这是泄漏检测器之类的问题，我们可以在到达那里时桥接。
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// 解决 Winapi 本身中不存在的 `SymGetOptions` 和 `SymSetOptions` 的问题。
// 否则，仅在我们针对 winapi 再次检查类型时使用。
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // 尚未在 winapi 中定义
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // 这是在 winapi 中定义的，但不正确 (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // 尚未在 winapi 中定义
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// 此宏用于定义 `Dbghelp` 结构体，该结构内部包含我们可能加载的所有函数指针。
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// `dbghelp.dll` 的已加载 DLL
            dll: HMODULE,

            // 我们可能使用的每个函数的每个函数指针
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // 最初我们还没有加载 DLL
            dll: 0 as *mut _,
            // 将所有函数的 Initiall 设置为零，以表示需要动态加载它们。
            //
            $($name: 0,)*
        };

        // 每个函数类型的便利 typedef。
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// 尝试打开 `dbghelp.dll`。
            /// 如果成功，则返回成功; 如果 `LoadLibraryW` 失败，则返回错误。
            ///
            /// Panics (如果已加载库)。
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // 我们要使用的每种方法的函数。
            // 调用时，它将读取缓存的函数指针或将其加载并返回已加载的值。
            // 断言负载成功。
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // 方便代理使用清理锁来引用 dbghelp 函数。
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// 初始化从 crate 访问 `dbghelp` API 函数所需的所有支持。
///
///
/// 请注意，此函数是安全的，它在内部具有自己的同步。
/// 另请注意，以递归方式多次调用此函数是安全的。
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // 我们需要做的第一件事就是同步这个函数。可以从其他线程并发调用，也可以在一个线程内递归调用。
        // 请注意，这比这要复杂得多，因为在此过程中，我们在此使用的 `dbghelp` 还必须与所有其他调用方同步到 `dbghelp`。
        //
        // 通常，在同一进程中实际上没有太多对 `dbghelp` 的调用，我们可以放心地假设我们是唯一访问它的人。
        // 但是，还有一个主要的其他用户，我们不得不担心的是讽刺的是我们自己，但是在标准库中。
        // Rust 标准库依赖于此 crate 来支持回溯，并且该 crate 也存在于 crates.io 上。
        // 这意味着，如果标准库正在打印 panic 回溯，则它可能与来自 crates.io 的 crate 竞争，从而导致段错误。
        //
        // 为了帮助解决此同步问题，我们在此处采用了 Windows 特有的技巧 (毕竟，这是 Windows 特有的关于同步的限制)。
        // 我们创建一个 *会话本地* 名为互斥锁来保护此调用。
        // 这里的意图是，标准库和此 crate 不必共享 Rust 级别的 API 即可在此处进行同步，而是可以在后台进行操作以确保它们彼此同步。
        //
        // 这样，当通过标准库或 crates.io 调用此函数时，我们可以确保获取了相同的互斥锁。
        //
        //  所以所有这一切都是说，我们要做的第一件事就是原子地创建一个 `HANDLE`，它是 Windows 上的一个命名互斥锁。
        // 我们与专门共享此函数的其他线程进行了一些同步，并确保每个此函数实例仅创建一个句柄。
        // 请注意，一旦将句柄存储在长度中，它就永远不会关闭。
        //
        // 实际执行锁定后，我们只需获取它，然后我们递出的 `Init` 句柄将最终负责将其丢弃。
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // 好，phew! 现在我们已经安全地同步了，让我们开始处理所有内容。
        // 首先，我们需要确保在此过程中实际加载了 `dbghelp.dll`。
        // 我们动态地执行此操作以避免静态依赖。
        // 从历史上讲，这样做是为了解决怪异的链接问题，它的目的是使二进制文件具有更高的可移植性，因为这在很大程度上只是调试实用程序。
        //
        //
        // 打开 `dbghelp.dll` 之后，我们需要在其中调用一些初始化函数，下面将对其进行详细说明。
        // 不过，我们只执行一次，因此我们有一个布尔值布尔值指示我们是否已经完成。
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // 确保设置了 `SYMOPT_DEFERRED_LOADS` 标志，因为根据 MSVC 自己的文档: "This is the fastest, most efficient way to use the symbol handler."，让我们开始吧!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // 实际上使用 MSVC 初始化符号。请注意，这可能会失败，但是我们将其忽略。
        // 本身并没有很多现有技术，但是 LLVM 内部似乎忽略了这里的返回值，并且 LLVM 中的一个消毒剂库在失败时会发出可怕的警告，但从长远来看基本上会忽略它。
        //
        //
        // Rust 出现了很多情况，就是标准库和 crates.io 上的 crate 都想竞争 `SymInitializeW`。
        // 历史上，标准库大多数时候都想初始化然后进行清理，但是现在它使用的是 crate，这意味着某个人将首先进行初始化，而另一个人将进行该初始化。
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}