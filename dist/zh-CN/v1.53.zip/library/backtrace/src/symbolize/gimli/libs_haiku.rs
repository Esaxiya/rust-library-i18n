// Haiku 实现了 image_info 结构和 get_next_image_info() 函数来迭代加载的可执行图像。
// image_info 结构体包含一个指向虚拟地址空间内 .text 部分开头的指针，以及该部分的大小。
//
// ELF 二进制文件的所有只读段都在地址空间的这一部分。
//
//

use super::mystd::borrow::ToOwned;
use super::mystd::ffi::{CStr, OsStr};
use super::mystd::os::unix::prelude::*;
use super::{Library, LibrarySegment, Vec};

pub(super) fn native_libraries() -> Vec<Library> {
    let mut libraries: Vec<Library> = Vec::new();

    unsafe {
        let mut info = mem::MaybeUninit::<libc::image_info>::zeroed();
        let mut cookie: i32 = 0;
        // 加载第一张图片以获取有效信息结构体
        let mut status =
            libc::get_next_image_info(libc::B_CURRENT_TEAM, &mut cookie, info.as_mut_ptr());
        if status != libc::B_OK {
            return libraries;
        }
        let mut info = info.assume_init();

        while status == libc::B_OK {
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: info.text_size as usize,
            });

            let bytes = CStr::from_ptr(info.name.as_ptr()).to_bytes();
            let name = OsStr::from_bytes(bytes).to_owned();
            libraries.push(Library {
                name: name,
                segments: segments,
                bias: info.text as usize,
            });

            status = libc::get_next_image_info(libc::B_CURRENT_TEAM, &mut cookie, &mut info);
        }
    }

    libraries
}