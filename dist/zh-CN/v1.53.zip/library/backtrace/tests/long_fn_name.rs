use backtrace::Backtrace;

// 50 个字符的模块名称
mod _234567890_234567890_234567890_234567890_234567890 {
    // 50 个字符的结构体名称
    #[allow(non_camel_case_types)]
    pub struct _234567890_234567890_234567890_234567890_234567890<T>(T);
    impl<T> _234567890_234567890_234567890_234567890_234567890<T> {
        #[allow(dead_code)]
        pub fn new() -> crate::Backtrace {
            crate::Backtrace::new()
        }
    }
}

// 长函数名称必须截断为 (MAX_SYM_NAME-1) 个字符。
// 仅对 msvc 运行此测试，因为 gnu 将为所有帧打印 "<no info>"。
#[test]
#[cfg(all(windows, target_env = "msvc"))]
fn test_long_fn_name() {
    use _234567890_234567890_234567890_234567890_234567890::_234567890_234567890_234567890_234567890_234567890 as S;

    // 结构体名称的 10 个重复，因此完全合格的函数名称至少为 10 *(50 + 50)* 2=2000 个字符长。
    //
    // 实际上它更长，因为它还包含 `::`，`<>` 和当前模块的名称
    //
    let bt = S::<S<S<S<S<S<S<S<S<S<i32>>>>>>>>>>::new();
    println!("{:?}", bt);

    let mut found_long_name_frame = false;

    for frame in bt.frames() {
        let symbols = frame.symbols();
        if symbols.is_empty() {
            continue;
        }

        if let Some(function_name) = symbols[0].name() {
            let function_name = function_name.as_str().unwrap();
            if function_name.contains("::_234567890_234567890_234567890_234567890_234567890") {
                found_long_name_frame = true;
                assert!(function_name.len() > 200);
            }
        }
    }

    assert!(found_long_name_frame);
}