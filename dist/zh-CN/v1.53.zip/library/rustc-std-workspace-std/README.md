# `rustc-std-workspace-std` crate

请参见 `rustc-std-workspace-core` crate 的文档。