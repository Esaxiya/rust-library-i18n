//! 通过流程中止实现 Rust panics
//!
//! 与通过展开的实现相比，此 crate 简单得多! 话虽这么说，它不是很通用，但是可以了!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

#[cfg(target_os = "android")]
mod android;

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" 有效载荷并填充到相关平台上的相关终端。
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    // Android 能够附加消息作为中止的一部分。
    #[cfg(target_os = "android")]
    android::android_set_abort_message(_payload);

    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // 调用 std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // 在 Windows 上，使用特定于处理器的 __fastfail 机制。在 Windows 8 和更高版本中，这将立即终止进程，而无需运行任何进程内异常处理程序。
            // 在 Windows 的早期版本中，此指令序列将被视为访问冲突，从而终止进程，但不必绕过所有异常处理程序。
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: 这与 libstd `abort_internal` 中的实现相同
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// 这... 有点奇怪。The tl;dr; 是正确链接所必需的，下面将进行详细说明。
//
// 现在，我们出厂的 libcore/libstd 二进制文件都已用 `-C panic=unwind` 编译。这样做是为了确保二进制文件最大程度地与尽可能多的情况兼容。
// 但是，对于使用 `-C panic=unwind` 编译的所有函数，编译器都需要 "personality function"。此个性函数被硬编码为符号 `rust_eh_personality`，并由 `eh_personality` lang 项定义。
//
// So...
// 为什么不在这里定义该 lang 项? 好问题! panic 运行时的链接方式实际上有点微妙，因为它们在编译器的 crate 存储区中是 "sort of"，但只有在另一个未链接时才实际链接。
//
// 结束意味着这 crate 和 panic_unwind crate 都可以出现在编译器的 crate 存储中，如果两者都定义了 `eh_personality` lang 项，那么将报错。
//
// 要解决此问题，如果链接到的 panic 运行时是展开运行时，则仅要求定义 `eh_personality`，否则就不需要定义 (正确地如此)。
// 但是，在这种情况下，该库仅定义了此符号，因此某处至少具有某些个性。
//
// 本质上，此符号只是为了连接到 libcore/libstd 二进制文件而定义的，但由于我们根本不在展开运行时中链接，因此永远不应调用它。
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // 在 x86_64-pc-windows-gnu 上，我们使用自己的个性函数，当我们传递所有帧时，该函数需要返回 `ExceptionContinueSearch`。
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // 与上面类似，这对应于当前仅在 Emscripten 上使用的 `eh_catch_typeinfo` lang 项。
    //
    // 由于 panics 不会生成异常，并且外部异常当前是 -C panic = 终止的 UB (尽管可能会更改)，所以任何 catch_unwind 调用将永远不会使用此 typeinfo。
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // 我们的启动对象在 i686-pc-windows-gnu 上调用了这两个对象，但是它们不需要执行任何操作，因此它们的主体是点头的。
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}