//! 将十进制字符串转换为 IEEE 754 二进制浮点数。
//!
//! # 问题陈述
//!
//! 我们给了一个十进制字符串，例如 `12.34e56`。
//! 该字符串由整数 (`12`)，小数 (`34`) 和指数 (`56`) 组成。所有部分都是可选的，缺少则解释为零。
//!
//! 我们寻求最接近十进制字符串确切值的 IEEE 754 浮点数。
//! 众所周知，许多十进制字符串在基数 2 中都没有终止表示，因此我们将 0.5 单位最后舍入 (换句话说，尽可能)。
//! 领带 (精确到两个连续浮点之间的中间的十进制值) 通过半对偶策略 (也称为银行家舍入) 来解决。
//!
//! 不用说，这在实现复杂性和所用的 CPU 周期方面都相当困难。
//!
//! # Implementation
//!
//! 首先，我们忽略迹象。或者更确切地说，我们在转换过程的开始就将其删除，然后在结束时将其重新应用。
//! 这在所有 edge 情况下都是正确的，因为 IEEE 浮点数对称于零左右，取反则仅翻转第一位。
//!
//! 然后，我们通过调整指数来删除小数点: 从概念上讲，`12.34e56` 变为 `1234e54`，我们用正整数 `f = 1234` 和整数 `e = 54` 对其进行描述。
//! 在解析阶段之后，几乎所有代码都使用 `(f, e)` 表示形式。
//!
//! 然后，我们尝试使用机器大小的整数和较小的，固定大小的浮点数 (首先是 `f32`/`f64`，然后是具有 64 位有效数字的类型 `Fp`)，尝试一长串越来越普通和昂贵的特殊情况。
//!
//! 如果所有这些方法都失败了，我们会硬着头皮，诉诸于一种简单但非常缓慢的算法，该算法需要完全计算 `f * 10^e`，然后进行迭代搜索以寻求最佳近似值。
//!
//! 首先，此模块及其子级实现以下算法:
//! "How to Read Floating Point Numbers Accurately" by William D.
//! Clinger, available online: <http://citeseerx.ist.psu.edu/viewdoc/summary?doi=10.1.1.45.4152>
//!
//! 此外，本文中使用了许多辅助函数，但 Rust (或至少在内核中) 不可用。
//! 我们的版本由于需要处理上溢和下溢以及处理次正规数的需求而变得更加复杂。
//! Bellerophon 和算法 R 在上溢，子正常和下溢方面存在问题。
//! 在输入进入关键区域之前，我们会保守地切换到算法 M (具有本文第 8 节中描述的修改)。
//!
//! 需要注意的另一个方面是 ``RawFloat`` trait，几乎所有函数都通过 ``RawFloat`` trait 进行了参数化。有人可能认为解析为 `f64` 并将结果转换为 `f32` 就足够了。
//! 不幸的是，这不是我们生活的世界，这与使用基数二进位或半到四舍五入四舍五入无关。
//!
//! 例如，考虑两种类型的 `d2` 和 `d4`，它们代表具有两个十进制数字和四个十进制数字的十进制类型，并以 "0.01499" 作为输入。让我们使用上半舍入。
//! 直接转到两位十进制数字将得到 `0.01`，但是如果我们首先四舍五入到四位数字，则会得到 `0.0150`，然后将其四舍五入为 `0.02`。
//! 同样的原理也适用于其他操作，如果要获得 0.5 ULP 精度，则需要 *进行全精度的所有操作，并在末尾将* exactly once 舍入*，同时考虑所有截断的位。
//!
//! FIXME: 尽管某些代码重复是必要的，但也许可以对部分代码进行混洗，以便减少重复的代码。
//! 算法的大部分不依赖于 float 类型来输出，或者仅需要访问一些常量即可作为参数传递。
//!
//! # Other
//!
//! 转换应 *从不* panic。
//! 在代码中有断言和显式的 panics，但是它们绝不应该被触发，而仅用作内部的健全性检查。任何 panics 都应视为错误。
//!
//! 虽然有单元测试，但它们在确保正确性上还远远不够，它们只覆盖了很小一部分可能的错误。
//! 更广泛的测试作为 Python 脚本位于目录 `src/etc/test-float-parse` 中。
//!
//! 关于整型溢出的注意事项: 该文件的许多部分都使用十进制指数 `e` 来执行算术运算。
//! 首先，我们将小数点移动: 在第一个十进制数字之前，在最后一个十进制数字之后，依此类推。如果不小心这样做可能会溢出。
//! 我们依靠解析子模块仅分发足够小的指数，其中 "sufficient" 表示 "such that the exponent +/- the number of decimal digits fits into a 64 bit integer"。
//! 较大的指数被接受，但是我们不对它们进行算术运算，它们立即变成 {positive,negative} {zero,infinity}。
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![doc(hidden)]
#![unstable(
    feature = "dec2flt",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

use crate::fmt;
use crate::str::FromStr;

use self::num::digits_to_big;
use self::parse::{parse_decimal, Decimal, ParseResult, Sign};
use self::rawfp::RawFloat;

mod algorithm;
mod num;
mod table;
// 这两个有自己的测试。
pub mod parse;
pub mod rawfp;

macro_rules! from_str_float_impl {
    ($t:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl FromStr for $t {
            type Err = ParseFloatError;

            /// 将以 10 为底的字符串转换为浮点数。
            /// 接受可选的十进制指数。
            ///
            /// 该函数接受诸如以下的字符串
            ///
            /// * '3.14'
            /// * '-3.14'
            /// * '2.5E10', 或等效地， '2.5e10'
            /// * '2.5E-10'
            /// * '5.'
            /// * '.5', 或者，等效地， '0.5'
            /// * 'inf', '-inf', 'NaN'
            ///
            /// 前导和尾随空格表示错误。
            ///
            /// # Grammar
            ///
            /// 遵循以下 [EBNF] 语法的所有字符串都将导致返回 [`Ok`]:
            ///
            ///
            /// ```txt
            /// Float  ::= Sign? ( 'inf' | 'NaN' | Number )
            /// Number ::= ( Digit+ |
            ///              Digit+ '.' Digit* |
            ///              Digit* '.' Digit+ ) Exp?
            /// Exp    ::= [eE] Sign? Digit+
            /// Sign   ::= [+-]
            /// Digit  ::= [0-9]
            /// ```
            ///
            /// [EBNF]: https://www.w3.org/TR/REC-xml/#sec-notation
            ///
            /// # 已知错误
            ///
            /// 在某些情况下，应该创建有效浮点数的某些字符串会返回错误。
            /// 有关详细信息，请参见 [issue #31407]。
            ///
            /// [issue #31407]: https://github.com/rust-lang/rust/issues/31407
            ///
            /// # Arguments
            ///
            /// * src - 字符串
            ///
            /// # 返回值
            ///
            /// `Err(ParseFloatError)` 如果字符串不代表有效数字。
            /// 否则，为 `Ok(n)`，其中 `n` 是 `src` 表示的浮点数。
            ///
            #[inline]
            fn from_str(src: &str) -> Result<Self, ParseFloatError> {
                dec2flt(src)
            }
        }
    };
}
from_str_float_impl!(f32);
from_str_float_impl!(f64);

/// 解析浮点数时可以返回的错误。
///
/// 该错误用作 [`f32`] 和 [`f64`] 的 [`FromStr`] 实现的错误类型。
///
///
/// # Example
///
/// ```
/// use std::str::FromStr;
///
/// if let Err(e) = f64::from_str("a.12") {
///     println!("Failed conversion to f64: {}", e);
/// }
/// ```
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseFloatError {
    kind: FloatErrorKind,
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum FloatErrorKind {
    Empty,
    Invalid,
}

impl ParseFloatError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            FloatErrorKind::Empty => "cannot parse float from empty string",
            FloatErrorKind::Invalid => "invalid float literal",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseFloatError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

fn pfe_empty() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Empty }
}

fn pfe_invalid() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Invalid }
}

/// 将十进制字符串拆分为符号和剩余部分，而无需检查或验证其余部分。
fn extract_sign(s: &str) -> (Sign, &str) {
    match s.as_bytes()[0] {
        b'+' => (Sign::Positive, &s[1..]),
        b'-' => (Sign::Negative, &s[1..]),
        // 如果字符串无效，则我们永远不会使用符号，因此我们无需在此处进行验证。
        _ => (Sign::Positive, s),
    }
}

/// 将十进制字符串转换为浮点数。
fn dec2flt<T: RawFloat>(s: &str) -> Result<T, ParseFloatError> {
    if s.is_empty() {
        return Err(pfe_empty());
    }
    let (sign, s) = extract_sign(s);
    let flt = match parse_decimal(s) {
        ParseResult::Valid(decimal) => convert(decimal)?,
        ParseResult::ShortcutToInf => T::INFINITY,
        ParseResult::ShortcutToZero => T::ZERO,
        ParseResult::Invalid => {
            if s.eq_ignore_ascii_case("nan") {
                T::NAN
            } else if s.eq_ignore_ascii_case("inf") || s.eq_ignore_ascii_case("infinity") {
                T::INFINITY
            } else {
                return Err(pfe_invalid());
            }
        }
    };

    match sign {
        Sign::Positive => Ok(flt),
        Sign::Negative => Ok(-flt),
    }
}

/// 十进制到浮点转换的主要动力: 统筹所有预处理并确定哪种算法应进行实际转换。
///
fn convert<T: RawFloat>(mut decimal: Decimal<'_>) -> Result<T, ParseFloatError> {
    simplify(&mut decimal);
    if let Some(x) = trivial_cases(&decimal) {
        return Ok(x);
    }
    // Remove/shift 掉小数点
    let e = decimal.exp - decimal.fractional.len() as i64;
    if let Some(x) = algorithm::fast_path(decimal.integral, decimal.fractional, e) {
        return Ok(x);
    }
    // Big32x40 限制为 1280 位，即大约 385 个十进制数字。
    // 如果超过此值，我们将崩溃，因此我们会在距离太近 (在 10 ^ 10 以内) 之前出错。
    let upper_bound = bound_intermediate_digits(&decimal, e);
    if upper_bound > 375 {
        return Err(pfe_invalid());
    }
    let f = digits_to_big(decimal.integral, decimal.fractional);

    // 现在，指数肯定适合 16 位，整个主要算法都使用该位。
    let e = e as i16;
    // FIXME 这些界限相当保守。
    // 对 Bellerophon 的故障模式进行更仔细的分析可能会允许在更多情况下使用它，从而大幅度提高速度。
    let exponent_in_range = table::MIN_E <= e && e <= table::MAX_E;
    let value_in_range = upper_bound <= T::MAX_NORMAL_DIGITS as u64;
    if exponent_in_range && value_in_range {
        Ok(algorithm::bellerophon(&f, e))
    } else {
        Ok(algorithm::algorithm_m(&f, e))
    }
}

// 如所写，这会导致优化效果不佳 (请参见 #27130，尽管它引用的是旧版本的代码)。
// `inline(always)` 是一种解决方法。
// 总体上只有两个调用站点，并且不会使代码大小变糟。

/// 即使可能需要去除指数，也应尽可能去除零
#[inline(always)]
fn simplify(decimal: &mut Decimal<'_>) {
    let is_zero = &|&&d: &&u8| -> bool { d == b'0' };
    // 修剪这些零不会改变任何内容，但可以启用快速路径 (<15 位数字)。
    let leading_zeros = decimal.integral.iter().take_while(is_zero).count();
    decimal.integral = &decimal.integral[leading_zeros..];
    let trailing_zeros = decimal.fractional.iter().rev().take_while(is_zero).count();
    let end = decimal.fractional.len() - trailing_zeros;
    decimal.fractional = &decimal.fractional[..end];
    // 简化形式为 0.0...x 和 x...0.0 的数字，并相应地调整指数。
    // 这可能并不总是一个胜利 (可能会将一些数字排除在快速路径之外)，但会显着简化其他部分 (尤其是近似值的大小)。
    //
    if decimal.integral.is_empty() {
        let leading_zeros = decimal.fractional.iter().take_while(is_zero).count();
        decimal.fractional = &decimal.fractional[leading_zeros..];
        decimal.exp -= leading_zeros as i64;
    } else if decimal.fractional.is_empty() {
        let trailing_zeros = decimal.integral.iter().rev().take_while(is_zero).count();
        let end = decimal.integral.len() - trailing_zeros;
        decimal.integral = &decimal.integral[..end];
        decimal.exp += trailing_zeros as i64;
    }
}

/// 返回算法 R 和算法 M 在处理给定小数时将计算的最大值的大小 (log10) 的快速脏上限。
///
fn bound_intermediate_digits(decimal: &Decimal<'_>, e: i64) -> u64 {
    // 由于 trivial_cases() 和解析器为我们筛选出了最极端的输入，因此我们不必担心这里的溢出。
    //
    let f_len: u64 = decimal.integral.len() as u64 + decimal.fractional.len() as u64;
    if e >= 0 {
        // 在 e >= 0 的情况下，两种算法都计算大约 `f * 10^e`。
        // 算法 R 对此进行了一些复杂的计算，但是对于上限，我们可以忽略它，因为它还会预先减小分数，因此我们在那里有很多缓冲区。
        //
        f_len + (e as u64)
    } else {
        // 如果 e < 0，则算法 R 做大致相同的事情，但是算法 M 不同:
        // 它试图找到一个正数 k，以使 `f << k / 10^e` 是有效范围内的有效数字。
        // 这将导致大约 `2^53 *f* 10^e` <`10^17 *f* 10^e`。
        // 触发此操作的一个输入为 0.33 ... 33 (375 x 3)。
        f_len + e.unsigned_abs() + 17
    }
}

/// 无需查看十进制数字即可检测到明显的上溢和下溢。
fn trivial_cases<T: RawFloat>(decimal: &Decimal<'_>) -> Option<T> {
    // 有零，但它们被 simplify() 去掉了
    if decimal.integral.is_empty() && decimal.fractional.is_empty() {
        return Some(T::ZERO);
    }
    // 这是 ceil(log10(the real value)) 的粗略近似值。
    // 我们在这里不必担心溢出问题，因为输入长度很小 (至少与 2 ^ 64 相比)，并且解析器已经处理了绝对值大于 10 ^ 18 (仍然短 10 ^ 19 的指数) 2 ^ 64)。
    //
    //
    let max_place = decimal.exp + decimal.integral.len() as i64;
    if max_place > T::INF_CUTOFF {
        return Some(T::INFINITY);
    } else if max_place < T::ZERO_CUTOFF {
        return Some(T::ZERO);
    }
    None
}