use crate::fmt;

/// 创建一个新的迭代器，每次迭代都调用提供的闭包 `F: FnMut() -> Option<T>`。
///
/// 这允许创建具有任何行为的自定义迭代器，而无需使用更冗长的语法来创建专用类型并为其实现 [`Iterator`] trait。
///
/// 请注意，`FromFn` 迭代器不会对闭包的行为进行假设，因此保守地不会实现 [`FusedIterator`]，也不会从默认 `(0, None)` 覆盖 [`Iterator::size_hint()`]。
///
///
/// 闭包可以使用捕获及其环境来跟踪迭代之间的状态。根据迭代器的使用方式，这可能需要在闭包上指定 [`move`] 关键字。
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// 让我们从 [module-level documentation] 重新实现计数器迭代器:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // 增加我们的数量。这就是为什么我们从零开始。
///     count += 1;
///
///     // 检查我们是否已经完成计数。
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// 一个迭代器，每次迭代调用提供的闭包 `F: FnMut() -> Option<T>`。
///
/// 该 `struct` 由 [`iter::from_fn()`] 函数创建。
/// 有关更多信息，请参见其文档。
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}