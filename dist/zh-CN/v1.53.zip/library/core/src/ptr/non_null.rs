use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` 但非零且协变。
///
/// 在使用裸指针构建数据结构时，这通常是正确的选择，但由于其额外的属性，最终使用起来更加危险。如果不确定是否应使用 `NonNull<T>`，请使用 `*mut T`!
///
/// 与 `*mut T` 不同，即使从未解引用指针，指针也必须始终为非 null。这样一来，枚举就可以将此禁止值用作判别式 - `Option<NonNull<T>>` 与 `*mut T` 具有相同的大小。
/// 但是，如果指针未解引用，它可能仍会悬垂。
///
/// 与 `*mut T` 不同，选择 `NonNull<T>` 作为 `T` 的协变。这样就可以在构建协变类型时使用 `NonNull<T>`，但是如果在实际上不应该协变的类型中使用，则会带来不健全的风险。
/// (尽管从技术上讲，不健全只能由调用不安全的函数引起，但对于 `*mut T` 却做出了相反的选择。)
///
/// 对于大多数安全抽象，例如 `Box`，`Rc`，`Arc`，`Vec` 和 `LinkedList`，协方差是正确的。之所以如此，是因为它们提供了遵循 Rust 的常规共享 XOR 可变规则的公共 API。
///
/// 如果您的类型不能安全地协变，则必须确保它包含一些附加字段以提供不变性。通常，此字段是 [`PhantomData`] 类型，例如 `PhantomData<Cell<T>>` 或 `PhantomData<&'a mut T>`。
///
/// 请注意，`NonNull<T>` 具有 `&T` 的 `From` 实例。但是，这不会改变以下事实: 除非通过 [`UnsafeCell<T>`] 内部发生可变的，否则通过 (从 a 派生的指针) 进行共享引用的可变的是未定义的行为。从共享引用创建变量引用也是如此。
///
/// 当使用不带 `UnsafeCell<T>` 的 `From` 实例时，您有责任确保从不调用 `as_mut`，并且从不使用 `as_ptr` 进行可变的。
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` 指针不是 `Send`，因为它们引用的数据可能是别名的。
// 注意，此暗示不是必需的，但应提供更好的错误消息。
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` 指针不是 `Sync`，因为它们引用的数据可能是别名的。
// 注意，此暗示不是必需的，但应提供更好的错误消息。
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// 创建一个悬空但对齐良好的新 `NonNull`。
    ///
    /// 与 `Vec::new` 一样，这对于初始化延迟分配的类型很有用。
    ///
    /// 请注意，该指针值可能表示一个指向 `T` 的有效指针，这意味着不得将其用作 "not yet initialized" 标记值。
    /// 延迟分配的类型必须通过其他某种方式来跟踪初始化。
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.36.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // SAFETY: mem::align_of () 返回一个非零的 usize，然后将其强制转换为 *mut T。
        // 因此，`ptr` 不为空，并且遵守了调用 new_unchecked() 的条件。
        //
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// 返回该值的共享引用。与 [`as_ref`] 相比，这不需要将该值初始化。
    ///
    /// 对于可变的对应物，请参见 [`as_uninit_mut`]。
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// 调用此方法时，必须确保满足以下所有条件:
    ///
    /// * 指针必须正确对齐。
    ///
    /// * 在 [the module documentation] 中定义的意义上，它必须是 "dereferencable"。
    ///
    /// * 您必须执行 Rust 的别名规则，因为返回的生命周期 `'a` 是任意选择的，不一定反映数据的实际生命周期。
    ///
    ///   特别是，在此生命周期的持续时间内，指针所指向的内存一定不能被可变的 (`UnsafeCell` 内部除外)。
    ///
    /// 即使未使用此方法的结果也是如此!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(&self) -> &'a MaybeUninit<T> {
        // SAFETY: 调用者必须保证 `self` 满足引用的所有要求。
        //
        unsafe { &*self.cast().as_ptr() }
    }

    /// 返回该值的唯一引用。与 [`as_mut`] 相比，这不需要将该值初始化。
    ///
    /// 有关共享副本，请参见 [`as_uninit_ref`]。
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// 调用此方法时，必须确保满足以下所有条件:
    ///
    /// * 指针必须正确对齐。
    ///
    /// * 在 [the module documentation] 中定义的意义上，它必须是 "dereferencable"。
    ///
    /// * 您必须执行 Rust 的别名规则，因为返回的生命周期 `'a` 是任意选择的，不一定反映数据的实际生命周期。
    ///
    ///   特别是，在此生命周期的持续时间内，指针所指向的内存一定不能通过任何其他指针进行访问 (读取或写入)。
    ///
    /// 即使未使用此方法的结果也是如此!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut<'a>(&mut self) -> &'a mut MaybeUninit<T> {
        // SAFETY: 调用者必须保证 `self` 满足引用的所有要求。
        //
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// 创建一个新的 `NonNull`。
    ///
    /// # Safety
    ///
    /// `ptr` 必须为非 null。
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.25.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SAFETY: 调用者必须保证 `ptr` 不为空。
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// 如果 `ptr` 不为空，则创建一个新的 `NonNull`。
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SAFETY: 指针已被检查并且不为 null
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// 执行与 [`std::ptr::from_raw_parts`] 相同的功能，除了返回 `NonNull` 指针 (与原始 `*const` 指针相反)。
    ///
    ///
    /// 有关更多详细信息，请参见 [`std::ptr::from_raw_parts`] 的文档。
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // SAFETY: `ptr::from::raw_parts_mut` 的结果为非空值，因为 `data_address` 为非。
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// 将 (可能是很宽的) 指针分解为地址和元数据组件。
    ///
    /// 以后可以使用 [`NonNull::from_raw_parts`] 重建指针。
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// 获取基础的 `*mut` 指针。
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// 返回该值的共享引用。如果该值可能未初始化，则必须改用 [`as_uninit_ref`]。
    ///
    /// 对于可变的对应物，请参见 [`as_mut`]。
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// 调用此方法时，必须确保满足以下所有条件:
    ///
    /// * 指针必须正确对齐。
    ///
    /// * 在 [the module documentation] 中定义的意义上，它必须是 "dereferencable"。
    ///
    /// * 指针必须指向 `T` 的初始化实例。
    ///
    /// * 您必须执行 Rust 的别名规则，因为返回的生命周期 `'a` 是任意选择的，不一定反映数据的实际生命周期。
    ///
    ///   特别是，在此生命周期的持续时间内，指针所指向的内存一定不能被可变的 (`UnsafeCell` 内部除外)。
    ///
    /// 即使未使用此方法的结果也是如此!
    /// (关于初始化的部分尚未完全决定，但是直到确定之前，唯一安全的方法是确保它们确实被初始化。)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(&self) -> &'a T {
        // SAFETY: 调用者必须保证 `self` 满足引用的所有要求。
        //
        unsafe { &*self.as_ptr() }
    }

    /// 返回该值的唯一引用。如果该值可能未初始化，则必须改用 [`as_uninit_mut`]。
    ///
    /// 有关共享副本，请参见 [`as_ref`]。
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// 调用此方法时，必须确保满足以下所有条件:
    ///
    /// * 指针必须正确对齐。
    ///
    /// * 在 [the module documentation] 中定义的意义上，它必须是 "dereferencable"。
    ///
    /// * 指针必须指向 `T` 的初始化实例。
    ///
    /// * 您必须执行 Rust 的别名规则，因为返回的生命周期 `'a` 是任意选择的，不一定反映数据的实际生命周期。
    ///
    ///   特别是，在此生命周期的持续时间内，指针所指向的内存一定不能通过任何其他指针进行访问 (读取或写入)。
    ///
    /// 即使未使用此方法的结果也是如此!
    /// (关于初始化的部分尚未完全决定，但是直到确定之前，唯一安全的方法是确保它们确实被初始化。)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut<'a>(&mut self) -> &'a mut T {
        // SAFETY: 调用者必须保证 `self` 满足可变引用的所有要求。
        //
        unsafe { &mut *self.as_ptr() }
    }

    /// 强制转换为另一种类型的指针。
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.36.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // SAFETY: `self` 是一个 `NonNull` 指针，该指针必须非空
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// 根据细指针和长度创建非空的原始切片。
    ///
    /// `len` 参数是 **元素** 的数量，而不是字节数。
    ///
    /// 此函数是安全的，但解引用的返回值不安全。
    /// 有关切片的安全要求，请参见 [`slice::from_raw_parts`] 的文档。
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // 从指向第一个元素的指针开始创建切片指针
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (请注意，此示例人为地演示了此方法的用法，但是 `let slice = NonNull::from(&x[..]);` 是编写这样的代码的更好方法。)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // SAFETY: `data` 是一个 `NonNull` 指针，该指针必须非空
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// 返回非空原始切片的长度。
    ///
    /// 返回的值是 **elements** 的数量，而不是字节数。
    ///
    /// 即使由于指针没有有效地址而无法将非空原始切片重新引用到切片时，此函数也是安全的。
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// 返回指向切片缓冲区的非 null 指针。
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // SAFETY: 我们知道 `self` 不为空。
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// 将裸指针返回到切片的缓冲区。
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// 返回对可能未初始化的值的切片的共享引用。与 [`as_ref`] 相比，这不需要将该值初始化。
    ///
    /// 对于可变的对应物，请参见 [`as_uninit_slice_mut`]。
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// 调用此方法时，必须确保满足以下所有条件:
    ///
    /// * 指针必须为 [valid]，才能读取许多字节的 `ptr.len() * mem::size_of::<T>()`，并且必须正确对齐。这尤其意味着:
    ///
    ///     * 该切片的整个存储范围必须包含在一个分配的对象中!
    ///       切片永远不能跨越多个分配的对象。
    ///
    ///     * 即使对于零长度的切片，指针也必须对齐。
    ///     这样做的一个原因是，枚举布局优化可能依赖于对齐的引用 (包括任何长度的切片) 和非空值，以将它们与其他数据区分开。
    ///
    ///     您可以使用 [`NonNull::dangling()`] 获得可用作零长度切片的 `data` 的指针。
    ///
    /// * 切片的总大小 `ptr.len() * mem::size_of::<T>()` 不能大于 `isize::MAX`。
    ///   请参见 [`pointer::offset`] 的安全文档。
    ///
    /// * 您必须执行 Rust 的别名规则，因为返回的生命周期 `'a` 是任意选择的，不一定反映数据的实际生命周期。
    ///   特别是，在此生命周期的持续时间内，指针所指向的内存一定不能被可变的 (`UnsafeCell` 内部除外)。
    ///
    /// 即使未使用此方法的结果也是如此!
    ///
    /// 另请参见 [`slice::from_raw_parts`]。
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(&self) -> &'a [MaybeUninit<T>] {
        // SAFETY: 调用者必须坚持 `as_uninit_slice` 的安全保证。
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// 返回可能未初始化值的切片的唯一引用。与 [`as_mut`] 相比，这不需要将该值初始化。
    ///
    /// 有关共享副本，请参见 [`as_uninit_slice`]。
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// 调用此方法时，必须确保满足以下所有条件:
    ///
    /// * 指针必须为 [valid] 才能进行 `ptr.len() * mem::size_of::<T>()` 多个字节的读取和写入，并且必须正确对齐。这尤其意味着:
    ///
    ///     * 该切片的整个存储范围必须包含在一个分配的对象中!
    ///       切片永远不能跨越多个分配的对象。
    ///
    ///     * 即使对于零长度的切片，指针也必须对齐。
    ///     这样做的一个原因是，枚举布局优化可能依赖于对齐的引用 (包括任何长度的切片) 和非空值，以将它们与其他数据区分开。
    ///
    ///     您可以使用 [`NonNull::dangling()`] 获得可用作零长度切片的 `data` 的指针。
    ///
    /// * 切片的总大小 `ptr.len() * mem::size_of::<T>()` 不能大于 `isize::MAX`。
    ///   请参见 [`pointer::offset`] 的安全文档。
    ///
    /// * 您必须执行 Rust 的别名规则，因为返回的生命周期 `'a` 是任意选择的，不一定反映数据的实际生命周期。
    ///   特别是，在此生命周期的持续时间内，指针所指向的内存一定不能通过任何其他指针进行访问 (读取或写入)。
    ///
    /// 即使未使用此方法的结果也是如此!
    ///
    /// 另请参见 [`slice::from_raw_parts_mut`]。
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // 这是安全的，因为 `memory` 对于许多字节的 `memory.len()` 读和写有效。
    /// // 请注意，此处不允许调用 `memory.as_mut()`，因为内容可能未初始化。
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut<'a>(&self) -> &'a mut [MaybeUninit<T>] {
        // SAFETY: 调用者必须坚持 `as_uninit_slice_mut` 的安全保证。
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// 将裸指针返回到元素或子切片，而不进行边界检查。
    ///
    /// 即使未使用生成的指针，使用越界索引或无法使用 `self` 调用此方法也是 [*[undefined 行为]*。
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // SAFETY: 调用方确保 `self` 是可解引用的，并且 `index` 是入站的。
        // 因此，结果指针不能为 NULL。
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // SAFETY: 唯一指针不能为空，因此必须遵守 new_unchecked() 的条件。
        //
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SAFETY: 可变引用不能为空。
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // SAFETY: 引用不能为空，因此必须遵守 new_unchecked() 的条件。
        //
        unsafe { NonNull { pointer: reference as *const T } }
    }
}